"""
pydaw.flux.ui_widgets.slider — Frigg.SliderV/H (Phase U-2/U-3)
===============================================================

PureData-Style Slider — vertikal oder horizontal. Drag verschiebt den
Schieber, der Wert wird linear interpoliert zwischen min und max.
Doppelklick = Reset auf Default. Mausrad = ±1 Step.

Eingebaut in v0.0.21.195.
"""

from __future__ import annotations

import logging
from typing import Optional

logger = logging.getLogger(__name__)


try:
    from PyQt6.QtCore import Qt, QRectF, QSize, pyqtSignal
    from PyQt6.QtGui import QColor, QPainter, QPen, QBrush
    from PyQt6.QtWidgets import QWidget, QSizePolicy
    _QT_AVAILABLE = True
except ImportError:
    _QT_AVAILABLE = False


def _clamp(x: float, lo: float, hi: float) -> float:
    if lo > hi:
        lo, hi = hi, lo
    return max(lo, min(hi, x))


if _QT_AVAILABLE:

    class SliderWidget(QWidget):  # type: ignore[misc]
        """Kontinuierlicher Slider — vertikal oder horizontal.

        Signale
        -------
        ``value_changed(float)`` — feuert beim Drag/Wheel/Reset.

        Parameter
        ---------
        orientation
            "vertical" | "horizontal"
        """

        WHEEL_STEPS_PER_RANGE = 100
        DRAG_FINE_TUNE_DIVISOR = 10

        COL_BG = "#0a0e14"
        COL_BORDER = "#1a1f29"
        COL_TRACK = "#13181f"
        COL_FILL = "#3df0e0"
        COL_HANDLE = "#7df0e0"

        value_changed = pyqtSignal(float)

        def __init__(
            self,
            value: float = 0.5,
            minimum: float = 0.0,
            maximum: float = 1.0,
            default: Optional[float] = None,
            orientation: str = "vertical",
            parent=None,
        ):
            super().__init__(parent)
            if maximum <= minimum:
                maximum = minimum + 1.0
            self._minimum = float(minimum)
            self._maximum = float(maximum)
            self._default = float(default) if default is not None else float(value)
            self._value = _clamp(float(value), self._minimum, self._maximum)
            self._orient = orientation if orientation in ("vertical", "horizontal") else "vertical"

            if self._orient == "vertical":
                self.setMinimumSize(20, 100)
                self.setMaximumSize(28, 160)
            else:
                self.setMinimumSize(100, 20)
                self.setMaximumSize(160, 28)
            self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)

            self._dragging = False
            self.setMouseTracking(True)
            self.setToolTip(self._tooltip())

        @property
        def value(self) -> float:
            return self._value

        @property
        def minimum(self) -> float:
            return self._minimum

        @property
        def maximum(self) -> float:
            return self._maximum

        def set_value(self, value: float, *, emit_signal: bool = True) -> None:
            new_v = _clamp(float(value), self._minimum, self._maximum)
            if new_v == self._value:
                return
            self._value = new_v
            if emit_signal:
                self.value_changed.emit(self._value)
            self.setToolTip(self._tooltip())
            self.update()

        def reset_to_default(self) -> None:
            self.set_value(self._default, emit_signal=True)

        def _value_from_position(self, x: float, y: float) -> float:
            range_ = self._maximum - self._minimum
            w = self.width()
            h = self.height()
            margin = 4
            if self._orient == "vertical":
                # oben = max, unten = min
                track_h = h - 2 * margin
                t = (h - margin - y) / max(track_h, 1.0)
            else:
                track_w = w - 2 * margin
                t = (x - margin) / max(track_w, 1.0)
            t = _clamp(t, 0.0, 1.0)
            return self._minimum + t * range_

        def mousePressEvent(self, event):  # type: ignore[override]
            if event.button() == Qt.MouseButton.LeftButton:
                self._dragging = True
                v = self._value_from_position(event.position().x(),
                                               event.position().y())
                self.set_value(v, emit_signal=True)
                event.accept()
            else:
                super().mousePressEvent(event)

        def mouseMoveEvent(self, event):  # type: ignore[override]
            if self._dragging:
                v = self._value_from_position(event.position().x(),
                                               event.position().y())
                self.set_value(v, emit_signal=True)

        def mouseReleaseEvent(self, event):  # type: ignore[override]
            if event.button() == Qt.MouseButton.LeftButton and self._dragging:
                self._dragging = False
                event.accept()
            else:
                super().mouseReleaseEvent(event)

        def mouseDoubleClickEvent(self, event):  # type: ignore[override]
            if event.button() == Qt.MouseButton.LeftButton:
                self.reset_to_default()
                event.accept()
            else:
                super().mouseDoubleClickEvent(event)

        def wheelEvent(self, event):  # type: ignore[override]
            steps = event.angleDelta().y() / 120.0
            if steps == 0:
                event.ignore()
                return
            range_ = self._maximum - self._minimum
            divisor = self.WHEEL_STEPS_PER_RANGE
            if event.modifiers() & Qt.KeyboardModifier.ShiftModifier:
                divisor *= self.DRAG_FINE_TUNE_DIVISOR
            step = range_ / divisor
            self.set_value(self._value + steps * step, emit_signal=True)
            event.accept()

        def paintEvent(self, event):  # type: ignore[override]
            painter = QPainter(self)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)

            w = self.width()
            h = self.height()
            margin = 4
            range_ = self._maximum - self._minimum
            t = (self._value - self._minimum) / range_ if range_ > 0 else 0

            # Track-Hintergrund
            painter.setBrush(QBrush(QColor(self.COL_BG)))
            painter.setPen(QPen(QColor(self.COL_BORDER), 1.0))
            painter.drawRoundedRect(QRectF(0, 0, w, h), 3.0, 3.0)

            if self._orient == "vertical":
                track_h = h - 2 * margin
                fill_h = t * track_h
                # Fill von unten nach oben
                fill_rect = QRectF(margin, h - margin - fill_h,
                                    w - 2 * margin, fill_h)
                painter.setBrush(QBrush(QColor(self.COL_FILL)))
                painter.setPen(Qt.PenStyle.NoPen)
                painter.drawRoundedRect(fill_rect, 1.5, 1.5)
                # Handle-Strich
                handle_y = h - margin - fill_h
                painter.setPen(QPen(QColor(self.COL_HANDLE), 2.0))
                painter.drawLine(int(margin), int(handle_y),
                                  int(w - margin), int(handle_y))
            else:
                track_w = w - 2 * margin
                fill_w = t * track_w
                fill_rect = QRectF(margin, margin, fill_w, h - 2 * margin)
                painter.setBrush(QBrush(QColor(self.COL_FILL)))
                painter.setPen(Qt.PenStyle.NoPen)
                painter.drawRoundedRect(fill_rect, 1.5, 1.5)
                handle_x = margin + fill_w
                painter.setPen(QPen(QColor(self.COL_HANDLE), 2.0))
                painter.drawLine(int(handle_x), int(margin),
                                  int(handle_x), int(h - margin))

            painter.end()

        def _tooltip(self) -> str:
            return (
                f"<b>Slider</b>: {self._value:g}<br>"
                f"<span style='color:#8b949e;'>Range: {self._minimum:g} … "
                f"{self._maximum:g}<br>"
                "Drag · Wheel · 2× Klick = Reset</span>"
            )

else:
    SliderWidget = None  # type: ignore[assignment,misc]


__all__ = ["SliderWidget"]
