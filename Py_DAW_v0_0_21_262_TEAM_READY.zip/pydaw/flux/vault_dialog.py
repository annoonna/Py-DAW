"""
pydaw.flux.vault_dialog — V-1 Save/Load-Dialoge für FLUX-Patches
================================================================

**Eingebaut in v0.0.21.197**. Spezifikation:
``PROJECT_DOCS/FLUX_GROVE_MANIFEST.md`` Sektion „FLUX Vault — Preset-System".

Zwei kompakte modale Dialoge:

* ``VaultSaveDialog`` — speichert den aktuellen Patch mit Metadaten
  (Name, Beschreibung, Tags, Style)
* ``VaultLoadDialog`` — Patch-Browser mit Filter (Factory/User), Style-
  Picker, Suche, Vorschau-Liste

Beide nutzen den ``FluxVaultDB``-Singleton aus
``pydaw.services.flux_vault_db``. Die Patch-Konvertierung von/zu
``Patch.to_dict()`` macht das Main-Widget — diese Dialoge geben nur
das Resultat als ``patch_id`` (load) bzw. das Metadaten-Dict (save)
zurück.

Stil
----

Konsistent mit dem FLUX-Toolbar-Stil (cyan auf dunkel, monospace).
Größe ist bewusst kompakt — 480x420px für den Save-Dialog, 640x480px
für den Load-Browser.

Nichts-Kaputt-Garantie
----------------------

* Reine Qt — keine Audio-/IPC-/Rust-Aufrufe
* Defensiv gegen fehlendes PyQt6: dann sind die Klassen einfach ``None``
* Defensiv gegen fehlende DB: bei Lade-Fehlern wird Status-Label
  geupdatet aber kein Crash
"""

from __future__ import annotations

import logging
from typing import Optional

logger = logging.getLogger(__name__)


try:
    from PyQt6.QtCore import Qt, pyqtSignal
    from PyQt6.QtGui import QColor, QFont
    from PyQt6.QtWidgets import (
        QDialog, QVBoxLayout, QHBoxLayout, QFormLayout,
        QLineEdit, QTextEdit, QComboBox, QPushButton, QLabel,
        QListWidget, QListWidgetItem, QCheckBox, QMessageBox,
        QDialogButtonBox,
    )
    _QT_AVAILABLE = True
except ImportError:
    _QT_AVAILABLE = False


# Style-Liste aus dem Manifest (V-1 hat nur Sacred geseeded, aber der
# Save-Dialog akzeptiert alle 12 Genres als zulässige Style-Tags).
_STYLES = [
    "", "sacred", "bach", "ambient", "synthwave", "techno", "dnb",
    "cinematic", "folk", "jazz", "hiphop", "idm", "soundscape",
    "random",  # v0.0.21.229 — algorithmic random patches (Norns/Ullr)
    "user",
]


# ─── Save-Dialog ──────────────────────────────────────────────────


if _QT_AVAILABLE:

    class VaultSaveDialog(QDialog):  # type: ignore[misc]
        """Modaler Dialog zum Speichern eines Patches im Vault.

        Felder:
        * Name (Pflicht)
        * Beschreibung (optional)
        * Style (Dropdown, optional)
        * Tags (komma-separiert, optional)
        * Author (optional)

        Bei OK wird der Patch via ``FluxVaultDB.save_patch()`` gespeichert.
        Der Caller bekommt die ``patch_id`` über ``saved_patch_id``.

        Wenn ``existing_patch_id`` gegeben ist, wird der Dialog im
        „Update existing"-Modus gezeigt (überschreibt mit history-archive).
        """

        # Cyan-Theme — passt zum FLUX-Look
        STYLESHEET = """
            QDialog { background: #0a0e14; color: #e6edf3; }
            QLabel { color: #8b949e; font-family: monospace; font-size: 11px; }
            QLineEdit, QTextEdit, QComboBox {
                background: #161b22; color: #e6edf3;
                border: 1px solid #30363d; border-radius: 3px;
                padding: 4px 6px;
                font-family: monospace; font-size: 11px;
            }
            QLineEdit:focus, QTextEdit:focus, QComboBox:focus {
                border: 1px solid #3df0e0;
            }
            QPushButton {
                background: #161b22; color: #3df0e0;
                border: 1px solid #3df0e0; border-radius: 3px;
                padding: 4px 12px; font-family: monospace;
                font-size: 11px; font-weight: bold;
            }
            QPushButton:hover { background: #3df0e0; color: #0a0e14; }
            QPushButton:disabled { color: #4a4a4a; border-color: #2a2a2a; }
        """

        def __init__(
            self,
            parent=None,
            *,
            initial_name: str = "",
            initial_description: str = "",
            initial_style: str = "user",
            initial_tags: Optional[list[str]] = None,
            initial_author: str = "",
            existing_patch_id: Optional[str] = None,
        ):
            super().__init__(parent)
            self.setWindowTitle(
                "FLUX Vault — Patch updaten" if existing_patch_id
                else "FLUX Vault — Patch speichern"
            )
            self.setStyleSheet(self.STYLESHEET)
            self.setMinimumSize(480, 380)
            self.saved_patch_id: Optional[str] = None
            self._existing_patch_id = existing_patch_id

            root = QVBoxLayout(self)
            root.setContentsMargins(16, 16, 16, 12)
            root.setSpacing(10)

            # Header
            header = QLabel("🗄  PATCH IM VAULT SPEICHERN")
            header.setStyleSheet(
                "color: #3df0e0; font-family: monospace; font-weight: bold; "
                "font-size: 13px;"
            )
            root.addWidget(header)

            if existing_patch_id is not None:
                hint = QLabel(
                    "<i>Vorhandener Patch wird überschrieben — der alte "
                    "State wird in der Time-Travel-History archiviert.</i>"
                )
                hint.setStyleSheet("color: #fbbf24; font-size: 10px;")
                hint.setTextFormat(Qt.TextFormat.RichText)
                root.addWidget(hint)

            # Form
            form = QFormLayout()
            form.setSpacing(8)
            form.setLabelAlignment(Qt.AlignmentFlag.AlignRight)

            self._name_edit = QLineEdit(initial_name)
            self._name_edit.setPlaceholderText("z.B. „Mein erster Sacred-Pad")
            form.addRow(QLabel("Name *"), self._name_edit)

            self._desc_edit = QTextEdit()
            self._desc_edit.setPlainText(initial_description)
            self._desc_edit.setMaximumHeight(80)
            self._desc_edit.setPlaceholderText("Was macht dieser Patch besonders?")
            form.addRow(QLabel("Beschreibung"), self._desc_edit)

            self._style_combo = QComboBox()
            for s in _STYLES:
                self._style_combo.addItem(s if s else "(kein Style)")
            try:
                idx = _STYLES.index(initial_style)
                self._style_combo.setCurrentIndex(idx)
            except ValueError:
                self._style_combo.setCurrentIndex(0)
            form.addRow(QLabel("Style"), self._style_combo)

            self._tags_edit = QLineEdit(", ".join(initial_tags or []))
            self._tags_edit.setPlaceholderText(
                "warm, pad, choir (komma-separiert)"
            )
            form.addRow(QLabel("Tags"), self._tags_edit)

            self._author_edit = QLineEdit(initial_author)
            self._author_edit.setPlaceholderText("Anno")
            form.addRow(QLabel("Autor"), self._author_edit)

            root.addLayout(form)

            # Status
            self._status = QLabel("")
            self._status.setStyleSheet(
                "color: #ef4444; font-size: 10px; font-family: monospace;"
            )
            root.addWidget(self._status)

            root.addStretch(1)

            # Button-Bar
            buttons = QHBoxLayout()
            buttons.addStretch(1)
            self._cancel_btn = QPushButton("Abbrechen")
            self._cancel_btn.clicked.connect(self.reject)
            buttons.addWidget(self._cancel_btn)
            self._save_btn = QPushButton(
                "Updaten" if existing_patch_id else "Speichern"
            )
            self._save_btn.setDefault(True)
            self._save_btn.clicked.connect(self._on_save)
            buttons.addWidget(self._save_btn)
            root.addLayout(buttons)

        def _on_save(self) -> None:
            """Wird aufgerufen wenn der User „Speichern" klickt.

            Validiert Name + delegiert an Caller via ``saved_patch_id``;
            **das tatsächliche save_patch** macht der Caller mit dem
            Patch-Dict, weil dieser Dialog das Patch-Modell nicht kennt.

            Ergebnis: ``self.metadata`` ist gesetzt nach ``accept()``.
            """
            name = self._name_edit.text().strip()
            if not name:
                self._status.setText("⚠ Name ist Pflicht.")
                self._name_edit.setFocus()
                return

            description = self._desc_edit.toPlainText().strip()
            style = self._style_combo.currentText().strip()
            if style.startswith("("):
                style = ""
            tags_raw = self._tags_edit.text().strip()
            tags = [t.strip() for t in tags_raw.split(",") if t.strip()]
            author = self._author_edit.text().strip()

            self.metadata = {
                "name": name,
                "description": description,
                "style": style,
                "tags": tags,
                "author": author,
                "patch_id": self._existing_patch_id,
            }
            self.accept()


# ─── Load-Dialog ──────────────────────────────────────────────────


    class VaultLoadDialog(QDialog):  # type: ignore[misc]
        """Modaler Patch-Browser für den FLUX-Vault.

        Zeigt eine Liste aller verfügbaren Patches (Factory + User),
        gefiltert nach Style + Suchbegriff. Bei Auswahl + OK liefert
        der Dialog die ``patch_id`` über ``selected_patch_id``.

        Default-Sortierung: Factory zuerst (Sacred-Presets oben),
        dann User-Patches alphabetisch.
        """

        STYLESHEET = """
            QDialog { background: #0a0e14; color: #e6edf3; }
            QLabel { color: #8b949e; font-family: monospace; font-size: 11px; }
            QLineEdit, QComboBox {
                background: #161b22; color: #e6edf3;
                border: 1px solid #30363d; border-radius: 3px;
                padding: 4px 6px;
                font-family: monospace; font-size: 11px;
            }
            QLineEdit:focus, QComboBox:focus {
                border: 1px solid #3df0e0;
            }
            QListWidget {
                background: #0a0e14; color: #e6edf3;
                border: 1px solid #161b22; border-radius: 3px;
                font-family: monospace; font-size: 11px;
                outline: none;
            }
            QListWidget::item {
                padding: 6px 8px;
                border-bottom: 1px solid #161b22;
            }
            QListWidget::item:selected {
                background: #1f2937; color: #3df0e0;
            }
            QListWidget::item:hover {
                background: #161b22;
            }
            QPushButton {
                background: #161b22; color: #3df0e0;
                border: 1px solid #3df0e0; border-radius: 3px;
                padding: 4px 12px; font-family: monospace;
                font-size: 11px; font-weight: bold;
            }
            QPushButton:hover { background: #3df0e0; color: #0a0e14; }
            QPushButton:disabled { color: #4a4a4a; border-color: #2a2a2a; }
            QCheckBox { color: #8b949e; font-size: 11px; }
            QCheckBox::indicator { width: 12px; height: 12px; }
        """

        def __init__(self, parent=None):
            super().__init__(parent)
            self.setWindowTitle("FLUX Vault — Patch laden")
            self.setStyleSheet(self.STYLESHEET)
            self.setMinimumSize(640, 480)
            self.selected_patch_id: Optional[str] = None
            # Map list-row → patch_id für Lookup beim OK
            self._row_to_id: dict[int, str] = {}
            # Beschreibungs-Cache fürs Detail-Panel
            self._row_to_desc: dict[int, str] = {}

            root = QVBoxLayout(self)
            root.setContentsMargins(16, 16, 16, 12)
            root.setSpacing(10)

            # Header
            header = QLabel("🗄  PATCH AUS VAULT LADEN")
            header.setStyleSheet(
                "color: #3df0e0; font-family: monospace; font-weight: bold; "
                "font-size: 13px;"
            )
            root.addWidget(header)

            # Filter-Bar
            filter_row = QHBoxLayout()
            filter_row.setSpacing(8)

            self._search_edit = QLineEdit()
            self._search_edit.setPlaceholderText("🔍  Suche (Name/Tag/...)")
            self._search_edit.textChanged.connect(self._refresh_list)
            filter_row.addWidget(self._search_edit, 2)

            self._style_combo = QComboBox()
            self._style_combo.addItem("(alle Styles)")
            for s in _STYLES:
                if s:
                    self._style_combo.addItem(s)
            self._style_combo.currentIndexChanged.connect(self._refresh_list)
            filter_row.addWidget(self._style_combo, 1)

            self._show_factory = QCheckBox("Factory")
            self._show_factory.setChecked(True)
            self._show_factory.stateChanged.connect(self._refresh_list)
            filter_row.addWidget(self._show_factory)

            self._show_user = QCheckBox("User")
            self._show_user.setChecked(True)
            self._show_user.stateChanged.connect(self._refresh_list)
            filter_row.addWidget(self._show_user)

            root.addLayout(filter_row)

            # Splitter: links Liste, rechts Detail
            split_row = QHBoxLayout()
            split_row.setSpacing(8)

            self._list = QListWidget()
            self._list.itemSelectionChanged.connect(self._update_detail)
            self._list.itemDoubleClicked.connect(lambda *_: self._on_load())
            split_row.addWidget(self._list, 2)

            self._detail = QLabel(
                "<i>Wähle einen Patch um die Details zu sehen.</i>"
            )
            self._detail.setTextFormat(Qt.TextFormat.RichText)
            self._detail.setWordWrap(True)
            self._detail.setAlignment(
                Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft
            )
            self._detail.setStyleSheet(
                "background: #161b22; padding: 12px; border-radius: 3px; "
                "color: #e6edf3; font-family: monospace; font-size: 11px;"
            )
            self._detail.setMinimumWidth(220)
            split_row.addWidget(self._detail, 1)

            root.addLayout(split_row, 1)

            # Status
            self._status = QLabel("")
            self._status.setStyleSheet(
                "color: #fbbf24; font-size: 10px; font-family: monospace;"
            )
            root.addWidget(self._status)

            # Button-Bar
            buttons = QHBoxLayout()
            self._delete_btn = QPushButton("Löschen")
            self._delete_btn.setStyleSheet(
                self.STYLESHEET +
                "QPushButton { color: #ef4444; border-color: #ef4444; }"
                "QPushButton:hover { background: #ef4444; color: #0a0e14; }"
            )
            self._delete_btn.clicked.connect(self._on_delete)
            self._delete_btn.setEnabled(False)
            buttons.addWidget(self._delete_btn)

            buttons.addStretch(1)

            self._cancel_btn = QPushButton("Abbrechen")
            self._cancel_btn.clicked.connect(self.reject)
            buttons.addWidget(self._cancel_btn)

            self._load_btn = QPushButton("Laden")
            self._load_btn.setDefault(True)
            self._load_btn.clicked.connect(self._on_load)
            self._load_btn.setEnabled(False)
            buttons.addWidget(self._load_btn)

            root.addLayout(buttons)

            # Liste füllen
            self._refresh_list()

        def _refresh_list(self) -> None:
            """Liste aus DB neu aufbauen mit aktuellen Filtern."""
            try:
                from pydaw.services.flux_vault_db import get_flux_vault
                vault = get_flux_vault()
                vault.ensure_loaded()
            except Exception as e:
                self._status.setText(f"⚠ Vault-Init fehlgeschlagen: {e}")
                return

            include_factory = self._show_factory.isChecked()
            include_user = self._show_user.isChecked()
            style_idx = self._style_combo.currentIndex()
            style = None
            if style_idx > 0:
                style = self._style_combo.currentText().strip()
            search = self._search_edit.text().strip() or None

            try:
                patches = vault.list_patches(
                    include_factory=include_factory,
                    include_user=include_user,
                    style=style,
                    search=search,
                )
            except Exception as e:
                self._status.setText(f"⚠ Liste fehlgeschlagen: {e}")
                return

            self._list.clear()
            self._row_to_id.clear()
            self._row_to_desc.clear()

            if not patches:
                self._status.setText("ℹ Keine Patches mit diesen Filtern.")
                return

            self._status.setText(f"📋 {len(patches)} Patches")

            for i, p in enumerate(patches):
                badge = "🏛" if p["is_factory"] else "👤"
                style_str = (
                    f"  ({p['style']})" if p.get("style") else ""
                )
                txt = f"  {badge}  {p['name']}{style_str}"
                item = QListWidgetItem(txt)
                # Factory-Einträge farblich hervorheben
                if p["is_factory"]:
                    item.setForeground(QColor("#3df0e0"))
                else:
                    item.setForeground(QColor("#e6edf3"))
                self._list.addItem(item)
                self._row_to_id[i] = p["id"]

                # Detail-Cache
                tags_str = ", ".join(p.get("tags") or [])
                key_str = p.get("musical_key") or "—"
                bpm_str = (
                    f"{p['bpm']:g}" if p.get("bpm") is not None else "—"
                )
                created = p.get("created_at", "—")
                desc = (
                    f"<b style='color:#3df0e0;'>{p['name']}</b><br>"
                    f"<span style='color:#8b949e;'>"
                    f"{p.get('description','') or '<i>keine Beschreibung</i>'}"
                    f"</span><br><br>"
                    f"<b>Style:</b> {p.get('style','—') or '—'}<br>"
                    f"<b>Tags:</b> {tags_str or '—'}<br>"
                    f"<b>Key:</b> {key_str}<br>"
                    f"<b>BPM:</b> {bpm_str}<br>"
                    f"<b>Author:</b> {p.get('author','—') or '—'}<br>"
                    f"<b>Erstellt:</b> {created}<br>"
                    f"<b>Typ:</b> {'Factory' if p['is_factory'] else 'User'}"
                )
                self._row_to_desc[i] = desc

        def _update_detail(self) -> None:
            """Detail-Panel auf Selektion aktualisieren."""
            row = self._list.currentRow()
            if row < 0 or row not in self._row_to_id:
                self._detail.setText(
                    "<i>Wähle einen Patch um die Details zu sehen.</i>"
                )
                self._load_btn.setEnabled(False)
                self._delete_btn.setEnabled(False)
                return
            self._detail.setText(self._row_to_desc.get(row, ""))
            self._load_btn.setEnabled(True)
            # Delete nur für User-Patches — wir sehen es am Cache-String
            is_user = "User" in self._row_to_desc.get(row, "")
            self._delete_btn.setEnabled(is_user)

        def _on_load(self) -> None:
            row = self._list.currentRow()
            if row < 0 or row not in self._row_to_id:
                return
            self.selected_patch_id = self._row_to_id[row]
            self.accept()

        def _on_delete(self) -> None:
            """Löscht den ausgewählten User-Patch (Factory ist geschützt)."""
            row = self._list.currentRow()
            if row < 0 or row not in self._row_to_id:
                return
            pid = self._row_to_id[row]
            confirm = QMessageBox.question(
                self,
                "Patch löschen",
                f"Patch {pid} unwiderruflich aus dem Vault entfernen?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if confirm != QMessageBox.StandardButton.Yes:
                return
            try:
                from pydaw.services.flux_vault_db import get_flux_vault
                vault = get_flux_vault()
                ok = vault.delete_patch(pid)
            except Exception as e:
                self._status.setText(f"⚠ Löschen fehlgeschlagen: {e}")
                return
            if not ok:
                self._status.setText(
                    "⚠ Patch konnte nicht gelöscht werden "
                    "(Factory-geschützt?)"
                )
                return
            self._status.setText("🗑 Patch gelöscht.")
            self._refresh_list()
            self._update_detail()

else:
    VaultSaveDialog = None  # type: ignore[assignment,misc]
    VaultLoadDialog = None  # type: ignore[assignment,misc]


__all__ = ["VaultSaveDialog", "VaultLoadDialog"]
