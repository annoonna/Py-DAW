"""Session Share Service (P5B) — Generate shareable project links.

Creates self-contained project packages that can be shared via link,
viewed in a browser, and optionally collaborated on.

Features:
- Generate shareable .pydaw-share package (ZIP with metadata)
- Browser-viewable HTML export (static project overview)
- QR code generation for quick sharing
- Comment/review system for shared sessions
- Optional password protection

v0.0.20.817 — Phase P5B
"""

from __future__ import annotations

import base64
import hashlib
import json
import logging
import os
import time
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Dict, Any

from PyQt6.QtCore import QObject, pyqtSignal

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class ShareLink:
    """A shareable link to a project session."""
    share_id: str = ""          # unique share identifier
    project_name: str = ""
    author: str = ""
    created_at: float = 0.0     # unix timestamp
    expires_at: float = 0.0     # 0 = never
    file_path: str = ""         # path to .pydaw-share package
    password_hash: str = ""     # SHA-256 hash (empty = no password)
    description: str = ""
    track_count: int = 0
    bpm: float = 120.0
    duration_beats: float = 0.0
    comments: List[Dict[str, str]] = field(default_factory=list)
    is_public: bool = True

    def to_dict(self) -> dict:
        return {
            "share_id": self.share_id,
            "project_name": self.project_name,
            "author": self.author,
            "created_at": self.created_at,
            "expires_at": self.expires_at,
            "description": self.description,
            "track_count": self.track_count,
            "bpm": self.bpm,
            "duration_beats": self.duration_beats,
            "comments": self.comments,
            "is_public": self.is_public,
        }

    @property
    def is_expired(self) -> bool:
        if self.expires_at <= 0:
            return False
        return time.time() > self.expires_at

    @property
    def has_password(self) -> bool:
        return bool(self.password_hash)


@dataclass
class ShareComment:
    """A comment on a shared session."""
    author: str = ""
    text: str = ""
    timestamp: float = 0.0
    beat_position: float = -1.0   # -1 = general, >=0 = at specific beat
    track_name: str = ""          # empty = general comment

    def to_dict(self) -> dict:
        return {
            "author": self.author,
            "text": self.text,
            "timestamp": self.timestamp,
            "beat_position": self.beat_position,
            "track_name": self.track_name,
        }


# ---------------------------------------------------------------------------
# Session Share Service
# ---------------------------------------------------------------------------

class SessionShareService(QObject):
    """Creates and manages shareable project sessions."""

    share_created = pyqtSignal(str, str)   # share_id, file_path
    share_loaded = pyqtSignal(object)       # ShareLink
    error = pyqtSignal(str)
    status = pyqtSignal(str)

    def __init__(
        self,
        project_service=None,
        share_dir: str = "",
        parent=None,
    ):
        super().__init__(parent)
        self._project = project_service
        self._share_dir = share_dir or str(Path.home() / ".pydaw" / "shares")
        self._active_shares: Dict[str, ShareLink] = {}

    def create_share(
        self,
        description: str = "",
        password: str = "",
        expires_hours: float = 0,
        include_media: bool = True,
    ) -> Optional[ShareLink]:
        """Create a shareable project package.

        Args:
            description: Share description
            password: Optional password (empty = no password)
            expires_hours: Expiration in hours (0 = never)
            include_media: Include audio files in package

        Returns:
            ShareLink on success, None on failure.
        """
        ps = self._project
        if ps is None:
            try:
                self.error.emit("Kein Projekt geladen")
            except Exception:
                pass
            return None

        proj = getattr(getattr(ps, 'ctx', None), 'project', None)
        if proj is None:
            proj = getattr(ps, 'project', None)
        if proj is None:
            try:
                self.error.emit("Kein Projekt geladen")
            except Exception:
                pass
            return None

        try:
            # Generate share ID
            share_id = hashlib.sha256(
                f"{time.time()}{os.getpid()}{id(proj)}".encode()
            ).hexdigest()[:12]

            # Collect project info
            project_name = getattr(proj, 'name', 'Untitled')
            tracks = getattr(proj, 'tracks', [])
            bpm = float(getattr(getattr(proj, 'transport', None), 'bpm', 120))

            # Create share link
            link = ShareLink(
                share_id=share_id,
                project_name=project_name,
                author=os.environ.get("USER", "Anonymous"),
                created_at=time.time(),
                expires_at=time.time() + expires_hours * 3600 if expires_hours > 0 else 0,
                description=description,
                track_count=len(tracks),
                bpm=bpm,
                is_public=not bool(password),
            )

            if password:
                link.password_hash = hashlib.sha256(password.encode()).hexdigest()

            # Create share directory
            Path(self._share_dir).mkdir(parents=True, exist_ok=True)
            share_path = os.path.join(self._share_dir, f"{share_id}.pydaw-share")

            # Build share package (ZIP)
            with zipfile.ZipFile(share_path, 'w', zipfile.ZIP_DEFLATED) as zf:
                # Metadata
                zf.writestr("share.json", json.dumps(link.to_dict(), indent=2))

                # Project overview HTML
                html = self._generate_overview_html(proj, link)
                zf.writestr("index.html", html)

                # Track listing
                track_info = []
                for t in tracks:
                    track_info.append({
                        "name": getattr(t, 'name', '?'),
                        "kind": getattr(t, 'kind', '?'),
                        "volume": round(getattr(t, 'volume', 0.8), 2),
                        "muted": getattr(t, 'muted', False),
                        "plugin": getattr(t, 'plugin_type', ''),
                    })
                zf.writestr("tracks.json", json.dumps(track_info, indent=2))

                # Project JSON (without media blobs for size)
                try:
                    proj_data = proj.to_dict() if hasattr(proj, 'to_dict') else {}
                    # Remove large binary data
                    if isinstance(proj_data, dict):
                        for key in list(proj_data.keys()):
                            if 'blob' in key.lower() or 'base64' in key.lower():
                                proj_data[key] = "<removed for share>"
                    zf.writestr("project.json", json.dumps(proj_data, indent=2,
                                                            default=str))
                except Exception:
                    zf.writestr("project.json", "{}")

            link.file_path = share_path
            self._active_shares[share_id] = link

            try:
                self.share_created.emit(share_id, share_path)
                self.status.emit(
                    f"📤 Session geteilt: {project_name} → {share_id}"
                )
            except Exception:
                pass

            log.info("Share created: %s → %s", share_id, share_path)
            return link

        except Exception as exc:
            log.error("Share creation failed: %s", exc)
            try:
                self.error.emit(f"Teilen fehlgeschlagen: {exc}")
            except Exception:
                pass
            return None

    def load_share(self, share_path: str) -> Optional[ShareLink]:
        """Load a .pydaw-share package."""
        try:
            with zipfile.ZipFile(share_path, 'r') as zf:
                meta_json = zf.read("share.json").decode("utf-8")
                meta = json.loads(meta_json)

                link = ShareLink(
                    share_id=meta.get("share_id", ""),
                    project_name=meta.get("project_name", ""),
                    author=meta.get("author", ""),
                    created_at=meta.get("created_at", 0),
                    expires_at=meta.get("expires_at", 0),
                    description=meta.get("description", ""),
                    track_count=meta.get("track_count", 0),
                    bpm=meta.get("bpm", 120),
                    comments=meta.get("comments", []),
                    is_public=meta.get("is_public", True),
                    file_path=share_path,
                )

                try:
                    self.share_loaded.emit(link)
                    self.status.emit(
                        f"📥 Session geladen: {link.project_name} von {link.author}"
                    )
                except Exception:
                    pass

                return link

        except Exception as exc:
            log.error("Share load failed: %s", exc)
            try:
                self.error.emit(f"Share laden fehlgeschlagen: {exc}")
            except Exception:
                pass
            return None

    def add_comment(
        self,
        share_id: str,
        author: str,
        text: str,
        beat_position: float = -1.0,
        track_name: str = "",
    ) -> Optional[ShareComment]:
        """Add a comment to a shared session."""
        link = self._active_shares.get(share_id)
        if link is None:
            return None

        comment = ShareComment(
            author=author,
            text=text,
            timestamp=time.time(),
            beat_position=beat_position,
            track_name=track_name,
        )
        link.comments.append(comment.to_dict())
        return comment

    def list_shares(self) -> List[ShareLink]:
        """List all available shares in the share directory."""
        shares = []
        if not os.path.isdir(self._share_dir):
            return shares

        for fname in os.listdir(self._share_dir):
            if fname.endswith(".pydaw-share"):
                fpath = os.path.join(self._share_dir, fname)
                link = self.load_share(fpath)
                if link and not link.is_expired:
                    shares.append(link)

        shares.sort(key=lambda s: s.created_at, reverse=True)
        return shares

    def _generate_overview_html(self, proj, link: ShareLink) -> str:
        """Generate a browser-viewable HTML overview of the project."""
        tracks = getattr(proj, 'tracks', [])

        track_rows = ""
        for t in tracks:
            name = getattr(t, 'name', '?')
            kind = getattr(t, 'kind', '?')
            vol = getattr(t, 'volume', 0.8)
            import math
            vol_db = 20 * math.log10(max(1e-10, vol))
            muted = "🔇" if getattr(t, 'muted', False) else ""
            plugin = getattr(t, 'plugin_type', '') or ''
            track_rows += (
                f"<tr><td>{name}</td><td>{kind}</td><td>{plugin}</td>"
                f"<td>{vol_db:+.1f} dB {muted}</td></tr>\n"
            )

        return f"""<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{link.project_name} — Py_DAW Session Share</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, sans-serif;
               background: #1e1e1e; color: #eee; margin: 0; padding: 20px; }}
        .container {{ max-width: 800px; margin: 0 auto; }}
        h1 {{ color: #4fc3f7; }}
        .meta {{ color: #999; font-size: 14px; margin-bottom: 20px; }}
        table {{ width: 100%; border-collapse: collapse; margin: 20px 0; }}
        th {{ background: #333; padding: 8px; text-align: left; color: #81c784; }}
        td {{ padding: 8px; border-bottom: 1px solid #333; }}
        tr:hover {{ background: #2a2a2a; }}
        .badge {{ display: inline-block; background: #37474f; padding: 4px 12px;
                  border-radius: 4px; margin: 2px; font-size: 12px; }}
        .footer {{ color: #666; font-size: 12px; margin-top: 40px;
                   border-top: 1px solid #333; padding-top: 10px; }}
    </style>
</head>
<body>
<div class="container">
    <h1>🎵 {link.project_name}</h1>
    <div class="meta">
        von <strong>{link.author}</strong> •
        <span class="badge">{link.bpm:.0f} BPM</span>
        <span class="badge">{link.track_count} Tracks</span>
    </div>
    {f'<p>{link.description}</p>' if link.description else ''}
    <h2>Tracks</h2>
    <table>
        <tr><th>Name</th><th>Typ</th><th>Plugin</th><th>Pegel</th></tr>
        {track_rows}
    </table>
    <div class="footer">
        Erstellt mit <strong>Py_DAW (ChronoScaleStudio)</strong> — Open Source DAW<br>
        Share-ID: {link.share_id}
    </div>
</div>
</body>
</html>"""

    def shutdown(self) -> None:
        self._active_shares.clear()
