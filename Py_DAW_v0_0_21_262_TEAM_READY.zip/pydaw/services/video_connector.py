"""video_connector.py — Zentraler Video-Integration Hub (v0.0.20.923).

VP1: Verbindet Arranger ↔ Video-Panel ↔ Video-KI Panel.

Jedes Modul registriert sich beim Connector und bekommt Cross-Module Events.
Kein Modul muss ein anderes direkt kennen — der Connector leitet alles weiter.

Usage:
    connector = VideoConnector.instance()
    connector.register_arranger(arranger_canvas)
    connector.register_video_panel(video_panel)
    connector.register_video_ki_panel(video_ki_panel)

    # Now clicking a scene in Video-KI will:
    # 1. Jump playhead to scene start
    # 2. Show frame in Video-Panel
    # 3. Highlight region in Arranger
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from PyQt6.QtCore import QObject, pyqtSignal

log = logging.getLogger(__name__)


class VideoConnector(QObject):
    """Zentraler Event-Hub für Video-Integration (VP1).

    Singleton — alle Module registrieren sich hier.
    Signals sind das einzige Kommunikationsmittel.
    """

    # ── Signals ──────────────────────────────────────────────

    # Video geladen (path, info_dict)
    video_loaded = pyqtSignal(str, dict)

    # Playhead bewegt (beat, seconds)
    playhead_sync = pyqtSignal(float, float)

    # Szene ausgewählt in Video-KI (scene_index, start_seconds, end_seconds)
    scene_selected = pyqtSignal(int, float, float)

    # KI-Analyse fertig (video_path, n_scenes, n_dialogs)
    analysis_completed = pyqtSignal(str, int, int)

    # Clip im Arranger ausgewählt (clip_id)
    clip_focused = pyqtSignal(str)

    # Video-Frame aktualisiert (seconds)
    frame_at = pyqtSignal(float)

    # Scene-Marker für Arranger (list of {beat, color, label})
    scene_markers_updated = pyqtSignal(list)

    # ── Singleton ────────────────────────────────────────────

    _instance: Optional[VideoConnector] = None

    @classmethod
    def instance(cls, parent=None) -> VideoConnector:
        if cls._instance is None:
            cls._instance = cls(parent)
        return cls._instance

    def __init__(self, parent=None):
        super().__init__(parent)
        self._arranger = None
        self._video_panel = None
        self._video_ki_panel = None
        self._transport = None
        self._project_service = None
        self._video_path = ""
        self._bpm = 120.0

    # ── Registration ─────────────────────────────────────────

    def register_arranger(self, arranger) -> None:
        """Register the ArrangerCanvas for cross-module sync."""
        self._arranger = arranger
        # VP3: Connect scene markers signal to arranger
        if hasattr(arranger, 'set_scene_markers'):
            try:
                self.scene_markers_updated.connect(arranger.set_scene_markers)
            except Exception:
                pass
        log.info("[VideoConnector] Arranger registered")

    def register_video_panel(self, panel) -> None:
        """Register the VideoPanel for preview sync."""
        self._video_panel = panel
        log.info("[VideoConnector] VideoPanel registered")
        # v0.0.20.928: If a video was already loaded before the panel existed,
        # load it now (fixes race condition: drop → on_video_loaded → panel created)
        if self._video_path and hasattr(panel, 'load_video_file'):
            try:
                panel.load_video_file(self._video_path)
                log.info("[VideoConnector] Late-loaded video into panel: %s",
                         self._video_path)
            except Exception:
                pass

    def register_video_ki_panel(self, panel) -> None:
        """Register the VideoKIPanel for analysis sync."""
        self._video_ki_panel = panel
        log.info("[VideoConnector] VideoKIPanel registered")
        # v0.0.20.928: Late-load if video already present
        if self._video_path and hasattr(panel, 'set_video_path'):
            try:
                panel.set_video_path(self._video_path)
            except Exception:
                pass

    def register_transport(self, transport) -> None:
        self._transport = transport

    def register_project_service(self, ps) -> None:
        self._project_service = ps

    def set_bpm(self, bpm: float) -> None:
        self._bpm = max(10.0, float(bpm))

    # ── Cross-Module Actions ─────────────────────────────────

    def on_video_loaded(self, video_path: str, info: dict = None) -> None:
        """Called when any module loads a video."""
        try:
            self._video_path = video_path
            info = info or {}

            # Notify Video-KI Panel
            if self._video_ki_panel and hasattr(self._video_ki_panel, 'set_video_path'):
                try:
                    self._video_ki_panel.set_video_path(video_path)
                except Exception:
                    pass

            # Notify Video-Panel
            if self._video_panel and hasattr(self._video_panel, 'load_video_file'):
                try:
                    self._video_panel.load_video_file(video_path)
                except Exception:
                    pass

            try:
                self.video_loaded.emit(video_path, info)
            except Exception:
                pass

            log.info("[VideoConnector] Video loaded: %s", video_path)
        except Exception as e:
            log.debug("[VideoConnector] on_video_loaded: %s", e)

    def on_scene_click(self, scene_index: int, start_seconds: float,
                        end_seconds: float = 0.0) -> None:
        """Called when user clicks a scene in Video-KI Panel.

        → Playhead jumps to scene start
        → Video-Panel shows frame at scene start
        → Arranger scrolls to position
        """
        try:
            bpm = self._bpm

            # 1. Move transport playhead
            beat = start_seconds * bpm / 60.0
            if self._transport and hasattr(self._transport, 'set_position'):
                try:
                    self._transport.set_position(beat)
                except Exception:
                    pass

            # 2. Video-Panel: show frame
            if self._video_panel and hasattr(self._video_panel, '_show_frame_at'):
                try:
                    self._video_panel._show_frame_at(start_seconds)
                except Exception:
                    pass

            # 3. Arranger: scroll to beat
            if self._arranger and hasattr(self._arranger, 'scroll_to_beat'):
                try:
                    self._arranger.scroll_to_beat(beat)
                except Exception:
                    pass

            try:
                self.scene_selected.emit(scene_index, start_seconds, end_seconds)
            except Exception:
                pass
        except Exception as e:
            log.debug("[VideoConnector] on_scene_click: %s", e)

    def on_analysis_done(self, video_path: str, vki_service) -> None:
        """Called when Video-KI analysis completes.

        → Creates scene markers in the Arranger
        → Updates Video-Panel with scene info
        """
        try:
            if not vki_service:
                return

            bpm = self._bpm
            markers = []

            for scene in vki_service.scenes:
                beat = scene.start_seconds * bpm / 60.0
                r, g, b = scene.dominant_color
                mood = vki_service.get_mood(scene.index)
                label = f"Szene {scene.index + 1}"
                if mood:
                    label += f" ({mood.key_suggestion}{mood.mode_suggestion[0].upper()}, {int(mood.tempo_suggestion)})"
                markers.append({
                    "beat": beat,
                    "color": f"#{r:02x}{g:02x}{b:02x}",
                    "label": label,
                    "scene_index": scene.index,
                })

            n_scenes = len(vki_service.scenes)
            n_dialogs = len(vki_service.dialogs)

            try:
                self.scene_markers_updated.emit(markers)
                self.analysis_completed.emit(video_path, n_scenes, n_dialogs)
            except Exception:
                pass

            log.info("[VideoConnector] Analysis markers: %d scenes, %d dialogs",
                     n_scenes, n_dialogs)
        except Exception as e:
            log.debug("[VideoConnector] on_analysis_done: %s", e)

    def on_clip_click(self, clip_id: str, beat: float) -> None:
        """Called when user clicks a video clip in the Arranger.

        → Video-Panel shows frame at clip position
        → Video-KI selects the scene at this position
        """
        try:
            bpm = self._bpm
            seconds = beat * 60.0 / bpm

            # Video-Panel: show frame
            if self._video_panel and hasattr(self._video_panel, '_show_frame_at'):
                try:
                    self._video_panel._show_frame_at(seconds)
                except Exception:
                    pass

            # Video-KI: select scene at position
            if self._video_ki_panel:
                vki = getattr(self._video_ki_panel, '_vki', None)
                if vki and hasattr(vki, 'get_scene_at'):
                    scene = vki.get_scene_at(seconds)
                    if scene is not None:
                        try:
                            lst = getattr(self._video_ki_panel, '_lst_scenes', None)
                            if lst:
                                lst.setCurrentRow(scene.index)
                        except Exception:
                            pass

            try:
                self.clip_focused.emit(clip_id)
            except Exception:
                pass
        except Exception as e:
            log.debug("[VideoConnector] on_clip_click: %s", e)

    def on_scrub(self, seconds: float) -> None:
        """Called when user scrubs in Video-Panel.

        → Move playhead
        → Update Video-KI scene selection
        """
        try:
            bpm = self._bpm
            beat = seconds * bpm / 60.0

            if self._transport and hasattr(self._transport, 'set_position'):
                try:
                    self._transport.set_position(beat)
                except Exception:
                    pass

            try:
                self.frame_at.emit(seconds)
            except Exception:
                pass
        except Exception as e:
            log.debug("[VideoConnector] on_scrub: %s", e)

    # ── Track + MIDI Creation (VP5) ──────────────────────────

    def create_scene_track_with_midi(self, scene, mood, suggestion,
                                      bpm: float = 120.0,
                                      variation: int = -1) -> Optional[str]:
        """VP5: Erstelle einen kompletten Instrument-Track für eine Szene.

        Args:
            variation: -1 = auto-increment (jeder Aufruf → andere Noten),
                       0+ = fester Variations-Wert

        Creates:
        1. New Instrument Track (name = suggestion preset name)
        2. AETERNA instrument with generated preset params
        3. MIDI Clip at scene position with generated notes
        4. Returns track_id or None

        THIS IS WHAT NO OTHER DAW CAN DO:
        Video → KI-Analyse → Stimmung → Sound-Vorschlag → Track + Instrument + MIDI
        """
        if not self._project_service:
            log.warning("[VideoConnector] No project_service — can't create track")
            return None

        try:
            from pydaw.model.project import Track, Clip, new_id
            from pydaw.model.midi import MidiNote
            from pydaw.services.video_ki_service import generate_midi_for_suggestion

            ps = self._project_service
            proj = getattr(ps, 'project', None)
            if proj is None:
                ctx = getattr(ps, 'ctx', None)
                proj = getattr(ctx, 'project', None) if ctx else None
            if not proj:
                return None

            bpm = float(getattr(proj, 'bpm', bpm) or bpm)

            # 1. Create Instrument Track
            track_name = f"🎬 {suggestion.preset_name}"
            trk = Track(
                kind="instrument",
                name=track_name,
                plugin_type="aeterna",
                instrument_state=dict(suggestion.preset_params),
            )
            proj.tracks.append(trk)
            tid = str(trk.id)

            # 2. Create MIDI Clip at scene position
            scene_start_beats = scene.start_seconds * bpm / 60.0
            scene_length_beats = scene.duration * bpm / 60.0
            scene_length_beats = max(4.0, scene_length_beats)

            clip = Clip(
                kind="midi",
                track_id=tid,
                label=f"Szene {scene.index + 1}: {suggestion.preset_name}",
                start_beats=round(scene_start_beats, 3),
                length_beats=round(scene_length_beats, 3),
            )
            proj.clips.append(clip)

            # 3. Generate MIDI notes (with variation for unique results each time)
            # v0.0.20.923: auto-increment variation counter
            if variation < 0:
                variation = getattr(self, '_variation_counter', 0)
                self._variation_counter = getattr(self, '_variation_counter', 0) + 1

            # Re-generate suggestion with variation seed for different preset params
            try:
                from pydaw.services.video_ki_service import suggest_sounds, analyze_mood
                varied_sugs = suggest_sounds(mood, scene, n_suggestions=1, variation=variation)
                if varied_sugs:
                    suggestion = varied_sugs[0]
                    # Update track instrument_state with varied params
                    trk.instrument_state = dict(suggestion.preset_params)
                    trk.name = f"🎬 {suggestion.preset_name} v{variation+1}"
                    clip.label = f"Szene {scene.index + 1}: {suggestion.preset_name} v{variation+1}"
            except Exception:
                pass

            midi_dicts = generate_midi_for_suggestion(suggestion, scene, bpm, variation=variation)
            midi_notes = []
            for nd in midi_dicts:
                # Clamp notes to clip length
                if nd["start_beats"] >= scene_length_beats:
                    continue
                length = min(nd["length_beats"],
                             scene_length_beats - nd["start_beats"])
                if length <= 0:
                    continue
                midi_notes.append(MidiNote(
                    pitch=int(nd["pitch"]),
                    start_beats=float(nd["start_beats"]),
                    length_beats=float(length),
                    velocity=int(nd["velocity"]),
                ))

            proj.midi_notes[clip.id] = midi_notes

            # 4. Emit changes
            try:
                if hasattr(ps, '_emit_changed'):
                    ps._emit_changed()
                elif hasattr(ps, '_emit_updated'):
                    ps._emit_updated()
            except Exception:
                pass

            log.info("[VideoConnector] VP5: Created track '%s' with %d MIDI notes "
                     "at beat %.1f (scene %d, %s %s, %d BPM)",
                     track_name, len(midi_notes), scene_start_beats,
                     scene.index + 1, suggestion.key, suggestion.mode,
                     suggestion.bpm)

            return tid

        except Exception as e:
            log.error("[VideoConnector] create_scene_track_with_midi: %s", e, exc_info=True)
            return None

    def create_all_scene_tracks(self, vki_service, bpm: float = 120.0) -> int:
        """VP5: Erstelle Tracks für ALLE Szenen (Top-Vorschlag pro Szene).

        Returns: Anzahl erstellter Tracks
        """
        if not vki_service:
            return 0

        created = 0
        for scene in vki_service.scenes:
            mood = vki_service.get_mood(scene.index)
            suggestions = vki_service.get_suggestions(scene.index)
            if mood and suggestions:
                tid = self.create_scene_track_with_midi(
                    scene, mood, suggestions[0], bpm)
                if tid:
                    created += 1

        log.info("[VideoConnector] VP5: Created %d scene tracks", created)
        return created

    # ── Scene-Aware Editing (VP8) ────────────────────────────

    def auto_split_at_scenes(self, clip_id: str, vki_service,
                              bpm: float = 120.0) -> int:
        """VP8: Auto-split a video clip at all scene boundaries.

        Takes a single video clip and splits it into N clips, one per scene.
        Each resulting clip is labeled with the scene number and mood.

        Args:
            clip_id: The video clip to split
            vki_service: VideoKIService with detected scenes
            bpm: Project BPM

        Returns: Number of clips created (0 on error)
        """
        if not self._project_service or not vki_service:
            return 0

        try:
            from pydaw.model.project import Clip, new_id

            ps = self._project_service
            proj = getattr(ps, 'project', None)
            if proj is None:
                ctx = getattr(ps, 'ctx', None)
                proj = getattr(ctx, 'project', None) if ctx else None
            if not proj:
                return 0

            # Find the source clip
            src = None
            for c in proj.clips:
                if str(getattr(c, 'id', '')) == str(clip_id):
                    src = c
                    break
            if not src or str(getattr(src, 'kind', '')) != 'video':
                return 0

            bpm = float(getattr(proj, 'bpm', bpm) or bpm)
            clip_start_beats = float(getattr(src, 'start_beats', 0))
            clip_offset_s = float(getattr(src, 'offset_seconds', 0) or 0)
            clip_len_beats = float(getattr(src, 'length_beats', 0))
            clip_end_beats = clip_start_beats + clip_len_beats
            track_id = str(getattr(src, 'track_id', ''))
            source_path = str(getattr(src, 'source_path', '') or '')

            scenes = vki_service.scenes
            if not scenes:
                return 0

            new_clips = []
            for scene in scenes:
                scene_start_beats = scene.start_seconds * bpm / 60.0
                scene_end_beats = scene.end_seconds * bpm / 60.0

                # Clip to the source clip's range
                s = max(clip_start_beats, scene_start_beats)
                e = min(clip_end_beats, scene_end_beats)
                if e - s < 0.01:
                    continue  # Scene doesn't overlap this clip

                # Offset into the video source
                scene_offset_s = clip_offset_s + (s - clip_start_beats) * 60.0 / bpm

                mood = vki_service.get_mood(scene.index)
                label = f"Szene {scene.index + 1}"
                if mood:
                    label += f" ({mood.key_suggestion}{mood.mode_suggestion[0].upper()})"

                nc = Clip(
                    kind="video",
                    track_id=track_id,
                    start_beats=round(s, 3),
                    length_beats=round(e - s, 3),
                    offset_seconds=round(scene_offset_s, 3),
                    label=label,
                    source_path=source_path,
                )
                new_clips.append(nc)

            if not new_clips:
                return 0

            # Remove original clip
            proj.clips = [c for c in proj.clips
                          if str(getattr(c, 'id', '')) != str(clip_id)]

            # Add new scene clips
            proj.clips.extend(new_clips)

            # Emit changes
            try:
                if hasattr(ps, '_emit_changed'):
                    ps._emit_changed()
                elif hasattr(ps, '_emit_updated'):
                    ps._emit_updated()
            except Exception:
                pass

            log.info("[VideoConnector] VP8: Split clip into %d scene clips",
                     len(new_clips))
            return len(new_clips)

        except Exception as e:
            log.error("[VideoConnector] auto_split_at_scenes: %s", e, exc_info=True)
            return 0

    def ripple_delete_scene(self, clip_id: str, bpm: float = 120.0) -> bool:
        """VP8: Delete a scene clip and ripple (slide) subsequent clips left.

        Args:
            clip_id: The clip to delete
            bpm: Project BPM

        Returns: True if successful
        """
        if not self._project_service:
            return False

        try:
            ps = self._project_service
            proj = getattr(ps, 'project', None)
            if proj is None:
                ctx = getattr(ps, 'ctx', None)
                proj = getattr(ctx, 'project', None) if ctx else None
            if not proj:
                return False

            # Find the clip
            target = None
            for c in proj.clips:
                if str(getattr(c, 'id', '')) == str(clip_id):
                    target = c
                    break
            if not target:
                return False

            track_id = str(getattr(target, 'track_id', ''))
            del_start = float(getattr(target, 'start_beats', 0))
            del_len = float(getattr(target, 'length_beats', 0))

            # Remove the clip
            proj.clips = [c for c in proj.clips
                          if str(getattr(c, 'id', '')) != str(clip_id)]

            # Ripple: slide subsequent clips on the same track left
            for c in proj.clips:
                if str(getattr(c, 'track_id', '')) == track_id:
                    cs = float(getattr(c, 'start_beats', 0))
                    if cs > del_start:
                        c.start_beats = max(0, cs - del_len)

            # Emit changes
            try:
                if hasattr(ps, '_emit_changed'):
                    ps._emit_changed()
                elif hasattr(ps, '_emit_updated'):
                    ps._emit_updated()
            except Exception:
                pass

            log.info("[VideoConnector] VP8: Ripple-deleted clip %s (%.1f beats)",
                     clip_id[:8], del_len)
            return True

        except Exception as e:
            log.error("[VideoConnector] ripple_delete_scene: %s", e, exc_info=True)
            return False
