"""final_state_db.py — SQLite-backed state for remaining migration phases.

v0.0.20.894 — Phases 27, 31-33, 39-42 (FINAL).

This module completes the SQLite migration roadmap:

Phase 27: CloudSync — Cloud sync timestamps, conflict log
Phase 31: ArrangerState — Zoom, scroll, track heights per project
Phase 32: PianoRollState — Zoom, scroll, note height per project
Phase 33: NotationState — Notation view config per project
Phase 39: VideoState — Video track config, SMPTE settings
Phase 40: PodcastState — Podcast mode config, silence detection settings
Phase 41: MasteringState — Mastering chain presets, LUFS targets
Phase 42: UndoCommands — Extended undo command metadata

All tables share the app-wide pydaw.db.

Usage:
    from pydaw.services.final_state_db import FinalStateDB
    db = FinalStateDB.get()
    db.ensure_loaded()

    # UI State
    db.save_arranger_state(project_path, pixels_per_beat=80.0, track_height=70)
    state = db.get_arranger_state(project_path)

    # Cloud Sync
    db.log_cloud_sync(project_path, "upload", success=True)

    # Mastering
    db.save_mastering_preset("Spotify Master", chain_json, lufs_target=-14.0)
"""

import json
import sqlite3
import logging
import time
from pathlib import Path
from typing import Dict, List, Optional, Any

log = logging.getLogger(__name__)


_SCHEMA_SQL = """
-- Phase 27: Cloud Sync Log
CREATE TABLE IF NOT EXISTS cloud_sync_log (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    project_path    TEXT NOT NULL,
    action          TEXT NOT NULL DEFAULT 'upload',
    provider        TEXT NOT NULL DEFAULT 'local',
    remote_path     TEXT NOT NULL DEFAULT '',
    files_synced    INTEGER NOT NULL DEFAULT 0,
    bytes_synced    INTEGER NOT NULL DEFAULT 0,
    success         INTEGER NOT NULL DEFAULT 1,
    error_msg       TEXT NOT NULL DEFAULT '',
    synced_at       REAL NOT NULL DEFAULT 0.0
);
CREATE INDEX IF NOT EXISTS idx_csl_proj ON cloud_sync_log(project_path, synced_at DESC);

CREATE TABLE IF NOT EXISTS cloud_conflicts (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    project_path    TEXT NOT NULL,
    file_path       TEXT NOT NULL DEFAULT '',
    conflict_type   TEXT NOT NULL DEFAULT 'modified',
    local_hash      TEXT NOT NULL DEFAULT '',
    remote_hash     TEXT NOT NULL DEFAULT '',
    resolution      TEXT NOT NULL DEFAULT 'pending',
    detected_at     REAL NOT NULL DEFAULT 0.0,
    resolved_at     REAL NOT NULL DEFAULT 0.0
);

-- Phase 31: Arranger UI State
CREATE TABLE IF NOT EXISTS arranger_state (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    project_path    TEXT NOT NULL UNIQUE,
    pixels_per_beat REAL NOT NULL DEFAULT 80.0,
    track_height    INTEGER NOT NULL DEFAULT 70,
    scroll_x        REAL NOT NULL DEFAULT 0.0,
    scroll_y        REAL NOT NULL DEFAULT 0.0,
    zoom_level      REAL NOT NULL DEFAULT 1.0,
    show_automation INTEGER NOT NULL DEFAULT 0,
    show_take_lanes INTEGER NOT NULL DEFAULT 0,
    collapsed_tracks TEXT NOT NULL DEFAULT '[]',
    updated_at      REAL NOT NULL DEFAULT 0.0
);

-- Phase 32: Piano Roll UI State
CREATE TABLE IF NOT EXISTS pianoroll_state (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    project_path    TEXT NOT NULL UNIQUE,
    pixels_per_beat REAL NOT NULL DEFAULT 90.0,
    note_height     INTEGER NOT NULL DEFAULT 12,
    scroll_x        REAL NOT NULL DEFAULT 0.0,
    scroll_y        REAL NOT NULL DEFAULT 720.0,
    snap_division   TEXT NOT NULL DEFAULT '1/16',
    tool_mode       TEXT NOT NULL DEFAULT 'pencil',
    velocity_visible INTEGER NOT NULL DEFAULT 1,
    expression_lane TEXT NOT NULL DEFAULT '',
    ghost_layers_visible INTEGER NOT NULL DEFAULT 1,
    updated_at      REAL NOT NULL DEFAULT 0.0
);

-- Phase 33: Notation Editor UI State
CREATE TABLE IF NOT EXISTS notation_state (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    project_path    TEXT NOT NULL UNIQUE,
    staff_spacing   INTEGER NOT NULL DEFAULT 80,
    zoom_level      REAL NOT NULL DEFAULT 1.0,
    show_lyrics     INTEGER NOT NULL DEFAULT 1,
    show_dynamics   INTEGER NOT NULL DEFAULT 1,
    show_chord_symbols INTEGER NOT NULL DEFAULT 1,
    clef            TEXT NOT NULL DEFAULT 'treble',
    page_width      INTEGER NOT NULL DEFAULT 800,
    enharmonic_pref TEXT NOT NULL DEFAULT 'auto',
    updated_at      REAL NOT NULL DEFAULT 0.0
);

-- Phase 39: Video Track State
CREATE TABLE IF NOT EXISTS video_state (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    project_path    TEXT NOT NULL UNIQUE,
    video_path      TEXT NOT NULL DEFAULT '',
    smpte_framerate REAL NOT NULL DEFAULT 25.0,
    smpte_drop_frame INTEGER NOT NULL DEFAULT 0,
    smpte_offset    TEXT NOT NULL DEFAULT '00:00:00:00',
    video_visible   INTEGER NOT NULL DEFAULT 1,
    video_opacity   REAL NOT NULL DEFAULT 1.0,
    chapters_json   TEXT NOT NULL DEFAULT '[]',
    updated_at      REAL NOT NULL DEFAULT 0.0
);

-- Phase 40: Podcast Mode State
CREATE TABLE IF NOT EXISTS podcast_state (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    project_path    TEXT NOT NULL UNIQUE,
    podcast_mode_active INTEGER NOT NULL DEFAULT 0,
    speech_eq_preset TEXT NOT NULL DEFAULT 'Broadcast',
    silence_threshold_db REAL NOT NULL DEFAULT -40.0,
    silence_min_duration_ms INTEGER NOT NULL DEFAULT 500,
    silence_padding_ms INTEGER NOT NULL DEFAULT 100,
    chapter_markers_json TEXT NOT NULL DEFAULT '[]',
    streaming_format TEXT NOT NULL DEFAULT 'mp3',
    streaming_bitrate INTEGER NOT NULL DEFAULT 128,
    updated_at      REAL NOT NULL DEFAULT 0.0
);

-- Phase 41: Mastering Presets
CREATE TABLE IF NOT EXISTS mastering_presets (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    name            TEXT NOT NULL DEFAULT '',
    lufs_target     REAL NOT NULL DEFAULT -14.0,
    true_peak_limit REAL NOT NULL DEFAULT -1.0,
    platform        TEXT NOT NULL DEFAULT 'spotify',
    chain_json      TEXT NOT NULL DEFAULT '{}',
    is_factory      INTEGER NOT NULL DEFAULT 0,
    description     TEXT NOT NULL DEFAULT '',
    created_at      REAL NOT NULL DEFAULT 0.0
);

-- Phase 42: Undo Command Metadata
CREATE TABLE IF NOT EXISTS undo_command_meta (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    project_path    TEXT NOT NULL,
    command_type    TEXT NOT NULL DEFAULT '',
    description     TEXT NOT NULL DEFAULT '',
    affected_tracks TEXT NOT NULL DEFAULT '[]',
    affected_clips  TEXT NOT NULL DEFAULT '[]',
    param_changes   TEXT NOT NULL DEFAULT '{}',
    can_merge       INTEGER NOT NULL DEFAULT 0,
    executed_at     REAL NOT NULL DEFAULT 0.0,
    undone_at       REAL NOT NULL DEFAULT 0.0
);
CREATE INDEX IF NOT EXISTS idx_ucm_proj ON undo_command_meta(project_path, executed_at DESC);

-- Phase 43: Video-KI Analysis Cache (v0.0.20.923)
CREATE TABLE IF NOT EXISTS video_ki_scenes (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    video_path      TEXT NOT NULL,
    scene_index     INTEGER NOT NULL,
    start_seconds   REAL NOT NULL DEFAULT 0.0,
    end_seconds     REAL NOT NULL DEFAULT 0.0,
    transition_type TEXT NOT NULL DEFAULT 'cut',
    brightness      REAL NOT NULL DEFAULT 0.5,
    contrast        REAL NOT NULL DEFAULT 0.5,
    saturation      REAL NOT NULL DEFAULT 0.5,
    warmth          REAL NOT NULL DEFAULT 0.5,
    dominant_color  TEXT NOT NULL DEFAULT '#808080',
    mood_tags_json  TEXT NOT NULL DEFAULT '[]',
    mood_json       TEXT NOT NULL DEFAULT '{}',
    suggestions_json TEXT NOT NULL DEFAULT '[]',
    updated_at      REAL NOT NULL DEFAULT 0.0
);
CREATE INDEX IF NOT EXISTS idx_vks_path ON video_ki_scenes(video_path);

CREATE TABLE IF NOT EXISTS video_ki_dialogs (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    video_path      TEXT NOT NULL,
    start_seconds   REAL NOT NULL DEFAULT 0.0,
    end_seconds     REAL NOT NULL DEFAULT 0.0,
    confidence      REAL NOT NULL DEFAULT 0.8,
    avg_energy_db   REAL NOT NULL DEFAULT -20.0,
    updated_at      REAL NOT NULL DEFAULT 0.0
);
CREATE INDEX IF NOT EXISTS idx_vkd_path ON video_ki_dialogs(video_path);

CREATE TABLE IF NOT EXISTS video_ki_subtitles (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    video_path      TEXT NOT NULL,
    start_seconds   REAL NOT NULL DEFAULT 0.0,
    end_seconds     REAL NOT NULL DEFAULT 0.0,
    text            TEXT NOT NULL DEFAULT '',
    language        TEXT NOT NULL DEFAULT '',
    updated_at      REAL NOT NULL DEFAULT 0.0
);
CREATE INDEX IF NOT EXISTS idx_vksub_path ON video_ki_subtitles(video_path);

-- v0.0.20.936: Per-clip video properties (opacity, speed, blend, transform)
CREATE TABLE IF NOT EXISTS clip_video_props (
    clip_id         TEXT PRIMARY KEY,
    opacity         REAL NOT NULL DEFAULT 1.0,
    speed           REAL NOT NULL DEFAULT 1.0,
    blend_mode      TEXT NOT NULL DEFAULT 'normal',
    scale           REAL NOT NULL DEFAULT 1.0,
    pos_x           REAL NOT NULL DEFAULT 0.0,
    pos_y           REAL NOT NULL DEFAULT 0.0,
    rotation        REAL NOT NULL DEFAULT 0.0,
    fade_in_beats   REAL NOT NULL DEFAULT 0.0,
    fade_out_beats  REAL NOT NULL DEFAULT 0.0,
    freeze_at       REAL NOT NULL DEFAULT -1.0,
    updated_at      REAL NOT NULL DEFAULT 0.0
);

-- v0.0.20.936: Per-clip filter chains (JSON array of filters)
CREATE TABLE IF NOT EXISTS clip_filter_chain (
    clip_id         TEXT PRIMARY KEY,
    filters_json    TEXT NOT NULL DEFAULT '[]',
    updated_at      REAL NOT NULL DEFAULT 0.0
);
"""


class FinalStateDB:
    """SQLite-backed state for phases 27, 31-33, 39-42.

    Singleton. Completes the SQLite migration roadmap.
    """

    _instance: Optional["FinalStateDB"] = None

    @classmethod
    def get(cls) -> "FinalStateDB":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._db_path = Path.home() / ".config" / "ChronoScaleStudio" / "pydaw.db"
        self._loaded = False

    def ensure_loaded(self) -> None:
        if self._loaded:
            return
        try:
            self._db_path.parent.mkdir(parents=True, exist_ok=True)
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.executescript(_SCHEMA_SQL)
                conn.commit()
            finally:
                conn.close()
            self._loaded = True
            log.info("[FinalStateDB] Tables ready")
        except Exception as e:
            log.warning("[FinalStateDB] Init failed: %s", e)

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self._db_path))
        conn.row_factory = sqlite3.Row
        return conn

    # ══════════════════════════════════════════════════════════════
    # Phase 27: Cloud Sync
    # ══════════════════════════════════════════════════════════════

    def log_cloud_sync(self, project_path: str, action: str = "upload",
                        provider: str = "local", remote_path: str = "",
                        files_synced: int = 0, bytes_synced: int = 0,
                        success: bool = True, error_msg: str = "") -> None:
        """Log a cloud sync operation."""
        try:
            conn = self._conn()
            try:
                conn.execute(
                    """INSERT INTO cloud_sync_log
                       (project_path, action, provider, remote_path,
                        files_synced, bytes_synced, success, error_msg, synced_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (project_path, action, provider, remote_path,
                     files_synced, bytes_synced, 1 if success else 0,
                     error_msg, time.time()),
                )
                conn.commit()
            finally:
                conn.close()
        except Exception as e:
            log.debug("[FinalStateDB] log_cloud_sync failed: %s", e)

    def get_cloud_sync_log(self, project_path: str = "",
                            limit: int = 30) -> List[dict]:
        try:
            conn = self._conn()
            try:
                if project_path:
                    rows = conn.execute(
                        "SELECT * FROM cloud_sync_log WHERE project_path=? "
                        "ORDER BY synced_at DESC LIMIT ?",
                        (project_path, limit),
                    ).fetchall()
                else:
                    rows = conn.execute(
                        "SELECT * FROM cloud_sync_log ORDER BY synced_at DESC LIMIT ?",
                        (limit,),
                    ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    def log_cloud_conflict(self, project_path: str, file_path: str,
                            conflict_type: str = "modified",
                            local_hash: str = "", remote_hash: str = "") -> None:
        try:
            conn = self._conn()
            try:
                conn.execute(
                    """INSERT INTO cloud_conflicts
                       (project_path, file_path, conflict_type,
                        local_hash, remote_hash, detected_at)
                       VALUES (?, ?, ?, ?, ?, ?)""",
                    (project_path, file_path, conflict_type,
                     local_hash, remote_hash, time.time()),
                )
                conn.commit()
            finally:
                conn.close()
        except Exception as e:
            log.debug("[FinalStateDB] log_cloud_conflict failed: %s", e)

    def resolve_cloud_conflict(self, conflict_id: int,
                                resolution: str = "local") -> None:
        try:
            conn = self._conn()
            try:
                conn.execute(
                    "UPDATE cloud_conflicts SET resolution=?, resolved_at=? WHERE id=?",
                    (resolution, time.time(), conflict_id),
                )
                conn.commit()
            finally:
                conn.close()
        except Exception:
            pass

    def get_pending_conflicts(self, project_path: str = "") -> List[dict]:
        try:
            conn = self._conn()
            try:
                if project_path:
                    rows = conn.execute(
                        "SELECT * FROM cloud_conflicts WHERE project_path=? AND resolution='pending'",
                        (project_path,),
                    ).fetchall()
                else:
                    rows = conn.execute(
                        "SELECT * FROM cloud_conflicts WHERE resolution='pending'"
                    ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    # ══════════════════════════════════════════════════════════════
    # Phase 31: Arranger State
    # ══════════════════════════════════════════════════════════════

    def save_arranger_state(self, project_path: str, **kwargs) -> None:
        """Save arranger UI state. Pass any subset of fields."""
        if not project_path:
            return
        fields = {
            "pixels_per_beat": float, "track_height": int,
            "scroll_x": float, "scroll_y": float, "zoom_level": float,
            "show_automation": lambda v: 1 if v else 0,
            "show_take_lanes": lambda v: 1 if v else 0,
            "collapsed_tracks": lambda v: json.dumps(v) if isinstance(v, list) else str(v),
        }
        try:
            conn = self._conn()
            try:
                # Check if exists
                row = conn.execute(
                    "SELECT id FROM arranger_state WHERE project_path=?",
                    (project_path,),
                ).fetchone()
                if row:
                    sets = []
                    vals = []
                    for k, v in kwargs.items():
                        if k in fields:
                            converter = fields[k]
                            sets.append(f"{k}=?")
                            vals.append(converter(v))
                    if sets:
                        sets.append("updated_at=?")
                        vals.extend([time.time(), project_path])
                        conn.execute(
                            f"UPDATE arranger_state SET {', '.join(sets)} WHERE project_path=?",
                            vals,
                        )
                else:
                    conn.execute(
                        """INSERT INTO arranger_state
                           (project_path, pixels_per_beat, track_height,
                            scroll_x, scroll_y, zoom_level, updated_at)
                           VALUES (?, ?, ?, ?, ?, ?, ?)""",
                        (project_path,
                         float(kwargs.get("pixels_per_beat", 80.0)),
                         int(kwargs.get("track_height", 70)),
                         float(kwargs.get("scroll_x", 0.0)),
                         float(kwargs.get("scroll_y", 0.0)),
                         float(kwargs.get("zoom_level", 1.0)),
                         time.time()),
                    )
                conn.commit()
            finally:
                conn.close()
        except Exception as e:
            log.debug("[FinalStateDB] save_arranger_state failed: %s", e)

    def get_arranger_state(self, project_path: str) -> Optional[dict]:
        try:
            conn = self._conn()
            try:
                row = conn.execute(
                    "SELECT * FROM arranger_state WHERE project_path=?",
                    (project_path,),
                ).fetchone()
                return dict(row) if row else None
            finally:
                conn.close()
        except Exception:
            return None

    # ══════════════════════════════════════════════════════════════
    # Phase 32: Piano Roll State
    # ══════════════════════════════════════════════════════════════

    def save_pianoroll_state(self, project_path: str, **kwargs) -> None:
        """Save piano roll UI state."""
        if not project_path:
            return
        try:
            conn = self._conn()
            try:
                row = conn.execute(
                    "SELECT id FROM pianoroll_state WHERE project_path=?",
                    (project_path,),
                ).fetchone()
                if row:
                    sets = []
                    vals = []
                    valid = {"pixels_per_beat", "note_height", "scroll_x", "scroll_y",
                             "snap_division", "tool_mode", "velocity_visible",
                             "expression_lane", "ghost_layers_visible"}
                    for k, v in kwargs.items():
                        if k in valid:
                            sets.append(f"{k}=?")
                            vals.append(v)
                    if sets:
                        sets.append("updated_at=?")
                        vals.extend([time.time(), project_path])
                        conn.execute(
                            f"UPDATE pianoroll_state SET {', '.join(sets)} WHERE project_path=?",
                            vals,
                        )
                else:
                    conn.execute(
                        """INSERT INTO pianoroll_state
                           (project_path, pixels_per_beat, note_height,
                            scroll_x, scroll_y, snap_division, tool_mode, updated_at)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                        (project_path,
                         float(kwargs.get("pixels_per_beat", 90.0)),
                         int(kwargs.get("note_height", 12)),
                         float(kwargs.get("scroll_x", 0.0)),
                         float(kwargs.get("scroll_y", 720.0)),
                         str(kwargs.get("snap_division", "1/16")),
                         str(kwargs.get("tool_mode", "pencil")),
                         time.time()),
                    )
                conn.commit()
            finally:
                conn.close()
        except Exception as e:
            log.debug("[FinalStateDB] save_pianoroll_state failed: %s", e)

    def get_pianoroll_state(self, project_path: str) -> Optional[dict]:
        try:
            conn = self._conn()
            try:
                row = conn.execute(
                    "SELECT * FROM pianoroll_state WHERE project_path=?",
                    (project_path,),
                ).fetchone()
                return dict(row) if row else None
            finally:
                conn.close()
        except Exception:
            return None

    # ══════════════════════════════════════════════════════════════
    # Phase 33: Notation Editor State
    # ══════════════════════════════════════════════════════════════

    def save_notation_state(self, project_path: str, **kwargs) -> None:
        """Save notation editor UI state."""
        if not project_path:
            return
        try:
            conn = self._conn()
            try:
                row = conn.execute(
                    "SELECT id FROM notation_state WHERE project_path=?",
                    (project_path,),
                ).fetchone()
                if row:
                    sets = []
                    vals = []
                    valid = {"staff_spacing", "zoom_level", "show_lyrics",
                             "show_dynamics", "show_chord_symbols", "clef",
                             "page_width", "enharmonic_pref"}
                    for k, v in kwargs.items():
                        if k in valid:
                            sets.append(f"{k}=?")
                            vals.append(v)
                    if sets:
                        sets.append("updated_at=?")
                        vals.extend([time.time(), project_path])
                        conn.execute(
                            f"UPDATE notation_state SET {', '.join(sets)} WHERE project_path=?",
                            vals,
                        )
                else:
                    conn.execute(
                        """INSERT INTO notation_state
                           (project_path, staff_spacing, zoom_level, clef, updated_at)
                           VALUES (?, ?, ?, ?, ?)""",
                        (project_path,
                         int(kwargs.get("staff_spacing", 80)),
                         float(kwargs.get("zoom_level", 1.0)),
                         str(kwargs.get("clef", "treble")),
                         time.time()),
                    )
                conn.commit()
            finally:
                conn.close()
        except Exception as e:
            log.debug("[FinalStateDB] save_notation_state failed: %s", e)

    def get_notation_state(self, project_path: str) -> Optional[dict]:
        try:
            conn = self._conn()
            try:
                row = conn.execute(
                    "SELECT * FROM notation_state WHERE project_path=?",
                    (project_path,),
                ).fetchone()
                return dict(row) if row else None
            finally:
                conn.close()
        except Exception:
            return None

    # ══════════════════════════════════════════════════════════════
    # Phase 39: Video Track State
    # ══════════════════════════════════════════════════════════════

    def save_video_state(self, project_path: str, **kwargs) -> None:
        """Save video track state."""
        if not project_path:
            return
        try:
            conn = self._conn()
            try:
                row = conn.execute(
                    "SELECT id FROM video_state WHERE project_path=?",
                    (project_path,),
                ).fetchone()
                if row:
                    sets = []
                    vals = []
                    valid = {"video_path", "smpte_framerate", "smpte_drop_frame",
                             "smpte_offset", "video_visible", "video_opacity",
                             "chapters_json"}
                    for k, v in kwargs.items():
                        if k in valid:
                            sets.append(f"{k}=?")
                            vals.append(v)
                    if sets:
                        sets.append("updated_at=?")
                        vals.extend([time.time(), project_path])
                        conn.execute(
                            f"UPDATE video_state SET {', '.join(sets)} WHERE project_path=?",
                            vals,
                        )
                else:
                    conn.execute(
                        """INSERT INTO video_state
                           (project_path, video_path, smpte_framerate, updated_at)
                           VALUES (?, ?, ?, ?)""",
                        (project_path,
                         str(kwargs.get("video_path", "")),
                         float(kwargs.get("smpte_framerate", 25.0)),
                         time.time()),
                    )
                conn.commit()
            finally:
                conn.close()
        except Exception as e:
            log.debug("[FinalStateDB] save_video_state failed: %s", e)

    def get_video_state(self, project_path: str) -> Optional[dict]:
        try:
            conn = self._conn()
            try:
                row = conn.execute(
                    "SELECT * FROM video_state WHERE project_path=?",
                    (project_path,),
                ).fetchone()
                return dict(row) if row else None
            finally:
                conn.close()
        except Exception:
            return None

    # ══════════════════════════════════════════════════════════════
    # Phase 40: Podcast Mode State
    # ══════════════════════════════════════════════════════════════

    def save_podcast_state(self, project_path: str, **kwargs) -> None:
        """Save podcast mode state."""
        if not project_path:
            return
        try:
            conn = self._conn()
            try:
                row = conn.execute(
                    "SELECT id FROM podcast_state WHERE project_path=?",
                    (project_path,),
                ).fetchone()
                if row:
                    sets = []
                    vals = []
                    valid = {"podcast_mode_active", "speech_eq_preset",
                             "silence_threshold_db", "silence_min_duration_ms",
                             "silence_padding_ms", "chapter_markers_json",
                             "streaming_format", "streaming_bitrate"}
                    for k, v in kwargs.items():
                        if k in valid:
                            sets.append(f"{k}=?")
                            vals.append(v)
                    if sets:
                        sets.append("updated_at=?")
                        vals.extend([time.time(), project_path])
                        conn.execute(
                            f"UPDATE podcast_state SET {', '.join(sets)} WHERE project_path=?",
                            vals,
                        )
                else:
                    conn.execute(
                        """INSERT INTO podcast_state
                           (project_path, podcast_mode_active, speech_eq_preset, updated_at)
                           VALUES (?, ?, ?, ?)""",
                        (project_path,
                         1 if kwargs.get("podcast_mode_active", False) else 0,
                         str(kwargs.get("speech_eq_preset", "Broadcast")),
                         time.time()),
                    )
                conn.commit()
            finally:
                conn.close()
        except Exception as e:
            log.debug("[FinalStateDB] save_podcast_state failed: %s", e)

    def get_podcast_state(self, project_path: str) -> Optional[dict]:
        try:
            conn = self._conn()
            try:
                row = conn.execute(
                    "SELECT * FROM podcast_state WHERE project_path=?",
                    (project_path,),
                ).fetchone()
                return dict(row) if row else None
            finally:
                conn.close()
        except Exception:
            return None

    # ══════════════════════════════════════════════════════════════
    # Phase 41: Mastering Presets
    # ══════════════════════════════════════════════════════════════

    def save_mastering_preset(self, name: str, chain_json: str = "{}",
                               lufs_target: float = -14.0,
                               true_peak_limit: float = -1.0,
                               platform: str = "spotify",
                               description: str = "",
                               is_factory: bool = False) -> int:
        """Save a mastering preset. Returns ID."""
        try:
            conn = self._conn()
            try:
                cur = conn.execute(
                    """INSERT INTO mastering_presets
                       (name, lufs_target, true_peak_limit, platform,
                        chain_json, is_factory, description, created_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                    (name, lufs_target, true_peak_limit, platform,
                     chain_json, 1 if is_factory else 0, description, time.time()),
                )
                conn.commit()
                return cur.lastrowid or 0
            finally:
                conn.close()
        except Exception as e:
            log.debug("[FinalStateDB] save_mastering_preset failed: %s", e)
            return 0

    def get_mastering_presets(self, platform: str = "",
                               limit: int = 50) -> List[dict]:
        try:
            conn = self._conn()
            try:
                if platform:
                    rows = conn.execute(
                        "SELECT * FROM mastering_presets WHERE platform=? ORDER BY name LIMIT ?",
                        (platform, limit),
                    ).fetchall()
                else:
                    rows = conn.execute(
                        "SELECT * FROM mastering_presets ORDER BY name LIMIT ?",
                        (limit,),
                    ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    def delete_mastering_preset(self, preset_id: int) -> None:
        try:
            conn = self._conn()
            try:
                conn.execute("DELETE FROM mastering_presets WHERE id=? AND is_factory=0",
                             (preset_id,))
                conn.commit()
            finally:
                conn.close()
        except Exception:
            pass

    # ══════════════════════════════════════════════════════════════
    # Phase 42: Undo Command Metadata
    # ══════════════════════════════════════════════════════════════

    def log_undo_command(self, project_path: str, command_type: str,
                          description: str = "",
                          affected_tracks: Optional[List[str]] = None,
                          affected_clips: Optional[List[str]] = None,
                          param_changes: Optional[Dict[str, Any]] = None,
                          can_merge: bool = False) -> None:
        """Log an undo command execution."""
        try:
            conn = self._conn()
            try:
                conn.execute(
                    """INSERT INTO undo_command_meta
                       (project_path, command_type, description,
                        affected_tracks, affected_clips, param_changes,
                        can_merge, executed_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                    (project_path, command_type, description,
                     json.dumps(affected_tracks or []),
                     json.dumps(affected_clips or []),
                     json.dumps(param_changes or {}),
                     1 if can_merge else 0, time.time()),
                )
                conn.commit()
            finally:
                conn.close()
        except Exception as e:
            log.debug("[FinalStateDB] log_undo_command failed: %s", e)

    def get_undo_commands(self, project_path: str,
                           limit: int = 100) -> List[dict]:
        try:
            conn = self._conn()
            try:
                rows = conn.execute(
                    "SELECT * FROM undo_command_meta WHERE project_path=? "
                    "ORDER BY executed_at DESC LIMIT ?",
                    (project_path, limit),
                ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    def mark_command_undone(self, command_id: int) -> None:
        try:
            conn = self._conn()
            try:
                conn.execute(
                    "UPDATE undo_command_meta SET undone_at=? WHERE id=?",
                    (time.time(), command_id),
                )
                conn.commit()
            finally:
                conn.close()
        except Exception:
            pass

    # ══════════════════════════════════════════════════════════════
    # Phase 43: Video-KI Analysis Cache (v0.0.20.923)
    # ══════════════════════════════════════════════════════════════

    def save_video_ki_analysis(self, video_path: str,
                                scenes_json: str, dialogs_json: str,
                                subtitles_json: str = "[]") -> None:
        """Persist Video-KI analysis results (VK1+VK2+VK3+VK4)."""
        if not video_path:
            return
        try:
            import json as _json
            conn = self._conn()
            try:
                # Clear old data for this video
                conn.execute("DELETE FROM video_ki_scenes WHERE video_path=?", (video_path,))
                conn.execute("DELETE FROM video_ki_dialogs WHERE video_path=?", (video_path,))
                conn.execute("DELETE FROM video_ki_subtitles WHERE video_path=?", (video_path,))

                now = time.time()

                # Insert scenes (with mood + suggestions embedded)
                for scene_data in _json.loads(scenes_json):
                    r, g, b = scene_data.get("dominant_r", 128), scene_data.get("dominant_g", 128), scene_data.get("dominant_b", 128)
                    conn.execute(
                        """INSERT INTO video_ki_scenes
                           (video_path, scene_index, start_seconds, end_seconds,
                            transition_type, brightness, contrast, saturation, warmth,
                            dominant_color, mood_tags_json, mood_json, suggestions_json, updated_at)
                           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                        (video_path, int(scene_data.get("index", 0)),
                         float(scene_data.get("start", 0)), float(scene_data.get("end", 0)),
                         str(scene_data.get("transition", "cut")),
                         float(scene_data.get("brightness", 0.5)),
                         float(scene_data.get("contrast", 0.5)),
                         float(scene_data.get("saturation", 0.5)),
                         float(scene_data.get("warmth", 0.5)),
                         f"#{r:02x}{g:02x}{b:02x}",
                         _json.dumps(scene_data.get("mood_tags", [])),
                         _json.dumps(scene_data.get("mood", {})),
                         _json.dumps(scene_data.get("suggestions", [])),
                         now))

                # Insert dialogs
                for dlg in _json.loads(dialogs_json):
                    conn.execute(
                        """INSERT INTO video_ki_dialogs
                           (video_path, start_seconds, end_seconds, confidence, avg_energy_db, updated_at)
                           VALUES (?,?,?,?,?,?)""",
                        (video_path, float(dlg.get("start", 0)), float(dlg.get("end", 0)),
                         float(dlg.get("confidence", 0.8)), float(dlg.get("energy_db", -20)),
                         now))

                # Insert subtitles
                for sub in _json.loads(subtitles_json):
                    conn.execute(
                        """INSERT INTO video_ki_subtitles
                           (video_path, start_seconds, end_seconds, text, language, updated_at)
                           VALUES (?,?,?,?,?,?)""",
                        (video_path, float(sub.get("start", 0)), float(sub.get("end", 0)),
                         str(sub.get("text", "")), str(sub.get("language", "")), now))

                conn.commit()
                log.debug("[FinalStateDB] Saved video-KI analysis for %s", video_path)
            finally:
                conn.close()
        except Exception as e:
            log.debug("[FinalStateDB] save_video_ki_analysis failed: %s", e)

    def get_video_ki_analysis(self, video_path: str) -> Optional[dict]:
        """Load cached Video-KI analysis results."""
        if not video_path:
            return None
        try:
            import json as _json
            conn = self._conn()
            try:
                scenes = []
                for row in conn.execute(
                        "SELECT * FROM video_ki_scenes WHERE video_path=? ORDER BY scene_index",
                        (video_path,)).fetchall():
                    scenes.append({
                        "index": int(row["scene_index"]),
                        "start": float(row["start_seconds"]),
                        "end": float(row["end_seconds"]),
                        "transition": str(row["transition_type"]),
                        "brightness": float(row["brightness"]),
                        "contrast": float(row["contrast"]),
                        "saturation": float(row["saturation"]),
                        "warmth": float(row["warmth"]),
                        "dominant_color": str(row["dominant_color"]),
                        "mood_tags": _json.loads(row["mood_tags_json"]),
                        "mood": _json.loads(row["mood_json"]),
                        "suggestions": _json.loads(row["suggestions_json"]),
                    })

                dialogs = []
                for row in conn.execute(
                        "SELECT * FROM video_ki_dialogs WHERE video_path=? ORDER BY start_seconds",
                        (video_path,)).fetchall():
                    dialogs.append({
                        "start": float(row["start_seconds"]),
                        "end": float(row["end_seconds"]),
                        "confidence": float(row["confidence"]),
                        "energy_db": float(row["avg_energy_db"]),
                    })

                subtitles = []
                for row in conn.execute(
                        "SELECT * FROM video_ki_subtitles WHERE video_path=? ORDER BY start_seconds",
                        (video_path,)).fetchall():
                    subtitles.append({
                        "start": float(row["start_seconds"]),
                        "end": float(row["end_seconds"]),
                        "text": str(row["text"]),
                        "language": str(row["language"]),
                    })

                if not scenes and not dialogs:
                    return None

                return {"scenes": scenes, "dialogs": dialogs, "subtitles": subtitles}
            finally:
                conn.close()
        except Exception as e:
            log.debug("[FinalStateDB] get_video_ki_analysis failed: %s", e)
            return None

    # ══════════════════════════════════════════════════════════════
    # Maintenance / Stats
    # ══════════════════════════════════════════════════════════════

    def stats(self) -> Dict[str, int]:
        result = {}
        tables = ("cloud_sync_log", "cloud_conflicts",
                  "arranger_state", "pianoroll_state", "notation_state",
                  "video_state", "podcast_state",
                  "mastering_presets", "undo_command_meta",
                  "video_ki_scenes", "video_ki_dialogs", "video_ki_subtitles")
        try:
            conn = self._conn()
            try:
                for table in tables:
                    row = conn.execute(f"SELECT COUNT(*) as cnt FROM {table}").fetchone()
                    result[table] = int(row["cnt"]) if row else 0
            finally:
                conn.close()
        except Exception:
            pass
        return result

    def prune_old_entries(self, max_age_days: int = 180) -> Dict[str, int]:
        """Prune old entries from time-based tables."""
        cutoff = time.time() - (max_age_days * 86400)
        result = {}
        try:
            conn = self._conn()
            try:
                for table, col in (("cloud_sync_log", "synced_at"),
                                    ("undo_command_meta", "executed_at")):
                    cur = conn.execute(f"DELETE FROM {table} WHERE {col} < ?", (cutoff,))
                    result[table] = cur.rowcount
                conn.commit()
            finally:
                conn.close()
        except Exception:
            pass
        return result

    # ══════════════════════════════════════════════════════════════
    # v0.0.20.936: Clip Video Properties (SQLite persistence)
    # ══════════════════════════════════════════════════════════════

    def save_clip_video_props(self, clip_id: str, props: dict) -> None:
        """Save per-clip video properties to SQLite."""
        self.ensure_loaded()
        try:
            conn = self._conn()
            try:
                conn.execute(
                    """INSERT OR REPLACE INTO clip_video_props
                       (clip_id, opacity, speed, blend_mode, scale, pos_x, pos_y,
                        rotation, fade_in_beats, fade_out_beats, freeze_at, updated_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (clip_id,
                     float(props.get("opacity", 1.0)),
                     float(props.get("speed", 1.0)),
                     str(props.get("blend_mode", "normal")),
                     float(props.get("scale", 1.0)),
                     float(props.get("pos_x", 0.0)),
                     float(props.get("pos_y", 0.0)),
                     float(props.get("rotation", 0.0)),
                     float(props.get("fade_in_beats", 0.0)),
                     float(props.get("fade_out_beats", 0.0)),
                     float(props.get("freeze_at", -1.0)),
                     time.time()),
                )
                conn.commit()
            finally:
                conn.close()
        except Exception as e:
            log.debug("[FinalStateDB] save_clip_video_props: %s", e)

    def load_clip_video_props(self, clip_id: str) -> Optional[dict]:
        """Load per-clip video properties from SQLite."""
        self.ensure_loaded()
        try:
            conn = self._conn()
            try:
                row = conn.execute(
                    "SELECT * FROM clip_video_props WHERE clip_id = ?",
                    (clip_id,),
                ).fetchone()
                if row:
                    return dict(row)
            finally:
                conn.close()
        except Exception:
            pass
        return None

    def save_clip_filter_chain(self, clip_id: str, filters_json: str) -> None:
        """Save per-clip filter chain to SQLite."""
        self.ensure_loaded()
        try:
            conn = self._conn()
            try:
                conn.execute(
                    """INSERT OR REPLACE INTO clip_filter_chain
                       (clip_id, filters_json, updated_at)
                       VALUES (?, ?, ?)""",
                    (clip_id, filters_json, time.time()),
                )
                conn.commit()
            finally:
                conn.close()
        except Exception as e:
            log.debug("[FinalStateDB] save_clip_filter_chain: %s", e)

    def load_clip_filter_chain(self, clip_id: str) -> Optional[str]:
        """Load per-clip filter chain JSON from SQLite."""
        self.ensure_loaded()
        try:
            conn = self._conn()
            try:
                row = conn.execute(
                    "SELECT filters_json FROM clip_filter_chain WHERE clip_id = ?",
                    (clip_id,),
                ).fetchone()
                if row:
                    return str(row["filters_json"])
            finally:
                conn.close()
        except Exception:
            pass
        return None
