"""
pydaw.flux.ui_widgets.pulse_ring — Frigg.PulseRing (Phase W-1)
==============================================================

**Eingebaut in v0.0.21.197** als Norse-Sigil-Replacement für den
klassischen ``AnimatedKnob`` (v.194). Spezifikation:
``PROJECT_DOCS/FLUX_GROVE_MANIFEST.md`` Sektion „FLUX Sigil — eigene
Widget-Designs", Punkt 1.

Design (aus dem Manifest)
-------------------------

* Hohler Ring im Hintergrund (matt-cyan)
* Innen ein kleiner pulsierender Kern (Wert = Größe des Kerns)
* Beim Drehen sich nach außen ausbreitende Welle (Pulse-Wave-Animation)
* Wert-Display unter dem Ring, mit Shimmer-Animation beim Wechsel
* Bei Verbindung leuchtet der Ring in der Connection-Farbe

Nichts-Kaputt-Garantie
----------------------

* **Identischer Signal-Vertrag** wie ``AnimatedKnob``: ``value_changed(float)``,
  ``set_value(v, emit_signal=...)``, ``_minimum``/``_maximum``/``_default``-
  Felder. Damit funktioniert Auto-Range (v.196), UiModuleBridge (v.195),
  PropertiesPanel-Sync — alles unverändert.
* **Reine Python-Schicht** — keine Rust/IPC-Änderungen.
* **Defensiv gegen fehlendes Qt** — ``PulseRingWidget = None`` als
  Stub.
* **Performance** — Animationen laufen über die zentrale
  ``AnimationEngine`` (CPU-budgetiert, SENTINEL-aware,
  reduced-motion-fähig).
"""

from __future__ import annotations

import logging
import math
from typing import Optional

logger = logging.getLogger(__name__)


try:
    from PyQt6.QtCore import (
        Qt, QPointF, QRectF, QSize, pyqtSignal,
    )
    from PyQt6.QtGui import (
        QColor, QPainter, QPen, QBrush, QFont, QRadialGradient,
    )
    from PyQt6.QtWidgets import QWidget, QSizePolicy
    _QT_AVAILABLE = True
except ImportError:
    _QT_AVAILABLE = False


from pydaw.flux.animation_engine import (
    get_animation_engine, ANIM_PULSE_WAVE, ANIM_SHIMMER,
)


# ─── Hilfs-Funktionen ─────────────────────────────────────────────


def _clamp(x: float, lo: float, hi: float) -> float:
    if lo > hi:
        lo, hi = hi, lo
    return max(lo, min(hi, x))


def _format_value(value: float, unit: str, max_abs: float) -> str:
    """Wert-Formatierung wie im AnimatedKnob — Konsistenz wahren."""
    abs_v = abs(value)
    if max_abs >= 1000:
        if abs_v >= 100:
            text = f"{value:.0f}"
        elif abs_v >= 10:
            text = f"{value:.1f}"
        else:
            text = f"{value:.2f}"
    elif max_abs >= 10:
        text = f"{value:.1f}"
    else:
        text = f"{value:.2f}"
    return f"{text} {unit}".strip()


# ─── Hauptklasse ──────────────────────────────────────────────────


if _QT_AVAILABLE:

    class PulseRingWidget(QWidget):  # type: ignore[misc]
        """Sigil-Knob: hohler Ring mit pulsierendem Kern.

        Der Ring zeigt den Wert als Bogenfüllung an (wie der klassische
        Knob), aber **innen** liegt ein **pulsierender Kern**, dessen
        Größe den aktuellen Wert verkörpert. Beim User-Drag wird zusätzlich
        ein **Pulse-Wave** (sich nach außen ausbreitender Ring) gezeigt.

        Signal-Vertrag (identisch zu AnimatedKnob)
        ------------------------------------------

        ``value_changed(float)`` — feuert sofort beim User-Eingriff.
        ``set_value(v, *, emit_signal=True)``
        ``reset_to_default()``

        Zusätzliche Felder (für Auto-Range-Adapter v.196):
        ``_minimum``, ``_maximum``, ``_default``
        """

        # Drag-Verhalten — gleich wie AnimatedKnob
        DRAG_PIXELS_FOR_FULL_RANGE = 200
        DRAG_FINE_TUNE_DIVISOR     = 10
        WHEEL_STEPS_PER_RANGE      = 100

        # Geometrie
        DEFAULT_SIZE   = 48                # etwas größer als Knob-Default 44
        RING_THICKNESS = 4
        ARC_START_DEG  = -135
        ARC_SPAN_DEG   = 270

        # Norse-Cyan-Palette (Manifest §"Design-Prinzipien": Cyan + Gold)
        COL_RING_BG       = "#1a1f29"      # leerer Ring
        COL_RING_ACTIVE   = "#3df0e0"      # aktiver Bogen (cyan)
        COL_CORE          = "#7df0e0"      # innerer Kern (heller cyan)
        COL_CORE_GLOW     = "#3df0e0"      # Kern-Glow-Halo
        COL_PULSE_WAVE    = "#3df0e0"      # auswandernde Welle (cyan)
        COL_TEXT          = "#e6edf3"
        COL_TEXT_DIM      = "#8b949e"
        COL_SHIMMER       = "#fbbf24"      # Gold-Shimmer beim Wert-Wechsel

        value_changed = pyqtSignal(float)

        def __init__(
            self,
            name: str = "param",
            value: float = 0.0,
            minimum: float = 0.0,
            maximum: float = 1.0,
            default: Optional[float] = None,
            unit: str = "",
            module_id: str = "",
            parent=None,
        ):
            super().__init__(parent)
            self._name = str(name)
            if maximum <= minimum:
                maximum = minimum + 1.0
            self._minimum = float(minimum)
            self._maximum = float(maximum)
            self._default = float(default) if default is not None else float(value)
            self._unit = str(unit)
            self._value = _clamp(float(value), self._minimum, self._maximum)
            self._module_id = str(module_id) or f"pulsering_{id(self):x}"

            # Animation-State (von der zentralen Engine getrieben)
            self._pulse_phase = 0.0       # Pulse-Wave 0..1, nur >0 während Animation
            self._shimmer_phase = 0.0     # Shimmer 0..1, nur während Wert-Wechsel
            self._connection_color: Optional[str] = None   # bei verbundenem Cable

            # Drag-State
            self._dragging = False
            self._drag_origin_y = 0.0
            self._drag_origin_value = 0.0
            self._drag_fine = False

            size = self.DEFAULT_SIZE
            self.setMinimumSize(size + 4, size + 18)
            self.setMaximumSize(size + 8, size + 22)
            self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
            self.setMouseTracking(True)
            self.setToolTip(self._tooltip_text())

            # Bei Construction wird KEINE Idle-Loop subscribed —
            # PulseRing nutzt nur One-Shots beim Wert-Wechsel.

        # ─── Public API ────────────────────────────────────────────

        @property
        def value(self) -> float:
            return self._value

        @property
        def minimum(self) -> float:
            return self._minimum

        @property
        def maximum(self) -> float:
            return self._maximum

        def set_value(self, value: float, *, emit_signal: bool = True) -> None:
            new_v = _clamp(float(value), self._minimum, self._maximum)
            if new_v == self._value:
                return
            self._value = new_v
            if emit_signal:
                self.value_changed.emit(self._value)
            self._trigger_pulse_wave()
            self._trigger_shimmer()
            self.setToolTip(self._tooltip_text())
            self.update()

        def reset_to_default(self) -> None:
            self.set_value(self._default, emit_signal=True)

        def set_connection_color(self, color: Optional[str]) -> None:
            """v.197: bei aktiver Connection den Ring in Cable-Farbe leuchten lassen.

            Wird vom flux_canvas aufgerufen wenn ein Cable verbunden /
            gelöst wird. ``None`` = unverbunden = Default-Cyan.
            """
            self._connection_color = color
            self.update()

        def closeEvent(self, event):  # type: ignore[override]
            """Cleanup: alle Subscriptions des Widgets entfernen."""
            try:
                eng = get_animation_engine()
                eng.unsubscribe_prefix(f"{self._module_id}::")
            except Exception:
                pass
            super().closeEvent(event)

        # ─── Interne Animations-Trigger ────────────────────────────

        def _trigger_pulse_wave(self) -> None:
            """One-Shot Pulse-Wave (Welle vom Zentrum nach außen)."""
            eng = get_animation_engine()
            sub_id = f"{self._module_id}::pulse"
            ok = eng.subscribe(
                sub_id, ANIM_PULSE_WAVE,
                self._on_pulse_frame,
                duration_ms=400,
            )
            if not ok:
                # Subscription abgelehnt (reduced-motion oder Stub) →
                # Phase manuell setzen damit der visuelle Sprung wenigstens
                # kurz zu sehen ist.
                self._pulse_phase = 0.0

        def _trigger_shimmer(self) -> None:
            """Shimmer-Goldglanz beim Wert-Wechsel (Display unter dem Ring)."""
            eng = get_animation_engine()
            sub_id = f"{self._module_id}::shimmer"
            eng.subscribe(
                sub_id, ANIM_SHIMMER,
                self._on_shimmer_frame,
                duration_ms=300,
            )

        def _on_pulse_frame(self, phase: float, frame: int) -> None:
            self._pulse_phase = float(phase)
            if phase >= 1.0:
                self._pulse_phase = 0.0
            self.update()

        def _on_shimmer_frame(self, phase: float, frame: int) -> None:
            self._shimmer_phase = float(phase)
            if phase >= 1.0:
                self._shimmer_phase = 0.0
            self.update()

        # ─── Mouse-Interaktion (gleich wie AnimatedKnob) ───────────

        def mousePressEvent(self, event):  # type: ignore[override]
            if event.button() == Qt.MouseButton.LeftButton:
                self._dragging = True
                self._drag_origin_y = event.position().y()
                self._drag_origin_value = self._value
                self._drag_fine = bool(
                    event.modifiers() & Qt.KeyboardModifier.ShiftModifier
                )
                self.setCursor(Qt.CursorShape.SizeVerCursor)
                event.accept()
            else:
                super().mousePressEvent(event)

        def mouseMoveEvent(self, event):  # type: ignore[override]
            if not self._dragging:
                return
            self._drag_fine = bool(
                event.modifiers() & Qt.KeyboardModifier.ShiftModifier
            )
            dy = self._drag_origin_y - event.position().y()
            range_ = self._maximum - self._minimum
            sensitivity = self.DRAG_PIXELS_FOR_FULL_RANGE
            if self._drag_fine:
                sensitivity *= self.DRAG_FINE_TUNE_DIVISOR
            new_value = self._drag_origin_value + (dy / sensitivity) * range_
            new_value = _clamp(new_value, self._minimum, self._maximum)
            if new_value != self._value:
                self._value = new_value
                self.value_changed.emit(self._value)
                self._trigger_shimmer()   # während drag konstant shimmern
                self.setToolTip(self._tooltip_text())
                self.update()

        def mouseReleaseEvent(self, event):  # type: ignore[override]
            if event.button() == Qt.MouseButton.LeftButton and self._dragging:
                self._dragging = False
                self._drag_fine = False
                self.unsetCursor()
                # Nach Release noch ein kräftiger Pulse-Wave als Bestätigung
                self._trigger_pulse_wave()
                event.accept()
            else:
                super().mouseReleaseEvent(event)

        def mouseDoubleClickEvent(self, event):  # type: ignore[override]
            if event.button() == Qt.MouseButton.LeftButton:
                self.reset_to_default()
                event.accept()
            else:
                super().mouseDoubleClickEvent(event)

        def wheelEvent(self, event):  # type: ignore[override]
            steps = event.angleDelta().y() / 120.0
            if steps == 0:
                event.ignore()
                return
            range_ = self._maximum - self._minimum
            divisor = self.WHEEL_STEPS_PER_RANGE
            if event.modifiers() & Qt.KeyboardModifier.ShiftModifier:
                divisor *= self.DRAG_FINE_TUNE_DIVISOR
            step = range_ / divisor
            self.set_value(self._value + steps * step, emit_signal=True)
            event.accept()

        # ─── Painting ──────────────────────────────────────────────

        def _value_to_t(self) -> float:
            r = self._maximum - self._minimum
            if r <= 0:
                return 0.0
            return _clamp((self._value - self._minimum) / r, 0.0, 1.0)

        def paintEvent(self, event):  # type: ignore[override]
            painter = QPainter(self)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            painter.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)

            w = self.width()
            h = self.height()
            label_h = 14
            ring_h = h - label_h
            ring_d = min(w, ring_h) - 4
            cx = w / 2.0
            cy = ring_h / 2.0 + 1
            r_outer = ring_d / 2.0

            # Connection-Farbe (cyan default, sonst CV-/Audio-/MIDI-Farbe)
            ring_active_color = self._connection_color or self.COL_RING_ACTIVE

            t = self._value_to_t()

            # 1) Hintergrund-Ring (matt-cyan)
            ring_rect = QRectF(
                cx - r_outer, cy - r_outer,
                2 * r_outer, 2 * r_outer,
            )
            pen_bg = QPen(QColor(self.COL_RING_BG))
            pen_bg.setWidth(self.RING_THICKNESS)
            pen_bg.setCapStyle(Qt.PenCapStyle.FlatCap)
            painter.setPen(pen_bg)
            painter.setBrush(Qt.BrushStyle.NoBrush)
            qt_start = int(225 * 16)
            qt_span_full = int(-270 * 16)
            painter.drawArc(ring_rect, qt_start, qt_span_full)

            # 2) Aktiver Wertbogen (in der Connection-Farbe)
            qt_span_active = int(-270 * t * 16)
            pen_fg = QPen(QColor(ring_active_color))
            pen_fg.setWidth(self.RING_THICKNESS)
            pen_fg.setCapStyle(Qt.PenCapStyle.RoundCap)
            painter.setPen(pen_fg)
            painter.drawArc(ring_rect, qt_start, qt_span_active)

            # 3) Pulse-Wave (One-Shot — auswandernder Ring beim Wert-Wechsel)
            if self._pulse_phase > 0.0:
                # Wave läuft von r_outer * 0.5 nach r_outer * 1.4
                wave_r = r_outer * (0.5 + 0.9 * self._pulse_phase)
                # Alpha fadet: 1.0 -> 0.0
                alpha = int((1.0 - self._pulse_phase) * 200)
                wave_color = QColor(self.COL_PULSE_WAVE)
                wave_color.setAlpha(alpha)
                wave_pen = QPen(wave_color)
                wave_pen.setWidthF(2.0 + 2.0 * (1.0 - self._pulse_phase))
                wave_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
                painter.setPen(wave_pen)
                painter.setBrush(Qt.BrushStyle.NoBrush)
                wave_rect = QRectF(
                    cx - wave_r, cy - wave_r,
                    2 * wave_r, 2 * wave_r,
                )
                painter.drawEllipse(wave_rect)

            # 4) Innerer pulsierender Kern (Größe = Wert)
            #    Bei value=0 ist der Kern minimal (0.15 * r_outer); bei
            #    value=max ist er fast so groß wie das Ring-Innere.
            r_max = r_outer - self.RING_THICKNESS - 2
            core_r = r_max * (0.20 + 0.65 * t)
            # Glow-Halo (etwas größer, transparent)
            glow_r = core_r + 3.0
            glow_grad = QRadialGradient(QPointF(cx, cy), glow_r)
            glow_color_outer = QColor(self.COL_CORE_GLOW)
            glow_color_outer.setAlpha(0)
            glow_color_inner = QColor(self.COL_CORE_GLOW)
            glow_color_inner.setAlpha(80)
            glow_grad.setColorAt(0.0, glow_color_inner)
            glow_grad.setColorAt(1.0, glow_color_outer)
            painter.setBrush(QBrush(glow_grad))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawEllipse(QPointF(cx, cy), glow_r, glow_r)

            # Kern (solid)
            core_grad = QRadialGradient(
                QPointF(cx - core_r * 0.2, cy - core_r * 0.2),
                core_r * 1.4,
            )
            core_grad.setColorAt(0.0, QColor(self.COL_CORE).lighter(160))
            core_grad.setColorAt(0.6, QColor(self.COL_CORE))
            core_grad.setColorAt(1.0, QColor(self.COL_RING_ACTIVE).darker(140))
            painter.setBrush(QBrush(core_grad))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawEllipse(QPointF(cx, cy), core_r, core_r)

            # 5) Wert-Label unter dem Ring (mit optionalem Shimmer)
            f = QFont("monospace", 7)
            painter.setFont(f)
            shimmer = self._shimmer_phase
            if shimmer > 0.0:
                # Ein heller Goldglanz-Streifen läuft von links nach rechts
                # über die Schrift. Implementiert als Mischfarbe zwischen
                # Default-Text und Gold, gewichtet durch eine Glocken-Kurve.
                bell = math.sin(shimmer * math.pi)   # 0..1..0
                base = QColor(self.COL_TEXT_DIM)
                gold = QColor(self.COL_SHIMMER)
                mix = QColor(
                    int(base.red()   * (1 - bell) + gold.red()   * bell),
                    int(base.green() * (1 - bell) + gold.green() * bell),
                    int(base.blue()  * (1 - bell) + gold.blue()  * bell),
                )
                painter.setPen(mix)
            else:
                painter.setPen(QColor(self.COL_TEXT_DIM))
            txt = _format_value(self._value, self._unit,
                                abs(self._maximum) + abs(self._minimum) + 1)
            rect = QRectF(0, ring_h, w, label_h)
            painter.drawText(rect, int(Qt.AlignmentFlag.AlignCenter), txt)

            painter.end()

        # ─── Tooltip / sizeHint ────────────────────────────────────

        def _tooltip_text(self) -> str:
            v = _format_value(
                self._value, self._unit,
                abs(self._maximum) + abs(self._minimum) + 1,
            )
            range_text = (
                f"{self._minimum:g} … {self._maximum:g}"
                + (f" {self._unit}" if self._unit else "")
            )
            return (
                f"<b>{self._name}</b> (PulseRing): {v}<br>"
                f"<span style='color:#8b949e;'>Range: {range_text}<br>"
                f"Default: {self._default:g}<br>"
                f"Drag = Wert · Shift = Fine · 2× Klick = Reset · Wheel = Step</span>"
            )

        def sizeHint(self):  # type: ignore[override]
            return QSize(self.DEFAULT_SIZE + 4, self.DEFAULT_SIZE + 18)

else:
    PulseRingWidget = None  # type: ignore[assignment,misc]


__all__ = ["PulseRingWidget"]
