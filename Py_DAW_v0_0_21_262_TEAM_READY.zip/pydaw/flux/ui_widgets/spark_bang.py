"""
pydaw.flux.ui_widgets.spark_bang — Frigg.SparkBang (Phase W-1)
==============================================================

**Eingebaut in v0.0.21.197** als Norse-Sigil-Replacement für den
klassischen ``BangWidget`` (v.195). Spezifikation:
``PROJECT_DOCS/FLUX_GROVE_MANIFEST.md`` Sektion „FLUX Sigil — eigene
Widget-Designs", Punkt 4.

Design (aus dem Manifest)
-------------------------

* 8-zackiger Funken-Stern (Mjölnir-Funken)
* Bei Klick: Funken-Explosion nach außen (Particle-Animation, ~12 Funken)
* Idle: subtiles Glitzern in den Spitzen (Constellation-artige Animation
  bei Default; aus bei Reduced-Motion)
* Verbunden mit Trigger-Pfaden: leuchtet wenn ein Signal durchgeht

Animation: **Spark-Burst** beim Klick, optional dezentes Glitzern im Idle.

Das Pulse-Verhalten (1.0 → 0.0 nach 80 ms via Off-Timer) ist identisch
zum klassischen ``BangWidget`` — Patches die einen Bang an einen Trigger-
Input geschickt haben funktionieren weiter.

Nichts-Kaputt-Garantie
----------------------

* Identischer Signal-Vertrag wie ``BangWidget``: ``value_changed(float)``
  mit zwei Pulses (1.0 sofort, 0.0 nach 80 ms)
* Reine Python-Schicht
* Defensiv gegen fehlendes Qt
"""

from __future__ import annotations

import logging
import math
import random
from typing import Optional

logger = logging.getLogger(__name__)


try:
    from PyQt6.QtCore import (
        Qt, QPointF, QRectF, QSize, QTimer, pyqtSignal,
    )
    from PyQt6.QtGui import (
        QColor, QPainter, QPen, QBrush, QPolygonF,
    )
    from PyQt6.QtWidgets import QWidget, QSizePolicy
    _QT_AVAILABLE = True
except ImportError:
    _QT_AVAILABLE = False


from pydaw.flux.animation_engine import (
    get_animation_engine, ANIM_SPARK_BURST,
)


# Anzahl Funken bei Burst (Manifest sagt ~12)
SPARK_COUNT = 12


if _QT_AVAILABLE:

    class SparkBangWidget(QWidget):  # type: ignore[misc]
        """Sigil-Bang: 8-zackiger Funken-Stern mit Burst beim Klick.

        Signal-Vertrag (identisch zu BangWidget):
        ``value_changed(float)`` — feuert (1.0, 0.0) als Puls
        ``trigger()`` — externer Auslöser (z.B. via MIDI-Map)
        Felder: ``_minimum=0``, ``_maximum=1``, ``_default=0`` für API-Konsistenz
        """

        DEFAULT_SIZE = 40
        PULSE_MS     = 80     # gleicher Wert wie BangWidget — Trigger-Verträglichkeit

        # Farben — Mjölnir-Gold + Cyan
        COL_BG          = "#0a0e14"
        COL_BORDER      = "#1a1f29"
        COL_BORDER_HOT  = "#fbbf24"      # Gold beim Burst
        COL_STAR_IDLE   = "#3df0e0"      # Cyan im Idle
        COL_STAR_HOT    = "#fbbf24"      # Gold beim Burst
        COL_SPARK       = "#fbbf24"      # Spark-Funken

        value_changed = pyqtSignal(float)

        def __init__(
            self,
            module_id: str = "",
            parent=None,
        ):
            super().__init__(parent)
            self._is_hot = False         # gerade leuchtend (Burst)
            self._module_id = str(module_id) or f"spark_{id(self):x}"

            # API-Compat (BangWidget hat das nicht, aber Auto-Range
            # versucht's defensiv)
            self._minimum = 0.0
            self._maximum = 1.0
            self._default = 0.0

            size = self.DEFAULT_SIZE
            self.setMinimumSize(size, size)
            self.setMaximumSize(size + 4, size + 4)
            self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)

            # Burst-State (12 Funken — randomisierte Richtungen)
            self._burst_phase = 0.0
            self._burst_dirs: list[tuple[float, float]] = []

            # Off-Timer (analog zu BangWidget)
            self._off_timer = QTimer(self)
            self._off_timer.setSingleShot(True)
            self._off_timer.setInterval(self.PULSE_MS)
            self._off_timer.timeout.connect(self._fire_off)

            self.setToolTip(self._tooltip())

        # ─── Public API ────────────────────────────────────────────

        @property
        def value(self) -> float:
            return 1.0 if self._is_hot else 0.0

        def trigger(self) -> None:
            """Externer Trigger (z.B. via MIDI-Map)."""
            self._fire_on()

        # `set_value` für API-Compat — leitet an trigger() weiter wenn
        # ein "ON" reinkommt
        def set_value(self, value: float, *, emit_signal: bool = True) -> None:
            if float(value) >= 0.5 and not self._is_hot:
                if emit_signal:
                    self._fire_on()
                else:
                    # Visuell zeigen ohne Signal
                    self._is_hot = True
                    self._spawn_sparks()
                    self.update()

        def closeEvent(self, event):  # type: ignore[override]
            try:
                eng = get_animation_engine()
                eng.unsubscribe_prefix(f"{self._module_id}::")
            except Exception:
                pass
            super().closeEvent(event)

        # ─── Mouse ─────────────────────────────────────────────────

        def mousePressEvent(self, event):  # type: ignore[override]
            if event.button() == Qt.MouseButton.LeftButton:
                self._fire_on()
                event.accept()
            else:
                super().mousePressEvent(event)

        # ─── Burst-Logik ───────────────────────────────────────────

        def _spawn_sparks(self) -> None:
            """SPARK_COUNT zufällig verteilte Funken-Richtungen erzeugen."""
            self._burst_dirs = []
            for i in range(SPARK_COUNT):
                # Hauptsächlich gleichmäßig im Kreis verteilt, mit
                # leichtem Random-Jitter
                base_angle = 2.0 * math.pi * (i / SPARK_COUNT)
                jitter = random.uniform(-0.15, 0.15)
                angle = base_angle + jitter
                self._burst_dirs.append((math.cos(angle), math.sin(angle)))

        def _fire_on(self) -> None:
            self._is_hot = True
            self.value_changed.emit(1.0)
            self._spawn_sparks()
            self._burst_phase = 0.0
            # Spark-Burst-Animation subscriben (600 ms)
            eng = get_animation_engine()
            eng.subscribe(
                f"{self._module_id}::burst", ANIM_SPARK_BURST,
                self._on_burst_frame,
                duration_ms=600,
            )
            self._off_timer.start()
            self.update()

        def _fire_off(self) -> None:
            self._is_hot = False
            self.value_changed.emit(0.0)
            self.update()

        def _on_burst_frame(self, phase: float, frame: int) -> None:
            self._burst_phase = float(phase)
            if phase >= 1.0:
                self._burst_phase = 0.0
                self._burst_dirs = []
            self.update()

        # ─── Painting ──────────────────────────────────────────────

        def _star_polygon(self, cx: float, cy: float, r_outer: float,
                           r_inner: float) -> "QPolygonF":
            """8-zackiger Stern (Mjölnir-Spitzen)."""
            poly = QPolygonF()
            spikes = 8
            for i in range(spikes * 2):
                # Abwechselnd outer / inner radius
                r = r_outer if (i % 2 == 0) else r_inner
                angle = math.pi / 2 - (math.pi * i / spikes)
                x = cx + r * math.cos(angle)
                y = cy - r * math.sin(angle)   # Qt y-down
                poly.append(QPointF(x, y))
            return poly

        def paintEvent(self, event):  # type: ignore[override]
            painter = QPainter(self)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)

            w = self.width()
            h = self.height()
            size = min(w, h) - 4
            x0 = (w - size) / 2
            y0 = (h - size) / 2
            rect = QRectF(x0, y0, size, size)

            # 1) Hintergrund + Border
            painter.setBrush(QBrush(QColor(self.COL_BG)))
            border_color = self.COL_BORDER_HOT if self._is_hot else self.COL_BORDER
            painter.setPen(QPen(QColor(border_color), 1.5))
            painter.drawRoundedRect(rect, 3.0, 3.0)

            # 2) Stern (8-zackig)
            cx = rect.center().x()
            cy = rect.center().y()
            r_outer = size * 0.36
            r_inner = size * 0.14
            star_color = self.COL_STAR_HOT if self._is_hot else self.COL_STAR_IDLE
            poly = self._star_polygon(cx, cy, r_outer, r_inner)
            star_brush = QColor(star_color)
            if self._is_hot:
                star_brush = star_brush.lighter(140)
            painter.setBrush(QBrush(star_brush))
            painter.setPen(QPen(QColor(star_color).darker(150), 0.8))
            painter.drawPolygon(poly)

            # 3) Spark-Burst (12 Funken radial nach außen)
            if self._burst_phase > 0.0 and self._burst_dirs:
                # Funken-Position: linear vom Stern nach außen
                travel = size * (0.30 + 0.50 * self._burst_phase)
                alpha = int((1.0 - self._burst_phase) * 220)
                spark_color = QColor(self.COL_SPARK)
                spark_color.setAlpha(alpha)
                spark_pen = QPen(spark_color)
                spark_pen.setWidthF(1.5)
                spark_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
                painter.setPen(spark_pen)
                for dx, dy in self._burst_dirs:
                    sx = cx + dx * travel
                    sy = cy + dy * travel
                    # Mini-Strich vom inneren Funken-Ursprung zur aktuellen
                    # Spark-Position
                    inner_r = r_outer * 0.7
                    sx_in = cx + dx * inner_r
                    sy_in = cy + dy * inner_r
                    painter.drawLine(QPointF(sx_in, sy_in), QPointF(sx, sy))
                    # Plus ein kleiner Punkt am Ende
                    painter.setBrush(QBrush(spark_color))
                    painter.drawEllipse(QPointF(sx, sy), 1.2, 1.2)

            painter.end()

        # ─── Tooltip ───────────────────────────────────────────────

        def _tooltip(self) -> str:
            return (
                "<b>SparkBang</b>: Trigger<br>"
                "<span style='color:#8b949e;'>"
                f"Klick = Puls (1.0 → 0.0 nach {self.PULSE_MS} ms)<br>"
                "Mjölnir-Funken zeigen den Burst</span>"
            )

        def sizeHint(self):  # type: ignore[override]
            return QSize(self.DEFAULT_SIZE, self.DEFAULT_SIZE)

else:
    SparkBangWidget = None  # type: ignore[assignment,misc]


__all__ = ["SparkBangWidget"]
