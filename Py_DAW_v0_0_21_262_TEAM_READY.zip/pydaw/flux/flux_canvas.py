"""
pydaw.flux.flux_canvas
======================

Der visuelle FLUX-Canvas — implementiert als PyQt6 QGraphicsScene
mit Custom-Painted Knoten und animierten Verbindungen.  Stilistisch
1:1 am WAECHTER-„Daten-Flux (Live)"-Tab orientiert:

    * schwarzer Hintergrund
    * dünne Neon-Rahmen pro Modul (Farbe = Gott-Familie aus yggdrasil)
    * cyan/magenta-Verbindungslinien mit Glow-Effekt
    * Pulse-Punkte die durch die Linien wandern (10 Hz Tick-Rate)
    * Modul-Header mit Glyphe + Name, Sub-Header mit Funktion
    * Hover-Highlight, Selection-Highlight

Alle Komponenten leben in QGraphicsScene-Items, damit Qt's Standard-
Selection / Drag / Snap / Z-Order funktioniert.  Die Animations-
Logik (Pulse) lebt in einem QTimer, der in die Scene-Items zeichnet.

Tasten-Combos
-------------

    Doppelklick (Canvas)       → Modul-Auswahl-Popup an Klick-Position
    Drag von Output-Port       → Verbindungs-Kabel zum Ziel-Input-Port
    Drag von Input-Port (mit Verbindung) → Trennen
    Del / Backspace            → Selektierte Module + Verbindungen löschen
    Strg+A                     → Alles selektieren
    Strg+D                     → Selektion duplizieren
    Strg+R                     → Selektion umbenennen
    Mausrad                    → Zoom (Strg+Mausrad = präziser)
    Mittlere Maustaste-Drag    → Pan
    Strg+S (im Hauptfenster)   → Patch wird mit Projekt gespeichert
"""

from __future__ import annotations

import logging
import math
from typing import Optional

try:
    from PyQt6.QtCore import (
        Qt, QPointF, QRectF, QTimer, QLineF, pyqtSignal, QObject,
    )
    from PyQt6.QtGui import (
        QColor, QPen, QBrush, QPainter, QPainterPath, QPainterPathStroker, QFont,
        QLinearGradient, QRadialGradient, QFontMetrics,
    )
    from PyQt6.QtWidgets import (
        QGraphicsScene, QGraphicsView, QGraphicsItem,
        QGraphicsPathItem, QGraphicsRectItem, QGraphicsEllipseItem,
        QGraphicsTextItem, QGraphicsObject, QGraphicsProxyWidget,
        QMenu, QInputDialog, QStyleOptionGraphicsItem,
    )
    _QT_AVAILABLE = True
except ImportError:
    _QT_AVAILABLE = False

from pydaw.flux.patch_model import (
    Patch, Module, Port, PortKind, PortDirection, Connection,
)
from pydaw.flux.yggdrasil import GODS, get_god, FluxColor


logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════
# Visual Constants — alle Maße zentralisiert für konsistentes Layout
# ═══════════════════════════════════════════════════════════════════

MOD_WIDTH      = 180        # Default-Breite eines Modul-Knotens
MOD_HEADER_H   = 32         # Höhe des farbigen Header-Streifens
MOD_PORT_H     = 22         # Pixel-Höhe pro Port-Zeile
MOD_PADDING    = 8
MOD_RADIUS     = 6          # Eck-Radius
MOD_BORDER     = 1.5        # Rahmen-Dicke

PORT_RADIUS    = 5          # Port-Kreis-Radius
PORT_HIT_BOX   = 12         # Erkennungs-Box für Klicks (größer als sichtbar)

CABLE_WIDTH         = 2.0
CABLE_GLOW_WIDTH    = 6.0
PULSE_SIZE          = 4.0
PULSE_SPEED_PX_PER_FRAME = 6   # bei 50 ms Tick = 120 px/s
PULSE_INTERVAL_PX   = 80       # Abstand zwischen den wandernden Pulsen

CANVAS_BG          = QColor("#0a0e14") if _QT_AVAILABLE else None
GRID_COLOR         = QColor("#161b22") if _QT_AVAILABLE else None
TEXT_PRIMARY       = QColor("#e6edf3") if _QT_AVAILABLE else None
TEXT_SECONDARY     = QColor("#8b949e") if _QT_AVAILABLE else None

# ─── v0.0.21.230 — Living Patterns UI (Session 2/3) ──────────────────
# Layout-Konstanten für die Tag-Chip-Strips unter `dynamic_outputs`-
# Modulen. Die Strips werden direkt unter dem normalen Port-Bereich
# gerendert; die Modul-Höhe wächst dynamisch mit der Anzahl Tags.
# Risiko-Begrenzung: nur Module mit ``module.dynamic_outputs == True``
# werden überhaupt erweitert — alle anderen Module bleiben pixel-genau
# identisch zum v.229-Layout. NICHTS-KAPUTT.
LP_SECTION_PAD_TOP  = 6     # Lücke zwischen Port-Block und LP-Section
LP_HEADER_H         = 14    # Höhe der "PROMOTED"/"OBSERVED"-Mini-Header
LP_CHIP_H           = 18    # Pixel-Höhe einer Chip-Zeile
LP_CHIP_GAP_X       = 4     # Horizontaler Abstand zwischen Chips
LP_CHIP_GAP_Y       = 3     # Vertikaler Abstand zwischen Chip-Reihen
LP_CHIP_PAD_X       = 6     # Innen-Padding (Text-Abstand zum Chip-Rand)
LP_CHIP_RADIUS      = 6     # Eck-Radius der Chips
LP_MAX_VISIBLE      = 8     # Max sichtbare Chips pro Section, Rest "+N more"
LP_BOTTOM_PAD       = 6
LP_SIDE_PAD         = 8     # Linker/rechter Innenrand der LP-Section
# Farben
LP_COLOR_PROMOTED   = QColor("#a78bfa") if _QT_AVAILABLE else None  # bright purple (frozen_tags)
LP_COLOR_OBSERVED   = QColor("#3a3050") if _QT_AVAILABLE else None  # dim purple-grey (observed_tags)
LP_COLOR_OVERFLOW   = QColor("#1f1530") if _QT_AVAILABLE else None  # very dim "+N more"
LP_TEXT_PROMOTED    = QColor("#0a0814") if _QT_AVAILABLE else None  # dark text on bright chip
LP_TEXT_OBSERVED    = QColor("#c4b5fd") if _QT_AVAILABLE else None  # light purple text
LP_TEXT_OVERFLOW    = QColor("#8b949e") if _QT_AVAILABLE else None
LP_SECTION_HDR_COL  = QColor("#a78bfa") if _QT_AVAILABLE else None


# ═══════════════════════════════════════════════════════════════════
# QGraphicsItems
# ═══════════════════════════════════════════════════════════════════

if _QT_AVAILABLE:

    class PortItem(QGraphicsEllipseItem):
        """Ein Port als kleiner farbiger Kreis am Rand des Moduls.

        Linke Seite = Input, rechte Seite = Output.  Die Farbe codiert
        den Port-Kind:
          * Audio   = cyan   (#3df0e0)
          * CV      = gelb   (#fbbf24)
          * MIDI    = magenta(#ec4899)
          * Gate    = rot    (#ef4444)
          * Rune    = purple (#a78bfa)  — v0.0.21.218 (Phase 2.3)

        Der `_color` der ConnectionItem wird aus der Source-Port-Brush
        abgeleitet, daher färben sich Rune-Cables automatisch purple
        sobald der Source-Port purple ist — keine extra Logik nötig.
        """

        KIND_COLORS: dict[PortKind, QColor] = {
            PortKind.AUDIO: QColor("#3df0e0"),
            PortKind.CV:    QColor("#fbbf24"),
            PortKind.MIDI:  QColor("#ec4899"),
            PortKind.GATE:  QColor("#ef4444"),
            # v0.0.21.218 — Rune-Realm (Phase 2.3): Vör/Norns/Ullr/
            # Ratatosk/Hoenir/Galdr nutzen RUNE-Ports. Purple matcht
            # die Module-Header-Farbe (FluxColor.PURPLE = #a78bfa) —
            # damit ist visuell sofort klar dass diese Pipeline im
            # Message-Realm läuft, nicht im Audio/CV-Realm.
            PortKind.RUNE:  QColor("#a78bfa"),
        }

        def __init__(self, port: Port, parent_module_item: "ModuleItem",
                     local_y: float):
            r = PORT_RADIUS
            super().__init__(-r, -r, 2 * r, 2 * r, parent_module_item)
            self.port = port
            self.module_item = parent_module_item
            self.setBrush(QBrush(self.KIND_COLORS.get(port.kind, QColor("#888"))))
            self.setPen(QPen(QColor("#0a0e14"), 1.5))
            self.setAcceptHoverEvents(True)
            self.setCursor(Qt.CursorShape.CrossCursor)
            # Position relativ zum Modul:  Inputs auf der linken Kante (x=0),
            # Outputs auf der rechten (x=MOD_WIDTH).
            x = 0 if port.direction == PortDirection.INPUT else MOD_WIDTH
            self.setPos(x, local_y)

        def hoverEnterEvent(self, event):
            self.setBrush(QBrush(self.brush().color().lighter(140)))
            super().hoverEnterEvent(event)

        def hoverLeaveEvent(self, event):
            self.setBrush(QBrush(self.KIND_COLORS.get(self.port.kind, QColor("#888"))))
            super().hoverLeaveEvent(event)

        def scene_pos(self) -> QPointF:
            return self.mapToScene(QPointF(0, 0))


    class ModuleItem(QGraphicsItem):
        """Ein FLUX-Modul-Knoten — Rechteck mit farbigem Header + Ports.

        Implementiert Custom-Painting für den Wächter-Stil-Look.
        Nutzt QGraphicsItem (nicht QGraphicsObject), weil wir keine
        Signals/Slots auf Item-Ebene brauchen — Events gehen über die
        Scene.

        v0.0.21.195: UI-Widget-Embedding. Wenn das Modul ein Frigg-
        Widget ist (Knob, Slider, Toggle, Bang, NumberBox, Comment),
        wird ein interaktives Widget über `QGraphicsProxyWidget` in
        den Modul-Body eingebettet. Das Widget feuert sein
        `value_changed`-Signal direkt; die FluxScene verdrahtet es
        mit `UiModuleBridge.handle_ui_value_changed()`.
        """

        # v0.0.21.195 — Standard-Höhen für eingebettete UI-Widgets
        UI_KNOB_BODY_H     = 64
        UI_SLIDER_V_BODY_H = 110
        UI_SLIDER_H_BODY_H = 36
        UI_TOGGLE_BODY_H   = 48
        UI_BANG_BODY_H     = 48
        UI_NUMBOX_BODY_H   = 36
        UI_COMMENT_BODY_H  = 32
        # v0.0.21.197 — Sigil-Widgets (W-1)
        UI_PULSE_RING_BODY_H      = 70
        UI_AURORA_SLIDER_V_BODY_H = 130
        UI_AURORA_SLIDER_H_BODY_H = 38
        UI_RUNE_TOGGLE_BODY_H     = 50
        UI_SPARK_BANG_BODY_H      = 50
        # v0.0.21.200 — Display-Sigil-Widgets (W-2)
        UI_VOLVA_NUMBER_BODY_H    = 56
        UI_BAUTA_STONE_BODY_H     = 64
        UI_MANI_METER_BODY_H      = 64
        # v0.0.21.231 — NumberFlow (display + sparkline historie)
        UI_NUMBER_FLOW_BODY_H     = 78
        # v0.0.21.203 — Saga.Magic Body (Stippling-Visualizer; größerer
        # Body damit die Form gut sichtbar ist, plus Platz für die
        # 2 Audio-In/Out-Port-Paare an den Seiten).
        SAGA_MAGIC_BODY_H         = 168

        def __init__(self, module: Module):
            super().__init__()
            self.module = module
            self.god = get_god(module.god)
            self.color = QColor(self.god.color.value if self.god else "#888")
            self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsMovable)
            self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsSelectable)
            self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemSendsGeometryChanges)
            self.setAcceptHoverEvents(True)
            self.setPos(QPointF(*module.position))
            self.port_items: list[PortItem] = []
            # v0.0.21.171: Aktivitäts-Wert (0..1) für „atmen"-Animation.
            # Wird vom Scene-Tick aus audio_preview.get_activity() gelesen.
            self.activity: float = 0.0

            # v0.0.21.230 — Living Patterns UI Layout-Cache.
            # `_lp_chips` enthält die Liste der gezeichneten Chip-Rechtecke
            # mit ihren zugeordneten Tag-Werten — wird in `_compute_lp_layout`
            # aufgebaut und in `mousePressEvent` für Hit-Testing genutzt.
            # `_lp_section_h` ist die zusätzliche Höhe die unter dem
            # normalen Port-Block reserviert wird (0 wenn das Modul
            # nicht ``dynamic_outputs`` hat oder gerade nichts zu zeigen ist).
            # `_lp_signature` ist ein billiger State-Hash über
            # observed/frozen-Tags; wenn sich der Hash zwischen 50ms-Ticks
            # ändert, ruft die FluxScene `update()` auf — das verhindert
            # konstanten Repaint bei statischen Patches und gibt Live-
            # Updates beim Test Play sobald neue Tags reinkommen.
            self._lp_chips: list[dict] = []   # list of {rect, value, section, overflow}
            self._lp_section_h: float = 0.0
            self._lp_signature: tuple = ()

            # v0.0.21.195: UI-Widget-Embedding (Frigg-Module)
            self.embedded_widget = None        # das eigentliche QWidget
            self.embedded_proxy = None         # QGraphicsProxyWidget-Wrapper
            self._is_ui_widget = bool(module.is_ui_widget())
            self._build_ui_widget_if_needed()

            # v0.0.21.203: Saga.Magic erkennen — kein eingebettetes Widget,
            # aber Custom-Body-Painting via SagaRendererProxy. Subscribe
            # passiert hier; unsubscribe in `set_patch()`/`remove_selected()`
            # über die `_saga_unsubscribe()`-Helfer-Methode.
            self._is_saga_magic: bool = bool(
                str(module.god) == "Saga" and str(module.kind) == "Magic"
            )
            if self._is_saga_magic:
                self._saga_subscribe()

            self._build_ports()

        def _build_ui_widget_if_needed(self) -> None:
            """v0.0.21.195: Erstellt das passende UI-Widget je nach Frigg-Kind.

            Wird einmalig im __init__ aufgerufen. Kein Throw bei
            unbekannten Kinds — fällt einfach auf einen leeren Body
            zurück (das Modul wird wie ein normales DSP-Modul gerendert).
            """
            if not self._is_ui_widget:
                return
            kind = (self.module.kind or "").strip()
            try:
                from pydaw.flux.ui_widgets import (
                    AnimatedKnob, ToggleWidget, BangWidget,
                    SliderWidget, NumberBoxWidget, CommentWidget,
                    # v.197 W-1 Sigil-Widgets
                    PulseRingWidget, AuroraSliderWidget,
                    RuneToggleWidget, SparkBangWidget,
                    # v.200 W-2 Display-Sigil-Widgets
                    VolvaNumberWidget, BautaStoneWidget, ManiMeterWidget,
                    # v.231 — Live-Probe für CV/RUNE-Werte
                    NumberFlowWidget,
                )
            except Exception as e:
                logger.debug("[FLUX-UI] ui_widgets import failed: %s", e)
                return

            params = self.module.params or {}
            value   = float(params.get("value", 0.0))
            mn      = float(params.get("minimum", 0.0))
            mx      = float(params.get("maximum", 1.0))
            default = float(params.get("default", value))

            widget = None
            try:
                if kind == "Knob" and AnimatedKnob is not None:
                    widget = AnimatedKnob(
                        name="value", value=value,
                        minimum=mn, maximum=mx, default=default,
                        unit="",
                    )
                elif kind == "SliderV" and SliderWidget is not None:
                    widget = SliderWidget(
                        value=value, minimum=mn, maximum=mx,
                        default=default, orientation="vertical",
                    )
                elif kind == "SliderH" and SliderWidget is not None:
                    widget = SliderWidget(
                        value=value, minimum=mn, maximum=mx,
                        default=default, orientation="horizontal",
                    )
                elif kind == "Toggle" and ToggleWidget is not None:
                    widget = ToggleWidget(value=value)
                elif kind == "Bang" and BangWidget is not None:
                    widget = BangWidget()
                elif kind == "NumberBox" and NumberBoxWidget is not None:
                    widget = NumberBoxWidget(
                        value=value, minimum=mn, maximum=mx,
                        default=default,
                    )
                elif kind == "Comment" and CommentWidget is not None:
                    widget = CommentWidget(
                        text=str(self.module.extra.get("text", "Comment …")),
                    )
                # v.197 W-1 — Sigil-Widgets
                elif kind == "PulseRing" and PulseRingWidget is not None:
                    widget = PulseRingWidget(
                        name="value", value=value,
                        minimum=mn, maximum=mx, default=default,
                        unit="", module_id=self.module.id,
                    )
                elif kind == "AuroraSliderV" and AuroraSliderWidget is not None:
                    widget = AuroraSliderWidget(
                        value=value, minimum=mn, maximum=mx,
                        default=default, orientation="vertical",
                        module_id=self.module.id,
                    )
                elif kind == "AuroraSliderH" and AuroraSliderWidget is not None:
                    widget = AuroraSliderWidget(
                        value=value, minimum=mn, maximum=mx,
                        default=default, orientation="horizontal",
                        module_id=self.module.id,
                    )
                elif kind == "RuneToggle" and RuneToggleWidget is not None:
                    widget = RuneToggleWidget(
                        value=value,
                        rune=str(self.module.extra.get("rune", "ᚠ")),
                        module_id=self.module.id,
                    )
                elif kind == "SparkBang" and SparkBangWidget is not None:
                    widget = SparkBangWidget(
                        module_id=self.module.id,
                    )
                # v.200 W-2 — Display-Sigil-Widgets
                elif kind == "VolvaNumber" and VolvaNumberWidget is not None:
                    decimals = int(params.get("decimals", 3))
                    widget = VolvaNumberWidget(
                        value=value, minimum=mn, maximum=mx,
                        default=default, decimals=decimals,
                        module_id=self.module.id,
                    )
                elif kind == "BautaStone" and BautaStoneWidget is not None:
                    runes = self.module.extra.get("runes")
                    if runes is None or not isinstance(runes, list):
                        runes = ["ᚠ", "ᚢ", "ᚦ", "ᚨ"]
                    widget = BautaStoneWidget(
                        value=value,
                        runes=list(runes),
                        module_id=self.module.id,
                    )
                elif kind == "ManiMeter" and ManiMeterWidget is not None:
                    widget = ManiMeterWidget(
                        value=value, minimum=mn, maximum=mx,
                        default=default,
                        module_id=self.module.id,
                    )
                # v.231 — Live-Probe für CV-Werte (read-only Display)
                elif kind == "NumberFlow" and NumberFlowWidget is not None:
                    decimals = int(params.get("decimals", 3))
                    widget = NumberFlowWidget(
                        value=0.0,
                        decimals=decimals,
                        module_id=self.module.id,
                    )
            except Exception as e:
                logger.debug("[FLUX-UI] widget create failed for %s: %s", kind, e)
                widget = None

            if widget is None:
                return

            # Hintergrund transparent halten, damit das Modul-Body
            # durchscheint
            try:
                widget.setStyleSheet("background: transparent;")
            except Exception:
                pass
            self.embedded_widget = widget
            proxy = QGraphicsProxyWidget(self)
            proxy.setWidget(widget)
            self.embedded_proxy = proxy
            # Position wird in `_position_ui_widget()` gesetzt — nachdem
            # Header + Ports klar sind.
            self._position_ui_widget()

        def _position_ui_widget(self) -> None:
            """Positioniert das eingebettete Widget im Modul-Body."""
            if self.embedded_proxy is None:
                return
            # Mittig im Body-Bereich (unter dem Header)
            body_y = MOD_HEADER_H + 6
            body_h = self._ui_body_height()
            widget = self.embedded_widget
            if widget is None:
                return
            w_size = widget.sizeHint()
            w_w = max(40, min(MOD_WIDTH - 20, w_size.width()))
            w_h = max(20, min(body_h, w_size.height()))
            x = (MOD_WIDTH - w_w) / 2
            y = body_y + (body_h - w_h) / 2
            self.embedded_proxy.setGeometry(QRectF(x, y, w_w, w_h))

        def _ui_body_height(self) -> float:
            """Body-Höhe je nach UI-Widget-Typ."""
            if not self._is_ui_widget:
                return 0
            kind = (self.module.kind or "").strip()
            return {
                "Knob":      self.UI_KNOB_BODY_H,
                "SliderV":   self.UI_SLIDER_V_BODY_H,
                "SliderH":   self.UI_SLIDER_H_BODY_H,
                "Toggle":    self.UI_TOGGLE_BODY_H,
                "Bang":      self.UI_BANG_BODY_H,
                "NumberBox": self.UI_NUMBOX_BODY_H,
                "Comment":   self.UI_COMMENT_BODY_H,
                # v.197 W-1 — Sigil-Widgets
                "PulseRing":     self.UI_PULSE_RING_BODY_H,
                "AuroraSliderV": self.UI_AURORA_SLIDER_V_BODY_H,
                "AuroraSliderH": self.UI_AURORA_SLIDER_H_BODY_H,
                "RuneToggle":    self.UI_RUNE_TOGGLE_BODY_H,
                "SparkBang":     self.UI_SPARK_BANG_BODY_H,
                # v.200 W-2 — Display-Sigil
                "VolvaNumber":   self.UI_VOLVA_NUMBER_BODY_H,
                "BautaStone":    self.UI_BAUTA_STONE_BODY_H,
                "ManiMeter":     self.UI_MANI_METER_BODY_H,
                # v.231 — Live-Probe (Number-Display mit Sparkline)
                "NumberFlow":    self.UI_NUMBER_FLOW_BODY_H,
            }.get(kind, 40)

        # ─── v0.0.21.203 — Saga.Magic-Renderer-Hook ──────────────
        def _saga_body_height(self) -> float:
            """Body-Höhe für Saga.Magic — fixe Höhe analog Frigg-Widgets."""
            return float(self.SAGA_MAGIC_BODY_H)

        def _saga_subscribe(self) -> None:
            """Registriert das Modul beim ``SagaRendererProxy``-Singleton.

            Wird in `__init__` aufgerufen wenn das Modul ein Saga.Magic
            ist. Die aktuellen Param-Werte werden direkt übermittelt;
            Updates kommen über `_saga_apply_param_update()`.

            Idempotent: wenn der Proxy nicht verfügbar ist (Qt-less
            Tests), wird `subscribe()` ein No-Op und logged debug.
            """
            try:
                from pydaw.flux.saga.renderer_proxy import (
                    get_saga_renderer_proxy,
                )
            except Exception as e:
                logger.debug("[FLUX-SAGA] proxy import failed: %s", e)
                return
            try:
                proxy = get_saga_renderer_proxy()
                params = self.module.params or {}
                proxy.subscribe(
                    str(self.module.id),
                    shape_id=int(params.get("shape", 0.0)),
                    density=float(params.get("density", 0.7)),
                    rotation_speed=float(params.get("rotation_speed", 0.5)),
                    audio_react=float(params.get("audio_react", 0.6)),
                    palette=int(params.get("palette", 0.0)),
                )
                logger.debug(
                    "[FLUX-SAGA] subscribed mod_id=%s shape=%s",
                    self.module.id, params.get("shape", 0.0),
                )
            except Exception as e:
                logger.warning("[FLUX-SAGA] subscribe failed: %s", e)

        def _saga_unsubscribe(self) -> None:
            """Idempotent. Wird beim Modul-Destroy/Patch-Wechsel aufgerufen."""
            if not self._is_saga_magic:
                return
            try:
                from pydaw.flux.saga.renderer_proxy import (
                    get_saga_renderer_proxy,
                )
                proxy = get_saga_renderer_proxy()
                proxy.unsubscribe(str(self.module.id))
                logger.debug(
                    "[FLUX-SAGA] unsubscribed mod_id=%s", self.module.id,
                )
            except Exception as e:
                logger.debug("[FLUX-SAGA] unsubscribe failed: %s", e)

        def _saga_apply_param_update(self) -> None:
            """Wird aufgerufen wenn sich Module-Params von außen ändern
            (z.B. UiModuleBridge nach Knob-Drehung). Liest die aktuellen
            Werte und schiebt sie zum Proxy. Idempotent / fehlertolerant.
            """
            if not self._is_saga_magic:
                return
            try:
                from pydaw.flux.saga.renderer_proxy import (
                    get_saga_renderer_proxy,
                )
                proxy = get_saga_renderer_proxy()
                params = self.module.params or {}
                proxy.update_params(
                    str(self.module.id),
                    shape_id=int(params.get("shape", 0.0)),
                    density=float(params.get("density", 0.7)),
                    rotation_speed=float(params.get("rotation_speed", 0.5)),
                    audio_react=float(params.get("audio_react", 0.6)),
                    palette=int(params.get("palette", 0.0)),
                )
            except Exception as e:
                logger.debug("[FLUX-SAGA] param update failed: %s", e)

        def _paint_saga_body(self, painter: QPainter) -> None:
            """Zeichnet den Saga.Magic-Body: leichter Hintergrund + Punktwolke.

            Wird aus `paint()` aufgerufen NACHDEM Header gezeichnet wurde
            und VOR den Port-Labels (Labels malen über die Punkte). So
            sind die Labels lesbar, der Body wirkt aber als „Bühne".

            Body-Rect: links und rechts mit ~30 px Rand für die Port-
            Hotzonen (PORT_HIT_BOX = 12 px Hitbox + Label-Bereich).
            Höhe: vom Header-Bottom bis zum Item-Bottom minus Padding.
            """
            try:
                from pydaw.flux.saga.renderer_proxy import (
                    get_saga_renderer_proxy,
                )
            except Exception:
                return
            try:
                proxy = get_saga_renderer_proxy()
            except Exception as e:
                logger.debug("[FLUX-SAGA] proxy fetch failed: %s", e)
                return

            # Body-Rect berechnen — wir lassen links 30 und rechts 30 px
            # für Ports + Labels frei; oben unter Header + 4 px Luft;
            # unten bis nahe der Modul-Unterkante (Padding-Margin).
            BODY_LEFT_MARGIN  = 30   # Inputs (PORT_RADIUS + Label)
            BODY_RIGHT_MARGIN = 30   # Outputs
            BODY_TOP_GAP      = 4
            BODY_BOTTOM_GAP   = 4
            total_h = self.total_height()
            body_x = BODY_LEFT_MARGIN
            body_y = MOD_HEADER_H + BODY_TOP_GAP
            body_w = MOD_WIDTH - BODY_LEFT_MARGIN - BODY_RIGHT_MARGIN
            body_h = total_h - MOD_HEADER_H - BODY_TOP_GAP - BODY_BOTTOM_GAP - MOD_PADDING
            if body_w < 30 or body_h < 30:
                return    # zu klein, nichts malen
            body_rect = QRectF(body_x, body_y, body_w, body_h)

            # Sehr dezenter dunkler Hintergrund (cyan-tönig) damit der
            # Body als „Saga-Stage" erkennbar ist auch wenn keine Punkte
            # gerendert sind (z.B. density=0).
            painter.save()
            try:
                stage_bg = QColor(8, 22, 28, 90)   # dunkles Cyan-Schwarz
                painter.setBrush(QBrush(stage_bg))
                painter.setPen(Qt.PenStyle.NoPen)
                painter.drawRoundedRect(body_rect, 4, 4)

                # Punktwolke vom Proxy zeichnen lassen.
                proxy.paint(painter, str(self.module.id), body_rect)
            except Exception as e:
                logger.debug("[FLUX-SAGA] paint failed: %s", e)
            finally:
                painter.restore()

            # Hinweis: Das periodische Re-Painting für Animation läuft
            # nicht hier (würde Endlosschleife paint→update→paint
            # auslösen). Stattdessen ruft `FluxScene._tick_pulses()` für
            # alle Saga-Module einmal pro 10-Hz-Pulse-Tick `item.update()`
            # auf — siehe `_tick_pulses()` weiter unten.
        def _build_ports(self) -> None:
            # Inputs auf der linken Seite, Outputs rechts — wir laufen
            # vertikal nach unten ab dem Header
            # v0.0.21.195: Bei UI-Widgets werden die Output-Ports rechts
            # neben dem eingebetteten Widget mittig vertikal positioniert
            if self._is_ui_widget:
                body_y = MOD_HEADER_H + 6
                body_h = self._ui_body_height()
                center_y = body_y + body_h / 2
                # Inputs links — meist keine bei Frigg-Widgets, aber
                # defensiv: wenn doch welche da sind, positionieren wir
                # sie linear
                y = MOD_HEADER_H + MOD_PORT_H / 2
                for p in self.module.inputs:
                    pi = PortItem(p, self, y)
                    self.port_items.append(pi)
                    y += MOD_PORT_H
                # Outputs rechts mittig vertikal — bei mehreren Outputs
                # gestapelt zentriert um body_center
                outs = list(self.module.outputs)
                if outs:
                    n = len(outs)
                    spacing = MOD_PORT_H
                    start_y = center_y - ((n - 1) * spacing) / 2
                    for i, p in enumerate(outs):
                        pi = PortItem(p, self, start_y + i * spacing)
                        self.port_items.append(pi)
                return

            # Standard-Layout für DSP-Module (unverändert seit v.193)
            y = MOD_HEADER_H + MOD_PORT_H / 2
            for p in self.module.inputs:
                pi = PortItem(p, self, y)
                self.port_items.append(pi)
                y += MOD_PORT_H
            y = MOD_HEADER_H + MOD_PORT_H / 2
            for p in self.module.outputs:
                pi = PortItem(p, self, y)
                self.port_items.append(pi)
                y += MOD_PORT_H

        def total_height(self) -> float:
            # v0.0.21.195: UI-Module haben fixe Body-Höhe abhängig vom Widget
            if self._is_ui_widget:
                return MOD_HEADER_H + self._ui_body_height() + MOD_PADDING + 6
            # v0.0.21.203: Saga.Magic hat fixen Body unter dem Header,
            # plus Platz für die 7 Inputs + 2 Outputs daneben. Body und
            # Ports ÜBERLAPPEN auf der Y-Achse (Body ist semi-transparent
            # Hintergrund, Port-Labels malen darüber).
            if self._is_saga_magic:
                n = max(len(self.module.inputs), len(self.module.outputs), 1)
                port_area = n * MOD_PORT_H
                body = self._saga_body_height()
                return MOD_HEADER_H + max(port_area, body) + MOD_PADDING
            n = max(len(self.module.inputs), len(self.module.outputs), 1)
            base_h = MOD_HEADER_H + n * MOD_PORT_H + MOD_PADDING
            # v0.0.21.230 — Living Patterns: zusätzliche Höhe für Chip-Strips
            # nur bei dynamic_outputs-Modulen. Wert wird in _compute_lp_layout
            # aktualisiert (bei jedem paint() ohnehin neu berechnet).
            return base_h + self._lp_section_h

        # ─── v0.0.21.230 — Living Patterns Layout & Painter ──────────

        def _lp_active(self) -> bool:
            """True wenn dieses Modul die Living-Patterns-Section zeigen soll.

            Bedingung: ``module.dynamic_outputs == True``. UI-Widget-Module
            (Frigg) haben dynamic_outputs=False und sind nicht betroffen,
            ebenso wie Saga.Magic. Damit ist der Pfad strikt opt-in.
            """
            return bool(getattr(self.module, "dynamic_outputs", False))

        def _lp_compute_signature(self) -> tuple:
            """Billiger State-Hash der observed/frozen-Tags.

            Wird vom FluxScene-Tick (50ms) konsultiert: wenn sich die
            Signatur ändert → ``self.update()`` triggern (Repaint).
            Sonst kein Repaint, kein GIL-Druck auf Audio.
            """
            if not self._lp_active():
                return ()
            obs = self.module.observed_tags.get(
                "rune_in", []
            )
            frz = self.module.frozen_tags.get("rune_in", [])
            # tuple(...) ist hashbar und billig zu erzeugen
            return (
                tuple(repr(x) for x in obs),
                tuple(repr(x) for x in frz),
                bool(self.module.frozen),
            )

        def _lp_chip_text_width(self, painter: QPainter, text: str) -> float:
            """Schätzt die Breite des Chip-Texts in Pixel.

            Uses fontMetrics — funktioniert nur während paint(). Im
            ``_compute_lp_layout`` (das auch ohne aktiven Painter
            laufen muss, z.B. für total_height) nutzen wir eine
            Fallback-Heuristik: ~6 px pro Zeichen bei monospace-9pt.
            """
            try:
                fm = painter.fontMetrics()
                return float(fm.horizontalAdvance(text))
            except Exception:
                return float(len(text) * 6)

        def _compute_lp_layout(
            self, painter: Optional[QPainter] = None,
        ) -> None:
            """Baut ``self._lp_chips`` auf und setzt ``self._lp_section_h``.

            Aufruf:
                * In ``paint()`` mit aktivem painter (für genaue Text-
                  Breiten via fontMetrics).
                * In ``total_height()`` (vor erstem paint) ohne painter
                  → fallback auf Heuristik. Das Layout korrigiert sich
                  beim ersten paint() ohnehin.

            Layout-Algorithmus:
                * Section "PROMOTED" (frozen_tags) zuerst, dann
                  Section "OBSERVED" (observed_tags ohne promoted).
                * Pro Section: max ``LP_MAX_VISIBLE`` Chips zeigen,
                  Rest als "+N more"-Chip.
                * Wrapping: Chips fliessen nach rechts und brechen
                  in eine neue Reihe um wenn die Modul-Breite überschritten.

            Mutiert:
                * ``self._lp_chips`` (Liste von Chip-Records)
                * ``self._lp_section_h`` (Höhe in px)
                * ``self._lp_signature`` (für Tick-Diff)
            """
            # Reset
            self._lp_chips = []
            self._lp_section_h = 0.0

            if not self._lp_active():
                self._lp_signature = ()
                return

            # Lazy-Import damit das ganze Modul auch ohne Living-Patterns
            # importierbar bleibt (Tests, Tooling).
            try:
                from pydaw.flux.living_patterns import (
                    get_promoted_patterns, get_observed_for_display,
                    format_tag_label,
                )
            except Exception as e:
                logger.debug("[LP] living_patterns import failed: %s", e)
                self._lp_signature = ()
                return

            promoted = get_promoted_patterns(self.module)
            observed = get_observed_for_display(self.module)

            # Wenn beide Listen leer sind UND das Modul nicht frozen ist,
            # zeigen wir keine LP-Section (ESC) — sonst ist da nur der
            # Header-Ghost ohne Inhalt. Bei frozen=True zeigen wir sie
            # immer (auch wenn leer) damit der User die Snapshot-Funktion
            # weiterhin benutzen kann via Properties-Panel; kein Inhalt
            # heisst dann "leer aber gefroren".
            if not promoted and not observed and not self.module.frozen:
                self._lp_signature = self._lp_compute_signature()
                return

            # Innen-Rechteck-Breite der LP-Section
            section_x0 = LP_SIDE_PAD
            section_x1 = MOD_WIDTH - LP_SIDE_PAD
            usable_w = section_x1 - section_x0

            # Standard-Port-Block-Höhe (vor LP-Section)
            n_ports = max(len(self.module.inputs), len(self.module.outputs), 1)
            ports_block_h = n_ports * MOD_PORT_H

            # Y-Cursor (lokales Koordinatensystem des Items)
            y_cursor = MOD_HEADER_H + ports_block_h + LP_SECTION_PAD_TOP

            # Trenn-Linie wird im paint() gezogen; hier nur Höhe addieren
            y_cursor += 2  # 1px Linie + 1px Luft

            # ── PROMOTED Section ──
            if promoted or self.module.frozen:
                y_cursor += LP_HEADER_H
                visible = promoted[:LP_MAX_VISIBLE]
                overflow_n = max(0, len(promoted) - LP_MAX_VISIBLE)
                row_y = y_cursor
                row_x = section_x0
                row_h = LP_CHIP_H
                for tag in visible:
                    label = format_tag_label(tag)
                    text_w = self._lp_chip_text_width(painter, label) \
                        if painter is not None else float(len(label) * 6)
                    chip_w = text_w + 2 * LP_CHIP_PAD_X
                    # Wrap auf neue Zeile?
                    if row_x + chip_w > section_x1 and row_x > section_x0:
                        row_y += LP_CHIP_H + LP_CHIP_GAP_Y
                        row_x = section_x0
                    rect = QRectF(row_x, row_y, chip_w, LP_CHIP_H)
                    self._lp_chips.append({
                        "rect": rect, "value": tag,
                        "section": "promoted", "overflow": False,
                        "label": label,
                    })
                    row_x += chip_w + LP_CHIP_GAP_X
                if overflow_n > 0:
                    label = f"+{overflow_n} more"
                    text_w = self._lp_chip_text_width(painter, label) \
                        if painter is not None else float(len(label) * 6)
                    chip_w = text_w + 2 * LP_CHIP_PAD_X
                    if row_x + chip_w > section_x1 and row_x > section_x0:
                        row_y += LP_CHIP_H + LP_CHIP_GAP_Y
                        row_x = section_x0
                    rect = QRectF(row_x, row_y, chip_w, LP_CHIP_H)
                    self._lp_chips.append({
                        "rect": rect, "value": None,
                        "section": "promoted", "overflow": True,
                        "label": label,
                    })
                y_cursor = row_y + LP_CHIP_H

            # ── OBSERVED Section ──
            if observed:
                # Etwas Luft zwischen Sections
                if promoted or self.module.frozen:
                    y_cursor += LP_CHIP_GAP_Y * 2
                y_cursor += LP_HEADER_H
                visible = observed[:LP_MAX_VISIBLE]
                overflow_n = max(0, len(observed) - LP_MAX_VISIBLE)
                row_y = y_cursor
                row_x = section_x0
                for tag in visible:
                    label = format_tag_label(tag)
                    text_w = self._lp_chip_text_width(painter, label) \
                        if painter is not None else float(len(label) * 6)
                    chip_w = text_w + 2 * LP_CHIP_PAD_X
                    if row_x + chip_w > section_x1 and row_x > section_x0:
                        row_y += LP_CHIP_H + LP_CHIP_GAP_Y
                        row_x = section_x0
                    rect = QRectF(row_x, row_y, chip_w, LP_CHIP_H)
                    self._lp_chips.append({
                        "rect": rect, "value": tag,
                        "section": "observed", "overflow": False,
                        "label": label,
                    })
                    row_x += chip_w + LP_CHIP_GAP_X
                if overflow_n > 0:
                    label = f"+{overflow_n} more"
                    text_w = self._lp_chip_text_width(painter, label) \
                        if painter is not None else float(len(label) * 6)
                    chip_w = text_w + 2 * LP_CHIP_PAD_X
                    if row_x + chip_w > section_x1 and row_x > section_x0:
                        row_y += LP_CHIP_H + LP_CHIP_GAP_Y
                        row_x = section_x0
                    rect = QRectF(row_x, row_y, chip_w, LP_CHIP_H)
                    self._lp_chips.append({
                        "rect": rect, "value": None,
                        "section": "observed", "overflow": True,
                        "label": label,
                    })
                y_cursor = row_y + LP_CHIP_H

            # Bottom-Pad
            y_cursor += LP_BOTTOM_PAD

            # Section-Höhe = Y-Cursor minus dem Y-Start-Punkt der Section
            section_start_y = MOD_HEADER_H + ports_block_h + LP_SECTION_PAD_TOP
            self._lp_section_h = max(0.0, y_cursor - section_start_y)
            self._lp_signature = self._lp_compute_signature()

        def _paint_lp_section(self, painter: QPainter) -> None:
            """Zeichnet die Living-Patterns-Section unter dem Port-Block.

            Wird aus ``paint()`` aufgerufen. Erwartet dass
            ``_compute_lp_layout(painter)`` JUST BEFORE diesem Call
            aufgerufen wurde (dort wird ``_lp_chips`` aufgebaut).
            """
            if not self._lp_active():
                return
            if not self._lp_chips and not self.module.frozen:
                # Nichts zu zeichnen — auch keine Header
                return

            # Standard-Port-Block-Höhe
            n_ports = max(len(self.module.inputs), len(self.module.outputs), 1)
            ports_block_h = n_ports * MOD_PORT_H
            section_start_y = MOD_HEADER_H + ports_block_h + LP_SECTION_PAD_TOP

            # ── Trenn-Linie zwischen Ports und LP-Section ──
            painter.setPen(QPen(LP_COLOR_OBSERVED, 1.0, Qt.PenStyle.DotLine))
            painter.drawLine(
                QPointF(LP_SIDE_PAD, section_start_y),
                QPointF(MOD_WIDTH - LP_SIDE_PAD, section_start_y),
            )

            # ── Section-Header (PROMOTED, OBSERVED) ──
            #
            # Wir leiten die Header-Y-Positionen aus den ersten Chips
            # jeder Section ab — falls eine Section keinen Chip hat
            # (frozen + leer), zeichnen wir trotzdem den Header an
            # der berechneten Position.
            painter.setFont(QFont("monospace", 7, QFont.Weight.Bold))
            painter.setPen(QPen(LP_SECTION_HDR_COL))

            # Header-Texte mit Frozen-Symbol falls relevant
            promoted_chips = [c for c in self._lp_chips
                              if c["section"] == "promoted"]
            observed_chips = [c for c in self._lp_chips
                              if c["section"] == "observed"]

            if promoted_chips or self.module.frozen:
                if promoted_chips:
                    hdr_y = promoted_chips[0]["rect"].y() - LP_HEADER_H + 2
                else:
                    # frozen but empty
                    hdr_y = section_start_y + 2
                hdr_text = "PROMOTED"
                if self.module.frozen:
                    hdr_text = "❄ FROZEN"
                painter.drawText(
                    QRectF(LP_SIDE_PAD, hdr_y,
                           MOD_WIDTH - 2 * LP_SIDE_PAD, LP_HEADER_H),
                    Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft,
                    hdr_text,
                )

            if observed_chips:
                hdr_y = observed_chips[0]["rect"].y() - LP_HEADER_H + 2
                hdr_text = "OBSERVED"
                if self.module.frozen:
                    hdr_text = "OBSERVED (frozen)"
                # Etwas dimmerer Header für observed
                hdr_color = QColor(LP_SECTION_HDR_COL)
                hdr_color.setAlpha(160)
                painter.setPen(QPen(hdr_color))
                painter.drawText(
                    QRectF(LP_SIDE_PAD, hdr_y,
                           MOD_WIDTH - 2 * LP_SIDE_PAD, LP_HEADER_H),
                    Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft,
                    hdr_text,
                )

            # ── Chips zeichnen ──
            painter.setFont(QFont("monospace", 8, QFont.Weight.Bold))
            for chip in self._lp_chips:
                rect: QRectF = chip["rect"]
                section = chip["section"]
                overflow = chip["overflow"]
                if overflow:
                    bg = LP_COLOR_OVERFLOW
                    fg = LP_TEXT_OVERFLOW
                elif section == "promoted":
                    bg = LP_COLOR_PROMOTED
                    fg = LP_TEXT_PROMOTED
                else:  # observed
                    bg = LP_COLOR_OBSERVED
                    fg = LP_TEXT_OBSERVED

                # Bei frozen=True etwas dimmen damit klar ist „nichts
                # mehr Live"
                if self.module.frozen and not overflow:
                    bg = QColor(bg)
                    bg.setAlpha(180)

                painter.setBrush(QBrush(bg))
                painter.setPen(Qt.PenStyle.NoPen)
                painter.drawRoundedRect(rect, LP_CHIP_RADIUS, LP_CHIP_RADIUS)

                # Text
                painter.setPen(QPen(fg))
                painter.drawText(
                    rect,
                    Qt.AlignmentFlag.AlignCenter,
                    chip["label"],
                )

                # Promoted-Chips bekommen ein subtiles × Symbol rechts oben
                # als Demote-Hint (v.230: Click-Demote ist implementiert,
                # aber v.231 wird's mit Animation und Connection-Cleanup
                # härten). Nur wenn der Chip groß genug ist.
                if section == "promoted" and not overflow and rect.width() > 28:
                    x_painter_color = QColor(fg)
                    x_painter_color.setAlpha(180)
                    painter.setPen(QPen(x_painter_color, 1.2))
                    cx = rect.right() - 4
                    cy = rect.top() + 4
                    sz = 2.5
                    painter.drawLine(
                        QPointF(cx - sz, cy - sz),
                        QPointF(cx + sz, cy + sz),
                    )
                    painter.drawLine(
                        QPointF(cx - sz, cy + sz),
                        QPointF(cx + sz, cy - sz),
                    )

        def _lp_chip_at(self, local_pos: QPointF) -> Optional[dict]:
            """Hit-Test: gibt den Chip an Position ``local_pos`` zurück
            oder ``None``. ``local_pos`` ist in Item-lokalen Koordinaten.
            """
            for chip in self._lp_chips:
                if chip["rect"].contains(local_pos):
                    return chip
            return None

        def mousePressEvent(self, event):
            """Click-Handler. Erst Living-Patterns-Chips prüfen, dann
            an die Standard-Behandlung (Selection/Drag) durchreichen.

            Beim Chip-Hit:
                * Promoted-Chip → demote (Tag aus frozen_tags entfernen)
                * Observed-Chip → promote (Tag in frozen_tags + neuer Port)
                * Overflow-Chip → no-op (zukünftig: tooltip/dialog)

            Die Mutation passiert via ``FluxScene._lp_promote/_lp_demote``
            damit Cable-Cleanup und ``patch_changed.emit()`` koordiniert
            ablaufen. Wenn die Scene unbekannt ist (z.B. headless test),
            fallen wir auf direkten Aufruf der living_patterns-Helper
            zurück.
            """
            if self._lp_active() and self._lp_chips:
                chip = self._lp_chip_at(event.pos())
                if chip is not None:
                    if chip["overflow"]:
                        # v0.0.21.231 — Overflow-Picker-Dialog: zeigt
                        # ALLE observed/promoted Tags in einer
                        # filter-fähigen Liste. Modal damit der User
                        # mehrere Patterns hintereinander einstellen
                        # kann bevor er den Dialog schließt.
                        scene = self.scene()
                        if isinstance(scene, FluxScene):
                            scene._lp_open_picker_dialog(self.module)
                        event.accept()
                        return
                    scene = self.scene()
                    if isinstance(scene, FluxScene):
                        if chip["section"] == "observed":
                            scene._lp_promote(self.module, chip["value"])
                        else:  # promoted
                            scene._lp_demote(self.module, chip["value"])
                    event.accept()
                    return
            super().mousePressEvent(event)

        def boundingRect(self) -> QRectF:
            # v0.0.21.171: Etwas mehr Luft für Aktivitäts-Glow (bis zu 14 px)
            margin = 14
            return QRectF(-margin, -margin,
                          MOD_WIDTH + 2 * margin,
                          self.total_height() + 2 * margin)

        def paint(self, painter: QPainter,
                  option: QStyleOptionGraphicsItem,
                  widget=None) -> None:
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)
            h = self.total_height()
            rect = QRectF(0, 0, MOD_WIDTH, h)

            # v0.0.21.171: Aktivitäts-Glow — atmet mit Audio-Amplitude.
            # Wird vor allem anderen gezeichnet, damit der Glow "um" das
            # Modul herum sichtbar ist. Nur wenn activity > Schwellenwert,
            # damit ruhige Module nicht permanent leuchten.
            if self.activity > 0.02:
                glow_color = QColor(self.color)
                glow_color.setAlpha(int(160 * min(1.0, self.activity)))
                glow_pen_width = MOD_BORDER + 4.0 + 6.0 * self.activity
                painter.setPen(QPen(glow_color, glow_pen_width))
                painter.setBrush(Qt.BrushStyle.NoBrush)
                painter.drawRoundedRect(rect, MOD_RADIUS, MOD_RADIUS)

            # Modul-Hintergrund (sehr dunkel, leicht transparent)
            bg = QColor(20, 24, 30, 230)
            painter.setBrush(QBrush(bg))
            border_color = self.color if not self.isSelected() else QColor("#ffffff")
            pen = QPen(border_color, MOD_BORDER + (1.0 if self.isSelected() else 0.0))
            painter.setPen(pen)
            painter.drawRoundedRect(rect, MOD_RADIUS, MOD_RADIUS)

            # Header-Streifen oben (god-color, sehr leicht transparent).
            # Wenn Aktivität hoch ist, wird der Header heller (das ist das „Feed-Licht").
            header_rect = QRectF(0, 0, MOD_WIDTH, MOD_HEADER_H)
            grad = QLinearGradient(0, 0, MOD_WIDTH, 0)
            base_alpha = 60 + int(80 * self.activity)  # 60..140 je nach Aktivität
            tail_alpha = 20 + int(40 * self.activity)  # 20..60
            c1 = QColor(self.color); c1.setAlpha(base_alpha)
            c2 = QColor(self.color); c2.setAlpha(tail_alpha)
            grad.setColorAt(0.0, c1)
            grad.setColorAt(1.0, c2)
            painter.setBrush(QBrush(grad))
            painter.setPen(Qt.PenStyle.NoPen)
            path = QPainterPath()
            path.addRoundedRect(header_rect, MOD_RADIUS, MOD_RADIUS)
            painter.drawPath(path)

            # v0.0.21.171: „Feed-Licht" — kleiner heller Punkt rechts im Header
            # der mit der Aktivität pulsiert. Klar erkennbar dass Audio durchläuft.
            if self.activity > 0.02:
                led_color = QColor(self.color).lighter(160)
                led_color.setAlpha(int(255 * min(1.0, self.activity * 1.5)))
                painter.setBrush(QBrush(led_color))
                painter.setPen(Qt.PenStyle.NoPen)
                led_radius = 3.0 + 2.0 * self.activity
                painter.drawEllipse(
                    QPointF(MOD_WIDTH - 14, MOD_HEADER_H / 2),
                    led_radius, led_radius,
                )

            # Header-Text: Glyphe + Modul-Name
            painter.setPen(QPen(self.color))
            font = QFont("monospace", 11, QFont.Weight.Bold)
            painter.setFont(font)
            glyph = self.god.glyph if self.god else "?"
            painter.drawText(
                QRectF(MOD_PADDING, 0, MOD_WIDTH - 2 * MOD_PADDING, MOD_HEADER_H),
                Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft,
                f"{glyph}  {self.module.god}",
            )
            painter.setPen(QPen(TEXT_SECONDARY))
            painter.setFont(QFont("monospace", 9))
            painter.drawText(
                QRectF(MOD_PADDING, 0, MOD_WIDTH - 2 * MOD_PADDING, MOD_HEADER_H),
                Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignRight,
                self.module.kind,
            )

            # v0.0.21.203 — Saga.Magic-Body-Render-Hook
            # Wir zeichnen die Punktwolke VOR den Port-Labels, damit
            # die Labels lesbar darüber liegen. Body-Rect ist die
            # ganze Innenfläche unter dem Header (links/rechts mit
            # leicht eingerücktem Rand für Port-Kreise).
            if self._is_saga_magic:
                self._paint_saga_body(painter)

            # Port-Labels — neben jedem Port-Kreis
            # v0.0.21.195: bei UI-Widget-Modulen weglassen — das eingebettete
            # Widget IST die User-Eingabe; Output-Port nur als Verbindungs-Anker.
            if self._is_ui_widget:
                return
            painter.setPen(QPen(TEXT_PRIMARY))
            painter.setFont(QFont("monospace", 9))
            y = MOD_HEADER_H + MOD_PORT_H / 2
            for p in self.module.inputs:
                painter.drawText(
                    QRectF(PORT_RADIUS + 4, y - MOD_PORT_H / 2,
                           MOD_WIDTH / 2, MOD_PORT_H),
                    Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft,
                    p.label,
                )
                y += MOD_PORT_H
            y = MOD_HEADER_H + MOD_PORT_H / 2
            for p in self.module.outputs:
                painter.drawText(
                    QRectF(MOD_WIDTH / 2, y - MOD_PORT_H / 2,
                           MOD_WIDTH / 2 - PORT_RADIUS - 4, MOD_PORT_H),
                    Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignRight,
                    p.label,
                )
                y += MOD_PORT_H

            # v0.0.21.230 — Living Patterns Chip-Strip unter den Ports.
            # Layout wird hier mit aktivem painter neu berechnet (für
            # exakte fontMetrics) und direkt darunter gezeichnet.
            # NICHTS-KAPUTT: nur wenn dynamic_outputs gesetzt — alle
            # anderen Module sind unverändert vom v.229-Verhalten.
            if self._lp_active():
                # Höhe vor- und nach-update vergleichen — wenn sich die
                # LP-Section-Höhe geändert hat (z.B. neuer Tag kam rein
                # und das Modul muss höher werden), `prepareGeometryChange`
                # aufrufen damit boundingRect() für die Scene neu indexiert
                # wird (sonst zeichnet Qt teils über die alte BBox hinaus).
                old_h = self._lp_section_h
                self._compute_lp_layout(painter)
                if abs(self._lp_section_h - old_h) > 0.5:
                    # geometry change — prepare nachträglich (Qt erlaubt
                    # das auch innerhalb von paint() ohne Crash, aber wir
                    # planen den nächsten Repaint)
                    self.prepareGeometryChange()
                self._paint_lp_section(painter)

        def itemChange(self, change, value):
            # Sync zurück ins Datenmodell wenn sich die Position ändert
            if change == QGraphicsItem.GraphicsItemChange.ItemPositionHasChanged:
                self.module.position = (value.x(), value.y())
                # Verbindungen müssen neu gezeichnet werden
                scene = self.scene()
                if isinstance(scene, FluxScene):
                    scene._update_cables_for_module(self.module.id)
            return super().itemChange(change, value)


    class CableItem(QGraphicsPathItem):
        """Eine Verbindungslinie zwischen zwei Ports.

        Zeichnet eine Bezier-Kurve mit Glow-Effekt + Pulse-Punkte +
        animierter Flow-Strich. Klickbar an JEDER Stelle der Bezier-
        Kurve (Hit-Box ~ 12 px breit, in `shape()` definiert).

        Disconnect-Animation: bei `start_disconnect()` läuft der
        Cable-Alpha über 200ms auf 0 ab + die Pulse-Punkte fliegen
        auseinander. Danach signalisiert das Cable-Item dem Scene
        dass es entfernt werden soll.
        """

        def __init__(self, connection: Connection,
                     source_port: PortItem, target_port: PortItem):
            super().__init__()
            self.connection = connection
            self.source_port = source_port
            self.target_port = target_port
            self.setZValue(-1)  # hinter den Modulen
            self._color = source_port.brush().color()
            self.phase = 0.0           # Pulse-Position [0..1]
            self.flow_phase = 0.0      # Flow-Strich-Animation [0..1]
            self.disconnect_progress = 0.0  # 0=normal, 1=fully gone
            self._disconnecting = False
            # CableItem ist klickbar — verarbeitet eigene mouse-Events
            self.setAcceptHoverEvents(True)
            self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsSelectable, True)
            self._hovered = False
            self._update_path()

        def shape(self) -> QPainterPath:
            """Hit-Detection: erweitere die Pfad-Linie auf eine ~14px-breite
            Hit-Region um Klicks an jeder Stelle des Cables zu fangen."""
            stroker = QPainterPathStroker()
            stroker.setWidth(14.0)
            stroker.setCapStyle(Qt.PenCapStyle.RoundCap)
            return stroker.createStroke(self.path())

        def hoverEnterEvent(self, event):
            self._hovered = True
            self.update()
            super().hoverEnterEvent(event)

        def hoverLeaveEvent(self, event):
            self._hovered = False
            self.update()
            super().hoverLeaveEvent(event)

        def start_disconnect(self) -> None:
            """Beginne die Disconnect-Animation. Scene fragt regelmäßig
            via `disconnect_progress` ob das Cable entsorgt werden kann."""
            self._disconnecting = True

        def _update_path(self) -> None:
            s = self.source_port.scene_pos()
            t = self.target_port.scene_pos()
            path = QPainterPath()
            path.moveTo(s)
            # Horizontale Bezier — Tangenten in horizontaler Richtung
            # (typisch für Patch-Cables in Pd/Reaktor/Bitwig)
            dx = (t.x() - s.x()) * 0.5
            c1 = QPointF(s.x() + max(60, dx), s.y())
            c2 = QPointF(t.x() - max(60, dx), t.y())
            path.cubicTo(c1, c2, t)
            self.setPath(path)

        def paint(self, painter: QPainter,
                  option: QStyleOptionGraphicsItem,
                  widget=None) -> None:
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)
            # Disconnect-Animation: Alpha multiplier
            disc_alpha = 1.0 - self.disconnect_progress
            # Hover-Boost: helleres Cable wenn Cursor drüber
            hover_boost = 1.3 if self._hovered else 1.0
            # Selection-Highlight: gelber Außenrahmen wenn selektiert
            if self.isSelected():
                sel_pen = QPen(QColor("#fbbf24"), CABLE_GLOW_WIDTH * 1.5,
                               Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap)
                painter.setPen(sel_pen)
                painter.drawPath(self.path())
            # Glow-Schicht: dickere, sehr transparente Linie darunter
            glow_color = QColor(self._color)
            glow_color.setAlpha(int(40 * disc_alpha * hover_boost))
            painter.setPen(QPen(glow_color, CABLE_GLOW_WIDTH,
                                Qt.PenStyle.SolidLine,
                                Qt.PenCapStyle.RoundCap))
            painter.drawPath(self.path())
            # Haupt-Linie
            main_color = QColor(self._color)
            main_color.setAlpha(int(180 * disc_alpha * hover_boost))
            painter.setPen(QPen(main_color, CABLE_WIDTH,
                                Qt.PenStyle.SolidLine,
                                Qt.PenCapStyle.RoundCap))
            painter.drawPath(self.path())
            # Flow-Strich auf der Mittellinie (animierte Strichelung)
            self._draw_flow_dashes(painter, disc_alpha)
            # Pulse-Punkte: zeichne mehrere wandernde Glanzpunkte
            self._draw_pulses(painter, disc_alpha)

        def _draw_flow_dashes(self, painter: QPainter, disc_alpha: float) -> None:
            """Animierte gestrichelte Linie OBEN auf der Bezier — der
            klassische 'Strom fließt'-Effekt aus Reaktor/Pd."""
            path = self.path()
            length = path.length()
            if length <= 0:
                return
            # Kurze Striche (8px) mit großen Lücken (16px) — das ergibt
            # eine erkennbare Flow-Animation
            dash_len = 8.0
            gap_len  = 16.0
            cycle    = dash_len + gap_len
            # flow_phase ∈ [0..1] verschiebt den Anfang der Striche
            offset_px = self.flow_phase * cycle
            # Wir zeichnen die Striche per pointAtPercent (langsam aber sicher)
            dash_color = QColor("#ffffff")
            dash_color.setAlpha(int(110 * disc_alpha))
            painter.setPen(QPen(dash_color, 1.2,
                                Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
            # Iteriere über die Pfad-Länge in cycle-Schritten
            pos = -offset_px  # negativ damit der erste Strich „eintaucht"
            while pos < length:
                start_px = max(0.0, pos)
                end_px   = min(length, pos + dash_len)
                if end_px > start_px:
                    p1 = path.pointAtPercent(start_px / length)
                    p2 = path.pointAtPercent(end_px   / length)
                    painter.drawLine(p1, p2)
                pos += cycle

        def _draw_pulses(self, painter: QPainter, disc_alpha: float = 1.0) -> None:
            path = self.path()
            length = path.length()
            if length <= 0:
                return
            painter.setPen(Qt.PenStyle.NoPen)
            # Anzahl Pulse: ein Pulse pro PULSE_INTERVAL_PX
            n = max(1, int(length / PULSE_INTERVAL_PX))
            # Während Disconnect: Pulse fliegen entlang Cable nach außen
            # (Effekt: Strom „verpufft")
            if self._disconnecting:
                # Pulse-Größe wächst mit disc_progress
                size_mult = 1.0 + self.disconnect_progress * 2.0
            else:
                size_mult = 1.0
            for i in range(n):
                # Verteile Pulse gleichmäßig + animiere mit phase
                t_frac = ((i / n) + self.phase) % 1.0
                pt = path.pointAtPercent(t_frac)
                # Glow-Kreis (transparent)
                glow = QRadialGradient(pt, PULSE_SIZE * 2.5 * size_mult)
                c = QColor(self._color)
                c.setAlpha(int(140 * disc_alpha))
                glow.setColorAt(0.0, c)
                c2 = QColor(self._color); c2.setAlpha(0)
                glow.setColorAt(1.0, c2)
                painter.setBrush(QBrush(glow))
                painter.drawEllipse(pt, PULSE_SIZE * 2.5 * size_mult,
                                    PULSE_SIZE * 2.5 * size_mult)
                # Innerer heller Kreis
                inner = QColor("#ffffff")
                inner.setAlpha(int(255 * disc_alpha))
                painter.setBrush(QBrush(inner))
                painter.drawEllipse(pt, PULSE_SIZE * 0.6, PULSE_SIZE * 0.6)


    class DragCableItem(QGraphicsPathItem):
        """Temporäres Cable während des Verbindens — folgt der Maus.

        Wird bei mousePressEvent auf einem OUTPUT-Port erzeugt und bei
        mouseReleaseEvent wieder entfernt. Hat dieselbe Bezier-Optik
        wie ein echtes CableItem aber gestrichelt + halbtransparent
        damit man sofort sieht: das ist ein Vorschau-Cable, noch nicht
        bestätigt."""

        def __init__(self, source_port: PortItem):
            super().__init__()
            self.source_port = source_port
            self._color = source_port.brush().color()
            self.setZValue(-0.5)  # zwischen Cable und Module
            self._cursor_pos = source_port.scene_pos()
            self._update_path()

        def update_to_cursor(self, scene_pos: QPointF) -> None:
            """Wird bei jedem mouseMove aufgerufen."""
            self._cursor_pos = scene_pos
            self._update_path()

        def _update_path(self) -> None:
            s = self.source_port.scene_pos()
            t = self._cursor_pos
            path = QPainterPath()
            path.moveTo(s)
            dx = (t.x() - s.x()) * 0.5
            c1 = QPointF(s.x() + max(60, dx), s.y())
            c2 = QPointF(t.x() - max(60, dx), t.y())
            path.cubicTo(c1, c2, t)
            self.setPath(path)

        def paint(self, painter: QPainter,
                  option: QStyleOptionGraphicsItem,
                  widget=None) -> None:
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)
            # Glow
            glow_color = QColor(self._color); glow_color.setAlpha(60)
            painter.setPen(QPen(glow_color, CABLE_GLOW_WIDTH,
                                Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
            painter.drawPath(self.path())
            # Hauptlinie gestrichelt — Vorschau-Optik
            main_color = QColor(self._color); main_color.setAlpha(220)
            pen = QPen(main_color, CABLE_WIDTH + 0.5,
                       Qt.PenStyle.DashLine, Qt.PenCapStyle.RoundCap)
            pen.setDashPattern([4.0, 3.0])
            painter.setPen(pen)
            painter.drawPath(self.path())
            # Cursor-End-Marker: kleiner pulsierender Kreis
            tip = QColor("#ffffff"); tip.setAlpha(220)
            painter.setBrush(QBrush(tip))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawEllipse(self._cursor_pos, 5.0, 5.0)
            # Außerer Glow-Ring um den Cursor
            ring_glow = QRadialGradient(self._cursor_pos, 14.0)
            c = QColor(self._color); c.setAlpha(150)
            ring_glow.setColorAt(0.0, c)
            c2 = QColor(self._color); c2.setAlpha(0)
            ring_glow.setColorAt(1.0, c2)
            painter.setBrush(QBrush(ring_glow))
            painter.drawEllipse(self._cursor_pos, 14.0, 14.0)


    class FluxScene(QGraphicsScene):
        """Die QGraphicsScene die einen Patch verwaltet."""

        # Signale für die UI (z.B. Properties-Panel updaten)
        module_selected = pyqtSignal(str)   # module.id
        patch_changed   = pyqtSignal()      # Patch-Struktur hat sich geändert
                                             # (Modul/Connection add/remove) →
                                             # triggert Engine-Resync
        # v0.0.21.196: separates Signal für reine Wert-Änderungen.
        # Wird beim UI-Modul-Drehen gefeuert. Triggert KEINEN Engine-
        # Resync — nur Dirty-Flag fürs Save-System. Der Engine-Param-
        # Update läuft über `set_module_param` (D-1-Pfad).
        param_only_changed = pyqtSignal()

        def __init__(self, patch: Optional[Patch] = None, parent=None):
            super().__init__(parent)
            self.patch = patch or Patch()
            self.module_items: dict[str, ModuleItem] = {}
            self.cable_items: dict[str, CableItem] = {}
            self.setBackgroundBrush(QBrush(CANVAS_BG))
            self.setSceneRect(-2000, -2000, 4000, 4000)
            self._build_from_patch()
            # Pulse-Animation
            self._pulse_timer = QTimer()
            self._pulse_timer.timeout.connect(self._tick_pulses)
            self._pulse_timer.start(50)  # 20 Hz
            # Connection-Drag-State (v0.0.21.181)
            self._dragging_from: Optional[PortItem] = None
            self._drag_cable: Optional[DragCableItem] = None
            # Disconnect-Animation: Liste der Cables die gerade entfernt
            # werden. Jedes Cable hat disconnect_progress ∈ [0..1] das pro
            # Tick um DISCONNECT_STEP wächst. Bei >= 1.0 wird das Cable
            # endgültig aus Scene + Patch entfernt.
            self._disconnecting_cables: list[CableItem] = []
            # Cluster-Layout-Animation: pro ModuleItem (target_x, target_y, t).
            # Bei jedem Tick lerpt die Position auf das Ziel zu (lerp = 0.18).
            self._cluster_targets: dict[str, tuple[float, float]] = {}

        # ─── Aufbau ──────────────────────────────────────────────

        def set_patch(self, patch: Patch) -> None:
            # v0.0.21.198 Hotfix: alte Sigil-Widgets müssen ihre Animation-
            # Subscriptions loswerden BEVOR die ModuleItems gelöscht werden.
            # Sonst hält die zentrale AnimationEngine-Tick-Loop weiter
            # widget-update()-Calls auf gelöschte Qt-Objekte und logged
            # Warnings/RuntimeErrors. closeEvent() wird beim QGraphics-
            # ProxyWidget-Cleanup nicht zuverlässig getriggert, daher
            # cleanen wir hier explizit pro ModuleItem.
            try:
                from pydaw.flux.animation_engine import get_animation_engine
                eng = get_animation_engine()
                for mi in list(self.module_items.values()):
                    mod = getattr(mi, "module", None)
                    if mod is None:
                        continue
                    mod_id = getattr(mod, "id", None)
                    if not mod_id:
                        continue
                    try:
                        eng.unsubscribe_prefix(f"{mod_id}::")
                    except Exception:
                        pass
            except Exception as e:
                logger.debug("[FLUX-UI] sigil cleanup pre-clear failed: %s", e)

            # v0.0.21.203: Saga-Cleanup analog Sigil-Cleanup. Vor dem
            # Patch-Wechsel werden alle Saga-Subscriptions vom
            # SagaRendererProxy entfernt — sonst wandert die Sampler-
            # Instance durch den Patch-Wechsel und der Proxy hält
            # Module-IDs die nicht mehr existieren.
            try:
                from pydaw.flux.saga.renderer_proxy import (
                    get_saga_renderer_proxy,
                )
                proxy = get_saga_renderer_proxy()
                for mi in list(self.module_items.values()):
                    if getattr(mi, "_is_saga_magic", False):
                        try:
                            proxy.unsubscribe(str(mi.module.id))
                        except Exception:
                            pass
            except Exception as e:
                logger.debug("[FLUX-SAGA] cleanup pre-clear failed: %s", e)

            self.patch = patch
            self.clear()
            self.module_items.clear()
            self.cable_items.clear()
            self._build_from_patch()

        def _build_from_patch(self) -> None:
            for m in self.patch.modules:
                self._add_module_item(m)
            for c in self.patch.connections:
                self._add_cable_item(c)

        def _add_module_item(self, module: Module) -> ModuleItem:
            item = ModuleItem(module)
            self.addItem(item)
            self.module_items[module.id] = item
            # v0.0.21.195: UI-Widget-Module — Signal mit Bridge verdrahten
            self._wire_ui_widget_signals(item)
            return item

        def _wire_ui_widget_signals(self, item: "ModuleItem") -> None:
            """v0.0.21.195: Verbindet das embedded UI-Widget eines Frigg-
            Moduls mit der UiModuleBridge.

            Bei jeder Wert-Änderung im Widget:
            1. Patch wird als dirty markiert (`patch_changed`)
            2. UiModuleBridge dispatcht den Wert an alle ausgehenden
               Connections (→ set_module_param am Ziel-DSP-Modul)

            Bei Comment-Widgets: keine Wert-Änderung, nur Text-Edit
            (wird in `extra["text"]` gespeichert).
            """
            widget = getattr(item, "embedded_widget", None)
            if widget is None:
                return
            mod_id = item.module.id
            kind = (item.module.kind or "").strip()

            # Knob, Slider, Toggle, Bang, NumberBox: alle haben value_changed
            value_changed_signal = getattr(widget, "value_changed", None)
            if value_changed_signal is not None:
                def _on_value_changed(v: float, _mid=mod_id) -> None:
                    self._handle_ui_value_changed(_mid, float(v))
                try:
                    value_changed_signal.connect(_on_value_changed)
                except Exception as e:
                    logger.debug("[FLUX-UI] connect value_changed failed: %s", e)

            # Comment-Widget: text_changed
            text_changed_signal = getattr(widget, "text_changed", None)
            if text_changed_signal is not None and kind == "Comment":
                def _on_text_changed(text: str, _mid=mod_id) -> None:
                    mod = self.patch.get_module(_mid) if self.patch else None
                    if mod is not None:
                        mod.extra["text"] = str(text)
                        self.patch_changed.emit()
                try:
                    text_changed_signal.connect(_on_text_changed)
                except Exception as e:
                    logger.debug("[FLUX-UI] connect text_changed failed: %s", e)

        def _auto_adapt_ui_widget_range(
            self, src_mi: "ModuleItem", target_port: Port,
        ) -> None:
            """v0.0.21.196: Übernimmt bei Frigg-Source die Target-Port-Range.

            Wenn z.B. ein Frigg.Knob (default 0..1) mit Bragi.SineOsc.Frequency
            (20..20000) verbunden wird, setzen wir Knob-Range automatisch
            auf 20..20000 und Wert auf den Target-Default. Das macht
            den Knob sofort musikalisch nutzbar — ohne dass der User
            in den PropertiesPanel muss.

            Heuristik: nur anpassen wenn der Knob noch in seinem
            "neutralen" Default-Range (0..1) steht. Wenn der User
            schon explizit eine Range gesetzt hat, lassen wir es.
            """
            if not getattr(src_mi, "_is_ui_widget", False):
                return
            mod = src_mi.module
            # Nur wertsendende UI-Widgets — nicht Comment etc.
            if "value" not in mod.params:
                return
            cur_min = float(mod.params.get("minimum", 0.0))
            cur_max = float(mod.params.get("maximum", 1.0))
            # Heuristik: "neutraler" Default-Range = exakt 0..1
            is_neutral = (cur_min == 0.0 and cur_max == 1.0)
            if not is_neutral:
                return  # User hat schon was eingestellt — nicht anfassen

            tgt_min = getattr(target_port, "minimum", None)
            tgt_max = getattr(target_port, "maximum", None)
            tgt_default = getattr(target_port, "default", None)
            if tgt_min is None or tgt_max is None or tgt_max <= tgt_min:
                return  # Ziel-Port hat keine sinnvolle Range

            # Range übernehmen
            mod.params["minimum"] = float(tgt_min)
            mod.params["maximum"] = float(tgt_max)
            if tgt_default is not None:
                mod.params["default"] = float(tgt_default)
                mod.params["value"] = float(tgt_default)
            else:
                # Mitte als sicherer Default
                mid = (float(tgt_min) + float(tgt_max)) / 2.0
                mod.params["default"] = mid
                mod.params["value"] = mid

            # Embedded Widget mit-aktualisieren (ohne Echo-Loop-Signal)
            widget = getattr(src_mi, "embedded_widget", None)
            if widget is None:
                return
            try:
                # AnimatedKnob, SliderWidget, NumberBoxWidget haben alle
                # _minimum/_maximum/_default Felder. Wir müssen sie low-
                # level anpassen weil set_value(emit=False) den Range
                # nicht ändert. AnimatedKnob hat _value_target und
                # _value_displayed (Lerp), die anderen haben _value.
                if hasattr(widget, "_minimum"):
                    widget._minimum = float(mod.params["minimum"])
                if hasattr(widget, "_maximum"):
                    widget._maximum = float(mod.params["maximum"])
                if hasattr(widget, "_default"):
                    widget._default = float(mod.params["default"])
                if hasattr(widget, "set_value"):
                    widget.set_value(float(mod.params["value"]),
                                      emit_signal=False)
                # Tooltip aktualisieren falls das Widget eine Methode hat
                tooltip_fn = getattr(widget, "_tooltip", None)
                if callable(tooltip_fn):
                    try:
                        widget.setToolTip(tooltip_fn())
                    except Exception:
                        pass
                widget.update()
            except Exception as e:
                logger.debug("[FLUX-UI] widget range adapt failed: %s", e)

            logger.info(
                "[FLUX-UI] %s.%s range auto-adapted to target port: %g..%g (default %g)",
                mod.god, mod.kind,
                mod.params["minimum"], mod.params["maximum"],
                mod.params["default"],
            )

        def _handle_ui_value_changed(self, module_id: str, value: float) -> None:
            """Slot: ein UI-Widget hat seinen Wert geändert.

            v0.0.21.196: NICHT mehr `patch_changed` feuern — das würde
            bei jeder Knob-Drehung einen kompletten `FluxSyncPatch`-IPC
            triggern (siehe `flux_main_widget._on_patch_changed`), was
            die GIL bei 60+ Hz Drehrate festfrisst. Stattdessen feuern
            wir das neue `param_only_changed`-Signal — das markiert nur
            den Dirty-State, ohne Engine-Resync. Der eigentliche Wert-
            Update geht direkt via `set_module_param` durch die Bridge.
            """
            try:
                from pydaw.services.ui_module_bridge import get_ui_module_bridge
                get_ui_module_bridge().handle_ui_value_changed(
                    self.patch, module_id, float(value),
                )
            except Exception as e:
                logger.debug("[FLUX-UI] bridge dispatch failed: %s", e)
            # v0.0.21.196: param_only_changed statt patch_changed → kein full-sync
            self.param_only_changed.emit()

        def _add_cable_item(self, connection: Connection) -> Optional[CableItem]:
            src_mod = self.module_items.get(connection.source_module)
            tgt_mod = self.module_items.get(connection.target_module)
            if src_mod is None or tgt_mod is None:
                return None
            src_port = next((p for p in src_mod.port_items
                             if p.port.name == connection.source_port
                             and p.port.direction == PortDirection.OUTPUT), None)
            tgt_port = next((p for p in tgt_mod.port_items
                             if p.port.name == connection.target_port
                             and p.port.direction == PortDirection.INPUT), None)
            if src_port is None or tgt_port is None:
                return None
            cable = CableItem(connection, src_port, tgt_port)
            self.addItem(cable)
            self.cable_items[connection.id] = cable
            return cable

        # ─── Modifikation ────────────────────────────────────────

        def add_module(self, module: Module, position: QPointF | None = None) -> ModuleItem:
            if position is not None:
                module.position = (position.x(), position.y())
            self.patch.add_module(module)
            item = self._add_module_item(module)
            self.patch_changed.emit()
            return item

        def remove_selected(self) -> None:
            for item in list(self.selectedItems()):
                if isinstance(item, ModuleItem):
                    mid = item.module.id
                    # v0.0.21.203: Saga-Unsubscribe vor dem Item-Destroy
                    # damit der Proxy die Sampler-Instance freigibt.
                    if getattr(item, "_is_saga_magic", False):
                        try:
                            item._saga_unsubscribe()
                        except Exception as e:
                            logger.debug("[FLUX-SAGA] unsub on remove failed: %s", e)
                    # Cascade: passende Cables zuerst entfernen
                    to_rm = [cid for cid, c in self.cable_items.items()
                             if c.connection.source_module == mid
                             or c.connection.target_module == mid]
                    for cid in to_rm:
                        self.removeItem(self.cable_items[cid])
                        del self.cable_items[cid]
                    self.removeItem(item)
                    del self.module_items[mid]
                    self.patch.remove_module(mid)
            self.patch_changed.emit()

        def _update_cables_for_module(self, module_id: str) -> None:
            for c in self.cable_items.values():
                if (c.connection.source_module == module_id
                        or c.connection.target_module == module_id):
                    c._update_path()

        # ─── v0.0.21.230 — Living Patterns Coordination ───────────

        def _lp_promote(self, module: Module, tag_value, *, _record: bool = True) -> None:
            """User klickte einen Observed-Chip → Promote.

            * Rufe living_patterns.promote_tag → Module mutiert
              (frozen_tags + neuer Output-Port).
            * ModuleItem-Ports neu aufbauen (PortItem für den neuen
              Port erzeugen + Layout aktualisieren).
            * Repaint triggern.
            * patch_changed-Signal feuern (für Engine-Sync und
              Project-Dirty-Flag).
            * v.231: Aktion auf den Undo-Stack legen (außer wenn aus
              Undo/Redo selbst aufgerufen — dann ``_record=False``).
            """
            try:
                from pydaw.flux.living_patterns import (
                    promote_tag, canonical_tag,
                )
            except Exception as e:
                logger.warning("[LP] promote import failed: %s", e)
                return
            new_port = promote_tag(module, tag_value)
            if new_port is None:
                # Schon promoted oder Cap erreicht — kein Repaint nötig
                return
            if _record:
                # Wir speichern den kanonisierten Wert damit Undo
                # exakt das gleiche Tag findet
                self._lp_record("promote", module.id, canonical_tag(tag_value))
            self._lp_rebuild_ports(module)
            self.patch_changed.emit()

        def _lp_demote(self, module: Module, tag_value, *, _record: bool = True) -> None:
            """User klickte einen Promoted-Chip → Demote.

            v0.0.21.231 — Demote-Animation:
                * Cables die zum entfernten ``pat_<idx>``-Port führen
                  werden in die existing 200ms-Cable-Disconnect-Animation
                  überführt (statt sofort gelöscht).
                * Patch-Modell wird sofort aktualisiert (frozen_tags +
                  outputs entfernt, nachfolgende pat_* re-numbered) —
                  das Save/Render-Verhalten ist also sofort korrekt,
                  nur die VISUELLE Disconnect-Animation läuft 200ms.
                * Cable-Connection wird sofort aus ``patch.connections``
                  entfernt (das CableItem behält seine eigene Kopie
                  in ``cable.connection`` für die Anim-Phase). Beim
                  ``_finalize_cable_removal`` ist ``patch.remove_connection``
                  ein no-op weil schon entfernt.

            Re-numbered Connections (pat_(N+1) → pat_N) werden weiterhin
            in-place mit-aktualisiert — keine Animation, sie bleiben
            sichtbar.
            """
            try:
                from pydaw.flux.living_patterns import (
                    demote_tag, _pat_port_name, canonical_tag,
                )
            except Exception as e:
                logger.warning("[LP] demote import failed: %s", e)
                return

            # 1) Index des Tags VOR dem Demote ermitteln
            promoted_before = list(
                module.frozen_tags.get("rune_in", [])
            )
            target_canon = canonical_tag(tag_value)
            target_idx = -1
            for i, v in enumerate(promoted_before):
                if canonical_tag(v) == target_canon:
                    target_idx = i
                    break
            if target_idx < 0:
                return

            if _record:
                # v.231: Undo-Stack-Eintrag VOR dem Mutate (damit Undo
                # nachher das richtige Tag wiederherstellen kann)
                from pydaw.flux.living_patterns import canonical_tag
                self._lp_record(
                    "demote", module.id, canonical_tag(tag_value),
                )

            removed_port_name = _pat_port_name(target_idx)

            # 2) Cables sammeln die animiert raus müssen
            cables_to_animate: list[CableItem] = []
            for cable in list(self.cable_items.values()):
                conn = cable.connection
                if (conn.source_module == module.id
                        and conn.source_port == removed_port_name):
                    cables_to_animate.append(cable)

            # 3) Patch-Connections für die animierten Cables sofort
            #    aus dem Patch-Modell entfernen — dann ist Save/Render
            #    konsistent. Der CableItem.connection bleibt gültig
            #    (separater Reference) für die Anim-Phase.
            cable_ids_animating = {c.connection.id for c in cables_to_animate}
            self.patch.connections = [
                c for c in self.patch.connections
                if c.id not in cable_ids_animating
            ]

            # 4) Demote im Modell ausführen (mutiert frozen_tags +
            #    outputs + re-numbered nachfolgende pat_*-Ports)
            ok = demote_tag(module, tag_value)
            if not ok:
                return

            # 5) Re-Numbering für Connections nachziehen — alle pat_*
            #    Connections deren Index größer als target_idx war
            #    müssen um -1 verschoben werden. (Nur die, die NICHT
            #    animiert weg-fade'n.)
            for cable in self.cable_items.values():
                conn = cable.connection
                if conn.id in cable_ids_animating:
                    continue
                if conn.source_module != module.id:
                    continue
                if not conn.source_port.startswith("pat_"):
                    continue
                try:
                    old_idx = int(conn.source_port.split("_", 1)[1])
                except ValueError:
                    continue
                if old_idx > target_idx:
                    new_name = _pat_port_name(old_idx - 1)
                    conn.source_port = new_name

            # 6) Disconnect-Animation für die zu entfernenden Cables
            #    starten. Schnellere Geschwindigkeit als der Default
            #    (5 ticks×0.05 = 250ms) damit es responsive wirkt;
            #    siehe `_disconnect_step_for` im _tick_pulses.
            for cable in cables_to_animate:
                if not cable._disconnecting:
                    cable.start_disconnect()
                    # Markiere dieses Cable als „LP-Demote" damit der
                    # Tick einen schnelleren Step nutzt (200ms statt 1s)
                    setattr(cable, "_lp_demote_anim", True)
                    self._disconnecting_cables.append(cable)

            # 7) ModuleItem-Ports neu aufbauen + verbleibende Cables
            #    re-routen
            self._lp_rebuild_ports(module)
            self._update_cables_for_module(module.id)
            self.patch_changed.emit()

        def _lp_rebuild_ports(self, module: Module) -> None:
            """Baut die PortItems eines ModuleItems nach Living-Patterns-
            Mutation neu auf. Der Sub-Item-Tree wird vollständig
            verworfen; vorhandene Cable-Verbindungen behalten ihre
            Connection-Objekte und werden nach dem Rebuild anhand der
            Port-Position-Lookup-Logik korrekt gezeichnet (CableItem
            ruft module_item.get_port_item_by_name() bei
            ``_update_path``).

            v.230 Note: Wir bauen die ganze Item-Geometrie neu damit die
            zusätzliche Höhe (LP-Section + neue Port-Reihen) konsistent
            sind. Das ist günstiger als selektives Hinzufügen einzelner
            Items, da PortItem-Y-Positionen sowieso vom Output-Index
            abhängen.
            """
            mi = self.module_items.get(module.id)
            if mi is None:
                return
            # Alte PortItems entfernen
            for pi in list(mi.port_items):
                try:
                    if pi.scene() is not None:
                        self.removeItem(pi)
                    pi.setParentItem(None)
                except Exception:
                    pass
            mi.port_items.clear()
            # Neu aufbauen
            mi.prepareGeometryChange()
            mi._build_ports()
            # LP-Layout invalidieren — wird im nächsten paint() neu berechnet
            mi._lp_chips = []
            mi._lp_section_h = 0.0
            mi._lp_signature = ()
            mi.update()
            # Cables aktualisieren (Endpunkte können sich verschoben haben)
            self._update_cables_for_module(module.id)

        def _lp_set_frozen(self, module: Module, frozen: bool) -> None:
            """Properties-Panel ❄ Toggle. Setzt ``module.frozen`` und
            triggert Repaint des entsprechenden ModuleItems.

            Wenn ``frozen=True``: der Renderer hört auf, observed_tags
            zu schreiben (siehe audio_preview._gather_inputs Hook).
            Existierende observed_tags bleiben sichtbar damit der User
            sie noch manuell promoten kann.
            """
            if not getattr(module, "dynamic_outputs", False):
                return
            module.frozen = bool(frozen)
            mi = self.module_items.get(module.id)
            if mi is not None:
                mi._lp_chips = []
                mi._lp_section_h = 0.0
                mi._lp_signature = ()
                mi.prepareGeometryChange()
                mi.update()
            self.patch_changed.emit()

        def _lp_snapshot(self, module: Module) -> int:
            """Properties-Panel 📸 Snapshot. Promotet ALLE observed_tags
            in einem Rutsch zu Patterns.

            Gibt die Anzahl der neu hinzugefügten Patterns zurück.
            """
            try:
                from pydaw.flux.living_patterns import (
                    snapshot_observed_to_frozen,
                )
            except Exception as e:
                logger.warning("[LP] snapshot import failed: %s", e)
                return 0
            count = snapshot_observed_to_frozen(module)
            if count > 0:
                self._lp_rebuild_ports(module)
                self.patch_changed.emit()
            return count

        def _lp_clear(self, module: Module) -> int:
            """Properties-Panel 🗑️ Clear. Demoted ALLE Patterns + entfernt
            zugehörige Connections.

            Gibt die Anzahl der entfernten Patterns zurück.
            """
            try:
                from pydaw.flux.living_patterns import (
                    get_promoted_patterns,
                )
            except Exception as e:
                logger.warning("[LP] clear import failed: %s", e)
                return 0
            promoted = list(get_promoted_patterns(module))
            count = 0
            # Wir nutzen den vollwertigen _lp_demote-Pfad damit Cables
            # mitgepflegt werden — von hinten her demoten damit das
            # Re-Numbering konsistent läuft.
            for v in reversed(promoted):
                self._lp_demote(module, v)
                count += 1
            return count

        # ─── v0.0.21.231 — Overflow Picker Dialog ──────────────────

        def _lp_open_picker_dialog(self, module: Module) -> None:
            """Öffnet den Living-Patterns-Picker-Dialog.

            Wird aufgerufen wenn der User auf einen `+N more`-Chip
            klickt. Der Dialog ist modal aber non-blocking — User kann
            mehrere Promote/Demote-Operationen hintereinander machen
            bevor er den Dialog schließt. Nach jeder Mutation werden
            die Listen im Dialog neu aufgebaut.
            """
            try:
                from pydaw.flux.living_patterns_picker_dialog import (
                    LivingPatternsPickerDialog,
                )
                from pydaw.flux.living_patterns import (
                    get_promoted_patterns, get_observed_for_display,
                )
            except Exception as e:
                logger.warning("[LP] picker dialog import failed: %s", e)
                return
            if LivingPatternsPickerDialog is None:
                return  # Qt fehlt

            label = f"{module.god}.{module.kind}"
            promoted = get_promoted_patterns(module)
            observed = get_observed_for_display(module)

            # Parent-Widget aus dem ersten View ableiten — sonst
            # hängt der Dialog ohne Parent in der Luft (z-order issues)
            parent_widget = None
            try:
                views = self.views()
                if views:
                    parent_widget = views[0].window()
            except Exception:
                parent_widget = None

            dlg = LivingPatternsPickerDialog(
                module_label=label,
                promoted=list(promoted),
                observed=list(observed),
                parent=parent_widget,
            )

            def _on_promote(v) -> None:
                self._lp_promote(module, v)
                # Listen im Dialog refreshen
                dlg.update_data(
                    promoted=get_promoted_patterns(module),
                    observed=get_observed_for_display(module),
                )

            def _on_demote(v) -> None:
                self._lp_demote(module, v)
                dlg.update_data(
                    promoted=get_promoted_patterns(module),
                    observed=get_observed_for_display(module),
                )

            dlg.promote_requested.connect(_on_promote)
            dlg.demote_requested.connect(_on_demote)
            try:
                dlg.exec()
            except Exception as e:
                logger.warning("[LP] picker dialog exec failed: %s", e)

        # ─── v0.0.21.231 — Living Patterns Undo/Redo ───────────────
        #
        # Einfacher in-memory Stack für promote/demote-Operationen.
        # Eine Aktion ist ein dict mit:
        #   action:  "promote" | "demote"
        #   module_id: str
        #   value:   any (kanonisierter Tag-Wert)
        #
        # Undo invertiert (promote ↔ demote). Beim Demote werden die
        # ursprünglich verbundenen Cables NICHT wiederhergestellt —
        # das wäre ein eigenes Patches-Snapshot-System (v.232+).
        #
        # Stack-Größe begrenzt auf LP_UNDO_MAX (50). Beim Überlauf
        # fällt der älteste Eintrag raus (FIFO).
        LP_UNDO_MAX = 50

        def _lp_undo_init(self) -> None:
            """Lazy-Init der Undo-Stacks. Wird aus _lp_promote/_lp_demote
            aufgerufen — kein __init__-Eintrag damit ältere Patches/Tests
            ohne Undo-Stack noch funktionieren."""
            if not hasattr(self, "_lp_undo_stack"):
                self._lp_undo_stack: list[dict] = []
                self._lp_redo_stack: list[dict] = []

        def _lp_record(self, action: str, module_id: str, value) -> None:
            """Dokumentiert eine Promote/Demote-Aktion für Undo."""
            self._lp_undo_init()
            entry = {"action": action, "module_id": module_id, "value": value}
            self._lp_undo_stack.append(entry)
            if len(self._lp_undo_stack) > self.LP_UNDO_MAX:
                self._lp_undo_stack.pop(0)
            # Neue Aktion → Redo-Stack invalidieren
            self._lp_redo_stack.clear()

        def lp_undo(self) -> bool:
            """Rückgängig der letzten Promote/Demote-Aktion.

            Gibt True zurück wenn etwas getan wurde, False wenn der
            Stack leer ist.
            """
            self._lp_undo_init()
            if not self._lp_undo_stack:
                return False
            entry = self._lp_undo_stack.pop()
            mod = self.patch.get_module(entry["module_id"]) if self.patch else None
            if mod is None:
                logger.debug("[LP-UNDO] target module gone — skipping")
                return False
            # Invertieren ohne Stack-Pollution
            self._lp_redo_stack.append(entry)
            try:
                if entry["action"] == "promote":
                    self._lp_demote(mod, entry["value"], _record=False)
                else:
                    self._lp_promote(mod, entry["value"], _record=False)
            except Exception as e:
                logger.warning("[LP-UNDO] failed: %s", e)
                return False
            return True

        def lp_redo(self) -> bool:
            """Wiederherstellen der letzten rückgängig gemachten Aktion."""
            self._lp_undo_init()
            if not self._lp_redo_stack:
                return False
            entry = self._lp_redo_stack.pop()
            mod = self.patch.get_module(entry["module_id"]) if self.patch else None
            if mod is None:
                return False
            self._lp_undo_stack.append(entry)
            try:
                if entry["action"] == "promote":
                    self._lp_promote(mod, entry["value"], _record=False)
                else:
                    self._lp_demote(mod, entry["value"], _record=False)
            except Exception as e:
                logger.warning("[LP-REDO] failed: %s", e)
                return False
            return True

        def lp_can_undo(self) -> bool:
            return bool(getattr(self, "_lp_undo_stack", []))

        def lp_can_redo(self) -> bool:
            return bool(getattr(self, "_lp_redo_stack", []))

        def _tick_lp_signatures(self) -> None:
            """50ms-Tick: prüft ob sich observed/frozen-Tags geändert haben
            und triggert in dem Fall einen Repaint des ModuleItems.

            Diese Funktion wird aus ``_tick_pulses`` aufgerufen — sie
            ist billig (tuple-of-strings-Hash pro dynamic-outputs-Modul).
            Der Repaint passiert nur wenn der Hash sich seit dem letzten
            Tick geändert hat — typischerweise wenn der Renderer einen
            neuen Tag in observed_tags geschrieben hat.
            """
            for mi in self.module_items.values():
                if not getattr(mi, "_lp_active", lambda: False)():
                    continue
                try:
                    new_sig = mi._lp_compute_signature()
                except Exception:
                    continue
                if new_sig != mi._lp_signature:
                    mi._lp_signature = new_sig
                    # Höhe könnte sich ändern → prepareGeometryChange
                    mi.prepareGeometryChange()
                    mi.update()

        # ─── Animation ───────────────────────────────────────────

        def _tick_pulses(self) -> None:
            # v0.0.21.171: Aktivitäts-Polling vom Audio-Preview-Service
            try:
                from pydaw.flux.audio_preview import get_preview
                prev = get_preview()
                # Decay aller bekannten Aktivitäts-Werte
                prev.tick_activity_decay()
                # In jedes ModuleItem den aktuellen Wert pushen + repainten
                # falls sich was geändert hat (Optimierung gegen unnötigen Repaint)
                for mid, item in self.module_items.items():
                    new_act = prev.get_activity(mid)
                    if abs(new_act - item.activity) > 0.005:
                        item.activity = new_act
                        item.update()
                # v0.0.21.231 — NumberFlow Live-Probe-Polling.
                # Für jedes Frigg.NumberFlow-Modul fragen wir den
                # zuletzt gerenderten cv_in-Wert ab und pushen ihn ins
                # eingebettete NumberFlowWidget. ``set_value`` mit
                # ``emit_signal=False`` damit der Bridge-Pfad nicht
                # versucht das auf DSP-Targets zu dispatchen — der
                # Wert kommt vom Patch, nicht vom User.
                for mid, item in self.module_items.items():
                    mod = getattr(item, "module", None)
                    if mod is None:
                        continue
                    if mod.god != "Frigg" or mod.kind != "NumberFlow":
                        continue
                    val = prev.get_module_value(mid)
                    if val is None:
                        continue
                    widget = getattr(item, "embedded_widget", None)
                    if widget is None:
                        continue
                    try:
                        if hasattr(widget, "set_value"):
                            widget.set_value(float(val), emit_signal=False)
                    except Exception:
                        # Widget-Lifetime kann zwischen Tick und set_value
                        # abgelaufen sein (set_patch cleanup) — silent
                        pass
            except Exception:
                pass  # Audio-Preview nicht verfügbar — UI funktioniert trotzdem

            # v0.0.21.230 — Living Patterns Tag-Diff-Check.
            # Wenn der Renderer in observed_tags neue Werte schreibt
            # (Test Play läuft, RUNE-Messages fließen rein), triggern
            # wir einen Repaint des Modul-Items damit die neuen Chips
            # erscheinen. Sehr billig: tuple-Hash, kein Repaint wenn
            # nichts neu ist.
            try:
                self._tick_lp_signatures()
            except Exception as e:
                logger.debug("[LP] tick_lp_signatures failed: %s", e)

            # v0.0.21.204 — Saga.Magic Smart-Repaint-Tick.
            # In v.203 wurde jedes Saga-Item bei jedem 50-ms-Tick
            # repainted — bei Mausbewegung floodete das den UI-Thread
            # und verursachte Audio-Glitches in ProAudio/SF2/Drums
            # (Python-side Audio konkurriert mit UI um den GIL).
            #
            # v.204 fragt den Proxy nach dem aktuellen Phase-Bucket
            # (Quantisierung 100 Buckets/Drehung). `item.update()` wird
            # NUR gerufen wenn der Bucket gewechselt hat. Bei
            # rotation_speed=0 also nie. Bei rotation_speed=0.25/sec
            # nur ~25× pro Sekunde, nicht 20× konstant.
            try:
                from pydaw.flux.saga.renderer_proxy import (
                    get_saga_renderer_proxy,
                )
                _saga_proxy = get_saga_renderer_proxy()
            except Exception:
                _saga_proxy = None
            if _saga_proxy is not None:
                for item in self.module_items.values():
                    if not getattr(item, "_is_saga_magic", False):
                        continue
                    try:
                        new_bucket = _saga_proxy.phase_bucket(
                            str(item.module.id),
                        )
                    except Exception:
                        new_bucket = -1
                    last_bucket = getattr(item, "_saga_last_bucket", -2)
                    if new_bucket != last_bucket:
                        item._saga_last_bucket = new_bucket
                        item.update()

            # Pulse-Phase + Flow-Animation auf den Kabeln (v.181: beides)
            for c in self.cable_items.values():
                length = max(1.0, c.path().length())
                # Pulse-Punkte (radial Glow + weißer Kern)
                step = PULSE_SPEED_PX_PER_FRAME / length
                c.phase = (c.phase + step) % 1.0
                # Flow-Striche: 24px-Zyklus, 1.5 Zyklen pro Sekunde
                # bei 20Hz Tick = 0.075 pro Tick (= 1.5/20)
                c.flow_phase = (c.flow_phase + 0.075) % 1.0
                c.update()

            # Disconnect-Animation: Progress hochzählen + finalisieren
            if self._disconnecting_cables:
                still_animating = []
                for c in self._disconnecting_cables:
                    # v0.0.21.231: LP-Demote-Cables fahren schneller raus
                    # (200ms = 4 ticks × 0.25) als normaler Click-Disconnect
                    # (1s = 20 ticks × 0.05). Das fühlt sich responsiv an
                    # beim Click-Demote, während User-Click-auf-Cable
                    # weiterhin 1s gibt um „uuuups" zu denken.
                    if getattr(c, "_lp_demote_anim", False):
                        c.disconnect_progress += 0.25
                    else:
                        c.disconnect_progress += 0.05  # 50ms × 20 = 1.0 nach 1s
                    if c.disconnect_progress >= 1.0:
                        # Endgültig entfernen
                        self._finalize_cable_removal(c)
                    else:
                        still_animating.append(c)
                        c.update()
                self._disconnecting_cables = still_animating

            # Cluster-Layout-Animation: pro Modul lerp zur Ziel-Position
            if self._cluster_targets:
                done = []
                for mid, (tx, ty) in list(self._cluster_targets.items()):
                    item = self.module_items.get(mid)
                    if item is None:
                        done.append(mid); continue
                    cur = item.pos()
                    dx, dy = tx - cur.x(), ty - cur.y()
                    if abs(dx) < 0.5 and abs(dy) < 0.5:
                        item.setPos(tx, ty)
                        item.module.position = (tx, ty)
                        done.append(mid)
                    else:
                        # Lerp 18% pro Tick → ~5 Ticks bis nahe am Ziel
                        item.setPos(cur.x() + dx * 0.18, cur.y() + dy * 0.18)
                        # Cables mitbewegen
                        self._update_cables_for_module(mid)
                for mid in done:
                    del self._cluster_targets[mid]

        # ─── Connection-Drag (v.181: mit Vorschau-Cable) ──────────

        def mousePressEvent(self, event):
            transform = self.views()[0].transform() if self.views() else None
            item = self.itemAt(event.scenePos(), transform)
            # 1) Klick auf Output-Port → Drag-Cable starten
            if isinstance(item, PortItem) \
               and item.port.direction == PortDirection.OUTPUT:
                self._dragging_from = item
                # NEU: Drag-Cable-Item erzeugen (gestrichelte Bezier-Vorschau)
                self._drag_cable = DragCableItem(item)
                self.addItem(self._drag_cable)
                event.accept()
                return
            # 2) Klick auf CableItem → Disconnect-Animation starten
            if isinstance(item, CableItem) and not item._disconnecting:
                item.start_disconnect()
                self._disconnecting_cables.append(item)
                event.accept()
                return
            super().mousePressEvent(event)

        def mouseMoveEvent(self, event):
            if self._drag_cable is not None:
                # Drag-Cable folgt der Cursor-Position
                self._drag_cable.update_to_cursor(event.scenePos())
                event.accept()
                return
            super().mouseMoveEvent(event)

        def mouseReleaseEvent(self, event):
            if self._dragging_from is not None:
                transform = self.views()[0].transform() if self.views() else None
                # Drag-Cable aus Scene entfernen — egal ob erfolgreich oder nicht
                if self._drag_cable is not None:
                    self.removeItem(self._drag_cable)
                    self._drag_cable = None
                end_item = self.itemAt(event.scenePos(), transform)
                if isinstance(end_item, PortItem) \
                   and end_item.port.direction == PortDirection.INPUT:
                    # Verbindung anlegen
                    src_mi = self._dragging_from.module_item
                    tgt_mi = end_item.module_item
                    conn = Connection(
                        source_module=src_mi.module.id,
                        source_port=self._dragging_from.port.name,
                        target_module=tgt_mi.module.id,
                        target_port=end_item.port.name,
                    )
                    if self.patch.add_connection(conn) is not None:
                        # v0.0.21.196: UI-Widget-Source → Range-Auto-Adapt.
                        # Wenn der Source ein Frigg-Modul ist und der Knob
                        # noch im Default-Range (0..1) steht, übernehmen
                        # wir die Range vom Ziel-Port. Dann zeigt der
                        # Knob z.B. "440 Hz" statt "0.5" und sendet auch
                        # 20..20000 Hz statt 0..1.
                        self._auto_adapt_ui_widget_range(src_mi, end_item.port)
                        self._add_cable_item(conn)
                        self.patch_changed.emit()
                    else:
                        logger.info("[FLUX] connection refused (incompatible ports)")
                self._dragging_from = None
                event.accept()
                return
            super().mouseReleaseEvent(event)

        def _finalize_cable_removal(self, cable: CableItem) -> None:
            """Entferne ein animiert verschwundenes Cable endgültig aus
            Scene UND aus dem Patch-Modell."""
            cid = cable.connection.id
            try:
                self.removeItem(cable)
            except Exception:
                pass
            self.cable_items.pop(cid, None)
            try:
                self.patch.remove_connection(cid)
            except Exception:
                # Falls remove_connection nicht existiert: list-comprehension
                self.patch.connections = [
                    c for c in self.patch.connections if c.id != cid
                ]
            self.patch_changed.emit()

        # ─── Cluster-Layout (v.181: Auto-Anordnung nach Topologie) ──

        def cluster_layout(self) -> None:
            """Auto-Layout: Module nach Topologie-Klasse in Spalten anordnen.

            Klassifikation per Port-Typen:
            - **Source**:    KEIN audio_in, hat audio-out (Bragi, Loki, Tyr)
            - **Modulator**: nur CV-Ports                  (Freyr.ADSR, ...)
            - **FX**:        audio_in UND audio_out         (Forseti, Iduna, Hel, Mimir, Fenrir)
            - **Output**:    audio_in, KEIN audio_out      (Heimdall.MasterOut)

            Anordnung: Sources links (x=0), Modulators darüber/darunter
            (x=180), FX in der Mitte (x=440 / 720), Outputs rechts (x=1000).
            Vertikal: 200px Abstand pro Cluster-Mitglied, vertikal zentriert
            um die Canvas-Mitte (y=0).

            Animation: nicht teleportieren — `_cluster_targets` setzt das
            Ziel, `_tick_pulses` lerpt mit 18% pro Tick (≈300ms total).
            """
            # 1. Klassifizieren
            cols: dict[str, list[Module]] = {
                "source": [], "mod": [], "fx_a": [], "fx_b": [], "out": [],
            }
            fx_buffer = []  # FX werden über 2 Spalten verteilt
            for m in self.patch.modules:
                has_audio_in = any(
                    p.kind == PortKind.AUDIO and p.direction == PortDirection.INPUT
                    for p in m.inputs
                )
                has_audio_out = any(
                    p.kind == PortKind.AUDIO and p.direction == PortDirection.OUTPUT
                    for p in m.outputs
                )
                has_cv_out = any(
                    p.kind == PortKind.CV and p.direction == PortDirection.OUTPUT
                    for p in m.outputs
                )
                if has_audio_in and not has_audio_out:
                    cols["out"].append(m)
                elif has_audio_in and has_audio_out:
                    fx_buffer.append(m)
                elif not has_audio_in and has_audio_out:
                    cols["source"].append(m)
                elif has_cv_out and not has_audio_out:
                    cols["mod"].append(m)
                else:
                    # Edge-Case (z.B. Tyr.PulseGate hat nur CV-out aber als Trigger)
                    cols["mod"].append(m)
            # FX gleichmäßig auf 2 Spalten aufteilen
            for i, m in enumerate(fx_buffer):
                cols["fx_a" if i % 2 == 0 else "fx_b"].append(m)

            # 2. Spalten-X-Positionen + vertikale Verteilung
            COL_X = {
                "source": -480.0,
                "mod":    -240.0,
                "fx_a":     20.0,
                "fx_b":    280.0,
                "out":     540.0,
            }
            ROW_H = 200.0
            self._cluster_targets.clear()
            for col_name, modules in cols.items():
                if not modules:
                    continue
                # Vertikal um y=0 zentrieren
                n = len(modules)
                y_start = -((n - 1) * ROW_H) / 2.0
                x = COL_X[col_name]
                for i, m in enumerate(modules):
                    y = y_start + i * ROW_H
                    self._cluster_targets[m.id] = (x, y)

            # 3. Im nächsten _tick_pulses werden die Module animiert
            #    zur Ziel-Position bewegt. patch_changed wird emittiert
            #    nachdem alle angekommen sind (oder direkt für Speicher).
            self.patch_changed.emit()

        # ─── Connection-Drag (Legacy-API) ─────────────────────────

        # ─── Grid-Zeichnung ──────────────────────────────────────

        def drawBackground(self, painter: QPainter, rect: QRectF) -> None:
            super().drawBackground(painter, rect)
            # Punkt-Raster im WAECHTER-Stil
            painter.setPen(QPen(GRID_COLOR, 0.6))
            grid = 40
            left = int(rect.left()) - (int(rect.left()) % grid)
            top = int(rect.top()) - (int(rect.top()) % grid)
            x = left
            while x < rect.right():
                y = top
                while y < rect.bottom():
                    painter.drawPoint(QPointF(x, y))
                    y += grid
                x += grid


    class FluxView(QGraphicsView):
        """View mit Mausrad-Zoom und Mittelmaustasten-Pan."""

        def __init__(self, scene: FluxScene, parent=None):
            super().__init__(scene, parent)
            self.setRenderHint(QPainter.RenderHint.Antialiasing)
            self.setDragMode(QGraphicsView.DragMode.RubberBandDrag)
            self.setTransformationAnchor(
                QGraphicsView.ViewportAnchor.AnchorUnderMouse,
            )
            self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
            self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
            self.setMouseTracking(True)

        def wheelEvent(self, event):
            factor = 1.15 if event.angleDelta().y() > 0 else 1 / 1.15
            self.scale(factor, factor)

        def keyPressEvent(self, event):
            if event.key() in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace):
                if isinstance(self.scene(), FluxScene):
                    self.scene().remove_selected()
                event.accept()
                return
            super().keyPressEvent(event)


else:
    # PyQt6 nicht verfügbar — Stubs damit Imports von dieser Datei
    # nicht crashen (z.B. in Test-Umgebungen)
    class FluxScene:  # type: ignore
        pass
    class FluxView:   # type: ignore
        pass


__all__ = ["FluxScene", "FluxView"]
