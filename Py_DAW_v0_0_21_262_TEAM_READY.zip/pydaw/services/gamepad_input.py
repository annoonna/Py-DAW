"""Gamepad Input Service (P4B) — Xbox/PS controller as instrument.

Uses pygame or evdev for gamepad input. Falls back gracefully if unavailable.

Features:
- Button → MIDI note mapping (chromatic or drum)
- Stick/Trigger → CC mapping (pitch bend, mod wheel, expression)
- D-Pad → transport control (play/stop/record/undo)
- Configurable mapping profiles
- Deadzone and curve adjustments

v0.0.20.810 — Phase P4B
"""

from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Callable, Any

from PyQt6.QtCore import QObject, pyqtSignal, QTimer

log = logging.getLogger(__name__)

# Try pygame first (cross-platform), then evdev (Linux-only)
_HAS_PYGAME = False
_HAS_EVDEV = False
try:
    import pygame  # type: ignore
    _HAS_PYGAME = True
except ImportError:
    pass

if not _HAS_PYGAME:
    try:
        import evdev  # type: ignore
        _HAS_EVDEV = True
    except ImportError:
        pass


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class GamepadButtonMap:
    """Map a gamepad button to a MIDI note or DAW action."""
    button_index: int          # pygame button index
    action: str = "note"       # "note"|"play"|"stop"|"record"|"undo"|"redo"
    midi_note: int = 60        # MIDI note (for action="note")
    velocity: int = 100
    channel: int = 0


@dataclass
class GamepadAxisMap:
    """Map a gamepad axis/stick to a MIDI CC."""
    axis_index: int            # pygame axis index
    cc: int = 1                # MIDI CC number
    channel: int = 0
    deadzone: float = 0.15     # ignore values below this threshold
    curve: float = 1.0         # response curve (1=linear, 2=quadratic)
    inverted: bool = False
    bipolar: bool = True       # True = -1..1 (centered), False = 0..1 (trigger)


@dataclass
class GamepadProfile:
    """Complete gamepad mapping profile."""
    name: str = "Default"
    buttons: List[GamepadButtonMap] = field(default_factory=list)
    axes: List[GamepadAxisMap] = field(default_factory=list)
    base_note: int = 60        # root note for chromatic mapping
    description: str = ""

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "buttons": len(self.buttons),
            "axes": len(self.axes),
            "base_note": self.base_note,
            "description": self.description,
        }


# ---------------------------------------------------------------------------
# Built-in profiles
# ---------------------------------------------------------------------------

def _build_xbox_instrument() -> GamepadProfile:
    """Xbox controller as chromatic instrument."""
    buttons = [
        # Face buttons → chord
        GamepadButtonMap(0, "note", 60, 100),   # A → C4
        GamepadButtonMap(1, "note", 64, 100),   # B → E4
        GamepadButtonMap(2, "note", 67, 100),   # X → G4
        GamepadButtonMap(3, "note", 72, 100),   # Y → C5
        # Bumpers → octave shift notes
        GamepadButtonMap(4, "note", 48, 80),    # LB → C3
        GamepadButtonMap(5, "note", 55, 80),    # RB → G3
        # Start/Select → transport
        GamepadButtonMap(7, "play"),             # Start → Play
        GamepadButtonMap(6, "stop"),             # Select → Stop
        # D-Pad (as buttons 11-14 in many mappings)
        GamepadButtonMap(11, "note", 57, 90),   # D-Up → A3
        GamepadButtonMap(12, "note", 53, 90),   # D-Down → F3
        GamepadButtonMap(13, "note", 50, 90),   # D-Left → D3
        GamepadButtonMap(14, "note", 62, 90),   # D-Right → D4
    ]
    axes = [
        GamepadAxisMap(0, cc=1, deadzone=0.15, bipolar=True),    # Left X → Mod
        GamepadAxisMap(1, cc=74, deadzone=0.15, bipolar=True),   # Left Y → Brightness
        GamepadAxisMap(3, cc=11, deadzone=0.15, bipolar=True),   # Right X → Expression
        GamepadAxisMap(4, cc=71, deadzone=0.15, bipolar=True),   # Right Y → Timbre
        GamepadAxisMap(2, cc=7, deadzone=0.05, bipolar=False),   # LT → Volume down
        GamepadAxisMap(5, cc=7, deadzone=0.05, bipolar=False),   # RT → Volume up
    ]
    return GamepadProfile(
        name="Xbox Instrument",
        buttons=buttons,
        axes=axes,
        base_note=60,
        description="Face buttons = Akkord, Sticks = CC, Start/Select = Transport",
    )


def _build_xbox_drums() -> GamepadProfile:
    """Xbox controller as drum machine."""
    buttons = [
        GamepadButtonMap(0, "note", 36, 110),   # A → Kick
        GamepadButtonMap(1, "note", 38, 100),   # B → Snare
        GamepadButtonMap(2, "note", 42, 90),    # X → Closed HH
        GamepadButtonMap(3, "note", 46, 85),    # Y → Open HH
        GamepadButtonMap(4, "note", 49, 80),    # LB → Crash
        GamepadButtonMap(5, "note", 51, 80),    # RB → Ride
        GamepadButtonMap(11, "note", 45, 90),   # D-Up → Tom High
        GamepadButtonMap(12, "note", 41, 90),   # D-Down → Tom Low
        GamepadButtonMap(13, "note", 39, 85),   # D-Left → Clap
        GamepadButtonMap(14, "note", 56, 85),   # D-Right → Cowbell
        GamepadButtonMap(7, "play"),
        GamepadButtonMap(6, "stop"),
    ]
    axes = [
        GamepadAxisMap(2, cc=1, deadzone=0.05, bipolar=False),   # LT → Velocity mod
        GamepadAxisMap(5, cc=11, deadzone=0.05, bipolar=False),  # RT → Expression
    ]
    return GamepadProfile(
        name="Xbox Drums",
        buttons=buttons,
        axes=axes,
        base_note=36,
        description="Face buttons = GM Drums, Trigger = Velocity/Expression",
    )


_BUILTIN_PROFILES: Dict[str, GamepadProfile] = {
    "xbox_instrument": _build_xbox_instrument(),
    "xbox_drums": _build_xbox_drums(),
}


def get_profiles() -> Dict[str, GamepadProfile]:
    return dict(_BUILTIN_PROFILES)


# ---------------------------------------------------------------------------
# Gamepad Input Service
# ---------------------------------------------------------------------------

class GamepadInputService(QObject):
    """Reads gamepad input and converts to MIDI/DAW actions.

    Uses pygame.joystick for cross-platform support.
    Polls at ~60 Hz via QTimer (non-blocking).
    """

    note_on = pyqtSignal(int, int, int)      # pitch, velocity, channel
    note_off = pyqtSignal(int, int)           # pitch, channel
    cc_changed = pyqtSignal(int, int, int)    # controller, value, channel
    transport_action = pyqtSignal(str)        # "play"|"stop"|"record"|"undo"|"redo"
    status = pyqtSignal(str)
    error = pyqtSignal(str)

    def __init__(
        self,
        midi_manager=None,
        transport=None,
        profile: Optional[GamepadProfile] = None,
        parent: Optional[QObject] = None,
    ):
        super().__init__(parent)
        self._midi_manager = midi_manager
        self._transport = transport
        self._profile = profile or _build_xbox_instrument()
        self._joystick = None
        self._running = False

        self._poll_timer = QTimer(self)
        self._poll_timer.setInterval(16)  # ~60 Hz
        self._poll_timer.timeout.connect(self._poll)

        self._button_states: Dict[int, bool] = {}
        self._axis_values: Dict[int, float] = {}
        self._active_notes: Dict[int, int] = {}  # button_index → midi_note

        self._initialized = False

    @staticmethod
    def is_available() -> bool:
        return _HAS_PYGAME or _HAS_EVDEV

    def set_profile(self, profile: GamepadProfile) -> None:
        self._profile = profile

    def start(self) -> bool:
        """Initialize pygame and connect to first gamepad."""
        if not _HAS_PYGAME:
            try:
                self.error.emit("Gamepad: pygame nicht installiert (pip install pygame)")
            except Exception:
                pass
            return False

        try:
            if not self._initialized:
                pygame.init()
                pygame.joystick.init()
                self._initialized = True

            count = pygame.joystick.get_count()
            if count == 0:
                try:
                    self.error.emit("Gamepad: Kein Controller erkannt")
                except Exception:
                    pass
                return False

            self._joystick = pygame.joystick.Joystick(0)
            self._joystick.init()

            name = self._joystick.get_name()
            num_buttons = self._joystick.get_numbuttons()
            num_axes = self._joystick.get_numaxes()

            self._running = True
            self._poll_timer.start()

            try:
                self.status.emit(
                    f"🎮 {name} verbunden ({num_buttons} Buttons, {num_axes} Achsen)"
                )
            except Exception:
                pass
            return True

        except Exception as exc:
            try:
                self.error.emit(f"Gamepad: Init fehlgeschlagen: {exc}")
            except Exception:
                pass
            return False

    def stop(self) -> None:
        """Disconnect gamepad."""
        self._running = False
        self._poll_timer.stop()

        # Release all active notes
        for btn_idx, note in list(self._active_notes.items()):
            try:
                self.note_off.emit(note, 0)
            except Exception:
                pass
        self._active_notes.clear()

        if self._joystick:
            try:
                self._joystick.quit()
            except Exception:
                pass
            self._joystick = None

    def _poll(self) -> None:
        """Poll gamepad state (~60 Hz)."""
        if not self._running or not self._joystick or not _HAS_PYGAME:
            return

        try:
            pygame.event.pump()  # process pygame events
        except Exception:
            return

        js = self._joystick
        profile = self._profile

        # ── Buttons ───────────────────────────────────────────────────
        for bmap in profile.buttons:
            try:
                pressed = js.get_button(bmap.button_index)
            except Exception:
                continue

            was_pressed = self._button_states.get(bmap.button_index, False)
            self._button_states[bmap.button_index] = pressed

            if pressed and not was_pressed:
                # Button just pressed
                if bmap.action == "note":
                    self._active_notes[bmap.button_index] = bmap.midi_note
                    try:
                        self.note_on.emit(bmap.midi_note, bmap.velocity, bmap.channel)
                    except Exception:
                        pass
                    self._inject_note_on(bmap.midi_note, bmap.velocity, bmap.channel)
                elif bmap.action in ("play", "stop", "record", "undo", "redo"):
                    try:
                        self.transport_action.emit(bmap.action)
                    except Exception:
                        pass
                    self._do_transport(bmap.action)

            elif not pressed and was_pressed:
                # Button just released
                if bmap.action == "note" and bmap.button_index in self._active_notes:
                    note = self._active_notes.pop(bmap.button_index)
                    try:
                        self.note_off.emit(note, bmap.channel)
                    except Exception:
                        pass
                    self._inject_note_off(note, bmap.channel)

        # ── Axes ──────────────────────────────────────────────────────
        for amap in profile.axes:
            try:
                raw = js.get_axis(amap.axis_index)
            except Exception:
                continue

            if amap.inverted:
                raw = -raw

            # Apply deadzone
            if abs(raw) < amap.deadzone:
                raw = 0.0
            else:
                # Rescale after deadzone
                sign = 1.0 if raw >= 0 else -1.0
                raw = sign * (abs(raw) - amap.deadzone) / (1.0 - amap.deadzone)

            # Apply curve
            if amap.curve != 1.0:
                raw = (abs(raw) ** amap.curve) * (1.0 if raw >= 0 else -1.0)

            # Convert to MIDI CC (0-127)
            if amap.bipolar:
                cc_val = int((raw + 1.0) * 63.5)  # -1..1 → 0..127
            else:
                cc_val = int(raw * 127.0)  # 0..1 → 0..127
            cc_val = max(0, min(127, cc_val))

            # Only send if changed
            prev = self._axis_values.get(amap.axis_index, -1)
            if cc_val != prev:
                self._axis_values[amap.axis_index] = cc_val
                try:
                    self.cc_changed.emit(amap.cc, cc_val, amap.channel)
                except Exception:
                    pass
                self._inject_cc(amap.cc, cc_val, amap.channel)

    def _inject_note_on(self, note: int, vel: int, ch: int) -> None:
        mm = self._midi_manager
        if mm is None:
            return
        try:
            import mido
            msg = mido.Message("note_on", note=note, velocity=vel, channel=ch)
            mm.inject_message(msg, source="gamepad")
        except ImportError:
            try:
                from pydaw.services.computer_keyboard_midi import _FakeMsg
                mm.inject_message(_FakeMsg("note_on", note, vel, ch), source="gamepad")
            except Exception:
                pass
        except Exception:
            pass

    def _inject_note_off(self, note: int, ch: int) -> None:
        mm = self._midi_manager
        if mm is None:
            return
        try:
            import mido
            msg = mido.Message("note_off", note=note, velocity=0, channel=ch)
            mm.inject_message(msg, source="gamepad")
        except ImportError:
            try:
                from pydaw.services.computer_keyboard_midi import _FakeMsg
                mm.inject_message(_FakeMsg("note_off", note, 0, ch), source="gamepad")
            except Exception:
                pass
        except Exception:
            pass

    def _inject_cc(self, ctrl: int, val: int, ch: int) -> None:
        mm = self._midi_manager
        if mm is None:
            return
        try:
            import mido
            msg = mido.Message("control_change", control=ctrl, value=val, channel=ch)
            mm.inject_message(msg, source="gamepad")
        except Exception:
            pass

    def _do_transport(self, action: str) -> None:
        t = self._transport
        if t is None:
            return
        try:
            if action == "play":
                t.play()
            elif action == "stop":
                t.stop()
            elif action == "record":
                t.toggle_record()
        except Exception:
            pass

    def shutdown(self) -> None:
        self.stop()
        if self._initialized and _HAS_PYGAME:
            try:
                pygame.joystick.quit()
            except Exception:
                pass
