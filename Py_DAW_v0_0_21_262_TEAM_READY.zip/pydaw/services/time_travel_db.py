"""time_travel_db.py — SQLite Journal für die Time-Travel Engine.

v0.0.20.898 — Phase T1 der TIME_TRAVEL_ROADMAP.

Speichert kontinuierlich ALLE Events (MIDI, Parameter, Plugin, Transport)
in einer SQLite-Datenbank. Ermöglicht:
- "Geh 5 Minuten zurück" (State Reconstruction)
- "Finde den Sound von letzter Woche" (FTS5 Suche)
- Undo-Baum (Git-Style Branching)
- Sound DNA (Audio-Fingerprinting)

Default Lookback: 5 Minuten (konfigurierbar).

Tabellen:
- journal_events       — Rohe Events (MIDI + Params + Plugin + Transport)
- journal_snapshots    — Periodische Voll-Snapshots (alle 30s)
- journal_tags         — KI-generierte Beschreibungen
- journal_tags_fts     — FTS5 Volltext-Suche
- journal_audio_fp     — Audio-Fingerprints
- journal_branches     — Undo-Baum (Git-Style)
- journal_sessions     — Session-Metadaten
- sound_dna            — Cross-Projekt Sound-Signaturen

Usage:
    from pydaw.services.time_travel_db import TimeTravelDB
    db = TimeTravelDB.get()
    db.ensure_loaded()

    # Events schreiben
    db.log_event(session_id, timestamp_ms, 'param_change',
                 track_id='trk_1', plugin_id='surge-xt',
                 param_id='cutoff', value_float=0.75)

    # Snapshot schreiben
    db.save_snapshot(session_id, timestamp_ms, state_json)

    # Events lesen (letzte 5 Minuten)
    events = db.get_events_in_range(session_id, start_ms, end_ms)

    # Sound suchen
    results = db.search_tags("warmer pad C-Moll")
"""

import json
import sqlite3
import logging
import time
import uuid
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple

log = logging.getLogger(__name__)

# ── Default-Konfiguration ──
DEFAULT_LOOKBACK_MINUTES = 5
DEFAULT_SNAPSHOT_INTERVAL_SEC = 30
DEFAULT_MAX_EVENTS_PER_SESSION = 100_000
DEFAULT_MAX_SNAPSHOTS_PER_SESSION = 500
DEFAULT_MAX_SESSION_AGE_DAYS = 30
DEFAULT_FLUSH_INTERVAL_MS = 500
DEFAULT_FLUSH_BATCH_SIZE = 100


_SCHEMA_SQL = """
-- Session-Metadaten
CREATE TABLE IF NOT EXISTS journal_sessions (
    id              TEXT PRIMARY KEY,
    project_path    TEXT NOT NULL DEFAULT '',
    project_name    TEXT NOT NULL DEFAULT '',
    bpm             REAL NOT NULL DEFAULT 120.0,
    sample_rate     INTEGER NOT NULL DEFAULT 48000,
    started_at      REAL NOT NULL,
    ended_at        REAL DEFAULT 0,
    event_count     INTEGER NOT NULL DEFAULT 0,
    snapshot_count  INTEGER NOT NULL DEFAULT 0,
    lookback_min    INTEGER NOT NULL DEFAULT 5
);

-- Alle Events (MIDI + Parameter + Plugin + Transport)
CREATE TABLE IF NOT EXISTS journal_events (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      TEXT NOT NULL,
    timestamp_ms    INTEGER NOT NULL,
    wall_clock      REAL NOT NULL,
    event_type      TEXT NOT NULL,
    track_id        TEXT NOT NULL DEFAULT '',
    plugin_id       TEXT NOT NULL DEFAULT '',
    param_id        TEXT NOT NULL DEFAULT '',
    value_float     REAL,
    value_int       INTEGER,
    value_text      TEXT DEFAULT '',
    meta_json       TEXT DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_je_session_time
    ON journal_events(session_id, timestamp_ms);
CREATE INDEX IF NOT EXISTS idx_je_track
    ON journal_events(track_id, timestamp_ms);
CREATE INDEX IF NOT EXISTS idx_je_type
    ON journal_events(event_type, timestamp_ms);
CREATE INDEX IF NOT EXISTS idx_je_plugin
    ON journal_events(plugin_id, timestamp_ms);

-- Periodische Voll-Snapshots (alle 30s)
CREATE TABLE IF NOT EXISTS journal_snapshots (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      TEXT NOT NULL,
    timestamp_ms    INTEGER NOT NULL,
    wall_clock      REAL NOT NULL,
    snapshot_json   TEXT NOT NULL,
    track_count     INTEGER DEFAULT 0,
    clip_count      INTEGER DEFAULT 0,
    bpm             REAL DEFAULT 120.0,
    label           TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_js_session_time
    ON journal_snapshots(session_id, timestamp_ms);

-- KI-generierte Beschreibungen / User-Tags
CREATE TABLE IF NOT EXISTS journal_tags (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      TEXT NOT NULL,
    timestamp_ms    INTEGER NOT NULL,
    wall_clock      REAL NOT NULL,
    tag_text        TEXT NOT NULL,
    confidence      REAL DEFAULT 1.0,
    source          TEXT DEFAULT 'auto'
);
CREATE INDEX IF NOT EXISTS idx_jt_session_time
    ON journal_tags(session_id, timestamp_ms);

-- FTS5 Volltext-Suche über Tags
CREATE VIRTUAL TABLE IF NOT EXISTS journal_tags_fts USING fts5(
    tag_text,
    content='journal_tags',
    content_rowid='id'
);

-- Trigger: FTS5 sync bei INSERT/DELETE/UPDATE
CREATE TRIGGER IF NOT EXISTS jt_ai AFTER INSERT ON journal_tags BEGIN
    INSERT INTO journal_tags_fts(rowid, tag_text) VALUES (new.id, new.tag_text);
END;
CREATE TRIGGER IF NOT EXISTS jt_ad AFTER DELETE ON journal_tags BEGIN
    INSERT INTO journal_tags_fts(journal_tags_fts, rowid, tag_text)
        VALUES('delete', old.id, old.tag_text);
END;
CREATE TRIGGER IF NOT EXISTS jt_au AFTER UPDATE ON journal_tags BEGIN
    INSERT INTO journal_tags_fts(journal_tags_fts, rowid, tag_text)
        VALUES('delete', old.id, old.tag_text);
    INSERT INTO journal_tags_fts(rowid, tag_text) VALUES (new.id, new.tag_text);
END;

-- Audio-Fingerprints (Sound-Signaturen)
CREATE TABLE IF NOT EXISTS journal_audio_fp (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      TEXT NOT NULL,
    timestamp_ms    INTEGER NOT NULL,
    track_id        TEXT DEFAULT '',
    fingerprint     BLOB NOT NULL,
    spectral_centroid REAL DEFAULT 0,
    rms_db          REAL DEFAULT -60,
    dominant_pitch  REAL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_jafp_session_time
    ON journal_audio_fp(session_id, timestamp_ms);

-- Undo-Baum (Git-Style Branches)
CREATE TABLE IF NOT EXISTS journal_branches (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      TEXT NOT NULL,
    branch_name     TEXT NOT NULL DEFAULT 'main',
    parent_branch_id INTEGER,
    fork_timestamp_ms INTEGER NOT NULL,
    snapshot_id     INTEGER,
    is_active       INTEGER DEFAULT 0,
    created_at      REAL NOT NULL,
    description     TEXT DEFAULT ''
);

-- Cross-Projekt Sound-Signaturen
CREATE TABLE IF NOT EXISTS sound_dna (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    project_path    TEXT NOT NULL,
    track_id        TEXT NOT NULL,
    plugin_id       TEXT NOT NULL,
    preset_name     TEXT DEFAULT '',
    param_hash      TEXT NOT NULL,
    fingerprint     BLOB,
    tags            TEXT DEFAULT '',
    created_at      REAL NOT NULL,
    UNIQUE(project_path, track_id, param_hash)
);
CREATE INDEX IF NOT EXISTS idx_sdna_plugin ON sound_dna(plugin_id);
"""


class TimeTravelDB:
    """SQLite-backed journal for the Time-Travel Engine.

    Singleton. Writes via batch-flush (non-blocking).
    Reads are direct (WAL mode allows concurrent reads).
    """

    _instance: Optional["TimeTravelDB"] = None

    @classmethod
    def get(cls) -> "TimeTravelDB":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._db_path = Path.home() / ".config" / "ChronoScaleStudio" / "pydaw.db"
        self._loaded = False
        self._event_buffer: List[tuple] = []
        self._tag_buffer: List[tuple] = []

    def ensure_loaded(self) -> None:
        if self._loaded:
            return
        try:
            self._db_path.parent.mkdir(parents=True, exist_ok=True)
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.executescript(_SCHEMA_SQL)
                conn.commit()
            finally:
                conn.close()
            self._loaded = True
            log.info("[TimeTravelDB] Tables ready")
        except Exception as e:
            log.warning("[TimeTravelDB] Init failed: %s", e)

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self._db_path))
        conn.row_factory = sqlite3.Row
        return conn

    @staticmethod
    def new_session_id() -> str:
        """Generate a unique session ID."""
        return f"ses_{uuid.uuid4().hex[:12]}"

    # ══════════════════════════════════════════════════════════════
    # Session Management
    # ══════════════════════════════════════════════════════════════

    def start_session(self, session_id: str, project_path: str = "",
                       project_name: str = "", bpm: float = 120.0,
                       sample_rate: int = 48000) -> None:
        """Register a new journaling session."""
        try:
            conn = self._conn()
            try:
                conn.execute(
                    """INSERT OR REPLACE INTO journal_sessions
                       (id, project_path, project_name, bpm, sample_rate,
                        started_at, lookback_min)
                       VALUES (?, ?, ?, ?, ?, ?, ?)""",
                    (session_id, project_path, project_name, bpm,
                     sample_rate, time.time(), DEFAULT_LOOKBACK_MINUTES),
                )
                conn.commit()
            finally:
                conn.close()
        except Exception as e:
            log.debug("[TimeTravelDB] start_session failed: %s", e)

    def end_session(self, session_id: str) -> None:
        """Mark a session as ended. Flush pending events first."""
        self.flush_events()
        try:
            conn = self._conn()
            try:
                conn.execute(
                    "UPDATE journal_sessions SET ended_at=? WHERE id=?",
                    (time.time(), session_id),
                )
                # Update counts
                ev_count = conn.execute(
                    "SELECT COUNT(*) as c FROM journal_events WHERE session_id=?",
                    (session_id,),
                ).fetchone()
                sn_count = conn.execute(
                    "SELECT COUNT(*) as c FROM journal_snapshots WHERE session_id=?",
                    (session_id,),
                ).fetchone()
                conn.execute(
                    "UPDATE journal_sessions SET event_count=?, snapshot_count=? WHERE id=?",
                    (ev_count["c"] if ev_count else 0,
                     sn_count["c"] if sn_count else 0,
                     session_id),
                )
                conn.commit()
            finally:
                conn.close()
        except Exception as e:
            log.debug("[TimeTravelDB] end_session failed: %s", e)

    def get_sessions(self, limit: int = 20) -> List[dict]:
        """Get recent sessions."""
        try:
            conn = self._conn()
            try:
                rows = conn.execute(
                    "SELECT * FROM journal_sessions ORDER BY started_at DESC LIMIT ?",
                    (limit,),
                ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    # ══════════════════════════════════════════════════════════════
    # Event Logging (Buffered Write)
    # ══════════════════════════════════════════════════════════════

    def log_event(self, session_id: str, timestamp_ms: int,
                   event_type: str, track_id: str = "",
                   plugin_id: str = "", param_id: str = "",
                   value_float: Optional[float] = None,
                   value_int: Optional[int] = None,
                   value_text: str = "",
                   meta: Optional[dict] = None) -> None:
        """Buffer a journal event. Call flush_events() periodically."""
        self._event_buffer.append((
            session_id, int(timestamp_ms), time.time(),
            str(event_type), str(track_id), str(plugin_id),
            str(param_id), value_float, value_int,
            str(value_text),
            json.dumps(meta or {}, ensure_ascii=False),
        ))
        # Auto-flush when buffer is large
        if len(self._event_buffer) >= DEFAULT_FLUSH_BATCH_SIZE:
            self.flush_events()

    def flush_events(self) -> int:
        """Write buffered events to disk. Returns count written."""
        if not self._event_buffer and not self._tag_buffer:
            return 0
        events = self._event_buffer[:]
        tags = self._tag_buffer[:]
        self._event_buffer.clear()
        self._tag_buffer.clear()
        written = 0
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                if events:
                    conn.executemany(
                        """INSERT INTO journal_events
                           (session_id, timestamp_ms, wall_clock, event_type,
                            track_id, plugin_id, param_id,
                            value_float, value_int, value_text, meta_json)
                           VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
                        events,
                    )
                    written += len(events)
                if tags:
                    conn.executemany(
                        """INSERT INTO journal_tags
                           (session_id, timestamp_ms, wall_clock, tag_text,
                            confidence, source)
                           VALUES (?,?,?,?,?,?)""",
                        tags,
                    )
                conn.commit()
            finally:
                conn.close()
        except Exception as e:
            log.debug("[TimeTravelDB] flush_events failed: %s", e)
        return written

    # ══════════════════════════════════════════════════════════════
    # Snapshots
    # ══════════════════════════════════════════════════════════════

    def save_snapshot(self, session_id: str, timestamp_ms: int,
                       snapshot_json: str, track_count: int = 0,
                       clip_count: int = 0, bpm: float = 120.0,
                       label: str = "") -> int:
        """Save a full project state snapshot. Returns snapshot ID."""
        try:
            conn = self._conn()
            try:
                cur = conn.execute(
                    """INSERT INTO journal_snapshots
                       (session_id, timestamp_ms, wall_clock, snapshot_json,
                        track_count, clip_count, bpm, label)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                    (session_id, timestamp_ms, time.time(),
                     snapshot_json, track_count, clip_count, bpm, label),
                )
                conn.commit()
                return cur.lastrowid or 0
            finally:
                conn.close()
        except Exception as e:
            log.debug("[TimeTravelDB] save_snapshot failed: %s", e)
            return 0

    def get_snapshot_before(self, session_id: str,
                             timestamp_ms: int) -> Optional[dict]:
        """Get the latest snapshot BEFORE a given timestamp."""
        try:
            conn = self._conn()
            try:
                row = conn.execute(
                    """SELECT * FROM journal_snapshots
                       WHERE session_id=? AND timestamp_ms <= ?
                       ORDER BY timestamp_ms DESC LIMIT 1""",
                    (session_id, timestamp_ms),
                ).fetchone()
                return dict(row) if row else None
            finally:
                conn.close()
        except Exception:
            return None

    def get_snapshots(self, session_id: str,
                       limit: int = 50) -> List[dict]:
        """Get all snapshots for a session."""
        try:
            conn = self._conn()
            try:
                rows = conn.execute(
                    """SELECT id, session_id, timestamp_ms, wall_clock,
                              track_count, clip_count, bpm, label
                       FROM journal_snapshots
                       WHERE session_id=? ORDER BY timestamp_ms DESC LIMIT ?""",
                    (session_id, limit),
                ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    # ══════════════════════════════════════════════════════════════
    # Event Reading (für State Reconstruction)
    # ══════════════════════════════════════════════════════════════

    def get_events_in_range(self, session_id: str,
                              start_ms: int, end_ms: int,
                              event_type: str = "",
                              track_id: str = "") -> List[dict]:
        """Get events in a time range. Basis für State Reconstruction."""
        try:
            conn = self._conn()
            try:
                sql = ("SELECT * FROM journal_events "
                       "WHERE session_id=? AND timestamp_ms >= ? AND timestamp_ms <= ?")
                params: list = [session_id, start_ms, end_ms]
                if event_type:
                    sql += " AND event_type=?"
                    params.append(event_type)
                if track_id:
                    sql += " AND track_id=?"
                    params.append(track_id)
                sql += " ORDER BY timestamp_ms ASC"
                rows = conn.execute(sql, params).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    def get_events_last_n_minutes(self, session_id: str,
                                    minutes: int = DEFAULT_LOOKBACK_MINUTES,
                                    current_ms: Optional[int] = None) -> List[dict]:
        """Get events from the last N minutes. Default: 5 Minuten."""
        if current_ms is None:
            # Schätze aktuelle Position aus letztem Event
            try:
                conn = self._conn()
                try:
                    row = conn.execute(
                        "SELECT MAX(timestamp_ms) as m FROM journal_events WHERE session_id=?",
                        (session_id,),
                    ).fetchone()
                    current_ms = int(row["m"]) if row and row["m"] else 0
                finally:
                    conn.close()
            except Exception:
                current_ms = 0
        start_ms = max(0, current_ms - (minutes * 60 * 1000))
        return self.get_events_in_range(session_id, start_ms, current_ms)

    def get_param_state_at(self, session_id: str,
                             timestamp_ms: int) -> Dict[str, Dict[str, float]]:
        """Reconstruct parameter state at a given timestamp.

        Returns: {track_id: {param_id: value, ...}, ...}
        """
        # 1. Find latest snapshot before timestamp
        snapshot = self.get_snapshot_before(session_id, timestamp_ms)
        base_ms = 0
        state: Dict[str, Dict[str, float]] = {}

        if snapshot:
            base_ms = int(snapshot.get("timestamp_ms", 0))
            try:
                sj = json.loads(snapshot.get("snapshot_json", "{}"))
                # Extract param values from snapshot
                for track in sj.get("tracks", []):
                    tid = str(track.get("id", ""))
                    if tid:
                        state[tid] = {
                            "volume": float(track.get("volume", 0.8)),
                            "pan": float(track.get("pan", 0.0)),
                        }
            except Exception:
                pass

        # 2. Replay param_change events from snapshot to target time
        events = self.get_events_in_range(
            session_id, base_ms, timestamp_ms,
            event_type="param_change",
        )
        for ev in events:
            tid = ev.get("track_id", "")
            pid = ev.get("param_id", "")
            val = ev.get("value_float")
            if tid and pid and val is not None:
                if tid not in state:
                    state[tid] = {}
                state[tid][pid] = float(val)

        return state

    # ══════════════════════════════════════════════════════════════
    # Tags + FTS5 Suche
    # ══════════════════════════════════════════════════════════════

    def add_tag(self, session_id: str, timestamp_ms: int,
                 tag_text: str, confidence: float = 1.0,
                 source: str = "auto") -> None:
        """Buffer a tag. Flushed with flush_events()."""
        self._tag_buffer.append((
            session_id, int(timestamp_ms), time.time(),
            str(tag_text), float(confidence), str(source),
        ))

    def add_user_bookmark(self, session_id: str, timestamp_ms: int,
                           label: str = "") -> None:
        """Add a user-created bookmark (tagged as 'user')."""
        text = label or f"Bookmark @ {timestamp_ms // 1000}s"
        self.add_tag(session_id, timestamp_ms, text,
                      confidence=1.0, source="user")
        self.flush_events()

    def search_tags(self, query: str, limit: int = 30) -> List[dict]:
        """Search tags using FTS5 full-text search."""
        try:
            conn = self._conn()
            try:
                rows = conn.execute(
                    """SELECT jt.*, rank
                       FROM journal_tags_fts fts
                       JOIN journal_tags jt ON jt.id = fts.rowid
                       WHERE journal_tags_fts MATCH ?
                       ORDER BY rank
                       LIMIT ?""",
                    (query, limit),
                ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    def search_tags_in_timerange(self, query: str,
                                   after_wall_clock: float = 0,
                                   before_wall_clock: float = 0,
                                   limit: int = 30) -> List[dict]:
        """Search tags with time filter (wall clock for cross-session)."""
        try:
            conn = self._conn()
            try:
                sql = """SELECT jt.*, rank
                         FROM journal_tags_fts fts
                         JOIN journal_tags jt ON jt.id = fts.rowid
                         WHERE journal_tags_fts MATCH ?"""
                params: list = [query]
                if after_wall_clock > 0:
                    sql += " AND jt.wall_clock >= ?"
                    params.append(after_wall_clock)
                if before_wall_clock > 0:
                    sql += " AND jt.wall_clock <= ?"
                    params.append(before_wall_clock)
                sql += " ORDER BY rank LIMIT ?"
                params.append(limit)
                rows = conn.execute(sql, params).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    # ══════════════════════════════════════════════════════════════
    # Audio Fingerprints
    # ══════════════════════════════════════════════════════════════

    def save_audio_fingerprint(self, session_id: str, timestamp_ms: int,
                                 fingerprint: bytes, track_id: str = "",
                                 spectral_centroid: float = 0,
                                 rms_db: float = -60,
                                 dominant_pitch: float = 0) -> None:
        """Save an audio fingerprint."""
        try:
            conn = self._conn()
            try:
                conn.execute(
                    """INSERT INTO journal_audio_fp
                       (session_id, timestamp_ms, track_id, fingerprint,
                        spectral_centroid, rms_db, dominant_pitch)
                       VALUES (?, ?, ?, ?, ?, ?, ?)""",
                    (session_id, timestamp_ms, track_id, fingerprint,
                     spectral_centroid, rms_db, dominant_pitch),
                )
                conn.commit()
            finally:
                conn.close()
        except Exception as e:
            log.debug("[TimeTravelDB] save_audio_fingerprint failed: %s", e)

    # ══════════════════════════════════════════════════════════════
    # Branches (Git-Style Undo Tree)
    # ══════════════════════════════════════════════════════════════

    def create_branch(self, session_id: str, branch_name: str,
                        fork_timestamp_ms: int, snapshot_id: int = 0,
                        parent_branch_id: Optional[int] = None,
                        description: str = "") -> int:
        """Create a new branch. Returns branch ID."""
        try:
            conn = self._conn()
            try:
                cur = conn.execute(
                    """INSERT INTO journal_branches
                       (session_id, branch_name, parent_branch_id,
                        fork_timestamp_ms, snapshot_id, is_active,
                        created_at, description)
                       VALUES (?, ?, ?, ?, ?, 0, ?, ?)""",
                    (session_id, branch_name, parent_branch_id,
                     fork_timestamp_ms, snapshot_id, time.time(),
                     description),
                )
                conn.commit()
                return cur.lastrowid or 0
            finally:
                conn.close()
        except Exception:
            return 0

    def get_branches(self, session_id: str) -> List[dict]:
        """Get all branches for a session."""
        try:
            conn = self._conn()
            try:
                rows = conn.execute(
                    "SELECT * FROM journal_branches WHERE session_id=? ORDER BY created_at",
                    (session_id,),
                ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    # ══════════════════════════════════════════════════════════════
    # Sound DNA (Cross-Projekt)
    # ══════════════════════════════════════════════════════════════

    def save_sound_dna(self, project_path: str, track_id: str,
                         plugin_id: str, param_hash: str,
                         preset_name: str = "",
                         fingerprint: Optional[bytes] = None,
                         tags: str = "") -> None:
        """Save a Sound DNA entry."""
        try:
            conn = self._conn()
            try:
                conn.execute(
                    """INSERT INTO sound_dna
                       (project_path, track_id, plugin_id, preset_name,
                        param_hash, fingerprint, tags, created_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                       ON CONFLICT(project_path, track_id, param_hash)
                       DO UPDATE SET
                           fingerprint=excluded.fingerprint,
                           tags=excluded.tags,
                           preset_name=excluded.preset_name""",
                    (project_path, track_id, plugin_id, preset_name,
                     param_hash, fingerprint, tags, time.time()),
                )
                conn.commit()
            finally:
                conn.close()
        except Exception as e:
            log.debug("[TimeTravelDB] save_sound_dna failed: %s", e)

    def find_similar_sounds(self, plugin_id: str,
                              limit: int = 20) -> List[dict]:
        """Find Sound DNA entries for the same plugin."""
        try:
            conn = self._conn()
            try:
                rows = conn.execute(
                    "SELECT * FROM sound_dna WHERE plugin_id=? ORDER BY created_at DESC LIMIT ?",
                    (plugin_id, limit),
                ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    # ══════════════════════════════════════════════════════════════
    # Maintenance
    # ══════════════════════════════════════════════════════════════

    def prune_old_sessions(self, max_age_days: int = DEFAULT_MAX_SESSION_AGE_DAYS) -> int:
        """Remove sessions older than max_age_days."""
        cutoff = time.time() - (max_age_days * 86400)
        removed = 0
        try:
            conn = self._conn()
            try:
                # Find old session IDs
                old = conn.execute(
                    "SELECT id FROM journal_sessions WHERE started_at < ?",
                    (cutoff,),
                ).fetchall()
                old_ids = [r["id"] for r in old]
                if old_ids:
                    placeholders = ",".join("?" * len(old_ids))
                    for table in ("journal_events", "journal_snapshots",
                                   "journal_tags", "journal_audio_fp",
                                   "journal_branches"):
                        conn.execute(
                            f"DELETE FROM {table} WHERE session_id IN ({placeholders})",
                            old_ids,
                        )
                    conn.execute(
                        f"DELETE FROM journal_sessions WHERE id IN ({placeholders})",
                        old_ids,
                    )
                    conn.commit()
                    removed = len(old_ids)
                    log.info("[TimeTravelDB] Pruned %d old sessions", removed)
            finally:
                conn.close()
        except Exception as e:
            log.debug("[TimeTravelDB] prune failed: %s", e)
        return removed

    def stats(self) -> Dict[str, Any]:
        """Return statistics."""
        result: Dict[str, Any] = {}
        try:
            conn = self._conn()
            try:
                for table in ("journal_sessions", "journal_events",
                               "journal_snapshots", "journal_tags",
                               "journal_audio_fp", "journal_branches",
                               "sound_dna"):
                    row = conn.execute(
                        f"SELECT COUNT(*) as cnt FROM {table}"
                    ).fetchone()
                    result[table] = int(row["cnt"]) if row else 0
            finally:
                conn.close()
        except Exception:
            pass
        return result
