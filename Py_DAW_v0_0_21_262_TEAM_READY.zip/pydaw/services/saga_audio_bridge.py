"""
pydaw.services.saga_audio_bridge — Track-Meter → Saga.Magic Audio-Reaktivität
==============================================================================

**v0.0.21.209 — Anno's Wunsch: „das herz reagiert nicht wenn modul angeschlossen
ist — wenn ströme durch kommen verändert es sich nicht es müsste KI-unterstützt
sein 3D, größe ändern usw."**

**v0.0.21.211 — Saga S-0b (Python-Edition / NICHTS-KAPUTT-Variante):**
Die Crest-Faktor-Centroid-Approximation aus v.209 wird durch eine
**echte FFT-256-Spectral-Centroid** ersetzt — siehe ``saga_fft_analyzer``.
Der Bridge peekt non-destructive den Master-Audio-Ring (HybridEngineBridge),
rechnet eine FFT pro Tick (~30/s, ~50 µs jeweils) und füttert die Saga-
Module mit echten spektralen Features. Crest-Faktor bleibt als Fallback,
wenn keine Audio-Daten erreichbar sind (z.B. reiner Rust-Render-Pfad).

Die Saga.Magic-Visualisierung hat seit v.202 die ``audio_react``-Property
und der ``SagaShapeSampler`` hat seit v.202 die ``update_audio_features()``-
Methode. Aber **niemand hat sie je aufgerufen** — die im Manifest geplante
Rust-IPC-Schicht (S-0b, ``/tmp/pydaw_saga.sock``) wurde nie implementiert.
Resultat: das Herz dreht sich (Aurora-Drift), aber pulsiert nicht mit dem
Audio. Das ist genau Annos Beschwerde.

Diese Bridge schließt die Lücke **ohne Rust-Änderung**:

  Rust ── MeterLevels Event ─→ rust_engine_bridge.track_meters_changed
        (per-track peak_l/peak_r/rms_l/rms_r, ~30 Hz)
                                                │
                                                ▼
                          SagaAudioBridge.on_track_meters()
                                                │
                                                ▼  (v.211)
                          peek master_ring  →  SagaFFTAnalyzer.analyze()
                          → SagaSpectralFeatures (echte FFT-Centroid)
                                                │
                                                ▼
                  SagaRendererProxy.update_audio_features(
                      mod_id, rms=…, centroid=…, onset=…)
                                                │
                                                ▼
                  SagaShapeSampler picks up rms/onset, the next
                  sample_points() expands radial_scale → Heart beats.

Das funktioniert mit den schon vorhandenen Per-Track-Meter-Events der
Rust-Engine — keine neue IPC, kein Rust-Rebuild.

**KI-Unterstützung-Stufen:**

* **v.209 (Crest-Faktor):** Centroid ≈ peak/rms. Visuell überzeugend,
  spektral nicht korrekt.
* **v.211 (FFT-256):** Centroid = Σ(f_i·|X_i|)/Σ|X_i| auf Hanning-
  fenstrierten 256-Sample-Block der Master-Ausgabe. Spektral korrekt,
  log-normiert auf [80 Hz..8 kHz] für stabiles Visual-Feedback.
* **Per-Modul-Modulation:** der globale FFT-Centroid wird mit der
  per-Track-RMS gewichtet. Stille Track → smoothed neutral 0.5.
  Lauter Track → übernimmt das Master-Centroid 1:1. Mehrere aktive
  Tracks → Mix-gewichteter Wert (akzeptabel, da Saga-Module sowieso
  einen Track-Audio-Pfad teilen, nicht echtes Per-Track-Spektrum
  anzeigen).
* **(Zukünftig) Rust-IPC:** wenn der Engine-Build-Pfad verfügbar wird,
  ersetzt eine 1-Zeilen-Schaltung das Python-Analyze() durch ein Rust-
  IPC-Recv. Die Datenklasse ``SagaSpectralFeatures`` ist die gleiche.

**NICHTS-KAPUTT-Pakt:**

  * Bridge ist Opt-In — nur aktiv wenn ``rust_engine_bridge`` vorhanden ist.
  * Verwendet Soft-Imports — Saga-Module ohne diese Bridge funktionieren
    weiter (nur ohne Audio-Reaktivität, wie vor v.209).
  * Keine Rust-Änderung — Bridge nutzt nur die schon emittierten
    ``MeterLevels``-Events.
  * Keine Performance-Last — die Bridge tickt mit der Engine-Meter-Rate
    (~30 Hz), nicht mit der UI-Repaint-Rate (~60 Hz).
  * **v.211:** FFT-Pfad ist additiv. Wenn Master-Ring leer ist, wenn
    ``peek_recent`` None liefert, wenn ``analyze`` is_valid=False zurückgibt,
    fällt der Bridge auf den v.209-Crest-Faktor zurück. Damit ist die
    Sound-Stabilität strikt erhalten.

**Lifecycle:**

  * ``get_saga_audio_bridge()`` → Singleton (Lazy-Init).
  * ``bridge.bind(audio_engine, project_service, flux_main_widget)`` →
    verbindet die Track-Meter-Pipeline.
  * Bei FLUX-Patch-Wechsel ruft ``flux_main_widget`` automatisch
    ``bridge.refresh_module_track_map()`` damit neu hinzugefügte/
    entfernte Saga.Magic-Module die richtigen Track-Peaks bekommen.
"""
from __future__ import annotations

import logging
import time
from typing import Any, Optional


logger = logging.getLogger(__name__)


# ─── Helper: per-Modul-State für Onset-Detection + Smoothing ───


class _SagaModuleAudioState:
    """Pro-Saga.Magic-Modul-Zustand für die Audio-Feature-Ableitung.

    Hält:
      * track_id              — welche Track-Peaks gehören zu mir?
      * last_rms              — letzter RMS-Wert für Δ-Berechnung
      * onset_pulse           — aktueller Burst-Wert (decay 0.85/tick)
      * smoothed_rms          — exponentiell geglätteter RMS für Flatness
      * smoothed_centroid     — Glättung der billigen Peak/RMS-Schätzung
    """

    __slots__ = (
        "track_id",
        "last_rms",
        "onset_pulse",
        "smoothed_rms",
        "smoothed_centroid",
        "last_update_ts",
    )

    def __init__(self, track_id: str = "") -> None:
        self.track_id = track_id
        self.last_rms: float = 0.0
        self.onset_pulse: float = 0.0
        self.smoothed_rms: float = 0.0
        self.smoothed_centroid: float = 0.5
        self.last_update_ts: float = 0.0


# ─── Bridge ─────────────────────────────────────────────────────


class SagaAudioBridge:
    """Routet Track-Meter-Events zu allen registrierten Saga.Magic-Modulen.

    Der Bridge hat keinen eigenen Timer. Er reagiert reaktiv auf:
      1. ``track_meters_changed``-Signal vom rust_engine_bridge (Rust-Pfad)
      2. ``master_meter_changed``-Signal (Fallback wenn keine per-Track-Meter)

    Die Modul-zu-Track-Zuordnung wird beim Patch-Bind aktualisiert
    (``refresh_module_track_map``). Pro Modul gibt's einen
    ``_SagaModuleAudioState`` der RMS-Δ → Onset und Smoothing-Werte
    berechnet.

    **Onset-Algorithmus (billig aber wirksam):**

      Δrms = current_rms - last_rms
      if Δrms > ONSET_THRESHOLD (0.08):
          onset_pulse = min(1.0, onset_pulse + (Δrms - 0.08) * 4.0)
      else:
          onset_pulse *= ONSET_DECAY (0.85)

    Das gibt einen schönen „atmenden Beat"-Effekt bei perkussivem Material
    und sanftere Pulse bei Pads/Drones. Genau das was die radial_scale-
    Animation in shape_sampler.sample_points() braucht.
    """

    # Klassenkonstanten — Tunable
    ONSET_THRESHOLD = 0.08      # RMS-Sprung der als Onset zählt
    ONSET_RISE_GAIN = 4.0       # Verstärkung über dem Threshold
    ONSET_DECAY = 0.85          # exp. Decay/Tick (~30 Hz → ~6 ticks bis 33%)
    RMS_SMOOTH = 0.7            # IIR-Koeff für smoothed_rms (höher = träger)
    CENTROID_SMOOTH = 0.85      # IIR-Koeff für smoothed_centroid

    # v0.0.21.211 — FFT-Pfad-Tunables
    FFT_PEEK_FRAMES = 512       # Wieviele Master-Ring-Samples peeken (>= 256)
    FFT_TRACK_RMS_GATE = 0.005  # Track-RMS unter diesem Wert → kein FFT-Override
    FFT_NEUTRAL_CENTROID = 0.5  # Bei Stille: smoothed_centroid pendelt zu 0.5

    def __init__(self) -> None:
        self._audio_engine: Optional[Any] = None
        self._project_service: Optional[Any] = None
        self._flux_main_widget: Optional[Any] = None
        self._rust_bridge: Optional[Any] = None

        # v0.0.21.211 — FFT-Analyzer für echte Spectral-Centroid.
        # Lazy-Init: nur instanziieren wenn die FFT-Pipeline tatsächlich
        # gebraucht wird (also bei erstem Tick mit aktiven Modulen).
        self._fft_analyzer: Optional[Any] = None
        # Cached Features vom letzten erfolgreichen FFT-Pass dieses Ticks.
        # Wird einmal pro `_on_track_meters` befüllt und für ALLE Module
        # in diesem Tick wiederverwendet (eine FFT pro Tick, nicht pro Modul).
        self._tick_fft_features: Optional[Any] = None
        # Diagnose: wie oft hat der FFT-Pfad gegriffen vs. Fallback?
        self._fft_hits: int = 0
        self._fft_misses: int = 0

        # mod_id → _SagaModuleAudioState
        self._module_states: dict[str, _SagaModuleAudioState] = {}

        # track_idx → track_id (gefüllt aus letztem track_meters-Update;
        # billiger als jedes Mal die ganze project.tracks-Liste laufen)
        self._track_idx_to_id: dict[int, str] = {}

        # Wurden die Signale schon angeschlossen?
        self._connected: bool = False

        # Diagnose-Counter
        self._tick_count: int = 0
        self._update_count: int = 0
        self._last_log_ts: float = 0.0

    # ─── Bind-API ───────────────────────────────────────────────

    def bind(
        self,
        audio_engine: Any = None,
        project_service: Any = None,
        flux_main_widget: Any = None,
    ) -> None:
        """Bindet den Bridge an die Service-Instances.

        Idempotent: kann mehrfach aufgerufen werden (bei jedem
        ServiceContainer-Init z.B.). Reconnects Signale nur einmal.
        """
        if audio_engine is not None:
            self._audio_engine = audio_engine
        if project_service is not None:
            self._project_service = project_service
        if flux_main_widget is not None:
            self._flux_main_widget = flux_main_widget

        if self._connected:
            return

        # rust_engine_bridge holen — der ist im audio_engine als Attribut
        # nach der R1-Hybrid-Setup-Phase verfügbar.
        rb = self._resolve_rust_bridge()
        if rb is None:
            logger.debug(
                "[SagaAudioBridge] no rust_engine_bridge yet — "
                "will retry on next bind() call"
            )
            return

        try:
            rb.track_meters_changed.connect(self._on_track_meters)
            rb.master_meter_changed.connect(self._on_master_meter)
            self._rust_bridge = rb
            self._connected = True
            logger.info(
                "[SagaAudioBridge] connected to rust_engine_bridge "
                "(track_meters + master_meter)"
            )
        except Exception as e:
            logger.warning(
                "[SagaAudioBridge] connect failed: %s", e
            )

    def _resolve_rust_bridge(self) -> Optional[Any]:
        """Versucht, den rust_engine_bridge zu finden. Mehrere Pfade
        werden probiert (verschiedene App-Versionen halten ihn an
        unterschiedlichen Stellen)."""
        ae = self._audio_engine
        if ae is None:
            return None

        for attr in (
            "_rust_bridge",
            "rust_bridge",
            "_rust_engine_bridge",
            "rust_engine_bridge",
        ):
            rb = getattr(ae, attr, None)
            if rb is not None:
                return rb

        # Fallback: Modul-Singleton (manche Code-Pfade halten einen)
        try:
            from pydaw.services.rust_engine_bridge import (
                get_rust_engine_bridge as _get,  # type: ignore
            )
            return _get()
        except Exception:
            pass
        try:
            from pydaw.services import rust_engine_bridge as _rebmod
            for attr in ("_INSTANCE", "_BRIDGE_INSTANCE", "BRIDGE"):
                inst = getattr(_rebmod, attr, None)
                if inst is not None:
                    return inst
        except Exception:
            pass
        return None

    # ─── v0.0.21.211 — FFT-Pfad-Helper ───────────────────────────

    def _resolve_master_ring(self) -> Optional[Any]:
        """Sucht den Master-Audio-Ring im HybridEngineBridge.

        Verwendet vier Lookup-Pfade in absteigender Spezifität:
          1. ``audio_engine.hybrid_bridge.meter_ring`` (Property in v0.0.20.14+)
          2. ``audio_engine._hybrid_bridge.meter_ring`` (Backing-Field)
          3. ``audio_engine.hybrid_bridge._meter_ring`` (privater Pfad)
          4. ``audio_engine._hybrid_bridge._meter_ring``

        Returns:
            ``AudioRingBuffer``-Instance oder None wenn nichts gefunden.
            None ist KEIN Fehler — die Bridge fällt dann auf den
            Crest-Faktor-Pfad zurück (v.209-Verhalten).
        """
        ae = self._audio_engine
        if ae is None:
            return None
        for hb_attr, mr_attr in (
            ("hybrid_bridge", "meter_ring"),
            ("_hybrid_bridge", "meter_ring"),
            ("hybrid_bridge", "_meter_ring"),
            ("_hybrid_bridge", "_meter_ring"),
        ):
            try:
                hb = getattr(ae, hb_attr, None)
                if hb is None:
                    continue
                ring = getattr(hb, mr_attr, None)
                if ring is None:
                    continue
                # Smoke-Check: das Ring muss `peek_recent` haben (v.211+).
                if not hasattr(ring, "peek_recent"):
                    continue
                return ring
            except Exception:
                continue
        return None

    def _ensure_fft_analyzer(self) -> Optional[Any]:
        """Lazy-Init des FFT-Analyzers. Liefert None wenn numpy fehlt
        oder das Modul nicht importierbar ist (defensiv)."""
        if self._fft_analyzer is not None:
            return self._fft_analyzer
        try:
            from pydaw.services.saga_fft_analyzer import (
                SagaFFTAnalyzer,
                DEFAULT_SAMPLE_RATE,
            )
            # Sample-Rate aus Engine ziehen falls verfügbar
            sr = DEFAULT_SAMPLE_RATE
            ae = self._audio_engine
            if ae is not None:
                for attr in ("sample_rate", "_sample_rate"):
                    try:
                        v = getattr(ae, attr, None)
                        if v is not None:
                            sr = int(v)
                            break
                    except Exception:
                        continue
            self._fft_analyzer = SagaFFTAnalyzer(sample_rate=sr)
            logger.info(
                "[SagaAudioBridge] FFT-256 analyzer initialized (sr=%d) — "
                "echte Spectral-Centroid aktiv",
                sr,
            )
            return self._fft_analyzer
        except Exception as e:
            logger.debug(
                "[SagaAudioBridge] FFT-Analyzer nicht verfügbar (Fallback aktiv): %s",
                e,
            )
            return None

    def _compute_tick_fft(self) -> None:
        """Pro Tick einmal: peek den Master-Ring und rechne die FFT.

        Das Ergebnis wird in ``self._tick_fft_features`` gecached und
        steht allen Modulen in diesem Tick zur Verfügung. Wenn nichts
        gepeekt werden kann (kein Ring, leerer Ring, numpy fehlt),
        bleibt ``_tick_fft_features = None`` und ``_compute_and_push``
        nutzt automatisch den Crest-Faktor-Fallback.
        """
        self._tick_fft_features = None  # Reset für diesen Tick
        ring = self._resolve_master_ring()
        if ring is None:
            self._fft_misses += 1
            return
        analyzer = self._ensure_fft_analyzer()
        if analyzer is None:
            self._fft_misses += 1
            return
        try:
            block = ring.peek_recent(self.FFT_PEEK_FRAMES)
            if block is None:
                self._fft_misses += 1
                return
            features = analyzer.analyze(block)
            if not features.is_valid:
                # Stille / zu kurz / NaN — Fallback aktiv
                self._fft_misses += 1
                return
            self._tick_fft_features = features
            self._fft_hits += 1
        except Exception as e:
            self._fft_misses += 1
            logger.debug("[SagaAudioBridge] _compute_tick_fft failed: %s", e)

    # ─── Modul-Track-Mapping ────────────────────────────────────

    def refresh_module_track_map(self) -> int:
        """Liest aus dem aktuellen FLUX-Projekt die Saga.Magic-Module
        und ihre zugehörigen Tracks. Wird vom flux_main_widget bei
        Patch-Wechsel oder Patch-Save aufgerufen.

        Returns
        -------
        Anzahl gefundener Saga.Magic-Module.
        """
        if self._project_service is None:
            return 0
        try:
            project = self._project_service.ctx.project
        except Exception:
            return 0

        # Patches im Projekt: typischerweise in `project.flux_patches`
        # oder über `flux_patch_service.get_assignments(project)`.
        # Wir nehmen den robustesten Pfad: über den Service.
        try:
            from pydaw.services.flux_patch_service import (
                get_flux_patch_service,
            )
            svc = get_flux_patch_service()
        except Exception:
            return 0

        # Sammeln: track_id → Liste der Saga.Magic-Modul-IDs
        new_states: dict[str, _SagaModuleAudioState] = {}
        try:
            tracks = list(getattr(project, "tracks", []) or [])
            for track in tracks:
                tid = str(getattr(track, "id", ""))
                if not tid:
                    continue
                try:
                    patch = svc.patch_for_track(project, tid)
                except Exception:
                    patch = None
                if patch is None:
                    continue
                modules = getattr(patch, "modules", None) or []
                for mod in modules:
                    try:
                        if (str(getattr(mod, "god", "")) == "Saga"
                                and str(getattr(mod, "kind", "")) == "Magic"):
                            mid = str(getattr(mod, "id", ""))
                            if not mid:
                                continue
                            # Behalten wenn schon existiert (state preserved)
                            old = self._module_states.get(mid)
                            if old is not None:
                                old.track_id = tid
                                new_states[mid] = old
                            else:
                                new_states[mid] = _SagaModuleAudioState(
                                    track_id=tid,
                                )
                    except Exception as e:
                        logger.debug(
                            "[SagaAudioBridge] module scan failed: %s", e
                        )
        except Exception as e:
            logger.debug(
                "[SagaAudioBridge] refresh_module_track_map failed: %s", e
            )

        self._module_states = new_states
        logger.debug(
            "[SagaAudioBridge] track-map refreshed: %d Saga.Magic modules",
            len(new_states),
        )
        return len(new_states)

    # ─── Slot-Handler: Track-Meter-Events ───────────────────────

    def _on_track_meters(self, meters: list) -> None:
        """Wird vom rust_engine_bridge bei jedem MeterLevels-Event
        gerufen (~30 Hz). meters ist eine Liste von Tupeln:
        [(track_index, peak_l, peak_r, rms_l, rms_r), …]
        """
        self._tick_count += 1

        if not self._module_states:
            return  # nichts zu tun

        # v0.0.21.211 — eine FFT pro Tick (nicht pro Modul). Wenn die
        # FFT erfolgreich ist, wird ``self._tick_fft_features`` gesetzt
        # und ``_compute_and_push`` benutzt den echten Spectral-Centroid.
        # Ansonsten (z.B. reiner Rust-Render-Pfad ohne Master-Ring,
        # numpy fehlt, Stille) bleibt der v.209-Crest-Faktor aktiv.
        self._compute_tick_fft()

        # 1. track_idx → track_id Map auffrischen (lazy: nur wenn Größe stimmt)
        if (self._project_service is not None
                and len(self._track_idx_to_id) != len(meters)):
            try:
                project = self._project_service.ctx.project
                tracks = list(getattr(project, "tracks", []) or [])
                self._track_idx_to_id = {
                    i: str(getattr(t, "id", ""))
                    for i, t in enumerate(tracks)
                    if getattr(t, "id", None)
                }
            except Exception:
                pass

        # 2. Pro Meter-Eintrag: track_id finden, Module suchen, Update senden
        try:
            from pydaw.flux.saga.renderer_proxy import (
                get_saga_renderer_proxy,
            )
            proxy = get_saga_renderer_proxy()
        except Exception:
            return

        # Schneller Lookup: track_id → Liste der mod_ids
        # (Bei wenigen Saga-Modulen — typisch 1-3 — ist die direkte
        # Iteration billig genug.)
        for entry in meters:
            try:
                if not isinstance(entry, (list, tuple)) or len(entry) < 3:
                    continue
                idx = int(entry[0])
                peak_l = float(entry[1])
                peak_r = float(entry[2])
                rms_l = float(entry[3]) if len(entry) > 3 else peak_l * 0.7
                rms_r = float(entry[4]) if len(entry) > 4 else peak_r * 0.7
            except Exception:
                continue

            tid = self._track_idx_to_id.get(idx, "")
            if not tid:
                continue

            # Mittel über L/R (Saga.Magic ist Mono-Visual)
            peak = max(peak_l, peak_r)
            rms = (rms_l + rms_r) * 0.5
            # Clamping (defensive — Engine sollte schon clampen)
            if peak < 0.0:
                peak = 0.0
            elif peak > 1.0:
                peak = 1.0
            if rms < 0.0:
                rms = 0.0
            elif rms > 1.0:
                rms = 1.0

            # Alle Module die zu dieser Track gehören finden
            for mid, st in self._module_states.items():
                if st.track_id != tid:
                    continue
                self._compute_and_push(proxy, mid, st, rms, peak)

    def _on_master_meter(
        self, peak_l: float, peak_r: float,
        rms_l: float = 0.0, rms_r: float = 0.0,
    ) -> None:
        """Master-Meter-Fallback. Wird derzeit nur als Diagnose genutzt —
        eine echte „Master-Saga" gibt's nicht (Saga.Magic sitzt immer
        auf einer konkreten Track). Hook bleibt für zukünftige Master-
        FX-Kette bereit.
        """
        # Aktuell ein No-Op. Wenn wir je eine Saga ohne Track-Bindung
        # haben (z.B. „Master-Visual"), könnte hier das Default-State
        # gefüttert werden.
        return

    def _compute_and_push(
        self,
        proxy: Any,
        mod_id: str,
        st: _SagaModuleAudioState,
        rms: float,
        peak: float,
    ) -> None:
        """Kernlogik: aus rms/peak die vier Sampler-Features ableiten und
        zum Proxy schicken.
        """
        # 1. Onset-Detection — schneller RMS-Anstieg = onset
        delta = rms - st.last_rms
        if delta > self.ONSET_THRESHOLD:
            st.onset_pulse = min(
                1.0,
                st.onset_pulse + (delta - self.ONSET_THRESHOLD) * self.ONSET_RISE_GAIN,
            )
        else:
            st.onset_pulse *= self.ONSET_DECAY
        # Floor — sehr kleine Werte verhindern Float-Denormals
        if st.onset_pulse < 0.001:
            st.onset_pulse = 0.0

        # 2. Smoothed RMS für Flatness-Schätzung
        st.smoothed_rms = (
            st.smoothed_rms * self.RMS_SMOOTH
            + rms * (1.0 - self.RMS_SMOOTH)
        )

        # 3. Centroid-Schätzung — v0.0.21.211: echte FFT-256 wenn verfügbar.
        #
        # Hierarchie (von präzise nach fallback):
        #   (a) Tick-FFT erfolgreich UND Track laut genug → echter Spectral-Centroid
        #   (b) Tick-FFT erfolgreich UND Track leise → smoothed_centroid driftet
        #       sanft Richtung neutral 0.5 (stille Tracks zeigen ruhiges Visual)
        #   (c) Kein Tick-FFT → Crest-Faktor wie v.209 (Backward-Compat)
        #
        # Warum die per-Track-Gate? Der Master-FFT ist mix-gewichtet. Wenn
        # Track A laut spielt und Track B still ist, würde B trotzdem den
        # FFT-Centroid von A „sehen" — visuell falsch. Mit dem Gate
        # bleibt das Saga-Visual eines stillen Tracks ruhig.
        fft_features = self._tick_fft_features
        if fft_features is not None and fft_features.is_valid:
            if rms >= self.FFT_TRACK_RMS_GATE:
                # Echter FFT-Centroid für aktive Tracks.
                centroid = float(fft_features.centroid)
            else:
                # Stiller Track im Mix — driftet zu Neutral.
                centroid = self.FFT_NEUTRAL_CENTROID
        else:
            # Fallback: Crest-Faktor (v.209-Verhalten).
            # Peak/RMS = 1.0 (Sinus) → centroid 0.0; 5.0+ (transient) → 1.0.
            if st.smoothed_rms > 0.005:
                crest = peak / st.smoothed_rms
                # Clamping & Normierung: 1.0..5.0 → 0.0..1.0
                centroid = max(0.0, min(1.0, (crest - 1.0) * 0.25))
            else:
                centroid = 0.5  # Stille → neutral
        st.smoothed_centroid = (
            st.smoothed_centroid * self.CENTROID_SMOOTH
            + centroid * (1.0 - self.CENTROID_SMOOTH)
        )

        # 4. Flatness — v0.0.21.211: echte spektrale Flatness wenn FFT lief,
        # sonst RMS-Variabilität als Approximation (wie v.209).
        if (fft_features is not None and fft_features.is_valid
                and rms >= self.FFT_TRACK_RMS_GATE):
            flatness = float(fft_features.flatness)
        elif st.smoothed_rms > 0.005:
            flatness = abs(rms - st.smoothed_rms) / st.smoothed_rms
            flatness = max(0.0, min(1.0, flatness * 0.5))
        else:
            flatness = 0.0

        # State updaten
        st.last_rms = rms
        st.last_update_ts = time.monotonic()

        # Push zum Proxy — der invalidiert dann seinen Pixmap-Cache
        # falls die Audio-Buckets sich geändert haben (siehe v.209
        # update_audio_features).
        try:
            proxy.update_audio_features(
                mod_id,
                rms=rms,
                centroid=st.smoothed_centroid,
                flatness=flatness,
                onset=st.onset_pulse,
            )
            self._update_count += 1
        except Exception as e:
            logger.debug(
                "[SagaAudioBridge] update_audio_features failed for %s: %s",
                mod_id, e,
            )

        # Periodische Diagnose-Logs (alle ~5 Sekunden)
        now = time.monotonic()
        if now - self._last_log_ts > 5.0 and self._update_count > 0:
            self._last_log_ts = now
            # v0.0.21.211 — auch FFT-Hit/Miss-Verhältnis ausgeben.
            total_fft_attempts = self._fft_hits + self._fft_misses
            fft_pct = (
                (self._fft_hits * 100.0 / total_fft_attempts)
                if total_fft_attempts > 0 else 0.0
            )
            logger.debug(
                "[SagaAudioBridge] %d ticks, %d updates, %d modules — "
                "rms=%.3f peak=%.3f onset=%.3f centroid=%.3f "
                "[FFT %d/%d hits = %.1f%%]",
                self._tick_count, self._update_count,
                len(self._module_states),
                rms, peak, st.onset_pulse, st.smoothed_centroid,
                self._fft_hits, total_fft_attempts, fft_pct,
            )

    # ─── Diagnose ───────────────────────────────────────────────

    def diagnose(self) -> dict:
        """Snapshot für Debug-Tools / SENTINEL."""
        # v0.0.21.211 — FFT-Diagnose mit aufnehmen.
        fft_diag: dict = {}
        try:
            if self._fft_analyzer is not None:
                fft_diag = self._fft_analyzer.diagnose()
        except Exception:
            fft_diag = {}
        return {
            "connected": self._connected,
            "modules_tracked": len(self._module_states),
            "tick_count": self._tick_count,
            "update_count": self._update_count,
            "track_idx_count": len(self._track_idx_to_id),
            "fft_hits": self._fft_hits,
            "fft_misses": self._fft_misses,
            "fft_analyzer": fft_diag,
            "modules": {
                mid: {
                    "track_id": st.track_id,
                    "last_rms": round(st.last_rms, 4),
                    "onset_pulse": round(st.onset_pulse, 4),
                    "smoothed_centroid": round(st.smoothed_centroid, 4),
                }
                for mid, st in self._module_states.items()
            },
        }


# ─── Singleton ───────────────────────────────────────────────────


_BRIDGE_INSTANCE: Optional[SagaAudioBridge] = None


def get_saga_audio_bridge() -> SagaAudioBridge:
    """Liefert die Prozess-globale ``SagaAudioBridge``-Instance.
    Lazy-Init beim ersten Zugriff.
    """
    global _BRIDGE_INSTANCE
    if _BRIDGE_INSTANCE is None:
        _BRIDGE_INSTANCE = SagaAudioBridge()
    return _BRIDGE_INSTANCE


__all__ = [
    "SagaAudioBridge",
    "get_saga_audio_bridge",
]
