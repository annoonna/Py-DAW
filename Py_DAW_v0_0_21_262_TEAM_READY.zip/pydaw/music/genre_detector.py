"""Genre Detector (P2B) — Offline genre classification from MIDI + audio.

Pure Python + optional numpy. No ML dependencies.
Works on MIDI notes and/or audio feature vectors.

Features:
- Genre classification from MIDI patterns (rhythm + harmony heuristics)
- Audio genre hints from spectral/dynamic features
- Confidence scores and similarity percentages
- Multi-genre detection (primary + secondary)

v0.0.20.809 — Phase P2B
"""

from __future__ import annotations

import logging
import math
from collections import Counter
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Tuple, Any

log = logging.getLogger(__name__)

try:
    import numpy as np
except Exception:
    np = None  # type: ignore


# ---------------------------------------------------------------------------
# Genre profiles: characteristic feature ranges
# ---------------------------------------------------------------------------

@dataclass
class GenreProfile:
    """Statistical profile for a genre, used for matching."""
    name: str
    # Rhythm
    bpm_range: Tuple[float, float] = (60.0, 200.0)
    density_range: Tuple[float, float] = (0.0, 20.0)  # notes per beat
    swing_range: Tuple[float, float] = (0.0, 1.0)
    syncopation_range: Tuple[float, float] = (0.0, 1.0)
    dominant_subdivision: str = "8th"  # "4th"|"8th"|"16th"|"triplet"
    # Harmony
    prefer_major: bool = True
    chord_complexity: float = 0.5  # 0=triads 1=extended/jazz
    typical_intervals: List[int] = field(default_factory=list)
    # Spectral (audio)
    low_energy_range: Tuple[float, float] = (0.0, 1.0)
    mid_energy_range: Tuple[float, float] = (0.0, 1.0)
    high_energy_range: Tuple[float, float] = (0.0, 1.0)
    dynamic_range_db: Tuple[float, float] = (3.0, 30.0)
    tags: List[str] = field(default_factory=list)


# ── Genre Database ────────────────────────────────────────────────────────

_GENRE_PROFILES: List[GenreProfile] = [
    GenreProfile(
        name="Techno",
        bpm_range=(120.0, 150.0), density_range=(3.0, 10.0),
        swing_range=(0.0, 0.1), syncopation_range=(0.1, 0.5),
        dominant_subdivision="16th", prefer_major=False,
        chord_complexity=0.2, low_energy_range=(0.3, 0.6),
        dynamic_range_db=(5.0, 15.0),
        tags=["electronic", "four-on-the-floor", "repetitive", "dark"],
    ),
    GenreProfile(
        name="House",
        bpm_range=(118.0, 132.0), density_range=(2.0, 8.0),
        swing_range=(0.0, 0.15), syncopation_range=(0.1, 0.4),
        dominant_subdivision="8th", prefer_major=True,
        chord_complexity=0.4, low_energy_range=(0.25, 0.5),
        dynamic_range_db=(6.0, 18.0),
        tags=["electronic", "four-on-the-floor", "groovy", "soulful"],
    ),
    GenreProfile(
        name="Drum & Bass",
        bpm_range=(160.0, 180.0), density_range=(4.0, 15.0),
        swing_range=(0.0, 0.1), syncopation_range=(0.3, 0.8),
        dominant_subdivision="16th", prefer_major=False,
        chord_complexity=0.3, low_energy_range=(0.3, 0.55),
        dynamic_range_db=(5.0, 15.0),
        tags=["electronic", "breakbeat", "fast", "bass-heavy"],
    ),
    GenreProfile(
        name="Hip-Hop",
        bpm_range=(70.0, 115.0), density_range=(1.5, 6.0),
        swing_range=(0.1, 0.4), syncopation_range=(0.2, 0.6),
        dominant_subdivision="16th", prefer_major=False,
        chord_complexity=0.3, low_energy_range=(0.3, 0.6),
        dynamic_range_db=(5.0, 14.0),
        tags=["urban", "boom-bap", "trap", "bass-heavy"],
    ),
    GenreProfile(
        name="Trap",
        bpm_range=(130.0, 170.0), density_range=(2.0, 12.0),
        swing_range=(0.0, 0.1), syncopation_range=(0.2, 0.7),
        dominant_subdivision="32nd", prefer_major=False,
        chord_complexity=0.2, low_energy_range=(0.35, 0.6),
        dynamic_range_db=(4.0, 12.0),
        tags=["electronic", "urban", "hi-hat-rolls", "bass-heavy", "808"],
    ),
    GenreProfile(
        name="Jazz",
        bpm_range=(80.0, 220.0), density_range=(2.0, 12.0),
        swing_range=(0.2, 0.6), syncopation_range=(0.3, 0.8),
        dominant_subdivision="triplet", prefer_major=True,
        chord_complexity=0.8,
        typical_intervals=[3, 4, 5, 7, 10, 11],
        dynamic_range_db=(10.0, 30.0),
        tags=["acoustic", "swing", "improvisation", "complex-harmony"],
    ),
    GenreProfile(
        name="Rock",
        bpm_range=(100.0, 160.0), density_range=(2.0, 8.0),
        swing_range=(0.0, 0.1), syncopation_range=(0.1, 0.4),
        dominant_subdivision="8th", prefer_major=True,
        chord_complexity=0.3, low_energy_range=(0.2, 0.5),
        mid_energy_range=(0.3, 0.6),
        dynamic_range_db=(8.0, 20.0),
        tags=["band", "guitar", "power-chords", "driving"],
    ),
    GenreProfile(
        name="Pop",
        bpm_range=(90.0, 140.0), density_range=(1.5, 6.0),
        swing_range=(0.0, 0.15), syncopation_range=(0.1, 0.3),
        dominant_subdivision="8th", prefer_major=True,
        chord_complexity=0.3, dynamic_range_db=(6.0, 18.0),
        tags=["mainstream", "catchy", "verse-chorus", "melodic"],
    ),
    GenreProfile(
        name="Ambient",
        bpm_range=(50.0, 120.0), density_range=(0.2, 2.0),
        swing_range=(0.0, 0.05), syncopation_range=(0.0, 0.2),
        dominant_subdivision="4th", prefer_major=True,
        chord_complexity=0.5, high_energy_range=(0.1, 0.4),
        dynamic_range_db=(15.0, 40.0),
        tags=["atmospheric", "slow", "pad", "ethereal", "texture"],
    ),
    GenreProfile(
        name="Lo-Fi",
        bpm_range=(70.0, 100.0), density_range=(1.0, 5.0),
        swing_range=(0.1, 0.35), syncopation_range=(0.1, 0.4),
        dominant_subdivision="8th", prefer_major=True,
        chord_complexity=0.5, dynamic_range_db=(8.0, 20.0),
        tags=["chill", "jazzy", "dusty", "warm"],
    ),
    GenreProfile(
        name="EDM",
        bpm_range=(125.0, 150.0), density_range=(3.0, 10.0),
        swing_range=(0.0, 0.05), syncopation_range=(0.1, 0.4),
        dominant_subdivision="16th", prefer_major=True,
        chord_complexity=0.3, low_energy_range=(0.25, 0.55),
        dynamic_range_db=(4.0, 14.0),
        tags=["electronic", "build-drop", "energetic", "festival"],
    ),
    GenreProfile(
        name="Funk",
        bpm_range=(95.0, 130.0), density_range=(3.0, 10.0),
        swing_range=(0.1, 0.3), syncopation_range=(0.4, 0.8),
        dominant_subdivision="16th", prefer_major=True,
        chord_complexity=0.5,
        typical_intervals=[3, 5, 7, 10],
        dynamic_range_db=(8.0, 22.0),
        tags=["groovy", "syncopated", "16th-note", "tight"],
    ),
    GenreProfile(
        name="Reggae",
        bpm_range=(65.0, 90.0), density_range=(1.5, 5.0),
        swing_range=(0.05, 0.2), syncopation_range=(0.3, 0.7),
        dominant_subdivision="8th", prefer_major=True,
        chord_complexity=0.3, dynamic_range_db=(8.0, 20.0),
        tags=["offbeat", "skank", "dub", "laid-back"],
    ),
    GenreProfile(
        name="Classical",
        bpm_range=(40.0, 180.0), density_range=(1.0, 15.0),
        swing_range=(0.0, 0.05), syncopation_range=(0.0, 0.3),
        dominant_subdivision="8th", prefer_major=True,
        chord_complexity=0.6,
        typical_intervals=[3, 4, 5, 7, 12],
        dynamic_range_db=(15.0, 50.0),
        tags=["orchestral", "polyphonic", "dynamic", "structured"],
    ),
    GenreProfile(
        name="Trance",
        bpm_range=(128.0, 150.0), density_range=(2.0, 8.0),
        swing_range=(0.0, 0.05), syncopation_range=(0.05, 0.3),
        dominant_subdivision="16th", prefer_major=False,
        chord_complexity=0.4, dynamic_range_db=(5.0, 16.0),
        tags=["electronic", "euphoric", "arpeggio", "build-drop"],
    ),
    GenreProfile(
        name="R&B",
        bpm_range=(60.0, 110.0), density_range=(1.5, 6.0),
        swing_range=(0.1, 0.3), syncopation_range=(0.2, 0.5),
        dominant_subdivision="16th", prefer_major=True,
        chord_complexity=0.6,
        typical_intervals=[3, 4, 7, 10, 11],
        dynamic_range_db=(8.0, 20.0),
        tags=["smooth", "soulful", "groove", "vocal"],
    ),
]


# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------

@dataclass
class GenreMatch:
    """Single genre match result."""
    genre: str
    similarity: float = 0.0  # 0..1
    confidence: str = "low"  # "low"|"medium"|"high"
    tags: List[str] = field(default_factory=list)
    reasons: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "genre": self.genre,
            "similarity_pct": round(self.similarity * 100, 1),
            "confidence": self.confidence,
            "tags": self.tags,
            "reasons": self.reasons,
        }


@dataclass
class GenreReport:
    """Complete genre detection report."""
    primary: Optional[GenreMatch] = None
    secondary: Optional[GenreMatch] = None
    all_matches: List[GenreMatch] = field(default_factory=list)
    bpm: float = 0.0
    note_count: int = 0
    description: str = ""

    def to_dict(self) -> dict:
        return {
            "primary": self.primary.to_dict() if self.primary else None,
            "secondary": self.secondary.to_dict() if self.secondary else None,
            "all_matches": [m.to_dict() for m in self.all_matches[:5]],
            "bpm": round(self.bpm, 1),
            "note_count": self.note_count,
            "description": self.description,
        }


# ---------------------------------------------------------------------------
# Matching engine
# ---------------------------------------------------------------------------

def _range_score(value: float, lo: float, hi: float) -> float:
    """Score how well a value fits within a range. 1.0 = perfect, 0.0 = far away."""
    if lo <= value <= hi:
        return 1.0
    if value < lo:
        dist = lo - value
        span = max(hi - lo, 1.0)
        return max(0.0, 1.0 - dist / span)
    # value > hi
    dist = value - hi
    span = max(hi - lo, 1.0)
    return max(0.0, 1.0 - dist / span)


def _match_genre(profile: GenreProfile,
                 bpm: float = 0.0,
                 density: float = 0.0,
                 swing: float = 0.0,
                 syncopation: float = 0.0,
                 subdivision: str = "",
                 is_major: bool = True,
                 chord_complexity: float = 0.0,
                 intervals: Optional[List[int]] = None,
                 low_energy: float = 0.0,
                 mid_energy: float = 0.0,
                 high_energy: float = 0.0,
                 dynamic_range_db: float = 0.0) -> GenreMatch:
    """Score a set of musical features against a genre profile."""
    scores: List[float] = []
    reasons: List[str] = []

    # BPM
    if bpm > 0:
        s = _range_score(bpm, *profile.bpm_range)
        scores.append(s * 2.0)  # weight x2
        if s > 0.7:
            reasons.append(f"BPM {bpm:.0f} passt gut ({profile.bpm_range[0]:.0f}-{profile.bpm_range[1]:.0f})")

    # Density
    if density > 0:
        s = _range_score(density, *profile.density_range)
        scores.append(s)
        if s > 0.7:
            reasons.append(f"Notendichte {density:.1f}/beat passt")

    # Swing
    s = _range_score(swing, *profile.swing_range)
    scores.append(s)
    if s > 0.7 and swing > 0.1:
        reasons.append(f"Swing {swing:.0%} typisch")

    # Syncopation
    s = _range_score(syncopation, *profile.syncopation_range)
    scores.append(s)
    if s > 0.7 and syncopation > 0.2:
        reasons.append(f"Synkopierung {syncopation:.0%} passt")

    # Subdivision match
    if subdivision and subdivision == profile.dominant_subdivision:
        scores.append(1.0)
        reasons.append(f"Subdivision {subdivision} typisch")
    elif subdivision:
        scores.append(0.3)

    # Major/minor preference
    if is_major == profile.prefer_major:
        scores.append(0.8)
    else:
        scores.append(0.4)

    # Chord complexity
    s = 1.0 - abs(chord_complexity - profile.chord_complexity)
    scores.append(s * 0.8)
    if s > 0.7:
        reasons.append(f"Akkord-Komplexität passt")

    # Typical intervals
    if intervals and profile.typical_intervals:
        overlap = len(set(intervals) & set(profile.typical_intervals))
        total = max(len(profile.typical_intervals), 1)
        s = overlap / total
        scores.append(s * 0.6)
        if s > 0.5:
            reasons.append(f"Intervalle typisch für {profile.name}")

    # Spectral features (if audio data available)
    if low_energy > 0 or mid_energy > 0 or high_energy > 0:
        s_low = _range_score(low_energy, *profile.low_energy_range)
        s_mid = _range_score(mid_energy, *profile.mid_energy_range)
        s_hi = _range_score(high_energy, *profile.high_energy_range)
        scores.append((s_low + s_mid + s_hi) / 3.0)

    # Dynamic range
    if dynamic_range_db > 0:
        s = _range_score(dynamic_range_db, *profile.dynamic_range_db)
        scores.append(s * 0.5)

    # Calculate similarity
    if not scores:
        similarity = 0.0
    else:
        similarity = sum(scores) / (len(scores) * 1.2)  # normalize, slight discount
        similarity = min(1.0, max(0.0, similarity))

    # Confidence
    if similarity > 0.7:
        confidence = "high"
    elif similarity > 0.45:
        confidence = "medium"
    else:
        confidence = "low"

    return GenreMatch(
        genre=profile.name,
        similarity=similarity,
        confidence=confidence,
        tags=list(profile.tags),
        reasons=reasons[:4],
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def detect_genre_from_midi(
    notes: List[Dict[str, Any]],
    bpm: float = 120.0,
    key_name: str = "",
) -> GenreReport:
    """Detect genre from MIDI note data.

    Args:
        notes: list of dicts with "pitch", "start", "duration", "velocity"
        bpm: project tempo
        key_name: detected key like "C major" or "A minor"

    Returns:
        GenreReport with ranked genre matches.
    """
    if not notes:
        return GenreReport(description="Keine Noten für Genre-Analyse vorhanden.")

    # Compute features from MIDI
    total_beats = 0.0
    pitches: List[int] = []
    velocities: List[int] = []
    start_times: List[float] = []
    durations: List[float] = []

    for n in notes:
        p = int(n.get("pitch", 60))
        s = float(n.get("start", 0))
        d = float(n.get("duration", 0.25))
        v = int(n.get("velocity", 80))
        pitches.append(p)
        velocities.append(v)
        start_times.append(s)
        durations.append(d)
        total_beats = max(total_beats, s + d)

    if total_beats <= 0:
        total_beats = 4.0

    # Density
    density = len(notes) / max(total_beats, 1.0)

    # Swing detection (ratio of odd vs even 8th-note placements)
    eighth_grid = [round(s * 2) / 2 for s in start_times]
    offbeat_count = sum(1 for g in eighth_grid if (g * 2) % 2 != 0)
    swing = offbeat_count / max(len(start_times), 1)

    # Syncopation (notes starting off strong beats)
    strong_beats = {0.0, 1.0, 2.0, 3.0}
    offbeat_starts = sum(1 for s in start_times if (s % 4) not in strong_beats)
    syncopation = offbeat_starts / max(len(start_times), 1)

    # Subdivision detection
    fractional_parts = [s % 1.0 for s in start_times]
    sub_16th = sum(1 for f in fractional_parts if abs(f % 0.25) < 0.05)
    sub_triplet = sum(1 for f in fractional_parts if abs(f % (1 / 3)) < 0.05)
    sub_32nd = sum(1 for f in fractional_parts
                   if abs(f % 0.125) < 0.03 and abs(f % 0.25) >= 0.05)

    if sub_32nd > len(notes) * 0.15:
        subdivision = "32nd"
    elif sub_triplet > sub_16th * 0.3:
        subdivision = "triplet"
    elif sub_16th > len(notes) * 0.4:
        subdivision = "16th"
    else:
        subdivision = "8th"

    # Key / major-minor
    is_major = "major" in key_name.lower() or "dur" in key_name.lower() if key_name else True

    # Chord complexity estimate (unique pitch classes / total)
    pitch_classes = set(p % 12 for p in pitches)
    chord_complexity = min(1.0, len(pitch_classes) / 7.0)

    # Interval analysis
    sorted_pitches = sorted(set(pitches))
    intervals: List[int] = []
    for i in range(1, len(sorted_pitches)):
        intervals.append((sorted_pitches[i] - sorted_pitches[i - 1]) % 12)

    # Velocity range
    if velocities:
        vel_range = (max(velocities) - min(velocities)) / 127.0
    else:
        vel_range = 0.0

    # Match against all profiles
    matches: List[GenreMatch] = []
    for profile in _GENRE_PROFILES:
        m = _match_genre(
            profile,
            bpm=bpm,
            density=density,
            swing=swing,
            syncopation=syncopation,
            subdivision=subdivision,
            is_major=is_major,
            chord_complexity=chord_complexity,
            intervals=intervals,
        )
        matches.append(m)

    # Sort by similarity
    matches.sort(key=lambda m: m.similarity, reverse=True)

    primary = matches[0] if matches else None
    secondary = matches[1] if len(matches) > 1 else None

    # Build description
    desc_parts = []
    if primary and primary.similarity > 0.3:
        desc_parts.append(
            f"Klingt am ehesten nach {primary.genre} "
            f"(Ähnlichkeit {primary.similarity:.0%})"
        )
    if secondary and secondary.similarity > 0.3:
        desc_parts.append(
            f"mit Elementen von {secondary.genre} "
            f"({secondary.similarity:.0%})"
        )
    if not desc_parts:
        desc_parts.append("Genre konnte nicht eindeutig bestimmt werden")

    desc_parts.append(
        f"Merkmale: {density:.1f} Noten/Beat, "
        f"{'Swing' if swing > 0.1 else 'Straight'}, "
        f"Subdivision={subdivision}, "
        f"{'Moll' if not is_major else 'Dur'}"
    )

    return GenreReport(
        primary=primary,
        secondary=secondary,
        all_matches=matches[:6],
        bpm=bpm,
        note_count=len(notes),
        description=". ".join(desc_parts),
    )


def detect_genre_from_audio(
    audio_features: Dict[str, float],
    bpm: float = 120.0,
) -> GenreReport:
    """Detect genre from pre-computed audio features.

    Args:
        audio_features: dict with keys like "low_energy", "mid_energy",
            "high_energy", "dynamic_range_db", "spectral_centroid_hz"
        bpm: detected or project tempo

    Returns:
        GenreReport with ranked genre matches.
    """
    low_e = audio_features.get("low_energy", 0.0)
    mid_e = audio_features.get("mid_energy", 0.0)
    high_e = audio_features.get("high_energy", 0.0)
    dyn = audio_features.get("dynamic_range_db", 12.0)

    matches: List[GenreMatch] = []
    for profile in _GENRE_PROFILES:
        m = _match_genre(
            profile,
            bpm=bpm,
            low_energy=low_e,
            mid_energy=mid_e,
            high_energy=high_e,
            dynamic_range_db=dyn,
        )
        matches.append(m)

    matches.sort(key=lambda m: m.similarity, reverse=True)
    primary = matches[0] if matches else None
    secondary = matches[1] if len(matches) > 1 else None

    desc = f"Audio-Genre: {primary.genre} ({primary.similarity:.0%})" if primary else "Nicht bestimmbar"

    return GenreReport(
        primary=primary,
        secondary=secondary,
        all_matches=matches[:6],
        bpm=bpm,
        description=desc,
    )
