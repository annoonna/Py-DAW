"""ki_church_music.py — Church Music Engine (v0.0.20.987)

KK9:  Choral-Datenbank (Public Domain melodies)
KK10: Orgel-Spezifisch (Registration, Pedal, Manual)
KK11: Chor-Satz SATB (Voice ranges, breath marks, double choir)

Usage:
    from pydaw.services.ki_church_music import ChurchMusicEngine

    church = ChurchMusicEngine()
    chorale = church.get_chorale("ein_feste_burg")
    organ_reg = church.suggest_registration("plenum")
    satb = church.harmonize_satb(soprano_melody)
"""

import random
import logging
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple

log = logging.getLogger(__name__)

try:
    from .ki_composition_theory import Scale, Chord, CadenceEngine
    from .ki_counterpoint import ChoraleHarmonizer
except ImportError:
    from pydaw.services.ki_composition_theory import Scale, Chord, CadenceEngine
    from pydaw.services.ki_counterpoint import ChoraleHarmonizer


# ═══════════════════════════════════════════════════════════════
# KK9: Choral Database (Public Domain)
# ═══════════════════════════════════════════════════════════════

@dataclass
class ChoraleEntry:
    """A chorale melody with metadata."""
    id: str
    title: str
    text_incipit: str           # First line of text
    melody: List[int]           # MIDI notes
    key: str                    # e.g. "D major"
    meter: str                  # e.g. "iambus"
    source: str                 # e.g. "EG 362", "BWV 80"
    year: int = 0
    composer: str = ""
    fermata_positions: List[int] = field(default_factory=list)  # phrase endings


# Public domain chorales (melodies before 1900)
CHORALE_DB: Dict[str, ChoraleEntry] = {
    "ein_feste_burg": ChoraleEntry(
        id="ein_feste_burg", title="Ein feste Burg ist unser Gott",
        text_incipit="Ein feste Burg ist unser Gott",
        melody=[62, 62, 62, 57, 59, 60, 62, 62, 60, 59, 57,
                62, 62, 64, 65, 67, 67, 65, 64, 62],
        key="D major", meter="iambus", source="EG 362",
        year=1529, composer="Martin Luther",
        fermata_positions=[3, 7, 11, 15, 19],
    ),
    "lobe_den_herren": ChoraleEntry(
        id="lobe_den_herren", title="Lobe den Herren, den mächtigen König",
        text_incipit="Lobe den Herren, den mächtigen König der Ehren",
        melody=[65, 69, 72, 72, 74, 72, 69, 65, 67, 69, 69,
                67, 65, 64, 62, 65],
        key="F major", meter="dactyl", source="EG 316",
        year=1680, composer="Joachim Neander",
        fermata_positions=[4, 8, 12, 15],
    ),
    "nun_danket": ChoraleEntry(
        id="nun_danket", title="Nun danket alle Gott",
        text_incipit="Nun danket alle Gott",
        melody=[67, 67, 69, 71, 72, 72, 74, 72, 71, 69, 67,
                67, 69, 71, 72, 72],
        key="G major", meter="iambus", source="EG 321",
        year=1636, composer="Martin Rinkart",
        fermata_positions=[3, 6, 10, 15],
    ),
    "o_haupt_voll_blut": ChoraleEntry(
        id="o_haupt_voll_blut", title="O Haupt voll Blut und Wunden",
        text_incipit="O Haupt voll Blut und Wunden",
        melody=[64, 67, 65, 64, 62, 60, 62, 64, 65, 67, 65,
                64, 62, 60, 59, 60],
        key="E minor", meter="iambus", source="EG 85 / BWV 244",
        year=1613, composer="Hans Leo Hassler / J.S. Bach",
        fermata_positions=[3, 7, 11, 15],
    ),
    "stille_nacht": ChoraleEntry(
        id="stille_nacht", title="Stille Nacht, heilige Nacht",
        text_incipit="Stille Nacht, heilige Nacht",
        melody=[67, 69, 67, 64, 67, 69, 67, 64, 74, 74, 71,
                72, 72, 67, 69, 69, 71, 69, 67, 69, 67, 64],
        key="G major", meter="dactyl", source="EG 46",
        year=1818, composer="Franz Xaver Gruber",
        fermata_positions=[3, 7, 10, 13, 17, 21],
    ),
    "vom_himmel_hoch": ChoraleEntry(
        id="vom_himmel_hoch", title="Vom Himmel hoch, da komm ich her",
        text_incipit="Vom Himmel hoch, da komm ich her",
        melody=[72, 71, 69, 67, 69, 71, 72, 74, 72, 71, 69,
                67, 69, 67, 65, 67],
        key="C major", meter="iambus", source="EG 24",
        year=1535, composer="Martin Luther",
        fermata_positions=[4, 8, 12, 15],
    ),
    "christ_lag": ChoraleEntry(
        id="christ_lag", title="Christ lag in Todesbanden",
        text_incipit="Christ lag in Todesbanden",
        melody=[64, 62, 60, 62, 64, 65, 67, 65, 64, 62,
                64, 62, 60, 59, 57, 60],
        key="E minor", meter="iambus", source="EG 101",
        year=1524, composer="Martin Luther",
        fermata_positions=[4, 8, 12, 15],
    ),
    "wachet_auf": ChoraleEntry(
        id="wachet_auf", title="Wachet auf, ruft uns die Stimme",
        text_incipit="Wachet auf, ruft uns die Stimme",
        melody=[64, 67, 71, 71, 72, 71, 69, 67, 69, 71,
                67, 64, 62, 64, 67, 64],
        key="E major", meter="trochee", source="EG 147 / BWV 140",
        year=1599, composer="Philipp Nicolai",
        fermata_positions=[4, 8, 12, 15],
    ),
}


# ═══════════════════════════════════════════════════════════════
# KK10: Organ Registration
# ═══════════════════════════════════════════════════════════════

@dataclass
class OrganStop:
    """An organ stop (Register)."""
    name: str
    family: str     # "principal", "flute", "reed", "string", "mixture"
    pitch: str      # "8'", "4'", "2'", "16'", "III-V" (mixture)
    manual: str     # "hauptwerk", "schwellwerk", "positiv", "pedal"


@dataclass
class OrganRegistration:
    """A complete organ registration (combination of stops)."""
    name: str
    description: str
    stops: List[OrganStop]
    dynamics: str           # pp, p, mf, f, ff
    suggested_for: List[str]  # ["choral", "fugue", "toccata"]


REGISTRATIONS: Dict[str, OrganRegistration] = {
    "plenum": OrganRegistration(
        name="Plenum", description="Volle Orgel — alle Prinzipale + Mixturen",
        stops=[
            OrganStop("Prinzipal", "principal", "8'", "hauptwerk"),
            OrganStop("Oktave", "principal", "4'", "hauptwerk"),
            OrganStop("Superoktave", "principal", "2'", "hauptwerk"),
            OrganStop("Mixtur", "mixture", "IV-V", "hauptwerk"),
            OrganStop("Trompete", "reed", "8'", "hauptwerk"),
            OrganStop("Prinzipal", "principal", "16'", "pedal"),
            OrganStop("Oktave", "principal", "8'", "pedal"),
            OrganStop("Posaune", "reed", "16'", "pedal"),
        ],
        dynamics="ff", suggested_for=["toccata", "plenum", "postlude"],
    ),
    "principal_chorus": OrganRegistration(
        name="Prinzipal-Chor", description="Prinzipale ohne Mixturen",
        stops=[
            OrganStop("Prinzipal", "principal", "8'", "hauptwerk"),
            OrganStop("Oktave", "principal", "4'", "hauptwerk"),
            OrganStop("Prinzipal", "principal", "16'", "pedal"),
            OrganStop("Oktave", "principal", "8'", "pedal"),
        ],
        dynamics="f", suggested_for=["choral", "hymn"],
    ),
    "flute_choir": OrganRegistration(
        name="Flöten-Chor", description="Sanfte Flötenregister",
        stops=[
            OrganStop("Rohrflöte", "flute", "8'", "schwellwerk"),
            OrganStop("Blockflöte", "flute", "4'", "schwellwerk"),
            OrganStop("Waldflöte", "flute", "2'", "schwellwerk"),
            OrganStop("Subbass", "flute", "16'", "pedal"),
        ],
        dynamics="p", suggested_for=["meditation", "communion", "prelude"],
    ),
    "reed_solo": OrganRegistration(
        name="Zungen-Solo", description="Solo-Zunge auf Schwellwerk",
        stops=[
            OrganStop("Oboe", "reed", "8'", "schwellwerk"),
            OrganStop("Rohrflöte", "flute", "8'", "schwellwerk"),
            OrganStop("Prinzipal", "principal", "8'", "hauptwerk"),
            OrganStop("Subbass", "flute", "16'", "pedal"),
        ],
        dynamics="mf", suggested_for=["cantus_firmus", "solo"],
    ),
    "string_celeste": OrganRegistration(
        name="Streicher + Celeste", description="Schwebende Streicher",
        stops=[
            OrganStop("Salicional", "string", "8'", "schwellwerk"),
            OrganStop("Vox Celeste", "string", "8'", "schwellwerk"),
            OrganStop("Gedackt", "flute", "8'", "hauptwerk"),
            OrganStop("Subbass", "flute", "16'", "pedal"),
        ],
        dynamics="pp", suggested_for=["meditation", "lullaby"],
    ),
    "trio_sonata": OrganRegistration(
        name="Triosonate", description="Drei Stimmen auf drei Manualen",
        stops=[
            OrganStop("Rohrflöte", "flute", "8'", "hauptwerk"),
            OrganStop("Prinzipal", "principal", "4'", "schwellwerk"),
            OrganStop("Subbass", "flute", "16'", "pedal"),
            OrganStop("Gedackt", "flute", "8'", "pedal"),
        ],
        dynamics="mf", suggested_for=["trio_sonata", "fugue"],
    ),
}


def suggest_registration(style: str) -> OrganRegistration:
    """Suggest organ registration for a musical style."""
    style_map = {
        "plenum": "plenum", "toccata": "plenum", "postlude": "plenum",
        "choral": "principal_chorus", "hymn": "principal_chorus",
        "meditation": "flute_choir", "communion": "flute_choir",
        "solo": "reed_solo", "cantus_firmus": "reed_solo",
        "trio_sonata": "trio_sonata", "fugue": "trio_sonata",
        "lullaby": "string_celeste", "prelude": "flute_choir",
    }
    reg_name = style_map.get(style, "principal_chorus")
    return REGISTRATIONS.get(reg_name, REGISTRATIONS["principal_chorus"])


def generate_pedal_voice(melody: List[int], scale: Scale) -> List[int]:
    """Generate independent pedal (bass) voice for organ.

    Not just doubling — uses contrary motion and passing tones.
    """
    bass = []
    for i, note in enumerate(melody):
        # Root of implied chord (simplified)
        degree = scale.degree_of(note)
        if degree is None:
            degree = 1
        root = scale.degree_to_midi(degree, 0) + 36  # pedal range

        # Add contrary motion
        if bass and i > 0:
            mel_dir = note - melody[i - 1]
            if mel_dir > 0:
                root = min(root, bass[-1] - 1)  # contrary
            elif mel_dir < 0:
                root = max(root, bass[-1] + 1)

        root = max(36, min(60, root))
        bass.append(root)
    return bass


def organ_point(bass_note: int, chords: List[Chord],
                bars: int = 4) -> List[int]:
    """Generate organ point (pedal point) — sustained bass note."""
    return [bass_note] * (bars * 4)


# ═══════════════════════════════════════════════════════════════
# KK11: SATB Choir
# ═══════════════════════════════════════════════════════════════

VOICE_RANGES = {
    "soprano": (60, 81),  # C4–A5
    "alto":    (53, 74),  # F3–D5
    "tenor":   (48, 69),  # C3–A4
    "bass":    (40, 62),  # E2–D4
}


@dataclass
class SATBScore:
    """Four-part choral score."""
    soprano: List[int]
    alto: List[int]
    tenor: List[int]
    bass: List[int]
    breath_marks: List[int]     # positions of breath marks/caesuras
    text: Optional[str] = None


def check_voice_crossing(satb: Dict[str, List[int]]) -> List[int]:
    """Check for voice crossing violations. Returns indices of violations."""
    violations = []
    s, a, t, b = satb["soprano"], satb["alto"], satb["tenor"], satb["bass"]
    for i in range(min(len(s), len(a), len(t), len(b))):
        if a[i] > s[i] or t[i] > a[i] or b[i] > t[i]:
            violations.append(i)
    return violations


def fix_voice_crossing(satb: Dict[str, List[int]]) -> Dict[str, List[int]]:
    """Fix voice crossing by octave transposition."""
    result = {k: list(v) for k, v in satb.items()}
    for i in range(min(len(result["soprano"]), len(result["alto"]),
                       len(result["tenor"]), len(result["bass"]))):
        # Ensure S > A > T > B
        if result["alto"][i] > result["soprano"][i]:
            result["alto"][i] -= 12
        if result["tenor"][i] > result["alto"][i]:
            result["tenor"][i] -= 12
        if result["bass"][i] > result["tenor"][i]:
            result["bass"][i] -= 12
    return result


def add_breath_marks(melody: List[int], fermata_positions: List[int] = None,
                     phrase_length: int = 4) -> List[int]:
    """Add automatic breath marks (caesuras) to a melody.

    Returns list of positions where breath marks should be placed.
    """
    if fermata_positions:
        return fermata_positions

    marks = []
    for i in range(phrase_length, len(melody), phrase_length):
        marks.append(i)
    return marks


def generate_double_choir(melody: List[int], scale: Scale) -> Dict:
    """Generate antiphonal double choir (Venetian style).

    Two SATB groups alternating and combining.
    Returns {choir1: SATB, choir2: SATB, tutti: SATB}
    """
    harmonizer = ChoraleHarmonizer(scale)

    # Split melody into alternating phrases
    phrase_len = max(4, len(melody) // 4)
    choir1_melody = []
    choir2_melody = []

    for i in range(0, len(melody), phrase_len):
        phrase = melody[i:i + phrase_len]
        if (i // phrase_len) % 2 == 0:
            choir1_melody.extend(phrase)
            choir2_melody.extend([0] * len(phrase))  # rest
        else:
            choir1_melody.extend([0] * len(phrase))  # rest
            choir2_melody.extend(phrase)

    # Harmonize each choir
    choir1 = harmonizer.harmonize([n for n in choir1_melody if n > 0])
    choir2 = harmonizer.harmonize([n for n in choir2_melody if n > 0])

    # Tutti at the end
    tutti = harmonizer.harmonize(melody[-phrase_len:])

    return {"choir1": choir1, "choir2": choir2, "tutti": tutti}


# ═══════════════════════════════════════════════════════════════
# Main Interface
# ═══════════════════════════════════════════════════════════════

class ChurchMusicEngine:
    """Unified interface for church music generation."""

    def __init__(self):
        self.chorales = CHORALE_DB
        self.registrations = REGISTRATIONS

    def get_chorale(self, chorale_id: str) -> Optional[ChoraleEntry]:
        return self.chorales.get(chorale_id)

    def list_chorales(self) -> List[Dict]:
        return [{"id": c.id, "title": c.title, "key": c.key,
                 "source": c.source, "year": c.year}
                for c in self.chorales.values()]

    def suggest_registration(self, style: str) -> OrganRegistration:
        return suggest_registration(style)

    def list_registrations(self) -> List[str]:
        return list(self.registrations.keys())

    def harmonize_satb(self, soprano: List[int],
                       key: str = "C", mode: str = "major") -> SATBScore:
        scale = Scale(root=key, mode=mode)
        harmonizer = ChoraleHarmonizer(scale)
        satb = harmonizer.harmonize(soprano)
        satb = fix_voice_crossing(satb)
        breaths = add_breath_marks(soprano)
        return SATBScore(
            soprano=satb["soprano"], alto=satb["alto"],
            tenor=satb["tenor"], bass=satb["bass"],
            breath_marks=breaths,
        )

    def generate_organ_chorale(self, chorale_id: str,
                               form: str = "cantus_firmus") -> Dict:
        """Generate an organ chorale setting."""
        chorale = self.get_chorale(chorale_id)
        if chorale is None:
            return {"error": f"Chorale '{chorale_id}' not found"}

        key_parts = chorale.key.split()
        root = key_parts[0] if key_parts else "C"
        mode = key_parts[1] if len(key_parts) > 1 else "major"
        scale = Scale(root=root, mode=mode)

        satb = self.harmonize_satb(chorale.melody, root, mode)
        pedal = generate_pedal_voice(chorale.melody, scale)
        reg = self.suggest_registration(form)

        return {
            "chorale": chorale.title,
            "form": form,
            "registration": reg.name,
            "soprano": satb.soprano,
            "alto": satb.alto,
            "tenor": satb.tenor,
            "bass": satb.bass,
            "pedal": pedal,
            "breath_marks": satb.breath_marks,
        }
