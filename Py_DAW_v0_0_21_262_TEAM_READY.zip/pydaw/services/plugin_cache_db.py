"""plugin_cache_db.py — SQLite-backed Plugin Scanner Cache.

v0.0.20.889 — Phase 7 der SQLite Migration Roadmap.

Replaces the JSON-based plugin cache (~/.cache/ChronoScaleStudio/plugin_cache.json)
with SQLite for faster queries, incremental updates, and better crash safety.

Old JSON cache (plugin_scanner.py load_cache/save_cache) remains functional
as fallback — this module adds a database layer alongside it.

Usage:
    from pydaw.services.plugin_cache_db import PluginCacheDB
    db = PluginCacheDB.get()
    db.ensure_loaded()

    # Query
    all_vst3 = db.get_by_format("vst3")
    instruments = db.get_instruments()
    surge = db.get_by_name("Surge XT")

    # Update after scan
    db.upsert_plugin("/usr/lib/vst3/Surge XT.vst3", name="Surge XT",
                     format="vst3", is_instrument=True, vendor="Surge Synth Team")

    # Check freshness
    if db.is_stale(max_age_hours=4):
        # trigger rescan
"""

import json
import sqlite3
import logging
import time
from pathlib import Path
from typing import Dict, List, Optional

log = logging.getLogger(__name__)


class PluginCacheDB:
    """SQLite-backed plugin scanner cache.

    Singleton. All entries cached in RAM for fast lookups.
    Writes go to SQLite immediately (plugins change rarely).
    """

    _instance: Optional["PluginCacheDB"] = None

    @classmethod
    def get(cls) -> "PluginCacheDB":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._db_path = Path.home() / ".config" / "ChronoScaleStudio" / "pydaw.db"
        self._cache: List[dict] = []
        self._by_path: Dict[str, dict] = {}           # path → row
        self._by_format: Dict[str, List[dict]] = {}    # format → [rows]
        self._loaded = False

    def ensure_loaded(self) -> None:
        """Create table, optionally migrate from JSON cache, load into RAM. Idempotent."""
        if self._loaded:
            return
        try:
            self._init_db()
            self._load_to_ram()
            if len(self._cache) == 0:
                self._migrate_from_json()
            self._loaded = True
            log.info("[PluginCacheDB] Loaded %d plugin entries", len(self._cache))
        except Exception as e:
            log.warning("[PluginCacheDB] Failed to load: %s", e)

    # ── Public API ──────────────────────────────────────────────

    def get_all(self) -> List[dict]:
        """All cached plugins."""
        self.ensure_loaded()
        return list(self._cache)

    def get_by_path(self, path: str) -> Optional[dict]:
        """Get plugin by filesystem path."""
        self.ensure_loaded()
        return self._by_path.get(path)

    def get_by_format(self, fmt: str) -> List[dict]:
        """Get all plugins of a format ('vst2', 'vst3', 'clap', 'lv2', 'ladspa')."""
        self.ensure_loaded()
        return list(self._by_format.get(fmt, []))

    def get_instruments(self) -> List[dict]:
        """Get all instrument plugins (not effects)."""
        self.ensure_loaded()
        return [p for p in self._cache if p.get("is_instrument")]

    def get_effects(self) -> List[dict]:
        """Get all effect plugins (not instruments)."""
        self.ensure_loaded()
        return [p for p in self._cache if not p.get("is_instrument")]

    def get_by_name(self, name: str) -> List[dict]:
        """Search plugins by name (case-insensitive substring)."""
        self.ensure_loaded()
        q = name.lower()
        return [p for p in self._cache if q in (p.get("name") or "").lower()]

    def get_by_vendor(self, vendor: str) -> List[dict]:
        """Get all plugins by vendor."""
        self.ensure_loaded()
        v = vendor.lower()
        return [p for p in self._cache if v in (p.get("vendor") or "").lower()]

    def is_stale(self, max_age_hours: float = 4.0) -> bool:
        """Check if cache is older than max_age_hours."""
        self.ensure_loaded()
        if not self._cache:
            return True
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                row = conn.execute(
                    "SELECT MAX(last_scan) FROM plugin_cache"
                ).fetchone()
                if not row or not row[0]:
                    return True
                # last_scan is ISO format from datetime('now')
                from datetime import datetime
                last = datetime.fromisoformat(row[0])
                now = datetime.now()
                age_hours = (now - last).total_seconds() / 3600
                return age_hours > max_age_hours
            finally:
                conn.close()
        except Exception:
            return True

    def upsert_plugin(self, path: str, name: str, fmt: str,
                      is_instrument: bool = False, **kwargs) -> bool:
        """Add or update a plugin in the cache. Returns True on success."""
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.execute(
                    """INSERT OR REPLACE INTO plugin_cache
                       (path, name, vendor, format, is_instrument, category,
                        fingerprint, last_scan, scan_ok, preset_count, presets)
                       VALUES (?,?,?,?,?,?,?,datetime('now'),?,?,?)""",
                    (path, name,
                     kwargs.get("vendor", ""),
                     fmt,
                     int(is_instrument),
                     kwargs.get("category", ""),
                     kwargs.get("fingerprint", ""),
                     int(kwargs.get("scan_ok", 1)),
                     int(kwargs.get("preset_count", 0)),
                     kwargs.get("presets", ""))
                )
                conn.commit()
            finally:
                conn.close()
            # Update RAM cache
            self._loaded = False
            self.ensure_loaded()
            return True
        except Exception as e:
            log.warning("[PluginCacheDB] upsert failed: %s", e)
            return False

    def upsert_batch(self, plugins: List[dict]) -> int:
        """Batch upsert plugins. Returns count of successfully inserted."""
        count = 0
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                for p in plugins:
                    try:
                        conn.execute(
                            """INSERT OR REPLACE INTO plugin_cache
                               (path, name, vendor, format, is_instrument, category,
                                fingerprint, last_scan, scan_ok, preset_count, presets)
                               VALUES (?,?,?,?,?,?,?,datetime('now'),?,?,?)""",
                            (p.get("path", ""),
                             p.get("name", ""),
                             p.get("vendor", ""),
                             p.get("format", p.get("kind", "")),
                             int(p.get("is_instrument", 0)),
                             p.get("category", ""),
                             p.get("fingerprint", ""),
                             int(p.get("scan_ok", 1)),
                             int(p.get("preset_count", 0)),
                             p.get("presets", ""))
                        )
                        count += 1
                    except Exception:
                        pass
                conn.commit()
            finally:
                conn.close()
            self._loaded = False
            self.ensure_loaded()
        except Exception as e:
            log.warning("[PluginCacheDB] batch upsert failed: %s", e)
        return count

    def remove_plugin(self, path: str) -> None:
        """Remove a plugin from the cache."""
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.execute("DELETE FROM plugin_cache WHERE path = ?", (path,))
                conn.commit()
            finally:
                conn.close()
            self._by_path.pop(path, None)
            self._cache = [p for p in self._cache if p.get("path") != path]
        except Exception:
            pass

    def clear_all(self) -> None:
        """Clear entire cache (before full rescan)."""
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.execute("DELETE FROM plugin_cache")
                conn.commit()
            finally:
                conn.close()
            self._cache.clear()
            self._by_path.clear()
            self._by_format.clear()
        except Exception:
            pass

    def get_scan_failures(self) -> List[dict]:
        """Get plugins that failed their last scan."""
        self.ensure_loaded()
        return [p for p in self._cache if not p.get("scan_ok")]

    def get_stats(self) -> Dict[str, int]:
        """Return summary stats of cached plugins."""
        self.ensure_loaded()
        stats = {"total": len(self._cache)}
        for fmt, plugins in self._by_format.items():
            stats[fmt] = len(plugins)
        stats["instruments"] = len([p for p in self._cache if p.get("is_instrument")])
        stats["effects"] = len([p for p in self._cache if not p.get("is_instrument")])
        return stats

    # ── Internal ────────────────────────────────────────────────

    def _init_db(self) -> None:
        """Create plugin_cache table if not exists."""
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(self._db_path))
        try:
            conn.executescript(_SCHEMA_SQL)
            conn.commit()
        finally:
            conn.close()

    def _load_to_ram(self) -> None:
        """Load all entries into RAM cache."""
        conn = sqlite3.connect(str(self._db_path))
        conn.row_factory = sqlite3.Row
        try:
            rows = conn.execute(
                "SELECT * FROM plugin_cache ORDER BY format, name"
            ).fetchall()
            self._cache.clear()
            self._by_path.clear()
            self._by_format.clear()
            for row in rows:
                d = dict(row)
                # Normalize boolean
                d["is_instrument"] = bool(d.get("is_instrument", 0))
                d["scan_ok"] = bool(d.get("scan_ok", 1))
                path = d.get("path", "")
                fmt = d.get("format", "")
                self._cache.append(d)
                if path:
                    self._by_path[path] = d
                self._by_format.setdefault(fmt, []).append(d)
        finally:
            conn.close()

    def _migrate_from_json(self) -> None:
        """One-time migration from JSON cache file."""
        try:
            json_path = (Path.home() / ".cache" / "ChronoScaleStudio" / "plugin_cache.json")
            if not json_path.exists():
                return
            data = json.loads(json_path.read_text(encoding="utf-8"))
            raw = data.get("plugins")
            if not isinstance(raw, dict):
                return
            plugins_to_add = []
            for kind, arr in raw.items():
                if not isinstance(arr, list):
                    continue
                for it in arr:
                    if not isinstance(it, dict):
                        continue
                    plugins_to_add.append({
                        "path": it.get("path", it.get("plugin_id", "")),
                        "name": it.get("name", ""),
                        "vendor": it.get("vendor", ""),
                        "format": str(kind),
                        "is_instrument": int(it.get("is_instrument", 0)),
                        "category": it.get("category", ""),
                        "fingerprint": "",
                        "scan_ok": 1,
                        "preset_count": 0,
                        "presets": "",
                    })
            if plugins_to_add:
                count = self.upsert_batch(plugins_to_add)
                log.info("[PluginCacheDB] Migrated %d plugins from JSON cache", count)
        except Exception as e:
            log.debug("[PluginCacheDB] JSON migration skipped: %s", e)


# ── Schema ──────────────────────────────────────────────────────

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS plugin_cache (
    path TEXT PRIMARY KEY,
    name TEXT,
    vendor TEXT,
    format TEXT,
    is_instrument INTEGER DEFAULT 0,
    category TEXT,
    fingerprint TEXT,
    last_scan TEXT,
    scan_ok INTEGER DEFAULT 1,
    preset_count INTEGER DEFAULT 0,
    presets TEXT
);
CREATE INDEX IF NOT EXISTS idx_plugin_cache_format ON plugin_cache(format);
CREATE INDEX IF NOT EXISTS idx_plugin_cache_name ON plugin_cache(name);
CREATE INDEX IF NOT EXISTS idx_plugin_cache_instrument ON plugin_cache(is_instrument);
"""
