"""
pydaw.flux.flux_telemetry_strip
================================

**v0.0.21.256 — Live-Telemetry-Strip + KI-Tipp-Hook**

Eine kompakte Status-Leiste unter dem FLUX-Canvas, die für das aktuell
selektierte Modul anzeigt:

```
[●] Bragi.SineOsc#abc123  │  freq: 440Hz · gain: 0.50  │  CV: —  │  CPU: —  │  💡 KI-Tipp
```

Architektur — was die Foundation jetzt liefert vs später:

| Sektion       | v.256 (jetzt)                            | v.257+ (später)                            |
|---------------|------------------------------------------|--------------------------------------------|
| Modul-Name    | ✅ aus Patch-Modell live                 | unverändert                                |
| Params (eff.) | ✅ aus Module.params (Python-Default)    | echte „effective"-Werte nach CV-Mod aus Rust |
| CV            | 🚧 Stub „—" (Tooltip erklärt)            | Block-Mean pro CV-Port aus Rust-Telemetry  |
| CPU/Modul     | 🚧 Stub „—" (Tooltip erklärt)            | per-module-µs aus Rust-Profiler            |
| 💡 KI-Tipp    | ✅ vollständig (sendet Patch+Modul-Kontext an ki_assistant_panel) | unverändert |

**Warum Stubs für CV+CPU?** Der Datenpfad Rust→Python für per-Modul-Telemetrie
braucht eine neue IPC-Nachrichten-Klasse (z.B. `FluxModuleTelemetryReport`)
plus Rust-Side-Profiling. Das gehört architektonisch zu v.257 (FLUX KI-
Builder), wo der gleiche Datenpfad für „live wiring animation" gebraucht
wird. Heute liefert v.256 die UI-Foundation, der Datenpfad lässt sich dann
plug-n-play anhängen ohne UI-Refactor.

**KI-Tipp-Hook (heute voll funktional):**

Der 💡-Button emittiert `tip_requested(patch_dict, module_id)`. Das
`flux_main_widget` leitet das an das bestehende `ki_assistant_panel.py`
weiter, das einen neuen Quick-Prompt-Token `_FLUX_PATCH_TIP_` versteht.
Claude-API ist dort schon integriert (sk-ant-*-Key, Streaming, Chat-History).

NICHTS-KAPUTT-Garantie: Wenn das Strip aus irgendeinem Grund nicht geladen
werden kann, fällt der FLUX-Tab auf die alte Status-Leiste-Optik zurück.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

try:
    from PyQt6.QtCore import Qt, pyqtSignal
    from PyQt6.QtWidgets import (
        QFrame, QHBoxLayout, QLabel, QPushButton, QSizePolicy,
    )
    _QT_AVAILABLE = True
except ImportError:
    _QT_AVAILABLE = False


# ════════════════════════════════════════════════════════════════════
# Param-Auswahl: welche Params zeigen wir kompakt?
# ════════════════════════════════════════════════════════════════════

# Pro Modul-Typ: Liste der wichtigsten 1-3 Params, nach Wichtigkeit sortiert.
# Wenn nicht aufgeführt: Fallback auf alle Params, max 3, alphabetisch.
PARAM_DISPLAY_PRIORITY: Dict[str, list] = {
    # Bragi (alle 19 Oszillatoren)
    "SineOsc":      ["freq", "gain"],
    "SawOsc":       ["freq", "gain"],
    "SquareOsc":    ["freq", "gain", "pulse_width"],
    "TriangleOsc":  ["freq", "gain"],
    "NoiseOsc":     ["gain"],
    "PulseOsc":     ["freq", "gain", "pulse_width"],
    "SubOsc":       ["freq", "gain", "octaves"],
    "SwarmOsc":     ["freq", "detune", "mix"],
    "WavetableOsc": ["freq", "gain", "position"],
    "UnionOsc":     ["freq", "voices", "rolloff"],
    "BiteOsc":      ["freq", "bite", "bias"],
    "Phase1Osc":    ["freq", "gain", "shape"],
    "ScrawlOsc":    ["freq", "chaos", "crush"],
    "HardSyncOsc":  ["freq", "slave_ratio"],
    "FMOsc":        ["freq", "mod_ratio", "mod_index"],
    "DriftOsc":     ["freq", "drift_amount"],
    "RingModOsc":   ["freq", "mod_freq", "mix"],
    "GrainOsc":     ["freq", "grain_size", "density"],
    "FormantOsc":   ["freq", "vowel"],
    # Forseti (Filter)
    "Lowpass":   ["cutoff", "resonance"],
    "Highpass":  ["cutoff", "resonance"],
    "Bandpass":  ["cutoff", "resonance"],
    "Notch":     ["cutoff", "resonance"],
    "Tilt":      ["tilt"],
    "Eq4":       ["low_gain", "lo_mid_gain", "hi_mid_gain", "high_gain"],
    # Loki (LFOs)
    "LfoSine":       ["rate", "depth"],
    "LfoTriangle":   ["rate", "depth"],
    "LfoSquare":     ["rate", "depth", "pulse_width"],
    "LfoSampleHold": ["rate", "depth"],
    # Dynamics
    "Compressor":  ["threshold", "ratio", "release_ms"],
    "Limiter":     ["ceiling", "release_ms"],
    "Gate":        ["threshold", "release_ms"],
    "PeakLimiter": ["threshold"],
    "Gain":        ["gain"],
    # Time-FX
    "Delay":  ["time", "feedback", "mix"],
    "Reverb": ["room_size", "damping", "mix"],
    # Mod-FX
    "Chorus":       ["rate", "depth", "mix"],
    "Flanger":      ["rate", "feedback", "mix"],
    "Phaser":       ["rate", "depth", "mix"],
    "StereoImager": ["width", "mix"],
    "Gater":        ["rate", "smooth", "mix"],
    "Vocoder":      ["formant_shift"],
    "TapeStop":     ["speed", "mix"],
    # Lo-Fi
    "BitCrush":  ["bits", "mix"],
    "Decimator": ["target_sr", "mix"],
    # Saturation
    "TubeDrive":   ["drive", "tone", "mix"],
    "Fuzz":        ["gain", "bias", "mix"],
    "Saturation":  ["amount", "mix"],
    "WaveShaper":  ["drive", "shape", "mix"],
    # Misc
    "PulseGate":   ["rate", "pulse_width"],
    "Stutter":     ["rate", "freeze"],
    "MasterOut":   ["gain"],
    "Sampler":     ["base_note"],
    "Adsr":        ["attack_ms", "release_ms"],
}


def _format_param(name: str, value: Any) -> str:
    """Formatiert (param_name, value) kompakt — Hz für freq, dB für gain
    bei Levels, % für mix-artige, sonst rohe Zahl."""
    try:
        v = float(value)
    except (TypeError, ValueError):
        return f"{name}={value}"
    # Frequenzen: Hz, große Werte als kHz
    if name in ("freq", "cutoff", "mod_freq", "target_sr"):
        if v >= 1000:
            return f"{name}: {v/1000:.2f}kHz"
        return f"{name}: {v:.0f}Hz"
    # Zeiten in ms
    if name.endswith("_ms"):
        return f"{name}: {v:.0f}ms"
    # Sekunden (delay-time, release als Zeit)
    if name in ("time", "attack", "release", "decay", "sustain"):
        if v < 1.0:
            return f"{name}: {v*1000:.0f}ms"
        return f"{name}: {v:.2f}s"
    # dB
    if name in ("threshold", "makeup", "low_gain", "lo_mid_gain",
                "hi_mid_gain", "high_gain", "ceiling"):
        return f"{name}: {v:+.1f}dB"
    # Bits (ganzzahlig)
    if name == "bits":
        return f"{name}: {v:.0f}-bit"
    # Default — 2 Nachkommastellen
    return f"{name}: {v:.2f}"


def _select_display_params(module_kind: str, params: Dict[str, Any]) -> list:
    """Wählt die Top-3 Params pro Modul-Typ aus."""
    priority = PARAM_DISPLAY_PRIORITY.get(module_kind)
    if priority is not None:
        return [(k, params[k]) for k in priority if k in params][:3]
    # Fallback: alle Params, max 3, alphabetisch
    keys = sorted(params.keys())[:3]
    return [(k, params[k]) for k in keys]


# ════════════════════════════════════════════════════════════════════
# Telemetry-Strip-Widget
# ════════════════════════════════════════════════════════════════════


if _QT_AVAILABLE:

    class FluxTelemetryStrip(QFrame):
        """Live-Telemetry-Strip am unteren Rand des FLUX-Tabs.

        Zeigt für das selektierte Modul: Name, eff. Params, CV-Werte,
        per-Modul-CPU. Plus 💡-Button für KI-Tipp.

        Public API:
        - ``set_module(module: Optional[Module])`` — Modul-Auswahl setzen.
          ``None`` versetzt den Strip in den „idle"-Zustand.
        - ``set_telemetry(cv_values: dict, cpu_us: float)`` — von Rust-
          Telemetrie befüllbar (v.257+, jetzt Stub-tauglich).
        - ``tip_requested = pyqtSignal(str, str)`` — emittiert
          ``(module_kind_full, module_id)`` wenn der KI-Tipp-Button
          geklickt wird. Empfänger soll ki_assistant_panel öffnen mit
          dem `_FLUX_PATCH_TIP_`-Quick-Prompt-Token + Patch-Kontext.
        """

        # Signal: User wünscht KI-Tipp für ein Modul
        # → (module_kind_full="Bragi.SineOsc", module_id="abc123")
        tip_requested = pyqtSignal(str, str)

        def __init__(self, parent=None):
            super().__init__(parent)
            self._current_module = None  # type: Optional[Any]

            self.setFrameShape(QFrame.Shape.NoFrame)
            self.setStyleSheet(
                "background:#0a0e13; border-top:1px solid #1f2937; "
                "color:#cbd5e1; font-family:monospace; font-size:10px;"
            )
            self.setFixedHeight(28)

            layout = QHBoxLayout(self)
            layout.setContentsMargins(8, 3, 8, 3)
            layout.setSpacing(12)

            # ─── Sektion 1: Modul-Name ─────────────────
            self._module_label = QLabel("● keine Modul-Auswahl")
            self._module_label.setStyleSheet("color:#94a3b8;")
            self._module_label.setMinimumWidth(180)
            layout.addWidget(self._module_label)

            self._sep1 = QLabel("│")
            self._sep1.setStyleSheet("color:#1f2937;")
            layout.addWidget(self._sep1)

            # ─── Sektion 2: Eff. Params ────────────────
            self._params_label = QLabel("—")
            self._params_label.setStyleSheet("color:#a5f3fc;")  # cyan-200
            self._params_label.setMinimumWidth(220)
            self._params_label.setToolTip(
                "Top-3 Params des selektierten Moduls (Default-Werte). "
                "v.257+: zeigt effektive Werte nach CV-Modulation aus Rust-Telemetrie."
            )
            layout.addWidget(self._params_label)

            self._sep2 = QLabel("│")
            self._sep2.setStyleSheet("color:#1f2937;")
            layout.addWidget(self._sep2)

            # ─── Sektion 3: CV-Werte (Stub) ────────────
            self._cv_label = QLabel("CV: —")
            self._cv_label.setStyleSheet("color:#fcd34d;")  # amber-300
            self._cv_label.setMinimumWidth(120)
            self._cv_label.setToolTip(
                "v.257+: Block-mean CV-Werte pro modulierten Param-Port "
                "(aus Rust-Engine via IPC-Telemetrie)."
            )
            layout.addWidget(self._cv_label)

            self._sep3 = QLabel("│")
            self._sep3.setStyleSheet("color:#1f2937;")
            layout.addWidget(self._sep3)

            # ─── Sektion 4: CPU/Modul (Stub) ───────────
            self._cpu_label = QLabel("CPU: —")
            self._cpu_label.setStyleSheet("color:#fb923c;")  # orange-400
            self._cpu_label.setMinimumWidth(80)
            self._cpu_label.setToolTip(
                "v.257+: Per-Modul-CPU-Zeit in µs/Block (aus Rust-Engine-"
                "Profiler via IPC-Telemetrie)."
            )
            layout.addWidget(self._cpu_label)

            layout.addStretch(1)

            # ─── KI-Tipp-Button ────────────────────────
            self._tip_button = QPushButton("💡 KI-Tipp")
            self._tip_button.setStyleSheet(
                "QPushButton { "
                "background:#7c3aed; color:white; "
                "border:none; border-radius:3px; "
                "padding:2px 10px; font-size:10px; font-family:monospace; "
                "} "
                "QPushButton:hover { background:#a78bfa; } "
                "QPushButton:disabled { background:#1f2937; color:#475569; }"
            )
            self._tip_button.setToolTip(
                "Holt einen kontextuellen KI-Tipp zum aktuellen Patch + "
                "selektierten Modul. Nutzt das integrierte ki_assistant_panel "
                "(Claude-API, sk-ant-*-Key in den Settings)."
            )
            self._tip_button.setEnabled(False)
            self._tip_button.clicked.connect(self._on_tip_clicked)
            layout.addWidget(self._tip_button)

            self.setLayout(layout)

        # ─── Public API ────────────────────────────────────────────

        def set_module(self, module) -> None:
            """Setzt die Modul-Auswahl. None → idle."""
            self._current_module = module
            if module is None:
                self._module_label.setText("● keine Modul-Auswahl")
                self._module_label.setStyleSheet("color:#94a3b8;")
                self._params_label.setText("—")
                self._cv_label.setText("CV: —")
                self._cpu_label.setText("CPU: —")
                self._tip_button.setEnabled(False)
                return

            # Modul-Name + Kurz-ID
            god = getattr(module, "god", "?")
            kind = getattr(module, "kind", "?")
            mid = getattr(module, "id", "?")
            short_id = mid[-6:] if isinstance(mid, str) and len(mid) > 6 else mid
            self._module_label.setText(f"● {god}.{kind}#{short_id}")

            # Farbe nach God
            try:
                from pydaw.flux.yggdrasil import get_god
                desc = get_god(god)
                if desc and getattr(desc, "color_hex", None):
                    self._module_label.setStyleSheet(
                        f"color:{desc.color_hex}; font-weight:bold;")
            except Exception:
                self._module_label.setStyleSheet(
                    "color:#cbd5e1; font-weight:bold;")

            # Params kompakt
            params = getattr(module, "params", {}) or {}
            display = _select_display_params(kind, params)
            if display:
                self._params_label.setText(
                    " · ".join(_format_param(n, v) for n, v in display))
            else:
                self._params_label.setText("(keine Params)")

            # v0.0.21.258 — CV/CPU statt hartkodiertem „—":
            # Zeige Default-Werte der CV-Input-Ports. Das ist NICHT
            # live-moduliert (Rust-Datenpfad folgt v.259) aber gibt
            # sofortiges Feedback dass das Modul Inputs hat und welche
            # Werte aktiv sind. Wenn der User später am Knob dreht,
            # ändert sich port.default — also zeigt der Strip die
            # aktuell wirkenden Werte.
            try:
                from pydaw.flux.patch_model import PortKind as _PK
                cv_ports = [
                    p for p in (getattr(module, "inputs", []) or [])
                    if getattr(p, "kind", None) == _PK.CV
                ]
                if cv_ports:
                    # Erste 2 CV-Ports kompakt (gleiche Logik wie
                    # set_telemetry für Konsistenz)
                    items = []
                    for p in cv_ports[:2]:
                        try:
                            v = float(getattr(p, "default", 0.0))
                            items.append((p.name, v))
                        except (TypeError, ValueError):
                            continue
                    if items:
                        self._cv_label.setText(
                            "CV: " + ", ".join(f"{k}={v:.2f}" for k, v in items)
                        )
                        # Tooltip: Hinweis dass das Default-Werte sind
                        self._cv_label.setToolTip(
                            "Aktuelle CV-Input-Werte (Default-Werte der "
                            "CV-Input-Ports).\n"
                            "Echte Live-CV-Modulation aus dem Rust-Engine-"
                            "Datenpfad folgt in v.259."
                        )
                    else:
                        self._cv_label.setText("CV: —")
                else:
                    # Modul hat keine CV-Inputs → kompakt anzeigen
                    self._cv_label.setText("CV: (keine)")
            except Exception:
                self._cv_label.setText("CV: —")
            # CPU bleibt Stub bis v.259-Per-Modul-Profiling
            self._cpu_label.setText("CPU: —")

            self._tip_button.setEnabled(True)

        def set_telemetry(self,
                          cv_values: Optional[Dict[str, float]] = None,
                          cpu_us: Optional[float] = None) -> None:
            """v.257-Hook: setzt Live-Telemetrie aus Rust-Engine.

            Args:
                cv_values: Dict {port_name: block_mean_cv_value}
                cpu_us: Per-Modul-CPU-Zeit in µs/Block
            """
            if cv_values:
                # zeig die ersten 2 modulierten Ports kompakt
                items = list(cv_values.items())[:2]
                if items:
                    parts = [f"{k}={v:.2f}" for k, v in items]
                    self._cv_label.setText("CV: " + ", ".join(parts))
                else:
                    self._cv_label.setText("CV: —")
            if cpu_us is not None:
                if cpu_us < 1.0:
                    self._cpu_label.setText(f"CPU: {cpu_us*1000:.0f}ns")
                elif cpu_us < 100.0:
                    self._cpu_label.setText(f"CPU: {cpu_us:.1f}µs")
                else:
                    self._cpu_label.setText(f"CPU: {cpu_us:.0f}µs")

        # ─── Slots ────────────────────────────────────────────────

        def _on_tip_clicked(self) -> None:
            """KI-Tipp-Button gedrückt → emittiere tip_requested."""
            if self._current_module is None:
                return
            god = getattr(self._current_module, "god", "?")
            kind = getattr(self._current_module, "kind", "?")
            mid = getattr(self._current_module, "id", "?")
            module_kind_full = f"{god}.{kind}"
            self.tip_requested.emit(module_kind_full, str(mid))

else:
    # Qt nicht verfügbar — Headless-Stub für CI/Tests
    class FluxTelemetryStrip:  # type: ignore
        def __init__(self, parent=None): pass
        def set_module(self, module): pass
        def set_telemetry(self, cv_values=None, cpu_us=None): pass


__all__ = [
    "FluxTelemetryStrip",
    "PARAM_DISPLAY_PRIORITY",
]
