"""MIDI Controller Profiles & Auto-Configuration (P4A + P4B).

Supports Novation Launchpad, Akai APC40/APC Mini, Ableton Push.
Auto-detects connected controllers and applies optimal mapping.

Features:
- Controller profile database with pad/knob/fader/button layouts
- Auto-detect by MIDI device name matching
- Clip launcher grid mapping (pad → scene/clip launch)
- Mixer mapping (faders → track volume, knobs → pan/send)
- Transport mapping (buttons → play/stop/record)
- LED feedback protocol per controller type

v0.0.20.810 — Phase P4A + P4B
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Tuple, Any, Callable

from PyQt6.QtCore import QObject, pyqtSignal

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data model: Controller Profile
# ---------------------------------------------------------------------------

@dataclass
class PadMapping:
    """Single pad → DAW action mapping."""
    midi_note: int          # MIDI note number this pad sends
    row: int = 0            # grid row (0 = top)
    col: int = 0            # grid column (0 = left)
    action: str = ""        # "clip_launch"|"scene_launch"|"stop_track"|"none"
    color_on: int = 0       # LED color when active (controller-specific)
    color_off: int = 0      # LED color when inactive
    color_playing: int = 0  # LED color when clip is playing


@dataclass
class FaderMapping:
    """Fader/knob → DAW parameter mapping."""
    cc: int                 # MIDI CC number
    channel: int = 0        # MIDI channel
    param: str = ""         # "volume"|"pan"|"send1"|"send2"|...
    track_offset: int = 0   # which track (relative to bank offset)
    is_fader: bool = True   # True=fader, False=knob


@dataclass
class ButtonMapping:
    """Button → DAW transport/action mapping."""
    midi_note: int = -1     # note number (-1 = CC instead)
    cc: int = -1            # CC number (-1 = note instead)
    channel: int = 0
    action: str = ""        # "play"|"stop"|"record"|"tap_tempo"|"undo"|"redo"
    is_toggle: bool = False
    color_on: int = 0
    color_off: int = 0


@dataclass
class ControllerProfile:
    """Complete profile for a MIDI controller."""
    name: str                           # Human-readable name
    match_patterns: List[str]           # Regex patterns to match device name
    manufacturer: str = ""
    grid_rows: int = 0                  # Pad grid dimensions
    grid_cols: int = 0
    pads: List[PadMapping] = field(default_factory=list)
    faders: List[FaderMapping] = field(default_factory=list)
    knobs: List[FaderMapping] = field(default_factory=list)
    buttons: List[ButtonMapping] = field(default_factory=list)
    has_led_feedback: bool = False
    led_sysex_header: bytes = b""       # SysEx prefix for LED commands
    note_mode_channel: int = 0          # Channel for pad notes
    cc_mode_channel: int = 0            # Channel for CC messages
    bank_size: int = 8                  # Tracks per bank page
    description: str = ""

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "manufacturer": self.manufacturer,
            "grid": f"{self.grid_rows}x{self.grid_cols}",
            "pads": len(self.pads),
            "faders": len(self.faders),
            "knobs": len(self.knobs),
            "buttons": len(self.buttons),
            "has_led_feedback": self.has_led_feedback,
            "description": self.description,
        }


# ---------------------------------------------------------------------------
# Built-in controller profiles
# ---------------------------------------------------------------------------

def _build_launchpad_mini_mk3() -> ControllerProfile:
    """Novation Launchpad Mini MK3 — 8x8 RGB pad grid."""
    pads = []
    # Launchpad Mini MK3 uses notes 81-11 (top-left=81, bottom-right=11)
    # Row 0 (top) = notes 81-88, Row 7 (bottom) = notes 11-18
    for row in range(8):
        for col in range(8):
            note = (8 - row) * 10 + (col + 1)  # Launchpad note layout
            action = "clip_launch" if col < 8 else "scene_launch"
            pads.append(PadMapping(
                midi_note=note, row=row, col=col,
                action=action,
                color_on=21,    # green
                color_off=0,    # off
                color_playing=72,  # yellow pulse
            ))

    # Scene launch buttons (right column, notes 89, 79, 69...)
    scene_buttons = []
    for row in range(8):
        note = (8 - row) * 10 + 9
        scene_buttons.append(ButtonMapping(
            midi_note=note, action="scene_launch",
            color_on=53, color_off=0,
        ))

    return ControllerProfile(
        name="Novation Launchpad Mini MK3",
        match_patterns=[r"(?i)launchpad\s*mini.*mk3", r"(?i)launchpad\s*mini"],
        manufacturer="Novation",
        grid_rows=8, grid_cols=8,
        pads=pads,
        buttons=scene_buttons,
        has_led_feedback=True,
        led_sysex_header=b"\xf0\x00\x20\x29\x02\x0d",
        bank_size=8,
        description="8x8 RGB Pad Grid, Scene Launch, Clip Launcher optimiert",
    )


def _build_launchpad_x() -> ControllerProfile:
    """Novation Launchpad X — 8x8 RGB pad grid with velocity sensitivity."""
    pads = []
    for row in range(8):
        for col in range(8):
            note = (8 - row) * 10 + (col + 1)
            pads.append(PadMapping(
                midi_note=note, row=row, col=col,
                action="clip_launch",
                color_on=21, color_off=0, color_playing=72,
            ))

    return ControllerProfile(
        name="Novation Launchpad X",
        match_patterns=[r"(?i)launchpad\s*x", r"(?i)launchpad.*lp\s*x"],
        manufacturer="Novation",
        grid_rows=8, grid_cols=8,
        pads=pads,
        has_led_feedback=True,
        led_sysex_header=b"\xf0\x00\x20\x29\x02\x0c",
        bank_size=8,
        description="8x8 RGB Velocity-Sensitive Pad Grid",
    )


def _build_apc_mini_mk2() -> ControllerProfile:
    """Akai APC Mini MK2 — 8x8 pad grid + 9 faders."""
    pads = []
    # APC Mini: notes 0-63 in 8x8 grid (bottom-left = 0, top-right = 63)
    for row in range(8):
        for col in range(8):
            note = row * 8 + col
            pads.append(PadMapping(
                midi_note=note, row=7 - row, col=col,  # flip row
                action="clip_launch",
                color_on=1,     # green
                color_off=0,    # off
                color_playing=5,  # yellow blink
            ))

    faders = []
    for i in range(9):
        faders.append(FaderMapping(
            cc=48 + i, param="volume" if i < 8 else "master_volume",
            track_offset=i, is_fader=True,
        ))

    # Bottom row buttons (scene launch)
    scene_buttons = []
    for i in range(8):
        scene_buttons.append(ButtonMapping(
            midi_note=64 + i, action="scene_launch",
            color_on=1, color_off=0,
        ))

    # Shift/transport buttons
    transport = [
        ButtonMapping(cc=98, action="record", is_toggle=True),
        ButtonMapping(cc=99, action="play", is_toggle=True),
    ]

    return ControllerProfile(
        name="Akai APC Mini MK2",
        match_patterns=[r"(?i)apc\s*mini.*mk2", r"(?i)apc\s*mini"],
        manufacturer="Akai",
        grid_rows=8, grid_cols=8,
        pads=pads,
        faders=faders,
        buttons=scene_buttons + transport,
        has_led_feedback=True,
        bank_size=8,
        description="8x8 Pad Grid + 9 Faders, Clip Launcher + Mixer",
    )


def _build_apc40_mk2() -> ControllerProfile:
    """Akai APC40 MK2 — 5x8 clip grid + 8 faders + 8 knobs."""
    pads = []
    for row in range(5):
        for col in range(8):
            note = (4 - row) * 8 + col
            pads.append(PadMapping(
                midi_note=note, row=row, col=col,
                action="clip_launch",
                color_on=1, color_off=0, color_playing=5,
            ))

    faders = [FaderMapping(cc=7 + i, param="volume", track_offset=i) for i in range(8)]
    faders.append(FaderMapping(cc=14, param="master_volume", track_offset=8))

    knobs = []
    for i in range(8):
        knobs.append(FaderMapping(cc=48 + i, param="pan", track_offset=i, is_fader=False))
    for i in range(8):
        knobs.append(FaderMapping(cc=16 + i, param="send1", track_offset=i, is_fader=False))

    transport = [
        ButtonMapping(midi_note=91, action="play"),
        ButtonMapping(midi_note=92, action="stop"),
        ButtonMapping(midi_note=93, action="record", is_toggle=True),
        ButtonMapping(midi_note=97, action="tap_tempo"),
    ]

    return ControllerProfile(
        name="Akai APC40 MK2",
        match_patterns=[r"(?i)apc\s*40.*mk2", r"(?i)apc\s*40"],
        manufacturer="Akai",
        grid_rows=5, grid_cols=8,
        pads=pads,
        faders=faders,
        knobs=knobs,
        buttons=transport,
        has_led_feedback=True,
        bank_size=8,
        description="5x8 Clip Grid + 8 Faders + 16 Knobs + Transport",
    )


def _build_push2() -> ControllerProfile:
    """Ableton Push 2 (basic support) — 8x8 pad grid + 8 encoders."""
    pads = []
    for row in range(8):
        for col in range(8):
            note = 36 + row * 8 + col  # Push 2 note layout
            pads.append(PadMapping(
                midi_note=note, row=7 - row, col=col,
                action="clip_launch",
                color_on=21, color_off=0, color_playing=9,
            ))

    knobs = [FaderMapping(cc=71 + i, param="pan" if i < 8 else "send1",
                          track_offset=i % 8, is_fader=False) for i in range(8)]

    transport = [
        ButtonMapping(cc=85, action="play"),
        ButtonMapping(cc=86, action="record", is_toggle=True),
    ]

    return ControllerProfile(
        name="Ableton Push 2",
        match_patterns=[r"(?i)ableton\s*push\s*2", r"(?i)push\s*2"],
        manufacturer="Ableton",
        grid_rows=8, grid_cols=8,
        pads=pads,
        knobs=knobs,
        buttons=transport,
        has_led_feedback=True,
        bank_size=8,
        description="8x8 Velocity-Sensitive Pads + 8 Encoders",
    )


def _build_generic_8x8() -> ControllerProfile:
    """Generic 8x8 MIDI pad controller (fallback profile)."""
    pads = []
    for row in range(8):
        for col in range(8):
            note = row * 8 + col
            pads.append(PadMapping(
                midi_note=note, row=row, col=col,
                action="clip_launch",
            ))
    return ControllerProfile(
        name="Generic 8x8 Pad Controller",
        match_patterns=[r"(?i)pad", r"(?i)grid"],
        manufacturer="Generic",
        grid_rows=8, grid_cols=8,
        pads=pads,
        bank_size=8,
        description="Generisches 8x8 Pad Grid — universelles Mapping",
    )


# ── Profile Registry ─────────────────────────────────────────────────────

_ALL_PROFILES: List[ControllerProfile] = [
    _build_launchpad_mini_mk3(),
    _build_launchpad_x(),
    _build_apc_mini_mk2(),
    _build_apc40_mk2(),
    _build_push2(),
    _build_generic_8x8(),
]


def get_all_profiles() -> List[ControllerProfile]:
    """Return all known controller profiles."""
    return list(_ALL_PROFILES)


def find_profile_by_name(device_name: str) -> Optional[ControllerProfile]:
    """Auto-detect controller profile from MIDI device name.

    Args:
        device_name: e.g. "Launchpad Mini MK3 MIDI 1"

    Returns:
        Matching ControllerProfile or None.
    """
    for profile in _ALL_PROFILES:
        for pattern in profile.match_patterns:
            if re.search(pattern, device_name):
                log.info("Controller erkannt: %s → %s", device_name, profile.name)
                return profile
    return None


# ---------------------------------------------------------------------------
# Controller Auto-Config Service
# ---------------------------------------------------------------------------

class ControllerAutoConfig(QObject):
    """Monitors MIDI inputs and auto-configures recognized controllers.

    Connects to MidiManager.inputs_changed to detect new controllers.
    """

    controller_detected = pyqtSignal(str, object)   # device_name, ControllerProfile
    controller_lost = pyqtSignal(str)                # device_name
    mapping_applied = pyqtSignal(str, str)           # device_name, profile_name
    status = pyqtSignal(str)

    def __init__(
        self,
        midi_manager=None,
        midi_mapping_service=None,
        clip_launcher_playback=None,
        transport=None,
        parent=None,
    ):
        super().__init__(parent)
        self._midi_manager = midi_manager
        self._mapping = midi_mapping_service
        self._launcher = clip_launcher_playback
        self._transport = transport

        self._active_profiles: Dict[str, ControllerProfile] = {}
        self._bank_offset: int = 0  # current bank page (track offset)

        # Auto-scan on inputs_changed
        if midi_manager is not None:
            try:
                midi_manager.inputs_changed.connect(self._on_inputs_changed)
            except Exception:
                pass

    def scan_and_configure(self) -> List[Tuple[str, ControllerProfile]]:
        """Scan all connected MIDI inputs and auto-configure recognized controllers.

        Returns list of (device_name, profile) tuples for detected controllers.
        """
        detected: List[Tuple[str, ControllerProfile]] = []

        mm = self._midi_manager
        if mm is None:
            return detected

        device_names = getattr(mm, 'get_input_names', lambda: [])()
        if not device_names:
            # Try mido directly
            try:
                import mido
                device_names = mido.get_input_names()
            except Exception:
                pass

        for name in device_names:
            if name in self._active_profiles:
                continue
            profile = find_profile_by_name(name)
            if profile is not None:
                self._active_profiles[name] = profile
                self._apply_profile(name, profile)
                detected.append((name, profile))
                try:
                    self.controller_detected.emit(name, profile)
                    self.mapping_applied.emit(name, profile.name)
                    self.status.emit(f"🎛 {profile.name} erkannt und konfiguriert")
                except Exception:
                    pass

        return detected

    def _on_inputs_changed(self) -> None:
        """Called when MIDI inputs change — rescan for controllers."""
        self.scan_and_configure()

    def _apply_profile(self, device_name: str, profile: ControllerProfile) -> None:
        """Apply a controller profile's mappings to the DAW."""
        mapping_svc = self._mapping
        if mapping_svc is None:
            return

        # Apply fader mappings
        for fm in profile.faders:
            try:
                mapping_svc.assign_cc(
                    cc=fm.cc, channel=fm.channel,
                    track_offset=fm.track_offset + self._bank_offset,
                    param=fm.param,
                )
            except Exception:
                pass

        # Apply knob mappings
        for km in profile.knobs:
            try:
                mapping_svc.assign_cc(
                    cc=km.cc, channel=km.channel,
                    track_offset=km.track_offset + self._bank_offset,
                    param=km.param,
                )
            except Exception:
                pass

        log.info("Profile applied: %s (%d faders, %d knobs, %d pads)",
                 profile.name, len(profile.faders), len(profile.knobs), len(profile.pads))

    def get_active_controllers(self) -> Dict[str, ControllerProfile]:
        """Return dict of currently active controller profiles."""
        return dict(self._active_profiles)

    def set_bank_offset(self, offset: int) -> None:
        """Shift the track bank (for paging through tracks)."""
        self._bank_offset = max(0, offset)
        # Re-apply all profiles with new offset
        for name, profile in self._active_profiles.items():
            self._apply_profile(name, profile)

    def bank_left(self) -> None:
        """Move track bank one page left."""
        bank_size = 8
        if self._active_profiles:
            bank_size = next(iter(self._active_profiles.values())).bank_size
        self.set_bank_offset(max(0, self._bank_offset - bank_size))

    def bank_right(self) -> None:
        """Move track bank one page right."""
        bank_size = 8
        if self._active_profiles:
            bank_size = next(iter(self._active_profiles.values())).bank_size
        self.set_bank_offset(self._bank_offset + bank_size)

    def handle_pad_press(self, note: int, velocity: int) -> bool:
        """Handle a pad press from a recognized controller.

        Returns True if handled (should not be forwarded as note).
        """
        for profile in self._active_profiles.values():
            for pad in profile.pads:
                if pad.midi_note == note:
                    if pad.action == "clip_launch" and self._launcher:
                        scene_idx = pad.row
                        track_idx = pad.col + self._bank_offset
                        try:
                            self._launcher.launch_clip_at(track_idx, scene_idx)
                        except Exception:
                            try:
                                self._launcher.launch_scene(scene_idx)
                            except Exception:
                                pass
                        return True
                    elif pad.action == "scene_launch" and self._launcher:
                        try:
                            self._launcher.launch_scene(pad.row)
                        except Exception:
                            pass
                        return True
                    elif pad.action == "stop_track" and self._launcher:
                        try:
                            self._launcher.stop_track(pad.col + self._bank_offset)
                        except Exception:
                            pass
                        return True
        return False

    def handle_button_press(self, note_or_cc: int, is_cc: bool = False) -> bool:
        """Handle a transport/utility button press."""
        transport = self._transport
        for profile in self._active_profiles.values():
            for btn in profile.buttons:
                match = (btn.cc == note_or_cc if is_cc
                         else btn.midi_note == note_or_cc)
                if match and transport:
                    if btn.action == "play":
                        try: transport.play()
                        except Exception: pass
                        return True
                    elif btn.action == "stop":
                        try: transport.stop()
                        except Exception: pass
                        return True
                    elif btn.action == "record":
                        try: transport.toggle_record()
                        except Exception: pass
                        return True
                    elif btn.action == "tap_tempo":
                        try: transport.tap_tempo()
                        except Exception: pass
                        return True
                    elif btn.action == "scene_launch" and self._launcher:
                        # Scene launch buttons
                        try:
                            idx = [b for b in profile.buttons
                                   if b.action == "scene_launch"].index(btn)
                            self._launcher.launch_scene(idx)
                        except Exception:
                            pass
                        return True
        return False

    def shutdown(self) -> None:
        """Cleanup."""
        self._active_profiles.clear()
