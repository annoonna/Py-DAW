"""
pydaw.services.flux_vault_factory_soviet — V-3 Soviet-Synths Factory-Presets

**v0.0.21.255 — Soviet v1 (Iron-Curtain-Edition)**
====================================================

12 ikonische sowjetische Synthesizer + Raumfahrt-Hommagen, übersetzt in
das modulare FLUX-System.  Charakter-Modul-Schema aus v.199/v.201
(Sacred-v2/Synthwave-v1) konsequent übernommen — jeder Preset bekommt
ein einzigartiges Charakter-Modul.

Hintergrund:
* **Polivoks** (1982, Polushkin) — ikonischer aggressiver Sound mit
  dirty Filter; Hauptinstrument vieler sowjetischer Bands der 80er.
* **ANS** (1937-1958, Murzin) — photoelektronischer Synthesizer; Tarkovsky
  hat ihn für *Solaris* und *Stalker* eingesetzt.
* **AELITA** — sowjetischer Brass/String-Synth.
* **Formanta** — sowjetische PM/FM-Synthese-Linie.
* Raumfahrt-Hommagen: Sputnik, Soyuz, Vostok, Mir, Salyut, Solyaris,
  Stalker (Tarkovsky), Lunokhod (Mond-Rover).

| Preset    | Charakter-Modul                       | Klang-Identität                          |
|-----------|---------------------------------------|------------------------------------------|
| Polivoks  | Saw + Bandpass-Resonance + Tube       | THE classic dirty Soviet lead            |
| ANS       | Noise + Phaser + huge Reverb          | photoelektrischer Tarkovsky-Drone        |
| Stalker   | Triangle + LFO-Drift + Decimator+Rev  | dunkle Zone-Ambient-Atmosphäre           |
| Solyaris  | Formant + LFO-Vibrato + huge Reverb   | kosmischer Bewusstseins-Pad              |
| Sputnik   | Square + BitCrush + Slap-Delay        | bleepy 1957er Retro-Lead                 |
| Soyuz     | Sub + Drift + LFO-Sweep + Decimator   | Raumfahrt-Sub-Bass mit Gleitflug         |
| Vostok    | FM + Tube + Sub-Layer                 | Gagarin-Bass (1961, erste Bemannung)     |
| Mir       | Triangle + Chorus + huge Reverb       | Raumstation-Pad (orbital, weich)         |
| Salyut    | Saw + LFO→Cutoff + Delay              | Sequencer-Lead (erste Raumstation, '71)  |
| AELITA    | Swarm + Tube + EQ4 (mid-heavy)        | sowjetischer Messing-Brass               |
| Formanta  | FM + Phaser + Reverb                  | PM-Glocke (Mirage-Hommage)               |
| Lunokhod  | Bite + Decimator + Compressor         | Mond-Rover Concrete-Bass                 |

Design-Notizen:
- v.255 nutzt den vollen Bragi-Familien-Reichtum (Saw, Square, Triangle,
  Noise, FormantOsc, FMOsc, SwarmOsc, BiteOsc, SubOsc, DriftOsc) — der
  CV-Sweep aus v.252-254 ist die Foundation, die diese Patches überhaupt
  modulierbar macht.
- Mehrere Patches nutzen LFO→Param-Routing (Salyut: LFO→Cutoff;
  Soyuz: LFO→Sub-pitch; Mir: LFO→Chorus.rate für Schwebung) — alle
  funktionieren ab v.252.A nahtlos.
- Versions-Marker ``"FLUX Factory (Soviet v1)"`` für sauberes Re-Seeding.
"""

from __future__ import annotations

import logging
from typing import Optional

logger = logging.getLogger(__name__)


SOVIET_FACTORY_VERSION = "v1"
SOVIET_FACTORY_AUTHOR = (
    f"FLUX Factory (Soviet {SOVIET_FACTORY_VERSION})"
)


# ─── Helper (analog Synthwave-Factory) ──────────────────────────────


def _connect(patch, src_id: str, src_port: str,
             tgt_id: str, tgt_port: str) -> bool:
    """Helper: Connection hinzufügen, defensiv gegen fehlende Module."""
    from pydaw.flux.patch_model import Connection
    src = patch.get_module(src_id)
    tgt = patch.get_module(tgt_id)
    if src is None or tgt is None:
        return False
    return patch.add_connection(Connection(
        source_module=src_id, source_port=src_port,
        target_module=tgt_id, target_port=tgt_port,
    ))


def _set(module, **params) -> None:
    """Helper: Module-Params setzen (defensiv gegen fehlende Keys)."""
    if module is None:
        return
    for k, v in params.items():
        if k in module.params:
            module.params[k] = v


def _build_patch_dict(name: str, builder) -> Optional[dict]:
    """Wrappt einen Patch-Builder in to_dict, defensiv gegen Fehler."""
    try:
        from pydaw.flux.patch_model import Patch
        p = builder()
        if not isinstance(p, Patch):
            return None
        p.name = name
        return p.to_dict()
    except Exception as e:
        logger.warning("[SovietPresets-v1] build %s failed: %s", name, e)
        return None


# ─── Patch-Builder (Soviet v1) ──────────────────────────────────────


def _build_polivoks():
    """Polivoks — Saw + Bandpass-Resonance + Tube (THE classic Soviet lead).

    Charakter: der Polivoks (1982, Vladimir Kuzmin/Ladislav Polushkin)
    war DAS sowjetische Synth-Brot — bekannt für seinen aggressiven,
    schmutzigen Filter mit Selbst-Resonanz. Saw durch Bandpass mit hoher
    Resonance, dann Tube-Drive für die typische Verschmutzung. Klassischer
    80er-Sowjet-Rock-Lead-Sound.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_saw_osc, make_forseti_bandpass,
        make_thor_tube_drive, make_vidar_compressor,
        make_iduna_delay, make_heimdall_master_out,
    )
    p = Patch(name="Polivoks")
    osc = make_bragi_saw_osc(); osc.position = (60, 200)
    _set(osc, freq=220.0, gain=0.45)  # A3
    bp = make_forseti_bandpass(); bp.position = (260, 200)
    _set(bp, cutoff=900.0, resonance=8.5)  # screaming Polivoks-Filter
    drive = make_thor_tube_drive(); drive.position = (460, 200)
    _set(drive, drive=14.0, tone=0.35, mix=0.85)  # dirty
    comp = make_vidar_compressor(); comp.position = (660, 200)
    _set(comp, threshold=-12.0, ratio=4.0,
         attack_ms=2.0, release_ms=80.0, makeup=3.0)
    delay = make_iduna_delay(); delay.position = (860, 200)
    _set(delay, time=0.18, feedback=0.3, mix=0.18, tone=3500.0)  # Slapback
    out = make_heimdall_master_out(); out.position = (1060, 200)
    for m in (osc, bp, drive, comp, delay, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", bp.id, "audio_in")
    _connect(p, bp.id, "audio_out", drive.id, "audio_in")
    _connect(p, drive.id, "audio_out", comp.id, "audio_in")
    _connect(p, comp.id, "audio_out", delay.id, "audio_in")
    _connect(p, delay.id, "audio_out", out.id, "audio_in_l")
    _connect(p, delay.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_ans():
    """ANS — Noise + Phaser + huge Reverb (photoelektrischer Drone).

    Charakter: der ANS (1937-1958, Evgeny Murzin) war ein photoelektronischer
    Synthesizer — Klang aus Lichtstrahlen, gefiltert durch optische Scheiben.
    Tarkovsky setzte ihn in *Solaris* und *Stalker* ein. Sound: rauschartig,
    spektral, weit hallend. Hier: Noise als Quelle, Phaser für die spektrale
    Modulation der photoelektrischen „Striche", riesiger Reverb für Tarkovsky-
    Atmosphäre.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_noise_osc, make_forseti_lowpass,
        make_skadi_phaser, make_iduna_reverb,
        make_loki_lfo_sine, make_heimdall_master_out,
    )
    p = Patch(name="ANS")
    noise = make_bragi_noise_osc(); noise.position = (60, 200)
    _set(noise, gain=0.35)
    lp = make_forseti_lowpass(); lp.position = (260, 200)
    _set(lp, cutoff=1800.0, resonance=0.6)  # spektral fokussiert
    phaser = make_skadi_phaser(); phaser.position = (460, 200)
    _set(phaser, rate=0.15, depth=0.85, feedback=0.7, mix=0.65)  # langsam tief
    rev = make_iduna_reverb(); rev.position = (660, 200)
    _set(rev, room_size=0.95, damping=0.25, mix=0.7)  # Tarkovsky-weit
    # LFO modulert Lowpass-cutoff für „atmende" photoelektrische Bewegung
    lfo = make_loki_lfo_sine(); lfo.position = (60, 60)
    _set(lfo, rate=0.07, depth=0.4)  # extrem langsam
    out = make_heimdall_master_out(); out.position = (860, 200)
    for m in (noise, lp, phaser, rev, lfo, out):
        p.add_module(m)
    _connect(p, noise.id, "audio_out", lp.id, "audio_in")
    _connect(p, lp.id, "audio_out", phaser.id, "audio_in")
    _connect(p, phaser.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    _connect(p, lfo.id, "cv_out", lp.id, "cutoff")
    return p


def _build_stalker():
    """Stalker — Triangle + LFO-Drift + Decimator + huge Reverb (Zone-Ambient).

    Charakter: Tarkovsky's *Stalker* (1979) — die „Zone" als unheimlicher,
    dunkler Raum. Triangle-Drone als Basis, sanfter LFO-Drift auf der
    Frequenz für unheimliche Schwebung, dezenter Decimator für analoge
    Verfremdung, riesiger gedämpfter Reverb.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_triangle_osc, make_loki_lfo_triangle,
        make_fenrir_decimator, make_forseti_lowpass,
        make_iduna_reverb, make_heimdall_master_out,
    )
    p = Patch(name="Stalker")
    osc = make_bragi_triangle_osc(); osc.position = (60, 200)
    _set(osc, freq=98.0, gain=0.5)  # G2 — tief
    lfo = make_loki_lfo_triangle(); lfo.position = (60, 60)
    _set(lfo, rate=0.13, depth=0.06)  # subtile Drift
    dec = make_fenrir_decimator(); dec.position = (260, 200)
    _set(dec, target_sr=12000.0, mix=0.4)  # leichte analoge Degradation
    lp = make_forseti_lowpass(); lp.position = (460, 200)
    _set(lp, cutoff=900.0, resonance=0.7)  # gedämpft
    rev = make_iduna_reverb(); rev.position = (660, 200)
    _set(rev, room_size=0.92, damping=0.65, mix=0.78)  # weit + gedämpft
    out = make_heimdall_master_out(); out.position = (860, 200)
    for m in (osc, lfo, dec, lp, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", dec.id, "audio_in")
    _connect(p, dec.id, "audio_out", lp.id, "audio_in")
    _connect(p, lp.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    # LFO → osc.freq (Drift) — v.252-CV-Sweep ermöglicht dies
    _connect(p, lfo.id, "cv_out", osc.id, "freq")
    return p


def _build_solyaris():
    """Solyaris — Formant + LFO-Vibrato + huge Reverb (kosmischer Pad).

    Charakter: Tarkovsky's *Solaris* (1972). Der Ozean-Planet, der
    Erinnerungen materialisiert. FormantOsc liefert vokale Formanten —
    klingt wie ferne Stimmen. LFO-Vibrato auf Vowel-Position lässt die
    Formanten gleiten, riesiger Reverb für die ozeanische Weite.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_formant_osc, make_loki_lfo_sine,
        make_skadi_chorus, make_iduna_reverb,
        make_heimdall_master_out,
    )
    p = Patch(name="Solyaris")
    osc = make_bragi_formant_osc(); osc.position = (60, 200)
    _set(osc, freq=174.61, gain=0.35,  # F3
         vowel=0.5, formant_shift=1.0, resonance=4.0)
    lfo = make_loki_lfo_sine(); lfo.position = (60, 60)
    _set(lfo, rate=0.25, depth=0.35)
    chorus = make_skadi_chorus(); chorus.position = (260, 200)
    _set(chorus, rate=0.4, depth=0.65, mix=0.55)
    rev = make_iduna_reverb(); rev.position = (460, 200)
    _set(rev, room_size=0.97, damping=0.3, mix=0.72)  # ozeanisch weit
    out = make_heimdall_master_out(); out.position = (660, 200)
    for m in (osc, lfo, chorus, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", chorus.id, "audio_in")
    _connect(p, chorus.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    # LFO → osc.vowel — gleitende Formanten (v.252-CV-Sweep)
    _connect(p, lfo.id, "cv_out", osc.id, "vowel")
    return p


def _build_sputnik():
    """Sputnik — Square + BitCrush + Slap-Delay (1957 Retro-Beep).

    Charakter: der erste künstliche Satellit (1957) sandte das ikonische
    „Beep-Beep-Beep" Signal. Hier: Square mit leichtem BitCrush für den
    8-Bit-Funkfunk-Charakter, kurzer Slap-Delay für das Echo durch die
    Ionosphäre.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_square_osc, make_fenrir_bit_crush,
        make_iduna_delay, make_iduna_reverb,
        make_heimdall_master_out,
    )
    p = Patch(name="Sputnik")
    osc = make_bragi_square_osc(); osc.position = (60, 200)
    _set(osc, freq=523.25, gain=0.4, pulse_width=0.5)  # C5 - bleep tone
    crush = make_fenrir_bit_crush(); crush.position = (260, 200)
    _set(crush, bits=6.0, mix=0.55)  # 6-bit Funkfunk
    delay = make_iduna_delay(); delay.position = (460, 200)
    _set(delay, time=0.12, feedback=0.55, mix=0.4, tone=3000.0)  # ionosphäre
    rev = make_iduna_reverb(); rev.position = (660, 200)
    _set(rev, room_size=0.45, damping=0.55, mix=0.22)
    out = make_heimdall_master_out(); out.position = (860, 200)
    for m in (osc, crush, delay, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", crush.id, "audio_in")
    _connect(p, crush.id, "audio_out", delay.id, "audio_in")
    _connect(p, delay.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_soyuz():
    """Soyuz — SubOsc + Drift + LFO-Sweep + Decimator (Raumfahrt-Sub-Bass).

    Charakter: Soyuz (russisch „Verbindung") — die robusteste Raumfähre
    der Geschichte, im Einsatz seit 1967. Sub-Oszillator als tiefes
    Fundament, Drift für analoges Pitch-Wobble (wie die Triebwerke),
    LFO-Sweep auf Cutoff für den Start-Schub-Effekt.

    Topologie: Sub + Drift werden via Ullr.Plus summiert (zwei parallele
    Layers — eine Verbindung pro Input verhindert direktes Stacken).
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_sub_osc, make_bragi_drift_osc,
        make_ullr_plus, make_forseti_lowpass,
        make_loki_lfo_sine, make_fenrir_decimator,
        make_thor_tube_drive, make_heimdall_master_out,
    )
    p = Patch(name="Soyuz")
    sub = make_bragi_sub_osc(); sub.position = (60, 200)
    _set(sub, freq=55.0, gain=0.5, octaves=2.0)  # A1 + 2 octaves
    drift = make_bragi_drift_osc(); drift.position = (60, 320)
    _set(drift, freq=110.0, gain=0.3,  # A2 layer
         drift_amount=0.25, drift_rate=0.4, warmth=0.6)
    mix = make_ullr_plus(); mix.position = (260, 260)  # mixt sub + drift
    lp = make_forseti_lowpass(); lp.position = (460, 260)
    _set(lp, cutoff=400.0, resonance=2.5)  # tief gefiltert
    lfo = make_loki_lfo_sine(); lfo.position = (460, 80)
    _set(lfo, rate=0.18, depth=600.0)  # Schub-Sweep
    dec = make_fenrir_decimator(); dec.position = (660, 260)
    _set(dec, target_sr=18000.0, mix=0.3)
    drive = make_thor_tube_drive(); drive.position = (860, 260)
    _set(drive, drive=8.0, tone=0.4, mix=0.55)
    out = make_heimdall_master_out(); out.position = (1060, 260)
    for m in (sub, drift, mix, lp, lfo, dec, drive, out):
        p.add_module(m)
    _connect(p, sub.id, "audio_out", mix.id, "audio_in_a")
    _connect(p, drift.id, "audio_out", mix.id, "audio_in_b")
    _connect(p, mix.id, "audio_out", lp.id, "audio_in")
    _connect(p, lp.id, "audio_out", dec.id, "audio_in")
    _connect(p, dec.id, "audio_out", drive.id, "audio_in")
    _connect(p, drive.id, "audio_out", out.id, "audio_in_l")
    _connect(p, drive.id, "audio_out", out.id, "audio_in_r")
    # LFO → Lowpass-cutoff (Schub-Modulation)
    _connect(p, lfo.id, "cv_out", lp.id, "cutoff")
    return p


def _build_vostok():
    """Vostok — FM + Tube + Sub-Layer (Gagarin-Bass, 1961).

    Charakter: Vostok 1 (1961) — Yuri Gagarin's erste bemannte Raumfahrt.
    FM-Synthese gibt den klassischen DX7-Brass-Bass-Sound, kombiniert
    mit Sub-Layer für Tiefe und Tube-Drive für Wärme.

    Topologie: FM + Sub via Ullr.Plus summiert (zwei parallele Layers).
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_fm_osc, make_bragi_sub_osc,
        make_ullr_plus, make_thor_tube_drive,
        make_vidar_compressor, make_forseti_lowpass,
        make_heimdall_master_out,
    )
    p = Patch(name="Vostok")
    fm = make_bragi_fm_osc(); fm.position = (60, 200)
    _set(fm, freq=87.31, gain=0.45,  # F2
         mod_ratio=2.0, mod_index=3.5, feedback=0.2)
    sub = make_bragi_sub_osc(); sub.position = (60, 320)
    _set(sub, freq=43.65, gain=0.3, octaves=1.0)  # F1
    mix = make_ullr_plus(); mix.position = (260, 260)
    lp = make_forseti_lowpass(); lp.position = (460, 260)
    _set(lp, cutoff=1800.0, resonance=1.0)
    drive = make_thor_tube_drive(); drive.position = (660, 260)
    _set(drive, drive=10.0, tone=0.45, mix=0.7)
    comp = make_vidar_compressor(); comp.position = (860, 260)
    _set(comp, threshold=-14.0, ratio=4.0,
         attack_ms=8.0, release_ms=120.0, makeup=4.0)
    out = make_heimdall_master_out(); out.position = (1060, 260)
    for m in (fm, sub, mix, lp, drive, comp, out):
        p.add_module(m)
    _connect(p, fm.id, "audio_out", mix.id, "audio_in_a")
    _connect(p, sub.id, "audio_out", mix.id, "audio_in_b")
    _connect(p, mix.id, "audio_out", lp.id, "audio_in")
    _connect(p, lp.id, "audio_out", drive.id, "audio_in")
    _connect(p, drive.id, "audio_out", comp.id, "audio_in")
    _connect(p, comp.id, "audio_out", out.id, "audio_in_l")
    _connect(p, comp.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_mir():
    """Mir — Triangle + Chorus + huge Reverb (orbital station pad).

    Charakter: die Raumstation Mir („Frieden") (1986-2001) — sanftes,
    weiches Schweben in der Umlaufbahn. Triangle-Pad, breiter Chorus mit
    LFO-modulierter Rate, riesiger weicher Reverb.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_triangle_osc, make_loki_lfo_sine,
        make_skadi_chorus, make_forseti_lowpass,
        make_iduna_reverb, make_heimdall_master_out,
    )
    p = Patch(name="Mir")
    osc = make_bragi_triangle_osc(); osc.position = (60, 200)
    _set(osc, freq=261.63, gain=0.4)  # C4
    lp = make_forseti_lowpass(); lp.position = (260, 200)
    _set(lp, cutoff=2200.0, resonance=0.4)
    chorus = make_skadi_chorus(); chorus.position = (460, 200)
    _set(chorus, rate=0.35, depth=0.7, mix=0.55)
    lfo = make_loki_lfo_sine(); lfo.position = (260, 60)
    _set(lfo, rate=0.09, depth=0.25)  # langsame chorus-rate-mod
    rev = make_iduna_reverb(); rev.position = (660, 200)
    _set(rev, room_size=0.88, damping=0.4, mix=0.55)
    out = make_heimdall_master_out(); out.position = (860, 200)
    for m in (osc, lp, chorus, lfo, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", lp.id, "audio_in")
    _connect(p, lp.id, "audio_out", chorus.id, "audio_in")
    _connect(p, chorus.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    # LFO → chorus.rate — atmende Bewegung (v.253 CV-Sweep)
    _connect(p, lfo.id, "cv_out", chorus.id, "rate")
    return p


def _build_salyut():
    """Salyut — Saw + LFO→Cutoff + Delay (sequencer arp).

    Charakter: Salyut 1 (1971) — die erste Raumstation überhaupt.
    Klassischer rhythmischer Sequencer-Lead mit Saw, der Filter wird per
    LFO im Tempo geöffnet/geschlossen — typisch für sowjetische
    Sequenzer-Tracks der 70er.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_saw_osc, make_loki_lfo_triangle,
        make_forseti_lowpass, make_iduna_delay,
        make_iduna_reverb, make_heimdall_master_out,
    )
    p = Patch(name="Salyut")
    osc = make_bragi_saw_osc(); osc.position = (60, 200)
    _set(osc, freq=329.63, gain=0.4)  # E4
    lp = make_forseti_lowpass(); lp.position = (260, 200)
    _set(lp, cutoff=1500.0, resonance=4.5)  # resonant
    lfo = make_loki_lfo_triangle(); lfo.position = (60, 60)
    _set(lfo, rate=2.0, depth=900.0)  # 2Hz cutoff-sweep
    delay = make_iduna_delay(); delay.position = (460, 200)
    _set(delay, time=0.375, feedback=0.5, mix=0.42, tone=4500.0)  # 8th-note
    rev = make_iduna_reverb(); rev.position = (660, 200)
    _set(rev, room_size=0.65, damping=0.4, mix=0.32)
    out = make_heimdall_master_out(); out.position = (860, 200)
    for m in (osc, lp, lfo, delay, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", lp.id, "audio_in")
    _connect(p, lp.id, "audio_out", delay.id, "audio_in")
    _connect(p, delay.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    # LFO → cutoff (rhythmische Filter-Modulation)
    _connect(p, lfo.id, "cv_out", lp.id, "cutoff")
    return p


def _build_aelita():
    """AELITA — Swarm + Tube + EQ4 (sowjetischer Brass).

    Charakter: AELITA war ein sowjetischer Brass/String-Synth — robuster
    polyfoner Klang. SwarmOsc liefert die typische 7-stimmige Brass-
    Schwebung, Tube-Drive wärmt, EQ4 hebt Mitten für den Brass-Stempel.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_swarm_osc, make_thor_tube_drive,
        make_forseti_eq4, make_skadi_chorus,
        make_iduna_reverb, make_heimdall_master_out,
    )
    p = Patch(name="AELITA")
    osc = make_bragi_swarm_osc(); osc.position = (60, 200)
    _set(osc, freq=261.63, gain=0.4,  # C4
         detune=22.0, mix=0.65)  # breit
    drive = make_thor_tube_drive(); drive.position = (260, 200)
    _set(drive, drive=12.0, tone=0.5, mix=0.65)
    eq = make_forseti_eq4(); eq.position = (460, 200)
    _set(eq, low_gain=-1.0, lo_mid_gain=4.0,
         hi_mid_gain=2.5, high_gain=-2.0)  # mid-heavy Brass
    chorus = make_skadi_chorus(); chorus.position = (660, 200)
    _set(chorus, rate=0.45, depth=0.4, mix=0.4)
    rev = make_iduna_reverb(); rev.position = (860, 200)
    _set(rev, room_size=0.6, damping=0.4, mix=0.3)
    out = make_heimdall_master_out(); out.position = (1060, 200)
    for m in (osc, drive, eq, chorus, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", drive.id, "audio_in")
    _connect(p, drive.id, "audio_out", eq.id, "audio_in")
    _connect(p, eq.id, "audio_out", chorus.id, "audio_in")
    _connect(p, chorus.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_formanta():
    """Formanta — FM + Phaser + Reverb (PM-Glocke, Mirage-Hommage).

    Charakter: Formanta Mirage (Sowjetunion, 80er) — eine der wenigen
    sowjetischen PM/FM-Synthese-Maschinen. Glockig, hell, mit komplexer
    Modulation. FM-Osc mit hohem mod_index liefert den Glocken-Charakter,
    Phaser für die analoge Bewegung.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_fm_osc, make_skadi_phaser,
        make_iduna_reverb, make_loki_lfo_sine,
        make_heimdall_master_out,
    )
    p = Patch(name="Formanta")
    fm = make_bragi_fm_osc(); fm.position = (60, 200)
    _set(fm, freq=523.25, gain=0.4,  # C5
         mod_ratio=3.5, mod_index=5.0, feedback=0.15)
    lfo = make_loki_lfo_sine(); lfo.position = (60, 60)
    _set(lfo, rate=0.6, depth=2.0)  # subtile mod_index-Bewegung
    phaser = make_skadi_phaser(); phaser.position = (260, 200)
    _set(phaser, rate=0.4, depth=0.55, feedback=0.5, mix=0.4)
    rev = make_iduna_reverb(); rev.position = (460, 200)
    _set(rev, room_size=0.78, damping=0.35, mix=0.45)
    out = make_heimdall_master_out(); out.position = (660, 200)
    for m in (fm, lfo, phaser, rev, out):
        p.add_module(m)
    _connect(p, fm.id, "audio_out", phaser.id, "audio_in")
    _connect(p, phaser.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    # LFO → mod_index (lebendige Glocken-Bewegung) — v.252.B FMOsc-CV
    _connect(p, lfo.id, "cv_out", fm.id, "mod_index")
    return p


def _build_lunokhod():
    """Lunokhod — Bite + Decimator + Compressor (Mond-Rover Concrete-Bass).

    Charakter: Lunokhod 1 (1970) — der erste ferngesteuerte Mond-Rover.
    Roboter-mechanischer Klang: BiteOsc liefert die harte „bissige"
    Wellenform mit asymmetrischem Bias, Decimator für die mechanische
    Step-Quantisierung, Compressor presst das in eine kompakte
    Concrete-Form.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_bite_osc, make_fenrir_decimator,
        make_forseti_bandpass, make_vidar_compressor,
        make_iduna_reverb, make_heimdall_master_out,
    )
    p = Patch(name="Lunokhod")
    osc = make_bragi_bite_osc(); osc.position = (60, 200)
    _set(osc, freq=82.41, gain=0.5,  # E2
         bite=0.7, bias=0.2)  # hart asymmetrisch
    bp = make_forseti_bandpass(); bp.position = (260, 200)
    _set(bp, cutoff=600.0, resonance=3.5)
    dec = make_fenrir_decimator(); dec.position = (460, 200)
    _set(dec, target_sr=8000.0, mix=0.5)  # mechanisch step-quantisiert
    comp = make_vidar_compressor(); comp.position = (660, 200)
    _set(comp, threshold=-10.0, ratio=8.0,
         attack_ms=1.0, release_ms=40.0, makeup=5.0)  # Concrete
    rev = make_iduna_reverb(); rev.position = (860, 200)
    _set(rev, room_size=0.5, damping=0.7, mix=0.18)  # trockenes Mondvakuum
    out = make_heimdall_master_out(); out.position = (1060, 200)
    for m in (osc, bp, dec, comp, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", bp.id, "audio_in")
    _connect(p, bp.id, "audio_out", dec.id, "audio_in")
    _connect(p, dec.id, "audio_out", comp.id, "audio_in")
    _connect(p, comp.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    return p


# ─── Preset-Liste ─────────────────────────────────────────────────


def _build_all() -> list[dict]:
    """Baut alle 12 Soviet-v1-Patches.  Wird **lazy** beim ersten
    Vault-Import aufgerufen."""
    builders = [
        ("Polivoks", "Saw + Bandpass-Resonance + Tube (THE classic Soviet lead).",
         ["lead", "soviet", "polivoks", "dirty"], "A3", _build_polivoks),
        ("ANS",      "Noise + Phaser + huge Reverb (photoelektrischer Tarkovsky-Drone).",
         ["pad", "drone", "tarkovsky", "ans"], "A2", _build_ans),
        ("Stalker",  "Triangle + LFO-Drift + Decimator + huge Reverb (Zone-Ambient).",
         ["pad", "ambient", "tarkovsky", "dark"], "G2", _build_stalker),
        ("Solyaris", "Formant + LFO-Vibrato + huge Reverb (kosmischer Bewusstseins-Pad).",
         ["pad", "cosmic", "formant", "tarkovsky"], "F3", _build_solyaris),
        ("Sputnik",  "Square + BitCrush + Slap-Delay (1957 Retro-Beep).",
         ["lead", "8bit", "retro", "satellite"], "C5", _build_sputnik),
        ("Soyuz",    "Sub + Drift + LFO-Sweep + Decimator (Raumfahrt-Sub-Bass).",
         ["bass", "sub", "space", "sweep"], "A1", _build_soyuz),
        ("Vostok",   "FM + Sub-Layer + Tube (Gagarin-Bass, 1961).",
         ["bass", "fm", "space", "warm"], "F2", _build_vostok),
        ("Mir",      "Triangle + Chorus + huge Reverb (orbital station pad).",
         ["pad", "soft", "orbital", "chorus"], "C4", _build_mir),
        ("Salyut",   "Saw + LFO→Cutoff + Delay (sequencer arp, erste Raumstation 1971).",
         ["lead", "sequencer", "arp", "lfo"], "E4", _build_salyut),
        ("AELITA",   "Swarm + Tube + EQ4 (sowjetischer Messing-Brass).",
         ["lead", "brass", "swarm", "soviet"], "C4", _build_aelita),
        ("Formanta", "FM + Phaser + Reverb (PM-Glocke, Mirage-Hommage).",
         ["lead", "bell", "fm", "soviet"], "C5", _build_formanta),
        ("Lunokhod", "Bite + Decimator + Compressor (Mond-Rover Concrete-Bass).",
         ["bass", "concrete", "mechanical", "rover"], "E2", _build_lunokhod),
    ]

    presets = []
    for name, desc, tags, key, builder in builders:
        patch_dict = _build_patch_dict(name, builder)
        if patch_dict is None:
            logger.warning("[SovietPresets-v1] %s skipped (build failed)", name)
            continue
        presets.append({
            "name": name,
            "description": desc,
            "tags": tags,
            "musical_key": key,
            "bpm": None,
            "author": SOVIET_FACTORY_AUTHOR,
            "icon_svg": "",
            "patch": patch_dict,
        })
    return presets


class _LazyPresetList:
    """Wrapper: baut die Patches erst beim ersten Iterieren."""

    def __init__(self):
        self._cache: Optional[list[dict]] = None

    def _ensure(self) -> list[dict]:
        if self._cache is None:
            self._cache = _build_all()
            logger.info(
                "[SovietPresets-v1] built %d Soviet presets (%s) lazily",
                len(self._cache), SOVIET_FACTORY_VERSION,
            )
        return self._cache

    def __iter__(self):
        return iter(self._ensure())

    def __len__(self):
        return len(self._ensure())

    def __getitem__(self, i):
        return self._ensure()[i]


SOVIET_PRESETS = _LazyPresetList()


__all__ = [
    "SOVIET_PRESETS",
    "SOVIET_FACTORY_VERSION",
    "SOVIET_FACTORY_AUTHOR",
]
