"""CV/Gate Service (P4B) — MIDI-to-CV conversion for modular synthesizers.

Converts MIDI notes to CV (1V/Octave) and Gate signals.
Output via audio channels (DC-coupled audio interface required).

Features:
- 1V/Octave pitch CV generation
- Gate signal (0V/5V emulation via audio output)
- Velocity CV output
- Mod Wheel / CC to CV conversion
- Multiple CV/Gate pairs for polyphonic patching
- Calibration table support

v0.0.20.810 — Phase P4B
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Tuple, Any

from PyQt6.QtCore import QObject, pyqtSignal

log = logging.getLogger(__name__)

try:
    import numpy as np
    _HAS_NUMPY = True
except ImportError:
    np = None  # type: ignore
    _HAS_NUMPY = False


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class CvGateConfig:
    """Configuration for a CV/Gate output pair."""
    pitch_channel: int = 0       # Audio output channel for pitch CV
    gate_channel: int = 1        # Audio output channel for gate
    velocity_channel: int = -1   # Audio channel for velocity CV (-1 = disabled)
    mod_channel: int = -1        # Audio channel for modwheel CV (-1 = disabled)

    octave_voltage: float = 1.0  # Volts per octave (standard = 1.0V/Oct)
    gate_high: float = 1.0       # Gate high level (normalized, 1.0 = full scale)
    gate_low: float = 0.0        # Gate low level
    pitch_offset: float = 0.0    # CV offset in volts (for calibration)
    reference_note: int = 60     # MIDI note that equals 0V (Middle C)

    retrigger_ms: float = 2.0    # Gate retrigger gap in ms
    portamento_ms: float = 0.0   # Pitch glide time (0 = off)

    enabled: bool = True

    def to_dict(self) -> dict:
        return {
            "pitch_channel": self.pitch_channel,
            "gate_channel": self.gate_channel,
            "velocity_channel": self.velocity_channel,
            "mod_channel": self.mod_channel,
            "octave_voltage": self.octave_voltage,
            "gate_high": self.gate_high,
            "reference_note": self.reference_note,
            "retrigger_ms": self.retrigger_ms,
            "portamento_ms": self.portamento_ms,
            "enabled": self.enabled,
        }


@dataclass
class CvCalibration:
    """Calibration table for non-linear CV response correction."""
    points: List[Tuple[int, float]] = field(default_factory=list)
    # List of (midi_note, actual_voltage) measured pairs

    def voltage_for_note(self, note: int, default_v_per_oct: float = 1.0 / 12.0) -> float:
        """Lookup calibrated voltage for a MIDI note."""
        if not self.points:
            return note * default_v_per_oct

        # Linear interpolation between calibration points
        if note <= self.points[0][0]:
            return self.points[0][1]
        if note >= self.points[-1][0]:
            return self.points[-1][1]

        for i in range(len(self.points) - 1):
            n0, v0 = self.points[i]
            n1, v1 = self.points[i + 1]
            if n0 <= note <= n1:
                t = (note - n0) / max(1, n1 - n0)
                return v0 + t * (v1 - v0)
        return note * default_v_per_oct


# ---------------------------------------------------------------------------
# CV/Gate Generator
# ---------------------------------------------------------------------------

class CvGateService(QObject):
    """Generates CV/Gate audio signals from MIDI input.

    Usage:
        1. Configure output channels via CvGateConfig
        2. Call note_on/note_off/cc from MidiManager
        3. Call render_buffer() in audio callback to get CV/Gate samples
    """

    status = pyqtSignal(str)

    def __init__(
        self,
        config: Optional[CvGateConfig] = None,
        sample_rate: float = 44100.0,
        parent: Optional[QObject] = None,
    ):
        super().__init__(parent)
        self._config = config or CvGateConfig()
        self._sample_rate = sample_rate
        self._calibration = CvCalibration()

        # Current state
        self._active_note: int = -1
        self._gate_on: bool = False
        self._velocity: float = 0.0
        self._mod_wheel: float = 0.0
        self._pitch_bend: float = 0.0  # -1..1 (normalized)
        self._pitch_bend_range: int = 2  # semitones

        # Portamento state
        self._target_cv: float = 0.0
        self._current_cv: float = 0.0

        # Retrigger state
        self._retrigger_samples_remaining: int = 0

    @property
    def config(self) -> CvGateConfig:
        return self._config

    def set_config(self, config: CvGateConfig) -> None:
        self._config = config

    def set_sample_rate(self, sr: float) -> None:
        self._sample_rate = sr

    def set_calibration(self, cal: CvCalibration) -> None:
        self._calibration = cal

    # ── MIDI input ────────────────────────────────────────────────────────

    def note_on(self, note: int, velocity: int) -> None:
        """Process MIDI note on."""
        if not self._config.enabled:
            return

        cfg = self._config

        # Retrigger: brief gate off before new note
        if self._gate_on and cfg.retrigger_ms > 0:
            self._retrigger_samples_remaining = int(
                cfg.retrigger_ms * self._sample_rate / 1000.0
            )

        self._active_note = note
        self._velocity = velocity / 127.0
        self._gate_on = True

        # Calculate target CV voltage
        note_offset = note - cfg.reference_note
        self._target_cv = (note_offset / 12.0) * cfg.octave_voltage + cfg.pitch_offset

        # Apply calibration if available
        if self._calibration.points:
            self._target_cv = self._calibration.voltage_for_note(note)

        # Instant or portamento
        if cfg.portamento_ms <= 0:
            self._current_cv = self._target_cv

    def note_off(self, note: int) -> None:
        """Process MIDI note off."""
        if note == self._active_note:
            self._gate_on = False
            self._active_note = -1

    def cc(self, controller: int, value: int) -> None:
        """Process MIDI CC."""
        if controller == 1:  # Mod wheel
            self._mod_wheel = value / 127.0
        elif controller == 64:  # Sustain pedal → hold gate
            if value >= 64 and self._active_note >= 0:
                self._gate_on = True

    def pitch_bend(self, value: int) -> None:
        """Process pitch bend (0-16383, center=8192)."""
        self._pitch_bend = (value - 8192) / 8192.0

    def all_notes_off(self) -> None:
        """Panic — reset all CV/Gate."""
        self._gate_on = False
        self._active_note = -1
        self._velocity = 0.0
        self._current_cv = 0.0
        self._target_cv = 0.0
        self._retrigger_samples_remaining = 0

    # ── Audio rendering ──────────────────────────────────────────────────

    def render_buffer(self, num_frames: int) -> Dict[int, Any]:
        """Render CV/Gate audio buffers.

        Args:
            num_frames: number of audio frames to render

        Returns:
            Dict mapping audio channel index → numpy array (float32).
        """
        if not _HAS_NUMPY:
            return {}

        cfg = self._config
        if not cfg.enabled:
            return {}

        result: Dict[int, Any] = {}

        # ── Pitch CV ─────────────────────────────────────────────────
        pitch_buf = np.zeros(num_frames, dtype=np.float32)
        if cfg.portamento_ms > 0 and self._current_cv != self._target_cv:
            # Exponential glide
            coeff = 1.0 - math.exp(-1.0 / (cfg.portamento_ms * self._sample_rate / 1000.0))
            for i in range(num_frames):
                self._current_cv += (self._target_cv - self._current_cv) * coeff
                pitch_buf[i] = self._current_cv
        else:
            pitch_buf[:] = self._current_cv

        # Add pitch bend
        if abs(self._pitch_bend) > 0.001:
            bend_v = (self._pitch_bend * self._pitch_bend_range / 12.0) * cfg.octave_voltage
            pitch_buf += bend_v

        # Normalize to audio range (-1..1) — assuming ±5V = full scale
        pitch_buf = pitch_buf / 5.0
        pitch_buf = np.clip(pitch_buf, -1.0, 1.0)
        result[cfg.pitch_channel] = pitch_buf

        # ── Gate ─────────────────────────────────────────────────────
        gate_buf = np.zeros(num_frames, dtype=np.float32)
        for i in range(num_frames):
            if self._retrigger_samples_remaining > 0:
                self._retrigger_samples_remaining -= 1
                gate_buf[i] = cfg.gate_low
            elif self._gate_on:
                gate_buf[i] = cfg.gate_high
            else:
                gate_buf[i] = cfg.gate_low
        result[cfg.gate_channel] = gate_buf

        # ── Velocity CV ──────────────────────────────────────────────
        if cfg.velocity_channel >= 0:
            vel_buf = np.full(num_frames, self._velocity, dtype=np.float32)
            result[cfg.velocity_channel] = vel_buf

        # ── Mod Wheel CV ─────────────────────────────────────────────
        if cfg.mod_channel >= 0:
            mod_buf = np.full(num_frames, self._mod_wheel, dtype=np.float32)
            result[cfg.mod_channel] = mod_buf

        return result

    def shutdown(self) -> None:
        self.all_notes_off()
