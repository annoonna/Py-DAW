# -*- coding: utf-8 -*-
"""Scripting Console Proxies for Instruments and Audio-FX.

v0.0.21.011 SC1+SC2+SC3: Full proxy framework for Python Console access
to all instruments, audio-FX, and note-FX.

Design goals:
- Read-through / write-through: no caching, always reads from engine
- Thread-safe: writes via QTimer.singleShot where needed
- Non-destructive: proxies only WRAP existing APIs, never modify them
- Discovery: help() and __repr__ on every proxy
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

log = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# SC1: Base Infrastructure
# ═══════════════════════════════════════════════════════════════

class _InstrumentProxyBase:
    """Base class for all instrument proxies."""

    _PROXY_TYPE = "instrument"
    _INSTRUMENT_NAME = "Unknown"

    def __init__(self, widget: Any, track_id: str, track_name: str, project_service: Any):
        object.__setattr__(self, '_widget', widget)
        object.__setattr__(self, '_track_id', str(track_id or ''))
        object.__setattr__(self, '_track_name', str(track_name or ''))
        object.__setattr__(self, '_ps', project_service)

    def _get_engine(self) -> Any:
        w = object.__getattribute__(self, '_widget')
        return getattr(w, 'engine', None)

    def _emit_changed(self) -> None:
        try:
            ps = object.__getattribute__(self, '_ps')
            if ps is not None:
                ps.project_changed.emit()
        except Exception:
            pass

    def _persist(self) -> None:
        """Trigger instrument state persistence (safe)."""
        try:
            w = object.__getattribute__(self, '_widget')
            fn = getattr(w, '_persist_instrument_state', None)
            if callable(fn):
                fn()
        except Exception:
            pass

    def trigger(self, pitch: int = 60, velocity: int = 100) -> str:
        """Trigger a note on the instrument."""
        try:
            eng = self._get_engine()
            if eng is None:
                return "No engine"
            ok = eng.trigger_note(int(pitch), int(velocity))
            return f"Note {pitch} vel={velocity} → {'OK' if ok else 'no sample'}"
        except Exception as e:
            return f"Error: {e}"

    def export_state(self) -> dict:
        """Export current instrument state as dict."""
        try:
            eng = self._get_engine()
            if eng and hasattr(eng, 'export_state'):
                return eng.export_state()
        except Exception:
            pass
        return {}

    def import_state(self, state: dict) -> str:
        """Import instrument state from dict."""
        try:
            eng = self._get_engine()
            if eng and hasattr(eng, 'import_state'):
                eng.import_state(state)
                self._persist()
                return "OK"
        except Exception as e:
            return f"Error: {e}"
        return "No engine"

    def help(self) -> str:
        """Show available methods and properties."""
        lines = [f"🎹 {self._INSTRUMENT_NAME} on '{object.__getattribute__(self, '_track_name')}'", ""]
        for name in sorted(dir(self)):
            if name.startswith('_'):
                continue
            attr = getattr(type(self), name, None)
            if attr is None:
                continue
            if isinstance(attr, property):
                lines.append(f"  .{name}  (property)")
            elif callable(attr):
                doc = getattr(attr, '__doc__', '') or ''
                short = doc.split('\n')[0].strip() if doc else ''
                lines.append(f"  .{name}()  — {short}")
        return '\n'.join(lines)

    def __repr__(self) -> str:
        tn = object.__getattribute__(self, '_track_name')
        return f"<{self._INSTRUMENT_NAME} on '{tn}'>"


# ═══════════════════════════════════════════════════════════════
# SC2.1: Pro Drum Machine Proxy
# ═══════════════════════════════════════════════════════════════

class _DrumSlotProxy:
    """Proxy for a single drum pad/slot."""

    def __init__(self, slot: Any, engine: Any, parent: Any):
        object.__setattr__(self, '_slot', slot)
        object.__setattr__(self, '_engine', engine)
        object.__setattr__(self, '_parent', parent)

    def _persist(self):
        try:
            object.__getattribute__(self, '_parent')._persist()
        except Exception:
            pass

    # ── Sample ──
    def load(self, path: str) -> str:
        """Load a sample file (WAV/FLAC/OGG/MP3/AIFF)."""
        slot = object.__getattribute__(self, '_slot')
        ok = slot.load_sample(str(path))
        self._persist()
        return f"Loaded: {path}" if ok else f"Failed to load: {path}"

    def clear(self) -> str:
        """Remove sample from this slot."""
        slot = object.__getattribute__(self, '_slot')
        slot.clear_sample()
        self._persist()
        return "Cleared"

    @property
    def sample(self) -> str:
        slot = object.__getattribute__(self, '_slot')
        return str(getattr(slot.state, 'sample_path', '') or '')

    @property
    def has_sample(self) -> bool:
        slot = object.__getattribute__(self, '_slot')
        return bool(slot.has_sample())

    # ── Name ──
    @property
    def name(self) -> str:
        slot = object.__getattribute__(self, '_slot')
        return str(getattr(slot.state, 'name', ''))

    @name.setter
    def name(self, v: str):
        slot = object.__getattribute__(self, '_slot')
        slot.state.name = str(v)
        self._persist()

    # ── Gain (0..100 UI space → 0..1 engine) ──
    @property
    def gain(self) -> float:
        slot = object.__getattribute__(self, '_slot')
        return float(getattr(slot.engine.state, 'gain', 0.8)) * 100.0

    @gain.setter
    def gain(self, v: float):
        slot = object.__getattribute__(self, '_slot')
        slot.engine.set_master(gain=float(max(0, min(100, v))) / 100.0)
        self._persist()

    # ── Pan (-1..+1) ──
    @property
    def pan(self) -> float:
        slot = object.__getattribute__(self, '_slot')
        return float(getattr(slot.engine.state, 'pan', 0.0))

    @pan.setter
    def pan(self, v: float):
        slot = object.__getattribute__(self, '_slot')
        slot.engine.set_master(pan=float(max(-1, min(1, v))))
        self._persist()

    # ── Tune (semitones) ──
    @property
    def tune(self) -> int:
        slot = object.__getattribute__(self, '_slot')
        return int(getattr(slot.state, 'tune_semitones', 0) or 0)

    @tune.setter
    def tune(self, v: int):
        slot = object.__getattribute__(self, '_slot')
        slot.state.tune_semitones = int(max(-48, min(48, v)))
        self._persist()

    # ── Filter ──
    @property
    def filter(self) -> str:
        slot = object.__getattribute__(self, '_slot')
        return str(getattr(slot.engine.state, 'filter_type', 'off') or 'off')

    @filter.setter
    def filter(self, v: str):
        slot = object.__getattribute__(self, '_slot')
        slot.engine.set_filter(ftype=str(v))
        self._persist()

    @property
    def cutoff(self) -> float:
        slot = object.__getattribute__(self, '_slot')
        return float(getattr(slot.engine.state, 'cutoff_hz', 8000.0))

    @cutoff.setter
    def cutoff(self, v: float):
        slot = object.__getattribute__(self, '_slot')
        slot.engine.set_filter(cutoff_hz=float(max(20, min(20000, v))))
        self._persist()

    @property
    def resonance(self) -> float:
        slot = object.__getattribute__(self, '_slot')
        return float(getattr(slot.engine.state, 'q', 0.707))

    @resonance.setter
    def resonance(self, v: float):
        slot = object.__getattribute__(self, '_slot')
        slot.engine.set_filter(q=float(max(0.25, min(12.0, v))))
        self._persist()

    # ── Region ──
    @property
    def start(self) -> float:
        slot = object.__getattribute__(self, '_slot')
        return float(getattr(slot.engine.state, 'start_position', 0.0))

    @start.setter
    def start(self, v: float):
        slot = object.__getattribute__(self, '_slot')
        try:
            slot.engine.set_region_norm(start=float(max(0, min(1, v))), end=None)
        except Exception:
            slot.engine.state.start_position = float(max(0, min(1, v)))
        self._persist()

    @property
    def end(self) -> float:
        slot = object.__getattribute__(self, '_slot')
        return float(getattr(slot.engine.state, 'end_position', 1.0))

    @end.setter
    def end(self, v: float):
        slot = object.__getattribute__(self, '_slot')
        try:
            slot.engine.set_region_norm(start=None, end=float(max(0, min(1, v))))
        except Exception:
            slot.engine.state.end_position = float(max(0, min(1, v)))
        self._persist()

    # ── Choke Group ──
    @property
    def choke(self) -> int:
        slot = object.__getattribute__(self, '_slot')
        return int(getattr(slot.state, 'choke_group', 0) or 0)

    @choke.setter
    def choke(self, v: int):
        slot = object.__getattribute__(self, '_slot')
        slot.state.choke_group = int(max(0, min(8, v)))
        self._persist()

    # ── MIDI Channel ──
    @property
    def channel(self) -> int:
        slot = object.__getattribute__(self, '_slot')
        return int(getattr(slot.state, 'midi_channel', -1))

    @channel.setter
    def channel(self, v: int):
        slot = object.__getattribute__(self, '_slot')
        slot.state.midi_channel = int(max(-1, min(15, v)))
        self._persist()

    # ── ADSR ──
    def env(self, a: float = None, d: float = None, s: float = None, r: float = None) -> str:
        """Set ADSR envelope. Only provided values are changed."""
        slot = object.__getattribute__(self, '_slot')
        slot.engine.set_env(a=a, d=d, s=s, r=r)
        self._persist()
        return "Envelope updated"

    # ── FX ──
    def fx(self, chorus: float = None, delay: float = None, reverb: float = None) -> str:
        """Set built-in FX mix. Only provided values are changed."""
        slot = object.__getattribute__(self, '_slot')
        slot.engine.set_fx(chorus_mix=chorus, delay_mix=delay, reverb_mix=reverb)
        self._persist()
        return "FX updated"

    def trigger(self, velocity: int = 100) -> str:
        """Trigger this pad."""
        slot = object.__getattribute__(self, '_slot')
        eng = object.__getattribute__(self, '_engine')
        idx = int(slot.state.index)
        pitch = int(eng.base_note + idx)
        ok = eng.trigger_note(pitch, int(velocity))
        return f"Slot {idx} ({slot.state.name}) vel={velocity} → {'OK' if ok else 'no sample'}"

    def __repr__(self) -> str:
        slot = object.__getattribute__(self, '_slot')
        sp = str(getattr(slot.state, 'sample_path', '') or '')
        sname = sp.split('/')[-1] if sp else '(empty)'
        return f"<DrumSlot {slot.state.index}: '{slot.state.name}' sample={sname}>"


class _DrumMachineProxy(_InstrumentProxyBase):
    """Full proxy for the Pro Drum Machine."""

    _PROXY_TYPE = "instrument"
    _INSTRUMENT_NAME = "Pro Drum Machine"

    def slot(self, index: int) -> _DrumSlotProxy:
        """Access a specific drum slot (0-based)."""
        eng = self._get_engine()
        if eng is None:
            raise RuntimeError("No drum engine")
        idx = int(index)
        if not (0 <= idx < len(eng.slots)):
            raise IndexError(f"Slot {idx} out of range (0..{len(eng.slots)-1})")
        return _DrumSlotProxy(eng.slots[idx], eng, self)

    def __getitem__(self, index: int) -> _DrumSlotProxy:
        return self.slot(index)

    @property
    def slots(self) -> list:
        """List all slots with name and sample info."""
        eng = self._get_engine()
        if eng is None:
            return []
        result = []
        for s in eng.slots:
            sp = str(getattr(s.state, 'sample_path', '') or '')
            sname = sp.split('/')[-1] if sp else ''
            result.append({
                'index': int(s.state.index),
                'name': str(s.state.name),
                'sample': sname,
                'note': int(eng.base_note + s.state.index),
                'choke': int(getattr(s.state, 'choke_group', 0) or 0),
                'channel': int(getattr(s.state, 'midi_channel', -1)),
            })
        return result

    @property
    def slot_count(self) -> int:
        eng = self._get_engine()
        return len(eng.slots) if eng else 0

    @property
    def base_note(self) -> int:
        eng = self._get_engine()
        return int(eng.base_note) if eng else 36

    @property
    def multi_output(self) -> bool:
        eng = self._get_engine()
        return bool(getattr(eng, '_multi_output_enabled', False)) if eng else False

    @multi_output.setter
    def multi_output(self, v: bool):
        eng = self._get_engine()
        if eng:
            eng.set_multi_output(bool(v))
            self._persist()


# ═══════════════════════════════════════════════════════════════
# SC2.2: Pro Sampler Proxy
# ═══════════════════════════════════════════════════════════════

class _SamplerEnvProxy:
    """ADSR envelope sub-proxy."""
    def __init__(self, engine: Any, persist_fn):
        object.__setattr__(self, '_eng', engine)
        object.__setattr__(self, '_persist', persist_fn)

    @property
    def attack(self) -> float:
        eng = object.__getattribute__(self, '_eng')
        return float(getattr(eng.state, 'a', 0.01))

    @attack.setter
    def attack(self, v: float):
        eng = object.__getattribute__(self, '_eng')
        eng.set_env(a=float(max(0.001, min(10.0, v))))
        object.__getattribute__(self, '_persist')()

    @property
    def decay(self) -> float:
        eng = object.__getattribute__(self, '_eng')
        return float(getattr(eng.state, 'd', 0.15))

    @decay.setter
    def decay(self, v: float):
        eng = object.__getattribute__(self, '_eng')
        eng.set_env(d=float(max(0.001, min(10.0, v))))
        object.__getattribute__(self, '_persist')()

    @property
    def sustain(self) -> float:
        eng = object.__getattribute__(self, '_eng')
        return float(getattr(eng.state, 's', 1.0))

    @sustain.setter
    def sustain(self, v: float):
        eng = object.__getattribute__(self, '_eng')
        eng.set_env(s=float(max(0.0, min(1.0, v))))
        object.__getattribute__(self, '_persist')()

    @property
    def release(self) -> float:
        eng = object.__getattribute__(self, '_eng')
        return float(getattr(eng.state, 'r', 0.2))

    @release.setter
    def release(self, v: float):
        eng = object.__getattribute__(self, '_eng')
        eng.set_env(r=float(max(0.001, min(30.0, v))))
        object.__getattribute__(self, '_persist')()

    def __repr__(self):
        return f"<Env A={self.attack:.3f} D={self.decay:.3f} S={self.sustain:.2f} R={self.release:.3f}>"


class _SamplerProxy(_InstrumentProxyBase):
    """Full proxy for the Pro Sampler."""

    _INSTRUMENT_NAME = "Pro Sampler"

    def _get_engine(self) -> Any:
        w = object.__getattribute__(self, '_widget')
        return getattr(w, 'engine', None)

    def load(self, path: str) -> str:
        """Load a sample file."""
        eng = self._get_engine()
        if eng is None:
            return "No engine"
        ok = eng.load_wav(str(path))
        self._persist()
        return f"Loaded: {path}" if ok else f"Failed: {path}"

    @property
    def root(self) -> int:
        eng = self._get_engine()
        return int(getattr(eng, 'root_note', 60)) if eng else 60

    @root.setter
    def root(self, v: int):
        eng = self._get_engine()
        if eng:
            eng.set_root(int(max(0, min(127, v))))
            self._persist()

    @property
    def gain(self) -> float:
        eng = self._get_engine()
        return float(getattr(eng.state, 'gain', 0.8)) if eng else 0.8

    @gain.setter
    def gain(self, v: float):
        eng = self._get_engine()
        if eng:
            eng.set_master(gain=float(max(0, min(1, v))))
            self._persist()

    @property
    def pan(self) -> float:
        eng = self._get_engine()
        return float(getattr(eng.state, 'pan', 0.0)) if eng else 0.0

    @pan.setter
    def pan(self, v: float):
        eng = self._get_engine()
        if eng:
            eng.set_master(pan=float(max(-1, min(1, v))))
            self._persist()

    @property
    def loop(self) -> bool:
        eng = self._get_engine()
        return bool(getattr(eng, '_loop_enabled', False)) if eng else False

    @loop.setter
    def loop(self, v: bool):
        eng = self._get_engine()
        if eng:
            eng.set_loop_enabled(bool(v))
            self._persist()

    @property
    def filter(self) -> str:
        eng = self._get_engine()
        return str(getattr(eng.state, 'filter_type', 'off') or 'off') if eng else 'off'

    @filter.setter
    def filter(self, v: str):
        eng = self._get_engine()
        if eng:
            eng.set_filter(ftype=str(v))
            self._persist()

    @property
    def cutoff(self) -> float:
        eng = self._get_engine()
        return float(getattr(eng.state, 'cutoff_hz', 8000.0)) if eng else 8000.0

    @cutoff.setter
    def cutoff(self, v: float):
        eng = self._get_engine()
        if eng:
            eng.set_filter(cutoff_hz=float(max(20, min(20000, v))))
            self._persist()

    @property
    def resonance(self) -> float:
        eng = self._get_engine()
        return float(getattr(eng.state, 'q', 0.707)) if eng else 0.707

    @resonance.setter
    def resonance(self, v: float):
        eng = self._get_engine()
        if eng:
            eng.set_filter(q=float(max(0.25, min(12.0, v))))
            self._persist()

    @property
    def env(self) -> _SamplerEnvProxy:
        eng = self._get_engine()
        return _SamplerEnvProxy(eng, self._persist)

    @property
    def start(self) -> float:
        eng = self._get_engine()
        return float(getattr(eng.state, 'start_position', 0.0)) if eng else 0.0

    @start.setter
    def start(self, v: float):
        eng = self._get_engine()
        if eng:
            try:
                eng.set_region_norm(start=float(max(0, min(1, v))), end=None)
            except Exception:
                eng.state.start_position = float(v)
            self._persist()

    @property
    def end(self) -> float:
        eng = self._get_engine()
        return float(getattr(eng.state, 'end_position', 1.0)) if eng else 1.0

    @end.setter
    def end(self, v: float):
        eng = self._get_engine()
        if eng:
            try:
                eng.set_region_norm(start=None, end=float(max(0, min(1, v))))
            except Exception:
                eng.state.end_position = float(v)
            self._persist()

    @property
    def distortion(self) -> float:
        eng = self._get_engine()
        return float(getattr(eng.state, 'dist_mix', 0.0)) if eng else 0.0

    @distortion.setter
    def distortion(self, v: float):
        eng = self._get_engine()
        if eng:
            eng.set_distortion(float(max(0, min(1, v))))
            self._persist()

    def set_fx(self, chorus: float = None, delay: float = None, reverb: float = None) -> str:
        """Set built-in FX mix values."""
        eng = self._get_engine()
        if eng:
            eng.set_fx(chorus_mix=chorus, delay_mix=delay, reverb_mix=reverb)
            self._persist()
            return "FX updated"
        return "No engine"


# ═══════════════════════════════════════════════════════════════
# SC2.3: AETERNA Synthesizer Proxy
# ═══════════════════════════════════════════════════════════════

class _AeternaProxy(_InstrumentProxyBase):
    """Proxy for the AETERNA Wavetable Synthesizer."""

    _INSTRUMENT_NAME = "AETERNA Synthesizer"

    @property
    def params(self) -> dict:
        """Get all parameters as dict."""
        eng = self._get_engine()
        if eng and hasattr(eng, 'export_state'):
            return eng.export_state()
        return {}

    def set(self, param: str, value: Any) -> str:
        """Set a parameter by name."""
        eng = self._get_engine()
        if eng is None:
            return "No engine"
        try:
            eng.set_param(str(param), value)
            self._persist()
            return f"{param} = {value}"
        except Exception as e:
            return f"Error: {e}"

    def get(self, param: str) -> Any:
        """Get a parameter by name."""
        state = self.params
        return state.get(str(param))

    @property
    def preset(self) -> str:
        eng = self._get_engine()
        return str(getattr(eng, '_preset_name', '')) if eng else ''

    @preset.setter
    def preset(self, v: str):
        eng = self._get_engine()
        if eng and hasattr(eng, 'set_preset_name'):
            eng.set_preset_name(str(v))
            self._persist()

    def wavetable(self, path: str) -> str:
        """Load a wavetable file."""
        eng = self._get_engine()
        if eng is None:
            return "No engine"
        try:
            eng.load_wavetable_file(str(path))
            self._persist()
            return f"Wavetable loaded: {path}"
        except Exception as e:
            return f"Error: {e}"

    def wavetable_builtin(self, name: str) -> str:
        """Load a built-in wavetable (Saw, Square, Sine, etc.)."""
        eng = self._get_engine()
        if eng is None:
            return "No engine"
        try:
            eng.load_wavetable_builtin(str(name))
            self._persist()
            return f"Built-in wavetable: {name}"
        except Exception as e:
            return f"Error: {e}"


# ═══════════════════════════════════════════════════════════════
# SC2.4: Fusion Synth Proxy
# ═══════════════════════════════════════════════════════════════

class _FusionProxy(_InstrumentProxyBase):
    """Proxy for the Fusion Subtractive Synthesizer."""

    _INSTRUMENT_NAME = "Fusion Synth"

    @property
    def params(self) -> dict:
        eng = self._get_engine()
        if eng and hasattr(eng, 'export_state'):
            return eng.export_state()
        return {}

    def set(self, param: str, value: Any) -> str:
        """Set a parameter by name."""
        eng = self._get_engine()
        if eng is None:
            return "No engine"
        try:
            if hasattr(eng, 'set_param'):
                eng.set_param(str(param), value)
            else:
                setattr(eng, str(param), value)
            self._persist()
            return f"{param} = {value}"
        except Exception as e:
            return f"Error: {e}"

    def get(self, param: str) -> Any:
        state = self.params
        return state.get(str(param))


# ═══════════════════════════════════════════════════════════════
# SC2.5: BRRR Flutter Synth Proxy
# ═══════════════════════════════════════════════════════════════

class _BRRRProxy(_InstrumentProxyBase):
    """Proxy for the BRRR Flutter/PADsynth Synthesizer."""

    _INSTRUMENT_NAME = "BRRR Flutter Synth"

    @property
    def params(self) -> dict:
        eng = self._get_engine()
        if eng and hasattr(eng, 'export_state'):
            return eng.export_state()
        return {}


# ═══════════════════════════════════════════════════════════════
# SC2.6: Bach Orgel Proxy
# ═══════════════════════════════════════════════════════════════

class _BachOrgelProxy(_InstrumentProxyBase):
    """Proxy for the Bach Drawbar Organ."""

    _INSTRUMENT_NAME = "Bach Orgel"

    @property
    def params(self) -> dict:
        eng = self._get_engine()
        if eng and hasattr(eng, 'export_state'):
            return eng.export_state()
        return {}

    def set(self, param: str, value: Any) -> str:
        """Set a parameter (e.g. drawbar_16, vibrato)."""
        eng = self._get_engine()
        if eng is None:
            return "No engine"
        try:
            eng.set_param(str(param), value)
            self._persist()
            return f"{param} = {value}"
        except Exception as e:
            return f"Error: {e}"

    def get(self, param: str) -> Any:
        state = self.params
        return state.get(str(param))


# ═══════════════════════════════════════════════════════════════
# SC2.7: Advanced Sampler (Multisample) Proxy
# ═══════════════════════════════════════════════════════════════

class _AdvancedSamplerProxy(_InstrumentProxyBase):
    """Proxy for the Advanced Sampler (zone-based multisampler)."""

    _INSTRUMENT_NAME = "Advanced Sampler"

    def _get_engine(self) -> Any:
        w = object.__getattribute__(self, '_widget')
        # Advanced Sampler uses _engine (lazy-loaded), not engine
        eng = getattr(w, 'engine', None) or getattr(w, '_engine', None)
        if eng is None:
            # Try lazy-load via _ensure_engine()
            try:
                fn = getattr(w, '_ensure_engine', None)
                if callable(fn):
                    eng = fn()
            except Exception:
                pass
        return eng

    @property
    def zones(self) -> list:
        """List all zones with key range and sample info."""
        eng = self._get_engine()
        if eng is None:
            return []
        try:
            sample_map = getattr(eng, '_map', None) or getattr(eng, 'sample_map', None)
            if sample_map is None:
                return []
            result = []
            for z in getattr(sample_map, 'zones', []):
                result.append({
                    'lo': int(getattr(z, 'lo_note', 0)),
                    'hi': int(getattr(z, 'hi_note', 127)),
                    'root': int(getattr(z, 'root_note', 60)),
                    'sample': str(getattr(z, 'sample_path', '')),
                    'gain': float(getattr(z, 'gain', 1.0)),
                })
            return result
        except Exception:
            return []

    @property
    def zone_count(self) -> int:
        return len(self.zones)

    @property
    def params(self) -> dict:
        eng = self._get_engine()
        if eng and hasattr(eng, 'export_state'):
            return eng.export_state()
        return {}


# ═══════════════════════════════════════════════════════════════
# SC2.8: SF2 Soundfont Proxy
# ═══════════════════════════════════════════════════════════════

class _SF2Proxy(_InstrumentProxyBase):
    """Proxy for the SF2 Soundfont Player (FluidSynth-based)."""

    _INSTRUMENT_NAME = "SF2 Soundfont"

    def program(self, bank: int = 0, preset: int = 0) -> str:
        """Set bank and preset number."""
        eng = self._get_engine()
        if eng is None:
            return "No engine"
        try:
            eng.set_program(int(bank), int(preset))
            self._persist()
            return f"Program: Bank {bank}, Preset {preset}"
        except Exception as e:
            return f"Error: {e}"

    @property
    def params(self) -> dict:
        eng = self._get_engine()
        if eng and hasattr(eng, 'export_state'):
            return eng.export_state()
        return {}


# ═══════════════════════════════════════════════════════════════
# SC1.4: Instruments Dict (top-level global)
# ═══════════════════════════════════════════════════════════════

# Plugin ID → Proxy class mapping
# NOTE: IDs must match pydaw/plugins/registry.py (NOT fx_specs.py!)
_PROXY_MAP = {
    'chrono.pro_drum_machine': _DrumMachineProxy,
    'chrono.pro_audio_sampler': _SamplerProxy,
    'chrono.aeterna': _AeternaProxy,
    'chrono.fusion': _FusionProxy,
    'chrono.brrr': _BRRRProxy,
    'chrono.bach_orgel': _BachOrgelProxy,
    'chrono.advanced_sampler': _AdvancedSamplerProxy,
    'chrono.sf2': _SF2Proxy,
    # Aliases from fx_specs.py (browser uses these)
    'chrono.drum_machine': _DrumMachineProxy,
    'chrono.sampler': _SamplerProxy,
}


class _InstrumentsProxy:
    """Dict-like proxy: instruments["Track Name"] → typed InstrumentProxy.

    Dynamically reads from DevicePanel._track_instruments so it always
    reflects the current state (no stale references).
    """

    def __init__(self, device_panel: Any, project_service: Any):
        object.__setattr__(self, '_dp', device_panel)
        object.__setattr__(self, '_ps', project_service)

    def _resolve(self, key: str) -> Optional[_InstrumentProxyBase]:
        dp = object.__getattribute__(self, '_dp')
        ps = object.__getattribute__(self, '_ps')
        if dp is None or ps is None:
            return None

        # Find track by name
        try:
            tracks = ps.ctx.project.tracks
        except Exception:
            return None

        track_id = None
        track_name = str(key)
        for t in tracks:
            if getattr(t, 'name', '') == str(key):
                track_id = str(getattr(t, 'id', ''))
                break

        if not track_id:
            return None

        # Get instrument widget from DevicePanel
        try:
            inst_info = dp._track_instruments.get(track_id)
            if inst_info is None:
                return None
            widget = inst_info.get('widget')
            plugin_id = str(inst_info.get('plugin_id', ''))
            if widget is None:
                return None

            # Find the right proxy class
            proxy_cls = _PROXY_MAP.get(plugin_id)
            if proxy_cls is None:
                # Fallback: generic proxy
                return _InstrumentProxyBase(widget, track_id, track_name, ps)
            return proxy_cls(widget, track_id, track_name, ps)
        except Exception as e:
            log.warning("instruments['%s'] error: %s", key, e)
            return None

    def __getitem__(self, key: str):
        proxy = self._resolve(str(key))
        if proxy is None:
            raise KeyError(f"No instrument on track '{key}' (track not found or no instrument loaded)")
        return proxy

    def __contains__(self, key: str) -> bool:
        return self._resolve(str(key)) is not None

    def __iter__(self):
        """Iterate over all track names that have instruments."""
        dp = object.__getattribute__(self, '_dp')
        ps = object.__getattribute__(self, '_ps')
        if dp is None or ps is None:
            return
        try:
            tracks = ps.ctx.project.tracks
            for t in tracks:
                tid = str(getattr(t, 'id', ''))
                if tid and tid in dp._track_instruments:
                    yield str(getattr(t, 'name', ''))
        except Exception:
            return

    def __len__(self) -> int:
        return sum(1 for _ in self)

    def __repr__(self) -> str:
        items = list(self)
        if not items:
            return "<instruments: (keine Instrumente geladen)>"
        lines = ["<instruments:"]
        dp = object.__getattribute__(self, '_dp')
        ps = object.__getattribute__(self, '_ps')
        for name in items:
            try:
                proxy = self._resolve(name)
                iname = proxy._INSTRUMENT_NAME if proxy else "?"
                lines.append(f"  '{name}' → {iname}")
            except Exception:
                lines.append(f"  '{name}' → ?")
        lines.append(">")
        return '\n'.join(lines)

    def help(self) -> str:
        """Show all available instruments and their track assignments."""
        return repr(self)


# ═══════════════════════════════════════════════════════════════
# SC3: Audio-FX Proxy
# ═══════════════════════════════════════════════════════════════

class _AudioFxDeviceProxy:
    """Proxy for a single audio FX device on a track.

    Reads/writes directly to the device dict in trk.audio_fx_chain.
    """

    def __init__(self, device_dict: dict, track, project_service, device_panel):
        object.__setattr__(self, '_dev', device_dict)
        object.__setattr__(self, '_trk', track)
        object.__setattr__(self, '_ps', project_service)
        object.__setattr__(self, '_dp', device_panel)

    def _emit(self):
        try:
            ps = object.__getattribute__(self, '_ps')
            ps.project_changed.emit()
        except Exception:
            pass

    @property
    def name(self) -> str:
        return str(object.__getattribute__(self, '_dev').get('name', ''))

    @property
    def plugin_id(self) -> str:
        return str(object.__getattribute__(self, '_dev').get('plugin_id', ''))

    @property
    def enabled(self) -> bool:
        return bool(object.__getattribute__(self, '_dev').get('enabled', True))

    @enabled.setter
    def enabled(self, v: bool):
        object.__getattribute__(self, '_dev')['enabled'] = bool(v)
        self._emit()

    @property
    def params(self) -> dict:
        """All parameters as dict."""
        return dict(object.__getattribute__(self, '_dev').get('params', {}))

    def __getitem__(self, key: str):
        """Get a parameter value: device["threshold_db"]"""
        dev = object.__getattribute__(self, '_dev')
        p = dev.get('params', {})
        if str(key) in p:
            return p[str(key)]
        raise KeyError(f"Parameter '{key}' not found. Available: {list(p.keys())}")

    def __setitem__(self, key: str, value):
        """Set a parameter value: device["threshold_db"] = -20"""
        dev = object.__getattribute__(self, '_dev')
        p = dev.setdefault('params', {})
        p[str(key)] = value
        self._emit()

    def set(self, key: str, value) -> str:
        """Set a parameter: device.set("threshold_db", -20)"""
        self[str(key)] = value
        return f"{key} = {value}"

    def get(self, key: str, default=None):
        """Get a parameter value with optional default."""
        dev = object.__getattribute__(self, '_dev')
        return dev.get('params', {}).get(str(key), default)

    def reset(self) -> str:
        """Reset all parameters to spec defaults."""
        dev = object.__getattribute__(self, '_dev')
        pid = str(dev.get('plugin_id', ''))
        try:
            from pydaw.ui.fx_specs import get_audio_fx
            spec = next((s for s in get_audio_fx() if s.plugin_id == pid), None)
            if spec:
                dev['params'] = dict(spec.defaults)
                self._emit()
                return f"Reset to defaults: {self.name}"
        except Exception:
            pass
        return "No defaults found"

    def help(self) -> str:
        """Show available parameters."""
        dev = object.__getattribute__(self, '_dev')
        p = dev.get('params', {})
        lines = [f"🎛️ {self.name} ({self.plugin_id})", f"   enabled={self.enabled}", "   Parameters:"]
        for k, v in sorted(p.items()):
            if not str(k).startswith('__'):
                lines.append(f"     {k} = {v}")
        return '\n'.join(lines)

    def __repr__(self) -> str:
        return f"<AudioFX '{self.name}' enabled={self.enabled}>"


# ═══════════════════════════════════════════════════════════════
# SC4: Note-FX Proxy
# ═══════════════════════════════════════════════════════════════

class _NoteFxDeviceProxy:
    """Proxy for a single Note-FX device on a track."""

    def __init__(self, device_dict: dict, track, project_service):
        object.__setattr__(self, '_dev', device_dict)
        object.__setattr__(self, '_trk', track)
        object.__setattr__(self, '_ps', project_service)

    def _emit(self):
        try:
            ps = object.__getattribute__(self, '_ps')
            ps.project_changed.emit()
        except Exception:
            pass

    @property
    def name(self) -> str:
        return str(object.__getattribute__(self, '_dev').get('name', ''))

    @property
    def plugin_id(self) -> str:
        return str(object.__getattribute__(self, '_dev').get('plugin_id', ''))

    @property
    def enabled(self) -> bool:
        return bool(object.__getattribute__(self, '_dev').get('enabled', True))

    @enabled.setter
    def enabled(self, v: bool):
        object.__getattribute__(self, '_dev')['enabled'] = bool(v)
        self._emit()

    @property
    def params(self) -> dict:
        return dict(object.__getattribute__(self, '_dev').get('params', {}))

    def __getitem__(self, key: str):
        dev = object.__getattribute__(self, '_dev')
        p = dev.get('params', {})
        if str(key) in p:
            return p[str(key)]
        raise KeyError(f"Parameter '{key}' not found. Available: {list(p.keys())}")

    def __setitem__(self, key: str, value):
        dev = object.__getattribute__(self, '_dev')
        p = dev.setdefault('params', {})
        p[str(key)] = value
        self._emit()

    def set(self, key: str, value) -> str:
        self[str(key)] = value
        return f"{key} = {value}"

    def get(self, key: str, default=None):
        dev = object.__getattribute__(self, '_dev')
        return dev.get('params', {}).get(str(key), default)

    def help(self) -> str:
        dev = object.__getattribute__(self, '_dev')
        p = dev.get('params', {})
        lines = [f"🎵 {self.name} ({self.plugin_id})", f"   enabled={self.enabled}", "   Parameters:"]
        for k, v in sorted(p.items()):
            lines.append(f"     {k} = {v}")
        return '\n'.join(lines)

    def __repr__(self) -> str:
        return f"<NoteFX '{self.name}' enabled={self.enabled}>"


# ═══════════════════════════════════════════════════════════════
# SC3.12 + SC4.5: Track Device Chain Access
# ═══════════════════════════════════════════════════════════════

class _TrackDevicesProxy:
    """Proxy for accessing audio-FX and note-FX on a track.

    Usage:
        track_fx = _TrackDevicesProxy(track, ps, dp, "audio")
        track_fx[0]                  # First device
        track_fx["Compressor"]       # Find by name
        track_fx.add("Compressor")   # Add device
        track_fx.remove(0)           # Remove by index
        len(track_fx)                # Count
        list(track_fx)               # Iterate
    """

    def __init__(self, track, project_service, device_panel, kind: str = "audio"):
        object.__setattr__(self, '_trk', track)
        object.__setattr__(self, '_ps', project_service)
        object.__setattr__(self, '_dp', device_panel)
        object.__setattr__(self, '_kind', kind)  # "audio" or "note"

    def _get_chain(self) -> list:
        trk = object.__getattribute__(self, '_trk')
        kind = object.__getattribute__(self, '_kind')
        if kind == "note":
            chain = getattr(trk, 'note_fx_chain', None)
        else:
            chain = getattr(trk, 'audio_fx_chain', None)
        if isinstance(chain, dict):
            return chain.get('devices', [])
        return []

    def _proxy_for(self, dev_dict: dict):
        kind = object.__getattribute__(self, '_kind')
        ps = object.__getattribute__(self, '_ps')
        trk = object.__getattribute__(self, '_trk')
        dp = object.__getattribute__(self, '_dp')
        if kind == "note":
            return _NoteFxDeviceProxy(dev_dict, trk, ps)
        return _AudioFxDeviceProxy(dev_dict, trk, ps, dp)

    def __getitem__(self, key):
        devs = self._get_chain()
        if isinstance(key, int):
            if 0 <= key < len(devs):
                return self._proxy_for(devs[key])
            raise IndexError(f"Device index {key} out of range (0..{len(devs)-1})")
        # Search by name
        for d in devs:
            if str(d.get('name', '')) == str(key):
                return self._proxy_for(d)
        raise KeyError(f"Device '{key}' not found. Available: {[d.get('name','') for d in devs]}")

    def __len__(self) -> int:
        return len(self._get_chain())

    def __iter__(self):
        for d in self._get_chain():
            yield self._proxy_for(d)

    def __contains__(self, name: str) -> bool:
        return any(str(d.get('name', '')) == str(name) for d in self._get_chain())

    def add(self, name: str) -> str:
        """Add a device by name (e.g. 'Compressor', 'EQ-5', 'Arp').

        Returns confirmation string.
        """
        dp = object.__getattribute__(self, '_dp')
        trk = object.__getattribute__(self, '_trk')
        kind = object.__getattribute__(self, '_kind')
        tid = str(getattr(trk, 'id', ''))
        if dp is None or not tid:
            return "No device panel"

        # Find plugin_id from name
        try:
            if kind == "note":
                from pydaw.ui.fx_specs import get_note_fx
                specs = get_note_fx()
            else:
                from pydaw.ui.fx_specs import get_audio_fx
                specs = get_audio_fx()
            spec = next((s for s in specs if s.name == str(name)), None)
            if spec is None:
                # Try partial match
                spec = next((s for s in specs if str(name).lower() in s.name.lower()), None)
            if spec is None:
                avail = [s.name for s in specs]
                return f"Device '{name}' not found. Available: {avail}"
            if kind == "note":
                dp.add_note_fx_to_track(tid, spec.plugin_id)
            else:
                dp.add_audio_fx_to_track(tid, spec.plugin_id)
            return f"Added: {spec.name}"
        except Exception as e:
            return f"Error: {e}"

    def remove(self, index: int) -> str:
        """Remove device by index."""
        devs = self._get_chain()
        if not (0 <= int(index) < len(devs)):
            return f"Index {index} out of range"
        dp = object.__getattribute__(self, '_dp')
        trk = object.__getattribute__(self, '_trk')
        kind = object.__getattribute__(self, '_kind')
        tid = str(getattr(trk, 'id', ''))
        dev = devs[int(index)]
        dev_id = str(dev.get('id', ''))
        try:
            if kind == "note":
                dp.remove_note_fx_device(tid, dev_id)
            else:
                dp.remove_audio_fx_device(tid, dev_id)
            return f"Removed: {dev.get('name', '?')}"
        except Exception as e:
            return f"Error: {e}"

    def __repr__(self) -> str:
        kind = object.__getattribute__(self, '_kind')
        devs = self._get_chain()
        label = "Audio-FX" if kind == "audio" else "Note-FX"
        if not devs:
            return f"<{label}: (leer)>"
        lines = [f"<{label}:"]
        for i, d in enumerate(devs):
            en = "✓" if d.get('enabled', True) else "✗"
            lines.append(f"  [{i}] {en} {d.get('name', '?')}")
        lines.append(">")
        return '\n'.join(lines)


# ═══════════════════════════════════════════════════════════════
# SC1.3 Extended: Track with devices/note_fx Properties
# ═══════════════════════════════════════════════════════════════

class _ExtendedTrackProxy:
    """Extends the existing _TrackProxy with .devices and .note_fx.

    This wraps the existing track proxy to add FX chain access
    without modifying the original _TrackProxy class.
    """

    def __init__(self, track_proxy, track, project_service, device_panel):
        object.__setattr__(self, '_inner', track_proxy)
        object.__setattr__(self, '_track', track)
        object.__setattr__(self, '_ps', project_service)
        object.__setattr__(self, '_dp', device_panel)

    @property
    def devices(self) -> _TrackDevicesProxy:
        """Access audio-FX devices on this track."""
        trk = object.__getattribute__(self, '_track')
        ps = object.__getattribute__(self, '_ps')
        dp = object.__getattribute__(self, '_dp')
        return _TrackDevicesProxy(trk, ps, dp, "audio")

    @property
    def note_fx(self) -> _TrackDevicesProxy:
        """Access note-FX devices on this track."""
        trk = object.__getattribute__(self, '_track')
        ps = object.__getattribute__(self, '_ps')
        dp = object.__getattribute__(self, '_dp')
        return _TrackDevicesProxy(trk, ps, dp, "note")

    @property
    def instrument(self):
        """Access the instrument on this track (if any)."""
        dp = object.__getattribute__(self, '_dp')
        ps = object.__getattribute__(self, '_ps')
        trk = object.__getattribute__(self, '_track')
        tid = str(getattr(trk, 'id', ''))
        tname = str(getattr(trk, 'name', ''))
        if dp is None:
            return None
        try:
            inst_info = dp._track_instruments.get(tid)
            if inst_info is None:
                return None
            widget = inst_info.get('widget')
            plugin_id = str(inst_info.get('plugin_id', ''))
            if widget is None:
                return None
            proxy_cls = _PROXY_MAP.get(plugin_id)
            if proxy_cls is None:
                return _InstrumentProxyBase(widget, tid, tname, ps)
            return proxy_cls(widget, tid, tname, ps)
        except Exception:
            return None

    def __getattr__(self, name):
        # Delegate everything else to the inner _TrackProxy
        inner = object.__getattribute__(self, '_inner')
        return getattr(inner, name)

    def __setattr__(self, name, value):
        inner = object.__getattribute__(self, '_inner')
        setattr(inner, name, value)

    def __repr__(self):
        inner = object.__getattribute__(self, '_inner')
        return repr(inner)


class _ExtendedTrackListProxy:
    """Extended track list that returns _ExtendedTrackProxy with .devices/.note_fx.

    Wraps the original _TrackListProxy, replacing each returned track
    with an _ExtendedTrackProxy.
    """

    def __init__(self, inner_list, project_service, device_panel):
        object.__setattr__(self, '_inner', inner_list)
        object.__setattr__(self, '_ps', project_service)
        object.__setattr__(self, '_dp', device_panel)

    def _wrap(self, track_proxy, track_obj):
        ps = object.__getattribute__(self, '_ps')
        dp = object.__getattribute__(self, '_dp')
        return _ExtendedTrackProxy(track_proxy, track_obj, ps, dp)

    def __getitem__(self, key):
        inner = object.__getattribute__(self, '_inner')
        ps = object.__getattribute__(self, '_ps')

        # Get the raw track proxy
        proxy = inner[key]

        # Find the actual track object to pass to extended proxy
        try:
            tracks = ps.ctx.project.tracks
            if isinstance(key, int):
                if 0 <= key < len(tracks):
                    return self._wrap(proxy, tracks[key])
            elif isinstance(key, str):
                for t in tracks:
                    if getattr(t, 'name', '') == str(key):
                        return self._wrap(proxy, t)
        except Exception:
            pass
        return proxy

    def __len__(self):
        return len(object.__getattribute__(self, '_inner'))

    def __iter__(self):
        inner = object.__getattribute__(self, '_inner')
        ps = object.__getattribute__(self, '_ps')
        try:
            tracks = ps.ctx.project.tracks
            for i, proxy in enumerate(inner):
                if i < len(tracks):
                    yield self._wrap(proxy, tracks[i])
                else:
                    yield proxy
        except Exception:
            yield from inner

    def __repr__(self):
        return repr(object.__getattribute__(self, '_inner'))


# ═══════════════════════════════════════════════════════════════
# SC6: History, Snapshots & Macros (Console Functions)
# ═══════════════════════════════════════════════════════════════

class _HistoryProxy:
    """Console access to scripting history (backed by SQLite)."""

    def __call__(self, n: int = 20) -> str:
        """Show last N commands."""
        try:
            from pydaw.services.extended_state_db import ExtendedStateDB
            edb = ExtendedStateDB.get()
            edb.ensure_loaded()
            rows = edb.get_script_history(limit=int(n))
            if not rows:
                return "(keine History)"
            lines = ["📜 Script History (neueste zuerst):"]
            for r in rows:
                ok = "✓" if r.get('success', 1) else "✗"
                code = str(r.get('code', '')).replace('\n', ' ')[:60]
                lines.append(f"  {ok} {code}")
            return '\n'.join(lines)
        except Exception as e:
            return f"Error: {e}"

    def search(self, query: str) -> str:
        """Search history for a keyword."""
        try:
            from pydaw.services.extended_state_db import ExtendedStateDB
            edb = ExtendedStateDB.get()
            edb.ensure_loaded()
            rows = edb.search_script_history(str(query))
            if not rows:
                return f"Keine Treffer für '{query}'"
            lines = [f"🔍 Suche: '{query}' ({len(rows)} Treffer):"]
            for r in rows:
                code = str(r.get('code', '')).replace('\n', ' ')[:60]
                lines.append(f"  {code}")
            return '\n'.join(lines)
        except Exception as e:
            return f"Error: {e}"

    def clear(self) -> str:
        """Clear all history."""
        try:
            from pydaw.services.extended_state_db import ExtendedStateDB
            edb = ExtendedStateDB.get()
            edb.ensure_loaded()
            conn = edb._conn()
            try:
                conn.execute("DELETE FROM script_history")
                conn.commit()
            finally:
                conn.close()
            return "History gelöscht"
        except Exception as e:
            return f"Error: {e}"

    def __repr__(self):
        return self(10)


class _MacroProxy:
    """Console access to macro recording and playback."""

    def __init__(self, scripting_service):
        object.__setattr__(self, '_svc', scripting_service)
        object.__setattr__(self, '_recording', False)
        object.__setattr__(self, '_rec_name', '')
        object.__setattr__(self, '_rec_commands', [])

    def start(self, name: str) -> str:
        """Start recording a macro."""
        object.__setattr__(self, '_recording', True)
        object.__setattr__(self, '_rec_name', str(name))
        object.__setattr__(self, '_rec_commands', [])
        return f"🔴 Macro '{name}' — Aufnahme gestartet. macro.stop() zum Beenden."

    def stop(self) -> str:
        """Stop recording and save the macro."""
        if not object.__getattribute__(self, '_recording'):
            return "Keine Aufnahme aktiv"
        name = object.__getattribute__(self, '_rec_name')
        cmds = object.__getattribute__(self, '_rec_commands')
        object.__setattr__(self, '_recording', False)

        import json
        try:
            from pydaw.services.extended_state_db import ExtendedStateDB
            edb = ExtendedStateDB.get()
            edb.ensure_loaded()
            edb.save_macro(name, json.dumps(cmds), duration=0.0)
            return f"⏹️ Macro '{name}' gespeichert ({len(cmds)} Befehle)"
        except Exception as e:
            return f"Error: {e}"

    def record_command(self, code: str) -> None:
        """Internal: called by execute() to record commands during macro recording."""
        if object.__getattribute__(self, '_recording'):
            cmds = object.__getattribute__(self, '_rec_commands')
            # Don't record macro control commands themselves
            if not code.strip().startswith('macro.'):
                cmds.append(code)

    def run(self, name: str) -> str:
        """Run a saved macro by name."""
        import json
        try:
            from pydaw.services.extended_state_db import ExtendedStateDB
            edb = ExtendedStateDB.get()
            edb.ensure_loaded()
            macros = edb.get_macros(limit=100)
            macro = next((m for m in macros if m.get('name') == str(name)), None)
            if macro is None:
                return f"Macro '{name}' nicht gefunden"

            cmds = json.loads(str(macro.get('actions_json', '[]')))
            svc = object.__getattribute__(self, '_svc')
            results = []
            for cmd in cmds:
                r = svc.execute(str(cmd))
                if r.output:
                    results.append(r.output)
                if r.error:
                    results.append(f"⚠️ {r.error}")
            return f"▶️ Macro '{name}' ({len(cmds)} Befehle)\n" + '\n'.join(results)
        except Exception as e:
            return f"Error: {e}"

    def list(self) -> str:
        """List all saved macros."""
        try:
            from pydaw.services.extended_state_db import ExtendedStateDB
            edb = ExtendedStateDB.get()
            edb.ensure_loaded()
            macros = edb.get_macros(limit=100)
            if not macros:
                return "(keine Macros gespeichert)"
            lines = ["📋 Gespeicherte Macros:"]
            for m in macros:
                import json
                cmds = json.loads(str(m.get('actions_json', '[]')))
                lines.append(f"  '{m.get('name','')}' — {len(cmds)} Befehle")
            return '\n'.join(lines)
        except Exception as e:
            return f"Error: {e}"

    def delete(self, name: str) -> str:
        """Delete a macro by name."""
        try:
            from pydaw.services.extended_state_db import ExtendedStateDB
            edb = ExtendedStateDB.get()
            edb.ensure_loaded()
            macros = edb.get_macros(limit=100)
            macro = next((m for m in macros if m.get('name') == str(name)), None)
            if macro is None:
                return f"Macro '{name}' nicht gefunden"
            edb.delete_macro(int(macro['id']))
            return f"Macro '{name}' gelöscht"
        except Exception as e:
            return f"Error: {e}"

    def export(self, name: str, path: str) -> str:
        """Export a macro as Python script."""
        import json
        try:
            from pydaw.services.extended_state_db import ExtendedStateDB
            edb = ExtendedStateDB.get()
            edb.ensure_loaded()
            macros = edb.get_macros(limit=100)
            macro = next((m for m in macros if m.get('name') == str(name)), None)
            if macro is None:
                return f"Macro '{name}' nicht gefunden"
            cmds = json.loads(str(macro.get('actions_json', '[]')))
            with open(str(path), 'w') as f:
                f.write(f"# Py_DAW Macro: {name}\n")
                f.write(f"# Exportiert aus Python Console\n\n")
                for cmd in cmds:
                    f.write(cmd + '\n')
            return f"Exportiert: {path} ({len(cmds)} Befehle)"
        except Exception as e:
            return f"Error: {e}"

    @property
    def recording(self) -> bool:
        return object.__getattribute__(self, '_recording')

    def __repr__(self):
        if self.recording:
            n = object.__getattribute__(self, '_rec_name')
            c = len(object.__getattribute__(self, '_rec_commands'))
            return f"<Macro 🔴 Recording '{n}' ({c} Befehle)>"
        return "<Macro — macro.start('name') zum Aufnehmen>"


class _SnapshotProxy:
    """Save/restore complete project state snapshots."""

    def __init__(self, project_service):
        object.__setattr__(self, '_ps', project_service)

    def save(self, name: str) -> str:
        """Save current project state as a named snapshot."""
        import json, time as _time
        try:
            ps = object.__getattribute__(self, '_ps')
            state = {}
            try:
                proj = ps.ctx.project
                state['bpm'] = getattr(proj, 'bpm', 120)
                state['tracks'] = []
                for t in proj.tracks:
                    td = {
                        'name': getattr(t, 'name', ''),
                        'volume': getattr(t, 'volume', 1.0),
                        'pan': getattr(t, 'pan', 0.0),
                        'muted': getattr(t, 'muted', False),
                        'solo': getattr(t, 'solo', False),
                    }
                    # Include FX chains
                    afxc = getattr(t, 'audio_fx_chain', None)
                    if isinstance(afxc, dict):
                        td['audio_fx_chain'] = afxc
                    nfxc = getattr(t, 'note_fx_chain', None)
                    if isinstance(nfxc, dict):
                        td['note_fx_chain'] = nfxc
                    state['tracks'].append(td)
            except Exception:
                pass

            from pydaw.services.extended_state_db import ExtendedStateDB
            edb = ExtendedStateDB.get()
            edb.ensure_loaded()
            # Use undo_snapshot table for snapshots
            proj_path = str(getattr(ps.ctx, 'project_path', 'snapshot'))
            edb.save_undo_snapshot(proj_path, f"snapshot:{name}", json.dumps(state))
            return f"📸 Snapshot '{name}' gespeichert"
        except Exception as e:
            return f"Error: {e}"

    def restore(self, name: str) -> str:
        """Restore a named snapshot (mixer state only — safe, non-destructive)."""
        import json
        try:
            ps = object.__getattribute__(self, '_ps')
            from pydaw.services.extended_state_db import ExtendedStateDB
            edb = ExtendedStateDB.get()
            edb.ensure_loaded()
            proj_path = str(getattr(ps.ctx, 'project_path', 'snapshot'))
            snapshots = edb.get_undo_snapshots(proj_path, limit=100)
            snap = next((s for s in snapshots if s.get('label', '') == f"snapshot:{name}"), None)
            if snap is None:
                return f"Snapshot '{name}' nicht gefunden"

            state_json = edb.get_undo_snapshot_state(int(snap['id']))
            if not state_json:
                return "Snapshot-Daten nicht gefunden"

            state = json.loads(state_json)
            proj = ps.ctx.project

            # Restore BPM
            if 'bpm' in state:
                proj.bpm = float(state['bpm'])

            # Restore mixer state (safe: only volume/pan/mute/solo)
            for sd in state.get('tracks', []):
                tname = str(sd.get('name', ''))
                for t in proj.tracks:
                    if getattr(t, 'name', '') == tname:
                        if 'volume' in sd:
                            t.volume = float(sd['volume'])
                        if 'pan' in sd:
                            t.pan = float(sd['pan'])
                        if 'muted' in sd:
                            t.muted = bool(sd['muted'])
                        if 'solo' in sd:
                            t.solo = bool(sd['solo'])
                        break
            ps.project_changed.emit()
            return f"📸 Snapshot '{name}' wiederhergestellt (Mixer-State)"
        except Exception as e:
            return f"Error: {e}"

    def list(self) -> str:
        """List all snapshots."""
        try:
            from pydaw.services.extended_state_db import ExtendedStateDB
            edb = ExtendedStateDB.get()
            edb.ensure_loaded()
            ps = object.__getattribute__(self, '_ps')
            proj_path = str(getattr(ps.ctx, 'project_path', 'snapshot'))
            snapshots = edb.get_undo_snapshots(proj_path, limit=100)
            snaps = [s for s in snapshots if str(s.get('label', '')).startswith('snapshot:')]
            if not snaps:
                return "(keine Snapshots)"
            lines = ["📸 Snapshots:"]
            for s in snaps:
                name = str(s.get('label', '')).replace('snapshot:', '')
                lines.append(f"  '{name}'")
            return '\n'.join(lines)
        except Exception as e:
            return f"Error: {e}"

    def __call__(self, name: str) -> str:
        """Shortcut: snapshot("name") saves."""
        return self.save(name)

    def __repr__(self):
        return self.list()


# ═══════════════════════════════════════════════════════════════
# SC7: Batch Operations & Templates
# ═══════════════════════════════════════════════════════════════

class _TemplatesProxy:
    """Pre-built FX chain templates."""

    def __init__(self, device_panel, project_service):
        object.__setattr__(self, '_dp', device_panel)
        object.__setattr__(self, '_ps', project_service)

    def _find_track_id(self, name: str) -> str:
        ps = object.__getattribute__(self, '_ps')
        try:
            for t in ps.ctx.project.tracks:
                if getattr(t, 'name', '') == str(name):
                    return str(getattr(t, 'id', ''))
        except Exception:
            pass
        return ''

    def vocal_chain(self, track_name: str) -> str:
        """Apply vocal chain: EQ-5 → Compressor → De-Esser → Reverb."""
        dp = object.__getattribute__(self, '_dp')
        tid = self._find_track_id(track_name)
        if not tid:
            return f"Track '{track_name}' nicht gefunden"
        try:
            for fx in ["chrono.fx.eq5", "chrono.fx.compressor", "chrono.fx.de_esser", "chrono.fx.reverb"]:
                dp.add_audio_fx_to_track(tid, fx)
            return f"🎤 Vocal-Chain auf '{track_name}': EQ-5 → Compressor → De-Esser → Reverb"
        except Exception as e:
            return f"Error: {e}"

    def drum_bus(self, track_name: str) -> str:
        """Apply drum bus chain: Compressor → EQ-5 → Peak Limiter."""
        dp = object.__getattribute__(self, '_dp')
        tid = self._find_track_id(track_name)
        if not tid:
            return f"Track '{track_name}' nicht gefunden"
        try:
            for fx in ["chrono.fx.compressor", "chrono.fx.eq5", "chrono.fx.peak_limiter"]:
                dp.add_audio_fx_to_track(tid, fx)
            return f"🥁 Drum-Bus auf '{track_name}': Compressor → EQ-5 → Peak Limiter"
        except Exception as e:
            return f"Error: {e}"

    def master_chain(self, track_name: str = "Master") -> str:
        """Apply master chain: EQ-5 → Compressor → Stereo Widener → Peak Limiter → Spectrum Analyzer."""
        dp = object.__getattribute__(self, '_dp')
        tid = self._find_track_id(track_name)
        if not tid:
            return f"Track '{track_name}' nicht gefunden"
        try:
            for fx in ["chrono.fx.eq5", "chrono.fx.compressor", "chrono.fx.stereo_widener",
                       "chrono.fx.peak_limiter", "chrono.fx.spectrum_analyzer"]:
                dp.add_audio_fx_to_track(tid, fx)
            return f"🎛️ Master-Chain auf '{track_name}': EQ → Comp → Stereo → Limiter → Analyzer"
        except Exception as e:
            return f"Error: {e}"

    def clean_guitar(self, track_name: str) -> str:
        """Apply clean guitar chain: EQ-5 → Chorus → Delay-2 → Reverb."""
        dp = object.__getattribute__(self, '_dp')
        tid = self._find_track_id(track_name)
        if not tid:
            return f"Track '{track_name}' nicht gefunden"
        try:
            for fx in ["chrono.fx.eq5", "chrono.fx.chorus", "chrono.fx.delay2", "chrono.fx.reverb"]:
                dp.add_audio_fx_to_track(tid, fx)
            return f"🎸 Clean-Guitar auf '{track_name}': EQ → Chorus → Delay → Reverb"
        except Exception as e:
            return f"Error: {e}"

    def synth_pad(self, track_name: str) -> str:
        """Apply synth pad chain: Phaser → Chorus → Reverb → Stereo Widener."""
        dp = object.__getattribute__(self, '_dp')
        tid = self._find_track_id(track_name)
        if not tid:
            return f"Track '{track_name}' nicht gefunden"
        try:
            for fx in ["chrono.fx.filter_plus", "chrono.fx.chorus", "chrono.fx.reverb",
                       "chrono.fx.stereo_widener"]:
                dp.add_audio_fx_to_track(tid, fx)
            return f"🎹 Synth-Pad auf '{track_name}': Phaser → Chorus → Reverb → Stereo"
        except Exception as e:
            return f"Error: {e}"

    def help(self) -> str:
        return """🎨 FX-Chain Templates:
  templates.vocal_chain("Vocals")     — EQ → Comp → DeEss → Reverb
  templates.drum_bus("Drums")         — Comp → EQ → Limiter
  templates.master_chain("Master")    — EQ → Comp → Stereo → Limiter → Analyzer
  templates.clean_guitar("Guitar")    — EQ → Chorus → Delay → Reverb
  templates.synth_pad("Pad")          — Phaser → Chorus → Reverb → Stereo"""

    def __repr__(self):
        return self.help()


# ═══════════════════════════════════════════════════════════════
# SC8: Tab-Completion (__dir__) + Inline Help
# ═══════════════════════════════════════════════════════════════

# Monkey-patch __dir__ onto key classes for tab-completion in console

def _public_attrs(cls):
    """Return list of public attributes/methods for tab-completion."""
    return [n for n in dir(cls) if not n.startswith('_')]

_DrumSlotProxy.__dir__ = lambda self: [
    'name', 'sample', 'has_sample', 'gain', 'pan', 'tune',
    'filter', 'cutoff', 'resonance', 'start', 'end',
    'choke', 'channel', 'load', 'clear', 'trigger', 'env', 'fx',
]

_DrumSlotProxy.help = lambda self: '\n'.join([
    f"🥁 Drum Slot {object.__getattribute__(self, '_slot').state.index}: "
    f"'{object.__getattribute__(self, '_slot').state.name}'",
    "",
    "Properties (read/write):",
    "  .name        str    — Pad-Name",
    "  .gain        float  — Lautstärke (0–100)",
    "  .pan         float  — Stereo (-1..+1)",
    "  .tune        int    — Pitch-Offset (Halbtöne)",
    "  .filter      str    — off/lowpass/highpass/bandpass",
    "  .cutoff      float  — Filter-Cutoff (20–20000 Hz)",
    "  .resonance   float  — Filter-Q (0.25–12.0)",
    "  .start       float  — Region Start (0–1)",
    "  .end         float  — Region End (0–1)",
    "  .choke       int    — Choke Group (0=off, 1–8)",
    "  .channel     int    — MIDI Channel (-1=Omni, 0–15)",
    "",
    "Properties (read-only):",
    "  .sample      str    — Aktueller Sample-Pfad",
    "  .has_sample   bool   — Sample geladen?",
    "",
    "Methods:",
    "  .load(path)          — Sample laden",
    "  .clear()             — Sample entfernen",
    "  .trigger(velocity)   — Pad triggern",
    "  .env(a,d,s,r)        — ADSR setzen",
    "  .fx(chorus,delay,reverb) — FX-Mix",
])

_DrumMachineProxy.__dir__ = lambda self: [
    'slots', 'slot', 'slot_count', 'base_note', 'multi_output',
    'trigger', 'export_state', 'import_state', 'help',
]

_SamplerProxy.__dir__ = lambda self: [
    'load', 'root', 'gain', 'pan', 'loop', 'filter', 'cutoff', 'resonance',
    'env', 'start', 'end', 'distortion', 'set_fx',
    'trigger', 'export_state', 'import_state', 'help',
]
_SamplerProxy.help = lambda self: '\n'.join([
    f"🎹 Pro Sampler on '{object.__getattribute__(self, '_track_name')}'",
    "",
    "Properties: .root .gain .pan .loop .filter .cutoff .resonance",
    "            .start .end .distortion .env (→ .env.attack .env.decay ...)",
    "Methods:    .load(path) .set_fx(chorus=,delay=,reverb=) .trigger(pitch,vel)",
    "            .export_state() .import_state(dict)",
])

_AeternaProxy.__dir__ = lambda self: [
    'params', 'set', 'get', 'preset', 'wavetable', 'wavetable_builtin',
    'trigger', 'export_state', 'import_state', 'help',
]
_FusionProxy.__dir__ = lambda self: [
    'params', 'set', 'get', 'trigger', 'export_state', 'import_state', 'help',
]
_BRRRProxy.__dir__ = lambda self: [
    'params', 'trigger', 'export_state', 'import_state', 'help',
]
_BachOrgelProxy.__dir__ = lambda self: [
    'params', 'set', 'get', 'trigger', 'export_state', 'import_state', 'help',
]

_AudioFxDeviceProxy.__dir__ = lambda self: [
    'name', 'plugin_id', 'enabled', 'params', 'set', 'get', 'reset', 'help',
]

_NoteFxDeviceProxy.__dir__ = lambda self: [
    'name', 'plugin_id', 'enabled', 'params', 'set', 'get', 'help',
]

_TrackDevicesProxy.__dir__ = lambda self: [
    'add', 'remove', 'help',
]
_TrackDevicesProxy.help = lambda self: '\n'.join([
    "🎛️ Device Chain",
    "",
    "  chain[0]              — Erster Device (Index)",
    "  chain['Compressor']   — Device nach Name",
    "  chain.add('Reverb')   — Device hinzufügen",
    "  chain.remove(0)       — Device entfernen (Index)",
    "  len(chain)            — Anzahl Devices",
    "  list(chain)           — Alle Devices iterieren",
    "",
    "Auf jedem Device:",
    "  dev.enabled = False   — Bypass",
    "  dev['param'] = value  — Parameter setzen",
    "  dev.params            — Alle Parameter",
    "  dev.reset()           — Defaults wiederherstellen",
])

_ExtendedTrackProxy.__dir__ = lambda self: [
    'name', 'volume', 'pan', 'muted', 'solo', 'record_arm', 'monitor',
    'devices', 'note_fx', 'instrument',
]

_InstrumentsProxy.__dir__ = lambda self: list(self)

_HistoryProxy.__dir__ = lambda self: ['search', 'clear']
_MacroProxy.__dir__ = lambda self: ['start', 'stop', 'run', 'list', 'delete', 'export', 'recording']
_SnapshotProxy.__dir__ = lambda self: ['save', 'restore', 'list']
_TemplatesProxy.__dir__ = lambda self: ['vocal_chain', 'drum_bus', 'master_chain', 'clean_guitar', 'synth_pad', 'help']


# ═══════════════════════════════════════════════════════════════
# SC8.1: Full API Reference (for help_api())
# ═══════════════════════════════════════════════════════════════

FULL_API_REFERENCE = """
🎵 Py_DAW Python Console — Vollständige API-Referenz
═══════════════════════════════════════════════════════

📦 GLOBALE OBJEKTE
  project          — Projekt (bpm, name, sample_rate)
  tracks           — Track-Liste (tracks[0], tracks["Name"])
  clips            — Clip-Liste
  transport        — Play/Stop/Seek/Loop
  mixer            — Volume/Pan/Mute/Solo
  instruments      — Instrument-Proxys
  history          — Script-History (SQLite)
  macro            — Macro-Aufnahme/Wiedergabe
  snapshot         — Projekt-Snapshots
  templates        — FX-Chain Templates

🥁 INSTRUMENTE (instruments["Track"])
  Drum Machine:    .slot(N), .slots, .trigger(pitch, vel)
  Pro Sampler:     .load(path), .root, .gain, .pan, .env, .filter
  AETERNA:         .set(param, val), .get(param), .wavetable(path)
  Fusion:          .set(param, val), .get(param)
  BRRR:            .trigger(pitch, vel), .params
  Bach Orgel:      .set(param, val), .get(param)

🎛️ AUDIO-FX (tracks["T"].devices)
  .add("Name")           — Hinzufügen (Compressor, EQ-5, Reverb, ...)
  .remove(index)         — Entfernen
  [0]["param"] = value   — Parameter setzen
  [0].enabled = False    — Bypass
  [0].reset()            — Defaults

🎵 NOTE-FX (tracks["T"].note_fx)
  .add("Arp")            — Hinzufügen
  [0]["mode"] = "up"     — Parameter setzen

🎨 TEMPLATES
  templates.vocal_chain("Vocals")
  templates.drum_bus("Drums")
  templates.master_chain("Master")
  templates.clean_guitar("Guitar")
  templates.synth_pad("Pad")

📜 HISTORY + MACROS
  history()              — Letzte Befehle
  history.search("text") — Suchen
  macro.start("name")    — Aufnahme
  macro.stop()           — Speichern
  macro.run("name")      — Abspielen
  macro.export("n",path) — Als .py exportieren

📸 SNAPSHOTS
  snapshot("name")       — Speichern
  restore("name")        — Wiederherstellen
  snapshot.list()        — Alle anzeigen

💡 TIPPS
  help(instruments)      — Instrument-Hilfe
  drum.slot(0).help()    — Slot-Parameter
  tracks["V"].devices[0].help() — FX-Parameter
"""

# SC8 addendum: Tab-completion for new proxies
_AdvancedSamplerProxy.__dir__ = lambda self: [
    'zones', 'zone_count', 'params', 'trigger', 'export_state', 'import_state', 'help',
]
_SF2Proxy.__dir__ = lambda self: [
    'program', 'params', 'trigger', 'export_state', 'import_state', 'help',
]
