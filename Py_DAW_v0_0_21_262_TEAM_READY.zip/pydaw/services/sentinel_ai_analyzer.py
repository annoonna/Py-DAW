"""sentinel_ai_analyzer.py — KI-Anbindung (Phase S10).

v0.0.20.905 — Phase S10 der SENTINEL_ROADMAP.

Integration mit Claude API fuer intelligente Crash-Analyse.
Kein Auto-Send — User muss IMMER bestaetigen (Datenschutz).

Ablauf:
1. Crash passiert → SENTINEL sammelt Blackbox
2. User wird gefragt: "KI-Analyse anfordern?"
3. Wenn ja: anonymisierter Report → Anthropic API → Analyse-Text
4. Analyse wird in UI angezeigt + in DB gespeichert

Ohne API-Key: nur lokale Pattern-Analyse (kein Netzwerk).
Mit API-Key: lokale + KI-gestuetzte Analyse.
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from typing import Any, Callable, Dict, Optional

log = logging.getLogger(__name__)

# Anonymization: these keys are stripped from crash data before sending
_SENSITIVE_KEYS = {
    "project_path", "home_dir", "user", "username", "hostname",
    "ip", "ip_address", "file_path", "filepath", "abs_path",
    "email", "session_file", "recent_projects",
}


def _anonymize(data: Any, depth: int = 0) -> Any:
    """Recursively strip sensitive fields from data before sending to API."""
    if depth > 20:
        return "<too deep>"
    if isinstance(data, dict):
        return {
            k: _anonymize(v, depth + 1)
            for k, v in data.items()
            if k.lower() not in _SENSITIVE_KEYS
        }
    if isinstance(data, list):
        return [_anonymize(item, depth + 1) for item in data[:50]]
    if isinstance(data, str) and len(data) > 3000:
        return data[:3000] + "…"
    return data


class SentinelAIAnalyzer:
    """KI-gestuetzte Crash- und Anomalie-Analyse.

    Uses Claude API (Anthropic) to analyze crash reports and provide
    structured fix suggestions. Privacy-first: no data sent without
    explicit user confirmation. All data is anonymized before sending.

    Usage:
        analyzer = SentinelAIAnalyzer.get()
        analyzer.set_api_key("sk-ant-...")
        result = analyzer.analyze_crash(crash_data)
    """

    _instance: Optional["SentinelAIAnalyzer"] = None

    @classmethod
    def get(cls) -> "SentinelAIAnalyzer":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._api_key: str = ""
        self._api_url: str = "https://api.anthropic.com/v1/messages"
        self._model: str = "claude-sonnet-4-20250514"
        self._db = None
        self._max_tokens: int = 2000
        self._timeout: float = 30.0
        # Callback for UI notification
        self._result_callback: Optional[Callable] = None

    def set_api_key(self, key: str) -> None:
        """Set the Anthropic API key. Key is NOT stored in plaintext on disk."""
        self._api_key = key.strip()

    def set_api_url(self, url: str) -> None:
        """Set custom API URL (for self-hosted or alternative endpoints)."""
        self._api_url = url.strip()

    def set_model(self, model: str) -> None:
        """Set the model to use (default: claude-sonnet-4-20250514)."""
        self._model = model.strip()

    def set_result_callback(self, callback: Callable) -> None:
        """Set callback for receiving async analysis results.

        Callback signature: callback(analysis_text: str, source: str, crash_id: int)
        """
        self._result_callback = callback

    @property
    def has_api_key(self) -> bool:
        return bool(self._api_key)

    @property
    def is_available(self) -> bool:
        """Check if AI analysis is available (has API key + urllib3/requests)."""
        return bool(self._api_key)

    def start(self) -> None:
        """Initialize DB connection."""
        try:
            from pydaw.services.sentinel_db import SentinelDB
            self._db = SentinelDB.get()
            self._db.ensure_loaded()
        except Exception:
            pass

    def load_key_from_keyring(self) -> bool:
        """Try to load API key from system keyring (if available)."""
        try:
            import keyring
            key = keyring.get_password("pydaw_sentinel", "anthropic_api_key")
            if key:
                self._api_key = key
                log.info("[SENTINEL AI] API key loaded from keyring")
                return True
        except ImportError:
            log.debug("[SENTINEL AI] keyring module not available")
        except Exception as exc:
            log.debug("[SENTINEL AI] keyring load failed: %s", exc)
        return False

    def save_key_to_keyring(self, key: str) -> bool:
        """Save API key to system keyring (encrypted)."""
        try:
            import keyring
            keyring.set_password("pydaw_sentinel", "anthropic_api_key", key)
            self._api_key = key
            log.info("[SENTINEL AI] API key saved to keyring")
            return True
        except ImportError:
            log.warning("[SENTINEL AI] keyring module not installed — "
                        "pip install keyring")
        except Exception as exc:
            log.warning("[SENTINEL AI] keyring save failed: %s", exc)
        return False

    def delete_key_from_keyring(self) -> bool:
        """Delete API key from system keyring."""
        try:
            import keyring
            keyring.delete_password("pydaw_sentinel", "anthropic_api_key")
            self._api_key = ""
            log.info("[SENTINEL AI] API key deleted from keyring")
            return True
        except Exception:
            pass
        self._api_key = ""
        return False

    # ══════════════════════════════════════════════════════════════
    # Analysis Methods
    # ══════════════════════════════════════════════════════════════

    def analyze_crash(self, crash_data: dict) -> str:
        """Analyze a crash report using Claude API.

        Args:
            crash_data: Dict with crash details (will be anonymized).

        Returns:
            Analysis text (markdown) or error message.
        """
        if not self._api_key:
            return self._local_analysis(crash_data)

        # Anonymize before sending
        safe_data = _anonymize(crash_data)

        prompt = self._build_crash_prompt(safe_data)
        result = self._call_api(prompt)
        if result.startswith("ERROR:"):
            log.warning("[SENTINEL AI] API call failed: %s", result)
            return self._local_analysis(crash_data) + \
                f"\n\n*KI-Analyse fehlgeschlagen: {result}*"
        return result

    def analyze_anomaly(self, anomaly_data: dict) -> str:
        """Analyze an anomaly using Claude API."""
        if not self._api_key:
            return self._local_anomaly_analysis(anomaly_data)

        safe_data = _anonymize(anomaly_data)
        prompt = self._build_anomaly_prompt(safe_data)
        result = self._call_api(prompt)
        if result.startswith("ERROR:"):
            return self._local_anomaly_analysis(anomaly_data) + \
                f"\n\n*KI-Analyse fehlgeschlagen: {result}*"
        return result

    def analyze_crash_async(self, crash_data: dict, crash_id: int = 0) -> None:
        """Analyze crash in background thread, notify via callback."""
        def _run():
            result = self.analyze_crash(crash_data)
            source = "ai" if self._api_key else "local"
            if self._result_callback:
                try:
                    self._result_callback(result, source, crash_id)
                except Exception:
                    pass

        t = threading.Thread(target=_run, name="sentinel-ai-analyze", daemon=True)
        t.start()

    def get_proactive_recommendations(self) -> str:
        """Get proactive recommendations based on current patterns.

        Sends anonymized pattern data to API and gets suggestions.
        """
        if not self._api_key or not self._db:
            return ""

        patterns = self._db.get_patterns(limit=20)
        if not patterns:
            return ""

        safe_patterns = _anonymize(patterns)
        prompt = self._build_recommendations_prompt(safe_patterns)
        result = self._call_api(prompt)
        return result if not result.startswith("ERROR:") else ""

    # ══════════════════════════════════════════════════════════════
    # API Call
    # ══════════════════════════════════════════════════════════════

    def _call_api(self, user_prompt: str) -> str:
        """Call Anthropic Messages API.

        Returns the assistant response text or 'ERROR: ...' string.
        """
        try:
            import urllib.request
            import urllib.error

            body = json.dumps({
                "model": self._model,
                "max_tokens": self._max_tokens,
                "messages": [
                    {"role": "user", "content": user_prompt},
                ],
                "system": (
                    "Du bist SENTINEL, ein KI-Diagnose-Assistent fuer die "
                    "Py_DAW Digital Audio Workstation. Analysiere Crash-Reports "
                    "und Anomalien. Antworte auf Deutsch, strukturiert als "
                    "Markdown. Gib konkrete, hilfreiche Empfehlungen. "
                    "Vermeide Spekulationen — basiere deine Analyse auf den "
                    "bereitgestellten Daten."
                ),
            }).encode("utf-8")

            req = urllib.request.Request(
                self._api_url,
                data=body,
                headers={
                    "Content-Type": "application/json",
                    "x-api-key": self._api_key,
                    "anthropic-version": "2023-06-01",
                },
                method="POST",
            )

            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                # Extract text from content blocks
                content = data.get("content", [])
                texts = []
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "text":
                        texts.append(block.get("text", ""))
                return "\n".join(texts) if texts else "Keine Analyse erhalten."

        except urllib.error.HTTPError as exc:
            return f"ERROR: HTTP {exc.code} — {exc.reason}"
        except urllib.error.URLError as exc:
            return f"ERROR: Verbindungsfehler — {exc.reason}"
        except TimeoutError:
            return "ERROR: Timeout (API nicht erreichbar)"
        except Exception as exc:
            return f"ERROR: {type(exc).__name__}: {exc}"

    # ══════════════════════════════════════════════════════════════
    # Prompt Building
    # ══════════════════════════════════════════════════════════════

    def _build_crash_prompt(self, crash_data: dict) -> str:
        """Build prompt for crash analysis."""
        crash_json = json.dumps(crash_data, indent=2, ensure_ascii=False,
                                 default=str)[:4000]
        return (
            "Analysiere diesen Crash-Report der Py_DAW Audio Workstation.\n\n"
            "## Crash-Daten\n"
            f"```json\n{crash_json}\n```\n\n"
            "## Bitte analysiere:\n"
            "1. **Ursache**: Was hat den Crash wahrscheinlich ausgeloest?\n"
            "2. **Komponente**: Welche Komponente ist betroffen?\n"
            "3. **Schwere**: Wie kritisch ist das Problem (1-5)?\n"
            "4. **Fix-Vorschlag**: Konkreter Vorschlag zur Behebung\n"
            "5. **Praevention**: Wie kann man das in Zukunft vermeiden?\n\n"
            "Antworte strukturiert als Markdown."
        )

    def _build_anomaly_prompt(self, anomaly_data: dict) -> str:
        """Build prompt for anomaly analysis."""
        anomaly_json = json.dumps(anomaly_data, indent=2, ensure_ascii=False,
                                    default=str)[:3000]
        return (
            "Analysiere diese Anomalie der Py_DAW Audio Workstation.\n\n"
            "## Anomalie-Daten\n"
            f"```json\n{anomaly_json}\n```\n\n"
            "## Bitte analysiere:\n"
            "1. **Bewertung**: Ist das ein echtes Problem oder False Positive?\n"
            "2. **Risiko**: Kann das zu einem Crash fuehren?\n"
            "3. **Empfehlung**: Was soll der User tun?\n\n"
            "Antworte kurz und praegnant (max 200 Woerter)."
        )

    def _build_recommendations_prompt(self, patterns: list) -> str:
        """Build prompt for proactive recommendations."""
        patterns_json = json.dumps(patterns, indent=2, ensure_ascii=False,
                                     default=str)[:3000]
        return (
            "Basierend auf diesen gelernten Crash-Mustern der Py_DAW "
            "Audio Workstation, gib proaktive Empfehlungen.\n\n"
            "## Gelernte Muster\n"
            f"```json\n{patterns_json}\n```\n\n"
            "## Bitte empfehle:\n"
            "1. Welche Muster sind am kritischsten?\n"
            "2. Welche praeventiven Massnahmen sind sinnvoll?\n"
            "3. Gibt es bekannte Probleme mit den genannten Plugins/Konfigurationen?\n\n"
            "Antworte kurz und praegnant."
        )

    # ══════════════════════════════════════════════════════════════
    # Local Analysis (fallback without API key)
    # ══════════════════════════════════════════════════════════════

    def _local_analysis(self, crash_data: dict) -> str:
        """Local crash analysis without AI — pattern-based."""
        parts = ["## SENTINEL Crash-Analyse (lokal)\n"]

        crash_type = crash_data.get("crash_type", crash_data.get("type", "unknown"))
        component = crash_data.get("component", "unknown")
        message = crash_data.get("error_message", crash_data.get("message", ""))

        parts.append(f"**Crash-Typ:** `{crash_type}`")
        parts.append(f"**Komponente:** `{component}`")
        if message:
            parts.append(f"**Meldung:** {message[:300]}")

        # Type-specific suggestions
        suggestions = {
            "segfault": "Segmentation Fault — wahrscheinlich ein Plugin-Crash. "
                        "Empfehlung: Plugin in Sandbox-Modus laden oder alternatives "
                        "Plugin verwenden.",
            "exception": "Python-Exception — interner Bug. Traceback fuer "
                         "Bug-Report exportieren.",
            "echo_loop": "Echo-Loop erkannt — Collab-System hat eine Nachrichtenschleife "
                         "erzeugt. SENTINEL hat die Schleife unterbrochen. "
                         "Empfehlung: Collab-Verbindung neu aufbauen.",
            "plugin_crash": "Plugin-Worker ist gestorben. Plugin evtl. nicht "
                            "kompatibel mit der aktuellen Audio-Konfiguration. "
                            "Empfehlung: Plugin neu laden oder ersetzen.",
            "deadlock": "Thread-Deadlock erkannt. Empfehlung: DAW neu starten, "
                        "Projekt vorher speichern.",
            "oom": "Out of Memory — zu viele Samples oder Plugins geladen. "
                   "Empfehlung: Tracks einfrieren oder Projekt aufteilen.",
            "timeout": "Plugin/Thread antwortet nicht. Kann bei komplexen "
                       "Presets passieren. Empfehlung: Preset vereinfachen "
                       "oder Worker neu starten.",
        }

        suggestion = suggestions.get(crash_type, "Unbekannter Crash-Typ. "
                                                   "Projekt speichern und "
                                                   "Bug-Report erstellen.")
        parts.append(f"\n**Analyse:** {suggestion}")

        # Blackbox summary if available
        blackbox = crash_data.get("blackbox", crash_data.get("blackbox_json", {}))
        if isinstance(blackbox, str):
            try:
                blackbox = json.loads(blackbox)
            except (json.JSONDecodeError, TypeError):
                blackbox = {}

        if isinstance(blackbox, dict):
            sys_state = blackbox.get("system_state", {})
            cpu = sys_state.get("cpu_percent", 0)
            mem = sys_state.get("memory_mb", 0)
            if cpu > 0 or mem > 0:
                parts.append(f"\n**System zum Crash-Zeitpunkt:** "
                             f"CPU {cpu:.1f}%, RAM {mem:.0f} MB")
                if cpu > 80:
                    parts.append("⚠️ Hohe CPU-Last — moegliche Ueberlastung")
                if mem > 4000:
                    parts.append("⚠️ Hoher Speicherverbrauch — moeglicher Memory Leak")

        parts.append("\n*Fuer detailliertere Analyse: Anthropic API-Key "
                     "in den Einstellungen hinterlegen.*")

        return "\n".join(parts)

    def _local_anomaly_analysis(self, anomaly_data: dict) -> str:
        """Local anomaly analysis without AI."""
        atype = anomaly_data.get("anomaly_type", anomaly_data.get("type", "unknown"))
        severity = anomaly_data.get("severity", 1)
        desc = anomaly_data.get("description", "")

        analysis = f"## SENTINEL Anomalie-Analyse (lokal)\n\n"
        analysis += f"**Typ:** `{atype}` | **Schwere:** Stufe {severity}\n"
        if desc:
            analysis += f"**Beschreibung:** {desc}\n"

        risk_map = {
            "echo_loop": "HOCH — kann zu Freeze fuehren",
            "cpu_spike": "MITTEL — kann bei komplexen Plugins normal sein",
            "memory_leak": "MITTEL-HOCH — wird mit der Zeit schlimmer",
            "thread_deadlock": "HOCH — kann zu Freeze fuehren",
            "plugin_timeout": "MITTEL — Plugin evtl. ueberlastet",
            "disk_space": "NIEDRIG-MITTEL — Platz schaffen empfohlen",
        }
        risk = risk_map.get(atype, "UNBEKANNT")
        analysis += f"\n**Risiko-Bewertung:** {risk}\n"
        analysis += "\n*Fuer KI-gestuetzte Analyse: API-Key konfigurieren.*"
        return analysis
