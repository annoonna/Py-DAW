"""SQLite logo button (painted, no external assets).

v0.0.20.894 — SQLite-Badge für Status-Bar.

Design intent:
- Round badge matching Qt / Python / Rust signature badges.
- Stylized "S" with small "ql" so the badge reads as SQLite.
- Blue-teal accent colors reflecting SQLite's brand identity.
- Click shows DB stats in the status bar.
"""

from __future__ import annotations

from PyQt6.QtCore import Qt, QRectF
from PyQt6.QtGui import QColor, QFont, QPainter, QPen, QRegion, QLinearGradient
from PyQt6.QtWidgets import QToolButton


class SQLiteLogoButton(QToolButton):
    """A lightweight, self-painted SQLite-inspired badge."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("sqliteLogoButton")
        self.setAutoRaise(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setToolTip(
            "SQLite Datenbank\n\n"
            "Alle Audio-Parameter, Presets, Plugin-States,\n"
            "UI-Einstellungen und Projekt-Metadaten werden\n"
            "in SQLite gespeichert.\n\n"
            "Einstellungen sind NICHT hardcoded —\n"
            "du kannst alles in Audio → Einstellungen ändern."
        )
        self.setMinimumSize(22, 22)

        # SQLite brand: light blue/teal accent
        self._blue = QColor(70, 160, 230)      # primary accent
        self._teal = QColor(60, 200, 180)       # secondary accent
        self._body = QColor("#14191F")
        self._rim = QColor("#253040")
        self._text = QColor("#F0F6FF")

    def resizeEvent(self, event):
        super().resizeEvent(event)
        try:
            self.setMask(QRegion(self.rect(), QRegion.RegionType.Ellipse))
        except Exception:
            pass

    def paintEvent(self, event):  # noqa: ARG002 - Qt signature
        p = QPainter(self)
        try:
            p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            p.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)

            d = max(1, min(self.width(), self.height()))
            inset = max(1.0, d * 0.08)
            outer = QRectF(inset, inset, d - 2.0 * inset, d - 2.0 * inset)

            # Soft dual glow — blue + teal
            blue_glow = QColor(self._blue)
            blue_glow.setAlpha(65)
            teal_glow = QColor(self._teal)
            teal_glow.setAlpha(55)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(blue_glow)
            p.drawEllipse(outer.adjusted(-d * 0.08, -d * 0.08, d * 0.03, d * 0.03))
            p.setBrush(teal_glow)
            p.drawEllipse(outer.adjusted(-d * 0.03, -d * 0.03, d * 0.08, d * 0.08))

            # Main dark body with blue-teal gradient
            grad = QLinearGradient(outer.topLeft(), outer.bottomRight())
            grad.setColorAt(0.0, QColor(18, 32, 52))
            grad.setColorAt(0.4, self._body)
            grad.setColorAt(0.7, QColor(16, 28, 38))
            grad.setColorAt(1.0, QColor(14, 34, 42))
            p.setBrush(grad)
            p.drawEllipse(outer)

            # Rim stroke
            rim_pen = QPen(self._rim)
            rim_pen.setWidthF(max(1.0, d * 0.06))
            p.setPen(rim_pen)
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawEllipse(outer.adjusted(0.5, 0.5, -0.5, -0.5))

            # Accent arcs — blue top-left, teal bottom-right
            accent_pen = QPen(QColor(self._blue.red(), self._blue.green(), self._blue.blue(), 100))
            accent_pen.setWidthF(max(1.0, d * 0.03))
            accent_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
            p.setPen(accent_pen)
            p.drawArc(outer.adjusted(d * 0.10, d * 0.10, -d * 0.10, -d * 0.10), 100 * 16, 120 * 16)
            accent_pen.setColor(QColor(self._teal.red(), self._teal.green(), self._teal.blue(), 110))
            p.setPen(accent_pen)
            p.drawArc(outer.adjusted(d * 0.10, d * 0.10, -d * 0.10, -d * 0.10), -60 * 16, 120 * 16)

            # Main letter "S"
            text_rect = outer.adjusted(d * 0.02, -d * 0.02, -d * 0.06, -d * 0.06)
            font_s = QFont()
            font_s.setBold(True)
            font_s.setPointSizeF(max(7.0, outer.height() * 0.42))
            p.setFont(font_s)
            p.setPen(QPen(self._text))
            p.drawText(text_rect, Qt.AlignmentFlag.AlignCenter, "S")

            # Small "ql" subscript in lower-right
            font_sub = QFont()
            font_sub.setBold(True)
            font_sub.setPointSizeF(max(4.0, outer.height() * 0.16))
            p.setFont(font_sub)
            sub_rect = QRectF(
                outer.center().x() + outer.width() * 0.04,
                outer.center().y() + outer.height() * 0.06,
                outer.width() * 0.30,
                outer.height() * 0.20,
            )
            p.drawText(sub_rect, Qt.AlignmentFlag.AlignCenter, "ql")
        finally:
            p.end()
