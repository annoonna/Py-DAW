"""Project Tabs Mixin — Extracted from main_window.py (v0.0.20.816).

Contains all multi-project tab handlers: switch, new, open, close,
save, save-as, browser-open, browser-import.

Self-contained: only references self.services, self.transport,
self._set_status, self._update_window_title — all provided by MainWindow.

~268 lines extracted.
"""

from __future__ import annotations

import logging

log = logging.getLogger(__name__)


class ProjectTabsMixin:
    """Multi-project tab handlers — mixed into MainWindow."""

    def _on_project_tab_switch(self, idx: int) -> None:
        """Switch to a different project tab.

        Key behavior: Only the active project uses the audio engine.
        When switching:
        1. Stop transport on old project
        2. Save old project state into its tab
        3. Swap ProjectService.ctx to the new tab's context
        4. Rebind audio engine to new project
        5. Refresh all UI panels
        """
        ts = getattr(self, '_project_tab_service', None)
        if not ts:
            return

        old_tab = ts.active_tab
        if old_tab:
            # Save current state into old tab
            old_tab.ctx = self.services.project.ctx
            old_tab.undo_stack = self.services.project.undo_stack

        # Stop transport before switch
        try:
            self.services.transport.stop()
        except Exception:
            pass

        # Switch
        ts.switch_to(idx)
        new_tab = ts.active_tab
        if not new_tab:
            return

        # Swap project context
        self.services.project.ctx = new_tab.ctx
        self.services.project.undo_stack = new_tab.undo_stack
        self.services.project._selected_track_id = ""

        # CS2-F: bootstrap persisted project-header fields into the legacy
        # transport through the Slice-0 adapter before the engine/UI refresh.
        try:
            self.services.project.bootstrap_slice0_core_transport(self.services.transport)
        except Exception:
            pass

        # Rebind audio engine
        try:
            self.services.audio_engine.bind_transport(
                self.services.project, self.services.transport
            )
        except Exception:
            pass

        # Refresh all UI panels
        try:
            self.services.project._emit_changed()
            self.services.project.project_opened.emit()
        except Exception:
            pass

        # Update window title
        try:
            self._update_window_title(new_tab.display_name)
        except Exception:
            pass

        self._set_status(f"Tab gewechselt: {new_tab.display_name}")

    def _on_tab_next(self) -> None:
        """Ctrl+Tab → switch to next project tab (wrapping)."""
        ts = getattr(self, '_project_tab_service', None)
        if not ts or ts.count <= 1:
            return
        nxt = (ts.active_index + 1) % ts.count
        self._on_project_tab_switch(nxt)

    def _on_tab_prev(self) -> None:
        """Ctrl+Shift+Tab → switch to previous project tab (wrapping)."""
        ts = getattr(self, '_project_tab_service', None)
        if not ts or ts.count <= 1:
            return
        prev = (ts.active_index - 1) % ts.count
        self._on_project_tab_switch(prev)

    def _on_project_tab_new(self) -> None:
        """Create a new empty project in a new tab."""
        ts = getattr(self, '_project_tab_service', None)
        if not ts:
            return

        # Save current tab state first
        old_tab = ts.active_tab
        if old_tab:
            old_tab.ctx = self.services.project.ctx
            old_tab.undo_stack = self.services.project.undo_stack

        # Create new tab
        idx = ts.add_new_project("Neues Projekt", activate=False)
        # Switch to it (this triggers the full rebind)
        self._on_project_tab_switch(idx)

    def _on_project_tab_open(self) -> None:
        """Open a project file in a new tab."""
        ts = getattr(self, '_project_tab_service', None)
        if not ts:
            return

        path, _ = QFileDialog.getOpenFileName(
            self, "Projekt in neuem Tab öffnen", "",
            "Py DAW Projekt (*.pydaw.json *.json);;Alle Dateien (*)",
        )
        if not path:
            return

        # Save current tab state first
        old_tab = ts.active_tab
        if old_tab:
            old_tab.ctx = self.services.project.ctx
            old_tab.undo_stack = self.services.project.undo_stack

        idx = ts.open_project_in_tab(Path(path), activate=False)
        if idx >= 0:
            self._on_project_tab_switch(idx)

    def _on_project_tab_close(self, idx: int) -> None:
        """Close a project tab with dirty check."""
        ts = getattr(self, '_project_tab_service', None)
        if not ts:
            return

        # Don't allow closing the last tab
        if ts.count <= 1:
            self._set_status("Letzter Tab kann nicht geschlossen werden.")
            return

        tab = ts.tab_at(idx)
        if not tab:
            return

        # Check for unsaved changes
        if tab.dirty:
            reply = QMessageBox.question(
                self, "Ungespeicherte Änderungen",
                f"Projekt '{tab.display_name}' hat ungespeicherte Änderungen.\n"
                "Trotzdem schließen?",
                QMessageBox.StandardButton.Save |
                QMessageBox.StandardButton.Discard |
                QMessageBox.StandardButton.Cancel,
            )
            if reply == QMessageBox.StandardButton.Cancel:
                return
            elif reply == QMessageBox.StandardButton.Save:
                if not ts.save_tab(idx):
                    return  # Save failed

        # If closing the active tab, switch first
        was_active = (idx == ts.active_index)
        ts.close_tab(idx)

        if was_active and ts.count > 0:
            self._on_project_tab_switch(ts.active_index)

    def _on_project_tab_save(self, idx: int) -> None:
        """Save a specific project tab."""
        ts = getattr(self, '_project_tab_service', None)
        if not ts:
            return

        tab = ts.tab_at(idx)
        if not tab:
            return

        # Sync current state if saving active tab
        if idx == ts.active_index:
            tab.ctx = self.services.project.ctx

        if tab.path:
            ts.save_tab(idx)
        else:
            self._on_project_tab_save_as(idx)

    def _on_project_tab_save_as(self, idx: int) -> None:
        """Save a project tab with file dialog."""
        ts = getattr(self, '_project_tab_service', None)
        if not ts:
            return

        tab = ts.tab_at(idx)
        if not tab:
            return

        # Sync current state if saving active tab
        if idx == ts.active_index:
            tab.ctx = self.services.project.ctx

        path, _ = QFileDialog.getSaveFileName(
            self, "Projekt speichern", "",
            "Py DAW Projekt (*.pydaw.json);;JSON (*.json);;Alle Dateien (*)",
        )
        if path:
            ts.save_tab(idx, Path(path))

    def _on_project_browser_open(self, path_str: str) -> None:
        """Open a project from the project browser in a new tab."""
        ts = getattr(self, '_project_tab_service', None)
        if not ts:
            return

        # Save current tab state
        old_tab = ts.active_tab
        if old_tab:
            old_tab.ctx = self.services.project.ctx
            old_tab.undo_stack = self.services.project.undo_stack

        idx = ts.open_project_in_tab(Path(path_str), activate=False)
        if idx >= 0:
            self._on_project_tab_switch(idx)

    def _on_project_browser_import(self, path_str: str, track_ids: list) -> None:
        """Import tracks from a browsed project into the active project.

        Opens the source project temporarily, copies tracks, then closes it.
        Full State Transfer: device chains, automations, routing preserved.
        """
        ts = getattr(self, '_project_tab_service', None)
        if not ts:
            return

        # Open source project temporarily (don't activate)
        src_idx = ts.open_project_in_tab(Path(path_str), activate=False)
        if src_idx < 0:
            return

        tgt_idx = ts.active_index
        new_ids = ts.copy_tracks_between_tabs(
            src_idx, tgt_idx, track_ids,
            include_clips=True,
            include_device_chains=True,
        )

        # Close the temporary source tab
        ts.close_tab(src_idx)

        if new_ids:
            # Refresh UI
            self.services.project._emit_changed()
            self._set_status(f"{len(new_ids)} Track(s) importiert.")

