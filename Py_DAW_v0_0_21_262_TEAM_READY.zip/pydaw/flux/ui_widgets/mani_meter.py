"""
pydaw.flux.ui_widgets.mani_meter — Frigg.ManiMeter (Phase W-2)
================================================================

**Eingebaut in v0.0.21.200** als mondförmige Pegel-/Wert-Anzeige.
Spezifikation: ``PROJECT_DOCS/FLUX_GROVE_MANIFEST.md`` Sektion „FLUX
Sigil — eigene Widget-Designs", W-2 Punkt 3.

Design (aus dem Manifest)
-------------------------

* Kreisrunder Mond als Hintergrund-Visual
* Wert 0..1 → Mond-Phase: 0 = Neumond (vollständig dunkel), 0.5 =
  Halbmond, 1 = Vollmond (vollständig hell)
* Idle: extrem langsamer Lunar-Phase-Cycle als feiner Schimmer-Effekt
  über die Mondscheibe (überlagert die Hauptdarstellung)
* Bei Wert-Änderung subtiler Echo-Ring-Effekt um den Mond
* Klick → Wert auf Klickposition setzen (Mausposition vertikal)
* Drag → kontinuierlich
* Mausrad → Wert ändern (1% pro Klick)

Anwendung
---------

Geeignet für **kontinuierliche Wert-Visualisierungen** mit organischem
Look:
* Mix-Regler (dry vs wet als Mond-Phase)
* Gain-Visualisierung
* Modulation-Tiefe-Anzeige

Nichts-Kaputt-Garantie
----------------------

* Identischer Signal-Vertrag wie ``AnimatedKnob`` / ``SliderWidget``:
  ``value_changed(float)``, ``set_value(v, *, emit_signal=...)``,
  ``_minimum``/``_maximum``/``_default``.
* Reine Python-Schicht, defensiv gegen fehlendes Qt.
* Animation läuft über die zentrale ``AnimationEngine``.
* ``closeEvent()`` räumt Subscriptions auf (v.198 Cleanup-Pakt).
"""

from __future__ import annotations

import logging
import math
from typing import Optional

logger = logging.getLogger(__name__)


try:
    from PyQt6.QtCore import (
        Qt, QPointF, QRectF, QSize, pyqtSignal,
    )
    from PyQt6.QtGui import (
        QColor, QPainter, QPen, QBrush, QFont, QRadialGradient,
        QPainterPath,
    )
    from PyQt6.QtWidgets import QWidget, QSizePolicy
    _QT_AVAILABLE = True
except ImportError:
    _QT_AVAILABLE = False


from pydaw.flux.animation_engine import (
    get_animation_engine, ANIM_LUNAR_PHASE, ANIM_ECHO_RING,
)


def _clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


if _QT_AVAILABLE:

    class ManiMeterWidget(QWidget):  # type: ignore[misc]
        """Mond-Phasen-Anzeige für FLUX-Patches.

        Signal-Vertrag (kompatibel zu Knob/Slider):
            ``value_changed(float)`` — feuert beim User-Eingriff
            ``set_value(v, *, emit_signal=True)`` — programmatisch
            ``_minimum``, ``_maximum``, ``_default``
        """

        DEFAULT_W = 64
        DEFAULT_H = 64

        # Style: dunkler Nachthimmel + heller Mond
        SKY_DARK   = QColor(14, 18, 30)
        SKY_LIGHT  = QColor(28, 38, 56)
        MOON_BRIGHT = QColor(238, 232, 210)         # Mond-elfenbein
        MOON_DARK   = QColor(50, 56, 68)             # Mond-Schatten
        MOON_GLOW   = QColor(238, 232, 210, 100)     # Glow-Aura
        ECHO_COLOR  = QColor(125, 215, 230, 140)     # Norse-Cyan-Ring

        value_changed = pyqtSignal(float)

        def __init__(
            self,
            value: float = 0.5,
            minimum: float = 0.0,
            maximum: float = 1.0,
            default: float = 0.5,
            module_id: Optional[str] = None,
            parent=None,
        ):
            super().__init__(parent)
            self._minimum = float(minimum)
            self._maximum = float(maximum)
            self._default = _clamp(float(default), self._minimum, self._maximum)
            self._value = _clamp(float(value), self._minimum, self._maximum)
            self._module_id = str(module_id or "mani_unbound")

            # Animation-State
            self._lunar_phase: float = 0.0     # 0..1, langsamer Idle-Cycle
            self._echo_phase: float = 1.0      # 1.0 = inaktiv
            # Drag-State
            self._dragging: bool = False

            self.setMinimumSize(self.DEFAULT_W, self.DEFAULT_H)
            self.setSizePolicy(QSizePolicy.Policy.Preferred,
                               QSizePolicy.Policy.Preferred)
            self.setCursor(Qt.CursorShape.PointingHandCursor)

            self._subscribe_idle_loop()

        # ─── Animation-Subscribes ─────────────────────────────────

        def _subscribe_idle_loop(self) -> None:
            try:
                eng = get_animation_engine()
                eng.subscribe(
                    sub_id=f"{self._module_id}::lunar",
                    anim_name=ANIM_LUNAR_PHASE,
                    on_frame=self._on_lunar_tick,
                )
            except Exception as e:
                logger.debug("[ManiMeter] lunar subscribe failed: %s", e)

        def _on_lunar_tick(self, phase: float, frame: int) -> None:
            self._lunar_phase = float(phase)
            try:
                self.update()
            except RuntimeError:
                raise

        def _trigger_echo_ring(self) -> None:
            try:
                eng = get_animation_engine()
                eng.subscribe(
                    sub_id=f"{self._module_id}::echo",
                    anim_name=ANIM_ECHO_RING,
                    on_frame=self._on_echo_tick,
                )
            except Exception as e:
                logger.debug("[ManiMeter] echo subscribe failed: %s", e)

        def _on_echo_tick(self, phase: float, frame: int) -> None:
            self._echo_phase = float(phase)
            try:
                self.update()
            except RuntimeError:
                raise

        # ─── Signal-Vertrag ────────────────────────────────────────

        @property
        def minimum(self) -> float:
            return self._minimum

        @property
        def maximum(self) -> float:
            return self._maximum

        def set_value(self, value: float, *, emit_signal: bool = True) -> None:
            new_v = _clamp(float(value), self._minimum, self._maximum)
            if abs(new_v - self._value) < 1e-12:
                return
            self._value = new_v
            self._trigger_echo_ring()
            self.update()
            if emit_signal:
                self.value_changed.emit(self._value)

        def reset_to_default(self) -> None:
            self.set_value(self._default, emit_signal=True)

        def value(self) -> float:
            return self._value

        def _normalized(self) -> float:
            r = self._maximum - self._minimum
            if r <= 0:
                return 0.0
            return _clamp((self._value - self._minimum) / r, 0.0, 1.0)

        # ─── Painting ──────────────────────────────────────────────

        def sizeHint(self) -> QSize:
            return QSize(self.DEFAULT_W, self.DEFAULT_H)

        def paintEvent(self, event) -> None:
            p = QPainter(self)
            p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            r = self.rect().adjusted(2, 2, -2, -2)

            # Nachthimmel-Hintergrund
            sky = QRadialGradient(
                QPointF(r.center().x(), r.center().y()),
                r.width() * 0.7,
            )
            sky.setColorAt(0.0, self.SKY_LIGHT)
            sky.setColorAt(1.0, self.SKY_DARK)
            p.setBrush(QBrush(sky))
            p.setPen(QPen(QColor(0, 0, 0, 100), 1))
            p.drawRoundedRect(QRectF(r), 6, 6)

            # Mond-Bereich
            cx = r.center().x()
            cy = r.center().y()
            moon_radius = min(r.width(), r.height()) * 0.36

            # Mond-Glow-Aura (sanft, immer da, mit Lunar-Phase-Modulation)
            glow_intensity = 0.5 + 0.3 * math.sin(self._lunar_phase * 2 * math.pi)
            glow_alpha = int(80 * glow_intensity * self._normalized())
            if glow_alpha > 0:
                aura = QRadialGradient(
                    QPointF(cx, cy), moon_radius * 1.8,
                )
                col = QColor(self.MOON_GLOW)
                col.setAlpha(glow_alpha)
                aura.setColorAt(0.0, col)
                aura.setColorAt(1.0, QColor(0, 0, 0, 0))
                p.setBrush(QBrush(aura))
                p.setPen(Qt.PenStyle.NoPen)
                p.drawEllipse(
                    QPointF(cx, cy),
                    moon_radius * 1.8, moon_radius * 1.8,
                )

            # Mond-Scheibe: voll dunkel als Basis
            p.setBrush(QBrush(self.MOON_DARK))
            p.setPen(QPen(QColor(28, 32, 42), 1))
            p.drawEllipse(QPointF(cx, cy), moon_radius, moon_radius)

            # Helle Phase: ein Klipp-Pfad, der je nach Wert mehr/weniger
            # vom Mond als hell zeigt. 0 = ganz dunkel, 0.5 = halbmond
            # (rechte Hälfte hell), 1.0 = Vollmond.
            v = self._normalized()
            if v > 0.001:
                bright_path = self._compute_bright_phase_path(
                    cx, cy, moon_radius, v
                )
                p.setBrush(QBrush(self.MOON_BRIGHT))
                p.setPen(Qt.PenStyle.NoPen)
                p.drawPath(bright_path)

            # Echo-Ring beim Wert-Wechsel
            if self._echo_phase < 1.0:
                ring_r = moon_radius * (1.0 + 0.8 * self._echo_phase)
                ring_alpha = int(140 * (1.0 - self._echo_phase))
                col = QColor(self.ECHO_COLOR)
                col.setAlpha(ring_alpha)
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.setPen(QPen(col, 2))
                p.drawEllipse(QPointF(cx, cy), ring_r, ring_r)

            # Mini-Sternchen am Rand für die Phase-Animation (subtil)
            if self._lunar_phase < 0.5:
                star_alpha = int(120 * (1.0 - 2 * self._lunar_phase))
            else:
                star_alpha = int(120 * (2 * self._lunar_phase - 1))
            if star_alpha > 20:
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QBrush(QColor(238, 232, 210, star_alpha)))
                # Drei kleine Sterne an festen Positionen
                star_positions = [
                    (r.left() + r.width() * 0.18, r.top() + r.height() * 0.22),
                    (r.right() - r.width() * 0.20, r.top() + r.height() * 0.32),
                    (r.left() + r.width() * 0.85, r.bottom() - r.height() * 0.25),
                ]
                for sx, sy in star_positions:
                    p.drawEllipse(QPointF(sx, sy), 1.0, 1.0)

            p.end()

        def _compute_bright_phase_path(
            self, cx: float, cy: float, radius: float, v: float
        ) -> "QPainterPath":
            """Berechnet den helle Mond-Bereich als Path.

            v=0   → leer (Neumond, kein Pfad)
            v=0.5 → rechte Halbkugel (Halbmond, "wachsend")
            v=1.0 → kompletter Kreis (Vollmond)

            Zwischen 0..0.5: Sichel die nach links wandert (rechte Seite
            des Mondes wird mehr und mehr hell)
            Zwischen 0.5..1.0: Vollmond-Annäherung — Schatten auf der
            linken Seite verschwindet
            """
            path = QPainterPath()
            if v <= 0.0:
                return path

            # Volles Mond-Oval als Basis
            full = QPainterPath()
            full.addEllipse(QPointF(cx, cy), radius, radius)

            if v >= 1.0:
                return full

            # v in (0..1): erstellen eine Ellipse die als "Schatten-Linse"
            # wirkt; die Helle-Phase = Mond ohne diesen Schatten
            # Trick: addieren der Mond-Ellipse, subtrahieren einer
            # vertikalen Schatten-Ellipse die je nach v positioniert ist.
            shadow = QPainterPath()
            # Horizontaler Offset des Schatten-Mittelpunktes:
            # v=0   → cx + radius (Schatten ist KOMPLETT auf dem Mond, alles dunkel)
            # v=0.5 → cx (Schatten ist genau die linke Hälfte)
            # v=1.0 → cx - radius (Schatten ist links vom Mond, alles hell)
            shadow_cx = cx + radius * (1.0 - 2.0 * v)
            # Schatten-Halb-Achse horizontal: variiert mit v.
            # Bei v=0.5 ist sie 0 (perfekte Halbmond-Linie), bei v→0 oder
            # v→1 wird sie groß genug um die Helle-Sichel zu formen.
            # Math-Trick: Ellipse-Halbachse = radius * |1 - 2v|
            ellipse_a = radius * abs(1.0 - 2.0 * v)
            shadow.addEllipse(
                QPointF(shadow_cx, cy),
                max(ellipse_a, 0.5),  # mindestens 0.5 damit Path gültig
                radius,
            )

            # Helle-Phase = Mond minus Schatten — aber je nach v anders:
            # Bei v < 0.5 (wachsender Mond): rechter Teil hell, linker
            # Schatten zeigt links der Schatten-Ellipse + Schnitt mit Mond.
            # Bei v > 0.5 (abnehmender Schatten): hellere Hälfte ist
            # Mond MINUS Schatten-Ellipse die rechts ist.
            if v < 0.5:
                # Rechte Sichel: Schnitt von Mond mit "rechts der Schatten-Mitte"
                # Wir bauen eine Maske: Mond minus (linke Hälfte plus Schatten-Ellipse)
                left_half = QPainterPath()
                left_half.addRect(QRectF(
                    cx - radius - 2, cy - radius - 2,
                    radius + 2, 2 * radius + 4,
                ))
                # Helle = Mond - linke Hälfte - Schatten
                bright = full.subtracted(left_half).subtracted(shadow)
                return bright
            else:
                # Wachsende Vollmond: Mond minus Schatten (der jetzt rechts
                # vom Center ist und kleiner wird)
                # Aber: wir wollen Schatten nur LINKS sichtbar; bei v>0.5
                # ist shadow_cx links vom Center, d.h. Schatten überlappt
                # nur teilweise mit Mond auf der linken Seite.
                # Helle = Mond minus diese Schatten-Linse.
                bright = full.subtracted(shadow)
                # Außerdem: wir wollen NICHT den Bereich rechts vom Mond
                # als Schatten sehen — den braucht's aber nicht entfernen
                # weil shadow innerhalb von Mond geclippt wird.
                return bright

        # ─── User-Eingabe ─────────────────────────────────────────

        def mousePressEvent(self, event) -> None:
            if event.button() == Qt.MouseButton.LeftButton:
                self._dragging = True
                self._update_value_from_pos(event.position())
                event.accept()

        def mouseMoveEvent(self, event) -> None:
            if self._dragging:
                self._update_value_from_pos(event.position())
                event.accept()

        def mouseReleaseEvent(self, event) -> None:
            self._dragging = False
            event.accept()

        def _update_value_from_pos(self, pos) -> None:
            """Vertikale Mausposition → Wert (oben = max, unten = min)."""
            r = self.rect().adjusted(2, 2, -2, -2)
            if r.height() <= 0:
                return
            y = float(pos.y())
            t = 1.0 - _clamp((y - r.top()) / r.height(), 0.0, 1.0)
            new_v = self._minimum + t * (self._maximum - self._minimum)
            self.set_value(new_v, emit_signal=True)

        def wheelEvent(self, event) -> None:
            steps = event.angleDelta().y() / 120.0
            range_ = self._maximum - self._minimum
            mods = event.modifiers()
            if mods & Qt.KeyboardModifier.ShiftModifier:
                step = range_ * 0.001
            else:
                step = range_ * 0.01
            self.set_value(self._value + steps * step, emit_signal=True)
            event.accept()

        def mouseDoubleClickEvent(self, event) -> None:
            if event.button() == Qt.MouseButton.LeftButton:
                self.reset_to_default()
                event.accept()

        # ─── Cleanup ──────────────────────────────────────────────

        def closeEvent(self, event) -> None:  # type: ignore[override]
            try:
                eng = get_animation_engine()
                eng.unsubscribe_prefix(f"{self._module_id}::")
            except Exception:
                pass
            super().closeEvent(event)


else:
    ManiMeterWidget = None  # type: ignore[assignment,misc]


__all__ = ["ManiMeterWidget"]
