"""
pydaw.flux.patch_model
======================

Datenmodell für FLUX-Patches.  Ein Patch ist ein gerichteter Graph
aus Modulen, deren Output-Ports mit Input-Ports anderer Module
verbunden sind.

Architektur-Überblick
---------------------

    Patch
      ├── modules: list[Module]
      │   ├── id: "mod_<uuid>"
      │   ├── god: "Bragi" | "Forseti" | …    (yggdrasil.GODS)
      │   ├── kind: "SineOsc" | "Lowpass" | …  (Modul-Subtyp)
      │   ├── position: (x, y)                 (Canvas-Pixel)
      │   ├── params: {name: float}
      │   ├── inputs:  list[Port]
      │   └── outputs: list[Port]
      └── connections: list[Connection]
          ├── id: "con_<uuid>"
          ├── source: (module_id, port_name)
          └── target: (module_id, port_name)

Port-Typen
----------

Audio-Ports tragen Stereo-Buffer-Refs zur Laufzeit; CV-Ports
tragen modulierende Skalar-Signale (z.B. Filter-Cutoff von einem
LFO).  MIDI-Ports tragen Note-On/Off + CC-Streams.  Die Engine
prüft beim Verbinden ob die Port-Typen kompatibel sind:

    AUDIO ↔ AUDIO   ✅
    CV    ↔ CV      ✅
    CV    ↔ AUDIO   ✅ (CV moduliert Audio-Param)
    AUDIO ↔ CV      ⚠️  (Audio-Rate-Modulation, special case)
    MIDI  ↔ MIDI    ✅
    MIDI  ↔ AUDIO   ❌  (kein Cast, Bragi-Synth dazwischen nötig)

Persistenz
----------

`Patch.to_dict()` / `Patch.from_dict()` sind JSON-serialisierbar.
FLUX-Patches werden im Projekt unter `project.flux_patches` als
Liste gespeichert.  Pro Track kann optional `track.flux_patch_id`
ein Patch referenzieren (Track-spezifischer Synth/FX-Graph).
"""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Optional


logger = logging.getLogger(__name__)


class PortKind(str, Enum):
    """Welche Art Signal fliesst durch diesen Port."""
    AUDIO = "audio"   # 32-bit float Stereo-Buffer
    CV    = "cv"      # Control-Voltage (skalar, ggf. block-rate)
    MIDI  = "midi"    # MIDI-Events (Note, CC, Pitch, Aftertouch)
    GATE  = "gate"    # Bool-Trigger (für Envelope-Triggers)
    # v0.0.21.215 — Rune-Realm: diskrete Message-Events.
    # Eine RUNE-Message ist ein dict mit mindestens "kind" (z.B. "bang",
    # "float", "int", "list", "symbol") und ggf. "value", "ts" (sample-
    # offset im Block). Pro Block fließt eine list[dict] (oft leer).
    # Ein Output-Port mit kind=RUNE liefert KEIN np.ndarray sondern eine
    # Liste; _gather_inputs überspringt für RUNE-Ports die CV-Skalierung.
    # In Phase 1 (v.215) nur kind="bang" implementiert; Float/Int/Symbol/
    # List kommen mit Ullr (Math/Expr) und Norns (Time) in v.216+.
    RUNE  = "rune"


class PortDirection(str, Enum):
    INPUT  = "input"
    OUTPUT = "output"


def _new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:10]}"


@dataclass
class Port:
    """Ein Anschluss-Punkt eines Moduls."""
    name: str                       # z.B. "freq", "audio_in_l", "trig"
    kind: PortKind                  # AUDIO/CV/MIDI/GATE
    direction: PortDirection        # INPUT/OUTPUT
    label: str = ""                 # human-friendly, default = name.title()
    default: float = 0.0            # CV-Default wenn nicht verbunden
    minimum: float = -1.0           # CV-Min für Slider/Knob
    maximum: float = 1.0            # CV-Max
    unit: str = ""                  # "Hz", "dB", "ms"

    def __post_init__(self) -> None:
        if not self.label:
            self.label = self.name.replace("_", " ").title()

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "kind": self.kind.value,
            "direction": self.direction.value,
            "label": self.label,
            "default": self.default,
            "minimum": self.minimum,
            "maximum": self.maximum,
            "unit": self.unit,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Port":
        return cls(
            name=str(d["name"]),
            kind=PortKind(str(d.get("kind", "audio"))),
            direction=PortDirection(str(d.get("direction", "input"))),
            label=str(d.get("label", "")),
            default=float(d.get("default", 0.0)),
            minimum=float(d.get("minimum", -1.0)),
            maximum=float(d.get("maximum", 1.0)),
            unit=str(d.get("unit", "")),
        )


@dataclass
class Module:
    """Ein FLUX-Modul auf dem Canvas.

    `god` ist der Name aus yggdrasil.GODS (z.B. "Bragi"); `kind`
    der Subtyp innerhalb dieser Familie (z.B. "SineOsc").  Die
    Kombination `(god, kind)` identifiziert eindeutig die DSP-
    Implementation in der Rust-Engine.
    """
    id: str = field(default_factory=lambda: _new_id("mod"))
    god: str = "Bragi"
    kind: str = "SineOsc"
    label: str = ""                    # User-spezifischer Anzeige-Name
    position: tuple[float, float] = (0.0, 0.0)
    # v0.0.21.229 — params war vorher dict[str, float], aber seit
    # v.227 (Ullr.Expr.expr) und v.228 (Hermod.OscPath.path_pattern,
    # OscSend.host/default_path) gibt es String-Params. Type-Hint
    # auf Any erweitert; from_dict wurde angepasst um non-numeric
    # Werte unverändert durchzulassen.
    params: dict[str, Any] = field(default_factory=dict)
    inputs:  list[Port] = field(default_factory=list)
    outputs: list[Port] = field(default_factory=list)
    # Optional: Modul-spezifische Daten als JSON-Blob (z.B. Wavetable-
    # Indizes, Sample-Pfade).  Bewusst flexibel — die Rust-Seite
    # validiert pro Modul-Typ.
    extra: dict[str, Any] = field(default_factory=dict)
    # ─── v0.0.21.229 — Living Patterns Foundation ──────────────────
    # Diese Felder bilden das Backend für die Living-Patterns-UI
    # (UI kommt v.230-231). In v.229 werden sie nur vom Renderer
    # geschrieben/gelesen, das Patch-Modell trägt sie persistent.
    #
    # ``dynamic_outputs``: True für Module die "Pattern-Discovery"
    # können (Vör.RouteV, Vör.SelectV, Vör.Route, Vör.Select).
    # Der Renderer protokolliert dann eingehende RUNE-Werte in
    # ``observed_tags`` pro input-port.
    #
    # ``observed_tags``: dict[input_port_name, list[unique_values]]
    # — vom Renderer befüllt. Cap bei 32 pro Port (im Renderer);
    # älteste Werte werden verdrängt. Persistiert nicht in JSON
    # (wird von_dict() nicht serialisiert), nur Frozen-Tags
    # bleiben erhalten — siehe ``frozen_tags``.
    #
    # ``frozen``: User hat den Tag-Discovery-Mode beendet → keine
    # neuen Werte werden mehr getrackt; ``frozen_tags`` ist
    # die finale Snapshot-Liste die ins JSON wandert.
    #
    # ``frozen_tags``: dict[port_name, list[value]] — wenn frozen
    # gesetzt wurde, werden hier die Tags die der User behalten
    # wollte gespeichert. Wird in to_dict()/from_dict() serialisiert.
    dynamic_outputs: bool = False
    observed_tags: dict[str, list[Any]] = field(default_factory=dict)
    frozen: bool = False
    frozen_tags: dict[str, list[Any]] = field(default_factory=dict)
    # ─── v0.0.21.238 — Living Patterns Histogramm ─────────────────
    # ``observed_counts``: dict[port_name, dict[tag_repr, count]]
    # — vom Renderer parallel zu observed_tags befüllt. Jeder Tag
    # bekommt einen Counter; Counter wird inkrementiert bei jedem
    # Sichten des Tags. Persistiert NICHT (live-only, wie observed_tags).
    # UI zeigt das als Top-N Histogramm im Properties-Panel.
    # Schlüssel ist immer ``repr(tag)`` für stabile dict-Keys
    # (numerische Tags werden in observed_tags als float gespeichert,
    # aber dict-Keys müssen hashable+stabil sein → repr ist robust).
    observed_counts: dict[str, dict[str, int]] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.label:
            self.label = f"{self.god}.{self.kind}"

    @property
    def display_name(self) -> str:
        """Was im Canvas-Header steht."""
        return self.label or f"{self.god}.{self.kind}"

    def is_ui_widget(self) -> bool:
        """v0.0.21.195: Ist dieses Modul ein UI-Control-Widget?

        UI-Widgets (god='Frigg': Knob, Slider, Toggle, Bang, NumberBox,
        Comment) leben rein in Python — sie produzieren CV-Werte die
        durch eine Bridge in Param-Updates der verbundenen DSP-Module
        übersetzt werden. Sie werden NICHT an die Rust-Engine geschickt.

        Lookup geht über `yggdrasil.GODS[god].is_ui_widget`. Defensiv
        gegen unbekannte Götter — gibt False zurück (Sicherheits-Default).
        """
        # Lokaler Import vermeidet Zyklus (yggdrasil importiert nichts
        # aus patch_model)
        try:
            from pydaw.flux.yggdrasil import GODS
        except Exception:
            return False
        desc = GODS.get((self.god or "").strip().capitalize())
        return bool(desc and desc.is_ui_widget)

    def get_port(self, name: str, direction: PortDirection) -> Optional[Port]:
        ports = self.inputs if direction == PortDirection.INPUT else self.outputs
        for p in ports:
            if p.name == name:
                return p
        return None

    def to_dict(self) -> dict[str, Any]:
        d = {
            "id": self.id,
            "god": self.god,
            "kind": self.kind,
            "label": self.label,
            "position": list(self.position),
            "params": dict(self.params),
            "inputs":  [p.to_dict() for p in self.inputs],
            "outputs": [p.to_dict() for p in self.outputs],
            "extra": dict(self.extra),
        }
        # v0.0.21.229 — Living Patterns: frozen-state + frozen_tags
        # persistieren. observed_tags NICHT (das ist Live-Tracking,
        # gehört nicht ins JSON).
        # v0.0.21.230 — dynamic_outputs WIRD jetzt persistiert. Vorher
        # wurde es nur vom Modul-Factory-Code gesetzt und beim Load
        # impliziert; das funktioniert für Vör.Route/RouteV/Select/SelectV
        # weil deren Factory `dynamic_outputs=True` setzt — aber nach
        # `from_dict` wäre der Wert verloren (Module() Default = False).
        # Ohne diesen Flag würden Promote/Demote nach JSON-Roundtrip
        # blockiert. Fix: serialisieren WENN True.
        if self.dynamic_outputs:
            d["dynamic_outputs"] = True
        if self.frozen:
            d["frozen"] = True
        if self.frozen_tags:
            d["frozen_tags"] = {
                k: list(v) for k, v in self.frozen_tags.items()
            }
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Module":
        pos = d.get("position", [0, 0])
        # v0.0.21.229 — params kann String-Werte enthalten (Ullr.Expr,
        # Hermod.Osc*). Vorher: float(v) hätte ValueError geworfen.
        # Neu: numerische Werte zu float konvertieren, Strings durch-
        # lassen, andere Typen durch JSON-natürliche Konvertierung.
        raw_params = d.get("params") or {}
        clean_params: dict[str, Any] = {}
        for k, v in raw_params.items():
            if isinstance(v, bool):
                clean_params[k] = v  # bool VOR int weil bool isinstance int
            elif isinstance(v, (int, float)):
                clean_params[k] = float(v)
            elif isinstance(v, str):
                clean_params[k] = v
            else:
                # list/dict/None → unverändert übernehmen
                clean_params[k] = v
        m = cls(
            id=str(d.get("id") or _new_id("mod")),
            god=str(d.get("god", "Bragi")),
            kind=str(d.get("kind", "SineOsc")),
            label=str(d.get("label", "")),
            position=(float(pos[0]), float(pos[1])),
            params=clean_params,
            inputs=[Port.from_dict(p) for p in (d.get("inputs") or [])],
            outputs=[Port.from_dict(p) for p in (d.get("outputs") or [])],
            extra=dict(d.get("extra") or {}),
        )
        # v0.0.21.231 — Defensiv-Clamp für Loki.LFO* phase-Params.
        # Vor v.231 war ``phase`` ein dead-code-Param ohne Port — die
        # Properties-Panel-Spinbox bekam dadurch ±1e6 Range, User
        # konnten Werte wie 370000 reindrehen. Beim Load alte JSON-
        # Patches automatisch clampen damit der neue Initial-Offset-
        # Pfad sinnvoll arbeitet (Werte > 1.0 würden zu phase=0
        # via mod 1.0, das ist visually ein „Reset".)
        if (m.god == "Loki"
                and m.kind in ("LFOSine", "LFOTriangle", "LFOSquare", "LFOSampleHold")
                and "phase" in m.params):
            try:
                p = float(m.params["phase"])
                if not (-2.0 <= p <= 2.0):
                    # Out-of-range → wir nehmen mod 1.0 was im allgemeinen
                    # 0 ergibt für Riesenwerte
                    m.params["phase"] = p % 1.0
                elif p < 0:
                    m.params["phase"] = (p % 1.0)
            except (TypeError, ValueError):
                m.params["phase"] = 0.0
        # v0.0.21.229 — Living Patterns frozen-state restoren
        # v0.0.21.230 — dynamic_outputs ebenfalls restoren (siehe to_dict
        # Doku oben). Falls der Patch von einer alten v.229-ZIP kommt
        # WO der Flag noch nicht serialisiert wurde, ist er beim Load
        # False — die Factory-Module bauen ihn wieder auf, aber bestehende
        # promoted Patterns wären unbenutzbar (weil promote_tag mit False
        # früh aussteigt). Defensive Backfill: wenn frozen_tags["rune_in"]
        # nicht-leer ist, setzen wir dynamic_outputs auf True (es muss
        # zur Erstellungszeit True gewesen sein, sonst hätte der Renderer
        # nichts schreiben können).
        if d.get("dynamic_outputs"):
            m.dynamic_outputs = True
        if d.get("frozen"):
            m.frozen = True
        ft = d.get("frozen_tags") or {}
        if isinstance(ft, dict):
            m.frozen_tags = {
                k: list(v) for k, v in ft.items() if isinstance(v, list)
            }
        # Backfill für alte v.229-Patches
        if (m.frozen_tags.get("rune_in")
                and not m.dynamic_outputs):
            m.dynamic_outputs = True
        return m


@dataclass
class Connection:
    """Ein gerichteter Kabel-Eintrag zwischen zwei Modul-Ports."""
    id: str = field(default_factory=lambda: _new_id("con"))
    source_module: str = ""
    source_port: str = ""
    target_module: str = ""
    target_port: str = ""
    # Optional: Skalierungs-/Offset-Faktoren für CV-Verbindungen.
    # 1.0 / 0.0 = pass-through (Default).
    scale: float = 1.0
    offset: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Connection":
        return cls(
            id=str(d.get("id") or _new_id("con")),
            source_module=str(d.get("source_module", "")),
            source_port=str(d.get("source_port", "")),
            target_module=str(d.get("target_module", "")),
            target_port=str(d.get("target_port", "")),
            scale=float(d.get("scale", 1.0)),
            offset=float(d.get("offset", 0.0)),
        )


@dataclass
class Patch:
    """Ein vollständiger FLUX-Graph: Module + Verbindungen + Meta."""
    id: str = field(default_factory=lambda: _new_id("patch"))
    name: str = "Untitled Patch"
    modules: list[Module] = field(default_factory=list)
    connections: list[Connection] = field(default_factory=list)
    # Canvas-View-State (Zoom, Pan) — wird mit-serialisiert
    view_zoom: float = 1.0
    view_offset: tuple[float, float] = (0.0, 0.0)
    # Metadata
    author: str = ""
    description: str = ""
    bpm_locked: bool = True   # Patch übernimmt Projekt-BPM für Tempo-Sync

    # ─── Mutationen ───────────────────────────────────────────

    def add_module(self, module: Module) -> Module:
        self.modules.append(module)
        return module

    def remove_module(self, module_id: str) -> bool:
        before = len(self.modules)
        self.modules = [m for m in self.modules if m.id != module_id]
        # Cascade: alle Verbindungen die diesen Modul anfassen entfernen
        self.connections = [
            c for c in self.connections
            if c.source_module != module_id and c.target_module != module_id
        ]
        return len(self.modules) < before

    def get_module(self, module_id: str) -> Optional[Module]:
        for m in self.modules:
            if m.id == module_id:
                return m
        return None

    def add_connection(self, connection: Connection) -> Optional[Connection]:
        """Fügt eine Verbindung hinzu, falls Port-Kinds kompatibel.

        Gibt None zurück wenn die Verbindung ungültig ist
        (z.B. AUDIO → MIDI ohne Konverter).
        """
        if not self._validate_connection(connection):
            return None
        # Optional: Existing Connection mit gleichem Target-Port ersetzen
        # (jeder Input darf nur eine Quelle haben).  Outputs dürfen
        # mehrfach verbunden sein (Fan-Out).
        self.connections = [
            c for c in self.connections
            if not (c.target_module == connection.target_module
                    and c.target_port == connection.target_port)
        ]
        self.connections.append(connection)
        return connection

    def remove_connection(self, connection_id: str) -> bool:
        before = len(self.connections)
        self.connections = [c for c in self.connections if c.id != connection_id]
        return len(self.connections) < before

    def _validate_connection(self, c: Connection) -> bool:
        src = self.get_module(c.source_module)
        tgt = self.get_module(c.target_module)
        if src is None or tgt is None:
            logger.warning("[FLUX] connection refers to missing module")
            return False
        if c.source_module == c.target_module:
            # No self-loops at the model level.  Feedback-Loops müssen
            # explizit über ein Mimir-Buffer-Modul realisiert werden.
            logger.info("[FLUX] self-loop rejected — use a Mimir delay")
            return False
        src_port = src.get_port(c.source_port, PortDirection.OUTPUT)
        tgt_port = tgt.get_port(c.target_port, PortDirection.INPUT)
        if src_port is None or tgt_port is None:
            logger.warning("[FLUX] connection port not found")
            return False
        # v0.0.21.219 — PERMISSIVE CONNECTIONS (Anno-Direktive):
        # „alle module ... müssen alle untereinander kommunizieren egal
        # welche ein- und ausgänge die farben haben". JEDE Port-Kind-
        # Kombination ist verbindbar; Type-Mismatch wird in
        # `audio_preview._gather_inputs` defensiv aufgelöst:
        #   * RUNE → Stream/CV/GATE: Bang-zu-Pulse-Bridge (≥1 Message →
        #     1.0, sonst 0.0) — der intuitive Fall „Bang triggert Gate"
        #   * Stream/CV/GATE → RUNE: leere Liste (KEIN implizites
        #     threshold-detect — das wäre Ratatosk.StreamToRune und
        #     braucht User-konfigurierte Schwelle)
        #   * MIDI ↔ andere: defensive Defaults, kein Crash
        # Echte Konvertierungen mit Parametern (smoothing, threshold,
        # MIDI-Decode, Mtof/Ftom) kommen mit der Ratatosk-Familie in
        # v.225+ als explizite Bridge-Module.
        if src_port.kind != tgt_port.kind:
            logger.info(
                "[FLUX] cross-realm connection accepted: %s.%s (%s) → %s.%s (%s)",
                src.label, src_port.name, src_port.kind.value,
                tgt.label, tgt_port.name, tgt_port.kind.value,
            )
        return True

    # ─── Persistenz ───────────────────────────────────────────

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "modules": [m.to_dict() for m in self.modules],
            "connections": [c.to_dict() for c in self.connections],
            "view_zoom": self.view_zoom,
            "view_offset": list(self.view_offset),
            "author": self.author,
            "description": self.description,
            "bpm_locked": self.bpm_locked,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Patch":
        vo = d.get("view_offset", [0, 0])
        p = cls(
            id=str(d.get("id") or _new_id("patch")),
            name=str(d.get("name", "Untitled Patch")),
            modules=[Module.from_dict(m) for m in (d.get("modules") or [])],
            connections=[Connection.from_dict(c) for c in (d.get("connections") or [])],
            view_zoom=float(d.get("view_zoom", 1.0)),
            view_offset=(float(vo[0]), float(vo[1])),
            author=str(d.get("author", "")),
            description=str(d.get("description", "")),
            bpm_locked=bool(d.get("bpm_locked", True)),
        )
        # Drop invalid connections (z.B. Port-Schema-Drift bei alten Patches)
        p.connections = [c for c in p.connections if p._validate_connection(c)]
        return p

    # ─── Diagnose ───────────────────────────────────────────

    def stats(self) -> dict[str, int]:
        return {
            "modules": len(self.modules),
            "connections": len(self.connections),
            "audio_connections": sum(
                1 for c in self.connections
                if (m := self.get_module(c.source_module)) and
                   (p := m.get_port(c.source_port, PortDirection.OUTPUT)) and
                   p.kind == PortKind.AUDIO
            ),
        }


__all__ = [
    "PortKind", "PortDirection", "Port",
    "Module", "Connection", "Patch",
]
