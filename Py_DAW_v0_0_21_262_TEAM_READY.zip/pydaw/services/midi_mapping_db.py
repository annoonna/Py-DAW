"""midi_mapping_db.py — SQLite-backed MIDI Mappings + Controller Profiles.

v0.0.20.890 — Phase 8 der SQLite Migration Roadmap.

Stores MIDI CC mappings and hardware controller profiles in SQLite.
Old system (project.midi_mappings list + hardcoded profiles) remains
fully functional as fallback.

Two tables:
- midi_mappings: CC→parameter assignments (per-project or global)
- controller_profiles: Hardware controller definitions (pads/faders/buttons)

Usage:
    from pydaw.services.midi_mapping_db import MidiMappingDB
    db = MidiMappingDB.get()
    db.ensure_loaded()

    # Mappings
    db.add_mapping(cc=74, param="filter_cutoff", plugin_id="chrono.aeterna",
                   track_id="track_1", channel=0)
    mappings = db.get_mappings_for_track("track_1")
    mapping = db.get_mapping_for_cc(74, channel=0)

    # Profiles
    profiles = db.get_all_profiles()
    nano = db.get_profile("nanoKONTROL2")
    db.set_active_profile("nanoKONTROL2")
"""

import json
import sqlite3
import logging
from pathlib import Path
from typing import Dict, List, Optional

log = logging.getLogger(__name__)


class MidiMappingDB:
    """SQLite-backed MIDI mapping and controller profile store.

    Singleton. RAM-cached for fast CC→param lookups during playback.
    """

    _instance: Optional["MidiMappingDB"] = None

    @classmethod
    def get(cls) -> "MidiMappingDB":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._db_path = Path.home() / ".config" / "ChronoScaleStudio" / "pydaw.db"
        # Mappings cache
        self._mappings: List[dict] = []
        self._by_cc: Dict[int, List[dict]] = {}  # cc_number → [mappings]
        # Profiles cache
        self._profiles: Dict[str, dict] = {}      # name → profile
        self._active_profile: Optional[str] = None
        self._loaded = False

    def ensure_loaded(self) -> None:
        """Create tables, seed factory profiles, load into RAM. Idempotent."""
        if self._loaded:
            return
        try:
            self._init_db()
            self._load_to_ram()
            self._loaded = True
            log.info("[MidiMappingDB] Loaded %d mappings, %d profiles",
                     len(self._mappings), len(self._profiles))
        except Exception as e:
            log.warning("[MidiMappingDB] Failed to load: %s", e)

    # ── Mapping API ─────────────────────────────────────────────

    def get_all_mappings(self, project_id: Optional[str] = None) -> List[dict]:
        """Get all mappings, optionally filtered by project."""
        self.ensure_loaded()
        if project_id is None:
            return list(self._mappings)
        return [m for m in self._mappings
                if m.get("project_id") == project_id or m.get("project_id") is None]

    def get_mapping_for_cc(self, cc: int, channel: int = -1) -> List[dict]:
        """Get mappings for a specific CC number."""
        self.ensure_loaded()
        results = self._by_cc.get(cc, [])
        if channel >= 0:
            results = [m for m in results
                       if m.get("channel", -1) == channel or m.get("channel", -1) == -1]
        return results

    def get_mappings_for_track(self, track_id: str) -> List[dict]:
        """Get all mappings targeting a specific track."""
        self.ensure_loaded()
        return [m for m in self._mappings if m.get("target_track_id") == track_id]

    def get_mapping_for_param(self, track_id: str, param: str) -> Optional[dict]:
        """Get the mapping for a specific parameter on a track."""
        self.ensure_loaded()
        for m in self._mappings:
            if m.get("target_track_id") == track_id and m.get("target_param") == param:
                return m
        return None

    def add_mapping(self, cc: int, param: str, **kwargs) -> bool:
        """Add a MIDI CC mapping."""
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.execute(
                    """INSERT INTO midi_mappings
                       (project_id, cc_number, channel, source_port,
                        target_track_id, target_param, target_plugin_id,
                        min_value, max_value, curve)
                       VALUES (?,?,?,?,?,?,?,?,?,?)""",
                    (kwargs.get("project_id"),
                     cc,
                     kwargs.get("channel", -1),
                     kwargs.get("source_port", ""),
                     kwargs.get("track_id", ""),
                     param,
                     kwargs.get("plugin_id", ""),
                     kwargs.get("min_value", 0.0),
                     kwargs.get("max_value", 1.0),
                     kwargs.get("curve", "linear"))
                )
                conn.commit()
            finally:
                conn.close()
            self._loaded = False
            self.ensure_loaded()
            return True
        except Exception as e:
            log.warning("[MidiMappingDB] add_mapping failed: %s", e)
            return False

    def remove_mapping(self, mapping_id: int) -> None:
        """Remove a mapping by its database ID."""
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.execute("DELETE FROM midi_mappings WHERE id = ?", (mapping_id,))
                conn.commit()
            finally:
                conn.close()
            self._loaded = False
            self.ensure_loaded()
        except Exception:
            pass

    def remove_mappings_for_param(self, track_id: str, param: str) -> None:
        """Remove all mappings for a specific track+param."""
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.execute(
                    "DELETE FROM midi_mappings WHERE target_track_id = ? AND target_param = ?",
                    (track_id, param))
                conn.commit()
            finally:
                conn.close()
            self._loaded = False
            self.ensure_loaded()
        except Exception:
            pass

    def clear_project_mappings(self, project_id: str) -> None:
        """Remove all mappings for a project."""
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.execute(
                    "DELETE FROM midi_mappings WHERE project_id = ?", (project_id,))
                conn.commit()
            finally:
                conn.close()
            self._loaded = False
            self.ensure_loaded()
        except Exception:
            pass

    def import_from_project(self, project_id: str,
                            mappings: List[dict]) -> int:
        """Import mappings from a project's midi_mappings list."""
        count = 0
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                for m in mappings:
                    try:
                        conn.execute(
                            """INSERT OR IGNORE INTO midi_mappings
                               (project_id, cc_number, channel, source_port,
                                target_track_id, target_param, target_plugin_id,
                                min_value, max_value, curve)
                               VALUES (?,?,?,?,?,?,?,?,?,?)""",
                            (project_id,
                             int(m.get("control", m.get("cc_number", 0))),
                             int(m.get("channel", -1)),
                             str(m.get("source_port", "")),
                             str(m.get("track_id", m.get("target_track_id", ""))),
                             str(m.get("param", m.get("target_param", ""))),
                             str(m.get("plugin_id", m.get("target_plugin_id", ""))),
                             float(m.get("min_value", 0.0)),
                             float(m.get("max_value", 1.0)),
                             str(m.get("curve", "linear")))
                        )
                        count += 1
                    except Exception:
                        pass
                conn.commit()
            finally:
                conn.close()
            self._loaded = False
            self.ensure_loaded()
        except Exception:
            pass
        return count

    # ── Profile API ─────────────────────────────────────────────

    def get_all_profiles(self) -> List[dict]:
        """Get all controller profiles."""
        self.ensure_loaded()
        return list(self._profiles.values())

    def get_profile(self, name: str) -> Optional[dict]:
        """Get a controller profile by name."""
        self.ensure_loaded()
        return self._profiles.get(name)

    def get_active_profile(self) -> Optional[dict]:
        """Get the currently active profile."""
        self.ensure_loaded()
        if self._active_profile:
            return self._profiles.get(self._active_profile)
        # Find any with is_active=1
        for p in self._profiles.values():
            if p.get("is_active"):
                return p
        return None

    def set_active_profile(self, name: str) -> bool:
        """Set a profile as active (deactivates others)."""
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.execute("UPDATE controller_profiles SET is_active = 0")
                conn.execute(
                    "UPDATE controller_profiles SET is_active = 1 WHERE name = ?",
                    (name,))
                conn.commit()
            finally:
                conn.close()
            self._active_profile = name
            self._loaded = False
            self.ensure_loaded()
            return True
        except Exception:
            return False

    def add_profile(self, name: str, profile_data: dict,
                    device_pattern: str = "", is_builtin: bool = False) -> bool:
        """Add or update a controller profile."""
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.execute(
                    """INSERT OR REPLACE INTO controller_profiles
                       (name, device_pattern, profile_data, is_builtin, is_active)
                       VALUES (?,?,?,?,0)""",
                    (name, device_pattern,
                     json.dumps(profile_data, ensure_ascii=False),
                     int(is_builtin))
                )
                conn.commit()
            finally:
                conn.close()
            self._loaded = False
            self.ensure_loaded()
            return True
        except Exception as e:
            log.warning("[MidiMappingDB] add_profile failed: %s", e)
            return False

    def detect_profile(self, device_name: str) -> Optional[dict]:
        """Auto-detect a controller profile by matching device name against patterns."""
        self.ensure_loaded()
        import re
        for p in self._profiles.values():
            pattern = p.get("device_pattern", "")
            if pattern:
                try:
                    if re.search(pattern, device_name, re.IGNORECASE):
                        return p
                except Exception:
                    pass
        return None

    # ── Internal ────────────────────────────────────────────────

    def _init_db(self) -> None:
        """Create tables + seed factory profiles."""
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(self._db_path))
        try:
            conn.executescript(_SCHEMA_SQL)
            count = conn.execute("SELECT COUNT(*) FROM controller_profiles").fetchone()[0]
            if count == 0:
                self._seed_factory_profiles(conn)
            conn.commit()
        finally:
            conn.close()

    def _load_to_ram(self) -> None:
        """Load all data into RAM."""
        conn = sqlite3.connect(str(self._db_path))
        conn.row_factory = sqlite3.Row
        try:
            # Mappings
            rows = conn.execute("SELECT * FROM midi_mappings").fetchall()
            self._mappings.clear()
            self._by_cc.clear()
            for row in rows:
                d = dict(row)
                self._mappings.append(d)
                cc = d.get("cc_number", 0)
                self._by_cc.setdefault(cc, []).append(d)

            # Profiles
            rows = conn.execute("SELECT * FROM controller_profiles").fetchall()
            self._profiles.clear()
            self._active_profile = None
            for row in rows:
                d = dict(row)
                name = d["name"]
                # Parse profile_data JSON
                try:
                    d["profile_data_parsed"] = json.loads(d.get("profile_data", "{}"))
                except Exception:
                    d["profile_data_parsed"] = {}
                self._profiles[name] = d
                if d.get("is_active"):
                    self._active_profile = name
        finally:
            conn.close()

    def _seed_factory_profiles(self, conn: sqlite3.Connection) -> None:
        """Insert built-in controller profiles."""
        for name, pattern, data in _FACTORY_PROFILES:
            try:
                conn.execute(
                    """INSERT OR IGNORE INTO controller_profiles
                       (name, device_pattern, profile_data, is_builtin, is_active)
                       VALUES (?,?,?,1,0)""",
                    (name, pattern, json.dumps(data, ensure_ascii=False))
                )
            except Exception:
                pass


# ── Schema ──────────────────────────────────────────────────────

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS midi_mappings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id TEXT,
    cc_number INTEGER NOT NULL,
    channel INTEGER DEFAULT -1,
    source_port TEXT,
    target_track_id TEXT,
    target_param TEXT NOT NULL,
    target_plugin_id TEXT,
    min_value REAL DEFAULT 0.0,
    max_value REAL DEFAULT 1.0,
    curve TEXT DEFAULT 'linear',
    created_at TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_midi_cc ON midi_mappings(cc_number);
CREATE INDEX IF NOT EXISTS idx_midi_track ON midi_mappings(target_track_id);
CREATE INDEX IF NOT EXISTS idx_midi_project ON midi_mappings(project_id);

CREATE TABLE IF NOT EXISTS controller_profiles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    device_pattern TEXT,
    profile_data TEXT NOT NULL,
    is_builtin INTEGER DEFAULT 0,
    is_active INTEGER DEFAULT 0
);
"""

# ── Factory Profiles ────────────────────────────────────────────
# Format: (name, device_pattern_regex, profile_data_dict)

_FACTORY_PROFILES = [
    (
        "nanoKONTROL2",
        r"nanoKONTROL2",
        {
            "manufacturer": "Korg",
            "type": "mixer_controller",
            "faders": [
                {"cc": i, "channel": 0, "param": "volume", "track_offset": idx}
                for idx, i in enumerate([0, 1, 2, 3, 4, 5, 6, 7])
            ],
            "knobs": [
                {"cc": i, "channel": 0, "param": "pan", "track_offset": idx}
                for idx, i in enumerate([16, 17, 18, 19, 20, 21, 22, 23])
            ],
            "solo_buttons": [
                {"cc": i, "channel": 0, "action": "solo", "track_offset": idx}
                for idx, i in enumerate([32, 33, 34, 35, 36, 37, 38, 39])
            ],
            "mute_buttons": [
                {"cc": i, "channel": 0, "action": "mute", "track_offset": idx}
                for idx, i in enumerate([48, 49, 50, 51, 52, 53, 54, 55])
            ],
            "rec_buttons": [
                {"cc": i, "channel": 0, "action": "record_arm", "track_offset": idx}
                for idx, i in enumerate([64, 65, 66, 67, 68, 69, 70, 71])
            ],
            "transport": {
                "play": {"cc": 41}, "stop": {"cc": 42},
                "record": {"cc": 45}, "rewind": {"cc": 43}, "forward": {"cc": 44},
            },
        }
    ),
    (
        "nanoKEY2",
        r"nanoKEY2",
        {
            "manufacturer": "Korg",
            "type": "keyboard",
            "keys": 25,
            "octave_range": [36, 96],
            "has_velocity": True,
            "has_modwheel": False,
            "has_pitch_bend": False,
        }
    ),
    (
        "Launchpad Mini",
        r"Launchpad Mini",
        {
            "manufacturer": "Novation",
            "type": "grid_controller",
            "grid_rows": 8, "grid_cols": 8,
            "has_led_feedback": True,
            "pads": [
                {"note": r * 16 + c, "row": r, "col": c, "action": "clip_launch"}
                for r in range(8) for c in range(8)
            ],
        }
    ),
    (
        "APC Mini",
        r"APC\s*Mini",
        {
            "manufacturer": "Akai",
            "type": "hybrid_controller",
            "grid_rows": 8, "grid_cols": 8,
            "has_led_feedback": True,
            "faders": [
                {"cc": 48 + i, "channel": 0, "param": "volume", "track_offset": i}
                for i in range(9)
            ],
        }
    ),
    (
        "Push 2",
        r"Ableton Push 2",
        {
            "manufacturer": "Ableton",
            "type": "full_controller",
            "grid_rows": 8, "grid_cols": 8,
            "has_led_feedback": True,
            "has_display": True,
            "encoders": 8,
        }
    ),
]
