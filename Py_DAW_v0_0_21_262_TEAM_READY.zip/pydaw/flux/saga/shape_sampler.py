"""
pydaw.flux.saga.shape_sampler — Pure-Python Form-Sampler
========================================================

**v0.0.21.202 — S-0**

Liefert eine sofort lauffähige Python-Implementation der Form-zu-
Punkte-Pipeline aus FLUX_SAGA_MANIFEST §2.4. Der Sampler kombiniert:

  1. Parametrisches Sampling (`ShapeDefinition.sample_polyline`)
  2. Stippling — Punkte mit gewichteter Density entlang des Pfades
  3. Audio-Reaktivität (S-0: passive — kein Audio-Tap; S-1+: live)
  4. Adaptive Density — bei SENTINEL-GIL-Spike automatisch reduziert

Die Klasse ``SagaShapeSampler`` ist die Lauf-Brücke zwischen einer
``ShapeDefinition`` (was ist die Form?) und dem Renderer-Proxy
(welche Punkte zeichnet QPainter?).

Architektur-Notiz S-0
---------------------

Im Manifest §2.3 ist das IPC-Format ``SagaFrame`` mit Punkten als
``(f16, f16, u8 alpha, u8 hue)`` spezifiziert. In S-0 produzieren wir
**identische Punkt-Tupel direkt in Python** als
``(x: float, y: float, alpha: int, hue: int)`` — das gleiche
Format, nur ohne IPC-Marshalling. Wenn die Rust-Engine in S-0+ die
Punkte liefert, kann der Renderer-Proxy beide Quellen einheitlich
behandeln.

Das ist die *Plugin-pattern*-Implementierung: Python-Sampler ist die
**Default-Quelle**, IPC ist die **bevorzugte Quelle wenn verfügbar**.
"""
from __future__ import annotations

import logging
import math
import random
from dataclasses import dataclass, field
from typing import Optional

from pydaw.services.saga_factory_shapes import (
    DEFAULT_SHAPE_ID,
    SHAPE_DEFINITIONS,
    ShapeDefinition,
    get_shape,
)


logger = logging.getLogger(__name__)


# ─── Datenmodell ─────────────────────────────────────────────────


@dataclass
class SagaPoint:
    """Ein Stippling-Punkt im Modul-Body.

    Koordinaten sind im Einheits-Quadrat ``[0..1]² (top-left origin)``,
    so dass der Renderer sie direkt mit der ``saga_rect`` skalieren
    kann (W = saga_rect.width, H = saga_rect.height).

    Alpha 0..255, Hue 0..359 (HSV-konform).
    """
    x: float
    y: float
    alpha: int
    hue: int


@dataclass
class SamplerConfig:
    """Sampling-Parameter für ``SagaShapeSampler``.

    Spec aus FLUX_SAGA_MANIFEST §4.1 (Saga.Magic-Parameters):

    * ``shape_id``       — 0..23 (Default 0=Heart)
    * ``density``        — 0..1, beeinflusst Punkt-Anzahl
    * ``rotation_speed`` — -2..2 (S-0: 0 ohne Animation; in Verbindung
      mit der Animation-Engine wird das in renderer_proxy live gesetzt)
    * ``audio_react``    — 0..1, S-0 passiv (kein Audio-Tap)
    * ``palette``        — 0..N (S-0: nur Norse-Cyan id=0)
    """
    shape_id: int = DEFAULT_SHAPE_ID
    density: float = 0.7
    rotation_speed: float = 0.0
    audio_react: float = 0.6
    palette: int = 0
    # S-0 Defaults (ohne Live-Audio)
    rms: float = 0.0
    spectral_centroid: float = 0.0
    spectral_flatness: float = 0.0
    onset_pulse: float = 0.0


# ─── Sampler ─────────────────────────────────────────────────────


class SagaShapeSampler:
    """Erzeugt Stippling-Punktwolken aus ShapeDefinitions.

    S-0: rein Python, keine externe Abhängigkeit außer ``random``.
    Threadsafe ist NICHT garantiert — pro Modul-Instance ein Sampler.

    Adaptive-Density-Hook: Renderer-Proxy kann ``set_throttled(True)``
    setzen wenn SENTINEL einen GIL-Spike meldet, dann reduziert der
    Sampler die Punkt-Anzahl auf 25% (siehe Manifest §6).
    """

    # Farb-Defaults (Norse-Cyan, FLUX_SAGA_MANIFEST §1.2)
    NORSE_CYAN_HUE = 185        # cyan-türkis
    NORSE_CYAN_HUE_SPREAD = 25  # ±25° Hue-Modulation für Variation
    DEFAULT_ALPHA_MIN = 60
    DEFAULT_ALPHA_MAX = 220

    def __init__(self, config: Optional[SamplerConfig] = None) -> None:
        self.config = config or SamplerConfig()
        self._throttled = False
        # Pseudo-Phase für Rotation: animations-engine erhöht das Tick-für-Tick
        self._phase: float = 0.0
        # Lokaler RNG für Stippling-Jitter — deterministische Wieder-
        # holbarkeit pro Sampler-Instance ist nicht erforderlich, aber
        # ein eigener RNG verhindert Konflikte mit anderen Modulen.
        self._rng = random.Random()

    # ─── Public API ───────────────────────────────────────────────

    def set_shape_id(self, shape_id: int) -> None:
        if shape_id < 0 or shape_id >= len(SHAPE_DEFINITIONS):
            shape_id = DEFAULT_SHAPE_ID
        self.config.shape_id = int(shape_id)

    def set_density(self, density: float) -> None:
        self.config.density = max(0.0, min(1.0, float(density)))

    def set_rotation_speed(self, speed: float) -> None:
        self.config.rotation_speed = max(-2.0, min(2.0, float(speed)))

    def set_audio_react(self, react: float) -> None:
        self.config.audio_react = max(0.0, min(1.0, float(react)))

    def set_throttled(self, throttled: bool) -> None:
        """SENTINEL-Hook: bei `True` reduziert der Sampler auf 25%
        Density. Wird vom Renderer-Proxy gesetzt wenn GIL-Last hoch."""
        self._throttled = bool(throttled)

    def advance_phase(self, dt_seconds: float) -> None:
        """Phase um dt vorrücken — benutzt von der Animation-Engine
        (1 tick = 1 advance) zur Rotation. Phase liegt in [0..1)."""
        self._phase = (self._phase + self.config.rotation_speed * dt_seconds) % 1.0

    def set_phase(self, phase: float) -> None:
        """Direkter Phase-Setter — für Reduced-Motion (gestoppte Anim)."""
        self._phase = phase % 1.0

    def update_audio_features(
        self, rms: float = 0.0, centroid: float = 0.0,
        flatness: float = 0.0, onset: float = 0.0,
    ) -> None:
        """Audio-Reaktivität-Hook (S-0: passiv, in S-0+ live von Rust)."""
        self.config.rms = max(0.0, min(1.0, float(rms)))
        self.config.spectral_centroid = max(0.0, min(1.0, float(centroid)))
        self.config.spectral_flatness = max(0.0, min(1.0, float(flatness)))
        self.config.onset_pulse = max(0.0, min(1.0, float(onset)))

    def shape(self) -> ShapeDefinition:
        """Aktuelle Form-Definition."""
        return get_shape(self.config.shape_id)

    # v0.0.21.212 — Audio-Reactive-Density tunables (Klassen-Konstanten).
    # Alle Schwellwerte konservativ gewählt; bei audio_react=0 wirkt nichts.
    QUIET_RMS_THRESHOLD = 0.05      # unter -26 dBFS = „silent"
    QUIET_REDUCTION = 0.5           # bei voller Stille + react=1 → 50% density
    RICHNESS_FLATNESS_FROM = 0.4    # ab dieser Flatness beginnt der Boost
    RICHNESS_BOOST = 0.25           # rauschartig + react=1 → +25% density
    ONSET_DENSITY_BOOST = 0.15      # onset_pulse=1 + react=1 → +15% density spike

    @classmethod
    def _compute_audio_richness_mul(cls, config: "SamplerConfig") -> float:
        """Liefert den Density-Multiplikator aus den Audio-Features.

        Drei Faktoren werden multipliziert:

        * **quiet_factor** — bei rms unter Schwelle und audio_react > 0
          reduziert sich die Density linear bis 0.5 (= 50%) bei voller
          Stille. Verhindert dass ein silenter Track ein dichtes Visual
          zeigt.
        * **rich_factor** — bei flatness > 0.4 (rauschartig / perkussiv)
          steigt die Density bis +25% bei voller Flatness.
        * **onset_factor** — kurze Density-Spike bei detektiertem Beat,
          bis +15% bei onset_pulse=1.

        Alle drei sind bit-identisch 1.0 bei ``audio_react = 0``.
        Damit ist der Default-Pfad (Anno hat audio_react auf 0
        gestellt) zu v.211 numerisch identisch — NICHTS-KAPUTT.

        Returns
        -------
        Multiplikator, geclampt auf [0.25, 1.5]. Wird in
        ``sample_points()`` mit ``density_mul`` × ``audio_mul`` × ``throttle_mul``
        multipliziert.
        """
        ar = max(0.0, min(1.0, float(config.audio_react)))
        if ar <= 0.0:
            # Strikt bit-identisch zu v.211: kein Code-Pfad-Wechsel,
            # nur Multiplikator 1.0 zurück.
            return 1.0

        rms = max(0.0, min(1.0, float(config.rms)))
        flatness = max(0.0, min(1.0, float(config.spectral_flatness)))
        onset = max(0.0, min(1.0, float(config.onset_pulse)))

        # 1) Quiet-Reduction
        # Bei rms >= QUIET_RMS_THRESHOLD: quiet_excess = 0 → quiet_factor = 1
        # Bei rms = 0:                    quiet_excess = 1 → quiet_factor = 1 - 0.5*ar
        if cls.QUIET_RMS_THRESHOLD > 0:
            quiet_excess = max(0.0, (cls.QUIET_RMS_THRESHOLD - rms) / cls.QUIET_RMS_THRESHOLD)
        else:
            quiet_excess = 0.0
        quiet_factor = 1.0 - quiet_excess * cls.QUIET_REDUCTION * ar

        # 2) Richness-Boost
        # Bei flatness <= RICHNESS_FLATNESS_FROM: rich_excess = 0 → rich_factor = 1
        # Bei flatness = 1:                       rich_excess = 1 → rich_factor = 1 + 0.25*ar
        if cls.RICHNESS_FLATNESS_FROM < 1.0:
            rich_excess = max(
                0.0,
                (flatness - cls.RICHNESS_FLATNESS_FROM)
                / (1.0 - cls.RICHNESS_FLATNESS_FROM),
            )
        else:
            rich_excess = 0.0
        rich_excess = min(1.0, rich_excess)
        rich_factor = 1.0 + rich_excess * cls.RICHNESS_BOOST * ar

        # 3) Onset-Spike
        onset_factor = 1.0 + onset * cls.ONSET_DENSITY_BOOST * ar

        # Kombinieren und clampen — Sicherheits-Bounds gegen Edge-Cases
        result = quiet_factor * rich_factor * onset_factor
        if result < 0.25:
            return 0.25
        if result > 1.5:
            return 1.5
        return result

    def sample_points(
        self,
        body_w: int = 100,
        body_h: int = 100,
        target_count: Optional[int] = None,
    ) -> list[SagaPoint]:
        """Erzeugt die Stippling-Punktwolke für den aktuellen Frame.

        Parameters
        ----------
        body_w, body_h
            Modul-Body-Dimension in Pixeln. Rein zur Skalierung der
            Punkt-Koordinaten (Center-Offset, Aspect).
        target_count
            Wieviele Punkte erzeugen (default: aus Shape-Definition,
            durch Density × Throttle moduliert).

        Returns
        -------
        Liste von ``SagaPoint``. Koordinaten ``x, y`` sind im Einheits-
        Quadrat ``[0..1]²`` (top-left origin).

        v0.0.21.209 — Audio-Reaktivität (das „Herz schlägt"):

        Drei zusätzliche Reaktions-Achsen, alle gesteuert durch
        ``audio_react`` (0..1 Master-Mix):

        1. **radial_scale**: bei lautem Signal expandiert die ganze Form
           nach außen (~12% bei voller Lautstärke). Das ist das
           offensichtlichste „Heart beats with the music"-Signal.
        2. **3D-Tilt**: Spectral-Centroid kippt die Form leicht in der
           Tiefe (Y-Achse staucht beim hohen Centroid). Erzeugt eine
           subtile 3D-Illusion wenn sich der Klang verändert.
        3. **Onset-Pulse**: kurzer extra-Boost auf radial_scale +
           Alpha bei Beat-Onsets. Der „KI-unterstützt"-Eindruck den
           Anno haben will entsteht aus der Kombination aller drei.

        Bei rms=0 / audio_react=0 wird keine dieser Modulationen aktiv —
        Verhalten ist bit-identisch zu v.208.

        v0.0.21.212 — Audio-Reactive-Density (Manifest §6 Adaptive-Density,
        Audio-Content-Variante; ergänzt SENTINEL-GIL-Throttle aus v.204):

        Drei zusätzliche Density-Modulatoren, alle wieder ``audio_react``-
        gesteuert (audio_react=0 → bit-identisch zu v.211):

        4. **Quiet-Rest** (``rms < 0.05`` mit voller Skalierung): silent
           Tracks zeigen weniger Stippling-Punkte (bis zu 50% Reduktion)
           — visuelle Ruhe in Stille statt voller Punkt-Wolke.
        5. **Richness-Boost** (``flatness > 0.4``): rauschartiges /
           perkussives Material bekommt bis zu +25% mehr Punkte für
           dichteres Visual-Feedback bei lebendigem Audio.
        6. **Onset-Spike**: bei detektiertem Beat kurzzeitiger +15%
           Density-Boost — synchron zum existierenden Alpha-Burst.
        """
        shape = self.shape()
        n_default = target_count if target_count is not None else shape.default_point_count

        # Density: 0..1 → 0.4..1.5 Multiplikator
        density_mul = 0.4 + self.config.density * 1.1
        # Audio-Reaktivität: bei lautem Signal mehr Punkte
        audio_mul = 1.0 + self.config.rms * self.config.audio_react * 0.6
        # Throttle: bei GIL-Spike auf 25%
        throttle_mul = 0.25 if self._throttled else 1.0

        # v0.0.21.212 — Audio-Content-Density-Modulation.
        # Static helper, weil _effective_density-Logik auch unabhängig
        # testbar sein soll (siehe Test-Suite). Multiplikator ist
        # bit-identisch 1.0 wenn audio_react=0 → NICHTS-KAPUTT-Pakt.
        audio_richness_mul = self._compute_audio_richness_mul(self.config)

        n = max(8, int(
            n_default * density_mul * audio_mul * audio_richness_mul * throttle_mul
        ))
        # Safety-Cap: niemals mehr als 1000 Punkte (selbst ohne Throttle)
        n = min(n, 1000)

        points: list[SagaPoint] = []
        rotation_phase = self._phase * 2.0 * math.pi
        cos_r = math.cos(rotation_phase)
        sin_r = math.sin(rotation_phase)

        # Spectral-Flatness gibt Stippling-Jitter (rauschig = wandernd)
        jitter = 0.005 + self.config.spectral_flatness * 0.05

        # Onset-Burst: bei detektiertem Beat extra-helle Punkte
        burst_alpha_boost = int(self.config.onset_pulse * 35)

        # ─── v0.0.21.209: Heart-Beat-Reaktivität ──────────────────
        # radial_scale: 1.0 (ruhig) bis 1.12 (voller Pegel mit react=1)
        # Onset gibt zusätzlich +0.06 als kurzer Burst.
        # Bei audio_react=0 → radial_scale=1.0 (zero-behavior-change).
        ar = self.config.audio_react
        radial_scale = (
            1.0
            + self.config.rms * ar * 0.12
            + self.config.onset_pulse * ar * 0.06
        )
        # Sanftes Cap damit Form niemals den Body überschießt
        if radial_scale > 1.18:
            radial_scale = 1.18

        # 3D-Tilt: hoher Spectral-Centroid kippt die Form (Y-Stauchung).
        # Wertebereich für tilt: 0.85..1.0 (15% Y-Stauchung max).
        # Bei audio_react=0 oder centroid=0.5 (neutral) → tilt=1.0.
        tilt_amount = (self.config.spectral_centroid - 0.5) * 2.0  # -1..+1
        tilt_y = 1.0 - abs(tilt_amount) * ar * 0.15

        # Depth-Pulse: leichter Phase-modulierter Atem (~5%) bei lautem
        # Signal — wirkt wie ein 3D-Z-Wackeln.
        depth_pulse = 1.0 + math.sin(self._phase * 4.0 * math.pi) * (
            self.config.rms * ar * 0.05
        )

        # Combined effective scale für die [-1..1]→[0..1]-Map
        eff_radial = radial_scale * depth_pulse
        # ──────────────────────────────────────────────────────────

        # Brightness-Boost durch RMS — bei lautem Signal hellere Stippels
        rms_alpha_boost = int(self.config.rms * ar * 50)

        for i in range(n):
            t = i / max(1, n - 1)
            # Form sampeln in [-1..1]²
            sx, sy = shape.sample(t)
            # v0.0.21.209: radial expansion + Y-Tilt vor der Rotation
            sx_a = sx * eff_radial
            sy_a = sy * eff_radial * tilt_y
            # Rotation
            rx = sx_a * cos_r - sy_a * sin_r
            ry = sx_a * sin_r + sy_a * cos_r
            # Jitter (Spectral-Flatness)
            if jitter > 0.001:
                rx += self._rng.uniform(-jitter, jitter)
                ry += self._rng.uniform(-jitter, jitter)
            # Map zu [0..1]² mit zentraler Positionierung
            # Wir reservieren 8% Margin damit Punkte nicht den Body
            # touchieren (visuell saubere Ränder)
            margin = 0.08
            scale = 0.5 - margin
            px = 0.5 + rx * scale
            py = 0.5 + ry * scale
            # Clamp gegen pathologische Jitter-Outliers
            px = max(0.0, min(1.0, px))
            py = max(0.0, min(1.0, py))
            # Alpha: Density-gewichtet plus Onset-Burst plus RMS-Boost
            base_alpha = self.DEFAULT_ALPHA_MIN + int(
                (self.DEFAULT_ALPHA_MAX - self.DEFAULT_ALPHA_MIN) * (0.4 + self.config.density * 0.6)
            )
            alpha = max(0, min(255,
                base_alpha + burst_alpha_boost + rms_alpha_boost))
            # Hue: Norse-Cyan + Centroid-Modulation
            hue = self.NORSE_CYAN_HUE + int(
                (self.config.spectral_centroid - 0.5) * 2.0 * self.NORSE_CYAN_HUE_SPREAD
            )
            hue = hue % 360
            points.append(SagaPoint(x=px, y=py, alpha=alpha, hue=hue))
        return points


# ─── Convenience ─────────────────────────────────────────────────


def sample_shape_to_points(
    shape_id: int = DEFAULT_SHAPE_ID,
    n: int = 256,
    density: float = 0.7,
) -> list[SagaPoint]:
    """One-shot: Punkte für eine Form sampeln. Praktisch für Tests
    und Preview-Renders ohne Sampler-Lifecycle."""
    cfg = SamplerConfig(shape_id=shape_id, density=density)
    sampler = SagaShapeSampler(cfg)
    return sampler.sample_points(target_count=n)


__all__ = [
    "SagaPoint", "SamplerConfig", "SagaShapeSampler",
    "sample_shape_to_points",
]
