"""
pydaw.services.flux_patch_service
==================================

Service zum Verwalten von FLUX-Patches im Projekt.

Architektur (Per-Track-Modell, wie Bitwig Grid)
-----------------------------------------------

Jede Track kann auf einen Patch verweisen (`Track.flux_patch_id`). Patches
selbst leben in einer flachen Liste auf Projekt-Ebene (`Project.flux_patches`).
Mehrere Tracks können denselben Patch teilen (z.B. zwei Bass-Tracks mit dem
gleichen Acid-Bass-Sound). Dieses Modell unterstützt:

    Track 1 (Bass)   ─→ patch_acid_bass
    Track 2 (Lead)   ─→ patch_lead
    Track 3 (Pad)    ─→ patch_pad
    Track 4 (Drums)  ─→ (kein Patch — nutzt SF2)
    Track 5 (Bass2)  ─→ patch_acid_bass    ← geteilt mit Track 1

Persistenz
----------

Beim Projekt-Save wird `Project.flux_patches` als JSON-Liste serialisiert
(jeder Patch via `Patch.to_dict()`). Beim Load wird die Liste rekonstruiert
via `Patch.from_dict()` und in einem In-Memory-Dict gehalten für schnelle
Lookups.

Thread-Safety
-------------

Diese Klasse ist NICHT thread-safe. Sie wird nur aus dem UI-Thread (Main-
Loop) aufgerufen. Audio-Thread liest stattdessen aus dem Rust-IPC-
Snapshot (seit v0.0.21.183 = F-1.1 Engine-Sync — siehe
`pydaw.services.flux_rust_sync`).

Engine-Sync (v0.0.21.183 — F-1.1)
---------------------------------

Jede Mutation (`add`, `remove`, `assign_to_track`, `create_for_track`)
versucht, den State auch in die Rust-Engine zu spiegeln. Der Sync-Aufruf
ist Best-Effort: wenn die Engine nicht läuft, wird das nur geloggt — die
Python-Seite bleibt voll funktional. Der Sync-Hook lässt sich für Tests
deaktivieren via `FluxPatchService(rust_sync_enabled=False)`.

Beim `load_from_project()` werden alle Patches einzeln nach Rust gespiegelt
nachdem sie in den lokalen In-Memory-Index eingetragen wurden — analog
zum SyncProject-Pattern für Tracks.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

from pydaw.flux.patch_model import Patch


logger = logging.getLogger(__name__)


class FluxPatchService:
    """Single-Instance-Service. Lebt in `Container.flux_patch_service`."""

    def __init__(self, rust_sync_enabled: bool = True) -> None:
        self._patches: dict[str, Patch] = {}
        # v0.0.21.183 — F-1.1: optionaler Engine-Sync. Lazy-resolved damit
        # Tests die Klasse instanziieren können ohne Rust-Engine-Modul.
        self._rust_sync_enabled = bool(rust_sync_enabled)
        self._rust_sync: Any = None  # FluxRustSync, lazy

    # ─── Engine-Sync (v0.0.21.183, F-1.1) ─────────────────────────

    def _get_rust_sync(self) -> Any:
        """Lazy-Auflösung des FluxRustSync-Singletons.

        Defensiv: falls der Import fehlschlägt (z.B. in headless-Tests
        ohne den Bridge-Modul-Tree), wird der Sync stillschweigend
        deaktiviert.
        """
        if not self._rust_sync_enabled:
            return None
        if self._rust_sync is None:
            try:
                from pydaw.services.flux_rust_sync import get_flux_rust_sync
                self._rust_sync = get_flux_rust_sync()
            except Exception as e:
                logger.debug("[FLUX-SERVICE] rust_sync unavailable: %s", e)
                self._rust_sync_enabled = False
                return None
        return self._rust_sync

    def _sync_patch_to_engine(self, patch: Patch) -> None:
        rs = self._get_rust_sync()
        if rs is not None:
            try:
                rs.sync_patch(patch)
            except Exception as e:
                logger.warning("[FLUX-SERVICE] sync_patch failed: %s", e)

    def _sync_remove_to_engine(self, patch_id: str) -> None:
        rs = self._get_rust_sync()
        if rs is not None:
            try:
                rs.remove_patch(patch_id)
            except Exception as e:
                logger.warning("[FLUX-SERVICE] remove_patch sync failed: %s", e)

    def _sync_assignment_to_engine(self, track_id: str, patch_id: str) -> None:
        rs = self._get_rust_sync()
        if rs is not None:
            try:
                rs.assign_to_track(track_id, patch_id)
            except Exception as e:
                logger.warning("[FLUX-SERVICE] assign sync failed: %s", e)

    # ─── Lifecycle: Projekt-Load / Save ────────────────────────────

    def load_from_project(self, project: Any) -> None:
        """Wird beim Projekt-Load aufgerufen — rekonstruiert alle Patches.

        Defensiv: ungültige Patch-Dicts werden übersprungen mit warning,
        nicht gecrasht.

        v0.0.21.183 — F-1.1: Nach dem In-Memory-Load wird jeder Patch
        zur Rust-Engine gespiegelt (best-effort).
        """
        self._patches.clear()
        raw_list = getattr(project, "flux_patches", None) or []
        for raw in raw_list:
            if not isinstance(raw, dict):
                continue
            try:
                patch = Patch.from_dict(raw)
                self._patches[patch.id] = patch
            except Exception as e:
                logger.warning("[FLUX-SERVICE] Skipped invalid patch: %s", e)
        logger.info("[FLUX-SERVICE] Loaded %d patch(es) from project", len(self._patches))
        # F-1.1: Spiegel nach Rust. Wir rufen sync_patch pro Patch auf —
        # das hält die Bridge defensiv (jeder Patch ist eine eigene IPC-
        # Message, und Fehler an einem Patch blockieren die anderen nicht).
        for patch in self._patches.values():
            self._sync_patch_to_engine(patch)
        # Nach dem Patches-Sync auch die Track-Assignments synchronisieren.
        for t in (getattr(project, "tracks", []) or []):
            tid = str(getattr(t, "id", "") or "")
            pid = str(getattr(t, "flux_patch_id", "") or "")
            if tid and pid:
                self._sync_assignment_to_engine(tid, pid)

    def save_to_project(self, project: Any) -> None:
        """Wird beim Projekt-Save aufgerufen — serialisiert alle Patches.

        Schreibt in `Project.flux_patches` (Liste von Dicts).
        """
        try:
            project.flux_patches = [p.to_dict() for p in self._patches.values()]
        except Exception as e:
            logger.warning("[FLUX-SERVICE] save_to_project failed: %s", e)

    # ─── Lookup ──────────────────────────────────────────────────────

    def get(self, patch_id: str) -> Optional[Patch]:
        if not patch_id:
            return None
        return self._patches.get(patch_id)

    def all_patches(self) -> list[Patch]:
        """Sortiert nach Name für UI-Listen."""
        return sorted(self._patches.values(), key=lambda p: p.name.lower())

    def patch_for_track(self, project: Any, track_id: str) -> Optional[Patch]:
        """Findet den Patch der gegebenen Track, oder None."""
        if not track_id:
            return None
        for t in getattr(project, "tracks", []) or []:
            if str(getattr(t, "id", "")) == track_id:
                pid = str(getattr(t, "flux_patch_id", "") or "")
                return self.get(pid) if pid else None
        return None

    def tracks_using_patch(self, project: Any, patch_id: str) -> list[str]:
        """Liefert Track-IDs die diesen Patch referenzieren (für Shared-Detection)."""
        if not patch_id:
            return []
        return [
            str(getattr(t, "id", ""))
            for t in (getattr(project, "tracks", []) or [])
            if str(getattr(t, "flux_patch_id", "") or "") == patch_id
        ]

    # ─── Mutationen ─────────────────────────────────────────────────

    def add(self, patch: Patch) -> Patch:
        """Fügt einen Patch hinzu (oder ersetzt einen mit gleicher ID).

        v0.0.21.183 — F-1.1: spiegelt den Patch zur Rust-Engine.
        """
        self._patches[patch.id] = patch
        self._sync_patch_to_engine(patch)
        return patch

    def remove(self, patch_id: str, project: Any | None = None) -> bool:
        """Entfernt einen Patch. Wenn `project` mitgegeben, werden alle
        Track-Referenzen darauf gelöscht (track.flux_patch_id = "").

        v0.0.21.183 — F-1.1: spiegelt das Remove zur Rust-Engine.
        Track-Assignments werden Rust-seitig automatisch mit-gelöscht
        (siehe `FluxPatchRegistry::remove_patch`).
        """
        if patch_id not in self._patches:
            return False
        del self._patches[patch_id]
        if project is not None:
            for t in getattr(project, "tracks", []) or []:
                if str(getattr(t, "flux_patch_id", "") or "") == patch_id:
                    try:
                        t.flux_patch_id = ""
                    except Exception:
                        pass
        self._sync_remove_to_engine(patch_id)
        return True

    def assign_to_track(self, project: Any, track_id: str,
                         patch_id: str) -> bool:
        """Setzt `track.flux_patch_id` auf den gegebenen Patch.

        Wenn patch_id == "", wird die Zuordnung entfernt (Track hat dann
        keinen FLUX-Patch mehr).

        v0.0.21.183 — F-1.1: spiegelt die Assignment-Änderung zur Rust-Engine.
        """
        if patch_id and patch_id not in self._patches:
            logger.warning("[FLUX-SERVICE] assign_to_track: unknown patch %s", patch_id)
            return False
        for t in getattr(project, "tracks", []) or []:
            if str(getattr(t, "id", "")) == track_id:
                try:
                    t.flux_patch_id = patch_id
                    self._sync_assignment_to_engine(track_id, patch_id)
                    return True
                except Exception as e:
                    logger.warning("[FLUX-SERVICE] failed to set flux_patch_id: %s", e)
                    return False
        return False

    def create_for_track(self, project: Any, track_id: str,
                          template: str = "demo") -> Optional[Patch]:
        """Erzeugt einen neuen Patch und weist ihn der Track zu.

        Templates:
            'demo'  — die Sine→LP→MasterOut Demo-Kette
            'empty' — leer (nur ein Heimdall.MasterOut)
        """
        from pydaw.flux.module_library import (
            make_demo_patch, make_module,
        )
        from pydaw.flux.patch_model import Patch
        if template == "demo":
            patch = make_demo_patch()
        elif template == "empty":
            patch = Patch(name="Empty Patch")
            out = make_module("Heimdall", "MasterOut")
            if out is not None:
                out.position = (400, 200)
                patch.add_module(out)
        else:
            return None
        # Patch-Name an Track anpassen für UX
        track_name = ""
        for t in getattr(project, "tracks", []) or []:
            if str(getattr(t, "id", "")) == track_id:
                track_name = str(getattr(t, "name", "") or "")
                break
        if track_name:
            patch.name = f"{track_name} — {patch.name}"
        self.add(patch)
        self.assign_to_track(project, track_id, patch.id)
        return patch


# ─── Module-Level Singleton (mit lazy-init) ─────────────────────────

_INSTANCE: Optional[FluxPatchService] = None


def get_flux_patch_service() -> FluxPatchService:
    global _INSTANCE
    if _INSTANCE is None:
        _INSTANCE = FluxPatchService()
    return _INSTANCE


__all__ = ["FluxPatchService", "get_flux_patch_service"]
