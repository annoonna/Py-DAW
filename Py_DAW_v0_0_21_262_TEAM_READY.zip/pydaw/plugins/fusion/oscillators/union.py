"""Fusion Oscillator — Union (3-wave crossfade blend).

v0.0.20.573: Phase 2 extended oscillators.

Union blends three waveforms with a single Shape control:
  Left (-1): Pulse +1 octave
  Center (0): Sawtooth
  Right (+1): Saw +1 octave
Plus a Sub pulse oscillator one octave down.
"""
from __future__ import annotations
import numpy as np
from typing import Optional
from .base import OscillatorBase


class UnionOscillator(OscillatorBase):
    """Three-wave blend oscillator with sub."""

    NAME = "Union"

    def __init__(self, sr: int = 48000):
        super().__init__(sr)
        self._shape = 0.0       # -1..+1
        self._sub_width = 0.5   # pulse width for sub
        self._sub_level = 0.0   # 0..1
        self._phase_hi = 0.0    # phase for +1oct oscillator
        self._phase_sub = 0.0   # phase for sub oscillator

    def set_param(self, key: str, value: float) -> None:
        if key == "shape":
            self._shape = max(-1.0, min(1.0, float(value)))
        elif key == "sub_width":
            self._sub_width = max(0.01, min(0.99, float(value)))
        elif key == "sub_level":
            self._sub_level = max(0.0, min(1.0, float(value)))
        else:
            super().set_param(key, value)

    def get_param(self, key: str) -> float:
        if key == "shape":
            return self._shape
        if key == "sub_width":
            return self._sub_width
        if key == "sub_level":
            return self._sub_level
        return super().get_param(key)

    def param_names(self) -> list[str]:
        return ["shape", "sub_width", "sub_level"]

    def reset_phase(self) -> None:
        super().reset_phase()
        self._phase_hi = 0.0
        self._phase_sub = 0.0

    def render(self, frames: int, freq: float, sr: int,
               phase_mod_buf: Optional[np.ndarray] = None) -> np.ndarray:
        """v0.0.20.785: Fully vectorized — numpy phase arrays + vectorized
        PolyBLEP for all three oscillators. ~12-15x faster than per-sample.
        """
        from .basic_waves import _vec_saw_polyblep, _vec_pulse_polyblep

        dt = freq / sr
        dt_hi = freq * 2.0 / sr       # +1 octave
        dt_sub = freq * 0.5 / sr       # -1 octave

        # Cache as locals
        shape = self._shape
        sub_level = self._sub_level
        sub_width = self._sub_width
        has_sub = sub_level > 0.001

        # Vectorized phase accumulation for all 3 oscillators
        indices = np.arange(frames, dtype=np.float64)
        phases_main = (self._phase + indices * dt) % 1.0
        phases_hi = (self._phase_hi + indices * dt_hi) % 1.0
        phases_sub = (self._phase_sub + indices * dt_sub) % 1.0

        # Update final phase state
        self._phase = (self._phase + frames * dt) % 1.0
        self._phase_hi = (self._phase_hi + frames * dt_hi) % 1.0
        self._phase_sub = (self._phase_sub + frames * dt_sub) % 1.0

        # Main saw (center) — vectorized PolyBLEP
        saw_main = _vec_saw_polyblep(phases_main, dt)

        # Blend with shape
        if shape < 0:
            # Left: blend saw → pulse +1oct
            blend = -shape
            pulse_hi = _vec_pulse_polyblep(phases_hi, dt_hi, 0.5)
            out = saw_main * (1.0 - blend) + pulse_hi * blend
        else:
            # Right: blend saw → saw +1oct
            blend = shape
            saw_hi = _vec_saw_polyblep(phases_hi, dt_hi)
            out = saw_main * (1.0 - blend) + saw_hi * blend

        # Sub oscillator (pulse -1oct)
        if has_sub:
            sub = _vec_pulse_polyblep(phases_sub, dt_sub, sub_width)
            out += sub * sub_level

        return out
