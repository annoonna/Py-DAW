"""project_state_db.py — SQLite-backed Project State Mirror.

v0.0.20.892 — Phase 5 der SQLite Migration Roadmap.

DESIGN PRINCIPLE:
  JSON project files remain the PRIMARY storage (authoritative).
  SQLite is a MIRROR for:
  - Crash recovery (last-known-good state survives unclean exit)
  - Fast queries (e.g. "which projects use track X?")
  - Future: incremental sync, collaborative editing backend

NEVER break the existing JSON save/load path. This module is
purely additive — if SQLite fails, the DAW works as before.

Tables (all scoped by project_path):
  project_meta    — BPM, sample rate, time sig, punch, etc.
  project_tracks  — One row per track (complex fields as JSON)
  project_clips   — One row per clip (complex fields as JSON)
  project_midi_notes — Individual MIDI notes (for fast queries)
  project_automation — Automation lane data (parameter_id → breakpoints)

Usage:
    from pydaw.services.project_state_db import ProjectStateDB
    db = ProjectStateDB.get()
    db.ensure_loaded()

    # Mirror full project after save
    db.sync_project(project_path, project)

    # Crash recovery: get last known state
    meta = db.get_project_meta(project_path)
    tracks = db.get_tracks(project_path)
    clips = db.get_clips(project_path)
"""

import json
import sqlite3
import logging
import time
from dataclasses import asdict

from pydaw.services.cs2_slice0 import Slice0ProjectMetaMirrorAdapter
from pathlib import Path
from typing import Dict, List, Optional, Any

log = logging.getLogger(__name__)


_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS project_meta (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    project_path    TEXT NOT NULL UNIQUE,
    project_name    TEXT NOT NULL DEFAULT '',
    bpm             REAL NOT NULL DEFAULT 120.0,
    sample_rate     INTEGER NOT NULL DEFAULT 48000,
    time_signature  TEXT NOT NULL DEFAULT '4/4',
    snap_division   TEXT NOT NULL DEFAULT '1/16',
    punch_enabled   INTEGER NOT NULL DEFAULT 0,
    punch_in_beat   REAL NOT NULL DEFAULT 4.0,
    punch_out_beat  REAL NOT NULL DEFAULT 16.0,
    pre_roll_bars   INTEGER NOT NULL DEFAULT 0,
    post_roll_bars  INTEGER NOT NULL DEFAULT 0,
    track_count     INTEGER NOT NULL DEFAULT 0,
    clip_count      INTEGER NOT NULL DEFAULT 0,
    launcher_quantize TEXT NOT NULL DEFAULT '1 Bar',
    launcher_mode   TEXT NOT NULL DEFAULT 'Trigger',
    extra_json      TEXT NOT NULL DEFAULT '{}',
    synced_at       REAL NOT NULL DEFAULT 0.0
);

CREATE TABLE IF NOT EXISTS project_tracks (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    project_path    TEXT NOT NULL,
    track_id        TEXT NOT NULL,
    track_index     INTEGER NOT NULL DEFAULT 0,
    kind            TEXT NOT NULL DEFAULT 'audio',
    name            TEXT NOT NULL DEFAULT 'Track',
    muted           INTEGER NOT NULL DEFAULT 0,
    solo            INTEGER NOT NULL DEFAULT 0,
    volume          REAL NOT NULL DEFAULT 0.8,
    pan             REAL NOT NULL DEFAULT 0.0,
    record_arm      INTEGER NOT NULL DEFAULT 0,
    input_pair      INTEGER NOT NULL DEFAULT 1,
    output_pair     INTEGER NOT NULL DEFAULT 1,
    monitor         INTEGER NOT NULL DEFAULT 0,
    plugin_type     TEXT NOT NULL DEFAULT '',
    instrument_enabled INTEGER NOT NULL DEFAULT 1,
    channel_config  TEXT NOT NULL DEFAULT 'stereo',
    output_target_id TEXT NOT NULL DEFAULT '',
    sidechain_source_id TEXT NOT NULL DEFAULT '',
    track_group_id  TEXT NOT NULL DEFAULT '',
    track_group_name TEXT NOT NULL DEFAULT '',
    extra_json      TEXT NOT NULL DEFAULT '{}',
    UNIQUE(project_path, track_id)
);

CREATE TABLE IF NOT EXISTS project_clips (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    project_path    TEXT NOT NULL,
    clip_id         TEXT NOT NULL,
    track_id        TEXT NOT NULL DEFAULT '',
    kind            TEXT NOT NULL DEFAULT 'audio',
    start_beats     REAL NOT NULL DEFAULT 0.0,
    length_beats    REAL NOT NULL DEFAULT 4.0,
    offset_beats    REAL NOT NULL DEFAULT 0.0,
    label           TEXT NOT NULL DEFAULT 'Clip',
    source_path     TEXT NOT NULL DEFAULT '',
    source_bpm      REAL,
    gain            REAL NOT NULL DEFAULT 1.0,
    pan             REAL NOT NULL DEFAULT 0.0,
    pitch           REAL NOT NULL DEFAULT 0.0,
    stretch         REAL NOT NULL DEFAULT 1.0,
    stretch_mode    TEXT NOT NULL DEFAULT 'tones',
    reversed        INTEGER NOT NULL DEFAULT 0,
    muted           INTEGER NOT NULL DEFAULT 0,
    fade_in_beats   REAL NOT NULL DEFAULT 0.0,
    fade_out_beats  REAL NOT NULL DEFAULT 0.0,
    launcher_only   INTEGER NOT NULL DEFAULT 0,
    take_group_id   TEXT NOT NULL DEFAULT '',
    take_index      INTEGER NOT NULL DEFAULT 0,
    is_comp_active  INTEGER NOT NULL DEFAULT 1,
    group_id        TEXT NOT NULL DEFAULT '',
    extra_json      TEXT NOT NULL DEFAULT '{}',
    UNIQUE(project_path, clip_id)
);

CREATE TABLE IF NOT EXISTS project_midi_notes (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    project_path    TEXT NOT NULL,
    clip_id         TEXT NOT NULL,
    pitch           INTEGER NOT NULL,
    start_beats     REAL NOT NULL,
    length_beats    REAL NOT NULL,
    velocity        INTEGER NOT NULL DEFAULT 100,
    accidental      INTEGER NOT NULL DEFAULT 0,
    tie_to_next     INTEGER NOT NULL DEFAULT 0,
    expressions_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS project_automation (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    project_path    TEXT NOT NULL,
    parameter_id    TEXT NOT NULL,
    track_id        TEXT NOT NULL DEFAULT '',
    lane_json       TEXT NOT NULL DEFAULT '{}',
    UNIQUE(project_path, parameter_id)
);

CREATE INDEX IF NOT EXISTS idx_pt_proj ON project_tracks(project_path);
CREATE INDEX IF NOT EXISTS idx_pc_proj ON project_clips(project_path);
CREATE INDEX IF NOT EXISTS idx_pc_track ON project_clips(project_path, track_id);
CREATE INDEX IF NOT EXISTS idx_pmn_proj ON project_midi_notes(project_path);
CREATE INDEX IF NOT EXISTS idx_pmn_clip ON project_midi_notes(project_path, clip_id);
CREATE INDEX IF NOT EXISTS idx_pa_proj ON project_automation(project_path);
"""


class ProjectStateDB:
    """SQLite-backed project state mirror.

    Singleton. Mirrors project data to SQLite after JSON save.
    The JSON project file remains authoritative — this is a cache
    for crash recovery and fast queries.
    """

    _instance: Optional["ProjectStateDB"] = None

    @classmethod
    def get(cls) -> "ProjectStateDB":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._db_path = Path.home() / ".config" / "ChronoScaleStudio" / "pydaw.db"
        self._loaded = False

    def ensure_loaded(self) -> None:
        """Create tables if needed. Idempotent."""
        if self._loaded:
            return
        try:
            self._db_path.parent.mkdir(parents=True, exist_ok=True)
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.executescript(_SCHEMA_SQL)
                conn.commit()
            finally:
                conn.close()
            self._loaded = True
            log.info("[ProjectStateDB] Tables ready")
        except Exception as e:
            log.warning("[ProjectStateDB] Init failed: %s", e)

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self._db_path))
        conn.row_factory = sqlite3.Row
        return conn

    # ══════════════════════════════════════════════════════════════
    # Full Project Sync (called after project save)
    # ══════════════════════════════════════════════════════════════

    def sync_project(self, project_path: str, project) -> bool:
        """Mirror entire project state to SQLite. Returns True on success.

        Args:
            project_path: Filesystem path to the .pydaw project file
            project: pydaw.model.project.Project instance
        """
        if not project_path or project is None:
            return False
        try:
            conn = sqlite3.connect(str(self._db_path))
            conn.execute("PRAGMA journal_mode=WAL")
            try:
                conn.execute("BEGIN")
                self._sync_meta(conn, project_path, project)
                self._sync_tracks(conn, project_path, project)
                self._sync_clips(conn, project_path, project)
                self._sync_midi_notes(conn, project_path, project)
                self._sync_automation(conn, project_path, project)
                conn.commit()
                log.info("[ProjectStateDB] Synced project: %s (%d tracks, %d clips)",
                         project_path,
                         len(getattr(project, 'tracks', []) or []),
                         len(getattr(project, 'clips', []) or []))
                return True
            except Exception:
                conn.rollback()
                raise
            finally:
                conn.close()
        except Exception as e:
            log.warning("[ProjectStateDB] sync_project failed: %s", e)
            return False

    def _sync_meta(self, conn: sqlite3.Connection, pp: str, project) -> None:
        """Sync project metadata."""
        tracks = getattr(project, 'tracks', []) or []
        clips = getattr(project, 'clips', []) or []
        extra = {}
        for key in ('ghost_layers', 'notation_marks', 'review_data',
                     'launcher_scene_names', 'launcher_scene_colors',
                     'launcher_midi_mapping', 'arranger_collapsed_group_ids',
                     'clip_launcher', 'launcher_scene_crossfade_ms',
                     'launcher_audio_input', 'launcher_punch_in',
                     'launcher_punch_out', 'launcher_monitoring',
                     'midi_mappings'):
            val = getattr(project, key, None)
            if val:
                extra[key] = val

        meta_adapter = Slice0ProjectMetaMirrorAdapter()
        header, extra = meta_adapter.merge_extra(project, extra)

        conn.execute(
            """INSERT INTO project_meta
               (project_path, project_name, bpm, sample_rate, time_signature,
                snap_division, punch_enabled, punch_in_beat, punch_out_beat,
                pre_roll_bars, post_roll_bars, track_count, clip_count,
                launcher_quantize, launcher_mode, extra_json, synced_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(project_path) DO UPDATE SET
                   project_name=excluded.project_name, bpm=excluded.bpm,
                   sample_rate=excluded.sample_rate,
                   time_signature=excluded.time_signature,
                   snap_division=excluded.snap_division,
                   punch_enabled=excluded.punch_enabled,
                   punch_in_beat=excluded.punch_in_beat,
                   punch_out_beat=excluded.punch_out_beat,
                   pre_roll_bars=excluded.pre_roll_bars,
                   post_roll_bars=excluded.post_roll_bars,
                   track_count=excluded.track_count,
                   clip_count=excluded.clip_count,
                   launcher_quantize=excluded.launcher_quantize,
                   launcher_mode=excluded.launcher_mode,
                   extra_json=excluded.extra_json,
                   synced_at=excluded.synced_at
            """,
            (pp, str(header.name or ''),
             float(header.bpm),
             int(header.sample_rate),
             str(header.time_signature),
             str(header.snap_division),
             1 if header.punch_enabled else 0,
             float(header.punch_in_beat),
             float(header.punch_out_beat),
             int(header.pre_roll_bars),
             int(header.post_roll_bars),
             len(tracks), len(clips),
             str(getattr(project, 'launcher_quantize', '1 Bar')),
             str(getattr(project, 'launcher_mode', 'Trigger')),
             json.dumps(extra, ensure_ascii=False),
             time.time()),
        )

    def _sync_tracks(self, conn: sqlite3.Connection, pp: str, project) -> None:
        """Sync all tracks (delete-and-reinsert for simplicity)."""
        conn.execute("DELETE FROM project_tracks WHERE project_path=?", (pp,))
        tracks = getattr(project, 'tracks', []) or []
        for idx, trk in enumerate(tracks):
            extra = {}
            for key in ('sends', 'note_fx_chain', 'audio_fx_chain',
                        'instrument_state', 'comp_regions', 'mpe_config',
                        'plugin_output_routing', 'midi_input', 'sf2_path',
                        'sf2_bank', 'sf2_preset', 'midi_channel',
                        'midi_channel_filter', 'automation_mode',
                        'take_lanes_visible', 'take_lanes_height',
                        'plugin_output_count'):
                val = getattr(trk, key, None)
                if val is not None and val != "" and val != {} and val != []:
                    extra[key] = val
            conn.execute(
                """INSERT INTO project_tracks
                   (project_path, track_id, track_index, kind, name,
                    muted, solo, volume, pan, record_arm,
                    input_pair, output_pair, monitor,
                    plugin_type, instrument_enabled,
                    channel_config, output_target_id, sidechain_source_id,
                    track_group_id, track_group_name, extra_json)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (pp, str(trk.id), idx, str(trk.kind), str(trk.name),
                 1 if trk.muted else 0, 1 if trk.solo else 0,
                 float(trk.volume), float(trk.pan),
                 1 if trk.record_arm else 0,
                 int(trk.input_pair), int(trk.output_pair),
                 1 if trk.monitor else 0,
                 str(trk.plugin_type or ''),
                 1 if trk.instrument_enabled else 0,
                 str(trk.channel_config), str(trk.output_target_id),
                 str(trk.sidechain_source_id),
                 str(trk.track_group_id), str(trk.track_group_name),
                 json.dumps(extra, ensure_ascii=False)),
            )

    def _sync_clips(self, conn: sqlite3.Connection, pp: str, project) -> None:
        """Sync all clips (delete-and-reinsert)."""
        conn.execute("DELETE FROM project_clips WHERE project_path=?", (pp,))
        clips = getattr(project, 'clips', []) or []
        for clip in clips:
            extra = {}
            for key in ('media_id', 'offset_seconds', 'formant',
                        'fade_in_curve', 'fade_out_curve',
                        'crossfade_beats', 'crossfade_curve',
                        'loop_start_beats', 'loop_end_beats',
                        'audio_slices', 'onsets', 'audio_events',
                        'clip_automation', 'stretch_markers', 'render_meta',
                        'launcher_start_quantize', 'launcher_playback_mode',
                        'launcher_release_action', 'launcher_next_action',
                        'launcher_next_action_b', 'launcher_next_action_probability',
                        'launcher_next_action_count', 'launcher_shuffle',
                        'launcher_accent', 'launcher_seed', 'launcher_color',
                        'launcher_crossfade_ms', 'launcher_record_mode',
                        'launcher_record_quantize', 'launcher_alt_clips',
                        'launcher_alt_start_quantize', 'launcher_alt_playback_mode',
                        'launcher_alt_release_action', 'launcher_q_on_loop'):
                val = getattr(clip, key, None)
                if val is not None and val != "" and val != {} and val != [] and val != 0 and val != 0.0:
                    # For audio_events, convert to dicts if needed
                    if key == 'audio_events' and val:
                        try:
                            val = [asdict(e) if hasattr(e, '__dataclass_fields__') else e for e in val]
                        except Exception:
                            pass
                    extra[key] = val
            conn.execute(
                """INSERT INTO project_clips
                   (project_path, clip_id, track_id, kind, start_beats,
                    length_beats, offset_beats, label, source_path, source_bpm,
                    gain, pan, pitch, stretch, stretch_mode,
                    reversed, muted, fade_in_beats, fade_out_beats,
                    launcher_only, take_group_id, take_index,
                    is_comp_active, group_id, extra_json)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (pp, str(clip.id), str(clip.track_id), str(clip.kind),
                 float(clip.start_beats), float(clip.length_beats),
                 float(clip.offset_beats), str(clip.label),
                 str(clip.source_path or ''),
                 float(clip.source_bpm) if clip.source_bpm else None,
                 float(clip.gain), float(clip.pan), float(clip.pitch),
                 float(clip.stretch), str(clip.stretch_mode),
                 1 if clip.reversed else 0, 1 if clip.muted else 0,
                 float(clip.fade_in_beats), float(clip.fade_out_beats),
                 1 if clip.launcher_only else 0,
                 str(clip.take_group_id), int(clip.take_index),
                 1 if clip.is_comp_active else 0,
                 str(clip.group_id),
                 json.dumps(extra, ensure_ascii=False)),
            )

    def _sync_midi_notes(self, conn: sqlite3.Connection, pp: str, project) -> None:
        """Sync all MIDI notes (delete-and-reinsert)."""
        conn.execute("DELETE FROM project_midi_notes WHERE project_path=?", (pp,))
        midi_notes = getattr(project, 'midi_notes', {}) or {}
        for clip_id, notes in midi_notes.items():
            if not notes:
                continue
            rows = []
            for n in notes:
                expr_json = "{}"
                expressions = getattr(n, 'expressions', None)
                if expressions:
                    try:
                        expr_json = json.dumps(expressions, ensure_ascii=False)
                    except Exception:
                        pass
                rows.append((
                    pp, str(clip_id), int(n.pitch),
                    float(n.start_beats), float(n.length_beats),
                    int(n.velocity), int(getattr(n, 'accidental', 0)),
                    1 if getattr(n, 'tie_to_next', False) else 0,
                    expr_json,
                ))
            if rows:
                conn.executemany(
                    """INSERT INTO project_midi_notes
                       (project_path, clip_id, pitch, start_beats, length_beats,
                        velocity, accidental, tie_to_next, expressions_json)
                       VALUES (?,?,?,?,?,?,?,?,?)""",
                    rows,
                )

    def _sync_automation(self, conn: sqlite3.Connection, pp: str, project) -> None:
        """Sync automation lanes."""
        conn.execute("DELETE FROM project_automation WHERE project_path=?", (pp,))
        am_lanes = getattr(project, 'automation_manager_lanes', {}) or {}
        if not am_lanes:
            return
        rows = []
        for param_id, lane_data in am_lanes.items():
            track_id = ""
            if isinstance(lane_data, dict):
                track_id = str(lane_data.get("track_id", ""))
            rows.append((
                pp, str(param_id), track_id,
                json.dumps(lane_data, ensure_ascii=False),
            ))
        if rows:
            conn.executemany(
                """INSERT INTO project_automation
                   (project_path, parameter_id, track_id, lane_json)
                   VALUES (?,?,?,?)""",
                rows,
            )

    # ══════════════════════════════════════════════════════════════
    # Read API (for crash recovery and queries)
    # ══════════════════════════════════════════════════════════════

    def get_project_meta(self, project_path: str) -> Optional[dict]:
        """Get project metadata. Returns None if not found."""
        try:
            conn = self._conn()
            try:
                row = conn.execute(
                    "SELECT * FROM project_meta WHERE project_path=?",
                    (project_path,),
                ).fetchone()
                return dict(row) if row else None
            finally:
                conn.close()
        except Exception:
            return None

    def get_tracks(self, project_path: str) -> List[dict]:
        """Get all tracks for a project, ordered by track_index."""
        try:
            conn = self._conn()
            try:
                rows = conn.execute(
                    "SELECT * FROM project_tracks WHERE project_path=? ORDER BY track_index",
                    (project_path,),
                ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    def get_clips(self, project_path: str, track_id: str = "") -> List[dict]:
        """Get clips, optionally filtered by track_id."""
        try:
            conn = self._conn()
            try:
                if track_id:
                    rows = conn.execute(
                        "SELECT * FROM project_clips WHERE project_path=? AND track_id=? ORDER BY start_beats",
                        (project_path, track_id),
                    ).fetchall()
                else:
                    rows = conn.execute(
                        "SELECT * FROM project_clips WHERE project_path=? ORDER BY start_beats",
                        (project_path,),
                    ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    def get_midi_notes(self, project_path: str, clip_id: str = "") -> List[dict]:
        """Get MIDI notes, optionally filtered by clip_id."""
        try:
            conn = self._conn()
            try:
                if clip_id:
                    rows = conn.execute(
                        "SELECT * FROM project_midi_notes WHERE project_path=? AND clip_id=? ORDER BY start_beats",
                        (project_path, clip_id),
                    ).fetchall()
                else:
                    rows = conn.execute(
                        "SELECT * FROM project_midi_notes WHERE project_path=? ORDER BY clip_id, start_beats",
                        (project_path,),
                    ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    def get_automation(self, project_path: str, parameter_id: str = "") -> List[dict]:
        """Get automation lanes."""
        try:
            conn = self._conn()
            try:
                if parameter_id:
                    rows = conn.execute(
                        "SELECT * FROM project_automation WHERE project_path=? AND parameter_id=?",
                        (project_path, parameter_id),
                    ).fetchall()
                else:
                    rows = conn.execute(
                        "SELECT * FROM project_automation WHERE project_path=?",
                        (project_path,),
                    ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    # ══════════════════════════════════════════════════════════════
    # Query API (cross-project queries)
    # ══════════════════════════════════════════════════════════════

    def list_synced_projects(self) -> List[dict]:
        """List all projects that have been synced."""
        try:
            conn = self._conn()
            try:
                rows = conn.execute(
                    "SELECT project_path, project_name, bpm, track_count, clip_count, synced_at "
                    "FROM project_meta ORDER BY synced_at DESC"
                ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    def get_track_count(self, project_path: str) -> int:
        """Get number of tracks in a project."""
        try:
            conn = self._conn()
            try:
                row = conn.execute(
                    "SELECT COUNT(*) as cnt FROM project_tracks WHERE project_path=?",
                    (project_path,),
                ).fetchone()
                return int(row["cnt"]) if row else 0
            finally:
                conn.close()
        except Exception:
            return 0

    def search_clips_by_source(self, source_path: str) -> List[dict]:
        """Find all clips across all projects using a specific source file."""
        try:
            conn = self._conn()
            try:
                rows = conn.execute(
                    "SELECT * FROM project_clips WHERE source_path LIKE ? ORDER BY project_path",
                    (f"%{source_path}%",),
                ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    # ══════════════════════════════════════════════════════════════
    # Crash Recovery — Reconstruct Project from DB
    # ══════════════════════════════════════════════════════════════

    def has_project(self, project_path: str) -> bool:
        """Check if a project exists in the SQLite mirror.

        v0.0.20.914 — Quick check for crash recovery availability.
        """
        try:
            conn = self._conn()
            try:
                row = conn.execute(
                    "SELECT 1 FROM project_meta WHERE project_path=?",
                    (project_path,),
                ).fetchone()
                return row is not None
            finally:
                conn.close()
        except Exception:
            return False

    def reconstruct_project_dict(self, project_path: str) -> Optional[Dict[str, Any]]:
        """Rebuild a full project dict from SQLite — for Project.from_dict().

        v0.0.20.914 — Crash recovery: wenn die JSON-Datei korrupt oder
        fehlend ist, kann das Projekt aus der letzten SQLite-Spiegelung
        rekonstruiert werden.

        Returns None if project not found in DB.
        The returned dict is compatible with Project.from_dict().
        """
        try:
            conn = self._conn()
            try:
                # ── Meta ──
                meta_row = conn.execute(
                    "SELECT * FROM project_meta WHERE project_path=?",
                    (project_path,),
                ).fetchone()
                if not meta_row:
                    return None
                meta = dict(meta_row)

                # Parse extra_json back into top-level keys
                extra = {}
                try:
                    extra = json.loads(meta.get('extra_json', '{}') or '{}')
                except Exception:
                    pass

                result: Dict[str, Any] = {
                    'launcher_quantize': meta.get('launcher_quantize', '1 Bar'),
                    'launcher_mode': meta.get('launcher_mode', 'Trigger'),
                }
                meta_adapter = Slice0ProjectMetaMirrorAdapter()
                meta_adapter.apply_to_project_dict(meta, extra, result)
                # Merge extra fields back to top-level
                for key in ('ghost_layers', 'notation_marks', 'clip_launcher',
                            'launcher_scene_names', 'launcher_scene_colors',
                            'midi_mappings', 'arranger_collapsed_group_ids',
                            'review_data'):
                    if key in extra:
                        result[key] = extra[key]

                # ── Tracks ──
                track_rows = conn.execute(
                    "SELECT * FROM project_tracks WHERE project_path=? ORDER BY track_index",
                    (project_path,),
                ).fetchall()
                tracks = []
                for tr in track_rows:
                    td = {
                        'id': tr['track_id'],
                        'kind': tr['kind'],
                        'name': tr['name'],
                        'muted': bool(tr['muted']),
                        'solo': bool(tr['solo']),
                        'volume': tr['volume'],
                        'pan': tr['pan'],
                        'record_arm': bool(tr['record_arm']),
                        'input_pair': tr['input_pair'],
                        'output_pair': tr['output_pair'],
                        'monitor': bool(tr['monitor']),
                        'plugin_type': tr['plugin_type'] or None,
                        'instrument_enabled': bool(tr['instrument_enabled']),
                        'channel_config': tr['channel_config'],
                        'output_target_id': tr['output_target_id'],
                        'sidechain_source_id': tr['sidechain_source_id'],
                        'track_group_id': tr['track_group_id'],
                        'track_group_name': tr['track_group_name'],
                    }
                    # Merge extra_json fields
                    try:
                        tex = json.loads(tr['extra_json'] or '{}')
                        td.update(tex)
                    except Exception:
                        pass
                    tracks.append(td)
                result['tracks'] = tracks

                # ── Clips ──
                clip_rows = conn.execute(
                    "SELECT * FROM project_clips WHERE project_path=? ORDER BY start_beats",
                    (project_path,),
                ).fetchall()
                clips = []
                for cr in clip_rows:
                    cd = {
                        'id': cr['clip_id'],
                        'track_id': cr['track_id'],
                        'kind': cr['kind'],
                        'start_beats': cr['start_beats'],
                        'length_beats': cr['length_beats'],
                        'offset_beats': cr['offset_beats'],
                        'label': cr['label'],
                        'source_path': cr['source_path'] or None,
                        'source_bpm': cr['source_bpm'],
                        'gain': cr['gain'],
                        'pan': cr['pan'],
                        'pitch': cr['pitch'],
                        'stretch': cr['stretch'],
                        'stretch_mode': cr['stretch_mode'],
                        'reversed': bool(cr['reversed']),
                        'muted': bool(cr['muted']),
                        'fade_in_beats': cr['fade_in_beats'],
                        'fade_out_beats': cr['fade_out_beats'],
                        'launcher_only': bool(cr['launcher_only']),
                        'take_group_id': cr['take_group_id'],
                        'take_index': cr['take_index'],
                        'is_comp_active': bool(cr['is_comp_active']),
                        'group_id': cr['group_id'],
                    }
                    try:
                        cex = json.loads(cr['extra_json'] or '{}')
                        cd.update(cex)
                    except Exception:
                        pass
                    clips.append(cd)
                result['clips'] = clips

                # ── MIDI Notes ──
                note_rows = conn.execute(
                    "SELECT * FROM project_midi_notes WHERE project_path=? ORDER BY clip_id, start_beats",
                    (project_path,),
                ).fetchall()
                midi_notes: Dict[str, list] = {}
                for nr in note_rows:
                    cid = nr['clip_id']
                    note_dict: Dict[str, Any] = {
                        'pitch': nr['pitch'],
                        'start_beats': nr['start_beats'],
                        'length_beats': nr['length_beats'],
                        'velocity': nr['velocity'],
                    }
                    if nr['accidental']:
                        note_dict['accidental'] = nr['accidental']
                    if nr['tie_to_next']:
                        note_dict['tie_to_next'] = True
                    try:
                        expr = json.loads(nr['expressions_json'] or '{}')
                        if expr:
                            note_dict['expressions'] = expr
                    except Exception:
                        pass
                    midi_notes.setdefault(cid, []).append(note_dict)
                result['midi_notes'] = midi_notes

                # ── Automation ──
                auto_rows = conn.execute(
                    "SELECT * FROM project_automation WHERE project_path=?",
                    (project_path,),
                ).fetchall()
                automation_manager_lanes = {}
                for ar in auto_rows:
                    try:
                        lane_data = json.loads(ar['lane_json'] or '{}')
                        automation_manager_lanes[ar['parameter_id']] = lane_data
                    except Exception:
                        pass
                if automation_manager_lanes:
                    result['automation_manager_lanes'] = automation_manager_lanes

                log.info("[ProjectStateDB] Reconstructed project from DB: %s "
                         "(%d tracks, %d clips, %d midi clip groups)",
                         project_path, len(tracks), len(clips), len(midi_notes))
                return result

            finally:
                conn.close()
        except Exception as e:
            log.warning("[ProjectStateDB] reconstruct_project_dict failed: %s", e)
            return None

    def try_recover_project(self, project_path: str):
        """Attempt crash recovery: rebuild Project object from SQLite.

        v0.0.20.914 — Returns a Project instance or None.
        The caller should use this when JSON load fails.

        Usage:
            pdb = ProjectStateDB.get()
            project = pdb.try_recover_project("/path/to/project")
            if project:
                # recovered from DB!
                ...
        """
        try:
            d = self.reconstruct_project_dict(project_path)
            if d is None:
                return None
            from pydaw.model.project import Project
            project = Project.from_dict(d)
            try:
                Slice0ProjectMetaMirrorAdapter().persistence.normalize_project(project)
            except Exception:
                pass
            log.info("[ProjectStateDB] Crash recovery successful for: %s", project_path)
            return project
        except Exception as e:
            log.warning("[ProjectStateDB] try_recover_project failed: %s", e)
            return None

    # ══════════════════════════════════════════════════════════════
    # Delete / Maintenance
    # ══════════════════════════════════════════════════════════════

    def remove_project(self, project_path: str) -> None:
        """Remove all data for a project."""
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                for table in ("project_meta", "project_tracks", "project_clips",
                              "project_midi_notes", "project_automation"):
                    conn.execute(f"DELETE FROM {table} WHERE project_path=?", (project_path,))
                conn.commit()
            finally:
                conn.close()
        except Exception as e:
            log.debug("[ProjectStateDB] remove_project failed: %s", e)

    def stats(self) -> Dict[str, Any]:
        """Return statistics."""
        result = {}
        try:
            conn = self._conn()
            try:
                for table in ("project_meta", "project_tracks", "project_clips",
                              "project_midi_notes", "project_automation"):
                    row = conn.execute(f"SELECT COUNT(*) as cnt FROM {table}").fetchone()
                    result[table] = int(row["cnt"]) if row else 0
            finally:
                conn.close()
        except Exception:
            pass
        return result
