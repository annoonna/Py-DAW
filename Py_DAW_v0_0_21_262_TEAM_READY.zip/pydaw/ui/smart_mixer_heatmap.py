"""smart_mixer_heatmap.py — Frequency Conflict Heatmap Widget.

v0.0.20.910 — C4.8: Smart Mixer Heatmap UI.

Visualizes frequency conflicts between tracks as an interactive
heatmap matrix (Track × Track × Frequency Band). Uses data from
SmartMixer.frequency_conflict_matrix() or MixAnalyzer.

Can be shown as:
- Standalone dialog (via menu)
- Dock widget in mixer area
- Overlay panel on the mixer strip area
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger(__name__)

try:
    from PyQt6.QtCore import Qt, QRectF, QTimer, pyqtSignal
    from PyQt6.QtGui import QColor, QPainter, QFont, QBrush, QPen, QLinearGradient
    from PyQt6.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
        QScrollArea, QFrame, QToolTip, QSizePolicy, QDialog,
        QComboBox, QCheckBox, QGroupBox,
    )
    _HAS_QT = True
except ImportError:
    _HAS_QT = False


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

BAND_LABELS = {
    "sub":      "Sub\n20-60",
    "low":      "Low\n60-250",
    "low_mid":  "LoMid\n250-500",
    "mid":      "Mid\n500-2k",
    "high_mid": "HiMid\n2k-6k",
    "high":     "High\n6k-12k",
    "air":      "Air\n12k-20k",
}

BAND_SHORT = ["Sub", "Low", "LoMid", "Mid", "HiMid", "High", "Air"]

# Heatmap colors: green (no conflict) → yellow → red (severe)
HEATMAP_COLORS = [
    (0.0,  QColor(40, 180, 60, 80)),     # green — clean
    (0.3,  QColor(180, 200, 40, 120)),    # yellow-green
    (0.5,  QColor(255, 200, 0, 160)),     # yellow — moderate
    (0.7,  QColor(255, 140, 0, 200)),     # orange
    (1.0,  QColor(255, 60, 30, 240)),     # red — severe
] if _HAS_QT else []

CELL_SIZE = 44
LABEL_WIDTH = 80
HEADER_HEIGHT = 50


# ---------------------------------------------------------------------------
# Heatmap Canvas Widget
# ---------------------------------------------------------------------------

if _HAS_QT:
    class _HeatmapCanvas(QWidget):
        """Custom painted heatmap grid."""

        cell_hovered = pyqtSignal(str, str, str, float)  # track_a, track_b, band, score
        cell_clicked = pyqtSignal(str, str, str, float)

        def __init__(self, parent=None):
            super().__init__(parent)
            self._track_names: List[str] = []
            self._band_names: List[str] = []
            self._heatmap: List[List[List[float]]] = []
            self._suggestions: Dict[tuple, str] = {}
            self._hover_cell: Optional[Tuple[int, int, int]] = None
            self.setMouseTracking(True)
            self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

        def set_data(
            self,
            track_names: List[str],
            band_names: List[str],
            heatmap: List[List[List[float]]],
            suggestions: Optional[Dict[tuple, str]] = None,
        ) -> None:
            """Set heatmap data and repaint."""
            self._track_names = list(track_names)
            self._band_names = list(band_names)
            self._heatmap = heatmap
            self._suggestions = suggestions or {}
            n_tracks = len(track_names)
            n_bands = len(band_names)
            w = LABEL_WIDTH + n_tracks * n_bands * CELL_SIZE + 20
            h = HEADER_HEIGHT + n_tracks * CELL_SIZE + 20
            self.setMinimumSize(max(200, w), max(100, h))
            self.update()

        def paintEvent(self, event) -> None:
            """Paint the heatmap grid."""
            if not self._track_names or not self._heatmap:
                return

            painter = QPainter(self)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)

            n_tracks = len(self._track_names)
            n_bands = len(self._band_names)

            # Font
            font = QFont("Segoe UI", 8)
            font_small = QFont("Segoe UI", 7)
            painter.setFont(font)

            # Draw column headers (Track B names repeated per band group)
            painter.setFont(font_small)
            x_start = LABEL_WIDTH

            # Band group headers
            for bi, band in enumerate(self._band_names):
                bx = x_start + bi * (n_tracks * CELL_SIZE // n_bands + CELL_SIZE)
                label = BAND_SHORT[bi] if bi < len(BAND_SHORT) else band
                painter.setPen(QPen(QColor(180, 180, 180)))
                painter.drawText(
                    QRectF(bx, 2, CELL_SIZE * 2, HEADER_HEIGHT - 4),
                    Qt.AlignmentFlag.AlignCenter,
                    label,
                )

            # Draw rows (Track A)
            painter.setFont(font)
            for i in range(n_tracks):
                y = HEADER_HEIGHT + i * CELL_SIZE
                name = self._track_names[i]
                # Truncate long names
                disp = name[:10] + "…" if len(name) > 10 else name

                # Row label
                painter.setPen(QPen(QColor(200, 200, 200)))
                painter.drawText(
                    QRectF(4, y, LABEL_WIDTH - 8, CELL_SIZE),
                    Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignRight,
                    disp,
                )

                # Draw cells for this row: each track_b × each band
                for j in range(n_tracks):
                    for k in range(n_bands):
                        x = LABEL_WIDTH + (j * n_bands + k) * CELL_SIZE // max(1, n_bands - 1)
                        # Simplified: flatten into j*n_bands+k columns
                        x = LABEL_WIDTH + (j * n_bands + k) * (CELL_SIZE // 2 + 2)

                        if i == j:
                            # Diagonal — skip (same track)
                            color = QColor(60, 60, 60, 40)
                        elif i < len(self._heatmap) and j < len(self._heatmap[i]) and k < len(self._heatmap[i][j]):
                            score = self._heatmap[i][j][k]
                            color = self._score_to_color(score)
                        else:
                            color = QColor(50, 50, 50, 30)

                        rect = QRectF(x, y, CELL_SIZE // 2, CELL_SIZE - 2)
                        painter.setBrush(QBrush(color))
                        painter.setPen(QPen(QColor(80, 80, 80), 0.5))
                        painter.drawRoundedRect(rect, 3, 3)

                        # Hover highlight
                        if self._hover_cell == (i, j, k):
                            painter.setBrush(QBrush(QColor(255, 255, 255, 40)))
                            painter.drawRoundedRect(rect, 3, 3)

            painter.end()

        def _score_to_color(self, score: float) -> QColor:
            """Map conflict score (0-1) to heatmap color."""
            score = max(0.0, min(1.0, score))
            if not HEATMAP_COLORS:
                gray = int(255 * (1.0 - score))
                return QColor(255 - gray, gray, 0, 180)

            # Interpolate between color stops
            for idx in range(1, len(HEATMAP_COLORS)):
                t0, c0 = HEATMAP_COLORS[idx - 1]
                t1, c1 = HEATMAP_COLORS[idx]
                if score <= t1:
                    frac = (score - t0) / max(0.001, t1 - t0)
                    r = int(c0.red() + frac * (c1.red() - c0.red()))
                    g = int(c0.green() + frac * (c1.green() - c0.green()))
                    b = int(c0.blue() + frac * (c1.blue() - c0.blue()))
                    a = int(c0.alpha() + frac * (c1.alpha() - c0.alpha()))
                    return QColor(r, g, b, a)

            return HEATMAP_COLORS[-1][1]

        def mouseMoveEvent(self, event) -> None:
            """Track hover for tooltip."""
            try:
                pos = event.position() if hasattr(event, 'position') else event.pos()
                x, y = pos.x(), pos.y()
                n_tracks = len(self._track_names)
                n_bands = len(self._band_names)
                if n_tracks == 0 or n_bands == 0:
                    return

                row = int((y - HEADER_HEIGHT) / CELL_SIZE)
                col_total = int((x - LABEL_WIDTH) / (CELL_SIZE // 2 + 2))
                if row < 0 or row >= n_tracks or col_total < 0:
                    self._hover_cell = None
                    self.update()
                    return

                j = col_total // n_bands
                k = col_total % n_bands
                if j >= n_tracks or k >= n_bands:
                    self._hover_cell = None
                    self.update()
                    return

                self._hover_cell = (row, j, k)
                self.update()

                # Show tooltip
                if row != j and row < len(self._heatmap) and j < len(self._heatmap[row]):
                    if k < len(self._heatmap[row][j]):
                        score = self._heatmap[row][j][k]
                        band = self._band_names[k] if k < len(self._band_names) else "?"
                        tip = (
                            f"{self._track_names[row]} ↔ {self._track_names[j]}\n"
                            f"Band: {band}\n"
                            f"Konflikt: {score:.0%}"
                        )
                        sug = self._suggestions.get((row, j, k), "")
                        if sug:
                            tip += f"\n💡 {sug}"
                        QToolTip.showText(event.globalPosition().toPoint(), tip, self)
            except Exception:
                pass

        def mousePressEvent(self, event) -> None:
            """Emit clicked signal."""
            if self._hover_cell:
                i, j, k = self._hover_cell
                if i < len(self._track_names) and j < len(self._track_names):
                    band = self._band_names[k] if k < len(self._band_names) else ""
                    score = 0.0
                    if i < len(self._heatmap) and j < len(self._heatmap[i]):
                        if k < len(self._heatmap[i][j]):
                            score = self._heatmap[i][j][k]
                    self.cell_clicked.emit(
                        self._track_names[i], self._track_names[j],
                        band, score,
                    )


    # ------------------------------------------------------------------
    # Smart Mixer Heatmap Panel
    # ------------------------------------------------------------------

    class SmartMixerHeatmapPanel(QWidget):
        """Smart Mixer Heatmap Panel — embeddable widget.

        Shows frequency conflict heatmap + gain recommendations.
        """

        status_message = pyqtSignal(str, int)

        def __init__(self, parent=None, project_service=None):
            super().__init__(parent)
            self._project_service = project_service
            self._smart_mixer = None
            self._mix_analyzer = None
            self._last_result = None
            self._init_ui()

        def _init_ui(self) -> None:
            layout = QVBoxLayout(self)
            layout.setContentsMargins(4, 4, 4, 4)
            layout.setSpacing(4)

            # Header
            header = QHBoxLayout()
            title = QLabel("<b>🎛️ Smart Mixer — Frequenz-Heatmap</b>")
            header.addWidget(title)
            header.addStretch()

            self._btn_analyze = QPushButton("🔍 Analysieren")
            self._btn_analyze.setToolTip(
                "Mix analysieren und Frequenz-Konflikte erkennen"
            )
            self._btn_analyze.clicked.connect(self._on_analyze)
            header.addWidget(self._btn_analyze)

            self._btn_auto_gain = QPushButton("⚡ Auto-Gain")
            self._btn_auto_gain.setToolTip(
                "Automatisches Gain-Staging anwenden"
            )
            self._btn_auto_gain.clicked.connect(self._on_auto_gain)
            self._btn_auto_gain.setEnabled(False)
            header.addWidget(self._btn_auto_gain)

            layout.addLayout(header)

            # Status line
            self._status = QLabel("Noch keine Analyse durchgeführt.")
            self._status.setStyleSheet("color: #888; font-size: 11px;")
            layout.addWidget(self._status)

            # Heatmap canvas in scroll area
            self._canvas = _HeatmapCanvas()
            scroll = QScrollArea()
            scroll.setWidget(self._canvas)
            scroll.setWidgetResizable(True)
            scroll.setMinimumHeight(180)
            layout.addWidget(scroll, stretch=1)

            # Suggestions area
            self._suggestions_label = QLabel("")
            self._suggestions_label.setWordWrap(True)
            self._suggestions_label.setStyleSheet(
                "font-size: 11px; padding: 4px; "
                "background: rgba(255,255,255,0.03); border-radius: 4px;"
            )
            self._suggestions_label.hide()
            layout.addWidget(self._suggestions_label)

            # Legend
            legend = QHBoxLayout()
            legend.addWidget(QLabel("<small>Konflikt:</small>"))
            for label, color_hex in [
                ("Gering", "#28B43C"), ("Mittel", "#FFC800"),
                ("Stark", "#FF8C00"), ("Kritisch", "#FF3C1E"),
            ]:
                dot = QLabel(f"<span style='color:{color_hex};'>●</span> {label}")
                dot.setStyleSheet("font-size: 10px;")
                legend.addWidget(dot)
            legend.addStretch()
            layout.addLayout(legend)

        def _on_analyze(self) -> None:
            """Run mix analysis on current project tracks."""
            try:
                self._ensure_services()

                ps = self._project_service
                if not ps:
                    self._status.setText("Kein Projekt-Service verfügbar.")
                    return

                ctx = getattr(ps, 'ctx', None)
                project = getattr(ctx, 'project', None) if ctx else None
                if not project or not getattr(project, 'tracks', None):
                    self._status.setText("Kein Projekt oder keine Tracks geladen.")
                    return

                tracks = project.tracks or []
                self._status.setText(f"Analysiere {len(tracks)} Tracks...")

                # Build track data for SmartMixer
                tracks_data = []
                for t in tracks:
                    tracks_data.append({
                        "track_id": str(getattr(t, 'id', '')),
                        "name": str(getattr(t, 'name', 'Track')),
                        "volume": float(getattr(t, 'volume', 0.8)),
                        "peak_db": float(getattr(t, 'peak_db', -6.0)),
                        "rms_db": float(getattr(t, 'rms_db', -18.0)),
                    })

                # Run analysis (without spectral data for now — needs audio buffers)
                sm = self._smart_mixer  # module reference
                # Use compute_auto_gain from existing smart_mixer module
                # Analyze tracks individually first
                from pydaw.services.smart_mixer import TrackAnalysis as _TA
                track_analyses = []
                for td in tracks_data:
                    ta = _TA()
                    ta.track_id = td["track_id"]
                    ta.name = td["name"]
                    ta.lufs = td.get("rms_db", -18.0)
                    ta.peak_db = td.get("peak_db", -6.0)
                    ta.rms_db = td.get("rms_db", -18.0)
                    track_analyses.append(ta)

                auto_gains = sm.compute_auto_gain(track_analyses)
                recommendations = sm.generate_recommendations(track_analyses)
                self._last_analyses = track_analyses
                self._last_gains = auto_gains
                self._btn_auto_gain.setEnabled(True)

                # Update UI
                self._status.setText(
                    f"✅ {len(tracks)} Tracks analysiert. "
                    f"{len(recommendations)} Empfehlungen."
                )

                # Show recommendations
                if recommendations:
                    text = "<br>".join(f"💡 {r}" for r in recommendations[:8])
                    self._suggestions_label.setText(text)
                    self._suggestions_label.show()
                else:
                    self._suggestions_label.hide()

                # Show gain recommendations
                if auto_gains:
                    adjustments = [
                        (tid, db) for tid, db in auto_gains.items()
                        if abs(db) > 0.5
                    ]
                    if adjustments:
                        # Find names
                        id_to_name = {td["track_id"]: td["name"] for td in tracks_data}
                        gain_text = "<br>".join(
                            f"🎚️ {id_to_name.get(tid, tid)}: {db:+.1f} dB"
                            for tid, db in adjustments[:5]
                        )
                        current = self._suggestions_label.text()
                        self._suggestions_label.setText(
                            current + "<br><br><b>Gain-Empfehlungen:</b><br>" + gain_text
                        )
                        self._suggestions_label.show()

                self.status_message.emit(
                    f"Smart Mixer: {len(tracks)} Tracks analysiert", 3000
                )

            except Exception as e:
                log.warning("Smart Mixer analysis error: %s", e)
                self._status.setText(f"Fehler: {e}")

        def _on_auto_gain(self) -> None:
            """Apply auto gain-staging to project."""
            try:
                self._ensure_services()

                ps = self._project_service
                if not ps:
                    return
                ctx = getattr(ps, 'ctx', None)
                project = getattr(ctx, 'project', None) if ctx else None
                if not project:
                    return

                results = self._smart_mixer.compute_auto_gain(
                    getattr(self, '_last_analyses', [])
                )
                applied = sum(1 for db in results.values() if abs(db) > 0.3)
                # Apply to project tracks
                for t in (project.tracks or []):
                    tid = str(getattr(t, 'id', ''))
                    gain_db = results.get(tid, 0.0)
                    if abs(gain_db) > 0.3:
                        import math
                        old_vol = getattr(t, 'volume', 0.8)
                        new_vol = min(1.0, old_vol * (10 ** (gain_db / 20.0)))
                        t.volume = new_vol
                self._status.setText(
                    f"⚡ Auto-Gain angewendet: {applied} Tracks angepasst."
                )
                self.status_message.emit(
                    f"Auto-Gain: {applied} Tracks angepasst", 3000
                )

                # Refresh mixer UI
                try:
                    main_win = self.parent()
                    while main_win and not hasattr(main_win, 'mixer'):
                        main_win = main_win.parent()
                    mixer = getattr(main_win, 'mixer', None)
                    if mixer and hasattr(mixer, 'update'):
                        mixer.update()
                except Exception:
                    pass

            except Exception as e:
                log.warning("Auto-gain error: %s", e)
                self._status.setText(f"Fehler: {e}")

        def _ensure_services(self) -> None:
            """Lazy-init SmartMixer and MixAnalyzer."""
            if self._smart_mixer is None:
                try:
                    import pydaw.services.smart_mixer as _sm
                    self._smart_mixer = _sm
                except ImportError:
                    log.warning("SmartMixer not available")
            if self._mix_analyzer is None:
                try:
                    from pydaw.services.mix_analysis import MixAnalyzer
                    self._mix_analyzer = MixAnalyzer()
                except ImportError:
                    pass


    # ------------------------------------------------------------------
    # Standalone Dialog
    # ------------------------------------------------------------------

    class SmartMixerDialog(QDialog):
        """Standalone dialog for Smart Mixer Heatmap."""

        def __init__(self, parent=None, project_service=None):
            super().__init__(parent)
            self.setWindowTitle("🎛️ Smart Mixer — Frequenz-Analyse")
            self.setMinimumSize(600, 400)
            self.resize(800, 500)

            layout = QVBoxLayout(self)
            self._panel = SmartMixerHeatmapPanel(
                parent=self, project_service=project_service
            )
            layout.addWidget(self._panel)

            # Close button
            btn_close = QPushButton("Schließen")
            btn_close.clicked.connect(self.accept)
            layout.addWidget(btn_close, alignment=Qt.AlignmentFlag.AlignRight)
