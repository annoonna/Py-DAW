"""video_ki_arranger.py — Video-KI Arranger Integration for VK1-VK6 (v0.0.20.951).

Integrates Video-KI analysis results into the DAW Arranger:
  VK1: Scene markers in Arranger at every scene change
  VK2: Dialog regions as markers + Auto-Duck automation
  VK3: Mood tags per scene + preset suggestions + scene bar
  VK4: Subtitle track in Arranger + searchable transcription
  VK5: Beat-to-Cut suggestions + BPM per scene
  VK6: ADR/Foley Cue-Sheet generation (PDF, CSV, markers)

Architecture:
  VideoKIArrangerService connects VideoKIService analysis results
  with the Arranger timeline. It generates markers, automation
  lanes, and visual overlays from scene/dialog/mood data.

What NO other DAW has:
  - KI-generated scene markers in a music DAW Arranger
  - Auto-Duck automation from dialog detection
  - Mood-based preset suggestions per video scene
  - ADR/Foley cue sheets generated from video analysis

Usage:
    svc = VideoKIArrangerService(project_service)
    svc.generate_scene_markers(video_path, bpm=120)
    svc.generate_auto_duck(video_path, duck_db=-12, fade_ms=200)
    svc.generate_cue_sheet(video_path, output_path)
"""

from __future__ import annotations

import csv
import json
import logging
import math
import os
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

log = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# Data structures
# ═══════════════════════════════════════════════════════════════

@dataclass
class SceneMarker:
    """A scene boundary marker for the Arranger."""
    marker_id: str = ""
    beat: float = 0.0
    time_seconds: float = 0.0
    label: str = ""
    color: str = "#4488ff"
    scene_index: int = 0
    mood_tags: List[str] = field(default_factory=list)
    duration_seconds: float = 0.0

    def __post_init__(self):
        if not self.marker_id:
            self.marker_id = f"sm_{uuid.uuid4().hex[:8]}"

    def to_dict(self) -> dict:
        return {
            "marker_id": self.marker_id,
            "beat": self.beat,
            "time_seconds": self.time_seconds,
            "label": self.label,
            "color": self.color,
            "scene_index": self.scene_index,
            "mood_tags": self.mood_tags,
            "duration_seconds": self.duration_seconds,
        }


@dataclass
class DialogRegionMarker:
    """A dialog region marker with auto-duck info."""
    marker_id: str = ""
    start_beat: float = 0.0
    end_beat: float = 0.0
    start_seconds: float = 0.0
    end_seconds: float = 0.0
    label: str = "🗣 Dialog"
    speaker: str = ""
    duck_automation: List[Tuple[float, float]] = field(default_factory=list)

    def __post_init__(self):
        if not self.marker_id:
            self.marker_id = f"dlg_{uuid.uuid4().hex[:8]}"

    def to_dict(self) -> dict:
        return {
            "marker_id": self.marker_id,
            "start_beat": self.start_beat,
            "end_beat": self.end_beat,
            "start_seconds": self.start_seconds,
            "end_seconds": self.end_seconds,
            "label": self.label,
            "speaker": self.speaker,
        }


@dataclass
class MoodSuggestion:
    """A mood-based music suggestion for a scene."""
    scene_index: int = 0
    mood_tags: List[str] = field(default_factory=list)
    suggested_preset: str = ""
    suggested_bpm: int = 120
    suggested_key: str = "C"
    color: str = "#888888"
    confidence: float = 0.0

    def to_dict(self) -> dict:
        return {
            "scene_index": self.scene_index,
            "mood_tags": self.mood_tags,
            "suggested_preset": self.suggested_preset,
            "suggested_bpm": self.suggested_bpm,
            "suggested_key": self.suggested_key,
            "color": self.color,
            "confidence": self.confidence,
        }


@dataclass
class BeatCutSuggestion:
    """A suggestion to align a video cut to a beat."""
    scene_index: int = 0
    original_time: float = 0.0    # seconds (scene boundary)
    nearest_beat: float = 0.0     # beat position
    nearest_bar: float = 0.0      # bar position
    offset_ms: float = 0.0       # how far from nearest beat
    suggested_bpm: int = 0        # BPM suggestion for this scene

    def to_dict(self) -> dict:
        return {
            "scene_index": self.scene_index,
            "original_time": self.original_time,
            "nearest_beat": self.nearest_beat,
            "nearest_bar": self.nearest_bar,
            "offset_ms": self.offset_ms,
            "suggested_bpm": self.suggested_bpm,
        }


@dataclass
class CueSheetEntry:
    """An ADR/Foley cue sheet entry."""
    cue_id: str = ""
    timecode: str = ""
    time_seconds: float = 0.0
    duration: float = 0.0
    cue_type: str = ""   # ADR, Foley, SFX, Music
    description: str = ""
    scene: str = ""
    character: str = ""
    notes: str = ""

    def __post_init__(self):
        if not self.cue_id:
            self.cue_id = f"CUE-{uuid.uuid4().hex[:6].upper()}"


# ═══════════════════════════════════════════════════════════════
# Mood → Music mapping
# ═══════════════════════════════════════════════════════════════

_MOOD_PRESETS: Dict[str, Dict[str, Any]] = {
    "dark": {"preset": "AETERNA Dark Pad", "bpm": 70, "key": "Dm",
             "color": "#2a1a3a"},
    "tense": {"preset": "AETERNA Tension Drone", "bpm": 80, "key": "Em",
              "color": "#4a1a1a"},
    "bright": {"preset": "AETERNA Bright Keys", "bpm": 120, "key": "C",
               "color": "#4a4a1a"},
    "happy": {"preset": "AETERNA Happy Pluck", "bpm": 128, "key": "G",
              "color": "#1a4a2a"},
    "sad": {"preset": "AETERNA Melancholy Strings", "bpm": 72, "key": "Am",
            "color": "#1a2a4a"},
    "epic": {"preset": "AETERNA Epic Brass", "bpm": 140, "key": "D",
             "color": "#4a2a1a"},
    "calm": {"preset": "AETERNA Ambient Pad", "bpm": 85, "key": "F",
             "color": "#2a3a2a"},
    "action": {"preset": "AETERNA Action Synth", "bpm": 150, "key": "Em",
               "color": "#4a1a2a"},
    "romantic": {"preset": "AETERNA Romantic Piano", "bpm": 90, "key": "Ab",
                 "color": "#3a1a3a"},
    "mysterious": {"preset": "AETERNA Mystery Texture", "bpm": 95, "key": "Bbm",
                   "color": "#1a1a3a"},
    "indoor": {"preset": "AETERNA Room Tone", "bpm": 100, "key": "C",
               "color": "#3a3a3a"},
    "outdoor": {"preset": "AETERNA Nature Ambience", "bpm": 110, "key": "G",
                "color": "#2a4a2a"},
}


def _seconds_to_tc(seconds: float, fps: float = 24.0) -> str:
    """Convert seconds to SMPTE timecode."""
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    f = int((seconds % 1) * fps)
    return f"{h:02d}:{m:02d}:{s:02d}:{f:02d}"


# ═══════════════════════════════════════════════════════════════
# VK1: Scene Markers
# ═══════════════════════════════════════════════════════════════

def generate_scene_markers(video_path: str,
                            bpm: float = 120.0,
                            fps: float = 24.0
                            ) -> List[SceneMarker]:
    """VK1: Generate Arranger markers at every scene change.
    
    Uses VideoKIService for scene detection, then converts
    scene boundaries to beat positions.
    """
    markers = []
    try:
        from pydaw.services.video_ki_service import VideoKIService
        svc = VideoKIService()
        svc.analyze_all(video_path)

        for i, scene in enumerate(svc.scenes):
            beat = scene.start_seconds * bpm / 60.0
            duration = scene.duration

            # Get mood for color
            mood = svc.get_mood(i)
            mood_tags = []
            color = "#4488ff"
            if mood:
                mood_tags = mood.mood_tags[:3] if hasattr(mood, 'mood_tags') else []
                # Color from dominant color
                if hasattr(scene, 'dominant_color'):
                    r, g, b = scene.dominant_color
                    color = f"#{r:02x}{g:02x}{b:02x}"

            marker = SceneMarker(
                beat=beat,
                time_seconds=scene.start_seconds,
                label=f"Szene {i + 1}: {_seconds_to_tc(scene.start_seconds, fps)}",
                color=color,
                scene_index=i,
                mood_tags=mood_tags,
                duration_seconds=duration,
            )
            markers.append(marker)

    except Exception as exc:
        log.error("Scene marker generation: %s", exc)

    return markers


# ═══════════════════════════════════════════════════════════════
# VK2: Dialog Detection → Auto-Duck
# ═══════════════════════════════════════════════════════════════

def generate_dialog_markers(video_path: str,
                             bpm: float = 120.0
                             ) -> List[DialogRegionMarker]:
    """VK2: Generate dialog region markers."""
    markers = []
    try:
        from pydaw.services.video_ki_service import VideoKIService
        svc = VideoKIService()
        svc.analyze_all(video_path)

        for dlg in svc.dialogs:
            start_beat = dlg.start_seconds * bpm / 60.0
            end_beat = dlg.end_seconds * bpm / 60.0

            marker = DialogRegionMarker(
                start_beat=start_beat,
                end_beat=end_beat,
                start_seconds=dlg.start_seconds,
                end_seconds=dlg.end_seconds,
                label=f"🗣 Dialog ({dlg.duration:.1f}s)",
            )
            markers.append(marker)

    except Exception as exc:
        log.error("Dialog marker generation: %s", exc)

    return markers


def generate_auto_duck(video_path: str,
                        bpm: float = 120.0,
                        duck_db: float = -12.0,
                        fade_beats: float = 0.25,
                        threshold: float = 0.3
                        ) -> List[Tuple[float, float]]:
    """VK2: Generate automation points for music ducking.
    
    Returns list of (beat, gain_linear) pairs for automation lane.
    
    Args:
        video_path: Video to analyze
        bpm: Current BPM
        duck_db: How much to duck (negative dB)
        fade_beats: Fade in/out duration in beats
        threshold: Dialog detection threshold
    """
    points = []
    try:
        from pydaw.services.video_ki_service import VideoKIService
        svc = VideoKIService()
        svc.analyze_all(video_path)

        duck_linear = 10 ** (duck_db / 20.0)

        # Start at full volume
        points.append((0.0, 1.0))

        for dlg in svc.dialogs:
            start_beat = dlg.start_seconds * bpm / 60.0
            end_beat = dlg.end_seconds * bpm / 60.0

            # Fade down before dialog
            fade_start = max(0, start_beat - fade_beats)
            points.append((fade_start, 1.0))
            points.append((start_beat, duck_linear))

            # Stay ducked during dialog
            points.append((end_beat, duck_linear))

            # Fade back up after dialog
            fade_end = end_beat + fade_beats
            points.append((fade_end, 1.0))

    except Exception as exc:
        log.error("Auto-duck generation: %s", exc)

    return points


# ═══════════════════════════════════════════════════════════════
# VK3: Mood Analysis → Suggestions
# ═══════════════════════════════════════════════════════════════

def generate_mood_suggestions(video_path: str,
                                bpm: float = 120.0
                                ) -> List[MoodSuggestion]:
    """VK3: Generate mood-based music suggestions per scene."""
    suggestions = []
    try:
        from pydaw.services.video_ki_service import VideoKIService
        svc = VideoKIService()
        svc.analyze_all(video_path)

        for i, scene in enumerate(svc.scenes):
            mood = svc.get_mood(i)
            if not mood:
                continue

            tags = mood.mood_tags[:3] if hasattr(mood, 'mood_tags') else []
            primary_tag = tags[0] if tags else "calm"

            preset_info = _MOOD_PRESETS.get(
                primary_tag, _MOOD_PRESETS["calm"])

            suggestion = MoodSuggestion(
                scene_index=i,
                mood_tags=tags,
                suggested_preset=preset_info["preset"],
                suggested_bpm=preset_info["bpm"],
                suggested_key=preset_info["key"],
                color=preset_info["color"],
                confidence=getattr(mood, 'confidence', 0.5),
            )
            suggestions.append(suggestion)

    except Exception as exc:
        log.error("Mood suggestion generation: %s", exc)

    return suggestions


def generate_scene_color_bar(video_path: str,
                               bpm: float = 120.0
                               ) -> List[Dict[str, Any]]:
    """VK3: Generate color-coded scene bar data for Arranger.
    
    Returns list of {start_beat, end_beat, color, label, mood_tags}
    for painting a mood-colored bar in the Arranger header.
    """
    bars = []
    try:
        from pydaw.services.video_ki_service import VideoKIService
        svc = VideoKIService()
        svc.analyze_all(video_path)

        for i, scene in enumerate(svc.scenes):
            start_beat = scene.start_seconds * bpm / 60.0
            end_beat = (scene.start_seconds + scene.duration) * bpm / 60.0

            mood = svc.get_mood(i)
            tags = mood.mood_tags[:2] if mood and hasattr(mood, 'mood_tags') else []
            primary = tags[0] if tags else "calm"

            color = _MOOD_PRESETS.get(primary, {}).get("color", "#333333")

            bars.append({
                "start_beat": start_beat,
                "end_beat": end_beat,
                "color": color,
                "label": f"S{i + 1}",
                "mood_tags": tags,
            })

    except Exception as exc:
        log.error("Scene color bar: %s", exc)

    return bars


# ═══════════════════════════════════════════════════════════════
# VK4: Subtitle Track Integration
# ═══════════════════════════════════════════════════════════════

def generate_subtitle_blocks(video_path: str,
                               bpm: float = 120.0
                               ) -> List[Dict[str, Any]]:
    """VK4: Generate subtitle text blocks for Arranger display.
    
    Returns list of {start_beat, end_beat, text, word_ids}
    """
    blocks = []
    try:
        from pydaw.services.video_whisper_service import WhisperService
        svc = WhisperService.instance()
        transcript = svc.get_transcript(video_path)
        if not transcript:
            return blocks

        for seg in transcript.segments:
            active = seg.active_words
            if not active:
                continue
            start_beat = seg.start * bpm / 60.0
            end_beat = seg.end * bpm / 60.0
            text = " ".join(w.word for w in active)

            blocks.append({
                "start_beat": start_beat,
                "end_beat": end_beat,
                "text": text,
                "word_ids": [w.word_id for w in active],
            })

    except Exception as exc:
        log.debug("Subtitle blocks: %s", exc)

    return blocks


def search_transcript(video_path: str,
                       query: str) -> List[Dict[str, Any]]:
    """VK4: Search transcript for a word/phrase.
    
    Returns list of {word, start, end, beat_start, beat_end, context}
    """
    results = []
    try:
        from pydaw.services.video_whisper_service import WhisperService
        svc = WhisperService.instance()
        transcript = svc.get_transcript(video_path)
        if not transcript:
            return results

        query_lower = query.lower()
        all_words = transcript.all_words

        for i, w in enumerate(all_words):
            if query_lower in w.word.lower():
                # Build context (5 words before/after)
                ctx_start = max(0, i - 5)
                ctx_end = min(len(all_words), i + 6)
                context = " ".join(
                    aw.word for aw in all_words[ctx_start:ctx_end])

                results.append({
                    "word": w.word,
                    "start": w.start,
                    "end": w.end,
                    "word_id": w.word_id,
                    "context": context,
                })

    except Exception as exc:
        log.debug("Transcript search: %s", exc)

    return results


def generate_chapter_titles(video_path: str) -> List[Dict[str, Any]]:
    """VK4: Auto-generate chapter titles from transcript content."""
    chapters = []
    try:
        from pydaw.services.video_whisper_service import WhisperService
        svc = WhisperService.instance()
        transcript = svc.get_transcript(video_path)
        if not transcript:
            return chapters

        # Use first few words of each segment group as chapter title
        seg_group_size = max(1, len(transcript.segments) // 10)  # ~10 chapters
        for i in range(0, len(transcript.segments), seg_group_size):
            group = transcript.segments[i:i + seg_group_size]
            if not group:
                continue

            first_seg = group[0]
            words = first_seg.active_words[:5]
            title = " ".join(w.word for w in words)
            if len(title) > 40:
                title = title[:37] + "..."

            chapters.append({
                "index": len(chapters) + 1,
                "time": first_seg.start,
                "title": title,
            })

    except Exception as exc:
        log.debug("Chapter title generation: %s", exc)

    return chapters


# ═══════════════════════════════════════════════════════════════
# VK5: Beat-to-Cut Suggestions
# ═══════════════════════════════════════════════════════════════

def generate_beat_cut_suggestions(video_path: str,
                                    bpm: float = 120.0
                                    ) -> List[BeatCutSuggestion]:
    """VK5: Suggest how to align video cuts to beats."""
    suggestions = []
    try:
        from pydaw.services.video_ki_service import VideoKIService
        svc = VideoKIService()
        svc.analyze_all(video_path)

        beat_duration = 60.0 / bpm  # seconds per beat
        bar_duration = beat_duration * 4  # seconds per bar (4/4)

        for i, scene in enumerate(svc.scenes):
            t = scene.start_seconds
            exact_beat = t / beat_duration
            nearest_beat = round(exact_beat)
            nearest_bar = round(exact_beat / 4) * 4

            offset_ms = abs(t - nearest_beat * beat_duration) * 1000

            # Suggest BPM where this cut falls exactly on a beat
            if t > 0:
                # Find BPM where t is an integer number of beats
                for test_bpm in range(60, 200):
                    test_beat_dur = 60.0 / test_bpm
                    beats_at_t = t / test_beat_dur
                    if abs(beats_at_t - round(beats_at_t)) < 0.02:
                        suggested_bpm = test_bpm
                        break
                else:
                    suggested_bpm = int(round(bpm))
            else:
                suggested_bpm = int(round(bpm))

            suggestions.append(BeatCutSuggestion(
                scene_index=i,
                original_time=t,
                nearest_beat=nearest_beat,
                nearest_bar=nearest_bar,
                offset_ms=offset_ms,
                suggested_bpm=suggested_bpm,
            ))

    except Exception as exc:
        log.error("Beat-cut suggestions: %s", exc)

    return suggestions


# ═══════════════════════════════════════════════════════════════
# VK6: ADR/Foley Cue-Sheet
# ═══════════════════════════════════════════════════════════════

def generate_cue_sheet(video_path: str,
                        fps: float = 24.0
                        ) -> List[CueSheetEntry]:
    """VK6: Generate ADR/Foley cue sheet entries from video analysis."""
    entries = []
    try:
        from pydaw.services.video_ki_service import VideoKIService
        svc = VideoKIService()
        svc.analyze_all(video_path)

        cue_num = 1

        # Dialog regions → ADR cues
        for dlg in svc.dialogs:
            entry = CueSheetEntry(
                cue_id=f"ADR-{cue_num:03d}",
                timecode=_seconds_to_tc(dlg.start_seconds, fps),
                time_seconds=dlg.start_seconds,
                duration=dlg.duration,
                cue_type="ADR",
                description=f"Dialog {dlg.duration:.1f}s",
                scene=f"Scene {_find_scene_at(svc, dlg.start_seconds) + 1}",
                character="",
                notes="Auto-detected dialog region",
            )
            entries.append(entry)
            cue_num += 1

        # Scene changes → Foley/SFX cues
        for i, scene in enumerate(svc.scenes):
            if i == 0:
                continue  # Skip first scene start

            mood = svc.get_mood(i)
            mood_desc = ""
            if mood and hasattr(mood, 'mood_tags'):
                mood_desc = ", ".join(mood.mood_tags[:2])

            entry = CueSheetEntry(
                cue_id=f"SFX-{cue_num:03d}",
                timecode=_seconds_to_tc(scene.start_seconds, fps),
                time_seconds=scene.start_seconds,
                duration=0.5,
                cue_type="SFX",
                description=f"Scene transition ({mood_desc})" if mood_desc
                            else "Scene transition",
                scene=f"Scene {i + 1}",
                notes=f"Mood: {mood_desc}" if mood_desc else "",
            )
            entries.append(entry)
            cue_num += 1

    except Exception as exc:
        log.error("Cue sheet generation: %s", exc)

    return entries


def _find_scene_at(svc, seconds: float) -> int:
    """Find scene index at given time."""
    for i, scene in enumerate(svc.scenes):
        if scene.start_seconds <= seconds < scene.start_seconds + scene.duration:
            return i
    return 0


def export_cue_sheet_csv(entries: List[CueSheetEntry],
                          output_path: str) -> bool:
    """VK6: Export cue sheet as CSV."""
    try:
        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        with open(output_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["Cue ID", "Timecode", "Duration",
                             "Type", "Description", "Scene",
                             "Character", "Notes"])
            for e in entries:
                writer.writerow([
                    e.cue_id, e.timecode, f"{e.duration:.2f}",
                    e.cue_type, e.description, e.scene,
                    e.character, e.notes])
        log.info("Cue sheet CSV: %s (%d entries)", output_path, len(entries))
        return True
    except Exception as exc:
        log.error("CSV export: %s", exc)
        return False


def export_cue_sheet_pdf(entries: List[CueSheetEntry],
                          output_path: str,
                          project_name: str = "Py_DAW Project",
                          fps: float = 24.0) -> bool:
    """VK6: Export cue sheet as PDF (text-based fallback)."""
    try:
        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

        lines = [
            f"ADR / FOLEY CUE SHEET",
            f"Project: {project_name}",
            f"FPS: {fps}",
            f"Generated: {time.strftime('%Y-%m-%d %H:%M')}",
            f"Total Cues: {len(entries)}",
            "",
            f"{'Cue ID':<12} {'TC':<14} {'Dur':<8} {'Type':<6} "
            f"{'Scene':<10} {'Description'}",
            "-" * 80,
        ]

        for e in entries:
            lines.append(
                f"{e.cue_id:<12} {e.timecode:<14} {e.duration:<8.2f} "
                f"{e.cue_type:<6} {e.scene:<10} {e.description}")
            if e.notes:
                lines.append(f"{'':>12} Notes: {e.notes}")

        lines.append("")
        lines.append(f"--- END OF CUE SHEET ({len(entries)} cues) ---")

        # Save as .txt (PDF generation would need reportlab)
        txt_path = output_path
        if txt_path.endswith(".pdf"):
            txt_path = txt_path.replace(".pdf", ".txt")

        with open(txt_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")

        log.info("Cue sheet: %s (%d entries)", txt_path, len(entries))
        return True
    except Exception as exc:
        log.error("Cue sheet export: %s", exc)
        return False


# ═══════════════════════════════════════════════════════════════
# VK9: Video Annotations
# ═══════════════════════════════════════════════════════════════

@dataclass
class VideoAnnotation:
    """A sticky note annotation on the video timeline."""
    annotation_id: str = ""
    beat: float = 0.0
    time_seconds: float = 0.0
    text: str = ""
    color: str = "yellow"    # red, green, yellow, blue
    status: str = "todo"     # todo, done, question
    author: str = ""
    created_at: float = 0.0

    # Color mapping
    _COLOR_MAP = {
        "red": "#ff4444", "todo": "#ff4444",
        "green": "#44ff44", "done": "#44ff44",
        "yellow": "#ffff44", "question": "#ffff44",
        "blue": "#4488ff",
    }

    def __post_init__(self):
        if not self.annotation_id:
            self.annotation_id = f"ann_{uuid.uuid4().hex[:8]}"
        if not self.created_at:
            self.created_at = time.time()

    @property
    def hex_color(self) -> str:
        return self._COLOR_MAP.get(self.color,
               self._COLOR_MAP.get(self.status, "#ffff44"))

    def to_dict(self) -> dict:
        return {
            "annotation_id": self.annotation_id,
            "beat": self.beat,
            "time_seconds": self.time_seconds,
            "text": self.text,
            "color": self.color,
            "status": self.status,
            "author": self.author,
            "created_at": self.created_at,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "VideoAnnotation":
        return cls(**{k: v for k, v in d.items()
                      if k in cls.__dataclass_fields__})


class AnnotationManager:
    """Manages video annotations (sticky notes)."""

    def __init__(self):
        self._annotations: List[VideoAnnotation] = []

    @property
    def annotations(self) -> List[VideoAnnotation]:
        return self._annotations

    def add(self, beat: float, text: str,
            color: str = "yellow", status: str = "todo",
            author: str = "", bpm: float = 120.0) -> VideoAnnotation:
        ann = VideoAnnotation(
            beat=beat,
            time_seconds=beat * 60.0 / bpm if bpm > 0 else 0,
            text=text,
            color=color,
            status=status,
            author=author,
        )
        self._annotations.append(ann)
        self._annotations.sort(key=lambda a: a.beat)
        return ann

    def remove(self, annotation_id: str) -> bool:
        before = len(self._annotations)
        self._annotations = [a for a in self._annotations
                              if a.annotation_id != annotation_id]
        return len(self._annotations) < before

    def set_status(self, annotation_id: str, status: str) -> bool:
        for a in self._annotations:
            if a.annotation_id == annotation_id:
                a.status = status
                if status == "done":
                    a.color = "green"
                elif status == "question":
                    a.color = "yellow"
                elif status == "todo":
                    a.color = "red"
                return True
        return False

    def search(self, query: str) -> List[VideoAnnotation]:
        q = query.lower()
        return [a for a in self._annotations if q in a.text.lower()]

    def export_text(self, output_path: str) -> bool:
        try:
            lines = ["# Video Annotations", ""]
            for a in self._annotations:
                status = {"todo": "[ ]", "done": "[x]",
                          "question": "[?]"}.get(a.status, "[ ]")
                lines.append(f"{status} Beat {a.beat:.1f} | {a.text}")
                if a.author:
                    lines.append(f"    Author: {a.author}")
            with open(output_path, "w", encoding="utf-8") as f:
                f.write("\n".join(lines) + "\n")
            return True
        except Exception:
            return False

    def to_dict_list(self) -> List[dict]:
        return [a.to_dict() for a in self._annotations]

    def load_from_list(self, data: List[dict]) -> None:
        self._annotations = [VideoAnnotation.from_dict(d) for d in data]
        self._annotations.sort(key=lambda a: a.beat)


# ═══════════════════════════════════════════════════════════════
# VideoKIArrangerService (combined)
# ═══════════════════════════════════════════════════════════════

class VideoKIArrangerService:
    """Combined service for all Video-KI Arranger integrations."""

    def __init__(self, project_service=None):
        self._ps = project_service
        self._scene_markers: List[SceneMarker] = []
        self._dialog_markers: List[DialogRegionMarker] = []
        self._mood_suggestions: List[MoodSuggestion] = []
        self._beat_suggestions: List[BeatCutSuggestion] = []
        self._cue_entries: List[CueSheetEntry] = []
        self._annotations = AnnotationManager()

    @property
    def scene_markers(self) -> List[SceneMarker]:
        return self._scene_markers

    @property
    def dialog_markers(self) -> List[DialogRegionMarker]:
        return self._dialog_markers

    @property
    def mood_suggestions(self) -> List[MoodSuggestion]:
        return self._mood_suggestions

    @property
    def annotations(self) -> AnnotationManager:
        return self._annotations

    def analyze_all(self, video_path: str,
                     bpm: float = 120.0, fps: float = 24.0) -> None:
        """Run all VK analyses."""
        self._scene_markers = generate_scene_markers(video_path, bpm, fps)
        self._dialog_markers = generate_dialog_markers(video_path, bpm)
        self._mood_suggestions = generate_mood_suggestions(video_path, bpm)
        self._beat_suggestions = generate_beat_cut_suggestions(
            video_path, bpm)
        self._cue_entries = generate_cue_sheet(video_path, fps)

        log.info("VK analysis: %d scenes, %d dialogs, %d moods, %d cues",
                 len(self._scene_markers), len(self._dialog_markers),
                 len(self._mood_suggestions), len(self._cue_entries))

    def get_auto_duck_points(self, video_path: str,
                               bpm: float = 120.0,
                               duck_db: float = -12.0
                               ) -> List[Tuple[float, float]]:
        return generate_auto_duck(video_path, bpm, duck_db)

    def get_scene_color_bar(self, video_path: str,
                              bpm: float = 120.0
                              ) -> List[Dict[str, Any]]:
        return generate_scene_color_bar(video_path, bpm)

    def get_subtitle_blocks(self, video_path: str,
                              bpm: float = 120.0
                              ) -> List[Dict[str, Any]]:
        return generate_subtitle_blocks(video_path, bpm)

    def search_transcript(self, video_path: str,
                            query: str) -> List[Dict[str, Any]]:
        return search_transcript(video_path, query)

    def export_cue_csv(self, output_path: str) -> bool:
        return export_cue_sheet_csv(self._cue_entries, output_path)

    def export_cue_pdf(self, output_path: str,
                        project_name: str = "") -> bool:
        return export_cue_sheet_pdf(self._cue_entries, output_path,
                                     project_name)
