"""
pydaw.services.flux_vault_factory_synthwave — V-2 Synthwave-Style Factory-Presets

**v0.0.21.201 — Synthwave v1 (80s-Retro-Edition)**
==================================================

Erste Iteration der Synthwave-Style-Presets nach dem **Sacred-v2-
Charakter-Modul-Schema** aus v0.0.21.199:

> Jeder Preset bekommt ein einzigartiges Charakter-Modul, das ihn
> unverwechselbar macht.

Die Synthwave-Familie holt 80er-Jahre-Retro-Synth-Sounds in das
modulare FLUX-System: Saw-heavy Lead-Lines, breite Chorus-Pads,
Tube-warme Bässe, Slap-Delay-Echos, Tape-Saturation-Artefakte,
BitCrush für 8-Bit-Arcade-Charakter.

| Preset           | Charakter-Modul                | Klang-Identität |
|------------------|--------------------------------|-----------------|
| Outrun           | Saw + Chorus + Tube + Slap-Delay | klassisches 80s-Lead |
| Neon-City        | Square (PWM via LFO) + Compressor | helles bewegtes Lead |
| Miami-Sunset     | Triangle + Tube-Drive + EQ4 + Chorus | warm rosafarben |
| Cyber-Nights     | Saw + LFO→Cutoff + Phaser + Delay | düster cyberpunk |
| VHS              | Saw+Sine + Decimator + WaveShaper | degradiertes Tape |
| DeLorean         | Stereo Saw L + Sub Saw R + StereoImager | brett-stereo Lead |
| Arcade           | Square + BitCrush(slight) + Chorus + Delay | 8-bit Arcade |
| Cassette-Drive   | Saw + Tube + Decimator(slight) + EQ4 | Tape-Charakter |
| Chrome           | Triangle + Phaser + Compressor + Imager | shiny metallisch |
| Pacific-Coast    | Saw + Tilt(+) + deep Chorus + Delay | offene Weite |
| Hotline          | Sub Square bass L + Saw mid R + Chorus + Delay | driving |
| Dreamwave        | Saw + LP + LFO-Vibrato + Chorus + huge Reverb | träumerisch weit |

Versions-Marker ``"FLUX Factory (Synthwave v1)"`` für sauberes Re-Seeding.
"""

from __future__ import annotations

import logging
from typing import Optional

logger = logging.getLogger(__name__)


SYNTHWAVE_FACTORY_VERSION = "v1"
SYNTHWAVE_FACTORY_AUTHOR = (
    f"FLUX Factory (Synthwave {SYNTHWAVE_FACTORY_VERSION})"
)


# ─── Helper ───────────────────────────────────────────────────────


def _connect(patch, src_id: str, src_port: str,
             tgt_id: str, tgt_port: str) -> bool:
    """Helper: Connection hinzufügen, defensiv gegen fehlende Module."""
    from pydaw.flux.patch_model import Connection
    src = patch.get_module(src_id)
    tgt = patch.get_module(tgt_id)
    if src is None or tgt is None:
        return False
    return patch.add_connection(Connection(
        source_module=src_id, source_port=src_port,
        target_module=tgt_id, target_port=tgt_port,
    ))


def _set(module, **params) -> None:
    """Helper: Module-Params setzen (defensiv gegen fehlende Keys)."""
    if module is None:
        return
    for k, v in params.items():
        if k in module.params:
            module.params[k] = v


def _build_patch_dict(name: str, builder) -> Optional[dict]:
    """Wrappt einen Patch-Builder in to_dict, defensiv gegen Fehler."""
    try:
        from pydaw.flux.patch_model import Patch
        p = builder()
        if not isinstance(p, Patch):
            return None
        p.name = name
        return p.to_dict()
    except Exception as e:
        logger.warning("[SynthwavePresets-v1] build %s failed: %s", name, e)
        return None


# ─── Patch-Builder pro Variant (Synthwave v1) ─────────────────────


def _build_outrun():
    """Outrun — Saw + Chorus + Tube + Slap-Delay (klassisches 80s-Lead).

    Charakter: das Brot-und-Butter Synthwave-Lead. Saw durch Chorus
    breit, dann TubeDrive wärmt, kurzer Slap-Delay gibt Rhythmus-Echo.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_saw_osc, make_forseti_lowpass,
        make_skadi_chorus, make_thor_tube_drive,
        make_iduna_delay, make_iduna_reverb,
        make_heimdall_master_out,
    )
    p = Patch(name="Outrun")
    osc = make_bragi_saw_osc(); osc.position = (60, 200)
    _set(osc, freq=349.23, gain=0.4)  # F4 lead
    flt = make_forseti_lowpass(); flt.position = (240, 200)
    _set(flt, cutoff=3500.0, resonance=0.45)
    chorus = make_skadi_chorus(); chorus.position = (420, 200)
    _set(chorus, rate=0.5, depth=0.6, mix=0.55)  # klassisch
    drive = make_thor_tube_drive(); drive.position = (600, 200)
    _set(drive, drive=8.0, tone=0.55, mix=0.65)
    delay = make_iduna_delay(); delay.position = (780, 200)
    _set(delay, time=0.25, feedback=0.45, mix=0.35, tone=4000.0)  # Slap-Echo
    rev = make_iduna_reverb(); rev.position = (960, 200)
    _set(rev, room_size=0.65, damping=0.4, mix=0.3)
    out = make_heimdall_master_out(); out.position = (1160, 200)
    for m in (osc, flt, chorus, drive, delay, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", flt.id, "audio_in")
    _connect(p, flt.id, "audio_out", chorus.id, "audio_in")
    _connect(p, chorus.id, "audio_out", drive.id, "audio_in")
    _connect(p, drive.id, "audio_out", delay.id, "audio_in")
    _connect(p, delay.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_neon_city():
    """Neon-City — Square mit PWM-LFO + Vidar.Compressor (helles bewegtes Lead).

    Charakter: Square mit Pulse-Width-Modulation via LFO (LFO an gain
    simuliert die PWM-Bewegung), Compressor für Punch — klingt wie
    eine pulsierende Neon-Reklame in der Großstadt.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_square_osc, make_loki_lfo_sine,
        make_forseti_lowpass, make_vidar_compressor,
        make_iduna_delay, make_iduna_reverb,
        make_heimdall_master_out,
    )
    p = Patch(name="Neon-City")
    osc = make_bragi_square_osc(); osc.position = (60, 200)
    _set(osc, freq=440.0, gain=0.4)  # A4
    lfo = make_loki_lfo_sine(); lfo.position = (60, 60)
    _set(lfo, rate=2.5, depth=0.18)  # PWM-Bewegung
    flt = make_forseti_lowpass(); flt.position = (260, 200)
    _set(flt, cutoff=3000.0, resonance=0.5)
    comp = make_vidar_compressor(); comp.position = (460, 200)
    _set(comp, threshold=-14.0, ratio=4.0, attack_ms=4.0,
         release_ms=60.0, makeup=4.0)
    delay = make_iduna_delay(); delay.position = (660, 200)
    _set(delay, time=0.3, feedback=0.4, mix=0.3, tone=5000.0)
    rev = make_iduna_reverb(); rev.position = (860, 200)
    _set(rev, room_size=0.55, damping=0.35, mix=0.28)
    out = make_heimdall_master_out(); out.position = (1060, 200)
    for m in (osc, lfo, flt, comp, delay, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", flt.id, "audio_in")
    _connect(p, flt.id, "audio_out", comp.id, "audio_in")
    _connect(p, comp.id, "audio_out", delay.id, "audio_in")
    _connect(p, delay.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    # LFO → osc.gain (PWM-artige Bewegung)
    _connect(p, lfo.id, "cv_out", osc.id, "gain")
    return p


def _build_miami_sunset():
    """Miami-Sunset — Triangle + TubeDrive + EQ4(warm) + Chorus (warm rosé).

    Charakter: warmer Triangle-Klang mit Tube-Wärme, EQ4 hebt Mids
    für die rosé-getönte Sunset-Atmosphäre, Chorus für Breite.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_triangle_osc, make_thor_tube_drive,
        make_forseti_eq4, make_skadi_chorus,
        make_iduna_reverb, make_heimdall_master_out,
    )
    p = Patch(name="Miami-Sunset")
    osc = make_bragi_triangle_osc(); osc.position = (60, 200)
    _set(osc, freq=329.63, gain=0.45)  # E4
    drive = make_thor_tube_drive(); drive.position = (260, 200)
    _set(drive, drive=10.0, tone=0.45, mix=0.7)  # warm
    eq = make_forseti_eq4(); eq.position = (460, 200)
    _set(eq, low_gain=2.0, lo_mid_gain=3.0,
         hi_mid_gain=-1.0, high_gain=-2.0)  # warm-mid
    chorus = make_skadi_chorus(); chorus.position = (660, 200)
    _set(chorus, rate=0.6, depth=0.5, mix=0.5)
    rev = make_iduna_reverb(); rev.position = (860, 200)
    _set(rev, room_size=0.7, damping=0.45, mix=0.32)
    out = make_heimdall_master_out(); out.position = (1060, 200)
    for m in (osc, drive, eq, chorus, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", drive.id, "audio_in")
    _connect(p, drive.id, "audio_out", eq.id, "audio_in")
    _connect(p, eq.id, "audio_out", chorus.id, "audio_in")
    _connect(p, chorus.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_cyber_nights():
    """Cyber-Nights — Saw + LFO→Cutoff + Phaser + Delay (düster cyberpunk).

    Charakter: dunkler Saw, LFO öffnet/schließt das Filter, Phaser
    gibt cyberpunk-typische metallene Bewegung, Delay-Echo verstärkt.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_saw_osc, make_loki_lfo_sine,
        make_forseti_lowpass, make_skadi_phaser,
        make_iduna_delay, make_iduna_reverb,
        make_heimdall_master_out,
    )
    p = Patch(name="Cyber-Nights")
    osc = make_bragi_saw_osc(); osc.position = (60, 200)
    _set(osc, freq=164.81, gain=0.4)  # E3 dunkel
    lfo = make_loki_lfo_sine(); lfo.position = (60, 60)
    _set(lfo, rate=0.35, depth=2.5)  # Filter-Sweep
    flt = make_forseti_lowpass(); flt.position = (260, 200)
    _set(flt, cutoff=1200.0, resonance=0.7)
    phaser = make_skadi_phaser(); phaser.position = (460, 200)
    _set(phaser, rate=0.5, depth=0.7, feedback=0.55, mix=0.55)
    delay = make_iduna_delay(); delay.position = (660, 200)
    _set(delay, time=0.5, feedback=0.55, mix=0.4, tone=3000.0)
    rev = make_iduna_reverb(); rev.position = (860, 200)
    _set(rev, room_size=0.7, damping=0.4, mix=0.35)
    out = make_heimdall_master_out(); out.position = (1060, 200)
    for m in (osc, lfo, flt, phaser, delay, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", flt.id, "audio_in")
    _connect(p, flt.id, "audio_out", phaser.id, "audio_in")
    _connect(p, phaser.id, "audio_out", delay.id, "audio_in")
    _connect(p, delay.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    # LFO → Filter-Cutoff
    _connect(p, lfo.id, "cv_out", flt.id, "cutoff")
    return p


def _build_vhs():
    """VHS — Saw L + Sine R + Decimator + WaveShaper (degradiertes Tape).

    Charakter: Decimator (Sample-Rate-Reduktion) erzeugt VHS-Aliasing,
    WaveShaper formt die Wellen tape-typisch um. Stereo-Mix von Saw L
    und Sine R erzeugt zwei verschiedene VHS-Spuren.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_saw_osc, make_bragi_sine_osc,
        make_fenrir_decimator, make_thor_wave_shaper,
        make_iduna_reverb, make_heimdall_master_out,
    )
    p = Patch(name="VHS")
    # L: Saw — Hauptspur
    osc_l = make_bragi_saw_osc(); osc_l.position = (60, 100)
    _set(osc_l, freq=220.0, gain=0.35)  # A3
    deci_l = make_fenrir_decimator(); deci_l.position = (260, 100)
    _set(deci_l, target_sr=12000.0, mix=0.55)  # VHS-Aliasing
    shaper_l = make_thor_wave_shaper(); shaper_l.position = (460, 100)
    _set(shaper_l, drive=8.0, shape=1.0, mix=0.6)  # cubic
    rev_l = make_iduna_reverb(); rev_l.position = (660, 100)
    _set(rev_l, room_size=0.55, damping=0.5, mix=0.32)
    # R: Sine — Sub-Spur
    osc_r = make_bragi_sine_osc(); osc_r.position = (60, 280)
    _set(osc_r, freq=110.0, gain=0.35)  # A2
    deci_r = make_fenrir_decimator(); deci_r.position = (260, 280)
    _set(deci_r, target_sr=10000.0, mix=0.5)
    shaper_r = make_thor_wave_shaper(); shaper_r.position = (460, 280)
    _set(shaper_r, drive=6.0, shape=2.0, mix=0.55)  # quintic
    rev_r = make_iduna_reverb(); rev_r.position = (660, 280)
    _set(rev_r, room_size=0.55, damping=0.5, mix=0.32)
    out = make_heimdall_master_out(); out.position = (880, 190)
    for m in (osc_l, deci_l, shaper_l, rev_l,
              osc_r, deci_r, shaper_r, rev_r, out):
        p.add_module(m)
    _connect(p, osc_l.id, "audio_out", deci_l.id, "audio_in")
    _connect(p, deci_l.id, "audio_out", shaper_l.id, "audio_in")
    _connect(p, shaper_l.id, "audio_out", rev_l.id, "audio_in")
    _connect(p, rev_l.id, "audio_out", out.id, "audio_in_l")
    _connect(p, osc_r.id, "audio_out", deci_r.id, "audio_in")
    _connect(p, deci_r.id, "audio_out", shaper_r.id, "audio_in")
    _connect(p, shaper_r.id, "audio_out", rev_r.id, "audio_in")
    _connect(p, rev_r.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_delorean():
    """DeLorean — Stereo Saw L + Sub Saw R + StereoImager (brett-stereo Lead).

    Charakter: zwei Saw-Stimmen leicht detuned (Quint-Distance L/R) +
    Imager macht die Stereo-Spreizung zum „Brett". Klassischer Synth-
    wave-Lead in voller Breite.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_saw_osc, make_forseti_lowpass,
        make_skadi_chorus, make_skadi_stereo_imager,
        make_iduna_reverb, make_heimdall_master_out,
    )
    p = Patch(name="DeLorean")
    # L: Saw — Hauptlead C4
    osc_l = make_bragi_saw_osc(); osc_l.position = (60, 100)
    _set(osc_l, freq=261.63, gain=0.3)  # C4
    flt_l = make_forseti_lowpass(); flt_l.position = (260, 100)
    _set(flt_l, cutoff=3200.0, resonance=0.45)
    chorus_l = make_skadi_chorus(); chorus_l.position = (460, 100)
    _set(chorus_l, rate=0.45, depth=0.55, mix=0.5)
    imager_l = make_skadi_stereo_imager(); imager_l.position = (660, 100)
    _set(imager_l, width=1.7, mix=1.0)
    rev_l = make_iduna_reverb(); rev_l.position = (860, 100)
    _set(rev_l, room_size=0.65, damping=0.4, mix=0.3)
    # R: Sub-Saw eine Oktave tiefer
    osc_r = make_bragi_saw_osc(); osc_r.position = (60, 280)
    _set(osc_r, freq=130.81, gain=0.3)  # C3
    flt_r = make_forseti_lowpass(); flt_r.position = (260, 280)
    _set(flt_r, cutoff=2000.0, resonance=0.5)
    chorus_r = make_skadi_chorus(); chorus_r.position = (460, 280)
    _set(chorus_r, rate=0.6, depth=0.55, mix=0.5)
    imager_r = make_skadi_stereo_imager(); imager_r.position = (660, 280)
    _set(imager_r, width=1.7, mix=1.0)
    rev_r = make_iduna_reverb(); rev_r.position = (860, 280)
    _set(rev_r, room_size=0.65, damping=0.4, mix=0.3)
    out = make_heimdall_master_out(); out.position = (1080, 190)
    for m in (osc_l, flt_l, chorus_l, imager_l, rev_l,
              osc_r, flt_r, chorus_r, imager_r, rev_r, out):
        p.add_module(m)
    _connect(p, osc_l.id, "audio_out", flt_l.id, "audio_in")
    _connect(p, flt_l.id, "audio_out", chorus_l.id, "audio_in")
    _connect(p, chorus_l.id, "audio_out", imager_l.id, "audio_in")
    _connect(p, imager_l.id, "audio_out", rev_l.id, "audio_in")
    _connect(p, rev_l.id, "audio_out", out.id, "audio_in_l")
    _connect(p, osc_r.id, "audio_out", flt_r.id, "audio_in")
    _connect(p, flt_r.id, "audio_out", chorus_r.id, "audio_in")
    _connect(p, chorus_r.id, "audio_out", imager_r.id, "audio_in")
    _connect(p, imager_r.id, "audio_out", rev_r.id, "audio_in")
    _connect(p, rev_r.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_arcade():
    """Arcade — Square + Fenrir.BitCrush(slight) + Chorus + Delay (8-bit).

    Charakter: Square-Wave durch leichte BitCrush bekommt 8-bit Atari/
    NES-Charakter, Chorus + Delay machen es game-soundtrack-würdig.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_square_osc, make_fenrir_bit_crush,
        make_skadi_chorus, make_iduna_delay,
        make_iduna_reverb, make_heimdall_master_out,
    )
    p = Patch(name="Arcade")
    osc = make_bragi_square_osc(); osc.position = (60, 200)
    _set(osc, freq=523.25, gain=0.4)  # C5 — heller arcade-Ton
    crush = make_fenrir_bit_crush(); crush.position = (260, 200)
    _set(crush, bits=8.0, mix=0.55)  # 8-bit
    chorus = make_skadi_chorus(); chorus.position = (460, 200)
    _set(chorus, rate=0.7, depth=0.5, mix=0.45)
    delay = make_iduna_delay(); delay.position = (660, 200)
    _set(delay, time=0.18, feedback=0.5, mix=0.4, tone=4500.0)  # quick echo
    rev = make_iduna_reverb(); rev.position = (860, 200)
    _set(rev, room_size=0.5, damping=0.35, mix=0.28)
    out = make_heimdall_master_out(); out.position = (1060, 200)
    for m in (osc, crush, chorus, delay, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", crush.id, "audio_in")
    _connect(p, crush.id, "audio_out", chorus.id, "audio_in")
    _connect(p, chorus.id, "audio_out", delay.id, "audio_in")
    _connect(p, delay.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_cassette_drive():
    """Cassette-Drive — Saw + Tube + Decimator(slight) + EQ4 (Tape-Charakter).

    Charakter: Tube-Drive für analoge Wärme + leichter Decimator für
    das Cassette-Wow-Aliasing + EQ4 zieht die Höhen ab wie ein Tape-
    Bandsalat.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_saw_osc, make_thor_tube_drive,
        make_fenrir_decimator, make_forseti_eq4,
        make_iduna_reverb, make_heimdall_master_out,
    )
    p = Patch(name="Cassette-Drive")
    osc = make_bragi_saw_osc(); osc.position = (60, 200)
    _set(osc, freq=246.94, gain=0.4)  # B3
    drive = make_thor_tube_drive(); drive.position = (260, 200)
    _set(drive, drive=12.0, tone=0.45, mix=0.7)
    deci = make_fenrir_decimator(); deci.position = (460, 200)
    _set(deci, target_sr=22050.0, mix=0.35)  # subtil — Tape-Aliasing
    eq = make_forseti_eq4(); eq.position = (660, 200)
    _set(eq, low_gain=1.0, lo_mid_gain=2.0,
         hi_mid_gain=-1.5, high_gain=-4.0)  # Höhen weg = Tape
    rev = make_iduna_reverb(); rev.position = (860, 200)
    _set(rev, room_size=0.6, damping=0.5, mix=0.32)
    out = make_heimdall_master_out(); out.position = (1060, 200)
    for m in (osc, drive, deci, eq, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", drive.id, "audio_in")
    _connect(p, drive.id, "audio_out", deci.id, "audio_in")
    _connect(p, deci.id, "audio_out", eq.id, "audio_in")
    _connect(p, eq.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_chrome():
    """Chrome — Triangle + Phaser + Compressor + Imager (shiny metallisch).

    Charakter: Triangle als clean-Basis, Phaser legt den metallischen
    Schimmer auf, Compressor verdichtet, Imager macht's breit wie
    poliertes Chrom.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_triangle_osc, make_skadi_phaser,
        make_vidar_compressor, make_skadi_stereo_imager,
        make_iduna_reverb, make_heimdall_master_out,
    )
    p = Patch(name="Chrome")
    osc = make_bragi_triangle_osc(); osc.position = (60, 200)
    _set(osc, freq=440.0, gain=0.5)  # A4
    phaser = make_skadi_phaser(); phaser.position = (260, 200)
    _set(phaser, rate=0.55, depth=0.65, feedback=0.5, mix=0.55)
    comp = make_vidar_compressor(); comp.position = (460, 200)
    _set(comp, threshold=-12.0, ratio=4.5, attack_ms=2.0,
         release_ms=80.0, makeup=4.0)
    imager = make_skadi_stereo_imager(); imager.position = (660, 200)
    _set(imager, width=1.6, mix=1.0)
    rev = make_iduna_reverb(); rev.position = (860, 200)
    _set(rev, room_size=0.6, damping=0.35, mix=0.3)
    out = make_heimdall_master_out(); out.position = (1060, 200)
    for m in (osc, phaser, comp, imager, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", phaser.id, "audio_in")
    _connect(p, phaser.id, "audio_out", comp.id, "audio_in")
    _connect(p, comp.id, "audio_out", imager.id, "audio_in")
    _connect(p, imager.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_pacific_coast():
    """Pacific-Coast — Saw + Tilt(+) + deep Chorus + Delay (offene Weite).

    Charakter: Tilt nach oben gibt offen-helle Höhe, tiefer Chorus
    macht's breit, Delay vergrößert den Raum — pazifisches Highway-
    Cruisen.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_saw_osc, make_forseti_tilt,
        make_skadi_chorus, make_iduna_delay,
        make_iduna_reverb, make_heimdall_master_out,
    )
    p = Patch(name="Pacific-Coast")
    osc = make_bragi_saw_osc(); osc.position = (60, 200)
    _set(osc, freq=293.66, gain=0.4)  # D4
    tilt = make_forseti_tilt(); tilt.position = (260, 200)
    _set(tilt, tilt=0.4)  # nach oben — offen hell
    chorus = make_skadi_chorus(); chorus.position = (460, 200)
    _set(chorus, rate=0.4, depth=0.75, mix=0.55)  # tief
    delay = make_iduna_delay(); delay.position = (660, 200)
    _set(delay, time=0.4, feedback=0.45, mix=0.35, tone=6000.0)
    rev = make_iduna_reverb(); rev.position = (860, 200)
    _set(rev, room_size=0.78, damping=0.4, mix=0.4)
    out = make_heimdall_master_out(); out.position = (1060, 200)
    for m in (osc, tilt, chorus, delay, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", tilt.id, "audio_in")
    _connect(p, tilt.id, "audio_out", chorus.id, "audio_in")
    _connect(p, chorus.id, "audio_out", delay.id, "audio_in")
    _connect(p, delay.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_hotline():
    """Hotline — Sub Square bass L + Saw mid R + Chorus + Delay (driving).

    Charakter: tiefer Square-Bass auf L (Pumping-Foundation), Saw-Lead
    auf R mit Chorus + Delay — klassisches Hotline-Miami-Setup.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_square_osc, make_bragi_saw_osc,
        make_forseti_lowpass, make_skadi_chorus,
        make_iduna_delay, make_iduna_reverb,
        make_heimdall_master_out,
    )
    p = Patch(name="Hotline")
    # L: Sub-Square Bass
    osc_l = make_bragi_square_osc(); osc_l.position = (60, 100)
    _set(osc_l, freq=82.41, gain=0.45)  # E2
    flt_l = make_forseti_lowpass(); flt_l.position = (260, 100)
    _set(flt_l, cutoff=550.0, resonance=0.5)  # bass-tight
    rev_l = make_iduna_reverb(); rev_l.position = (460, 100)
    _set(rev_l, room_size=0.5, damping=0.45, mix=0.22)  # tight
    # R: Saw Lead
    osc_r = make_bragi_saw_osc(); osc_r.position = (60, 280)
    _set(osc_r, freq=329.63, gain=0.35)  # E4
    flt_r = make_forseti_lowpass(); flt_r.position = (260, 280)
    _set(flt_r, cutoff=3000.0, resonance=0.4)
    chorus_r = make_skadi_chorus(); chorus_r.position = (460, 280)
    _set(chorus_r, rate=0.55, depth=0.6, mix=0.5)
    delay_r = make_iduna_delay(); delay_r.position = (660, 280)
    _set(delay_r, time=0.3, feedback=0.5, mix=0.4, tone=4500.0)
    rev_r = make_iduna_reverb(); rev_r.position = (860, 280)
    _set(rev_r, room_size=0.65, damping=0.4, mix=0.3)
    out = make_heimdall_master_out(); out.position = (1080, 190)
    for m in (osc_l, flt_l, rev_l,
              osc_r, flt_r, chorus_r, delay_r, rev_r, out):
        p.add_module(m)
    _connect(p, osc_l.id, "audio_out", flt_l.id, "audio_in")
    _connect(p, flt_l.id, "audio_out", rev_l.id, "audio_in")
    _connect(p, rev_l.id, "audio_out", out.id, "audio_in_l")
    _connect(p, osc_r.id, "audio_out", flt_r.id, "audio_in")
    _connect(p, flt_r.id, "audio_out", chorus_r.id, "audio_in")
    _connect(p, chorus_r.id, "audio_out", delay_r.id, "audio_in")
    _connect(p, delay_r.id, "audio_out", rev_r.id, "audio_in")
    _connect(p, rev_r.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_dreamwave():
    """Dreamwave — Saw + LP + LFO-Vibrato + Chorus + huge Reverb (träumerisch).

    Charakter: weicher Filter, LFO-Vibrato auf Cutoff (atmend), tiefer
    Chorus, riesige Halle — der träumerischste Synthwave-Style.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_saw_osc, make_loki_lfo_sine,
        make_forseti_lowpass, make_skadi_chorus,
        make_iduna_reverb, make_heimdall_master_out,
    )
    p = Patch(name="Dreamwave")
    osc = make_bragi_saw_osc(); osc.position = (80, 200)
    _set(osc, freq=220.0, gain=0.4)  # A3
    lfo = make_loki_lfo_sine(); lfo.position = (80, 60)
    _set(lfo, rate=0.4, depth=1.5)  # Filter-Atmen
    flt = make_forseti_lowpass(); flt.position = (300, 200)
    _set(flt, cutoff=1800.0, resonance=0.5)
    chorus = make_skadi_chorus(); chorus.position = (500, 200)
    _set(chorus, rate=0.4, depth=0.75, mix=0.6)  # tief
    rev = make_iduna_reverb(); rev.position = (700, 200)
    _set(rev, room_size=0.92, damping=0.35, mix=0.55)  # huge
    out = make_heimdall_master_out(); out.position = (900, 200)
    for m in (osc, lfo, flt, chorus, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", flt.id, "audio_in")
    _connect(p, flt.id, "audio_out", chorus.id, "audio_in")
    _connect(p, chorus.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    # LFO → Filter-Cutoff
    _connect(p, lfo.id, "cv_out", flt.id, "cutoff")
    return p


# ─── Preset-Liste ─────────────────────────────────────────────────


def _build_all() -> list[dict]:
    """Baut alle 12 Synthwave-v1-Patches.  Wird **lazy** beim ersten
    Vault-Import aufgerufen."""
    builders = [
        ("Outrun",         "Saw + Chorus + Tube + Slap-Delay (klassisches 80s-Lead).",
         ["lead", "saw", "chorus", "delay"], "F4", _build_outrun),
        ("Neon-City",      "Square mit PWM-LFO + Compressor (helles bewegtes Lead).",
         ["lead", "pwm", "compressor", "delay"], "A4", _build_neon_city),
        ("Miami-Sunset",   "Triangle + Tube + EQ4(warm) + Chorus (warm rosé).",
         ["pad", "warm", "tube", "chorus"], "E4", _build_miami_sunset),
        ("Cyber-Nights",   "Saw + LFO→Cutoff + Phaser + Delay (düster cyberpunk).",
         ["lead", "dark", "phaser", "lfo"], "E3", _build_cyber_nights),
        ("VHS",            "Saw L + Sine R + Decimator + WaveShaper (degradiertes Tape).",
         ["pad", "tape", "decimator", "stereo"], "A3", _build_vhs),
        ("DeLorean",       "Stereo Saw L + Sub Saw R + StereoImager (brett-stereo Lead).",
         ["lead", "stereo", "wide", "saw"], "C4", _build_delorean),
        ("Arcade",         "Square + BitCrush(slight) + Chorus + Delay (8-bit).",
         ["lead", "8bit", "bitcrush", "arcade"], "C5", _build_arcade),
        ("Cassette-Drive", "Saw + Tube + Decimator(slight) + EQ4 (Tape-Charakter).",
         ["pad", "tape", "tube", "warm"], "B3", _build_cassette_drive),
        ("Chrome",         "Triangle + Phaser + Compressor + Imager (shiny metallisch).",
         ["lead", "metallic", "phaser", "compressor"], "A4", _build_chrome),
        ("Pacific-Coast",  "Saw + Tilt(+) + deep Chorus + Delay (offene Weite).",
         ["lead", "open", "chorus", "delay"], "D4", _build_pacific_coast),
        ("Hotline",        "Sub Square bass L + Saw mid R + Chorus + Delay (driving).",
         ["bass", "lead", "stereo", "driving"], "E2", _build_hotline),
        ("Dreamwave",      "Saw + LP + LFO-Vibrato + Chorus + huge Reverb (träumerisch).",
         ["pad", "dreamy", "lfo", "huge"], "A3", _build_dreamwave),
    ]

    presets = []
    for name, desc, tags, key, builder in builders:
        patch_dict = _build_patch_dict(name, builder)
        if patch_dict is None:
            logger.warning("[SynthwavePresets-v1] %s skipped (build failed)", name)
            continue
        presets.append({
            "name": name,
            "description": desc,
            "tags": tags,
            "musical_key": key,
            "bpm": None,
            "author": SYNTHWAVE_FACTORY_AUTHOR,
            "icon_svg": "",
            "patch": patch_dict,
        })
    return presets


class _LazyPresetList:
    """Wrapper: baut die Patches erst beim ersten Iterieren."""

    def __init__(self):
        self._cache: Optional[list[dict]] = None

    def _ensure(self) -> list[dict]:
        if self._cache is None:
            self._cache = _build_all()
            logger.info(
                "[SynthwavePresets-v1] built %d Synthwave presets (%s) lazily",
                len(self._cache), SYNTHWAVE_FACTORY_VERSION,
            )
        return self._cache

    def __iter__(self):
        return iter(self._ensure())

    def __len__(self):
        return len(self._ensure())

    def __getitem__(self, i):
        return self._ensure()[i]


SYNTHWAVE_PRESETS = _LazyPresetList()


__all__ = [
    "SYNTHWAVE_PRESETS",
    "SYNTHWAVE_FACTORY_VERSION",
    "SYNTHWAVE_FACTORY_AUTHOR",
]
