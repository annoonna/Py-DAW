"""SmartDrop Mixin — Extracted from main_window.py (v0.0.20.815).

Contains all SmartDrop drag-and-drop handlers for instrument/FX/track
morphing and migration. Separated as Mixin class for maintainability.

Self-contained: only references self.services, self.arranger,
self.device_panel, self._set_status, self._set_view_mode — all provided
by MainWindow through Mixin inheritance.

~2600 lines extracted from 8494 → main_window.py reduced to ~5894.
"""

from __future__ import annotations

import logging

log = logging.getLogger(__name__)


class SmartDropMixin:
    """SmartDrop drag-and-drop handlers — mixed into MainWindow."""

    def _build_smartdrop_audio_to_instrument_morph_plan(self, track_id: str, payload: dict | None = None) -> dict:
        """Build/validate the future Audio→Instrument morph plan without mutating state."""
        track_id = str(track_id or "").strip()
        try:
            payload = dict(payload or {})
        except Exception:
            payload = {}
        plugin_name = str(payload.get("name") or "").strip() or "Instrument"
        proj = getattr(self.services, "project", None)
        if proj is None:
            return {}
        try:
            return dict(proj.validate_audio_to_instrument_morph(track_id, plugin_name=plugin_name) or {})
        except Exception:
            return {}

    def _show_smartdrop_morph_guard_dialog(self, plan: dict | None) -> dict:
        """Show the central morph-guard dialog and return the user's intent.

        Today this still stays non-mutating because the guard-plan keeps
        ``can_apply=False``. The dialog/result contract is prepared so the same
        flow can later forward an explicit confirmation to the real apply phase
        without touching ArrangerCanvas/TrackList again.
        """
        try:
            plan = dict(plan or {})
        except Exception:
            plan = {}
        result = {
            "shown": False,
            "accepted": False,
            "can_apply": bool(plan.get("can_apply")),
            "requires_confirmation": bool(plan.get("requires_confirmation")),
        }
        if not bool(plan.get("requires_confirmation")):
            return result
        track_name = str(plan.get("track_name") or "Spur")
        plugin_name = str(plan.get("plugin_name") or "Instrument")
        track_summary = str(plan.get("summary") or "")
        blocked_reasons = [str(x).strip() for x in list(plan.get("blocked_reasons") or []) if str(x).strip()]
        rollback_lines = [str(x).strip() for x in list(plan.get("rollback_lines") or []) if str(x).strip()]
        future_apply_steps = [str(x).strip() for x in list(plan.get("future_apply_steps") or []) if str(x).strip()]
        required_snapshots = [str(x).strip() for x in list(plan.get("required_snapshots") or []) if str(x).strip()]
        snapshot_refs = []
        for item in list(plan.get("snapshot_refs") or []):
            try:
                item = dict(item or {})
            except Exception:
                item = {}
            name = str(item.get("name") or "").strip()
            ref = str(item.get("ref") or "").strip()
            if name and ref:
                snapshot_refs.append((name, ref))
        readiness_checks = []
        for item in list(plan.get("readiness_checks") or []):
            try:
                item = dict(item or {})
            except Exception:
                item = {}
            title = str(item.get("title") or "").strip()
            state = str(item.get("state") or "").strip().lower()
            detail = str(item.get("detail") or "").strip()
            if title:
                readiness_checks.append((title, state, detail))
        transaction_steps = [str(x).strip() for x in list(plan.get("transaction_steps") or []) if str(x).strip()]
        transaction_key = str(plan.get("transaction_key") or "").strip()
        transaction_summary = str(plan.get("transaction_summary") or "").strip()
        snapshot_ref_summary = str(plan.get("snapshot_ref_summary") or "").strip()
        runtime_snapshot_summary = str(plan.get("runtime_snapshot_summary") or "").strip()
        runtime_snapshot_handle_summary = str(plan.get("runtime_snapshot_handle_summary") or "").strip()
        runtime_snapshot_capture_summary = str(plan.get("runtime_snapshot_capture_summary") or "").strip()
        runtime_snapshot_instances = []
        for item in list(plan.get("runtime_snapshot_instances") or []):
            try:
                item = dict(item or {})
            except Exception:
                item = {}
            name = str(item.get("name") or "").strip()
            snapshot_instance_key = str(item.get("snapshot_instance_key") or "").strip()
            snapshot_instance_kind = str(item.get("snapshot_instance_kind") or "").strip()
            snapshot_state = str(item.get("snapshot_state") or "").strip().lower()
            owner_scope = str(item.get("owner_scope") or "").strip()
            owner_ids = [str(x).strip() for x in list(item.get("owner_ids") or []) if str(x).strip()]
            snapshot_stub = str(item.get("snapshot_stub") or "").strip()
            snapshot_payload = dict(item.get("snapshot_payload") or {}) if isinstance(item.get("snapshot_payload"), dict) else {}
            snapshot_payload_entry_count = int(item.get("snapshot_payload_entry_count") or 0)
            payload_digest = str(item.get("payload_digest") or "").strip()
            if name:
                runtime_snapshot_instances.append((name, snapshot_instance_key, snapshot_instance_kind, snapshot_state, owner_scope, owner_ids, snapshot_stub, snapshot_payload_entry_count, payload_digest, snapshot_payload))
        runtime_snapshot_objects = []
        for item in list(plan.get("runtime_snapshot_objects") or []):
            try:
                item = dict(item or {})
            except Exception:
                item = {}
            name = str(item.get("name") or "").strip()
            snapshot_object_key = str(item.get("snapshot_object_key") or "").strip()
            snapshot_object_class = str(item.get("snapshot_object_class") or "").strip()
            bind_state = str(item.get("bind_state") or "").strip().lower()
            owner_scope = str(item.get("owner_scope") or "").strip()
            owner_ids = [str(x).strip() for x in list(item.get("owner_ids") or []) if str(x).strip()]
            capture_method = str(item.get("capture_method") or "").strip()
            restore_method = str(item.get("restore_method") or "").strip()
            rollback_slot = str(item.get("rollback_slot") or "").strip()
            payload_digest = str(item.get("payload_digest") or "").strip()
            supports_capture = bool(item.get("supports_capture"))
            supports_restore = bool(item.get("supports_restore"))
            object_stub = str(item.get("object_stub") or "").strip()
            if name:
                runtime_snapshot_objects.append((name, snapshot_object_key, snapshot_object_class, bind_state, owner_scope, owner_ids, capture_method, restore_method, rollback_slot, payload_digest, supports_capture, supports_restore, object_stub))
        runtime_snapshot_instance_summary = str(plan.get("runtime_snapshot_instance_summary") or "").strip()
        runtime_snapshot_object_summary = str(plan.get("runtime_snapshot_object_summary") or "").strip()
        runtime_snapshot_stub_summary = str(plan.get("runtime_snapshot_stub_summary") or "").strip()
        runtime_snapshot_state_carrier_summary = str(plan.get("runtime_snapshot_state_carrier_summary") or "").strip()
        runtime_snapshot_stubs = []
        for item in list(plan.get("runtime_snapshot_stubs") or []):
            try:
                item = dict(item or {})
            except Exception:
                item = {}
            name = str(item.get("name") or "").strip()
            snapshot_object_key = str(item.get("snapshot_object_key") or "").strip()
            snapshot_object_class = str(item.get("snapshot_object_class") or "").strip()
            bind_state = str(item.get("bind_state") or "").strip().lower()
            stub_key = str(item.get("stub_key") or "").strip()
            stub_class = str(item.get("stub_class") or "").strip()
            dispatch_state = str(item.get("dispatch_state") or "").strip().lower()
            capture_method = str(item.get("capture_method") or "").strip()
            restore_method = str(item.get("restore_method") or "").strip()
            rollback_slot = str(item.get("rollback_slot") or "").strip()
            supports_capture_preview = bool(item.get("supports_capture_preview"))
            supports_restore_preview = bool(item.get("supports_restore_preview"))
            factory_method = str(item.get("factory_method") or "").strip()
            capture_stub = str(item.get("capture_stub") or "").strip()
            restore_stub = str(item.get("restore_stub") or "").strip()
            rollback_stub = str(item.get("rollback_stub") or "").strip()
            if name:
                runtime_snapshot_stubs.append((name, snapshot_object_key, snapshot_object_class, bind_state, stub_key, stub_class, dispatch_state, capture_method, restore_method, rollback_slot, supports_capture_preview, supports_restore_preview, factory_method, capture_stub, restore_stub, rollback_stub))
        runtime_snapshot_state_carriers = []
        for item in list(plan.get("runtime_snapshot_state_carriers") or []):
            try:
                item = dict(item or {})
            except Exception:
                item = {}
            name = str(item.get("name") or "").strip()
            snapshot_object_key = str(item.get("snapshot_object_key") or "").strip()
            snapshot_object_class = str(item.get("snapshot_object_class") or "").strip()
            stub_key = str(item.get("stub_key") or "").strip()
            stub_class = str(item.get("stub_class") or "").strip()
            carrier_key = str(item.get("carrier_key") or "").strip()
            carrier_class = str(item.get("carrier_class") or "").strip()
            carrier_state = str(item.get("carrier_state") or "").strip().lower()
            capture_method = str(item.get("capture_method") or "").strip()
            restore_method = str(item.get("restore_method") or "").strip()
            rollback_slot = str(item.get("rollback_slot") or "").strip()
            supports_capture_state = bool(item.get("supports_capture_state"))
            supports_restore_state = bool(item.get("supports_restore_state"))
            bind_method = str(item.get("bind_method") or "").strip()
            capture_state_stub = str(item.get("capture_state_stub") or "").strip()
            restore_state_stub = str(item.get("restore_state_stub") or "").strip()
            rollback_state_stub = str(item.get("rollback_state_stub") or "").strip()
            state_payload_preview = dict(item.get("state_payload_preview") or {}) if isinstance(item.get("state_payload_preview"), dict) else {}
            state_payload_entry_count = int(item.get("state_payload_entry_count") or 0)
            state_payload_digest = str(item.get("state_payload_digest") or "").strip()
            if name:
                runtime_snapshot_state_carriers.append((name, snapshot_object_key, snapshot_object_class, stub_key, stub_class, carrier_key, carrier_class, carrier_state, capture_method, restore_method, rollback_slot, supports_capture_state, supports_restore_state, bind_method, capture_state_stub, restore_state_stub, rollback_state_stub, state_payload_entry_count, state_payload_digest, state_payload_preview))
        runtime_snapshot_state_containers = []
        for item in list(plan.get("runtime_snapshot_state_containers") or []):
            try:
                item = dict(item or {})
            except Exception:
                item = {}
            name = str(item.get("name") or "").strip()
            snapshot_object_key = str(item.get("snapshot_object_key") or "").strip()
            snapshot_object_class = str(item.get("snapshot_object_class") or "").strip()
            stub_key = str(item.get("stub_key") or "").strip()
            stub_class = str(item.get("stub_class") or "").strip()
            carrier_key = str(item.get("carrier_key") or "").strip()
            carrier_class = str(item.get("carrier_class") or "").strip()
            container_key = str(item.get("container_key") or "").strip()
            container_class = str(item.get("container_class") or "").strip()
            container_state = str(item.get("container_state") or "").strip().lower()
            capture_method = str(item.get("capture_method") or "").strip()
            restore_method = str(item.get("restore_method") or "").strip()
            rollback_slot = str(item.get("rollback_slot") or "").strip()
            supports_capture_container = bool(item.get("supports_capture_container"))
            supports_restore_container = bool(item.get("supports_restore_container"))
            supports_runtime_state_container = bool(item.get("supports_runtime_state_container"))
            instantiate_method = str(item.get("instantiate_method") or "").strip()
            capture_container_stub = str(item.get("capture_container_stub") or "").strip()
            restore_container_stub = str(item.get("restore_container_stub") or "").strip()
            rollback_container_stub = str(item.get("rollback_container_stub") or "").strip()
            runtime_state_stub = str(item.get("runtime_state_stub") or "").strip()
            state_payload_entry_count = int(item.get("state_payload_entry_count") or 0)
            state_payload_digest = str(item.get("state_payload_digest") or "").strip()
            state_payload_preview = dict(item.get("state_payload_preview") or {}) if isinstance(item.get("state_payload_preview"), dict) else {}
            container_payload_entry_count = int(item.get("container_payload_entry_count") or 0)
            container_payload_digest = str(item.get("container_payload_digest") or "").strip()
            container_payload_preview = dict(item.get("container_payload_preview") or {}) if isinstance(item.get("container_payload_preview"), dict) else {}
            if name:
                runtime_snapshot_state_containers.append((name, snapshot_object_key, snapshot_object_class, stub_key, stub_class, carrier_key, carrier_class, container_key, container_class, container_state, capture_method, restore_method, rollback_slot, supports_capture_container, supports_restore_container, supports_runtime_state_container, instantiate_method, capture_container_stub, restore_container_stub, rollback_container_stub, runtime_state_stub, state_payload_entry_count, state_payload_digest, state_payload_preview, container_payload_entry_count, container_payload_digest, container_payload_preview))
        runtime_snapshot_state_container_summary = str(plan.get("runtime_snapshot_state_container_summary") or "").strip()
        runtime_snapshot_state_holders = []
        for item in list(plan.get("runtime_snapshot_state_holders") or []):
            try:
                item = dict(item or {})
            except Exception:
                item = {}
            name = str(item.get("name") or "").strip()
            snapshot_object_key = str(item.get("snapshot_object_key") or "").strip()
            snapshot_object_class = str(item.get("snapshot_object_class") or "").strip()
            stub_key = str(item.get("stub_key") or "").strip()
            stub_class = str(item.get("stub_class") or "").strip()
            carrier_key = str(item.get("carrier_key") or "").strip()
            carrier_class = str(item.get("carrier_class") or "").strip()
            container_key = str(item.get("container_key") or "").strip()
            container_class = str(item.get("container_class") or "").strip()
            holder_key = str(item.get("holder_key") or "").strip()
            holder_class = str(item.get("holder_class") or "").strip()
            holder_state = str(item.get("holder_state") or "").strip().lower()
            capture_method = str(item.get("capture_method") or "").strip()
            restore_method = str(item.get("restore_method") or "").strip()
            rollback_slot = str(item.get("rollback_slot") or "").strip()
            supports_capture_holder = bool(item.get("supports_capture_holder"))
            supports_restore_holder = bool(item.get("supports_restore_holder"))
            supports_runtime_state_holder = bool(item.get("supports_runtime_state_holder"))
            instantiate_method = str(item.get("instantiate_method") or "").strip()
            capture_holder_stub = str(item.get("capture_holder_stub") or "").strip()
            restore_holder_stub = str(item.get("restore_holder_stub") or "").strip()
            rollback_holder_stub = str(item.get("rollback_holder_stub") or "").strip()
            runtime_holder_stub = str(item.get("runtime_holder_stub") or "").strip()
            container_payload_entry_count = int(item.get("container_payload_entry_count") or 0)
            container_payload_digest = str(item.get("container_payload_digest") or "").strip()
            container_payload_preview = dict(item.get("container_payload_preview") or {}) if isinstance(item.get("container_payload_preview"), dict) else {}
            holder_payload_entry_count = int(item.get("holder_payload_entry_count") or 0)
            holder_payload_digest = str(item.get("holder_payload_digest") or "").strip()
            holder_payload_preview = dict(item.get("holder_payload_preview") or {}) if isinstance(item.get("holder_payload_preview"), dict) else {}
            if name:
                runtime_snapshot_state_holders.append((name, snapshot_object_key, snapshot_object_class, stub_key, stub_class, carrier_key, carrier_class, container_key, container_class, holder_key, holder_class, holder_state, capture_method, restore_method, rollback_slot, supports_capture_holder, supports_restore_holder, supports_runtime_state_holder, instantiate_method, capture_holder_stub, restore_holder_stub, rollback_holder_stub, runtime_holder_stub, container_payload_entry_count, container_payload_digest, container_payload_preview, holder_payload_entry_count, holder_payload_digest, holder_payload_preview))
        runtime_snapshot_state_slots = []
        for item in list(plan.get("runtime_snapshot_state_slots") or []):
            try:
                item = dict(item or {})
            except Exception:
                item = {}
            name = str(item.get("name") or "").strip()
            snapshot_object_key = str(item.get("snapshot_object_key") or "").strip()
            snapshot_object_class = str(item.get("snapshot_object_class") or "").strip()
            stub_key = str(item.get("stub_key") or "").strip()
            stub_class = str(item.get("stub_class") or "").strip()
            carrier_key = str(item.get("carrier_key") or "").strip()
            carrier_class = str(item.get("carrier_class") or "").strip()
            container_key = str(item.get("container_key") or "").strip()
            container_class = str(item.get("container_class") or "").strip()
            holder_key = str(item.get("holder_key") or "").strip()
            holder_class = str(item.get("holder_class") or "").strip()
            slot_key = str(item.get("slot_key") or "").strip()
            slot_class = str(item.get("slot_class") or "").strip()
            slot_state = str(item.get("slot_state") or "").strip().lower()
            capture_method = str(item.get("capture_method") or "").strip()
            restore_method = str(item.get("restore_method") or "").strip()
            rollback_slot = str(item.get("rollback_slot") or "").strip()
            supports_capture_slot = bool(item.get("supports_capture_slot"))
            supports_restore_slot = bool(item.get("supports_restore_slot"))
            supports_runtime_state_slot = bool(item.get("supports_runtime_state_slot"))
            instantiate_method = str(item.get("instantiate_method") or "").strip()
            capture_slot_stub = str(item.get("capture_slot_stub") or "").strip()
            restore_slot_stub = str(item.get("restore_slot_stub") or "").strip()
            rollback_slot_stub = str(item.get("rollback_slot_stub") or "").strip()
            runtime_state_slot_stub = str(item.get("runtime_state_slot_stub") or "").strip()
            holder_payload_entry_count = int(item.get("holder_payload_entry_count") or 0)
            holder_payload_digest = str(item.get("holder_payload_digest") or "").strip()
            holder_payload_preview = dict(item.get("holder_payload_preview") or {}) if isinstance(item.get("holder_payload_preview"), dict) else {}
            slot_payload_entry_count = int(item.get("slot_payload_entry_count") or 0)
            slot_payload_digest = str(item.get("slot_payload_digest") or "").strip()
            slot_payload_preview = dict(item.get("slot_payload_preview") or {}) if isinstance(item.get("slot_payload_preview"), dict) else {}
            if name:
                runtime_snapshot_state_slots.append((name, snapshot_object_key, snapshot_object_class, stub_key, stub_class, carrier_key, carrier_class, container_key, container_class, holder_key, holder_class, slot_key, slot_class, slot_state, capture_method, restore_method, rollback_slot, supports_capture_slot, supports_restore_slot, supports_runtime_state_slot, instantiate_method, capture_slot_stub, restore_slot_stub, rollback_slot_stub, runtime_state_slot_stub, holder_payload_entry_count, holder_payload_digest, holder_payload_preview, slot_payload_entry_count, slot_payload_digest, slot_payload_preview))
        runtime_snapshot_state_slot_summary = str(plan.get("runtime_snapshot_state_slot_summary") or "").strip()
        runtime_snapshot_state_stores = []
        for item in list(plan.get("runtime_snapshot_state_stores") or []):
            try:
                item = dict(item or {})
            except Exception:
                item = {}
            name = str(item.get("name") or "").strip()
            snapshot_object_key = str(item.get("snapshot_object_key") or "").strip()
            snapshot_object_class = str(item.get("snapshot_object_class") or "").strip()
            stub_key = str(item.get("stub_key") or "").strip()
            stub_class = str(item.get("stub_class") or "").strip()
            carrier_key = str(item.get("carrier_key") or "").strip()
            carrier_class = str(item.get("carrier_class") or "").strip()
            container_key = str(item.get("container_key") or "").strip()
            container_class = str(item.get("container_class") or "").strip()
            holder_key = str(item.get("holder_key") or "").strip()
            holder_class = str(item.get("holder_class") or "").strip()
            slot_key = str(item.get("slot_key") or "").strip()
            slot_class = str(item.get("slot_class") or "").strip()
            store_key = str(item.get("store_key") or "").strip()
            store_class = str(item.get("store_class") or "").strip()
            store_state = str(item.get("store_state") or "").strip().lower()
            capture_method = str(item.get("capture_method") or "").strip()
            restore_method = str(item.get("restore_method") or "").strip()
            rollback_slot = str(item.get("rollback_slot") or "").strip()
            supports_capture_store = bool(item.get("supports_capture_store"))
            supports_restore_store = bool(item.get("supports_restore_store"))
            supports_runtime_state_store = bool(item.get("supports_runtime_state_store"))
            instantiate_method = str(item.get("instantiate_method") or "").strip()
            capture_store_stub = str(item.get("capture_store_stub") or "").strip()
            restore_store_stub = str(item.get("restore_store_stub") or "").strip()
            rollback_store_stub = str(item.get("rollback_store_stub") or "").strip()
            runtime_state_store_stub = str(item.get("runtime_state_store_stub") or "").strip()
            capture_handle_key = str(item.get("capture_handle_key") or "").strip()
            restore_handle_key = str(item.get("restore_handle_key") or "").strip()
            rollback_handle_key = str(item.get("rollback_handle_key") or "").strip()
            capture_handle_state = str(item.get("capture_handle_state") or "").strip().lower()
            slot_payload_entry_count = int(item.get("slot_payload_entry_count") or 0)
            slot_payload_digest = str(item.get("slot_payload_digest") or "").strip()
            slot_payload_preview = dict(item.get("slot_payload_preview") or {}) if isinstance(item.get("slot_payload_preview"), dict) else {}
            store_payload_entry_count = int(item.get("store_payload_entry_count") or 0)
            store_payload_digest = str(item.get("store_payload_digest") or "").strip()
            store_payload_preview = dict(item.get("store_payload_preview") or {}) if isinstance(item.get("store_payload_preview"), dict) else {}
            if name:
                runtime_snapshot_state_stores.append((name, snapshot_object_key, snapshot_object_class, stub_key, stub_class, carrier_key, carrier_class, container_key, container_class, holder_key, holder_class, slot_key, slot_class, store_key, store_class, store_state, capture_method, restore_method, rollback_slot, supports_capture_store, supports_restore_store, supports_runtime_state_store, instantiate_method, capture_store_stub, restore_store_stub, rollback_store_stub, runtime_state_store_stub, capture_handle_key, restore_handle_key, rollback_handle_key, capture_handle_state, slot_payload_entry_count, slot_payload_digest, slot_payload_preview, store_payload_entry_count, store_payload_digest, store_payload_preview))
        runtime_snapshot_state_store_summary = str(plan.get("runtime_snapshot_state_store_summary") or "").strip()
        runtime_snapshot_state_registries = []
        for item in list(plan.get("runtime_snapshot_state_registries") or []):
            try:
                item = dict(item or {})
            except Exception:
                item = {}
            name = str(item.get("name") or "").strip()
            snapshot_object_key = str(item.get("snapshot_object_key") or "").strip()
            snapshot_object_class = str(item.get("snapshot_object_class") or "").strip()
            stub_key = str(item.get("stub_key") or "").strip()
            stub_class = str(item.get("stub_class") or "").strip()
            carrier_key = str(item.get("carrier_key") or "").strip()
            carrier_class = str(item.get("carrier_class") or "").strip()
            container_key = str(item.get("container_key") or "").strip()
            container_class = str(item.get("container_class") or "").strip()
            holder_key = str(item.get("holder_key") or "").strip()
            holder_class = str(item.get("holder_class") or "").strip()
            slot_key = str(item.get("slot_key") or "").strip()
            slot_class = str(item.get("slot_class") or "").strip()
            store_key = str(item.get("store_key") or "").strip()
            store_class = str(item.get("store_class") or "").strip()
            registry_key = str(item.get("registry_key") or "").strip()
            registry_class = str(item.get("registry_class") or "").strip()
            registry_state = str(item.get("registry_state") or "").strip().lower()
            capture_method = str(item.get("capture_method") or "").strip()
            restore_method = str(item.get("restore_method") or "").strip()
            rollback_slot = str(item.get("rollback_slot") or "").strip()
            supports_capture_registry = bool(item.get("supports_capture_registry"))
            supports_restore_registry = bool(item.get("supports_restore_registry"))
            supports_runtime_state_registry = bool(item.get("supports_runtime_state_registry"))
            instantiate_method = str(item.get("instantiate_method") or "").strip()
            capture_registry_stub = str(item.get("capture_registry_stub") or "").strip()
            restore_registry_stub = str(item.get("restore_registry_stub") or "").strip()
            rollback_registry_stub = str(item.get("rollback_registry_stub") or "").strip()
            runtime_state_registry_stub = str(item.get("runtime_state_registry_stub") or "").strip()
            capture_handle_key = str(item.get("capture_handle_key") or "").strip()
            restore_handle_key = str(item.get("restore_handle_key") or "").strip()
            rollback_handle_key = str(item.get("rollback_handle_key") or "").strip()
            handle_store_key = str(item.get("handle_store_key") or "").strip()
            handle_store_class = str(item.get("handle_store_class") or "").strip()
            handle_store_state = str(item.get("handle_store_state") or "").strip().lower()
            store_payload_entry_count = int(item.get("store_payload_entry_count") or 0)
            store_payload_digest = str(item.get("store_payload_digest") or "").strip()
            store_payload_preview = dict(item.get("store_payload_preview") or {}) if isinstance(item.get("store_payload_preview"), dict) else {}
            registry_payload_entry_count = int(item.get("registry_payload_entry_count") or 0)
            registry_payload_digest = str(item.get("registry_payload_digest") or "").strip()
            registry_payload_preview = dict(item.get("registry_payload_preview") or {}) if isinstance(item.get("registry_payload_preview"), dict) else {}
            if name:
                runtime_snapshot_state_registries.append((name, snapshot_object_key, snapshot_object_class, stub_key, stub_class, carrier_key, carrier_class, container_key, container_class, holder_key, holder_class, slot_key, slot_class, store_key, store_class, registry_key, registry_class, registry_state, capture_method, restore_method, rollback_slot, supports_capture_registry, supports_restore_registry, supports_runtime_state_registry, instantiate_method, capture_registry_stub, restore_registry_stub, rollback_registry_stub, runtime_state_registry_stub, capture_handle_key, restore_handle_key, rollback_handle_key, handle_store_key, handle_store_class, handle_store_state, store_payload_entry_count, store_payload_digest, store_payload_preview, registry_payload_entry_count, registry_payload_digest, registry_payload_preview))
        runtime_snapshot_state_registry_summary = str(plan.get("runtime_snapshot_state_registry_summary") or "").strip()
        runtime_snapshot_state_registry_backends = []
        for item in list(plan.get("runtime_snapshot_state_registry_backends") or []):
            try:
                item = dict(item or {})
            except Exception:
                item = {}
            name = str(item.get("name") or "").strip()
            snapshot_object_key = str(item.get("snapshot_object_key") or "").strip()
            snapshot_object_class = str(item.get("snapshot_object_class") or "").strip()
            stub_key = str(item.get("stub_key") or "").strip()
            stub_class = str(item.get("stub_class") or "").strip()
            carrier_key = str(item.get("carrier_key") or "").strip()
            carrier_class = str(item.get("carrier_class") or "").strip()
            container_key = str(item.get("container_key") or "").strip()
            container_class = str(item.get("container_class") or "").strip()
            holder_key = str(item.get("holder_key") or "").strip()
            holder_class = str(item.get("holder_class") or "").strip()
            slot_key = str(item.get("slot_key") or "").strip()
            slot_class = str(item.get("slot_class") or "").strip()
            store_key = str(item.get("store_key") or "").strip()
            store_class = str(item.get("store_class") or "").strip()
            registry_key = str(item.get("registry_key") or "").strip()
            registry_class = str(item.get("registry_class") or "").strip()
            backend_key = str(item.get("backend_key") or "").strip()
            backend_class = str(item.get("backend_class") or "").strip()
            backend_state = str(item.get("backend_state") or "").strip().lower()
            capture_method = str(item.get("capture_method") or "").strip()
            restore_method = str(item.get("restore_method") or "").strip()
            rollback_slot = str(item.get("rollback_slot") or "").strip()
            supports_capture_backend = bool(item.get("supports_capture_backend"))
            supports_restore_backend = bool(item.get("supports_restore_backend"))
            supports_runtime_state_backend = bool(item.get("supports_runtime_state_backend"))
            instantiate_method = str(item.get("instantiate_method") or "").strip()
            capture_backend_stub = str(item.get("capture_backend_stub") or "").strip()
            restore_backend_stub = str(item.get("restore_backend_stub") or "").strip()
            rollback_backend_stub = str(item.get("rollback_backend_stub") or "").strip()
            runtime_state_backend_stub = str(item.get("runtime_state_backend_stub") or "").strip()
            handle_register_key = str(item.get("handle_register_key") or "").strip()
            handle_register_class = str(item.get("handle_register_class") or "").strip()
            handle_register_state = str(item.get("handle_register_state") or "").strip().lower()
            registry_slot_key = str(item.get("registry_slot_key") or "").strip()
            registry_slot_class = str(item.get("registry_slot_class") or "").strip()
            registry_slot_state = str(item.get("registry_slot_state") or "").strip().lower()
            registry_payload_entry_count = int(item.get("registry_payload_entry_count") or 0)
            registry_payload_digest = str(item.get("registry_payload_digest") or "").strip()
            registry_payload_preview = dict(item.get("registry_payload_preview") or {}) if isinstance(item.get("registry_payload_preview"), dict) else {}
            backend_payload_entry_count = int(item.get("backend_payload_entry_count") or 0)
            backend_payload_digest = str(item.get("backend_payload_digest") or "").strip()
            backend_payload_preview = dict(item.get("backend_payload_preview") or {}) if isinstance(item.get("backend_payload_preview"), dict) else {}
            if name:
                runtime_snapshot_state_registry_backends.append((name, snapshot_object_key, snapshot_object_class, stub_key, stub_class, carrier_key, carrier_class, container_key, container_class, holder_key, holder_class, slot_key, slot_class, store_key, store_class, registry_key, registry_class, backend_key, backend_class, backend_state, capture_method, restore_method, rollback_slot, supports_capture_backend, supports_restore_backend, supports_runtime_state_backend, instantiate_method, capture_backend_stub, restore_backend_stub, rollback_backend_stub, runtime_state_backend_stub, handle_register_key, handle_register_class, handle_register_state, registry_slot_key, registry_slot_class, registry_slot_state, registry_payload_entry_count, registry_payload_digest, registry_payload_preview, backend_payload_entry_count, backend_payload_digest, backend_payload_preview))
        runtime_snapshot_state_registry_backend_summary = str(plan.get("runtime_snapshot_state_registry_backend_summary") or "").strip()
        runtime_snapshot_state_registry_backend_adapters = []
        for item in list(plan.get("runtime_snapshot_state_registry_backend_adapters") or []):
            try:
                item = dict(item or {})
            except Exception:
                item = {}
            name = str(item.get("name") or "").strip()
            snapshot_object_key = str(item.get("snapshot_object_key") or "").strip()
            snapshot_object_class = str(item.get("snapshot_object_class") or "").strip()
            stub_key = str(item.get("stub_key") or "").strip()
            stub_class = str(item.get("stub_class") or "").strip()
            carrier_key = str(item.get("carrier_key") or "").strip()
            carrier_class = str(item.get("carrier_class") or "").strip()
            container_key = str(item.get("container_key") or "").strip()
            container_class = str(item.get("container_class") or "").strip()
            holder_key = str(item.get("holder_key") or "").strip()
            holder_class = str(item.get("holder_class") or "").strip()
            slot_key = str(item.get("slot_key") or "").strip()
            slot_class = str(item.get("slot_class") or "").strip()
            store_key = str(item.get("store_key") or "").strip()
            store_class = str(item.get("store_class") or "").strip()
            registry_key = str(item.get("registry_key") or "").strip()
            registry_class = str(item.get("registry_class") or "").strip()
            backend_key = str(item.get("backend_key") or "").strip()
            backend_class = str(item.get("backend_class") or "").strip()
            adapter_key = str(item.get("adapter_key") or "").strip()
            adapter_class = str(item.get("adapter_class") or "").strip()
            adapter_state = str(item.get("adapter_state") or "").strip().lower()
            capture_method = str(item.get("capture_method") or "").strip()
            restore_method = str(item.get("restore_method") or "").strip()
            rollback_slot = str(item.get("rollback_slot") or "").strip()
            supports_capture_backend_adapter = bool(item.get("supports_capture_backend_adapter"))
            supports_restore_backend_adapter = bool(item.get("supports_restore_backend_adapter"))
            supports_runtime_state_backend_adapter = bool(item.get("supports_runtime_state_backend_adapter"))
            instantiate_method = str(item.get("instantiate_method") or "").strip()
            capture_adapter_stub = str(item.get("capture_adapter_stub") or "").strip()
            restore_adapter_stub = str(item.get("restore_adapter_stub") or "").strip()
            rollback_adapter_stub = str(item.get("rollback_adapter_stub") or "").strip()
            runtime_state_backend_adapter_stub = str(item.get("runtime_state_backend_adapter_stub") or "").strip()
            backend_store_adapter_key = str(item.get("backend_store_adapter_key") or "").strip()
            backend_store_adapter_class = str(item.get("backend_store_adapter_class") or "").strip()
            backend_store_adapter_state = str(item.get("backend_store_adapter_state") or "").strip().lower()
            registry_slot_backend_key = str(item.get("registry_slot_backend_key") or "").strip()
            registry_slot_backend_class = str(item.get("registry_slot_backend_class") or "").strip()
            registry_slot_backend_state = str(item.get("registry_slot_backend_state") or "").strip().lower()
            backend_payload_entry_count = int(item.get("backend_payload_entry_count") or 0)
            backend_payload_digest = str(item.get("backend_payload_digest") or "").strip()
            backend_payload_preview = dict(item.get("backend_payload_preview") or {}) if isinstance(item.get("backend_payload_preview"), dict) else {}
            adapter_payload_entry_count = int(item.get("adapter_payload_entry_count") or 0)
            adapter_payload_digest = str(item.get("adapter_payload_digest") or "").strip()
            adapter_payload_preview = dict(item.get("adapter_payload_preview") or {}) if isinstance(item.get("adapter_payload_preview"), dict) else {}
            if name:
                runtime_snapshot_state_registry_backend_adapters.append((name, snapshot_object_key, snapshot_object_class, stub_key, stub_class, carrier_key, carrier_class, container_key, container_class, holder_key, holder_class, slot_key, slot_class, store_key, store_class, registry_key, registry_class, backend_key, backend_class, adapter_key, adapter_class, adapter_state, capture_method, restore_method, rollback_slot, supports_capture_backend_adapter, supports_restore_backend_adapter, supports_runtime_state_backend_adapter, instantiate_method, capture_adapter_stub, restore_adapter_stub, rollback_adapter_stub, runtime_state_backend_adapter_stub, backend_store_adapter_key, backend_store_adapter_class, backend_store_adapter_state, registry_slot_backend_key, registry_slot_backend_class, registry_slot_backend_state, backend_payload_entry_count, backend_payload_digest, backend_payload_preview, adapter_payload_entry_count, adapter_payload_digest, adapter_payload_preview))
        runtime_snapshot_state_registry_backend_adapter_summary = str(plan.get("runtime_snapshot_state_registry_backend_adapter_summary") or "").strip()
        runtime_snapshot_bundle_summary = str(plan.get("runtime_snapshot_bundle_summary") or "").strip()
        runtime_snapshot_apply_runner_summary = str(plan.get("runtime_snapshot_apply_runner_summary") or "").strip()
        runtime_snapshot_dry_run_summary = str(plan.get("runtime_snapshot_dry_run_summary") or "").strip()
        first_minimal_case_summary = str(plan.get("first_minimal_case_summary") or "").strip()
        runtime_snapshot_precommit_contract_summary = str(plan.get("runtime_snapshot_precommit_contract_summary") or "").strip()
        runtime_snapshot_atomic_entrypoints_summary = str(plan.get("runtime_snapshot_atomic_entrypoints_summary") or "").strip()
        runtime_snapshot_mutation_gate_capsule_summary = str(plan.get("runtime_snapshot_mutation_gate_capsule_summary") or "").strip()
        runtime_snapshot_command_undo_shell_summary = str(plan.get("runtime_snapshot_command_undo_shell_summary") or "").strip()
        runtime_snapshot_command_factory_payload_summary = str(plan.get("runtime_snapshot_command_factory_payload_summary") or "").strip()
        runtime_snapshot_preview_command_construction_summary = str(plan.get("runtime_snapshot_preview_command_construction_summary") or "").strip()
        runtime_snapshot_dry_command_executor_summary = str(plan.get("runtime_snapshot_dry_command_executor_summary") or "").strip()
        runtime_snapshot_state_holder_summary = str(plan.get("runtime_snapshot_state_holder_summary") or "").strip()
        try:
            bundle_plan = dict(plan.get("runtime_snapshot_bundle") or {})
        except Exception:
            bundle_plan = {}
        runtime_snapshot_bundle = {
            "bundle_key": str(bundle_plan.get("bundle_key") or "").strip(),
            "transaction_key": str(bundle_plan.get("transaction_key") or "").strip(),
            "transaction_container_kind": str(bundle_plan.get("transaction_container_kind") or "").strip(),
            "bundle_state": str(bundle_plan.get("bundle_state") or "").strip().lower(),
            "object_count": int(bundle_plan.get("object_count") or 0),
            "ready_object_count": int(bundle_plan.get("ready_object_count") or 0),
            "required_snapshot_count": int(bundle_plan.get("required_snapshot_count") or 0),
            "snapshot_object_keys": [str(x).strip() for x in list(bundle_plan.get("snapshot_object_keys") or []) if str(x).strip()],
            "capture_methods": [str(x).strip() for x in list(bundle_plan.get("capture_methods") or []) if str(x).strip()],
            "restore_methods": [str(x).strip() for x in list(bundle_plan.get("restore_methods") or []) if str(x).strip()],
            "rollback_slots": [str(x).strip() for x in list(bundle_plan.get("rollback_slots") or []) if str(x).strip()],
            "payload_digests": [str(x).strip() for x in list(bundle_plan.get("payload_digests") or []) if str(x).strip()],
            "commit_stub": str(bundle_plan.get("commit_stub") or "").strip(),
            "rollback_stub": str(bundle_plan.get("rollback_stub") or "").strip(),
            "bundle_stub": str(bundle_plan.get("bundle_stub") or "").strip(),
        }
        try:
            apply_runner_plan = dict(plan.get("runtime_snapshot_apply_runner") or {})
        except Exception:
            apply_runner_plan = {}
        runtime_snapshot_apply_runner = {
            "runner_key": str(apply_runner_plan.get("runner_key") or "").strip(),
            "transaction_key": str(apply_runner_plan.get("transaction_key") or "").strip(),
            "bundle_key": str(apply_runner_plan.get("bundle_key") or "").strip(),
            "apply_mode": str(apply_runner_plan.get("apply_mode") or "").strip(),
            "runner_state": str(apply_runner_plan.get("runner_state") or "").strip().lower(),
            "phase_count": int(apply_runner_plan.get("phase_count") or 0),
            "ready_phase_count": int(apply_runner_plan.get("ready_phase_count") or 0),
            "apply_sequence": [str(x).strip() for x in list(apply_runner_plan.get("apply_sequence") or []) if str(x).strip()],
            "restore_sequence": [str(x).strip() for x in list(apply_runner_plan.get("restore_sequence") or []) if str(x).strip()],
            "rollback_sequence": [str(x).strip() for x in list(apply_runner_plan.get("rollback_sequence") or []) if str(x).strip()],
            "rehearsed_steps": [str(x).strip() for x in list(apply_runner_plan.get("rehearsed_steps") or []) if str(x).strip()],
            "phase_results": [dict(x or {}) for x in list(apply_runner_plan.get("phase_results") or []) if isinstance(x, dict)],
            "state_registry_backend_adapter_calls": [str(x).strip() for x in list(apply_runner_plan.get("state_registry_backend_adapter_calls") or []) if str(x).strip()],
            "state_registry_backend_adapter_summary": str(apply_runner_plan.get("state_registry_backend_adapter_summary") or "").strip(),
            "backend_store_adapter_calls": [str(x).strip() for x in list(apply_runner_plan.get("backend_store_adapter_calls") or []) if str(x).strip()],
            "backend_store_adapter_summary": str(apply_runner_plan.get("backend_store_adapter_summary") or "").strip(),
            "registry_slot_backend_calls": [str(x).strip() for x in list(apply_runner_plan.get("registry_slot_backend_calls") or []) if str(x).strip()],
            "registry_slot_backend_summary": str(apply_runner_plan.get("registry_slot_backend_summary") or "").strip(),
            "runner_dispatch_summary": str(apply_runner_plan.get("runner_dispatch_summary") or "").strip(),
            "commit_preview_only": bool(apply_runner_plan.get("commit_preview_only")),
            "rollback_rehearsed": bool(apply_runner_plan.get("rollback_rehearsed")),
            "apply_runner_stub": str(apply_runner_plan.get("apply_runner_stub") or "").strip(),
        }
        try:
            first_minimal_case_plan = dict(plan.get("first_minimal_case_report") or {})
        except Exception:
            first_minimal_case_plan = {}
        first_minimal_case_report = {
            "minimal_case_key": str(first_minimal_case_plan.get("minimal_case_key") or "").strip(),
            "transaction_key": str(first_minimal_case_plan.get("transaction_key") or "").strip(),
            "candidate_state": str(first_minimal_case_plan.get("candidate_state") or "").strip().lower(),
            "target_kind": str(first_minimal_case_plan.get("target_kind") or "").strip().lower(),
            "target_empty": bool(first_minimal_case_plan.get("target_empty")),
            "audio_clip_count": int(first_minimal_case_plan.get("audio_clip_count") or 0),
            "audio_fx_count": int(first_minimal_case_plan.get("audio_fx_count") or 0),
            "note_fx_count": int(first_minimal_case_plan.get("note_fx_count") or 0),
            "bundle_ready": bool(first_minimal_case_plan.get("bundle_ready")),
            "apply_runner_ready": bool(first_minimal_case_plan.get("apply_runner_ready")),
            "dry_run_ready": bool(first_minimal_case_plan.get("dry_run_ready")),
            "future_unlock_ready": bool(first_minimal_case_plan.get("future_unlock_ready")),
            "blocked_by": [str(x).strip() for x in list(first_minimal_case_plan.get("blocked_by") or []) if str(x).strip()],
            "pending_by": [str(x).strip() for x in list(first_minimal_case_plan.get("pending_by") or []) if str(x).strip()],
            "summary": str(first_minimal_case_plan.get("summary") or "").strip(),
        }
        try:
            precommit_contract_plan = dict(plan.get("runtime_snapshot_precommit_contract") or {})
        except Exception:
            precommit_contract_plan = {}
        runtime_snapshot_precommit_contract = {
            "contract_key": str(precommit_contract_plan.get("contract_key") or "").strip(),
            "transaction_key": str(precommit_contract_plan.get("transaction_key") or "").strip(),
            "minimal_case_key": str(precommit_contract_plan.get("minimal_case_key") or "").strip(),
            "contract_state": str(precommit_contract_plan.get("contract_state") or "").strip().lower(),
            "mutation_gate_state": str(precommit_contract_plan.get("mutation_gate_state") or "").strip().lower(),
            "target_scope": str(precommit_contract_plan.get("target_scope") or "").strip(),
            "target_empty": bool(precommit_contract_plan.get("target_empty")),
            "preview_phase_count": int(precommit_contract_plan.get("preview_phase_count") or 0),
            "ready_preview_phase_count": int(precommit_contract_plan.get("ready_preview_phase_count") or 0),
            "preview_commit_sequence": [str(x).strip() for x in list(precommit_contract_plan.get("preview_commit_sequence") or []) if str(x).strip()],
            "preview_rollback_sequence": [str(x).strip() for x in list(precommit_contract_plan.get("preview_rollback_sequence") or []) if str(x).strip()],
            "preview_phase_results": [dict(x or {}) for x in list(precommit_contract_plan.get("preview_phase_results") or []) if isinstance(x, dict)],
            "bundle_key": str(precommit_contract_plan.get("bundle_key") or "").strip(),
            "apply_runner_key": str(precommit_contract_plan.get("apply_runner_key") or "").strip(),
            "dry_run_key": str(precommit_contract_plan.get("dry_run_key") or "").strip(),
            "future_commit_stub": str(precommit_contract_plan.get("future_commit_stub") or "").strip(),
            "future_rollback_stub": str(precommit_contract_plan.get("future_rollback_stub") or "").strip(),
            "commit_preview_only": bool(precommit_contract_plan.get("commit_preview_only")),
            "project_mutation_enabled": bool(precommit_contract_plan.get("project_mutation_enabled")),
            "blocked_by": [str(x).strip() for x in list(precommit_contract_plan.get("blocked_by") or []) if str(x).strip()],
            "pending_by": [str(x).strip() for x in list(precommit_contract_plan.get("pending_by") or []) if str(x).strip()],
            "summary": str(precommit_contract_plan.get("summary") or "").strip(),
        }
        try:
            atomic_entrypoints_plan = dict(plan.get("runtime_snapshot_atomic_entrypoints") or {})
        except Exception:
            atomic_entrypoints_plan = {}
        runtime_snapshot_atomic_entrypoints = {
            "entrypoint_key": str(atomic_entrypoints_plan.get("entrypoint_key") or "").strip(),
            "transaction_key": str(atomic_entrypoints_plan.get("transaction_key") or "").strip(),
            "contract_key": str(atomic_entrypoints_plan.get("contract_key") or "").strip(),
            "entrypoint_state": str(atomic_entrypoints_plan.get("entrypoint_state") or "").strip().lower(),
            "mutation_gate_state": str(atomic_entrypoints_plan.get("mutation_gate_state") or "").strip().lower(),
            "target_scope": str(atomic_entrypoints_plan.get("target_scope") or "").strip(),
            "owner_class": str(atomic_entrypoints_plan.get("owner_class") or "").strip(),
            "total_entrypoint_count": int(atomic_entrypoints_plan.get("total_entrypoint_count") or 0),
            "ready_entrypoint_count": int(atomic_entrypoints_plan.get("ready_entrypoint_count") or 0),
            "entrypoints": [dict(x or {}) for x in list(atomic_entrypoints_plan.get("entrypoints") or []) if isinstance(x, dict)],
            "preview_dispatch_sequence": [str(x).strip() for x in list(atomic_entrypoints_plan.get("preview_dispatch_sequence") or []) if str(x).strip()],
            "future_apply_stub": str(atomic_entrypoints_plan.get("future_apply_stub") or "").strip(),
            "future_commit_stub": str(atomic_entrypoints_plan.get("future_commit_stub") or "").strip(),
            "future_rollback_stub": str(atomic_entrypoints_plan.get("future_rollback_stub") or "").strip(),
            "blocked_by": [str(x).strip() for x in list(atomic_entrypoints_plan.get("blocked_by") or []) if str(x).strip()],
            "pending_by": [str(x).strip() for x in list(atomic_entrypoints_plan.get("pending_by") or []) if str(x).strip()],
            "summary": str(atomic_entrypoints_plan.get("summary") or "").strip(),
        }
        try:
            mutation_gate_capsule_plan = dict(plan.get("runtime_snapshot_mutation_gate_capsule") or {})
        except Exception:
            mutation_gate_capsule_plan = {}
        runtime_snapshot_mutation_gate_capsule = {
            "capsule_key": str(mutation_gate_capsule_plan.get("capsule_key") or "").strip(),
            "transaction_key": str(mutation_gate_capsule_plan.get("transaction_key") or "").strip(),
            "contract_key": str(mutation_gate_capsule_plan.get("contract_key") or "").strip(),
            "entrypoint_key": str(mutation_gate_capsule_plan.get("entrypoint_key") or "").strip(),
            "capsule_state": str(mutation_gate_capsule_plan.get("capsule_state") or "").strip().lower(),
            "mutation_gate_state": str(mutation_gate_capsule_plan.get("mutation_gate_state") or "").strip().lower(),
            "target_scope": str(mutation_gate_capsule_plan.get("target_scope") or "").strip(),
            "owner_class": str(mutation_gate_capsule_plan.get("owner_class") or "").strip(),
            "total_capsule_step_count": int(mutation_gate_capsule_plan.get("total_capsule_step_count") or 0),
            "ready_capsule_step_count": int(mutation_gate_capsule_plan.get("ready_capsule_step_count") or 0),
            "capsule_steps": [dict(x or {}) for x in list(mutation_gate_capsule_plan.get("capsule_steps") or []) if isinstance(x, dict)],
            "preview_capsule_sequence": [str(x).strip() for x in list(mutation_gate_capsule_plan.get("preview_capsule_sequence") or []) if str(x).strip()],
            "future_gate_stub": str(mutation_gate_capsule_plan.get("future_gate_stub") or "").strip(),
            "future_capsule_stub": str(mutation_gate_capsule_plan.get("future_capsule_stub") or "").strip(),
            "future_commit_stub": str(mutation_gate_capsule_plan.get("future_commit_stub") or "").strip(),
            "future_rollback_stub": str(mutation_gate_capsule_plan.get("future_rollback_stub") or "").strip(),
            "blocked_by": [str(x).strip() for x in list(mutation_gate_capsule_plan.get("blocked_by") or []) if str(x).strip()],
            "pending_by": [str(x).strip() for x in list(mutation_gate_capsule_plan.get("pending_by") or []) if str(x).strip()],
            "summary": str(mutation_gate_capsule_plan.get("summary") or "").strip(),
        }
        try:
            command_undo_shell_plan = dict(plan.get("runtime_snapshot_command_undo_shell") or {})
        except Exception:
            command_undo_shell_plan = {}
        runtime_snapshot_command_undo_shell = {
            "shell_key": str(command_undo_shell_plan.get("shell_key") or "").strip(),
            "transaction_key": str(command_undo_shell_plan.get("transaction_key") or "").strip(),
            "capsule_key": str(command_undo_shell_plan.get("capsule_key") or "").strip(),
            "contract_key": str(command_undo_shell_plan.get("contract_key") or "").strip(),
            "shell_state": str(command_undo_shell_plan.get("shell_state") or "").strip().lower(),
            "mutation_gate_state": str(command_undo_shell_plan.get("mutation_gate_state") or "").strip().lower(),
            "target_scope": str(command_undo_shell_plan.get("target_scope") or "").strip(),
            "owner_class": str(command_undo_shell_plan.get("owner_class") or "").strip(),
            "command_class": str(command_undo_shell_plan.get("command_class") or "").strip(),
            "command_module": str(command_undo_shell_plan.get("command_module") or "").strip(),
            "total_shell_step_count": int(command_undo_shell_plan.get("total_shell_step_count") or 0),
            "ready_shell_step_count": int(command_undo_shell_plan.get("ready_shell_step_count") or 0),
            "shell_steps": [dict(x or {}) for x in list(command_undo_shell_plan.get("shell_steps") or []) if isinstance(x, dict)],
            "preview_shell_sequence": [str(x).strip() for x in list(command_undo_shell_plan.get("preview_shell_sequence") or []) if str(x).strip()],
            "future_command_stub": str(command_undo_shell_plan.get("future_command_stub") or "").strip(),
            "future_undo_stub": str(command_undo_shell_plan.get("future_undo_stub") or "").strip(),
            "future_commit_stub": str(command_undo_shell_plan.get("future_commit_stub") or "").strip(),
            "future_rollback_stub": str(command_undo_shell_plan.get("future_rollback_stub") or "").strip(),
            "blocked_by": [str(x).strip() for x in list(command_undo_shell_plan.get("blocked_by") or []) if str(x).strip()],
            "pending_by": [str(x).strip() for x in list(command_undo_shell_plan.get("pending_by") or []) if str(x).strip()],
            "summary": str(command_undo_shell_plan.get("summary") or "").strip(),
        }
        try:
            command_factory_payload_plan = dict(plan.get("runtime_snapshot_command_factory_payloads") or {})
        except Exception:
            command_factory_payload_plan = {}
        runtime_snapshot_command_factory_payloads = {
            "factory_key": str(command_factory_payload_plan.get("factory_key") or "").strip(),
            "transaction_key": str(command_factory_payload_plan.get("transaction_key") or "").strip(),
            "shell_key": str(command_factory_payload_plan.get("shell_key") or "").strip(),
            "capsule_key": str(command_factory_payload_plan.get("capsule_key") or "").strip(),
            "contract_key": str(command_factory_payload_plan.get("contract_key") or "").strip(),
            "payload_state": str(command_factory_payload_plan.get("payload_state") or "").strip().lower(),
            "mutation_gate_state": str(command_factory_payload_plan.get("mutation_gate_state") or "").strip().lower(),
            "target_scope": str(command_factory_payload_plan.get("target_scope") or "").strip(),
            "owner_class": str(command_factory_payload_plan.get("owner_class") or "").strip(),
            "command_class": str(command_factory_payload_plan.get("command_class") or "").strip(),
            "command_module": str(command_factory_payload_plan.get("command_module") or "").strip(),
            "label_preview": str(command_factory_payload_plan.get("label_preview") or "").strip(),
            "payload_delta_kind": str(command_factory_payload_plan.get("payload_delta_kind") or "").strip(),
            "materialized_payload_count": int(command_factory_payload_plan.get("materialized_payload_count") or 0),
            "before_payload_summary": dict(command_factory_payload_plan.get("before_payload_summary") or {}) if isinstance(command_factory_payload_plan.get("before_payload_summary"), dict) else {},
            "after_payload_summary": dict(command_factory_payload_plan.get("after_payload_summary") or {}) if isinstance(command_factory_payload_plan.get("after_payload_summary"), dict) else {},
            "total_factory_step_count": int(command_factory_payload_plan.get("total_factory_step_count") or 0),
            "ready_factory_step_count": int(command_factory_payload_plan.get("ready_factory_step_count") or 0),
            "factory_steps": [dict(x or {}) for x in list(command_factory_payload_plan.get("factory_steps") or []) if isinstance(x, dict)],
            "preview_factory_sequence": [str(x).strip() for x in list(command_factory_payload_plan.get("preview_factory_sequence") or []) if str(x).strip()],
            "future_factory_stub": str(command_factory_payload_plan.get("future_factory_stub") or "").strip(),
            "future_before_snapshot_stub": str(command_factory_payload_plan.get("future_before_snapshot_stub") or "").strip(),
            "future_after_snapshot_stub": str(command_factory_payload_plan.get("future_after_snapshot_stub") or "").strip(),
            "blocked_by": [str(x).strip() for x in list(command_factory_payload_plan.get("blocked_by") or []) if str(x).strip()],
            "pending_by": [str(x).strip() for x in list(command_factory_payload_plan.get("pending_by") or []) if str(x).strip()],
            "summary": str(command_factory_payload_plan.get("summary") or "").strip(),
        }
        try:
            preview_command_plan = dict(plan.get("runtime_snapshot_preview_command_construction") or {})
        except Exception:
            preview_command_plan = {}
        runtime_snapshot_preview_command_construction = {
            "preview_command_key": str(preview_command_plan.get("preview_command_key") or "").strip(),
            "transaction_key": str(preview_command_plan.get("transaction_key") or "").strip(),
            "factory_key": str(preview_command_plan.get("factory_key") or "").strip(),
            "shell_key": str(preview_command_plan.get("shell_key") or "").strip(),
            "capsule_key": str(preview_command_plan.get("capsule_key") or "").strip(),
            "contract_key": str(preview_command_plan.get("contract_key") or "").strip(),
            "preview_state": str(preview_command_plan.get("preview_state") or "").strip().lower(),
            "mutation_gate_state": str(preview_command_plan.get("mutation_gate_state") or "").strip().lower(),
            "target_scope": str(preview_command_plan.get("target_scope") or "").strip(),
            "owner_class": str(preview_command_plan.get("owner_class") or "").strip(),
            "command_class": str(preview_command_plan.get("command_class") or "").strip(),
            "command_module": str(preview_command_plan.get("command_module") or "").strip(),
            "command_constructor": str(preview_command_plan.get("command_constructor") or "").strip(),
            "label_preview": str(preview_command_plan.get("label_preview") or "").strip(),
            "apply_callback_name": str(preview_command_plan.get("apply_callback_name") or "").strip(),
            "apply_callback_owner_class": str(preview_command_plan.get("apply_callback_owner_class") or "").strip(),
            "payload_delta_kind": str(preview_command_plan.get("payload_delta_kind") or "").strip(),
            "materialized_payload_count": int(preview_command_plan.get("materialized_payload_count") or 0),
            "before_payload_summary": dict(preview_command_plan.get("before_payload_summary") or {}) if isinstance(preview_command_plan.get("before_payload_summary"), dict) else {},
            "after_payload_summary": dict(preview_command_plan.get("after_payload_summary") or {}) if isinstance(preview_command_plan.get("after_payload_summary"), dict) else {},
            "command_field_names": [str(x).strip() for x in list(preview_command_plan.get("command_field_names") or []) if str(x).strip()],
            "total_preview_step_count": int(preview_command_plan.get("total_preview_step_count") or 0),
            "ready_preview_step_count": int(preview_command_plan.get("ready_preview_step_count") or 0),
            "preview_steps": [dict(x or {}) for x in list(preview_command_plan.get("preview_steps") or []) if isinstance(x, dict)],
            "preview_command_sequence": [str(x).strip() for x in list(preview_command_plan.get("preview_command_sequence") or []) if str(x).strip()],
            "future_constructor_stub": str(preview_command_plan.get("future_constructor_stub") or "").strip(),
            "future_executor_stub": str(preview_command_plan.get("future_executor_stub") or "").strip(),
            "blocked_by": [str(x).strip() for x in list(preview_command_plan.get("blocked_by") or []) if str(x).strip()],
            "pending_by": [str(x).strip() for x in list(preview_command_plan.get("pending_by") or []) if str(x).strip()],
            "summary": str(preview_command_plan.get("summary") or "").strip(),
        }
        try:
            dry_command_executor_plan = dict(plan.get("runtime_snapshot_dry_command_executor") or {})
        except Exception:
            dry_command_executor_plan = {}
        runtime_snapshot_dry_command_executor = {
            "dry_executor_key": str(dry_command_executor_plan.get("dry_executor_key") or "").strip(),
            "transaction_key": str(dry_command_executor_plan.get("transaction_key") or "").strip(),
            "preview_command_key": str(dry_command_executor_plan.get("preview_command_key") or "").strip(),
            "factory_key": str(dry_command_executor_plan.get("factory_key") or "").strip(),
            "shell_key": str(dry_command_executor_plan.get("shell_key") or "").strip(),
            "capsule_key": str(dry_command_executor_plan.get("capsule_key") or "").strip(),
            "contract_key": str(dry_command_executor_plan.get("contract_key") or "").strip(),
            "dry_executor_state": str(dry_command_executor_plan.get("dry_executor_state") or "").strip().lower(),
            "mutation_gate_state": str(dry_command_executor_plan.get("mutation_gate_state") or "").strip().lower(),
            "target_scope": str(dry_command_executor_plan.get("target_scope") or "").strip(),
            "owner_class": str(dry_command_executor_plan.get("owner_class") or "").strip(),
            "command_class": str(dry_command_executor_plan.get("command_class") or "").strip(),
            "command_module": str(dry_command_executor_plan.get("command_module") or "").strip(),
            "command_constructor": str(dry_command_executor_plan.get("command_constructor") or "").strip(),
            "label_preview": str(dry_command_executor_plan.get("label_preview") or "").strip(),
            "apply_callback_name": str(dry_command_executor_plan.get("apply_callback_name") or "").strip(),
            "apply_callback_owner_class": str(dry_command_executor_plan.get("apply_callback_owner_class") or "").strip(),
            "payload_delta_kind": str(dry_command_executor_plan.get("payload_delta_kind") or "").strip(),
            "materialized_payload_count": int(dry_command_executor_plan.get("materialized_payload_count") or 0),
            "before_payload_summary": dict(dry_command_executor_plan.get("before_payload_summary") or {}) if isinstance(dry_command_executor_plan.get("before_payload_summary"), dict) else {},
            "after_payload_summary": dict(dry_command_executor_plan.get("after_payload_summary") or {}) if isinstance(dry_command_executor_plan.get("after_payload_summary"), dict) else {},
            "do_call_count": int(dry_command_executor_plan.get("do_call_count") or 0),
            "undo_call_count": int(dry_command_executor_plan.get("undo_call_count") or 0),
            "callback_call_count": int(dry_command_executor_plan.get("callback_call_count") or 0),
            "callback_trace": [str(x).strip() for x in list(dry_command_executor_plan.get("callback_trace") or []) if str(x).strip()],
            "callback_payload_digests": [str(x).strip() for x in list(dry_command_executor_plan.get("callback_payload_digests") or []) if str(x).strip()],
            "total_simulation_step_count": int(dry_command_executor_plan.get("total_simulation_step_count") or 0),
            "ready_simulation_step_count": int(dry_command_executor_plan.get("ready_simulation_step_count") or 0),
            "simulation_steps": [dict(x or {}) for x in list(dry_command_executor_plan.get("simulation_steps") or []) if isinstance(x, dict)],
            "simulation_sequence": [str(x).strip() for x in list(dry_command_executor_plan.get("simulation_sequence") or []) if str(x).strip()],
            "future_executor_stub": str(dry_command_executor_plan.get("future_executor_stub") or "").strip(),
            "future_live_executor_stub": str(dry_command_executor_plan.get("future_live_executor_stub") or "").strip(),
            "blocked_by": [str(x).strip() for x in list(dry_command_executor_plan.get("blocked_by") or []) if str(x).strip()],
            "pending_by": [str(x).strip() for x in list(dry_command_executor_plan.get("pending_by") or []) if str(x).strip()],
            "summary": str(dry_command_executor_plan.get("summary") or "").strip(),
        }
        try:
            dry_run_plan = dict(plan.get("runtime_snapshot_dry_run") or {})
        except Exception:
            dry_run_plan = {}
        runtime_snapshot_dry_run = {
            "runner_key": str(dry_run_plan.get("runner_key") or "").strip(),
            "transaction_key": str(dry_run_plan.get("transaction_key") or "").strip(),
            "bundle_key": str(dry_run_plan.get("bundle_key") or "").strip(),
            "dry_run_mode": str(dry_run_plan.get("dry_run_mode") or "").strip(),
            "runner_state": str(dry_run_plan.get("runner_state") or "").strip().lower(),
            "phase_count": int(dry_run_plan.get("phase_count") or 0),
            "ready_phase_count": int(dry_run_plan.get("ready_phase_count") or 0),
            "capture_sequence": [str(x).strip() for x in list(dry_run_plan.get("capture_sequence") or []) if str(x).strip()],
            "restore_sequence": [str(x).strip() for x in list(dry_run_plan.get("restore_sequence") or []) if str(x).strip()],
            "rollback_sequence": [str(x).strip() for x in list(dry_run_plan.get("rollback_sequence") or []) if str(x).strip()],
            "rehearsed_steps": [str(x).strip() for x in list(dry_run_plan.get("rehearsed_steps") or []) if str(x).strip()],
            "phase_results": [dict(x or {}) for x in list(dry_run_plan.get("phase_results") or []) if isinstance(x, dict)],
            "capture_method_calls": [str(x).strip() for x in list(dry_run_plan.get("capture_method_calls") or []) if str(x).strip()],
            "restore_method_calls": [str(x).strip() for x in list(dry_run_plan.get("restore_method_calls") or []) if str(x).strip()],
            "state_carrier_calls": [str(x).strip() for x in list(dry_run_plan.get("state_carrier_calls") or []) if str(x).strip()],
            "state_carrier_summary": str(dry_run_plan.get("state_carrier_summary") or "").strip(),
            "state_container_calls": [str(x).strip() for x in list(dry_run_plan.get("state_container_calls") or []) if str(x).strip()],
            "state_container_summary": str(dry_run_plan.get("state_container_summary") or "").strip(),
            "state_holder_calls": [str(x).strip() for x in list(dry_run_plan.get("state_holder_calls") or []) if str(x).strip()],
            "state_holder_summary": str(dry_run_plan.get("state_holder_summary") or "").strip(),
            "state_slot_calls": [str(x).strip() for x in list(dry_run_plan.get("state_slot_calls") or []) if str(x).strip()],
            "state_slot_summary": str(dry_run_plan.get("state_slot_summary") or "").strip(),
            "state_store_calls": [str(x).strip() for x in list(dry_run_plan.get("state_store_calls") or []) if str(x).strip()],
            "state_store_summary": str(dry_run_plan.get("state_store_summary") or "").strip(),
            "state_registry_calls": [str(x).strip() for x in list(dry_run_plan.get("state_registry_calls") or []) if str(x).strip()],
            "state_registry_summary": str(dry_run_plan.get("state_registry_summary") or "").strip(),
            "state_registry_backend_calls": [str(x).strip() for x in list(dry_run_plan.get("state_registry_backend_calls") or []) if str(x).strip()],
            "state_registry_backend_summary": str(dry_run_plan.get("state_registry_backend_summary") or "").strip(),
            "state_registry_backend_adapter_calls": [str(x).strip() for x in list(dry_run_plan.get("state_registry_backend_adapter_calls") or []) if str(x).strip()],
            "state_registry_backend_adapter_summary": str(dry_run_plan.get("state_registry_backend_adapter_summary") or "").strip(),
            "runner_dispatch_summary": str(dry_run_plan.get("runner_dispatch_summary") or "").strip(),
            "commit_rehearsed": bool(dry_run_plan.get("commit_rehearsed")),
            "rollback_rehearsed": bool(dry_run_plan.get("rollback_rehearsed")),
            "dry_run_stub": str(dry_run_plan.get("dry_run_stub") or "").strip(),
        }
        runtime_snapshot_preview = []
        for item in list(plan.get("runtime_snapshot_preview") or []):
            try:
                item = dict(item or {})
            except Exception:
                item = {}
            name = str(item.get("name") or "").strip()
            ref = str(item.get("ref") or "").strip()
            item_summary = str(item.get("summary") or "").strip()
            available = bool(item.get("available"))
            if name:
                runtime_snapshot_preview.append((name, ref, available, item_summary))
        runtime_snapshot_handles = []
        for item in list(plan.get("runtime_snapshot_handles") or []):
            try:
                item = dict(item or {})
            except Exception:
                item = {}
            name = str(item.get("name") or "").strip()
            handle_key = str(item.get("handle_key") or "").strip()
            capture_state = str(item.get("capture_state") or "").strip().lower()
            owner_scope = str(item.get("owner_scope") or "").strip()
            owner_ids = [str(x).strip() for x in list(item.get("owner_ids") or []) if str(x).strip()]
            item_summary = str(item.get("summary") or "").strip()
            capture_stub = str(item.get("capture_stub") or "").strip()
            if name:
                runtime_snapshot_handles.append((name, handle_key, capture_state, owner_scope, owner_ids, item_summary, capture_stub))
        runtime_snapshot_captures = []
        for item in list(plan.get("runtime_snapshot_captures") or []):
            try:
                item = dict(item or {})
            except Exception:
                item = {}
            name = str(item.get("name") or "").strip()
            capture_key = str(item.get("capture_key") or "").strip()
            capture_object_kind = str(item.get("capture_object_kind") or "").strip()
            capture_state = str(item.get("capture_state") or "").strip().lower()
            owner_scope = str(item.get("owner_scope") or "").strip()
            owner_ids = [str(x).strip() for x in list(item.get("owner_ids") or []) if str(x).strip()]
            capture_stub = str(item.get("capture_stub") or "").strip()
            payload_preview = dict(item.get("payload_preview") or {}) if isinstance(item.get("payload_preview"), dict) else {}
            payload_entry_count = int(item.get("payload_entry_count") or 0)
            if name:
                runtime_snapshot_captures.append((name, capture_key, capture_object_kind, capture_state, owner_scope, owner_ids, capture_stub, payload_entry_count, payload_preview))
        readiness_summary = str(plan.get("readiness_summary") or "").strip()
        impact_summary = str(plan.get("impact_summary") or "").strip()
        message = str(plan.get("blocked_message") or "SmartDrop noch gesperrt: Audio->Instrument-Morphing ist noch nicht freigeschaltet.")
        can_apply = bool(plan.get("can_apply"))
        try:
            box = QMessageBox(self)
            box.setIcon(QMessageBox.Icon.Warning)
            box.setWindowTitle("SmartDrop Sicherheitspruefung")
            if can_apply:
                box.setText(f"{plugin_name} wirklich auf {track_name} morphen?")
            else:
                box.setText(f"{plugin_name} kann noch nicht direkt auf {track_name} gemorpht werden.")
            info_lines = [message]
            if track_summary:
                info_lines.append(f"Zielspur: {track_summary}")
            if impact_summary:
                info_lines.append(impact_summary)
            if transaction_summary:
                info_lines.append(transaction_summary)
            if snapshot_ref_summary:
                info_lines.append(snapshot_ref_summary)
            if runtime_snapshot_summary:
                info_lines.append(runtime_snapshot_summary)
            if runtime_snapshot_handle_summary:
                info_lines.append(runtime_snapshot_handle_summary)
            if runtime_snapshot_capture_summary:
                info_lines.append(runtime_snapshot_capture_summary)
            if runtime_snapshot_instance_summary:
                info_lines.append(runtime_snapshot_instance_summary)
            if runtime_snapshot_object_summary:
                info_lines.append(runtime_snapshot_object_summary)
            if runtime_snapshot_stub_summary:
                info_lines.append(runtime_snapshot_stub_summary)
            if runtime_snapshot_state_carrier_summary:
                info_lines.append(runtime_snapshot_state_carrier_summary)
            if runtime_snapshot_state_holder_summary:
                info_lines.append(runtime_snapshot_state_holder_summary)
            if runtime_snapshot_state_slot_summary:
                info_lines.append(runtime_snapshot_state_slot_summary)
            if runtime_snapshot_state_store_summary:
                info_lines.append(runtime_snapshot_state_store_summary)
            if runtime_snapshot_state_registry_summary:
                info_lines.append(runtime_snapshot_state_registry_summary)
            if runtime_snapshot_state_registry_backend_summary:
                info_lines.append(runtime_snapshot_state_registry_backend_summary)
            if runtime_snapshot_state_registry_backend_adapter_summary:
                info_lines.append(runtime_snapshot_state_registry_backend_adapter_summary)
            if runtime_snapshot_bundle_summary:
                info_lines.append(runtime_snapshot_bundle_summary)
            if runtime_snapshot_apply_runner_summary:
                info_lines.append(runtime_snapshot_apply_runner_summary)
            if runtime_snapshot_dry_run_summary:
                info_lines.append(runtime_snapshot_dry_run_summary)
            if first_minimal_case_summary:
                info_lines.append(first_minimal_case_summary)
            if runtime_snapshot_precommit_contract_summary:
                info_lines.append(runtime_snapshot_precommit_contract_summary)
            if runtime_snapshot_atomic_entrypoints_summary:
                info_lines.append(runtime_snapshot_atomic_entrypoints_summary)
            if runtime_snapshot_mutation_gate_capsule_summary:
                info_lines.append(runtime_snapshot_mutation_gate_capsule_summary)
            if runtime_snapshot_command_undo_shell_summary:
                info_lines.append(runtime_snapshot_command_undo_shell_summary)
            if runtime_snapshot_command_factory_payload_summary:
                info_lines.append(runtime_snapshot_command_factory_payload_summary)
            if runtime_snapshot_preview_command_construction_summary:
                info_lines.append(runtime_snapshot_preview_command_construction_summary)
            if runtime_snapshot_dry_command_executor_summary:
                info_lines.append(runtime_snapshot_dry_command_executor_summary)
            if readiness_summary:
                info_lines.append(readiness_summary)
            if can_apply:
                info_lines.append("Bitte nur bestaetigen, wenn die Sicherheitspruefung nachvollziehbar ist.")
            else:
                info_lines.append("Dieser Dialog ist aktuell nur eine Sicherheitsvorschau - es wird noch nichts veraendert.")
            box.setInformativeText("\n\n".join([ln for ln in info_lines if ln]))
            detail_sections = []
            if blocked_reasons:
                detail_sections.append(
                    "Risiken / Blocker:\n" + "\n".join([f"- {reason}" for reason in blocked_reasons])
                )
            if rollback_lines:
                detail_sections.append(
                    "Rueckbau vor echter Freigabe:\n" + "\n".join([f"- {line}" for line in rollback_lines])
                )
            if future_apply_steps:
                detail_sections.append(
                    "Spaetere atomare Apply-Phase:\n" + "\n".join(future_apply_steps)
                )
            if required_snapshots:
                detail_sections.append(
                    "Noetige Snapshots:\n" + "\n".join([f"- {item}" for item in required_snapshots])
                )
            if snapshot_refs:
                detail_sections.append(
                    "Geplante Snapshot-Referenzen:\n" + "\n".join([f"- {name} -> {ref}" for (name, ref) in snapshot_refs])
                )
            if runtime_snapshot_preview:
                runtime_lines = []
                for (name, ref, available, summary) in runtime_snapshot_preview:
                    prefix = "READY" if available else "PENDING"
                    line = f"- [{prefix}] {name}"
                    if ref:
                        line += f" -> {ref}"
                    if summary:
                        line += f" — {summary}"
                    runtime_lines.append(line)
                detail_sections.append(
                    "Aktuelle Runtime-Snapshot-Vorschau:\n" + "\n".join(runtime_lines)
                )
            if runtime_snapshot_handles:
                handle_state_label = {"ready": "READY", "pending": "PENDING", "blocked": "BLOCKED"}
                handle_lines = []
                for (name, handle_key, capture_state, owner_scope, owner_ids, summary, capture_stub) in runtime_snapshot_handles:
                    prefix = handle_state_label.get(capture_state, capture_state.upper() or "INFO")
                    scope_text = f"scope={owner_scope}" if owner_scope else "scope=unbekannt"
                    owner_text = f"targets={len(owner_ids)}"
                    line = f"- [{prefix}] {name} -> {handle_key} ({scope_text}, {owner_text})"
                    if capture_stub:
                        line += f" · stub={capture_stub}"
                    if summary:
                        line += f" — {summary}"
                    handle_lines.append(line)
                detail_sections.append(
                    "Runtime-Snapshot-Handle-Vorschau:\n" + "\n".join(handle_lines)
                )
            if runtime_snapshot_captures:
                capture_state_label = {"ready": "READY", "pending": "PENDING", "blocked": "BLOCKED"}
                capture_lines = []
                for (name, capture_key, capture_object_kind, capture_state, owner_scope, owner_ids, capture_stub, payload_entry_count, payload_preview) in runtime_snapshot_captures:
                    prefix = capture_state_label.get(capture_state, capture_state.upper() or "INFO")
                    scope_text = f"scope={owner_scope}" if owner_scope else "scope=unbekannt"
                    owner_text = f"targets={len(owner_ids)}"
                    line = f"- [{prefix}] {name} -> {capture_key} ({capture_object_kind or 'capture'}, {scope_text}, {owner_text})"
                    if capture_stub:
                        line += f" · stub={capture_stub}"
                    if payload_entry_count > 0:
                        line += f" · payload={payload_entry_count}"
                    preview_parts = []
                    for p_key, p_val in list((payload_preview or {}).items())[:4]:
                        if isinstance(p_val, list):
                            preview_parts.append(f"{p_key}={len(p_val)}")
                        else:
                            preview_parts.append(f"{p_key}={p_val}")
                    if preview_parts:
                        line += f" — {'; '.join(preview_parts)}"
                    capture_lines.append(line)
                detail_sections.append(
                    "Runtime-Capture-Objekt-Vorschau:\n" + "\n".join(capture_lines)
                )
            if runtime_snapshot_instances:
                instance_state_label = {"ready": "READY", "pending": "PENDING", "blocked": "BLOCKED"}
                instance_lines = []
                for (name, snapshot_instance_key, snapshot_instance_kind, snapshot_state, owner_scope, owner_ids, snapshot_stub, snapshot_payload_entry_count, payload_digest, snapshot_payload) in runtime_snapshot_instances:
                    prefix = instance_state_label.get(snapshot_state, snapshot_state.upper() or "INFO")
                    scope_text = f"scope={owner_scope}" if owner_scope else "scope=unbekannt"
                    owner_text = f"targets={len(owner_ids)}"
                    line = f"- [{prefix}] {name} -> {snapshot_instance_key} ({snapshot_instance_kind or 'instance'}, {scope_text}, {owner_text})"
                    if snapshot_stub:
                        line += f" · stub={snapshot_stub}"
                    if snapshot_payload_entry_count > 0:
                        line += f" · payload={snapshot_payload_entry_count}"
                    if payload_digest:
                        line += f" · digest={payload_digest}"
                    preview_parts = []
                    for p_key, p_val in list((snapshot_payload or {}).items())[:4]:
                        if isinstance(p_val, list):
                            preview_parts.append(f"{p_key}={len(p_val)}")
                        else:
                            preview_parts.append(f"{p_key}={p_val}")
                    if preview_parts:
                        line += f" — {'; '.join(preview_parts)}"
                    instance_lines.append(line)
                detail_sections.append(
                    "Runtime-Snapshot-Instanz-Vorschau:\n" + "\n".join(instance_lines)
                )
            if runtime_snapshot_stubs:
                stub_state_label = {"ready": "READY", "pending": "PENDING", "blocked": "BLOCKED"}
                stub_lines = []
                for (name, snapshot_object_key, snapshot_object_class, bind_state, stub_key, stub_class, dispatch_state, capture_method, restore_method, rollback_slot, supports_capture_preview, supports_restore_preview, factory_method, capture_stub, restore_stub, rollback_stub) in runtime_snapshot_stubs:
                    prefix = stub_state_label.get(dispatch_state, dispatch_state.upper() or "INFO")
                    line = f"- [{prefix}] {name} -> {stub_key} ({stub_class or 'RuntimeSnapshotStub'})"
                    if snapshot_object_key:
                        line += f" · obj={snapshot_object_key}"
                    if snapshot_object_class:
                        line += f" · class={snapshot_object_class}"
                    if factory_method:
                        line += f" · factory={factory_method}"
                    method_parts = []
                    if capture_method:
                        method_parts.append(f"capture={capture_method}")
                    if restore_method:
                        method_parts.append(f"restore={restore_method}")
                    if rollback_slot:
                        method_parts.append(f"rollback={rollback_slot}")
                    if method_parts:
                        line += " — " + "; ".join(method_parts)
                    stub_parts = []
                    if supports_capture_preview:
                        stub_parts.append("capture-preview")
                    if supports_restore_preview:
                        stub_parts.append("restore-preview")
                    if capture_stub:
                        stub_parts.append(capture_stub)
                    if restore_stub:
                        stub_parts.append(restore_stub)
                    if rollback_stub:
                        stub_parts.append(rollback_stub)
                    if stub_parts:
                        line += f" · {' | '.join(stub_parts[:4])}"
                    stub_lines.append(line)
                detail_sections.append(
                    "Runtime-Snapshot-Stubs / Klassenkopplung:\n" + "\n".join(stub_lines)
                )
            if runtime_snapshot_state_carriers:
                carrier_state_label = {"ready": "READY", "pending": "PENDING", "blocked": "BLOCKED"}
                carrier_lines = []
                for (name, snapshot_object_key, snapshot_object_class, stub_key, stub_class, carrier_key, carrier_class, carrier_state, capture_method, restore_method, rollback_slot, supports_capture_state, supports_restore_state, bind_method, capture_state_stub, restore_state_stub, rollback_state_stub, state_payload_entry_count, state_payload_digest, state_payload_preview) in runtime_snapshot_state_carriers:
                    prefix = carrier_state_label.get(carrier_state, carrier_state.upper() or "INFO")
                    line = f"- [{prefix}] {name} -> {carrier_key} ({carrier_class or 'RuntimeSnapshotStateCarrier'})"
                    if snapshot_object_key:
                        line += f" · obj={snapshot_object_key}"
                    if snapshot_object_class:
                        line += f" · class={snapshot_object_class}"
                    if stub_key:
                        line += f" · stub={stub_key}"
                    if stub_class:
                        line += f" · stub-class={stub_class}"
                    if bind_method:
                        line += f" · bind={bind_method}"
                    method_parts = []
                    if capture_method:
                        method_parts.append(f"capture={capture_method}")
                    if restore_method:
                        method_parts.append(f"restore={restore_method}")
                    if rollback_slot:
                        method_parts.append(f"rollback={rollback_slot}")
                    if method_parts:
                        line += " — " + "; ".join(method_parts)
                    stub_parts = []
                    if supports_capture_state:
                        stub_parts.append("capture-state")
                    if supports_restore_state:
                        stub_parts.append("restore-state")
                    if capture_state_stub:
                        stub_parts.append(capture_state_stub)
                    if restore_state_stub:
                        stub_parts.append(restore_state_stub)
                    if rollback_state_stub:
                        stub_parts.append(rollback_state_stub)
                    if stub_parts:
                        line += f" · {' | '.join(stub_parts[:4])}"
                    if state_payload_entry_count > 0:
                        line += f" · payload={state_payload_entry_count}"
                    if state_payload_digest:
                        line += f" · digest={state_payload_digest}"
                    preview_parts = []
                    for p_key, p_val in list((state_payload_preview or {}).items())[:4]:
                        if isinstance(p_val, list):
                            preview_parts.append(f"{p_key}={len(p_val)}")
                        else:
                            preview_parts.append(f"{p_key}={p_val}")
                    if preview_parts:
                        line += f" — {'; '.join(preview_parts)}"
                    carrier_lines.append(line)
                detail_sections.append(
                    "Runtime-Zustandstraeger / State-Carrier:\n" + "\n".join(carrier_lines)
                )
            if runtime_snapshot_state_containers:
                container_state_label = {"ready": "READY", "pending": "PENDING", "blocked": "BLOCKED"}
                container_lines = []
                for (name, snapshot_object_key, snapshot_object_class, stub_key, stub_class, carrier_key, carrier_class, container_key, container_class, container_state, capture_method, restore_method, rollback_slot, supports_capture_container, supports_restore_container, supports_runtime_state_container, instantiate_method, capture_container_stub, restore_container_stub, rollback_container_stub, runtime_state_stub, state_payload_entry_count, state_payload_digest, state_payload_preview, container_payload_entry_count, container_payload_digest, container_payload_preview) in runtime_snapshot_state_containers:
                    prefix = container_state_label.get(container_state, container_state.upper() or "INFO")
                    line = f"- [{prefix}] {name} -> {container_key} ({container_class or 'RuntimeSnapshotStateContainer'})"
                    if snapshot_object_key:
                        line += f" · obj={snapshot_object_key}"
                    if snapshot_object_class:
                        line += f" · class={snapshot_object_class}"
                    if carrier_key:
                        line += f" · carrier={carrier_key}"
                    if carrier_class:
                        line += f" · carrier-class={carrier_class}"
                    if stub_key:
                        line += f" · stub={stub_key}"
                    if stub_class:
                        line += f" · stub-class={stub_class}"
                    if instantiate_method:
                        line += f" · bind={instantiate_method}"
                    method_parts = []
                    if capture_method:
                        method_parts.append(f"capture={capture_method}")
                    if restore_method:
                        method_parts.append(f"restore={restore_method}")
                    if rollback_slot:
                        method_parts.append(f"rollback={rollback_slot}")
                    if method_parts:
                        line += " — " + "; ".join(method_parts)
                    stub_parts = []
                    if supports_capture_container:
                        stub_parts.append("capture-container")
                    if supports_restore_container:
                        stub_parts.append("restore-container")
                    if supports_runtime_state_container:
                        stub_parts.append("runtime-state")
                    if capture_container_stub:
                        stub_parts.append(capture_container_stub)
                    if restore_container_stub:
                        stub_parts.append(restore_container_stub)
                    if rollback_container_stub:
                        stub_parts.append(rollback_container_stub)
                    if runtime_state_stub:
                        stub_parts.append(runtime_state_stub)
                    if stub_parts:
                        line += f" · {' | '.join(stub_parts[:5])}"
                    if container_payload_entry_count > 0:
                        line += f" · payload={container_payload_entry_count}"
                    if container_payload_digest:
                        line += f" · digest={container_payload_digest}"
                    preview_parts = []
                    for p_key, p_val in list((container_payload_preview or {}).items())[:4]:
                        if isinstance(p_val, list):
                            preview_parts.append(f"{p_key}={len(p_val)}")
                        elif isinstance(p_val, dict):
                            preview_parts.append(f"{p_key}={len(p_val)}")
                        else:
                            preview_parts.append(f"{p_key}={p_val}")
                    if preview_parts:
                        line += f" — {'; '.join(preview_parts)}"
                    container_lines.append(line)
                detail_sections.append(
                    "Separate Runtime-State-Container:\n" + "\n".join(container_lines)
                )
            if runtime_snapshot_state_holders:
                holder_state_label = {"ready": "READY", "pending": "PENDING", "blocked": "BLOCKED"}
                holder_lines = []
                for (name, snapshot_object_key, snapshot_object_class, stub_key, stub_class, carrier_key, carrier_class, container_key, container_class, holder_key, holder_class, holder_state, capture_method, restore_method, rollback_slot, supports_capture_holder, supports_restore_holder, supports_runtime_state_holder, instantiate_method, capture_holder_stub, restore_holder_stub, rollback_holder_stub, runtime_holder_stub, container_payload_entry_count, container_payload_digest, container_payload_preview, holder_payload_entry_count, holder_payload_digest, holder_payload_preview) in runtime_snapshot_state_holders:
                    prefix = holder_state_label.get(holder_state, holder_state.upper() or "INFO")
                    line = f"- [{prefix}] {name} -> {holder_key} ({holder_class or 'RuntimeSnapshotStateHolder'})"
                    if snapshot_object_key:
                        line += f" · obj={snapshot_object_key}"
                    if snapshot_object_class:
                        line += f" · class={snapshot_object_class}"
                    if container_key:
                        line += f" · container={container_key}"
                    if container_class:
                        line += f" · container-class={container_class}"
                    if carrier_key:
                        line += f" · carrier={carrier_key}"
                    if carrier_class:
                        line += f" · carrier-class={carrier_class}"
                    if stub_key:
                        line += f" · stub={stub_key}"
                    if stub_class:
                        line += f" · stub-class={stub_class}"
                    if instantiate_method:
                        line += f" · bind={instantiate_method}"
                    method_parts = []
                    if capture_method:
                        method_parts.append(f"capture={capture_method}")
                    if restore_method:
                        method_parts.append(f"restore={restore_method}")
                    if rollback_slot:
                        method_parts.append(f"rollback={rollback_slot}")
                    if method_parts:
                        line += " — " + "; ".join(method_parts)
                    stub_parts = []
                    if supports_capture_holder:
                        stub_parts.append("capture-holder")
                    if supports_restore_holder:
                        stub_parts.append("restore-holder")
                    if supports_runtime_state_holder:
                        stub_parts.append("runtime-holder")
                    if capture_holder_stub:
                        stub_parts.append(capture_holder_stub)
                    if restore_holder_stub:
                        stub_parts.append(restore_holder_stub)
                    if rollback_holder_stub:
                        stub_parts.append(rollback_holder_stub)
                    if runtime_holder_stub:
                        stub_parts.append(runtime_holder_stub)
                    if stub_parts:
                        line += f" · {' | '.join(stub_parts[:5])}"
                    if holder_payload_entry_count > 0:
                        line += f" · payload={holder_payload_entry_count}"
                    if holder_payload_digest:
                        line += f" · digest={holder_payload_digest}"
                    preview_parts = []
                    for p_key, p_val in list((holder_payload_preview or {}).items())[:4]:
                        if isinstance(p_val, list):
                            preview_parts.append(f"{p_key}={len(p_val)}")
                        elif isinstance(p_val, dict):
                            preview_parts.append(f"{p_key}={len(p_val)}")
                        else:
                            preview_parts.append(f"{p_key}={p_val}")
                    if preview_parts:
                        line += f" — {'; '.join(preview_parts)}"
                    holder_lines.append(line)
                detail_sections.append(
                    "Separate Runtime-State-Halter:\n" + "\n".join(holder_lines)
                )

            if runtime_snapshot_state_slots:
                slot_state_label = {"ready": "READY", "pending": "PENDING", "blocked": "BLOCKED"}
                slot_lines = []
                for (name, snapshot_object_key, snapshot_object_class, stub_key, stub_class, carrier_key, carrier_class, container_key, container_class, holder_key, holder_class, slot_key, slot_class, slot_state, capture_method, restore_method, rollback_slot, supports_capture_slot, supports_restore_slot, supports_runtime_state_slot, instantiate_method, capture_slot_stub, restore_slot_stub, rollback_slot_stub, runtime_state_slot_stub, holder_payload_entry_count, holder_payload_digest, holder_payload_preview, slot_payload_entry_count, slot_payload_digest, slot_payload_preview) in runtime_snapshot_state_slots:
                    prefix = slot_state_label.get(slot_state, slot_state.upper() or "INFO")
                    line = f"- [{prefix}] {name} -> {slot_key} ({slot_class or 'RuntimeSnapshotStateSlot'})"
                    if snapshot_object_key:
                        line += f" · obj={snapshot_object_key}"
                    if snapshot_object_class:
                        line += f" · class={snapshot_object_class}"
                    if holder_key:
                        line += f" · holder={holder_key}"
                    if holder_class:
                        line += f" · holder-class={holder_class}"
                    if container_key:
                        line += f" · container={container_key}"
                    if container_class:
                        line += f" · container-class={container_class}"
                    if carrier_key:
                        line += f" · carrier={carrier_key}"
                    if carrier_class:
                        line += f" · carrier-class={carrier_class}"
                    if stub_key:
                        line += f" · stub={stub_key}"
                    if stub_class:
                        line += f" · stub-class={stub_class}"
                    if instantiate_method:
                        line += f" · bind={instantiate_method}"
                    method_parts = []
                    if capture_method:
                        method_parts.append(f"capture={capture_method}")
                    if restore_method:
                        method_parts.append(f"restore={restore_method}")
                    if rollback_slot:
                        method_parts.append(f"rollback={rollback_slot}")
                    if method_parts:
                        line += " — " + "; ".join(method_parts)
                    stub_parts = []
                    if supports_capture_slot:
                        stub_parts.append("capture-slot")
                    if supports_restore_slot:
                        stub_parts.append("restore-slot")
                    if supports_runtime_state_slot:
                        stub_parts.append("runtime-slot")
                    for stub_text in (capture_slot_stub, restore_slot_stub, rollback_slot_stub, runtime_state_slot_stub):
                        if stub_text:
                            stub_parts.append(stub_text)
                    if stub_parts:
                        line += f" · {' | '.join(stub_parts[:5])}"
                    if slot_payload_entry_count > 0:
                        line += f" · payload={slot_payload_entry_count}"
                    if slot_payload_digest:
                        line += f" · digest={slot_payload_digest}"
                    preview_parts = []
                    for p_key, p_val in list((slot_payload_preview or {}).items())[:4]:
                        if isinstance(p_val, list):
                            preview_parts.append(f"{p_key}={len(p_val)}")
                        elif isinstance(p_val, dict):
                            preview_parts.append(f"{p_key}={len(p_val)}")
                        else:
                            preview_parts.append(f"{p_key}={p_val}")
                    if preview_parts:
                        line += f" — {'; '.join(preview_parts)}"
                    slot_lines.append(line)
                detail_sections.append(
                    "Runtime-State-Slots / Snapshot-State-Speicher:\n" + "\n".join(slot_lines)
                )

            if runtime_snapshot_state_stores:
                store_state_label = {"ready": "READY", "pending": "PENDING", "blocked": "BLOCKED"}
                store_lines = []
                for (name, snapshot_object_key, snapshot_object_class, stub_key, stub_class, carrier_key, carrier_class, container_key, container_class, holder_key, holder_class, slot_key, slot_class, store_key, store_class, store_state, capture_method, restore_method, rollback_slot, supports_capture_store, supports_restore_store, supports_runtime_state_store, instantiate_method, capture_store_stub, restore_store_stub, rollback_store_stub, runtime_state_store_stub, capture_handle_key, restore_handle_key, rollback_handle_key, capture_handle_state, slot_payload_entry_count, slot_payload_digest, slot_payload_preview, store_payload_entry_count, store_payload_digest, store_payload_preview) in runtime_snapshot_state_stores:
                    prefix = store_state_label.get(store_state, store_state.upper() or "INFO")
                    line = f"- [{prefix}] {name} -> {store_key} ({store_class or 'RuntimeSnapshotStateStore'})"
                    if snapshot_object_key:
                        line += f" · obj={snapshot_object_key}"
                    if snapshot_object_class:
                        line += f" · class={snapshot_object_class}"
                    if slot_key:
                        line += f" · slot={slot_key}"
                    if slot_class:
                        line += f" · slot-class={slot_class}"
                    if holder_key:
                        line += f" · holder={holder_key}"
                    if holder_class:
                        line += f" · holder-class={holder_class}"
                    if instantiate_method:
                        line += f" · bind={instantiate_method}"
                    handle_parts = []
                    if capture_handle_key:
                        handle_parts.append(f"capture-handle={capture_handle_key}")
                    if restore_handle_key:
                        handle_parts.append(f"restore-handle={restore_handle_key}")
                    if rollback_handle_key:
                        handle_parts.append(f"rollback-handle={rollback_handle_key}")
                    if capture_handle_state:
                        handle_parts.append(f"handle-state={capture_handle_state}")
                    if handle_parts:
                        line += " — " + "; ".join(handle_parts[:4])
                    stub_parts = []
                    if supports_capture_store:
                        stub_parts.append("capture-store")
                    if supports_restore_store:
                        stub_parts.append("restore-store")
                    if supports_runtime_state_store:
                        stub_parts.append("runtime-store")
                    for stub_text in (capture_store_stub, restore_store_stub, rollback_store_stub, runtime_state_store_stub):
                        if stub_text:
                            stub_parts.append(stub_text)
                    if stub_parts:
                        line += f" · {' | '.join(stub_parts[:5])}"
                    if store_payload_entry_count > 0:
                        line += f" · payload={store_payload_entry_count}"
                    if store_payload_digest:
                        line += f" · digest={store_payload_digest}"
                    preview_parts = []
                    for p_key, p_val in list((store_payload_preview or {}).items())[:4]:
                        if isinstance(p_val, list):
                            preview_parts.append(f"{p_key}={len(p_val)}")
                        elif isinstance(p_val, dict):
                            preview_parts.append(f"{p_key}={len(p_val)}")
                        else:
                            preview_parts.append(f"{p_key}={p_val}")
                    if preview_parts:
                        line += f" — {'; '.join(preview_parts)}"
                    store_lines.append(line)
                detail_sections.append(
                    "Runtime-State-Stores / Capture-Handles:\n" + "\n".join(store_lines)
                )

            if runtime_snapshot_state_registries:
                registry_lines = []
                for (name, snapshot_object_key, snapshot_object_class, stub_key, stub_class, carrier_key, carrier_class, container_key, container_class, holder_key, holder_class, slot_key, slot_class, store_key, store_class, registry_key, registry_class, registry_state, capture_method, restore_method, rollback_slot, supports_capture_registry, supports_restore_registry, supports_runtime_state_registry, instantiate_method, capture_registry_stub, restore_registry_stub, rollback_registry_stub, runtime_state_registry_stub, capture_handle_key, restore_handle_key, rollback_handle_key, handle_store_key, handle_store_class, handle_store_state, store_payload_entry_count, store_payload_digest, store_payload_preview, registry_payload_entry_count, registry_payload_digest, registry_payload_preview) in runtime_snapshot_state_registries:
                    prefix = state_label.get(registry_state, registry_state.upper() if registry_state else "INFO")
                    line = f"- [{prefix}] {name} ({snapshot_object_class or 'snapshot'}) -> {registry_key or 'registry'}"
                    key_parts = []
                    for key_name, key_val in (("stub", stub_key), ("carrier", carrier_key), ("container", container_key), ("holder", holder_key), ("slot", slot_key), ("store", store_key), ("handle-store", handle_store_key)):
                        if key_val:
                            key_parts.append(f"{key_name}={key_val}")
                    if key_parts:
                        line += " — " + "; ".join(key_parts[:7])
                    handle_parts = []
                    for key_name, key_val in (("capture-handle", capture_handle_key), ("restore-handle", restore_handle_key), ("rollback-handle", rollback_handle_key), ("handle-store-class", handle_store_class)):
                        if key_val:
                            handle_parts.append(f"{key_name}={key_val}")
                    if handle_store_state:
                        handle_parts.append(f"handle-store-state={handle_store_state}")
                    if handle_parts:
                        line += " · " + " | ".join(handle_parts[:5])
                    stub_parts = []
                    if supports_capture_registry:
                        stub_parts.append("capture-registry")
                    if supports_restore_registry:
                        stub_parts.append("restore-registry")
                    if supports_runtime_state_registry:
                        stub_parts.append("runtime-registry")
                    for stub_text in (capture_registry_stub, restore_registry_stub, rollback_registry_stub, runtime_state_registry_stub):
                        if stub_text:
                            stub_parts.append(stub_text)
                    if stub_parts:
                        line += f" · {' | '.join(stub_parts[:5])}"
                    if registry_payload_entry_count > 0:
                        line += f" · payload={registry_payload_entry_count}"
                    if registry_payload_digest:
                        line += f" · digest={registry_payload_digest}"
                    preview_parts = []
                    for p_key, p_val in list((registry_payload_preview or {}).items())[:4]:
                        if isinstance(p_val, list):
                            preview_parts.append(f"{p_key}={len(p_val)}")
                        elif isinstance(p_val, dict):
                            preview_parts.append(f"{p_key}={len(p_val)}")
                        else:
                            preview_parts.append(f"{p_key}={p_val}")
                    if preview_parts:
                        line += f" — {'; '.join(preview_parts)}"
                    registry_lines.append(line)
                detail_sections.append(
                    "Runtime-State-Registries / Handle-Speicher\n" + "\n".join(registry_lines)
                )

            if runtime_snapshot_state_registry_backends:
                backend_state_label = {"ready": "READY", "pending": "PENDING", "blocked": "BLOCKED"}
                backend_lines = []
                for (name, snapshot_object_key, snapshot_object_class, stub_key, stub_class, carrier_key, carrier_class, container_key, container_class, holder_key, holder_class, slot_key, slot_class, store_key, store_class, registry_key, registry_class, backend_key, backend_class, backend_state, capture_method, restore_method, rollback_slot, supports_capture_backend, supports_restore_backend, supports_runtime_state_backend, instantiate_method, capture_backend_stub, restore_backend_stub, rollback_backend_stub, runtime_state_backend_stub, handle_register_key, handle_register_class, handle_register_state, registry_slot_key, registry_slot_class, registry_slot_state, registry_payload_entry_count, registry_payload_digest, registry_payload_preview, backend_payload_entry_count, backend_payload_digest, backend_payload_preview) in runtime_snapshot_state_registry_backends:
                    prefix = backend_state_label.get(backend_state, backend_state.upper() or "INFO")
                    line = f"- [{prefix}] {name} -> {backend_class or 'backend'}"
                    id_parts = []
                    if backend_key:
                        id_parts.append(f"backend={backend_key}")
                    if registry_key:
                        id_parts.append(f"registry={registry_key}")
                    if handle_register_key:
                        id_parts.append(f"handle-register={handle_register_key}")
                    if registry_slot_key:
                        id_parts.append(f"registry-slot={registry_slot_key}")
                    if id_parts:
                        line += " · " + " | ".join(id_parts[:5])
                    stub_parts = []
                    if supports_capture_backend:
                        stub_parts.append("capture-backend")
                    if supports_restore_backend:
                        stub_parts.append("restore-backend")
                    if supports_runtime_state_backend:
                        stub_parts.append("runtime-backend")
                    for stub_text in (capture_backend_stub, restore_backend_stub, rollback_backend_stub, runtime_state_backend_stub):
                        if stub_text:
                            stub_parts.append(stub_text)
                    if stub_parts:
                        line += f" · {' | '.join(stub_parts[:5])}"
                    if backend_payload_entry_count > 0:
                        line += f" · payload={backend_payload_entry_count}"
                    if backend_payload_digest:
                        line += f" · digest={backend_payload_digest}"
                    preview_parts = []
                    for p_key, p_val in list((backend_payload_preview or {}).items())[:4]:
                        if isinstance(p_val, list):
                            preview_parts.append(f"{p_key}={len(p_val)}")
                        elif isinstance(p_val, dict):
                            preview_parts.append(f"{p_key}={len(p_val)}")
                        else:
                            preview_parts.append(f"{p_key}={p_val}")
                    if preview_parts:
                        line += f" — {'; '.join(preview_parts)}"
                    backend_lines.append(line)
                detail_sections.append(
                    "Runtime-State-Registry-Backends / Handle-Register / Registry-Slots\n" + "\n".join(backend_lines)
                )

            if runtime_snapshot_state_registry_backend_adapters:
                adapter_state_label = {"ready": "READY", "pending": "PENDING", "blocked": "BLOCKED"}
                adapter_lines = []
                for (name, snapshot_object_key, snapshot_object_class, stub_key, stub_class, carrier_key, carrier_class, container_key, container_class, holder_key, holder_class, slot_key, slot_class, store_key, store_class, registry_key, registry_class, backend_key, backend_class, adapter_key, adapter_class, adapter_state, capture_method, restore_method, rollback_slot, supports_capture_backend_adapter, supports_restore_backend_adapter, supports_runtime_state_backend_adapter, instantiate_method, capture_adapter_stub, restore_adapter_stub, rollback_adapter_stub, runtime_state_backend_adapter_stub, backend_store_adapter_key, backend_store_adapter_class, backend_store_adapter_state, registry_slot_backend_key, registry_slot_backend_class, registry_slot_backend_state, backend_payload_entry_count, backend_payload_digest, backend_payload_preview, adapter_payload_entry_count, adapter_payload_digest, adapter_payload_preview) in runtime_snapshot_state_registry_backend_adapters:
                    prefix = adapter_state_label.get(adapter_state, adapter_state.upper() or "INFO")
                    line = f"- [{prefix}] {name} -> {adapter_class or 'backend-adapter'}"
                    id_parts = []
                    if adapter_key:
                        id_parts.append(f"adapter={adapter_key}")
                    if backend_key:
                        id_parts.append(f"backend={backend_key}")
                    if backend_store_adapter_key:
                        id_parts.append(f"backend-store-adapter={backend_store_adapter_key}")
                    if registry_slot_backend_key:
                        id_parts.append(f"registry-slot-backend={registry_slot_backend_key}")
                    if id_parts:
                        line += " · " + " | ".join(id_parts[:5])
                    stub_parts = []
                    if supports_capture_backend_adapter:
                        stub_parts.append("capture-backend-adapter")
                    if supports_restore_backend_adapter:
                        stub_parts.append("restore-backend-adapter")
                    if supports_runtime_state_backend_adapter:
                        stub_parts.append("runtime-backend-adapter")
                    for stub_text in (capture_adapter_stub, restore_adapter_stub, rollback_adapter_stub, runtime_state_backend_adapter_stub):
                        if stub_text:
                            stub_parts.append(stub_text)
                    if stub_parts:
                        line += f" · {' | '.join(stub_parts[:5])}"
                    if adapter_payload_entry_count > 0:
                        line += f" · payload={adapter_payload_entry_count}"
                    if adapter_payload_digest:
                        line += f" · digest={adapter_payload_digest}"
                    preview_parts = []
                    for p_key, p_val in list((adapter_payload_preview or {}).items())[:4]:
                        if isinstance(p_val, list):
                            preview_parts.append(f"{p_key}={len(p_val)}")
                        elif isinstance(p_val, dict):
                            preview_parts.append(f"{p_key}={len(p_val)}")
                        else:
                            preview_parts.append(f"{p_key}={p_val}")
                    if preview_parts:
                        line += f" — {'; '.join(preview_parts)}"
                    adapter_lines.append(line)
                detail_sections.append(
                    "Runtime-State-Registry-Backend-Adapter / Backend-Store-Adapter / Registry-pyqtSlot-Backends\n" + "\n".join(adapter_lines)
                )

            if runtime_snapshot_bundle.get("bundle_key"):
                bundle_prefix = bundle_state_label.get(str(runtime_snapshot_bundle.get("bundle_state") or "").strip().lower(), str(runtime_snapshot_bundle.get("bundle_state") or "").upper() or "INFO")
                bundle_lines = [
                    f"- [{bundle_prefix}] key={runtime_snapshot_bundle.get('bundle_key')}",
                    f"- type={runtime_snapshot_bundle.get('transaction_container_kind') or 'transaction-bundle'}",
                    f"- objektbindungen={runtime_snapshot_bundle.get('ready_object_count', 0)}/{runtime_snapshot_bundle.get('object_count', 0)}",
                    f"- benoetigte snapshots={runtime_snapshot_bundle.get('required_snapshot_count', 0)}",
                ]
                if runtime_snapshot_bundle.get("bundle_stub"):
                    bundle_lines.append(f"- bundle-stub={runtime_snapshot_bundle.get('bundle_stub')}")
                if runtime_snapshot_bundle.get("commit_stub"):
                    bundle_lines.append(f"- commit-stub={runtime_snapshot_bundle.get('commit_stub')}")
                if runtime_snapshot_bundle.get("rollback_stub"):
                    bundle_lines.append(f"- rollback-stub={runtime_snapshot_bundle.get('rollback_stub')}")
                if runtime_snapshot_bundle.get("capture_methods"):
                    bundle_lines.append(f"- capture-methoden={', '.join(runtime_snapshot_bundle.get('capture_methods')[:4])}")
                if runtime_snapshot_bundle.get("restore_methods"):
                    bundle_lines.append(f"- restore-methoden={', '.join(runtime_snapshot_bundle.get('restore_methods')[:4])}")
                if runtime_snapshot_bundle.get("rollback_slots"):
                    bundle_lines.append(f"- rollback-slots={', '.join(runtime_snapshot_bundle.get('rollback_slots')[:4])}")
                if runtime_snapshot_bundle.get("snapshot_object_keys"):
                    bundle_lines.append(f"- snapshot-objekte={len(runtime_snapshot_bundle.get('snapshot_object_keys'))}")
                if runtime_snapshot_bundle.get("payload_digests"):
                    bundle_lines.append(f"- payload-digests={', '.join(runtime_snapshot_bundle.get('payload_digests')[:3])}")
                detail_sections.append(
                    "Snapshot-Bundle / Transaktions-Container:\n" + "\n".join(bundle_lines)
                )
            if runtime_snapshot_apply_runner.get("runner_key"):
                apply_runner_state_label = {"ready": "READY", "pending": "PENDING", "blocked": "BLOCKED"}
                apply_runner_prefix = apply_runner_state_label.get(str(runtime_snapshot_apply_runner.get("runner_state") or "").strip().lower(), str(runtime_snapshot_apply_runner.get("runner_state") or "").upper() or "INFO")
                apply_runner_lines = [
                    f"- [{apply_runner_prefix}] key={runtime_snapshot_apply_runner.get('runner_key')}",
                    f"- mode={runtime_snapshot_apply_runner.get('apply_mode') or 'read-only-snapshot-transaction-dispatch'}",
                    f"- bundle={runtime_snapshot_apply_runner.get('bundle_key') or runtime_snapshot_bundle.get('bundle_key') or 'n/a'}",
                    f"- phasen={runtime_snapshot_apply_runner.get('ready_phase_count', 0)}/{runtime_snapshot_apply_runner.get('phase_count', 0)}",
                ]
                if runtime_snapshot_apply_runner.get("apply_runner_stub"):
                    apply_runner_lines.append(f"- runner-stub={runtime_snapshot_apply_runner.get('apply_runner_stub')}")
                if runtime_snapshot_apply_runner.get("apply_sequence"):
                    apply_runner_lines.append(f"- apply-sequenz={', '.join(runtime_snapshot_apply_runner.get('apply_sequence')[:4])}")
                if runtime_snapshot_apply_runner.get("restore_sequence"):
                    apply_runner_lines.append(f"- restore-sequenz={', '.join(runtime_snapshot_apply_runner.get('restore_sequence')[:4])}")
                if runtime_snapshot_apply_runner.get("rollback_sequence"):
                    apply_runner_lines.append(f"- rollback-sequenz={', '.join(runtime_snapshot_apply_runner.get('rollback_sequence')[:4])}")
                if runtime_snapshot_apply_runner.get("rehearsed_steps"):
                    apply_runner_lines.append(f"- rehearsed-steps={len(runtime_snapshot_apply_runner.get('rehearsed_steps'))}")
                if runtime_snapshot_apply_runner.get("state_registry_backend_adapter_calls"):
                    apply_runner_lines.append(f"- state-registry-backend-adapter-calls={', '.join(runtime_snapshot_apply_runner.get('state_registry_backend_adapter_calls')[:4])}")
                if runtime_snapshot_apply_runner.get("state_registry_backend_adapter_summary"):
                    apply_runner_lines.append(f"- state-registry-backend-adapter={runtime_snapshot_apply_runner.get('state_registry_backend_adapter_summary')}")
                if runtime_snapshot_apply_runner.get("backend_store_adapter_calls"):
                    apply_runner_lines.append(f"- backend-store-adapter-calls={', '.join(runtime_snapshot_apply_runner.get('backend_store_adapter_calls')[:4])}")
                if runtime_snapshot_apply_runner.get("backend_store_adapter_summary"):
                    apply_runner_lines.append(f"- backend-store-adapter={runtime_snapshot_apply_runner.get('backend_store_adapter_summary')}")
                if runtime_snapshot_apply_runner.get("registry_slot_backend_calls"):
                    apply_runner_lines.append(f"- registry-slot-backend-calls={', '.join(runtime_snapshot_apply_runner.get('registry_slot_backend_calls')[:4])}")
                if runtime_snapshot_apply_runner.get("registry_slot_backend_summary"):
                    apply_runner_lines.append(f"- registry-slot-backend={runtime_snapshot_apply_runner.get('registry_slot_backend_summary')}")
                if runtime_snapshot_apply_runner.get("runner_dispatch_summary"):
                    apply_runner_lines.append(f"- dispatch={runtime_snapshot_apply_runner.get('runner_dispatch_summary')}")
                phase_results = runtime_snapshot_apply_runner.get("phase_results") or []
                for item in phase_results[:6]:
                    try:
                        item = dict(item or {})
                    except Exception:
                        item = {}
                    phase = str(item.get("phase") or "").strip() or "phase"
                    target = str(item.get("target") or "").strip() or "target"
                    method = str(item.get("method") or "").strip() or "method"
                    state = str(item.get("state") or "").strip().upper() or "INFO"
                    detail = str(item.get("detail") or "").strip()
                    line = f"- [{state}] {phase} -> {target} via {method}"
                    if detail:
                        line += f" — {detail}"
                    apply_runner_lines.append(line)
                detail_sections.append(
                    "Read-only Snapshot-Transaktions-Dispatch / Apply-Runner:\n" + "\n".join(apply_runner_lines)
                )
            if runtime_snapshot_dry_run.get("runner_key"):
                dry_run_state_label = {"ready": "READY", "pending": "PENDING", "blocked": "BLOCKED"}
                dry_run_prefix = dry_run_state_label.get(str(runtime_snapshot_dry_run.get("runner_state") or "").strip().lower(), str(runtime_snapshot_dry_run.get("runner_state") or "").upper() or "INFO")
                dry_run_lines = [
                    f"- [{dry_run_prefix}] key={runtime_snapshot_dry_run.get('runner_key')}",
                    f"- mode={runtime_snapshot_dry_run.get('dry_run_mode') or 'read-only-transaction-rehearsal'}",
                    f"- bundle={runtime_snapshot_dry_run.get('bundle_key') or runtime_snapshot_bundle.get('bundle_key') or 'n/a'}",
                    f"- phasen={runtime_snapshot_dry_run.get('ready_phase_count', 0)}/{runtime_snapshot_dry_run.get('phase_count', 0)}",
                ]
                if runtime_snapshot_dry_run.get("dry_run_stub"):
                    dry_run_lines.append(f"- runner-stub={runtime_snapshot_dry_run.get('dry_run_stub')}")
                if runtime_snapshot_dry_run.get("capture_sequence"):
                    dry_run_lines.append(f"- capture-sequenz={', '.join(runtime_snapshot_dry_run.get('capture_sequence')[:4])}")
                if runtime_snapshot_dry_run.get("restore_sequence"):
                    dry_run_lines.append(f"- restore-sequenz={', '.join(runtime_snapshot_dry_run.get('restore_sequence')[:4])}")
                if runtime_snapshot_dry_run.get("rollback_sequence"):
                    dry_run_lines.append(f"- rollback-sequenz={', '.join(runtime_snapshot_dry_run.get('rollback_sequence')[:4])}")
                if runtime_snapshot_dry_run.get("rehearsed_steps"):
                    dry_run_lines.append(f"- rehearsed-steps={len(runtime_snapshot_dry_run.get('rehearsed_steps'))}")
                if runtime_snapshot_dry_run.get("capture_method_calls"):
                    dry_run_lines.append(f"- capture-calls={', '.join(runtime_snapshot_dry_run.get('capture_method_calls')[:4])}")
                if runtime_snapshot_dry_run.get("restore_method_calls"):
                    dry_run_lines.append(f"- restore-calls={', '.join(runtime_snapshot_dry_run.get('restore_method_calls')[:4])}")
                if runtime_snapshot_dry_run.get("state_carrier_calls"):
                    dry_run_lines.append(f"- state-carrier-calls={', '.join(runtime_snapshot_dry_run.get('state_carrier_calls')[:4])}")
                if runtime_snapshot_dry_run.get("state_carrier_summary"):
                    dry_run_lines.append(f"- state-carrier={runtime_snapshot_dry_run.get('state_carrier_summary')}")
                if runtime_snapshot_dry_run.get("state_container_calls"):
                    dry_run_lines.append(f"- state-container-calls={', '.join(runtime_snapshot_dry_run.get('state_container_calls')[:4])}")
                if runtime_snapshot_dry_run.get("state_container_summary"):
                    dry_run_lines.append(f"- state-container={runtime_snapshot_dry_run.get('state_container_summary')}")
                if runtime_snapshot_dry_run.get("state_holder_calls"):
                    dry_run_lines.append(f"- state-holder-calls={', '.join(runtime_snapshot_dry_run.get('state_holder_calls')[:4])}")
                if runtime_snapshot_dry_run.get("state_holder_summary"):
                    dry_run_lines.append(f"- state-holder={runtime_snapshot_dry_run.get('state_holder_summary')}")
                if runtime_snapshot_dry_run.get("state_slot_calls"):
                    dry_run_lines.append(f"- state-slot-calls={', '.join(runtime_snapshot_dry_run.get('state_slot_calls')[:4])}")
                if runtime_snapshot_dry_run.get("state_slot_summary"):
                    dry_run_lines.append(f"- state-slot={runtime_snapshot_dry_run.get('state_slot_summary')}")
                if runtime_snapshot_dry_run.get("state_store_calls"):
                    dry_run_lines.append(f"- state-store-calls={', '.join(runtime_snapshot_dry_run.get('state_store_calls')[:4])}")
                if runtime_snapshot_dry_run.get("state_store_summary"):
                    dry_run_lines.append(f"- state-store={runtime_snapshot_dry_run.get('state_store_summary')}")
                if runtime_snapshot_dry_run.get("state_registry_calls"):
                    dry_run_lines.append(f"- state-registry-calls={', '.join(runtime_snapshot_dry_run.get('state_registry_calls')[:4])}")
                if runtime_snapshot_dry_run.get("state_registry_summary"):
                    dry_run_lines.append(f"- state-registry={runtime_snapshot_dry_run.get('state_registry_summary')}")
                if runtime_snapshot_dry_run.get("state_registry_backend_calls"):
                    dry_run_lines.append(f"- state-registry-backend-calls={', '.join(runtime_snapshot_dry_run.get('state_registry_backend_calls')[:4])}")
                if runtime_snapshot_dry_run.get("state_registry_backend_summary"):
                    dry_run_lines.append(f"- state-registry-backend={runtime_snapshot_dry_run.get('state_registry_backend_summary')}")
                if runtime_snapshot_dry_run.get("state_registry_backend_adapter_calls"):
                    dry_run_lines.append(f"- state-registry-backend-adapter-calls={', '.join(runtime_snapshot_dry_run.get('state_registry_backend_adapter_calls')[:4])}")
                if runtime_snapshot_dry_run.get("state_registry_backend_adapter_summary"):
                    dry_run_lines.append(f"- state-registry-backend-adapter={runtime_snapshot_dry_run.get('state_registry_backend_adapter_summary')}")
                if runtime_snapshot_dry_run.get("runner_dispatch_summary"):
                    dry_run_lines.append(f"- dispatch={runtime_snapshot_dry_run.get('runner_dispatch_summary')}")
                phase_results = runtime_snapshot_dry_run.get("phase_results") or []
                for item in phase_results[:6]:
                    try:
                        item = dict(item or {})
                    except Exception:
                        item = {}
                    phase = str(item.get("phase") or "").strip() or "phase"
                    target = str(item.get("target") or "").strip() or "target"
                    method = str(item.get("method") or "").strip() or "method"
                    state = str(item.get("state") or "").strip().upper() or "INFO"
                    detail = str(item.get("detail") or "").strip()
                    line = f"- [{state}] {phase} -> {target} via {method}"
                    if detail:
                        line += f" — {detail}"
                    dry_run_lines.append(line)
                detail_sections.append(
                    "Read-only Dry-Run / Transaktions-Runner:\n" + "\n".join(dry_run_lines)
                )
            if runtime_snapshot_precommit_contract.get("contract_key"):
                precommit_state_label = {"ready": "READY", "pending": "PENDING", "blocked": "BLOCKED"}
                precommit_prefix = precommit_state_label.get(str(runtime_snapshot_precommit_contract.get("contract_state") or "").strip().lower(), str(runtime_snapshot_precommit_contract.get("contract_state") or "").upper() or "INFO")
                precommit_lines = [
                    f"- [{precommit_prefix}] key={runtime_snapshot_precommit_contract.get('contract_key')}",
                    f"- scope={runtime_snapshot_precommit_contract.get('target_scope') or 'empty-audio-track-minimal-case'}",
                    f"- mutation-gate={runtime_snapshot_precommit_contract.get('mutation_gate_state') or 'blocked'}",
                    f"- vorschauphasen={runtime_snapshot_precommit_contract.get('ready_preview_phase_count', 0)}/{runtime_snapshot_precommit_contract.get('preview_phase_count', 0)}",
                    f"- bundle={runtime_snapshot_precommit_contract.get('bundle_key') or runtime_snapshot_bundle.get('bundle_key') or 'n/a'}",
                    f"- apply-runner={runtime_snapshot_precommit_contract.get('apply_runner_key') or runtime_snapshot_apply_runner.get('runner_key') or 'n/a'}",
                    f"- dry-run={runtime_snapshot_precommit_contract.get('dry_run_key') or runtime_snapshot_dry_run.get('runner_key') or 'n/a'}",
                ]
                if runtime_snapshot_precommit_contract.get("future_commit_stub"):
                    precommit_lines.append(f"- future-commit-stub={runtime_snapshot_precommit_contract.get('future_commit_stub')}")
                if runtime_snapshot_precommit_contract.get("future_rollback_stub"):
                    precommit_lines.append(f"- future-rollback-stub={runtime_snapshot_precommit_contract.get('future_rollback_stub')}")
                if runtime_snapshot_precommit_contract.get("preview_commit_sequence"):
                    precommit_lines.append(f"- commit-sequenz={', '.join(runtime_snapshot_precommit_contract.get('preview_commit_sequence')[:4])}")
                if runtime_snapshot_precommit_contract.get("preview_rollback_sequence"):
                    precommit_lines.append(f"- rollback-sequenz={', '.join(runtime_snapshot_precommit_contract.get('preview_rollback_sequence')[:4])}")
                if runtime_snapshot_precommit_contract.get("blocked_by"):
                    precommit_lines.append(f"- blocked-by={', '.join(runtime_snapshot_precommit_contract.get('blocked_by')[:6])}")
                if runtime_snapshot_precommit_contract.get("pending_by"):
                    precommit_lines.append(f"- pending-by={', '.join(runtime_snapshot_precommit_contract.get('pending_by')[:6])}")
                phase_results = runtime_snapshot_precommit_contract.get("preview_phase_results") or []
                for item in phase_results[:6]:
                    try:
                        item = dict(item or {})
                    except Exception:
                        item = {}
                    phase = str(item.get("phase") or "").strip() or "phase"
                    target = str(item.get("target") or "").strip() or "target"
                    method = str(item.get("method") or "").strip() or "method"
                    state = str(item.get("state") or "").strip().upper() or "INFO"
                    detail = str(item.get("detail") or "").strip()
                    line = f"- [{state}] {phase} -> {target} via {method}"
                    if detail:
                        line += f" — {detail}"
                    precommit_lines.append(line)
                detail_sections.append(
                    "Leere Audio-Spur: read-only Pre-Commit-Vertrag:\n" + "\n".join(precommit_lines)
                )
            if runtime_snapshot_atomic_entrypoints.get("entrypoint_key"):
                atomic_state_label = {"ready": "READY", "pending": "PENDING", "blocked": "BLOCKED"}
                atomic_prefix = atomic_state_label.get(str(runtime_snapshot_atomic_entrypoints.get("entrypoint_state") or "").strip().lower(), str(runtime_snapshot_atomic_entrypoints.get("entrypoint_state") or "").upper() or "INFO")
                atomic_lines = [
                    f"- [{atomic_prefix}] key={runtime_snapshot_atomic_entrypoints.get('entrypoint_key')}",
                    f"- scope={runtime_snapshot_atomic_entrypoints.get('target_scope') or 'empty-audio-track-minimal-case'}",
                    f"- owner={runtime_snapshot_atomic_entrypoints.get('owner_class') or 'n/a'}",
                    f"- mutation-gate={runtime_snapshot_atomic_entrypoints.get('mutation_gate_state') or 'blocked'}",
                    f"- entry-points={runtime_snapshot_atomic_entrypoints.get('ready_entrypoint_count', 0)}/{runtime_snapshot_atomic_entrypoints.get('total_entrypoint_count', 0)}",
                ]
                if runtime_snapshot_atomic_entrypoints.get("future_apply_stub"):
                    atomic_lines.append(f"- future-apply-stub={runtime_snapshot_atomic_entrypoints.get('future_apply_stub')}")
                if runtime_snapshot_atomic_entrypoints.get("future_commit_stub"):
                    atomic_lines.append(f"- future-commit-stub={runtime_snapshot_atomic_entrypoints.get('future_commit_stub')}")
                if runtime_snapshot_atomic_entrypoints.get("future_rollback_stub"):
                    atomic_lines.append(f"- future-rollback-stub={runtime_snapshot_atomic_entrypoints.get('future_rollback_stub')}")
                if runtime_snapshot_atomic_entrypoints.get("preview_dispatch_sequence"):
                    atomic_lines.append(f"- dispatch-sequenz={', '.join(runtime_snapshot_atomic_entrypoints.get('preview_dispatch_sequence')[:6])}")
                if runtime_snapshot_atomic_entrypoints.get("blocked_by"):
                    atomic_lines.append(f"- blocked-by={', '.join(runtime_snapshot_atomic_entrypoints.get('blocked_by')[:6])}")
                if runtime_snapshot_atomic_entrypoints.get("pending_by"):
                    atomic_lines.append(f"- pending-by={', '.join(runtime_snapshot_atomic_entrypoints.get('pending_by')[:6])}")
                for item in (runtime_snapshot_atomic_entrypoints.get("entrypoints") or [])[:10]:
                    try:
                        item = dict(item or {})
                    except Exception:
                        item = {}
                    label = str(item.get("label") or "").strip() or "entry-point"
                    target = str(item.get("target") or "").strip() or "target"
                    method = str(item.get("method") or "").strip() or "method"
                    state = str(item.get("state") or "").strip().upper() or "INFO"
                    detail = str(item.get("detail") or "").strip()
                    line = f"- [{state}] {label} -> {target} via {method}"
                    if detail:
                        line += f" — {detail}"
                    atomic_lines.append(line)
                detail_sections.append(
                    "Read-only atomare Commit-/Undo-/Routing-Entry-Points:\n" + "\n".join(atomic_lines)
                )
            if runtime_snapshot_mutation_gate_capsule.get("capsule_key"):
                capsule_state_label = {"ready": "READY", "pending": "PENDING", "blocked": "BLOCKED"}
                capsule_prefix = capsule_state_label.get(str(runtime_snapshot_mutation_gate_capsule.get("capsule_state") or "").strip().lower(), str(runtime_snapshot_mutation_gate_capsule.get("capsule_state") or "").upper() or "INFO")
                capsule_lines = [
                    f"- [{capsule_prefix}] key={runtime_snapshot_mutation_gate_capsule.get('capsule_key')}",
                    f"- scope={runtime_snapshot_mutation_gate_capsule.get('target_scope') or 'empty-audio-track-minimal-case'}",
                    f"- owner={runtime_snapshot_mutation_gate_capsule.get('owner_class') or 'n/a'}",
                    f"- mutation-gate={runtime_snapshot_mutation_gate_capsule.get('mutation_gate_state') or 'blocked'}",
                    f"- kapselschritte={runtime_snapshot_mutation_gate_capsule.get('ready_capsule_step_count', 0)}/{runtime_snapshot_mutation_gate_capsule.get('total_capsule_step_count', 0)}",
                ]
                if runtime_snapshot_mutation_gate_capsule.get("future_gate_stub"):
                    capsule_lines.append(f"- future-gate-stub={runtime_snapshot_mutation_gate_capsule.get('future_gate_stub')}")
                if runtime_snapshot_mutation_gate_capsule.get("future_capsule_stub"):
                    capsule_lines.append(f"- future-capsule-stub={runtime_snapshot_mutation_gate_capsule.get('future_capsule_stub')}")
                if runtime_snapshot_mutation_gate_capsule.get("future_commit_stub"):
                    capsule_lines.append(f"- future-commit-stub={runtime_snapshot_mutation_gate_capsule.get('future_commit_stub')}")
                if runtime_snapshot_mutation_gate_capsule.get("future_rollback_stub"):
                    capsule_lines.append(f"- future-rollback-stub={runtime_snapshot_mutation_gate_capsule.get('future_rollback_stub')}")
                if runtime_snapshot_mutation_gate_capsule.get("preview_capsule_sequence"):
                    capsule_lines.append(f"- kapsel-sequenz={', '.join(runtime_snapshot_mutation_gate_capsule.get('preview_capsule_sequence')[:8])}")
                if runtime_snapshot_mutation_gate_capsule.get("blocked_by"):
                    capsule_lines.append(f"- blocked-by={', '.join(runtime_snapshot_mutation_gate_capsule.get('blocked_by')[:6])}")
                if runtime_snapshot_mutation_gate_capsule.get("pending_by"):
                    capsule_lines.append(f"- pending-by={', '.join(runtime_snapshot_mutation_gate_capsule.get('pending_by')[:6])}")
                for item in (runtime_snapshot_mutation_gate_capsule.get("capsule_steps") or [])[:12]:
                    try:
                        item = dict(item or {})
                    except Exception:
                        item = {}
                    label = str(item.get("label") or "").strip() or "capsule-step"
                    target = str(item.get("target") or "").strip() or "target"
                    method = str(item.get("method") or "").strip() or "method"
                    state = str(item.get("state") or "").strip().upper() or "INFO"
                    detail = str(item.get("detail") or "").strip()
                    line = f"- [{state}] {label} -> {target} via {method}"
                    if detail:
                        line += f" — {detail}"
                    capsule_lines.append(line)
                detail_sections.append(
                    "Read-only Mutation-Gate / Transaction-Capsule:\n" + "\n".join(capsule_lines)
                )
            if runtime_snapshot_command_undo_shell.get("shell_key"):
                shell_state_label = {"ready": "READY", "pending": "PENDING", "blocked": "BLOCKED"}
                shell_prefix = shell_state_label.get(str(runtime_snapshot_command_undo_shell.get("shell_state") or "").strip().lower(), str(runtime_snapshot_command_undo_shell.get("shell_state") or "").upper() or "INFO")
                shell_lines = [
                    f"- [{shell_prefix}] key={runtime_snapshot_command_undo_shell.get('shell_key')}",
                    f"- scope={runtime_snapshot_command_undo_shell.get('target_scope') or 'empty-audio-track-minimal-case'}",
                    f"- owner={runtime_snapshot_command_undo_shell.get('owner_class') or 'n/a'}",
                    f"- command={runtime_snapshot_command_undo_shell.get('command_class') or 'ProjectSnapshotEditCommand'}",
                    f"- command-module={runtime_snapshot_command_undo_shell.get('command_module') or 'n/a'}",
                    f"- mutation-gate={runtime_snapshot_command_undo_shell.get('mutation_gate_state') or 'blocked'}",
                    f"- huellenschritte={runtime_snapshot_command_undo_shell.get('ready_shell_step_count', 0)}/{runtime_snapshot_command_undo_shell.get('total_shell_step_count', 0)}",
                ]
                if runtime_snapshot_command_undo_shell.get("future_command_stub"):
                    shell_lines.append(f"- future-command-stub={runtime_snapshot_command_undo_shell.get('future_command_stub')}")
                if runtime_snapshot_command_undo_shell.get("future_undo_stub"):
                    shell_lines.append(f"- future-undo-stub={runtime_snapshot_command_undo_shell.get('future_undo_stub')}")
                if runtime_snapshot_command_undo_shell.get("future_commit_stub"):
                    shell_lines.append(f"- future-commit-stub={runtime_snapshot_command_undo_shell.get('future_commit_stub')}")
                if runtime_snapshot_command_undo_shell.get("future_rollback_stub"):
                    shell_lines.append(f"- future-rollback-stub={runtime_snapshot_command_undo_shell.get('future_rollback_stub')}")
                if runtime_snapshot_command_undo_shell.get("preview_shell_sequence"):
                    shell_lines.append(f"- huellen-sequenz={', '.join(runtime_snapshot_command_undo_shell.get('preview_shell_sequence')[:8])}")
                if runtime_snapshot_command_undo_shell.get("blocked_by"):
                    shell_lines.append(f"- blocked-by={', '.join(runtime_snapshot_command_undo_shell.get('blocked_by')[:6])}")
                if runtime_snapshot_command_undo_shell.get("pending_by"):
                    shell_lines.append(f"- pending-by={', '.join(runtime_snapshot_command_undo_shell.get('pending_by')[:6])}")
                for item in (runtime_snapshot_command_undo_shell.get("shell_steps") or [])[:12]:
                    try:
                        item = dict(item or {})
                    except Exception:
                        item = {}
                    label = str(item.get("label") or "").strip() or "shell-step"
                    target = str(item.get("target") or "").strip() or "target"
                    method = str(item.get("method") or "").strip() or "method"
                    state = str(item.get("state") or "").strip().upper() or "INFO"
                    detail = str(item.get("detail") or "").strip()
                    line = f"- [{state}] {label} -> {target} via {method}"
                    if detail:
                        line += f" — {detail}"
                    shell_lines.append(line)
                detail_sections.append(
                    "Read-only ProjectSnapshotEditCommand / Undo-Huelle:\n" + "\n".join(shell_lines)
                )
            if runtime_snapshot_command_factory_payloads.get("factory_key"):
                payload_state_label = {"ready": "READY", "pending": "PENDING", "blocked": "BLOCKED"}
                payload_prefix = payload_state_label.get(str(runtime_snapshot_command_factory_payloads.get("payload_state") or "").strip().lower(), str(runtime_snapshot_command_factory_payloads.get("payload_state") or "").upper() or "INFO")
                before_payload_summary = dict(runtime_snapshot_command_factory_payloads.get("before_payload_summary") or {})
                after_payload_summary = dict(runtime_snapshot_command_factory_payloads.get("after_payload_summary") or {})
                payload_lines = [
                    f"- [{payload_prefix}] key={runtime_snapshot_command_factory_payloads.get('factory_key')}",
                    f"- scope={runtime_snapshot_command_factory_payloads.get('target_scope') or 'empty-audio-track-minimal-case'}",
                    f"- owner={runtime_snapshot_command_factory_payloads.get('owner_class') or 'n/a'}",
                    f"- command={runtime_snapshot_command_factory_payloads.get('command_class') or 'ProjectSnapshotEditCommand'}",
                    f"- command-module={runtime_snapshot_command_factory_payloads.get('command_module') or 'n/a'}",
                    f"- mutation-gate={runtime_snapshot_command_factory_payloads.get('mutation_gate_state') or 'blocked'}",
                    f"- factory-schritte={runtime_snapshot_command_factory_payloads.get('ready_factory_step_count', 0)}/{runtime_snapshot_command_factory_payloads.get('total_factory_step_count', 0)}",
                    f"- payloads={runtime_snapshot_command_factory_payloads.get('materialized_payload_count', 0)}/2",
                    f"- delta-kind={runtime_snapshot_command_factory_payloads.get('payload_delta_kind') or 'n/a'}",
                ]
                if runtime_snapshot_command_factory_payloads.get("label_preview"):
                    payload_lines.append(f"- label-preview={runtime_snapshot_command_factory_payloads.get('label_preview')}")
                if runtime_snapshot_command_factory_payloads.get("future_factory_stub"):
                    payload_lines.append(f"- future-factory-stub={runtime_snapshot_command_factory_payloads.get('future_factory_stub')}")
                if runtime_snapshot_command_factory_payloads.get("future_before_snapshot_stub"):
                    payload_lines.append(f"- future-before-stub={runtime_snapshot_command_factory_payloads.get('future_before_snapshot_stub')}")
                if runtime_snapshot_command_factory_payloads.get("future_after_snapshot_stub"):
                    payload_lines.append(f"- future-after-stub={runtime_snapshot_command_factory_payloads.get('future_after_snapshot_stub')}")
                if runtime_snapshot_command_factory_payloads.get("preview_factory_sequence"):
                    payload_lines.append(f"- factory-sequenz={', '.join(runtime_snapshot_command_factory_payloads.get('preview_factory_sequence')[:8])}")
                if before_payload_summary:
                    payload_lines.append(
                        f"- before-payload=digest {before_payload_summary.get('payload_digest') or 'n/a'}, bytes {before_payload_summary.get('payload_size_bytes', 0)}, entries {before_payload_summary.get('payload_entry_count', 0)}, keys {', '.join(before_payload_summary.get('top_level_keys', [])[:8]) or 'n/a'}"
                    )
                if after_payload_summary:
                    payload_lines.append(
                        f"- after-payload=digest {after_payload_summary.get('payload_digest') or 'n/a'}, bytes {after_payload_summary.get('payload_size_bytes', 0)}, entries {after_payload_summary.get('payload_entry_count', 0)}, keys {', '.join(after_payload_summary.get('top_level_keys', [])[:8]) or 'n/a'}"
                    )
                if runtime_snapshot_command_factory_payloads.get("blocked_by"):
                    payload_lines.append(f"- blocked-by={', '.join(runtime_snapshot_command_factory_payloads.get('blocked_by')[:6])}")
                if runtime_snapshot_command_factory_payloads.get("pending_by"):
                    payload_lines.append(f"- pending-by={', '.join(runtime_snapshot_command_factory_payloads.get('pending_by')[:6])}")
                for item in (runtime_snapshot_command_factory_payloads.get("factory_steps") or [])[:12]:
                    try:
                        item = dict(item or {})
                    except Exception:
                        item = {}
                    label = str(item.get("label") or "").strip() or "factory-step"
                    target = str(item.get("target") or "").strip() or "target"
                    method = str(item.get("method") or "").strip() or "method"
                    state = str(item.get("state") or "").strip().upper() or "INFO"
                    detail = str(item.get("detail") or "").strip()
                    line = f"- [{state}] {label} -> {target} via {method}"
                    if detail:
                        line += f" — {detail}"
                    payload_lines.append(line)
                detail_sections.append(
                    "Read-only Before-/After-Snapshot-Command-Factory:\n" + "\n".join(payload_lines)
                )
            if runtime_snapshot_preview_command_construction.get("preview_command_key"):
                preview_state_label = {"ready": "READY", "pending": "PENDING", "blocked": "BLOCKED"}
                preview_prefix = preview_state_label.get(str(runtime_snapshot_preview_command_construction.get("preview_state") or "").strip().lower(), str(runtime_snapshot_preview_command_construction.get("preview_state") or "").upper() or "INFO")
                before_preview_summary = dict(runtime_snapshot_preview_command_construction.get("before_payload_summary") or {})
                after_preview_summary = dict(runtime_snapshot_preview_command_construction.get("after_payload_summary") or {})
                preview_lines = [
                    f"- [{preview_prefix}] key={runtime_snapshot_preview_command_construction.get('preview_command_key')}",
                    f"- scope={runtime_snapshot_preview_command_construction.get('target_scope') or 'empty-audio-track-minimal-case'}",
                    f"- owner={runtime_snapshot_preview_command_construction.get('owner_class') or 'n/a'}",
                    f"- command={runtime_snapshot_preview_command_construction.get('command_class') or 'ProjectSnapshotEditCommand'}",
                    f"- command-module={runtime_snapshot_preview_command_construction.get('command_module') or 'n/a'}",
                    f"- mutation-gate={runtime_snapshot_preview_command_construction.get('mutation_gate_state') or 'blocked'}",
                    f"- preview-schritte={runtime_snapshot_preview_command_construction.get('ready_preview_step_count', 0)}/{runtime_snapshot_preview_command_construction.get('total_preview_step_count', 0)}",
                    f"- payloads={runtime_snapshot_preview_command_construction.get('materialized_payload_count', 0)}/2",
                    f"- constructor={runtime_snapshot_preview_command_construction.get('command_constructor') or 'n/a'}",
                ]
                if runtime_snapshot_preview_command_construction.get("label_preview"):
                    preview_lines.append(f"- label-preview={runtime_snapshot_preview_command_construction.get('label_preview')}")
                if runtime_snapshot_preview_command_construction.get("apply_callback_name"):
                    preview_lines.append(
                        f"- apply-callback={runtime_snapshot_preview_command_construction.get('apply_callback_owner_class') or 'n/a'}.{runtime_snapshot_preview_command_construction.get('apply_callback_name')}"
                    )
                if runtime_snapshot_preview_command_construction.get("command_field_names"):
                    preview_lines.append(f"- command-felder={', '.join(runtime_snapshot_preview_command_construction.get('command_field_names')[:8])}")
                if runtime_snapshot_preview_command_construction.get("future_constructor_stub"):
                    preview_lines.append(f"- future-constructor-stub={runtime_snapshot_preview_command_construction.get('future_constructor_stub')}")
                if runtime_snapshot_preview_command_construction.get("future_executor_stub"):
                    preview_lines.append(f"- future-executor-stub={runtime_snapshot_preview_command_construction.get('future_executor_stub')}")
                if runtime_snapshot_preview_command_construction.get("preview_command_sequence"):
                    preview_lines.append(f"- preview-sequenz={', '.join(runtime_snapshot_preview_command_construction.get('preview_command_sequence')[:8])}")
                if before_preview_summary:
                    preview_lines.append(
                        f"- before-payload=digest {before_preview_summary.get('payload_digest') or 'n/a'}, bytes {before_preview_summary.get('payload_size_bytes', 0)}, entries {before_preview_summary.get('payload_entry_count', 0)}, keys {', '.join(before_preview_summary.get('top_level_keys', [])[:8]) or 'n/a'}"
                    )
                if after_preview_summary:
                    preview_lines.append(
                        f"- after-payload=digest {after_preview_summary.get('payload_digest') or 'n/a'}, bytes {after_preview_summary.get('payload_size_bytes', 0)}, entries {after_preview_summary.get('payload_entry_count', 0)}, keys {', '.join(after_preview_summary.get('top_level_keys', [])[:8]) or 'n/a'}"
                    )
                if runtime_snapshot_preview_command_construction.get("blocked_by"):
                    preview_lines.append(f"- blocked-by={', '.join(runtime_snapshot_preview_command_construction.get('blocked_by')[:6])}")
                if runtime_snapshot_preview_command_construction.get("pending_by"):
                    preview_lines.append(f"- pending-by={', '.join(runtime_snapshot_preview_command_construction.get('pending_by')[:6])}")
                for item in (runtime_snapshot_preview_command_construction.get("preview_steps") or [])[:12]:
                    try:
                        item = dict(item or {})
                    except Exception:
                        item = {}
                    label = str(item.get("label") or "").strip() or "preview-step"
                    target = str(item.get("target") or "").strip() or "target"
                    method = str(item.get("method") or "").strip() or "method"
                    state = str(item.get("state") or "").strip().upper() or "INFO"
                    detail = str(item.get("detail") or "").strip()
                    line = f"- [{state}] {label} -> {target} via {method}"
                    if detail:
                        line += f" — {detail}"
                    preview_lines.append(line)
                detail_sections.append(
                    "Read-only Preview-Command-Konstruktion:\n" + "\n".join(preview_lines)
                )
            if runtime_snapshot_dry_command_executor.get("dry_executor_key"):
                dry_state_label = {"ready": "READY", "pending": "PENDING", "blocked": "BLOCKED"}
                dry_prefix = dry_state_label.get(str(runtime_snapshot_dry_command_executor.get("dry_executor_state") or "").strip().lower(), str(runtime_snapshot_dry_command_executor.get("dry_executor_state") or "").upper() or "INFO")
                before_dry_summary = dict(runtime_snapshot_dry_command_executor.get("before_payload_summary") or {})
                after_dry_summary = dict(runtime_snapshot_dry_command_executor.get("after_payload_summary") or {})
                dry_lines = [
                    f"- [{dry_prefix}] key={runtime_snapshot_dry_command_executor.get('dry_executor_key')}",
                    f"- scope={runtime_snapshot_dry_command_executor.get('target_scope') or 'empty-audio-track-minimal-case'}",
                    f"- owner={runtime_snapshot_dry_command_executor.get('owner_class') or 'n/a'}",
                    f"- command={runtime_snapshot_dry_command_executor.get('command_class') or 'ProjectSnapshotEditCommand'}",
                    f"- command-module={runtime_snapshot_dry_command_executor.get('command_module') or 'n/a'}",
                    f"- mutation-gate={runtime_snapshot_dry_command_executor.get('mutation_gate_state') or 'blocked'}",
                    f"- simulationsschritte={runtime_snapshot_dry_command_executor.get('ready_simulation_step_count', 0)}/{runtime_snapshot_dry_command_executor.get('total_simulation_step_count', 0)}",
                    f"- do/undo={runtime_snapshot_dry_command_executor.get('do_call_count', 0)}/{runtime_snapshot_dry_command_executor.get('undo_call_count', 0)}",
                    f"- callbacks={runtime_snapshot_dry_command_executor.get('callback_call_count', 0)}",
                    f"- constructor={runtime_snapshot_dry_command_executor.get('command_constructor') or 'n/a'}",
                ]
                if runtime_snapshot_dry_command_executor.get("label_preview"):
                    dry_lines.append(f"- label-preview={runtime_snapshot_dry_command_executor.get('label_preview')}")
                if runtime_snapshot_dry_command_executor.get("apply_callback_name"):
                    dry_lines.append(
                        f"- apply-callback={runtime_snapshot_dry_command_executor.get('apply_callback_owner_class') or 'n/a'}.{runtime_snapshot_dry_command_executor.get('apply_callback_name')}"
                    )
                if runtime_snapshot_dry_command_executor.get("future_executor_stub"):
                    dry_lines.append(f"- future-executor-stub={runtime_snapshot_dry_command_executor.get('future_executor_stub')}")
                if runtime_snapshot_dry_command_executor.get("future_live_executor_stub"):
                    dry_lines.append(f"- future-live-executor-stub={runtime_snapshot_dry_command_executor.get('future_live_executor_stub')}")
                if runtime_snapshot_dry_command_executor.get("simulation_sequence"):
                    dry_lines.append(f"- simulations-sequenz={', '.join(runtime_snapshot_dry_command_executor.get('simulation_sequence')[:8])}")
                if runtime_snapshot_dry_command_executor.get("callback_trace"):
                    dry_lines.append(f"- callback-trace={', '.join(runtime_snapshot_dry_command_executor.get('callback_trace')[:8])}")
                if runtime_snapshot_dry_command_executor.get("callback_payload_digests"):
                    dry_lines.append(f"- callback-digests={', '.join(runtime_snapshot_dry_command_executor.get('callback_payload_digests')[:8])}")
                if before_dry_summary:
                    dry_lines.append(
                        f"- before-payload=digest {before_dry_summary.get('payload_digest') or 'n/a'}, bytes {before_dry_summary.get('payload_size_bytes', 0)}, entries {before_dry_summary.get('payload_entry_count', 0)}, keys {', '.join(before_dry_summary.get('top_level_keys', [])[:8]) or 'n/a'}"
                    )
                if after_dry_summary:
                    dry_lines.append(
                        f"- after-payload=digest {after_dry_summary.get('payload_digest') or 'n/a'}, bytes {after_dry_summary.get('payload_size_bytes', 0)}, entries {after_dry_summary.get('payload_entry_count', 0)}, keys {', '.join(after_dry_summary.get('top_level_keys', [])[:8]) or 'n/a'}"
                    )
                if runtime_snapshot_dry_command_executor.get("blocked_by"):
                    dry_lines.append(f"- blocked-by={', '.join(runtime_snapshot_dry_command_executor.get('blocked_by')[:6])}")
                if runtime_snapshot_dry_command_executor.get("pending_by"):
                    dry_lines.append(f"- pending-by={', '.join(runtime_snapshot_dry_command_executor.get('pending_by')[:6])}")
                for item in (runtime_snapshot_dry_command_executor.get("simulation_steps") or [])[:12]:
                    try:
                        item = dict(item or {})
                    except Exception:
                        item = {}
                    label = str(item.get("label") or "").strip() or "simulation-step"
                    target = str(item.get("target") or "").strip() or "target"
                    method = str(item.get("method") or "").strip() or "method"
                    state = str(item.get("state") or "").strip().upper() or "INFO"
                    detail = str(item.get("detail") or "").strip()
                    line = f"- [{state}] {label} -> {target} via {method}"
                    if detail:
                        line += f" — {detail}"
                    dry_lines.append(line)
                detail_sections.append(
                    "Read-only Dry-Command-Executor / do()-undo()-Simulations-Harness:\n" + "\n".join(dry_lines)
                )
            if readiness_checks:
                state_label = {"ready": "READY", "pending": "PENDING", "blocked": "BLOCKED"}
                detail_sections.append(
                    "Apply-Readiness-Checkliste:\n" + "\n".join([
                        f"- [{state_label.get(state, state.upper() or 'INFO')}] {title}" + (f" — {detail}" if detail else "")
                        for (title, state, detail) in readiness_checks
                    ])
                )
            if transaction_steps:
                transaction_block = "Geplanter atomarer Ablauf:\n" + "\n".join(transaction_steps)
                if transaction_key:
                    transaction_block += f"\n\nTransaction-Key: {transaction_key}"
                detail_sections.append(transaction_block)
            if detail_sections:
                detail_sections.append(
                    "Erst danach darf Audio->Instrument-Morphing Undo-/Routing-sicher aktiviert werden."
                )
                box.setDetailedText("\n\n".join(detail_sections))
            if can_apply:
                box.setStandardButtons(QMessageBox.StandardButton.Ok | QMessageBox.StandardButton.Cancel)
                box.setDefaultButton(QMessageBox.StandardButton.Cancel)
                try:
                    ok_btn = box.button(QMessageBox.StandardButton.Ok)
                    if ok_btn is not None:
                        ok_btn.setText("Morphing bestaetigen")
                    cancel_btn = box.button(QMessageBox.StandardButton.Cancel)
                    if cancel_btn is not None:
                        cancel_btn.setText("Abbrechen")
                except Exception:
                    pass
            else:
                box.setStandardButtons(QMessageBox.StandardButton.Ok)
                box.setDefaultButton(QMessageBox.StandardButton.Ok)
            clicked = box.exec()
            result["shown"] = True
            result["accepted"] = bool(can_apply and clicked == int(QMessageBox.StandardButton.Ok))
            return result
        except Exception:
            return result

    def _migrate_automation_for_device_move(self, source_track_id: str, target_track_id: str, device_id: str, device_kind: str, copy: bool = False) -> int:
        """Migrate automation lanes when a device is moved between tracks (Bitwig-style).

        v0.0.20.524: FIXED — also replaces afx device_ids in keys.
        VST instruments have keys like "afx:{track_id}:{device_id}:vst3:Cutoff".
        When copied/moved, the target track gets a NEW device_id. This function
        builds a device_id mapping from source→target audio_fx_chains and replaces
        both track_id and device_id in the key string.
        Internal instruments (Bach Orgel) use "trk:{track_id}:bach_orgel:param"
        which has no device_id — those work with just track_id replacement.
        """
        migrated = 0
        try:
            source_track_id = str(source_track_id or "").strip()
            target_track_id = str(target_track_id or "").strip()
            device_id = str(device_id or "").strip()
            device_kind = str(device_kind or "").strip().lower()
            if not source_track_id or not target_track_id or source_track_id == target_track_id:
                return 0

            # Access AutomationManager
            am = None
            try:
                am = getattr(self.services, "automation_manager", None)
                if am is None:
                    am = getattr(getattr(self.services, "audio_engine", None), "_automation_manager", None)
                if am is None:
                    am = getattr(getattr(self.services, "container", None), "automation_manager", None)
            except Exception:
                am = None
            if am is None or not hasattr(am, "_lanes"):
                return 0

            # v524: Build device_id mapping from source→target audio_fx_chains
            # This maps old afx device IDs to new ones by matching plugin_id.
            device_id_map: dict[str, str] = {}  # old_device_id -> new_device_id
            try:
                proj = getattr(self.services, "project", None)
                project_obj = getattr(getattr(proj, "ctx", None), "project", None)
                if project_obj is not None:
                    tracks_list = list(getattr(project_obj, "tracks", []) or [])
                    src_trk = next((t for t in tracks_list if str(getattr(t, "id", "")) == source_track_id), None)
                    tgt_trk = next((t for t in tracks_list if str(getattr(t, "id", "")) == target_track_id), None)
                    if src_trk is not None and tgt_trk is not None:
                        src_chain = getattr(src_trk, "audio_fx_chain", None) or {}
                        tgt_chain = getattr(tgt_trk, "audio_fx_chain", None) or {}
                        src_devs = list(src_chain.get("devices", []) or []) if isinstance(src_chain, dict) else []
                        tgt_devs = list(tgt_chain.get("devices", []) or []) if isinstance(tgt_chain, dict) else []
                        # Match devices by plugin_id (order-preserving)
                        tgt_by_plugin: dict[str, list] = {}
                        for d in tgt_devs:
                            if isinstance(d, dict):
                                pid = str(d.get("plugin_id", "") or "")
                                if pid:
                                    tgt_by_plugin.setdefault(pid, []).append(str(d.get("id", "") or ""))
                        for d in src_devs:
                            if isinstance(d, dict):
                                old_did = str(d.get("id", "") or "")
                                pid = str(d.get("plugin_id", "") or "")
                                if old_did and pid and pid in tgt_by_plugin:
                                    candidates = tgt_by_plugin[pid]
                                    if candidates:
                                        new_did = candidates.pop(0)
                                        if new_did and new_did != old_did:
                                            device_id_map[old_did] = new_did
            except Exception:
                pass

            # Find lanes to migrate
            lanes_to_migrate: list[tuple[str, str]] = []  # (old_pid, new_pid)

            for pid, lane in list(am._lanes.items()):
                lane_tid = str(getattr(lane, "track_id", "") or "").strip()
                if lane_tid != source_track_id and source_track_id not in pid:
                    continue

                pid_lower = pid.lower()
                if pid_lower.endswith(":volume") or pid_lower.endswith(":pan"):
                    continue

                if device_kind in ("audio_fx", "note_fx") and device_id:
                    if device_id not in pid:
                        continue
                elif device_kind == "instrument":
                    pass
                else:
                    continue

                # Build new key: replace track_id AND device_ids
                new_pid = pid.replace(source_track_id, target_track_id)
                for old_did, new_did in device_id_map.items():
                    new_pid = new_pid.replace(old_did, new_did)
                if new_pid == pid:
                    continue
                lanes_to_migrate.append((pid, new_pid))

            # Perform migration (move or copy)
            import copy as _copy_mod
            for old_pid, new_pid in lanes_to_migrate:
                try:
                    if new_pid in am._lanes:
                        continue
                    old_lane = am._lanes.get(old_pid)
                    if old_lane is None:
                        continue
                    if copy:
                        new_lane = _copy_mod.deepcopy(old_lane)
                        new_lane.parameter_id = new_pid
                        new_lane.track_id = target_track_id
                        am._lanes[new_pid] = new_lane
                    else:
                        am._lanes.pop(old_pid, None)
                        old_lane.parameter_id = new_pid
                        old_lane.track_id = target_track_id
                        am._lanes[new_pid] = old_lane
                    migrated += 1
                except Exception:
                    pass

            if migrated > 0:
                try:
                    am.lane_data_changed.emit("")
                except Exception:
                    pass
        except Exception:
            pass
        return migrated

    def _smartdrop_remove_from_source(self, source_track_id: str, source_device_id: str, device_kind: str, plugin_name: str = "") -> None:
        """Remove a device from its source track after a successful cross-track SmartDrop move.

        v0.0.20.516: Bitwig-style cross-track device move
        v0.0.20.517: Auto track-type adjustment after instrument removal
        Safe: if removal fails, the device stays on both tracks (user can manually clean up).
        """
        source_track_id = str(source_track_id or "").strip()
        source_device_id = str(source_device_id or "").strip()
        device_kind = str(device_kind or "").strip().lower()
        if not source_track_id:
            return
        try:
            if device_kind == "instrument":
                self.device_panel._remove_instrument(source_track_id)
                # v517: Auto track-type adjustment — if source track was an instrument
                # track and now has no instrument, convert back to audio track
                try:
                    proj = getattr(self.services, "project", None)
                    project_obj = getattr(getattr(proj, "ctx", None), "project", None)
                    src_trk = next((t for t in (getattr(project_obj, "tracks", []) or []) if str(getattr(t, "id", "") or "") == source_track_id), None)
                    if src_trk is not None:
                        src_kind = str(getattr(src_trk, "kind", "") or "").strip().lower()
                        src_plugin = str(getattr(src_trk, "plugin_type", "") or "").strip()
                        if src_kind == "instrument" and not src_plugin:
                            proj.set_track_kind(source_track_id, "audio")
                except Exception:
                    pass
            elif device_kind == "note_fx" and source_device_id:
                self.device_panel.remove_note_fx_device(source_track_id, source_device_id)
            elif device_kind == "audio_fx" and source_device_id:
                self.device_panel.remove_audio_fx_device(source_track_id, source_device_id)
        except Exception:
            pass

    @staticmethod
    def _is_ctrl_held() -> bool:
        """Check if Ctrl/Cmd modifier is currently held (for copy-on-drag, Bitwig-style)."""
        try:
            from PyQt6.QtWidgets import QApplication
            from PyQt6.QtCore import Qt
            mods = QApplication.keyboardModifiers()
            return bool(mods & Qt.KeyboardModifier.ControlModifier)
        except Exception:
            return False

    def _on_arranger_smartdrop_instrument_morph_guard(self, track_id: str, payload: dict) -> None:
        """Route Instrument→Audio drops through the central preview/validate/apply guard.

        For the minimal case (empty audio track), this now performs the real
        atomic mutation: track.kind change + instrument insertion + undo push.
        For all other cases, it stays non-mutating with a guard dialog.
        """
        plan = self._build_smartdrop_audio_to_instrument_morph_plan(track_id, payload)
        if not plan:
            try:
                self._set_status("SmartDrop noch gesperrt: Audio→Instrument-Morphing-Plan konnte nicht erstellt werden.", 3600)
            except Exception:
                pass
            return
        dialog_result = self._show_smartdrop_morph_guard_dialog(plan)
        dialog_shown = bool(dialog_result.get("shown"))
        dialog_accepted = bool(dialog_result.get("accepted"))
        proj = getattr(self.services, "project", None)
        result: dict
        if bool(plan.get("can_apply")):
            if dialog_shown and not dialog_accepted:
                result = dict(plan)
                result["message"] = "Morphing abgebrochen. Es wurde nichts veraendert."
            else:
                try:
                    result = dict(proj.apply_audio_to_instrument_morph(plan) or {}) if proj is not None else dict(plan)
                except Exception:
                    result = dict(plan)
                # Stage 2+3: If the atomic morph succeeded, insert the instrument
                if bool(result.get("ok")) and bool(result.get("applied")):
                    try:
                        payload_dict = dict(payload or {})
                        plugin_id = str(payload_dict.get("plugin_id") or "").strip()
                        plugin_name = str(payload_dict.get("plugin_name") or payload_dict.get("name") or "").strip() or "Instrument"
                        morph_track_id = str(result.get("track_id") or track_id or "").strip()
                        # v516: cross-track move detection / v517: Ctrl = copy
                        source_track_id = str(payload_dict.get("source_track_id") or "").strip()
                        is_cross_track = bool(source_track_id and source_track_id != morph_track_id)
                        is_copy = self._is_ctrl_held()
                        if plugin_id and morph_track_id:
                            try:
                                self.device_panel.add_instrument_to_track(morph_track_id, plugin_id)
                            except Exception:
                                pass
                            # v516: Remove from source / v517: skip if Ctrl (copy)
                            # v519: Migrate automation lanes with the device
                            # v522: Always migrate automation (copy or move)
                            if is_cross_track and source_track_id:
                                self._migrate_automation_for_device_move(source_track_id, morph_track_id, "", "instrument", copy=is_copy)
                            if is_cross_track and source_track_id and not is_copy:
                                self._smartdrop_remove_from_source(source_track_id, "", "instrument", plugin_name)
                            try:
                                self.arranger.tracks.select_track(morph_track_id)
                            except Exception:
                                pass
                            try:
                                self.device_panel.show_track(morph_track_id)
                            except Exception:
                                pass
                            try:
                                self._set_view_mode("device", force=True)
                            except Exception:
                                pass
                            try:
                                proj._emit_updated()
                            except Exception:
                                pass
                            try:
                                proj.project_changed.emit()
                            except Exception:
                                pass
                            result["message"] = (
                                f"SmartDrop ausgefuehrt: Audio-Spur → Instrument-Spur ({plugin_name})"
                                + (f" (kopiert von {source_track_id[:8]})" if (is_cross_track and is_copy)
                                   else (f" (verschoben von {source_track_id[:8]})" if is_cross_track else ""))
                                + ". Undo mit Ctrl+Z."
                            )
                    except Exception:
                        pass
        else:
            try:
                result = dict(proj.apply_audio_to_instrument_morph(plan) or {}) if proj is not None else dict(plan)
            except Exception:
                result = dict(plan)
        message = str(result.get("message") or plan.get("blocked_message") or "SmartDrop noch gesperrt: Audio→Instrument-Morphing ist noch nicht freigeschaltet.")
        if dialog_shown and bool(plan.get("requires_confirmation")) and not bool(plan.get("can_apply")):
            message = f"Sicherheitspruefung geoeffnet - {message}"
        try:
            self._set_status(message, 4200 if dialog_shown else 3800)
        except Exception:
            pass

    def _on_arranger_smartdrop_instrument_to_track(self, track_id: str, payload: dict) -> None:
        """Insert/replace an instrument on an existing instrument track.

        v0.0.20.479: handles drops onto EXISTING instrument tracks
        v0.0.20.516: also handles cross-track moves from DevicePanel (Bitwig-style)
        """
        track_id = str(track_id or "").strip()
        if not track_id:
            return
        try:
            payload = dict(payload or {})
        except Exception:
            payload = {}
        plugin_id = str(payload.get("plugin_id") or "").strip()
        plugin_name = str(payload.get("name") or "").strip() or "Instrument"
        params = dict(payload.get("params") or {}) if isinstance(payload.get("params"), dict) else {}
        # v0.0.20.884: Merge __preset_params from Preset Universe drag payload
        if not params and isinstance(payload.get("__preset_params"), dict):
            params = dict(payload["__preset_params"])
        raw_kind = str(payload.get("kind") or "").strip().lower()
        device_kind = str(payload.get("device_kind") or raw_kind or "").strip().lower()
        if device_kind != "instrument" or not plugin_id:
            return

        # v516: cross-track move detection / v517: Ctrl = copy
        source_track_id = str(payload.get("source_track_id") or "").strip()
        source_device_id = str(payload.get("device_id") or "").strip()
        is_cross_track = bool(source_track_id and source_track_id != track_id)
        is_copy = self._is_ctrl_held()  # v517: Ctrl+Drag = Copy

        proj = getattr(self.services, "project", None)
        project_obj = getattr(getattr(proj, "ctx", None), "project", None)
        track = None
        try:
            tracks = list(getattr(project_obj, "tracks", []) or [])
            track = next((t for t in tracks if str(getattr(t, "id", "") or "") == track_id), None)
        except Exception:
            track = None
        if track is None or str(getattr(track, "kind", "") or "") != "instrument":
            return

        track_name = str(getattr(track, "name", "") or track_id)
        try:
            verb = "kopieren" if is_copy else "verschieben"
            if is_cross_track:
                proj._auto_undo_pending_label = f"SmartDrop: Instrument {verb} → {track_name} ({plugin_name})"
            else:
                proj._auto_undo_pending_label = f"SmartDrop: Instrument auf Spur ({plugin_name})"
        except Exception:
            pass

        ok = False
        try:
            if raw_kind == "instrument":
                ok = bool(self.device_panel.add_instrument_to_track(track_id, plugin_id))
            else:
                ok = bool(self.device_panel.add_audio_fx_to_track(track_id, plugin_id, name=plugin_name, params=params))
        except Exception:
            ok = False

        if not ok:
            try:
                self._set_status(f"SmartDrop fehlgeschlagen: {plugin_name} konnte nicht auf {track_name} eingefügt werden.", 3200)
            except Exception:
                pass
            return

        # v522: Always migrate automation (copy or move), only remove source on move
        if is_cross_track and source_track_id:
            self._migrate_automation_for_device_move(source_track_id, track_id, source_device_id, "instrument", copy=is_copy)
        if is_cross_track and source_track_id and not is_copy:
            self._smartdrop_remove_from_source(source_track_id, source_device_id, "instrument", plugin_name)

        try:
            self.arranger.tracks.select_track(track_id)
        except Exception:
            pass
        try:
            self.device_panel.show_track(track_id)
        except Exception:
            pass
        try:
            self._set_view_mode("device", force=True)
        except Exception:
            pass
        try:
            verb = "kopiert" if (is_cross_track and is_copy) else ("verschoben" if is_cross_track else "gesetzt")
            self._set_status(f"SmartDrop: Instrument {verb} — {track_name} · {plugin_name}", 2600)
        except Exception:
            pass

        # v0.0.20.884: Apply preset params after instrument is set on track
        if params or payload.get("__factory_sample"):
            try:
                from PyQt6.QtCore import QTimer
                preset_data = {
                    "plugin_id": plugin_id,
                    "name": plugin_name,
                    "params": params,
                }
                QTimer.singleShot(400, lambda d=dict(preset_data): self.device_panel.apply_universe_preset(d))
            except Exception:
                pass

    def _on_arranger_smartdrop_fx_to_track(self, track_id: str, payload: dict) -> None:
        """Insert compatible FX on an existing compatible track.

        v0.0.20.480: Note-FX/Audio-FX on compatible tracks
        v0.0.20.516: also handles cross-track moves from DevicePanel (Bitwig-style)
        """
        track_id = str(track_id or "").strip()
        if not track_id:
            return
        try:
            payload = dict(payload or {})
        except Exception:
            payload = {}
        plugin_id = str(payload.get("plugin_id") or "").strip()
        plugin_name = str(payload.get("name") or "").strip() or "Effekt"
        params = dict(payload.get("params") or {}) if isinstance(payload.get("params"), dict) else {}
        # v0.0.20.884: Merge __preset_params from Preset Universe drag payload
        if not params and isinstance(payload.get("__preset_params"), dict):
            params = dict(payload["__preset_params"])
        device_kind = str(payload.get("device_kind") or payload.get("kind") or "").strip().lower()
        if device_kind not in ("audio_fx", "note_fx") or not plugin_id:
            return

        # v516: cross-track move detection / v517: Ctrl = copy
        source_track_id = str(payload.get("source_track_id") or "").strip()
        source_device_id = str(payload.get("device_id") or "").strip()
        is_cross_track = bool(source_track_id and source_track_id != track_id)
        is_copy = self._is_ctrl_held()  # v517: Ctrl+Drag = Copy

        proj = getattr(self.services, "project", None)
        project_obj = getattr(getattr(proj, "ctx", None), "project", None)
        track = None
        try:
            tracks = list(getattr(project_obj, "tracks", []) or [])
            track = next((t for t in tracks if str(getattr(t, "id", "") or "") == track_id), None)
        except Exception:
            track = None
        if track is None:
            return

        track_kind = str(getattr(track, "kind", "") or "").strip().lower()
        move_verb = "kopieren" if (is_cross_track and is_copy) else ("verschieben" if is_cross_track else "gesetzt")
        t_name = str(getattr(track, 'name', '') or track_id)
        if device_kind == "note_fx":
            compatible = track_kind == "instrument"
            undo_label = f"SmartDrop: Note-FX {move_verb} ({plugin_name})"
            ok_call = lambda: bool(self.device_panel.add_note_fx_to_track(track_id, plugin_id, name=plugin_name, params=params))
            status_ok = f"SmartDrop: Note-FX {move_verb} — {t_name} · {plugin_name}"
            status_fail = f"SmartDrop fehlgeschlagen: {plugin_name} konnte nicht als Note-FX auf {t_name} eingefügt werden."
        else:
            compatible = track_kind in ("instrument", "audio", "bus", "group", "fx")
            undo_label = f"SmartDrop: Audio-FX {move_verb} ({plugin_name})"
            ok_call = lambda: bool(self.device_panel.add_audio_fx_to_track(track_id, plugin_id, name=plugin_name, params=params))
            status_ok = f"SmartDrop: Audio-FX {move_verb} — {t_name} · {plugin_name}"
            status_fail = f"SmartDrop fehlgeschlagen: {plugin_name} konnte nicht als Audio-FX auf {t_name} eingefügt werden."
        if not compatible:
            return

        try:
            proj._auto_undo_pending_label = undo_label
        except Exception:
            pass

        ok = False
        try:
            ok = bool(ok_call())
        except Exception:
            ok = False
        if not ok:
            try:
                self._set_status(status_fail, 3200)
            except Exception:
                pass
            return

        # v522: Always migrate automation (copy or move), only remove source on move
        if is_cross_track and source_track_id and source_device_id:
            self._migrate_automation_for_device_move(source_track_id, track_id, source_device_id, device_kind, copy=is_copy)
        if is_cross_track and source_track_id and source_device_id and not is_copy:
            self._smartdrop_remove_from_source(source_track_id, source_device_id, device_kind, plugin_name)

        try:
            self.arranger.tracks.select_track(track_id)
        except Exception:
            pass
        try:
            self.device_panel.show_track(track_id)
        except Exception:
            pass
        try:
            self._set_view_mode("device", force=True)
        except Exception:
            pass
        try:
            self._set_status(status_ok, 2600)
        except Exception:
            pass

    def _on_arranger_smartdrop_new_instrument_track(self, payload: dict) -> None:
        """Create a new instrument track from an empty-space Arranger plugin drop.

        Safety-first MVP for v0.0.20.478:
        - only handles instrument-capable payloads
        - only creates a NEW track at the end
        - no track morphing of existing tracks
        - uses the existing add_track + device-panel insert paths
        """
        try:
            payload = dict(payload or {})
        except Exception:
            payload = {}
        plugin_id = str(payload.get("plugin_id") or "").strip()
        plugin_name = str(payload.get("name") or "").strip() or "Instrument Track"
        params = dict(payload.get("params") or {}) if isinstance(payload.get("params"), dict) else {}
        # v0.0.20.884: Merge __preset_params from Preset Universe drag payload
        if not params and isinstance(payload.get("__preset_params"), dict):
            params = dict(payload["__preset_params"])
        raw_kind = str(payload.get("kind") or "").strip().lower()
        device_kind = str(payload.get("device_kind") or raw_kind or "").strip().lower()
        if device_kind != "instrument" or not plugin_id:
            return

        proj = getattr(self.services, "project", None)
        if proj is None:
            return

        try:
            proj._auto_undo_pending_label = f"SmartDrop: Neue Instrument-Spur ({plugin_name})"
        except Exception:
            pass

        new_track = None
        try:
            new_track = proj.add_track("instrument", name=plugin_name)
        except Exception:
            new_track = None
        new_track_id = str(getattr(new_track, "id", "") or "")
        if not new_track_id:
            try:
                self._set_status("SmartDrop fehlgeschlagen: Spur konnte nicht angelegt werden.", 2600)
            except Exception:
                pass
            return

        ok = False
        try:
            if raw_kind == "instrument":
                ok = bool(self.device_panel.add_instrument_to_track(new_track_id, plugin_id))
            else:
                ok = bool(self.device_panel.add_audio_fx_to_track(new_track_id, plugin_id, name=plugin_name, params=params))
        except Exception:
            ok = False

        if not ok:
            try:
                proj.remove_track(new_track_id)
            except Exception:
                pass
            try:
                self._set_status(f"SmartDrop fehlgeschlagen: {plugin_name} konnte nicht in die neue Spur eingefügt werden.", 3200)
            except Exception:
                pass
            return

        try:
            self.arranger.tracks.select_track(new_track_id)
        except Exception:
            pass
        try:
            self.device_panel.show_track(new_track_id)
        except Exception:
            pass

        # v0.0.20.884: Apply preset params after instrument is created
        if params or payload.get("__factory_sample"):
            try:
                from PyQt6.QtCore import QTimer
                preset_data = {
                    "plugin_id": plugin_id,
                    "name": plugin_name,
                    "params": params,
                }
                QTimer.singleShot(400, lambda d=dict(preset_data): self.device_panel.apply_universe_preset(d))
            except Exception:
                pass
        try:
            self._set_view_mode("device", force=True)
        except Exception:
            pass
        try:
            self._set_status(f"SmartDrop: Neue Instrument-Spur angelegt — {plugin_name}", 2600)
        except Exception:
            pass


    # --- Phase 2/3: Track-Header ▾ helpers (UI-only) ---

