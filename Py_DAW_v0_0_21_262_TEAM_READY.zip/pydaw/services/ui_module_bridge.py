"""
pydaw.services.ui_module_bridge
================================

Python-Side Bridge: UI-Modul-Werte (Frigg.Knob/Slider/Toggle/Bang/…)
werden in `set_module_param`-Calls an die DSP-Ziel-Module übersetzt.

**Eingebaut in v0.0.21.195** als zentrale Komponente der Bitwig-Grid-/
PureData-/Max-for-Live-Architektur in FLUX.

Architektur
-----------

::

    User dreht Frigg.Knob im Canvas
        │
        ▼
    AnimatedKnob.value_changed(0.7)
        │
        ▼
    ModuleItem (Canvas) ruft  bridge.handle_ui_value_changed(patch, mod_id, 0.7)
        │
        ▼
    UiModuleBridge:
      - Sucht alle Connections vom Frigg.Knob.out
      - Pro Connection: setzt am Target-Modul den entsprechenden
        Ziel-Param via flux_rust_sync.set_module_param
        │
        ▼
    Rust-Engine bekommt FluxSetModuleParam wie als wäre es ein
    direkter PropertiesPanel-Edit (D-1-Pfad seit v.184/v.190)

Das ist sauber, weil:

1. **Keine Rust-Änderung nötig** — der bestehende `FluxSetModuleParam`-IPC
   ist der einzige Weg, der genutzt wird
2. **Frigg-Module sind in der Engine unsichtbar** —
   `flux_rust_sync.build_sync_patch_command()` filtert sie raus
3. **Verbindung Frigg→DSP ist im Patch-Modell ein normaler Connection-
   Eintrag** — wird beim Save/Load mitgespeichert
4. **Erweiterbar**: später kann ein Frigg-Modul native Rust-Implementation
   bekommen, und die Bridge wird dann nur noch ein No-op

Convention (siehe `module_library.py` Frigg-Factories)
-------------------------------------------------------

* Jedes Frigg-Modul hat genau einen Output-Port `out` (CV oder GATE)
* Wert lebt in `module.params["value"]`
* Range in `module.params["minimum"]` / `params["maximum"]`
* Default in `module.params["default"]`

Wenn ein Frigg-Modul mehrere Outputs hat (NICHT der Standardfall),
wird der erste verwendet.
"""

from __future__ import annotations

import logging
from typing import Optional

from pydaw.flux.patch_model import Patch, Module, Connection, PortDirection


logger = logging.getLogger(__name__)


class UiModuleBridge:
    """Übersetzt UI-Modul-Wert-Änderungen in DSP-Modul-Param-Updates.

    Ist instantiierbar; eine Instanz pro Anwendung reicht
    (`get_ui_module_bridge()` Singleton). Die Bridge ist stateless —
    sie hält keinen Patch-State, sondern bekommt das Patch bei jedem
    Aufruf übergeben (so umgehen wir das Problem von Patch-Switches
    und Per-Track-Patches).

    Defensive Properties
    --------------------

    * **No-engine-mode**: wenn `flux_rust_sync` keine Bridge findet,
      ist der ganze Aufruf eine no-op. UI bleibt am Leben.
    * **No-target-mode**: wenn das UI-Modul keine ausgehenden
      Connections hat, wird der Wert NUR im UI-Modul gespeichert
      (Patch-Modell), nicht weitergesendet.
    * **Tolerant gegen unbekannte Ziel-Module**: wenn ein Connection
      auf ein Modul zeigt das nicht (mehr) existiert, wird ein
      `debug!` geloggt und die Connection übersprungen.
    """

    def __init__(self) -> None:
        self._dispatched_count: int = 0
        self._skipped_count: int = 0

    # ─── Hauptmethode ───────────────────────────────────────────────

    def handle_ui_value_changed(
        self,
        patch: Optional[Patch],
        module_id: str,
        value: float,
    ) -> int:
        """UI-Modul-Wert hat sich geändert → an alle Ziele dispatchen.

        Speichert den neuen Wert im UI-Modul-Patch-Modell, iteriert
        dann alle ausgehenden Connections und ruft für jede Ziel-
        Adresse `flux_rust_sync.set_module_param` auf.

        Returns: Anzahl erfolgreich dispatchter Param-Updates.
        """
        if patch is None:
            logger.debug("[UI-BRIDGE] no patch, skip dispatch")
            return 0
        ui_mod = patch.get_module(module_id)
        if ui_mod is None:
            logger.debug("[UI-BRIDGE] module %s not in patch", module_id)
            return 0
        if not ui_mod.is_ui_widget():
            # Sicherheits-Check — handle_ui_value_changed soll NUR für
            # echte UI-Module aufgerufen werden
            logger.debug(
                "[UI-BRIDGE] module %s is not a UI widget (%s.%s) — skip",
                module_id, ui_mod.god, ui_mod.kind,
            )
            return 0

        # Wert im UI-Modul-Patch-Modell speichern (für Save/Persist)
        ui_mod.params["value"] = float(value)

        # Alle ausgehenden Connections finden
        outgoing = self._find_outgoing(patch, module_id)
        if not outgoing:
            self._skipped_count += 1
            logger.debug(
                "[UI-BRIDGE] %s.%s value=%g, no outgoing connections — UI-only",
                ui_mod.god, ui_mod.kind, value,
            )
            return 0

        # Pro Connection: dispatch
        n_dispatched = 0
        try:
            from pydaw.services.flux_rust_sync import get_flux_rust_sync
            sync = get_flux_rust_sync()
        except Exception as e:
            logger.debug("[UI-BRIDGE] flux_rust_sync unavailable: %s", e)
            sync = None

        # v0.0.21.196: Source-Range vom UI-Modul lesen (Knob 0..1, Slider 0..1, …)
        src_min = float(ui_mod.params.get("minimum", 0.0))
        src_max = float(ui_mod.params.get("maximum", 1.0))
        if src_max <= src_min:
            src_max = src_min + 1.0  # degenerate Range absichern

        for conn in outgoing:
            target_mod = patch.get_module(conn.target_module)
            if target_mod is None:
                logger.debug(
                    "[UI-BRIDGE] target module %s not found, skip",
                    conn.target_module,
                )
                continue

            # v0.0.21.196: Auto-Range-Mapping. Wenn die Connection scale=1
            # offset=0 hat (Default), mappen wir Source-Range linear auf
            # Target-Port-Range. Damit sendet ein Knob 0..1 verbunden mit
            # Bragi.SineOsc.Frequency (Range 20..20000) automatisch
            # 20..20000 statt 0..1. Wenn der User explizit scale/offset
            # gesetzt hat (z.B. um Inversion oder Custom-Mapping zu machen),
            # respektieren wir das stattdessen.
            conn_scale = float(conn.scale or 1.0)
            conn_offset = float(conn.offset or 0.0)
            is_default_mapping = (conn_scale == 1.0 and conn_offset == 0.0)

            scaled = float(value)
            if is_default_mapping:
                # Auto-Map: Source [src_min..src_max] → Target [tgt_min..tgt_max]
                target_port = target_mod.get_port(
                    conn.target_port, PortDirection.INPUT,
                ) if hasattr(target_mod, "get_port") else None
                tgt_min = None
                tgt_max = None
                if target_port is not None:
                    tgt_min = getattr(target_port, "minimum", None)
                    tgt_max = getattr(target_port, "maximum", None)
                if tgt_min is not None and tgt_max is not None and tgt_max > tgt_min:
                    # Lineares Mapping
                    t = (float(value) - src_min) / (src_max - src_min)
                    scaled = float(tgt_min) + t * (float(tgt_max) - float(tgt_min))
                # Sonst: identity (kein Range-Info am Target-Port)
            else:
                # User hat scale/offset bewusst gesetzt — respektiere das
                scaled = float(value) * conn_scale + conn_offset

            # Engine-Side: setze param am Target
            if sync is not None:
                try:
                    sync.set_module_param(
                        patch.id, conn.target_module, conn.target_port, scaled,
                    )
                except Exception as e:
                    logger.debug(
                        "[UI-BRIDGE] set_module_param failed: %s",
                        e,
                    )
                    continue
            # Patch-Modell: target.params[port_name] auch aktualisieren
            # (für Save/Persist-Konsistenz, falls der Target-Param
            # gleichnamig zum Port ist — FLUX-Konvention)
            if conn.target_port in target_mod.params:
                target_mod.params[conn.target_port] = scaled
            n_dispatched += 1

        self._dispatched_count += n_dispatched
        logger.debug(
            "[UI-BRIDGE] %s.%s value=%g → %d targets dispatched",
            ui_mod.god, ui_mod.kind, value, n_dispatched,
        )
        return n_dispatched

    # ─── Helper ─────────────────────────────────────────────────────

    @staticmethod
    def _find_outgoing(patch: Patch, source_module: str) -> list[Connection]:
        """Alle Connections die vom gegebenen Modul ausgehen."""
        return [c for c in patch.connections if c.source_module == source_module]

    # ─── Statistik (für Debug/Diag) ─────────────────────────────────

    @property
    def dispatched_count(self) -> int:
        return self._dispatched_count

    @property
    def skipped_count(self) -> int:
        return self._skipped_count


# ─── Singleton-Helper ────────────────────────────────────────────────

_INSTANCE: Optional[UiModuleBridge] = None


def get_ui_module_bridge() -> UiModuleBridge:
    """Gibt die globale UiModuleBridge-Instanz zurück. Lazy-init."""
    global _INSTANCE
    if _INSTANCE is None:
        _INSTANCE = UiModuleBridge()
    return _INSTANCE


__all__ = ["UiModuleBridge", "get_ui_module_bridge"]
