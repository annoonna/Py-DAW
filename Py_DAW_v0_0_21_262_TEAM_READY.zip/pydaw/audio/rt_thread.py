"""Realtime thread helpers for the audio engine.

v0.0.20.775: NEW FILE — Fixes audio stuttering / 3-second dropouts.

Root causes addressed:
1. Audio thread runs at normal priority → kernel preempts it for GUI/GC
2. Python GC runs inside audio callback → unpredictable pauses
3. No memory locking → pages can be swapped out

Usage:
    from pydaw.audio.rt_thread import promote_to_realtime, demote_from_realtime

    # At start of audio thread:
    rt_state = promote_to_realtime()
    
    # At end of audio thread:
    demote_from_realtime(rt_state)
"""
from __future__ import annotations

import gc
import os
import sys
import ctypes
import ctypes.util
from typing import Any, Dict, Optional

from pydaw.utils.logging_setup import get_logger

log = get_logger(__name__)


def promote_to_realtime() -> Dict[str, Any]:
    """Promote the calling thread to near-realtime priority.

    Returns a state dict to pass to demote_from_realtime() later.

    Steps (best-effort, never crashes):
    1. Disable Python garbage collector (prevents 5-50ms pauses)
    2. Set SCHED_FIFO or SCHED_RR at priority 50 (Linux)
    3. Fallback: os.nice(-15) if SCHED_FIFO fails
    4. Lock memory pages (mlockall) to prevent page faults
    """
    state: Dict[str, Any] = {
        "gc_was_enabled": gc.isenabled(),
        "original_nice": 0,
        "sched_set": False,
        "mlocked": False,
    }

    # 1. Disable GC in audio thread
    try:
        if gc.isenabled():
            gc.disable()
            log.info("[RT] GC disabled for audio thread")
    except Exception:
        pass

    # 2. Try SCHED_FIFO (Linux only, needs CAP_SYS_NICE or rtprio in limits.conf)
    if sys.platform == "linux":
        try:
            SCHED_FIFO = 1
            # struct sched_param { int sched_priority; }
            param = os.sched_param(50)  # priority 50 (range 1-99)
            os.sched_setscheduler(0, SCHED_FIFO, param)
            state["sched_set"] = True
            log.info("[RT] SCHED_FIFO priority 50 set ✓")
        except PermissionError:
            # Fallback: try SCHED_RR (sometimes allowed when FIFO isn't)
            try:
                SCHED_RR = 2
                param = os.sched_param(50)
                os.sched_setscheduler(0, SCHED_RR, param)
                state["sched_set"] = True
                log.info("[RT] SCHED_RR priority 50 set ✓")
            except Exception:
                pass
        except Exception:
            pass

        # 2b. Fallback: nice -15 if sched_setscheduler failed
        if not state["sched_set"]:
            try:
                os.nice(-15)
                log.info("[RT] nice(-15) set as fallback")
            except PermissionError:
                try:
                    os.nice(-5)
                    log.info("[RT] nice(-5) set as fallback")
                except Exception:
                    pass
            except Exception:
                pass

        # 3. mlockall — prevent page faults in audio thread
        try:
            libc_name = ctypes.util.find_library("c")
            if libc_name:
                libc = ctypes.CDLL(libc_name, use_errno=True)
                MCL_CURRENT = 1
                MCL_FUTURE = 2
                ret = libc.mlockall(MCL_CURRENT | MCL_FUTURE)
                if ret == 0:
                    state["mlocked"] = True
                    log.info("[RT] mlockall() ✓ — memory pages locked")
                else:
                    log.debug("[RT] mlockall() failed (expected without CAP_IPC_LOCK)")
        except Exception:
            pass

    return state


def demote_from_realtime(state: Dict[str, Any]) -> None:
    """Restore normal thread priority and re-enable GC."""
    # Re-enable GC
    try:
        if state.get("gc_was_enabled", True):
            gc.enable()
    except Exception:
        pass

    # Restore scheduler
    if sys.platform == "linux" and state.get("sched_set"):
        try:
            SCHED_OTHER = 0
            param = os.sched_param(0)
            os.sched_setscheduler(0, SCHED_OTHER, param)
        except Exception:
            pass

    # munlockall
    if state.get("mlocked"):
        try:
            libc_name = ctypes.util.find_library("c")
            if libc_name:
                libc = ctypes.CDLL(libc_name, use_errno=True)
                libc.munlockall()
        except Exception:
            pass
