# Local copy for BRRR plugin independence — original: pydaw/plugins/sampler/ui_widgets.py
# -*- coding: utf-8 -*-
"""Compact UI widgets for the Sampler device (Pro-DAW-Style Device Panel).

Knob: small QPainter-drawn rotary knob with label + value.
WaveformDisplay: thin waveform strip with loop markers.
"""
from __future__ import annotations

import math
from pathlib import Path
from typing import Optional

import numpy as np

from PyQt6.QtCore import Qt, QTimer, QRectF, pyqtSignal
from PyQt6.QtGui import QPainter, QColor, QPen, QFont
from PyQt6.QtWidgets import QWidget, QSizePolicy, QFrame, QMenu


class CompactKnob(QWidget):
    """Compact QPainter-drawn knob (~52x64 px).

    v0.0.20.90:
    - Optional AutomationManager binding (register_parameter)
    - Right-click context menu: "Show Automation in Arranger" + reset
    - External updates (automation playback) move the knob without feedback loops

    Notes:
    - The AutomationManager emits parameter_changed(parameter_id, value) (2 args).
    - We block signals on external updates so legacy engine wiring does not fire.
    """

    valueChanged = pyqtSignal(int)

    def __init__(self, title: str = "", init: int = 0, parent=None):
        super().__init__(parent)
        self._title = title
        self._minimum = 0
        self._maximum = 100
        self._value = int(max(self._minimum, min(self._maximum, init)))
        self._dragging = False
        self._drag_y = 0

        # --- automation binding (optional)
        self._automation_manager = None
        self._automation_param = None
        self._parameter_id: str = ""
        self._track_id: str = ""
        self._default_value: float = float(self._value)
        self._external_update: bool = False
        self._mgr_connected: bool = False

        self.setFixedSize(52, 64)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setToolTip(self._format_tooltip())

    # ---------------- basic API
    def value(self) -> int:
        return self._value

    def minimum(self) -> int:
        return int(self._minimum)

    def maximum(self) -> int:
        return int(self._maximum)

    def setRange(self, minimum: int, maximum: int) -> None:
        try:
            lo = int(round(float(minimum)))
            hi = int(round(float(maximum)))
        except Exception:
            lo, hi = 0, 100
        if hi < lo:
            lo, hi = hi, lo
        self._minimum = lo
        self._maximum = hi
        self.setValue(self._value)

    def _value_ratio(self) -> float:
        span = float(self._maximum - self._minimum)
        if span <= 0.0:
            return 0.0
        return max(0.0, min(1.0, (float(self._value) - float(self._minimum)) / span))

    def _format_value_text(self) -> str:
        v = float(self._value)
        lo = int(self._minimum)
        hi = int(self._maximum)
        if lo == 0 and hi == 100:
            return f"{int(round(v))}%"
        if abs(v) >= 1000.0:
            if abs(v) >= 10000.0 or float(int(v)) == v:
                return f"{int(round(v / 1000.0))}k"
            return f"{v / 1000.0:.1f}k"
        if float(int(v)) == v:
            return str(int(v))
        return f"{v:.1f}"

    def _format_tooltip(self) -> str:
        return f"{self._title}: {self._format_value_text()}"

    def setValueExternal(self, v: int) -> None:
        """Set value from automation/playback without emitting valueChanged."""
        try:
            self._external_update = True
            self.blockSignals(True)
            self.setValue(int(v))
        finally:
            try:
                self.blockSignals(False)
            except Exception:
                pass
            self._external_update = False

    # ---------------- automation
    def bind_automation(
        self,
        automation_manager,
        parameter_id: str,
        *,
        name: str | None = None,
        track_id: str = "",
        minimum: float = 0.0,
        maximum: float = 100.0,
        default: float | None = None,
    ) -> None:
        """Bind this knob to an AutomatableParameter in the global AutomationManager."""
        self._automation_manager = automation_manager
        self._parameter_id = str(parameter_id or "")
        self._track_id = str(track_id or "")

        if default is None:
            default = float(self._value)
        self._default_value = float(default)

        # Create / fetch parameter
        try:
            if self._automation_manager is not None and self._parameter_id:
                self._automation_param = self._automation_manager.register_parameter(
                    self._parameter_id,
                    str(name or self._title or self._parameter_id),
                    float(minimum),
                    float(maximum),
                    float(default),
                    track_id=self._track_id,
                )
        except Exception:
            self._automation_param = None

        # Listen to global changes once (knob updates itself on playback)
        if (not self._mgr_connected) and (self._automation_manager is not None):
            try:
                self._automation_manager.parameter_changed.connect(self._on_mgr_parameter_changed)
                self._mgr_connected = True
            except Exception:
                self._mgr_connected = False

        # Right-click context menu (Bitwig/Ableton style)
        try:
            self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
            try:
                self.customContextMenuRequested.disconnect()
            except (TypeError, RuntimeError):
                pass
            self.customContextMenuRequested.connect(self._show_context_menu)
        except Exception:
            pass

        # Seed base value into the parameter
        try:
            if self._automation_param is not None:
                self._automation_param.set_value(float(self._value))
        except Exception:
            pass

        # v0.0.20.569: Restore persistent CC mapping if one exists
        # (survives widget recreation on zoom out/in, track rebuild, etc.)
        try:
            persistent = getattr(self._automation_manager, "_persistent_cc_map", None)
            if isinstance(persistent, dict) and self._parameter_id:
                cc_info = persistent.get(str(self._parameter_id))
                if cc_info is not None:
                    ch, cc = int(cc_info[0]), int(cc_info[1])
                    self._midi_cc_mapping = (ch, cc)
                    self._register_midi_cc_listener()
        except Exception:
            pass

    def set_automation_target(self, parameter_id: str, *, default: float | None = None) -> None:
        """Switch this knob to control another parameter_id (e.g. Drum slot selection)."""
        self._parameter_id = str(parameter_id or "")
        if default is not None:
            self._default_value = float(default)
        try:
            if self._automation_manager is not None and self._parameter_id:
                self._automation_param = self._automation_manager.get_parameter(self._parameter_id)
        except Exception:
            self._automation_param = None

    # ---------------- value changes
    def setValue(self, v: int) -> None:
        v = int(max(self._minimum, min(self._maximum, int(v))))
        if v != self._value:
            self._value = v
            self.setToolTip(self._format_tooltip())
            self.update()

            if not self.signalsBlocked():
                self.valueChanged.emit(v)

            # Push base value into automation system ONLY for interactive changes
            if (not self._external_update) and (self._automation_param is not None):
                try:
                    self._automation_param.set_value(float(v))
                except Exception:
                    pass

    def _on_mgr_parameter_changed(self, parameter_id: str, value: float) -> None:
        """Automation playback / lane edits → GUI."""
        try:
            if str(parameter_id) != str(self._parameter_id):
                return
            self.setValueExternal(int(round(float(value))))
        except Exception:
            pass

    def _show_context_menu(self, pos) -> None:
        try:
            if self._automation_manager is None or not self._parameter_id:
                return
            menu = QMenu(self)
            act_show = menu.addAction("🔲 Show Automation in Arranger")

            # v0.0.20.397: MIDI Learn context menu
            act_learn = None
            act_unmap = None
            cc_info = getattr(self, "_midi_cc_mapping", None)
            if cc_info is not None:
                ch, cc_num = cc_info
                menu.addAction(f"🎹 Mapped: CC{cc_num} ch{ch}").setEnabled(False)
                act_unmap = menu.addAction("🎹 MIDI Mapping entfernen")
            else:
                act_learn = menu.addAction("🎹 MIDI Learn")

            act_mod = menu.addAction("🔲 Add Modulator (LFO/ENV) — coming soon")
            try:
                act_mod.setEnabled(False)
            except Exception:
                pass
            menu.addSeparator()
            act_reset = menu.addAction("↩ Reset to Default")

            chosen = menu.exec(self.mapToGlobal(pos))
            if chosen is None:
                return
            if chosen == act_show:
                try:
                    self._automation_manager.request_show_automation.emit(str(self._parameter_id))
                except Exception:
                    pass
            elif chosen == act_learn:
                self._start_midi_learn()
            elif chosen == act_unmap:
                self._midi_cc_mapping = None
                self._remove_midi_cc_listener()
                # v0.0.20.569: Also remove from persistent map
                try:
                    persistent = getattr(self._automation_manager, "_persistent_cc_map", None)
                    if isinstance(persistent, dict) and self._parameter_id:
                        persistent.pop(str(self._parameter_id), None)
                except Exception:
                    pass
            elif chosen == act_reset:
                try:
                    if self._automation_param is not None:
                        self._automation_param.set_value(float(self._default_value))
                        self._automation_param.set_automation_value(None)
                except Exception:
                    pass
                self.setValueExternal(int(round(self._default_value)))
        except Exception:
            pass

    # ── MIDI Learn (v0.0.20.397) ──

    def _start_midi_learn(self) -> None:
        """Enter MIDI Learn mode: next CC sets the mapping."""
        try:
            # Find the MidiMappingService or MIDI input
            mgr = self._automation_manager
            if mgr is None:
                return
            # Store ourselves as the learn target on the automation manager
            mgr._midi_learn_knob = self
            # Visual feedback
            self.setStyleSheet("border: 2px solid #ff6060;")
            # Status message
            try:
                from PyQt6.QtWidgets import QApplication
                sb = None
                for w in QApplication.topLevelWidgets():
                    sb = getattr(w, "statusBar", None)
                    if callable(sb):
                        sb().showMessage("MIDI Learn aktiv: bewege jetzt einen CC-Regler am Controller.", 10000)
                        break
            except Exception:
                pass
        except Exception:
            pass

    def _on_midi_learn_cc(self, channel: int, cc: int) -> None:
        """Called when a CC is received during MIDI Learn mode."""
        self._midi_cc_mapping = (int(channel), int(cc))
        self.setStyleSheet("")
        # Register CC listener
        self._register_midi_cc_listener()
        # v0.0.20.569: Save to persistent registry (survives widget rebuilds)
        try:
            mgr = self._automation_manager
            pid = getattr(self, "_parameter_id", None)
            if mgr is not None and pid:
                persistent = getattr(mgr, "_persistent_cc_map", None)
                if persistent is None:
                    mgr._persistent_cc_map = {}
                    persistent = mgr._persistent_cc_map
                persistent[str(pid)] = (int(channel), int(cc))
        except Exception:
            pass

    def _register_midi_cc_listener(self) -> None:
        """Register this knob to receive CC updates from the MIDI input."""
        try:
            mgr = self._automation_manager
            if mgr is None:
                return
            cc_listeners = getattr(mgr, "_midi_cc_listeners", None)
            if cc_listeners is None:
                mgr._midi_cc_listeners = {}
                cc_listeners = mgr._midi_cc_listeners
            mapping = self._midi_cc_mapping
            if mapping is not None:
                cc_listeners[mapping] = self
        except Exception:
            pass

    def _remove_midi_cc_listener(self) -> None:
        """Unregister this knob from CC updates."""
        try:
            mgr = self._automation_manager
            if mgr is None:
                return
            cc_listeners = getattr(mgr, "_midi_cc_listeners", None)
            if cc_listeners is None:
                return
            # Remove any entries pointing to this knob
            to_remove = [k for k, v in cc_listeners.items() if v is self]
            for k in to_remove:
                del cc_listeners[k]
        except Exception:
            pass

    def handle_midi_cc(self, value_0_127: int) -> None:
        """Apply incoming MIDI CC value (0-127) → knob 0-100 + engine."""
        try:
            lo = int(self._minimum)
            hi = int(self._maximum)
            v = lo + int(round((int(value_0_127) / 127.0) * float(hi - lo)))
            self.setValue(v)  # Updates visual + emits valueChanged → engine
        except Exception:
            pass

    # ---------------- drawing + interaction
    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()

        # Title (top)
        p.setPen(QColor("#aaaaaa"))
        p.setFont(QFont("Sans", 7))
        p.drawText(0, 0, w, 12, Qt.AlignmentFlag.AlignHCenter, self._title)

        cx, cy = w // 2, 12 + 20
        r = 14

        # Background arc
        p.setPen(QPen(QColor("#333333"), 3, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        arc = QRectF(cx - r, cy - r, 2 * r, 2 * r)
        p.drawArc(arc, 225 * 16, -270 * 16)

        # Value arc
        ratio = self._value_ratio()
        if ratio > 0.0:
            p.setPen(QPen(QColor("#e060e0"), 3, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
            span = int(-270 * ratio)
            p.drawArc(arc, 225 * 16, span * 16)

        # Pointer
        angle = math.radians(225.0 - ratio * 270.0)
        px = cx + (r - 4) * math.cos(angle)
        py = cy - (r - 4) * math.sin(angle)
        p.setPen(QPen(QColor("#ffffff"), 2, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        p.drawLine(int(cx), int(cy), int(px), int(py))

        # Center dot
        p.setBrush(QColor("#666666"))
        p.setPen(Qt.PenStyle.NoPen)
        p.drawEllipse(cx - 3, cy - 3, 6, 6)

        # Value (bottom)
        p.setPen(QColor("#cccccc"))
        p.setFont(QFont("Sans", 7))
        p.drawText(0, h - 12, w, 12, Qt.AlignmentFlag.AlignHCenter, self._format_value_text())

    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self._dragging = True
            self._drag_y = int(e.position().y())

    def mouseMoveEvent(self, e):
        if self._dragging:
            dy = self._drag_y - int(e.position().y())
            self._drag_y = int(e.position().y())
            self.setValue(self._value + dy)

    def mouseReleaseEvent(self, _):
        self._dragging = False

    def wheelEvent(self, e):
        delta = 1 if e.angleDelta().y() > 0 else -1
        self.setValue(self._value + delta)


