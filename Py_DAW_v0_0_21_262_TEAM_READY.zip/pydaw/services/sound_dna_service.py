"""sound_dna_service.py — Audio Fingerprinting & Sound DNA (Phases T10+T11).

v0.0.20.901 — Phases T10 + T11 der TIME_TRAVEL_ROADMAP.

Jeder Sound bekommt einen "genetischen Fingerabdruck" — ein 128-dimensionaler
Vektor der den Klang-Charakter beschreibt (unabhaengig von Lautstaerke/Tonhoehe).

Berechnung (ohne externe KI-Modelle, rein numpy):
1. 2s Audio-Buffer → STFT → Mel-Spektrogramm (128 Baender)
2. Mittelwert ueber Zeit → 128-dim Vektor
3. L2-Normalisierung

Aehnlichkeitssuche:
- Cosine Similarity zwischen Fingerprints
- > 0.85 = "sehr aehnlich", > 0.70 = "aehnlich"

Cross-Projekt:
- sound_dna Tabelle speichert Fingerprints ALLER Projekte
- "Finde diesen Sound in meinen anderen Projekten"
"""

from __future__ import annotations

import hashlib
import json
import logging
import math
import struct
import time
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger(__name__)

# Fingerprint dimensions
FP_DIMS = 128
FP_SIMILAR_THRESHOLD = 0.70
FP_VERY_SIMILAR_THRESHOLD = 0.85


def _compute_fingerprint_from_buffer(samples: List[float],
                                       sample_rate: int = 48000) -> bytes:
    """Compute a 128-dim audio fingerprint from raw samples.

    Uses a simplified Mel-spectrogram approach (no numpy required).
    Falls back to spectral statistics if buffer is too short.
    """
    if not samples or len(samples) < 256:
        return b'\x00' * (FP_DIMS * 4)

    n = len(samples)

    # Simple DFT-based approach for small buffers
    # Divide into FP_DIMS frequency bins
    # Using a simplified periodogram
    fp = [0.0] * FP_DIMS

    # Window into chunks, compute energy per bin
    chunk_size = min(1024, n)
    n_chunks = max(1, n // chunk_size)

    for chunk_idx in range(n_chunks):
        offset = chunk_idx * chunk_size
        chunk = samples[offset:offset + chunk_size]
        if len(chunk) < 16:
            continue

        # Apply Hanning window
        windowed = []
        clen = len(chunk)
        for i, s in enumerate(chunk):
            w = 0.5 * (1.0 - math.cos(2.0 * math.pi * i / max(1, clen - 1)))
            windowed.append(s * w)

        # Compute magnitude spectrum (simplified DFT for FP_DIMS bins)
        for k in range(FP_DIMS):
            freq_bin = k * (clen // 2) // FP_DIMS
            # Goertzel-like: sum of magnitudes around this bin
            real_sum = 0.0
            imag_sum = 0.0
            bin_freq = freq_bin / max(1, clen)
            for i_s, sv in enumerate(windowed[:clen]):
                angle = 2.0 * math.pi * bin_freq * i_s
                real_sum += sv * math.cos(angle)
                imag_sum -= sv * math.sin(angle)
            mag = math.sqrt(real_sum * real_sum + imag_sum * imag_sum)
            fp[k] += mag

    # Average over chunks
    if n_chunks > 0:
        fp = [v / n_chunks for v in fp]

    # L2 normalize
    norm = math.sqrt(sum(v * v for v in fp))
    if norm > 1e-10:
        fp = [v / norm for v in fp]

    # Pack as float32 bytes
    return struct.pack(f'{FP_DIMS}f', *fp)


def _cosine_similarity(fp_a: bytes, fp_b: bytes) -> float:
    """Compute cosine similarity between two fingerprints."""
    if len(fp_a) != FP_DIMS * 4 or len(fp_b) != FP_DIMS * 4:
        return 0.0

    try:
        a = struct.unpack(f'{FP_DIMS}f', fp_a)
        b = struct.unpack(f'{FP_DIMS}f', fp_b)
    except Exception:
        return 0.0

    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))

    if norm_a < 1e-10 or norm_b < 1e-10:
        return 0.0
    return dot / (norm_a * norm_b)


def _spectral_features(samples: List[float],
                         sample_rate: int = 48000) -> Dict[str, float]:
    """Compute simple spectral features from audio samples."""
    if not samples:
        return {"centroid": 0, "rms_db": -60, "pitch": 0}

    # RMS
    rms = math.sqrt(sum(s * s for s in samples) / max(1, len(samples)))
    rms_db = 20.0 * math.log10(max(1e-10, rms))

    # Zero crossing rate (rough pitch proxy)
    zcr = 0
    for i in range(1, len(samples)):
        if (samples[i] >= 0) != (samples[i - 1] >= 0):
            zcr += 1
    zcr_rate = zcr / max(1, len(samples))

    # Rough pitch estimate from ZCR
    pitch_hz = zcr_rate * sample_rate / 2.0

    # Spectral centroid approximation
    centroid = pitch_hz  # simplified

    return {
        "centroid": centroid,
        "rms_db": rms_db,
        "pitch": pitch_hz,
    }


def _param_hash(params: Dict[str, float]) -> str:
    """Create a SHA-256 hash of sorted parameter values."""
    sorted_items = sorted(params.items())
    data = json.dumps(sorted_items, sort_keys=True)
    return hashlib.sha256(data.encode()).hexdigest()[:16]


class SoundDNAService:
    """Audio fingerprinting and cross-project sound search.

    Computes 128-dim fingerprints, stores in DB, provides similarity search.
    """

    _instance: Optional["SoundDNAService"] = None

    @classmethod
    def get(cls) -> "SoundDNAService":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._db = None
        try:
            from pydaw.services.time_travel_db import TimeTravelDB
            self._db = TimeTravelDB.get()
            self._db.ensure_loaded()
        except Exception:
            pass

    def compute_fingerprint(self, samples: List[float],
                              sample_rate: int = 48000) -> bytes:
        """Compute a 128-dim fingerprint from audio samples."""
        return _compute_fingerprint_from_buffer(samples, sample_rate)

    def store_fingerprint(self, session_id: str, timestamp_ms: int,
                            samples: List[float], track_id: str = "",
                            sample_rate: int = 48000) -> None:
        """Compute and store a fingerprint in the journal."""
        if not self._db:
            return
        fp = self.compute_fingerprint(samples, sample_rate)
        features = _spectral_features(samples, sample_rate)
        self._db.save_audio_fingerprint(
            session_id, timestamp_ms, fp, track_id=track_id,
            spectral_centroid=features.get("centroid", 0),
            rms_db=features.get("rms_db", -60),
            dominant_pitch=features.get("pitch", 0),
        )

    def store_sound_dna(self, project_path: str, track_id: str,
                          plugin_id: str, params: Dict[str, float],
                          preset_name: str = "",
                          samples: Optional[List[float]] = None,
                          tags: str = "") -> None:
        """Store a Sound DNA entry for cross-project search."""
        if not self._db:
            return
        ph = _param_hash(params)
        fp = None
        if samples:
            fp = self.compute_fingerprint(samples)
        self._db.save_sound_dna(
            project_path, track_id, plugin_id, ph,
            preset_name=preset_name, fingerprint=fp, tags=tags,
        )

    def find_similar_in_session(self, session_id: str,
                                  reference_fp: bytes,
                                  limit: int = 10) -> List[Dict[str, Any]]:
        """Find similar sounds in a session by fingerprint similarity."""
        if not self._db:
            return []

        try:
            conn = self._db._conn()
            try:
                rows = conn.execute(
                    """SELECT * FROM journal_audio_fp
                       WHERE session_id=? AND fingerprint IS NOT NULL
                       ORDER BY timestamp_ms DESC LIMIT ?""",
                    (session_id, limit * 3),
                ).fetchall()
            finally:
                conn.close()
        except Exception:
            return []

        results = []
        for r in rows:
            fp = r["fingerprint"]
            if not fp:
                continue
            sim = _cosine_similarity(reference_fp, fp)
            if sim >= FP_SIMILAR_THRESHOLD:
                results.append({
                    "timestamp_ms": r["timestamp_ms"],
                    "track_id": r["track_id"],
                    "similarity": round(sim, 3),
                    "rms_db": r["rms_db"],
                    "spectral_centroid": r["spectral_centroid"],
                    "very_similar": sim >= FP_VERY_SIMILAR_THRESHOLD,
                })

        results.sort(key=lambda x: x["similarity"], reverse=True)
        return results[:limit]

    def find_similar_across_projects(self, plugin_id: str,
                                       reference_fp: Optional[bytes] = None,
                                       limit: int = 20) -> List[Dict[str, Any]]:
        """Find similar sounds across all projects."""
        if not self._db:
            return []

        entries = self._db.find_similar_sounds(plugin_id, limit=limit * 2)
        if not reference_fp:
            return entries[:limit]

        # Rank by fingerprint similarity
        results = []
        for e in entries:
            fp = e.get("fingerprint")
            if fp:
                sim = _cosine_similarity(reference_fp, fp)
                e["similarity"] = round(sim, 3)
            else:
                e["similarity"] = 0.0
            results.append(e)

        results.sort(key=lambda x: x.get("similarity", 0), reverse=True)
        return results[:limit]
