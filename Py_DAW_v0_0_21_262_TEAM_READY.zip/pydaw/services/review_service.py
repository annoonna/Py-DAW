"""Review Service — Comments, markers, and task assignment for collaborative review.

v0.0.20.797 — Phase 5A: Collaboration & Cloud

Features:
  - Time-stamped comments (anchored to beat positions or tracks)
  - Review markers (like flags/notes on the timeline)
  - Task assignment (assign review items to collaborators)
  - Comment threads (reply to comments)
  - Resolution tracking (open/resolved/won't fix)
  - Export review summary (Markdown report)
  - Persistence in project file (survives save/load)

Usage:
    review = ReviewService(project_service)
    review.add_comment(beat=16.0, track_id="trk_1", text="Vocals too loud here")
    review.add_marker(beat=32.0, label="Check reverb tail", color="#FF0000")
    review.add_task(text="Fix clipping on master", assignee="Bob")
    review.resolve_item("comment_abc123")
    report = review.export_summary()
"""

from __future__ import annotations

import json
import logging
import time
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

log = logging.getLogger(__name__)


@dataclass
class ReviewComment:
    """A review comment anchored to a position in the project."""
    id: str = ""
    author: str = ""
    text: str = ""
    beat: float = -1.0       # -1 = not anchored to timeline
    track_id: str = ""       # "" = not anchored to a track
    created_at: str = ""
    status: str = "open"     # "open" | "resolved" | "wontfix"
    resolved_by: str = ""
    resolved_at: str = ""
    parent_id: str = ""      # for threaded replies
    color: str = "#FFD700"   # visual marker color

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ReviewComment":
        known = {f.name for f in cls.__dataclass_fields__.values()}
        return cls(**{k: v for k, v in d.items() if k in known})


@dataclass
class ReviewMarker:
    """A visual marker on the timeline for review purposes."""
    id: str = ""
    label: str = ""
    beat: float = 0.0
    color: str = "#FF6B4A"
    author: str = ""
    created_at: str = ""
    kind: str = "flag"       # "flag" | "region" | "todo"
    end_beat: float = 0.0    # for "region" kind

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ReviewMarker":
        known = {f.name for f in cls.__dataclass_fields__.values()}
        return cls(**{k: v for k, v in d.items() if k in known})


@dataclass
class ReviewTask:
    """A review task assigned to a collaborator."""
    id: str = ""
    text: str = ""
    assignee: str = ""
    author: str = ""
    created_at: str = ""
    due_date: str = ""
    priority: str = "normal"  # "low" | "normal" | "high" | "urgent"
    status: str = "open"      # "open" | "in_progress" | "done" | "wontfix"
    completed_at: str = ""
    related_comment_id: str = ""  # link to a comment
    beat: float = -1.0        # optional timeline anchor

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ReviewTask":
        known = {f.name for f in cls.__dataclass_fields__.values()}
        return cls(**{k: v for k, v in d.items() if k in known})


class ReviewService:
    """Service for managing review comments, markers, and tasks.

    All data is stored in the project's review_data dict and persists
    across save/load cycles.
    """

    def __init__(self, project_service=None):
        self._project = project_service
        self._comments: List[ReviewComment] = []
        self._markers: List[ReviewMarker] = []
        self._tasks: List[ReviewTask] = []
        self._current_user: str = ""

    def set_project_service(self, ps) -> None:
        self._project = ps

    def set_current_user(self, name: str) -> None:
        self._current_user = name

    # ------------------------------------------------------------------
    # Persistence (load/save from project)
    # ------------------------------------------------------------------

    def load_from_project(self) -> None:
        """Load review data from the project."""
        if not self._project:
            return
        try:
            ctx = getattr(self._project, 'ctx', None)
            proj = getattr(ctx, 'project', None) if ctx else None
            if not proj:
                return
            review_data = getattr(proj, 'review_data', {}) or {}
            self._comments = [ReviewComment.from_dict(c) for c in review_data.get("comments", [])]
            self._markers = [ReviewMarker.from_dict(m) for m in review_data.get("markers", [])]
            self._tasks = [ReviewTask.from_dict(t) for t in review_data.get("tasks", [])]
        except Exception as e:
            log.warning("Failed to load review data: %s", e)

    def save_to_project(self) -> None:
        """Save review data to the project."""
        if not self._project:
            return
        try:
            ctx = getattr(self._project, 'ctx', None)
            proj = getattr(ctx, 'project', None) if ctx else None
            if not proj:
                return
            proj.review_data = {
                "comments": [c.to_dict() for c in self._comments],
                "markers": [m.to_dict() for m in self._markers],
                "tasks": [t.to_dict() for t in self._tasks],
            }
        except Exception as e:
            log.warning("Failed to save review data: %s", e)

    # ------------------------------------------------------------------
    # Comments
    # ------------------------------------------------------------------

    def add_comment(self, text: str, beat: float = -1.0,
                    track_id: str = "", parent_id: str = "",
                    color: str = "#FFD700") -> ReviewComment:
        """Add a review comment."""
        comment = ReviewComment(
            id=f"rc_{uuid.uuid4().hex[:10]}",
            author=self._current_user,
            text=text,
            beat=beat,
            track_id=track_id,
            created_at=datetime.utcnow().isoformat(),
            parent_id=parent_id,
            color=color,
        )
        self._comments.append(comment)
        self.save_to_project()
        log.info("Review comment added: '%s' at beat %.1f", text[:40], beat)
        return comment

    def get_comments(self, track_id: str = "",
                     status: str = "") -> List[ReviewComment]:
        """Get comments, optionally filtered."""
        result = list(self._comments)
        if track_id:
            result = [c for c in result if c.track_id == track_id]
        if status:
            result = [c for c in result if c.status == status]
        return sorted(result, key=lambda c: c.beat if c.beat >= 0 else 9999)

    def get_thread(self, parent_id: str) -> List[ReviewComment]:
        """Get all replies to a comment."""
        return sorted(
            [c for c in self._comments if c.parent_id == parent_id],
            key=lambda c: c.created_at,
        )

    def resolve_comment(self, comment_id: str, resolved_by: str = "") -> bool:
        """Mark a comment as resolved."""
        for c in self._comments:
            if c.id == comment_id:
                c.status = "resolved"
                c.resolved_by = resolved_by or self._current_user
                c.resolved_at = datetime.utcnow().isoformat()
                self.save_to_project()
                return True
        return False

    def delete_comment(self, comment_id: str) -> bool:
        """Delete a comment and its replies."""
        before = len(self._comments)
        self._comments = [
            c for c in self._comments
            if c.id != comment_id and c.parent_id != comment_id
        ]
        if len(self._comments) < before:
            self.save_to_project()
            return True
        return False

    # ------------------------------------------------------------------
    # Markers
    # ------------------------------------------------------------------

    def add_marker(self, beat: float, label: str = "",
                   color: str = "#FF6B4A", kind: str = "flag",
                   end_beat: float = 0.0) -> ReviewMarker:
        """Add a review marker on the timeline."""
        marker = ReviewMarker(
            id=f"rm_{uuid.uuid4().hex[:10]}",
            label=label or f"Review at {beat:.1f}",
            beat=beat,
            color=color,
            author=self._current_user,
            created_at=datetime.utcnow().isoformat(),
            kind=kind,
            end_beat=end_beat if kind == "region" else 0.0,
        )
        self._markers.append(marker)
        self.save_to_project()
        return marker

    def get_markers(self) -> List[ReviewMarker]:
        """Get all review markers, sorted by beat."""
        return sorted(self._markers, key=lambda m: m.beat)

    def delete_marker(self, marker_id: str) -> bool:
        before = len(self._markers)
        self._markers = [m for m in self._markers if m.id != marker_id]
        if len(self._markers) < before:
            self.save_to_project()
            return True
        return False

    # ------------------------------------------------------------------
    # Tasks
    # ------------------------------------------------------------------

    def add_task(self, text: str, assignee: str = "",
                 priority: str = "normal", beat: float = -1.0,
                 related_comment_id: str = "") -> ReviewTask:
        """Add a review task."""
        task = ReviewTask(
            id=f"rt_{uuid.uuid4().hex[:10]}",
            text=text,
            assignee=assignee,
            author=self._current_user,
            created_at=datetime.utcnow().isoformat(),
            priority=priority,
            beat=beat,
            related_comment_id=related_comment_id,
        )
        self._tasks.append(task)
        self.save_to_project()
        return task

    def get_tasks(self, assignee: str = "",
                  status: str = "") -> List[ReviewTask]:
        """Get tasks, optionally filtered."""
        result = list(self._tasks)
        if assignee:
            result = [t for t in result if t.assignee == assignee]
        if status:
            result = [t for t in result if t.status == status]
        return result

    def complete_task(self, task_id: str) -> bool:
        for t in self._tasks:
            if t.id == task_id:
                t.status = "done"
                t.completed_at = datetime.utcnow().isoformat()
                self.save_to_project()
                return True
        return False

    def delete_task(self, task_id: str) -> bool:
        before = len(self._tasks)
        self._tasks = [t for t in self._tasks if t.id != task_id]
        if len(self._tasks) < before:
            self.save_to_project()
            return True
        return False

    # ------------------------------------------------------------------
    # Summary / Export
    # ------------------------------------------------------------------

    def get_stats(self) -> Dict[str, Any]:
        """Get review statistics."""
        open_comments = sum(1 for c in self._comments if c.status == "open" and not c.parent_id)
        resolved_comments = sum(1 for c in self._comments if c.status == "resolved" and not c.parent_id)
        open_tasks = sum(1 for t in self._tasks if t.status in ("open", "in_progress"))
        done_tasks = sum(1 for t in self._tasks if t.status == "done")

        return {
            "comments_open": open_comments,
            "comments_resolved": resolved_comments,
            "comments_total": open_comments + resolved_comments,
            "markers": len(self._markers),
            "tasks_open": open_tasks,
            "tasks_done": done_tasks,
            "tasks_total": open_tasks + done_tasks,
        }

    def export_summary(self) -> str:
        """Export review summary as Markdown."""
        stats = self.get_stats()
        lines = [
            "# 🎵 Py_DAW Review Summary",
            "",
            f"**Generated:** {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}",
            f"**Comments:** {stats['comments_open']} open, {stats['comments_resolved']} resolved",
            f"**Tasks:** {stats['tasks_open']} open, {stats['tasks_done']} done",
            f"**Markers:** {stats['markers']}",
            "",
        ]

        # Open comments
        open_comments = [c for c in self._comments if c.status == "open" and not c.parent_id]
        if open_comments:
            lines.append("## Open Comments")
            lines.append("")
            for c in sorted(open_comments, key=lambda x: x.beat if x.beat >= 0 else 9999):
                pos = f"Beat {c.beat:.1f}" if c.beat >= 0 else "General"
                track = f" (Track: {c.track_id})" if c.track_id else ""
                lines.append(f"- **{pos}{track}** — {c.text} _{c.author}, {c.created_at[:10]}_")
                replies = self.get_thread(c.id)
                for r in replies:
                    lines.append(f"  - ↳ {r.text} _{r.author}_")
            lines.append("")

        # Open tasks
        open_tasks = [t for t in self._tasks if t.status in ("open", "in_progress")]
        if open_tasks:
            lines.append("## Open Tasks")
            lines.append("")
            for t in open_tasks:
                assignee = f" → {t.assignee}" if t.assignee else ""
                prio = f" [{t.priority.upper()}]" if t.priority != "normal" else ""
                lines.append(f"- {'🔴' if t.priority == 'urgent' else '⬜'}{prio} {t.text}{assignee}")
            lines.append("")

        # Markers
        if self._markers:
            lines.append("## Review Markers")
            lines.append("")
            for m in sorted(self._markers, key=lambda x: x.beat):
                lines.append(f"- Beat {m.beat:.1f}: {m.label} _{m.author}_")
            lines.append("")

        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Clear
    # ------------------------------------------------------------------

    def clear_all(self) -> None:
        """Remove all review data."""
        self._comments.clear()
        self._markers.clear()
        self._tasks.clear()
        self.save_to_project()

    def clear_resolved(self) -> None:
        """Remove only resolved comments and done tasks."""
        self._comments = [c for c in self._comments if c.status != "resolved"]
        self._tasks = [t for t in self._tasks if t.status != "done"]
        self.save_to_project()
