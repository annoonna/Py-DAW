"""
pydaw.services.flux_vault_factory_thunderdome — Hardcore Thunderdome Factory

**v0.0.21.214 — Thunderdome v1**
================================

Hardcore-/Gabber-/Industrial-Leads + verzerrte Bass-Kicks im Stil der
Thunderdome-Compilations (Niederlande, Mitte 90er bis 2000er).
Anno: „Hardcore Thunderdome ca 12 variations".

Charakter aller Patches: **brutal verzerrt, übersteuert, Übersättigung**.
Jeder Preset kombiniert mindestens **2 Distortion-/Saturation-Stufen** in
Reihe (Thor.TubeDrive + Thor.Fuzz oder + Fenrir.BitCrush) damit das
typische zerschossene Klangbild entsteht.

| Preset             | Charakter |
|--------------------|-----------|
| Gabber-Kick        | Sub-Saw + TubeDrive Hard + Fuzz + Limiter (klassisch) |
| Distorted-Bass     | Saw + 4-Pole-LP + TubeDrive + WaveShaper |
| Hoover-Lead        | Saw+Square Stack + LFO-PWM + Phaser + TubeDrive |
| Acid-303           | Saw + LP+Resonance + ADSR-Cutoff + Fuzz |
| Mentasm-Stab       | Saw + Phaser + Detune + TubeDrive + Limiter |
| Industrial-Hit     | NoiseOsc + Bandpass + BitCrush + Reverb |
| Berserker-Lead     | Saw + Decimator + Fuzz + Phaser + Limiter |
| Reverse-Crash      | NoiseOsc + LFO-Sweep + Reverb + Fuzz |
| Hardcore-Stab      | Square + LFO-PWM + TubeDrive + Decimator |
| Sub-Detonation     | SineOsc(40Hz) + Saw layer + TubeDrive + Compressor |
| Screech-Lead       | SquareOsc + Highpass + Fuzz + WaveShaper |
| Thunder-Pad        | Saw stack + Chorus + Phaser + Compressor |

Versions-Marker ``"FLUX Factory (Thunderdome v1)"``. Alle Patches sind
**rein additiv** und nutzen ausschließlich existierende Module — keine
neuen Module nötig.
"""

from __future__ import annotations

import logging
from typing import Optional

logger = logging.getLogger(__name__)


THUNDERDOME_FACTORY_VERSION = "v1"
THUNDERDOME_FACTORY_AUTHOR = (
    f"FLUX Factory (Thunderdome {THUNDERDOME_FACTORY_VERSION})"
)


# ─── Helper (identisch zu drumkit/synthwave) ─────────────────────


def _connect(patch, src_id: str, src_port: str,
             tgt_id: str, tgt_port: str) -> bool:
    from pydaw.flux.patch_model import Connection
    src = patch.get_module(src_id)
    tgt = patch.get_module(tgt_id)
    if src is None or tgt is None:
        return False
    return patch.add_connection(Connection(
        source_module=src_id, source_port=src_port,
        target_module=tgt_id, target_port=tgt_port,
    ))


def _set(module, **params) -> None:
    if module is None:
        return
    for k, v in params.items():
        if k in module.params:
            module.params[k] = v


def _build_patch_dict(name: str, builder) -> Optional[dict]:
    try:
        from pydaw.flux.patch_model import Patch
        p = builder()
        if not isinstance(p, Patch):
            return None
        p.name = name
        return p.to_dict()
    except Exception as e:
        logger.warning("[ThunderdomePresets-v1] build %s failed: %s", name, e)
        return None


# ─── Patch-Builder pro Variation (Thunderdome v1) ─────────────────


def _build_gabber_kick():
    """Gabber-Kick — Saw(50Hz) + TubeDrive(hard) + Fuzz + Limiter.

    Klassischer Rotterdam-Gabber-Kick: tiefer Saw (im Gegensatz zu Sub-Sine
    wegen der Obertöne), dann zwei Verzerrungs-Stufen (TubeDrive + Fuzz),
    am Ende harter Limiter. Klingt wie ein „Faust ins Gesicht".
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_saw_osc, make_freyr_adsr, make_tyr_pulse_gate,
        make_thor_tube_drive, make_thor_fuzz, make_vidar_limiter,
        make_heimdall_master_out,
    )
    p = Patch(name="Gabber-Kick")
    osc = make_bragi_saw_osc(); osc.position = (260, 200)
    _set(osc, freq=50.0, gain=0.0)
    env = make_freyr_adsr(); env.position = (60, 320)
    _set(env, attack=0.002, decay=0.3, sustain=0.0, release=0.05)
    gate = make_tyr_pulse_gate(); gate.position = (60, 200)
    _set(gate, rate=2.5, pulse_width=0.1)
    drv = make_thor_tube_drive(); drv.position = (480, 200)
    _set(drv, drive=15.0, tone=0.4, mix=1.0)
    fuzz = make_thor_fuzz(); fuzz.position = (700, 200)
    _set(fuzz, gain=8.0, bias=0.2, mix=0.85)
    lim = make_vidar_limiter(); lim.position = (920, 200)
    _set(lim, ceiling=-0.5, release_ms=20.0)
    out = make_heimdall_master_out(); out.position = (1140, 200)
    for m in (osc, env, gate, drv, fuzz, lim, out):
        p.add_module(m)
    _connect(p, gate.id, "gate_out", env.id, "gate")
    _connect(p, env.id, "cv_out", osc.id, "gain")
    _connect(p, osc.id, "audio_out", drv.id, "audio_in")
    _connect(p, drv.id, "audio_out", fuzz.id, "audio_in")
    _connect(p, fuzz.id, "audio_out", lim.id, "audio_in")
    _connect(p, lim.id, "audio_out", out.id, "audio_in_l")
    _connect(p, lim.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_distorted_bass():
    """Distorted-Bass — Saw + Lowpass(resonance) + TubeDrive + WaveShaper.

    Treibender Sub-Bass: Saw bei 80 Hz, dann Lowpass mit hoher Resonanz
    für „bouncy"-Charakter, anschließend zwei nichtlineare Stufen
    (TubeDrive für sanfte Wärme, WaveShaper für harte Verzerrung).
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_saw_osc, make_forseti_lowpass,
        make_thor_tube_drive, make_thor_wave_shaper,
        make_heimdall_master_out,
    )
    p = Patch(name="Distorted-Bass")
    osc = make_bragi_saw_osc(); osc.position = (60, 200)
    _set(osc, freq=80.0, gain=0.5)
    flt = make_forseti_lowpass(); flt.position = (260, 200)
    _set(flt, cutoff=600.0, resonance=0.85)
    drv = make_thor_tube_drive(); drv.position = (480, 200)
    _set(drv, drive=10.0, tone=0.45, mix=0.9)
    ws = make_thor_wave_shaper(); ws.position = (700, 200)
    _set(ws)
    out = make_heimdall_master_out(); out.position = (920, 200)
    for m in (osc, flt, drv, ws, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", flt.id, "audio_in")
    _connect(p, flt.id, "audio_out", drv.id, "audio_in")
    _connect(p, drv.id, "audio_out", ws.id, "audio_in")
    _connect(p, ws.id, "audio_out", out.id, "audio_in_l")
    _connect(p, ws.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_hoover_lead():
    """Hoover-Lead — Square + LFO-PWM + Phaser + TubeDrive.

    Der unverwechselbare „Hoover"-Klang aus den frühen 90ern. FLUX hat
    keinen Mixer-Modul, daher single-source: nur Square mit LFO auf gain
    (= klassische Pulsweiten-Modulation), Phaser für Bewegung,
    TubeDrive für Aggression. Wer den vollen Stack will, kann manuell
    einen zweiten Saw-Osc hinzufügen und stereo splitten.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_square_osc, make_loki_lfo_sine,
        make_skadi_phaser, make_thor_tube_drive, make_forseti_lowpass,
        make_heimdall_master_out,
    )
    p = Patch(name="Hoover-Lead")
    sq = make_bragi_square_osc(); sq.position = (60, 200)
    _set(sq, freq=220.0, gain=0.4)
    lfo = make_loki_lfo_sine(); lfo.position = (60, 60)
    _set(lfo, rate=4.0, depth=0.3)
    flt = make_forseti_lowpass(); flt.position = (260, 200)
    _set(flt, cutoff=2500.0, resonance=0.5)
    ph = make_skadi_phaser(); ph.position = (480, 200)
    _set(ph, rate=0.4, depth=0.7, mix=0.6)
    drv = make_thor_tube_drive(); drv.position = (700, 200)
    _set(drv, drive=6.0, tone=0.55, mix=0.7)
    out = make_heimdall_master_out(); out.position = (920, 200)
    for m in (sq, lfo, flt, ph, drv, out):
        p.add_module(m)
    _connect(p, lfo.id, "cv_out", sq.id, "gain")
    _connect(p, sq.id, "audio_out", flt.id, "audio_in")
    _connect(p, flt.id, "audio_out", ph.id, "audio_in")
    _connect(p, ph.id, "audio_out", drv.id, "audio_in")
    _connect(p, drv.id, "audio_out", out.id, "audio_in_l")
    _connect(p, drv.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_acid_303():
    """Acid-303 — Saw + LP+Resonance + ADSR-Cutoff + Fuzz.

    TB-303-Stil mit ADSR-modulierter Filter-Cutoff (klassisch acid-squelch),
    + Fuzz für die Hardcore-Aggression. 303-Pattern ist musikalisch oft
    repetitiv, deshalb hier 16th-Triggering via PulseGate.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_saw_osc, make_freyr_adsr, make_tyr_pulse_gate,
        make_forseti_lowpass, make_thor_fuzz,
        make_heimdall_master_out,
    )
    p = Patch(name="Acid-303")
    osc = make_bragi_saw_osc(); osc.position = (260, 200)
    _set(osc, freq=110.0, gain=0.5)
    env = make_freyr_adsr(); env.position = (60, 320)
    _set(env, attack=0.001, decay=0.18, sustain=0.0, release=0.1)
    gate = make_tyr_pulse_gate(); gate.position = (60, 200)
    _set(gate, rate=8.0, pulse_width=0.4)
    flt = make_forseti_lowpass(); flt.position = (480, 200)
    _set(flt, cutoff=600.0, resonance=0.95)
    fuzz = make_thor_fuzz(); fuzz.position = (700, 200)
    _set(fuzz, gain=4.0, bias=0.0, mix=0.7)
    out = make_heimdall_master_out(); out.position = (920, 200)
    for m in (osc, env, gate, flt, fuzz, out):
        p.add_module(m)
    _connect(p, gate.id, "gate_out", env.id, "gate")
    _connect(p, env.id, "cv_out", flt.id, "cutoff")
    _connect(p, osc.id, "audio_out", flt.id, "audio_in")
    _connect(p, flt.id, "audio_out", fuzz.id, "audio_in")
    _connect(p, fuzz.id, "audio_out", out.id, "audio_in_l")
    _connect(p, fuzz.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_mentasm_stab():
    """Mentasm-Stab — Saw L + Saw R (detuned) + Phaser + TubeDrive + Limiter.

    Der „Second Phase / Mentasm"-Stab. FLUX hat keinen Mixer, deshalb echte
    Stereo-Aufteilung: saw1 (440 Hz) → linker Kanal mit FX-Kette, saw2
    (445 Hz, leicht detuned) → rechter Kanal. Das gibt den breit-schwebenden
    Mentasm-Charakter weil L und R minimal unterschiedlich sind.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_saw_osc, make_skadi_phaser,
        make_thor_tube_drive, make_vidar_limiter,
        make_heimdall_master_out,
    )
    p = Patch(name="Mentasm-Stab")
    saw1 = make_bragi_saw_osc(); saw1.position = (60, 140)
    _set(saw1, freq=440.0, gain=0.45)
    saw2 = make_bragi_saw_osc(); saw2.position = (60, 320)
    _set(saw2, freq=445.0, gain=0.45)  # Detune

    # L-Kette
    ph_l = make_skadi_phaser(); ph_l.position = (260, 140)
    _set(ph_l, rate=0.6, depth=0.8, mix=0.7)
    drv_l = make_thor_tube_drive(); drv_l.position = (480, 140)
    _set(drv_l, drive=12.0, tone=0.5, mix=0.85)
    lim_l = make_vidar_limiter(); lim_l.position = (700, 140)
    _set(lim_l, ceiling=-1.0, release_ms=15.0)

    # R-Kette
    ph_r = make_skadi_phaser(); ph_r.position = (260, 320)
    _set(ph_r, rate=0.55, depth=0.8, mix=0.7)
    drv_r = make_thor_tube_drive(); drv_r.position = (480, 320)
    _set(drv_r, drive=12.0, tone=0.5, mix=0.85)
    lim_r = make_vidar_limiter(); lim_r.position = (700, 320)
    _set(lim_r, ceiling=-1.0, release_ms=15.0)

    out = make_heimdall_master_out(); out.position = (920, 200)
    for m in (saw1, saw2, ph_l, drv_l, lim_l, ph_r, drv_r, lim_r, out):
        p.add_module(m)
    _connect(p, saw1.id, "audio_out", ph_l.id, "audio_in")
    _connect(p, ph_l.id, "audio_out", drv_l.id, "audio_in")
    _connect(p, drv_l.id, "audio_out", lim_l.id, "audio_in")
    _connect(p, lim_l.id, "audio_out", out.id, "audio_in_l")
    _connect(p, saw2.id, "audio_out", ph_r.id, "audio_in")
    _connect(p, ph_r.id, "audio_out", drv_r.id, "audio_in")
    _connect(p, drv_r.id, "audio_out", lim_r.id, "audio_in")
    _connect(p, lim_r.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_industrial_hit():
    """Industrial-Hit — NoiseOsc + Bandpass + BitCrush + Reverb.

    Kalter metallischer Industrial-Schlag. Noise + schmaler Bandpass
    erzeugt Resonanz-„Klong", BitCrush (4 Bit) reduziert auf
    Lo-Fi-8-Bit-Charakter, Reverb gibt Hallenraum.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_noise_osc, make_freyr_adsr, make_tyr_pulse_gate,
        make_forseti_bandpass, make_fenrir_bit_crush, make_iduna_reverb,
        make_heimdall_master_out,
    )
    p = Patch(name="Industrial-Hit")
    noise = make_bragi_noise_osc(); noise.position = (260, 200)
    _set(noise, gain=0.0)
    env = make_freyr_adsr(); env.position = (60, 320)
    _set(env, attack=0.002, decay=0.25, sustain=0.0, release=0.05)
    gate = make_tyr_pulse_gate(); gate.position = (60, 200)
    _set(gate, rate=1.5, pulse_width=0.05)
    bp = make_forseti_bandpass(); bp.position = (480, 200)
    _set(bp, cutoff=900.0, resonance=4.0)
    bc = make_fenrir_bit_crush(); bc.position = (700, 200)
    _set(bc, bits=4.0, mix=0.85)
    rev = make_iduna_reverb(); rev.position = (920, 200)
    _set(rev, room_size=0.7, damping=0.3, mix=0.4)
    out = make_heimdall_master_out(); out.position = (1140, 200)
    for m in (noise, env, gate, bp, bc, rev, out):
        p.add_module(m)
    _connect(p, gate.id, "gate_out", env.id, "gate")
    _connect(p, env.id, "cv_out", noise.id, "gain")
    _connect(p, noise.id, "audio_out", bp.id, "audio_in")
    _connect(p, bp.id, "audio_out", bc.id, "audio_in")
    _connect(p, bc.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_berserker_lead():
    """Berserker-Lead — Saw + Decimator + Fuzz + Phaser + Limiter.

    Brutal-fies aggressiv. Decimator zerstört das Saw mit Sample-Rate-
    Reduktion (klingt wie alter Sampler), Fuzz übersteuert massiv,
    Phaser bewegt das Ganze, Limiter fängt die Peaks ab.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_saw_osc, make_fenrir_decimator, make_thor_fuzz,
        make_skadi_phaser, make_vidar_limiter,
        make_heimdall_master_out,
    )
    p = Patch(name="Berserker-Lead")
    osc = make_bragi_saw_osc(); osc.position = (60, 200)
    _set(osc, freq=330.0, gain=0.5)
    dec = make_fenrir_decimator(); dec.position = (260, 200)
    _set(dec, mix=0.9)
    fuzz = make_thor_fuzz(); fuzz.position = (480, 200)
    _set(fuzz, gain=10.0, bias=0.15, mix=0.8)
    ph = make_skadi_phaser(); ph.position = (700, 200)
    _set(ph, rate=0.8, depth=0.6, mix=0.5)
    lim = make_vidar_limiter(); lim.position = (920, 200)
    _set(lim, ceiling=-1.5, release_ms=10.0)
    out = make_heimdall_master_out(); out.position = (1140, 200)
    for m in (osc, dec, fuzz, ph, lim, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", dec.id, "audio_in")
    _connect(p, dec.id, "audio_out", fuzz.id, "audio_in")
    _connect(p, fuzz.id, "audio_out", ph.id, "audio_in")
    _connect(p, ph.id, "audio_out", lim.id, "audio_in")
    _connect(p, lim.id, "audio_out", out.id, "audio_in_l")
    _connect(p, lim.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_reverse_crash():
    """Reverse-Crash — NoiseOsc + LFO-Sweep + Reverb + Fuzz.

    Klassischer Riser/Crash-Effekt: Noise wird über LFO-Modulation per
    Bandpass „aufgewischt", Reverb gibt Räumlichkeit, Fuzz aggressiv.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_noise_osc, make_loki_lfo_triangle,
        make_forseti_bandpass, make_iduna_reverb, make_thor_fuzz,
        make_heimdall_master_out,
    )
    p = Patch(name="Reverse-Crash")
    noise = make_bragi_noise_osc(); noise.position = (260, 200)
    _set(noise, gain=0.5)
    lfo = make_loki_lfo_triangle(); lfo.position = (60, 60)
    _set(lfo, rate=0.3, depth=0.9)
    bp = make_forseti_bandpass(); bp.position = (480, 200)
    _set(bp, cutoff=3000.0, resonance=2.5)
    rev = make_iduna_reverb(); rev.position = (700, 200)
    _set(rev, room_size=0.85, damping=0.2, mix=0.55)
    fuzz = make_thor_fuzz(); fuzz.position = (920, 200)
    _set(fuzz, gain=5.0, bias=0.1, mix=0.6)
    out = make_heimdall_master_out(); out.position = (1140, 200)
    for m in (noise, lfo, bp, rev, fuzz, out):
        p.add_module(m)
    _connect(p, lfo.id, "cv_out", bp.id, "cutoff")
    _connect(p, noise.id, "audio_out", bp.id, "audio_in")
    _connect(p, bp.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", fuzz.id, "audio_in")
    _connect(p, fuzz.id, "audio_out", out.id, "audio_in_l")
    _connect(p, fuzz.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_hardcore_stab():
    """Hardcore-Stab — Square + LFO-PWM + TubeDrive + Decimator.

    Kurzer aggressiver Stab. Square mit LFO auf Pulsweite, TubeDrive
    übersteuert, Decimator gibt zusätzlichen rauen Charakter.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_square_osc, make_loki_lfo_sine,
        make_thor_tube_drive, make_fenrir_decimator,
        make_heimdall_master_out,
    )
    p = Patch(name="Hardcore-Stab")
    osc = make_bragi_square_osc(); osc.position = (60, 200)
    _set(osc, freq=180.0, gain=0.5)
    lfo = make_loki_lfo_sine(); lfo.position = (60, 60)
    _set(lfo, rate=6.0, depth=0.4)
    drv = make_thor_tube_drive(); drv.position = (260, 200)
    _set(drv, drive=11.0, tone=0.4, mix=0.9)
    dec = make_fenrir_decimator(); dec.position = (480, 200)
    _set(dec, mix=0.75)
    out = make_heimdall_master_out(); out.position = (700, 200)
    for m in (osc, lfo, drv, dec, out):
        p.add_module(m)
    _connect(p, lfo.id, "cv_out", osc.id, "gain")
    _connect(p, osc.id, "audio_out", drv.id, "audio_in")
    _connect(p, drv.id, "audio_out", dec.id, "audio_in")
    _connect(p, dec.id, "audio_out", out.id, "audio_in_l")
    _connect(p, dec.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_sub_detonation():
    """Sub-Detonation — SineOsc(40Hz) L + SawOsc(80Hz) R + TubeDrive + Compressor.

    Ultra-tiefer Sub-Bass mit Oktav-Saw-Layer für Obertöne. FLUX hat keinen
    Mixer, daher Stereo-Split: Sine auf L (clean Sub mit moderater Drive),
    Saw auf R durch eigene stärkere Drive+Comp-Kette (Obertöne-Layer).
    Beim Hören ergibt sich ein breiter dröhnender Bass — Sub mittig
    dominiert, Saw fügt Schärfe.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_sine_osc, make_bragi_saw_osc,
        make_thor_tube_drive, make_vidar_compressor,
        make_heimdall_master_out,
    )
    p = Patch(name="Sub-Detonation")
    sub = make_bragi_sine_osc(); sub.position = (60, 140)
    _set(sub, freq=40.0, gain=0.7)
    saw = make_bragi_saw_osc(); saw.position = (60, 320)
    _set(saw, freq=80.0, gain=0.4)

    # L: Sine Sub mit moderater Drive + heavy Comp
    drv_l = make_thor_tube_drive(); drv_l.position = (260, 140)
    _set(drv_l, drive=4.0, tone=0.3, mix=0.6)
    comp_l = make_vidar_compressor(); comp_l.position = (480, 140)
    _set(comp_l, threshold=-18.0, ratio=8.0, attack_ms=2.0,
         release_ms=80.0, makeup=8.0)

    # R: Saw mit stärkerer Drive
    drv_r = make_thor_tube_drive(); drv_r.position = (260, 320)
    _set(drv_r, drive=8.0, tone=0.45, mix=0.8)
    comp_r = make_vidar_compressor(); comp_r.position = (480, 320)
    _set(comp_r, threshold=-15.0, ratio=6.0, attack_ms=2.0,
         release_ms=80.0, makeup=6.0)

    out = make_heimdall_master_out(); out.position = (700, 200)
    for m in (sub, saw, drv_l, comp_l, drv_r, comp_r, out):
        p.add_module(m)
    _connect(p, sub.id, "audio_out", drv_l.id, "audio_in")
    _connect(p, drv_l.id, "audio_out", comp_l.id, "audio_in")
    _connect(p, comp_l.id, "audio_out", out.id, "audio_in_l")
    _connect(p, saw.id, "audio_out", drv_r.id, "audio_in")
    _connect(p, drv_r.id, "audio_out", comp_r.id, "audio_in")
    _connect(p, comp_r.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_screech_lead():
    """Screech-Lead — Square + Highpass + Fuzz + WaveShaper.

    Schreiend hochfrequenter Lead. Square wird oben durch Highpass
    von allem unter 800 Hz befreit, dann zwei Verzerrungs-Stufen
    (Fuzz + WaveShaper) für maximales Kreischen.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_square_osc, make_forseti_highpass,
        make_thor_fuzz, make_thor_wave_shaper,
        make_heimdall_master_out,
    )
    p = Patch(name="Screech-Lead")
    osc = make_bragi_square_osc(); osc.position = (60, 200)
    _set(osc, freq=880.0, gain=0.4)
    hp = make_forseti_highpass(); hp.position = (260, 200)
    _set(hp, cutoff=800.0, resonance=0.5)
    fuzz = make_thor_fuzz(); fuzz.position = (480, 200)
    _set(fuzz, gain=12.0, bias=0.25, mix=0.9)
    ws = make_thor_wave_shaper(); ws.position = (700, 200)
    _set(ws)
    out = make_heimdall_master_out(); out.position = (920, 200)
    for m in (osc, hp, fuzz, ws, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", hp.id, "audio_in")
    _connect(p, hp.id, "audio_out", fuzz.id, "audio_in")
    _connect(p, fuzz.id, "audio_out", ws.id, "audio_in")
    _connect(p, ws.id, "audio_out", out.id, "audio_in_l")
    _connect(p, ws.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_thunder_pad():
    """Thunder-Pad — Saw + Lowpass + Chorus + Phaser + Compressor.

    Massive verzerrte Pad-Wand. FLUX hat keinen Mixer, deshalb single-source
    statt 3-Saw-Stack. Chorus + Phaser + Lowpass-Resonanz erzeugen genug
    Bewegung und Breite — die Detune-Stack-Charakteristik geht zwar
    verloren, aber das Pad klingt trotzdem voll und atmosphärisch.
    Compressor klebt alles zusammen.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_saw_osc, make_skadi_chorus, make_skadi_phaser,
        make_vidar_compressor, make_forseti_lowpass,
        make_heimdall_master_out,
    )
    p = Patch(name="Thunder-Pad")
    saw = make_bragi_saw_osc(); saw.position = (60, 200)
    _set(saw, freq=110.0, gain=0.5)
    flt = make_forseti_lowpass(); flt.position = (260, 200)
    _set(flt, cutoff=2000.0, resonance=0.4)
    ch = make_skadi_chorus(); ch.position = (480, 200)
    _set(ch, rate=0.4, depth=0.7, mix=0.6)
    ph = make_skadi_phaser(); ph.position = (700, 200)
    _set(ph, rate=0.25, depth=0.6, mix=0.5)
    comp = make_vidar_compressor(); comp.position = (920, 200)
    _set(comp, threshold=-12.0, ratio=4.0, attack_ms=8.0,
         release_ms=120.0, makeup=3.0)
    out = make_heimdall_master_out(); out.position = (1140, 200)
    for m in (saw, flt, ch, ph, comp, out):
        p.add_module(m)
    _connect(p, saw.id, "audio_out", flt.id, "audio_in")
    _connect(p, flt.id, "audio_out", ch.id, "audio_in")
    _connect(p, ch.id, "audio_out", ph.id, "audio_in")
    _connect(p, ph.id, "audio_out", comp.id, "audio_in")
    _connect(p, comp.id, "audio_out", out.id, "audio_in_l")
    _connect(p, comp.id, "audio_out", out.id, "audio_in_r")
    return p


# ─── Lazy Preset-Liste (entspricht Sacred/Bach/Ambient/Synthwave) ──


_THUNDERDOME_PRESETS_SPEC = [
    ("Gabber-Kick",     _build_gabber_kick,     "Saw + TubeDrive + Fuzz + Limiter (Rotterdam-Stil)", []),
    ("Distorted-Bass",  _build_distorted_bass,  "Resonant LP + TubeDrive + WaveShaper",              []),
    ("Hoover-Lead",     _build_hoover_lead,     "Saw+Square Stack + LFO-PWM + Phaser",               []),
    ("Acid-303",        _build_acid_303,        "ADSR-modulierte Filter-Cutoff + Fuzz",              []),
    ("Mentasm-Stab",    _build_mentasm_stab,    "Detune-Saws + Phaser + harter Limiter",             []),
    ("Industrial-Hit",  _build_industrial_hit,  "Bandpass-Resonanz + BitCrush + Hall",               []),
    ("Berserker-Lead",  _build_berserker_lead,  "Decimator + Fuzz + Phaser + Limiter",               []),
    ("Reverse-Crash",   _build_reverse_crash,   "LFO-Sweep über Bandpass + Reverb",                  []),
    ("Hardcore-Stab",   _build_hardcore_stab,   "Square+LFO-PWM + TubeDrive + Decimator",            []),
    ("Sub-Detonation",  _build_sub_detonation,  "Sine 40 Hz + Saw 80 Hz + Compressor (8:1)",         []),
    ("Screech-Lead",    _build_screech_lead,    "Square + HP + Fuzz + WaveShaper (kreischend)",      []),
    ("Thunder-Pad",     _build_thunder_pad,     "3-Saw Detune-Stack + Chorus + Phaser + Comp",       []),
]


def _build_all() -> list[dict]:
    result: list[dict] = []
    for name, builder, desc, tags in _THUNDERDOME_PRESETS_SPEC:
        d = _build_patch_dict(name, builder)
        if d is None:
            continue
        result.append({
            "name": name,
            "description": desc,
            "author": THUNDERDOME_FACTORY_AUTHOR,
            "patch": d,
            "tags": tags,
            "bpm": 180,
            "musical_key": "",
            "icon_svg": "",
        })
    return result


class _LazyPresetList:
    def __init__(self):
        self._cache: Optional[list[dict]] = None

    def _ensure(self) -> list[dict]:
        if self._cache is None:
            self._cache = _build_all()
            logger.info(
                "[ThunderdomePresets-v1] built %d Thunderdome presets (%s) lazily",
                len(self._cache), THUNDERDOME_FACTORY_VERSION,
            )
        return self._cache

    def __iter__(self):
        return iter(self._ensure())

    def __len__(self):
        return len(self._ensure())

    def __getitem__(self, i):
        return self._ensure()[i]


THUNDERDOME_PRESETS = _LazyPresetList()


__all__ = [
    "THUNDERDOME_PRESETS",
    "THUNDERDOME_FACTORY_VERSION",
    "THUNDERDOME_FACTORY_AUTHOR",
]
