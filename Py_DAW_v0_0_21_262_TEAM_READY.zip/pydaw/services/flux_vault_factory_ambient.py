"""
pydaw.services.flux_vault_factory_ambient — V-2 Ambient-Style Factory-Presets

**v0.0.21.201 — Ambient v1 (Atmosphäre-Edition)**
=================================================

Erste Iteration der Ambient-Style-Presets nach dem **Sacred-v2-
Charakter-Modul-Schema** aus v0.0.21.199:

> Jeder Preset bekommt ein einzigartiges Charakter-Modul, das ihn
> unverwechselbar macht.

Anders als Sacred und Bach DARF Ambient reverb-dominiert sein — das
ist Teil des Stils. Die 12 Ambient-Presets unterscheiden sich aber
durch unterschiedliche Quellen (Noise, Sine, Triangle), unter-
schiedliche Modulationsgrade (LFO-Cutoff vs LFO-Gain vs S&H), und
verschiedene Charakter-FX (Phaser, Chorus, Decimator, Delay).

| Preset           | Charakter-Modul                  | Klang-Identität |
|------------------|----------------------------------|-----------------|
| Mist             | Pink-ish Noise + LP + sanfter Phaser | dunstig wabernd |
| Aurora           | Triangle + LFO→Cutoff + StereoImager | tanzende Polarlichter |
| Glacier          | Sine bass + tiefer LP + Phaser + Max-Reverb | eisig kalt |
| Whisper          | Triangle L + Noise R + HP-Filter | flüstern auf Augenhöhe |
| Cathedral-Ice    | Sine + StereoImager-Wide + Phaser + Max-Reverb | kalt-kathedral |
| Solar-Wind       | Noise + Bandpass + LFO→Phaser | strömender Solarwind |
| Underwater       | Sine + LP-HARD + Chorus + Decimator | gedämpft unterwasser |
| Nightfall        | Sine bass L + Triangle R + Tilt(-) + huge Reverb | abends dämmernd |
| Dust             | Triangle + S&H-LFO + BitCrush(subtil) | körnig staubig |
| Memory           | Sine + Long-Delay + Tilt(-) + Reverb | verschwommene Erinnerung |
| Weightless       | Sine + LFO-Vibrato + deep Chorus + Imager + Max-Reverb | schwerelos |
| Cosmos           | Stereo Sine bass L + Triangle high R + Phaser + Imager + Max | kosmisch weit |

Versions-Marker ``"FLUX Factory (Ambient v1)"`` für sauberes Re-Seeding.
"""

from __future__ import annotations

import logging
from typing import Optional

logger = logging.getLogger(__name__)


AMBIENT_FACTORY_VERSION = "v1"
AMBIENT_FACTORY_AUTHOR = f"FLUX Factory (Ambient {AMBIENT_FACTORY_VERSION})"


# ─── Helper ───────────────────────────────────────────────────────


def _connect(patch, src_id: str, src_port: str,
             tgt_id: str, tgt_port: str) -> bool:
    """Helper: Connection hinzufügen, defensiv gegen fehlende Module."""
    from pydaw.flux.patch_model import Connection
    src = patch.get_module(src_id)
    tgt = patch.get_module(tgt_id)
    if src is None or tgt is None:
        return False
    return patch.add_connection(Connection(
        source_module=src_id, source_port=src_port,
        target_module=tgt_id, target_port=tgt_port,
    ))


def _set(module, **params) -> None:
    """Helper: Module-Params setzen (defensiv gegen fehlende Keys)."""
    if module is None:
        return
    for k, v in params.items():
        if k in module.params:
            module.params[k] = v


def _build_patch_dict(name: str, builder) -> Optional[dict]:
    """Wrappt einen Patch-Builder in to_dict, defensiv gegen Fehler."""
    try:
        from pydaw.flux.patch_model import Patch
        p = builder()
        if not isinstance(p, Patch):
            return None
        p.name = name
        return p.to_dict()
    except Exception as e:
        logger.warning("[AmbientPresets-v1] build %s failed: %s", name, e)
        return None


# ─── Patch-Builder pro Variant (Ambient v1) ───────────────────────


def _build_mist():
    """Mist — Noise + Lowpass + sanfter Skadi.Phaser (dunstig wabernd).

    Charakter: weißes Rauschen tief gefiltert + Phaser-Bewegung
    erzeugt einen dunstigen, undefinierten Grundton.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_noise_osc, make_forseti_lowpass,
        make_skadi_phaser, make_iduna_reverb,
        make_heimdall_master_out,
    )
    p = Patch(name="Mist")
    osc = make_bragi_noise_osc(); osc.position = (60, 200)
    _set(osc, gain=0.25)
    flt = make_forseti_lowpass(); flt.position = (260, 200)
    _set(flt, cutoff=420.0, resonance=0.4)  # tief — Pink-ish
    phaser = make_skadi_phaser(); phaser.position = (460, 200)
    _set(phaser, rate=0.12, depth=0.5, feedback=0.35, mix=0.5)
    rev = make_iduna_reverb(); rev.position = (660, 200)
    _set(rev, room_size=0.85, damping=0.55, mix=0.55)
    out = make_heimdall_master_out(); out.position = (860, 200)
    for m in (osc, flt, phaser, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", flt.id, "audio_in")
    _connect(p, flt.id, "audio_out", phaser.id, "audio_in")
    _connect(p, phaser.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_aurora():
    """Aurora — Triangle + LFO→Cutoff + StereoImager (tanzende Polarlichter).

    Charakter: starker LFO an Filter-Cutoff erzeugt das tanzende
    Auf- und Ab-Schweben des Aurora-Boreale-Vorhangs. Wide-Stereo.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_triangle_osc, make_loki_lfo_sine,
        make_forseti_lowpass, make_skadi_stereo_imager,
        make_iduna_reverb, make_heimdall_master_out,
    )
    p = Patch(name="Aurora")
    osc = make_bragi_triangle_osc(); osc.position = (80, 200)
    _set(osc, freq=261.63, gain=0.4)
    lfo = make_loki_lfo_sine(); lfo.position = (80, 60)
    _set(lfo, rate=0.22, depth=2.5)  # langsam und stark — Aurora-Schweben
    flt = make_forseti_lowpass(); flt.position = (300, 200)
    _set(flt, cutoff=1500.0, resonance=0.6)
    imager = make_skadi_stereo_imager(); imager.position = (500, 200)
    _set(imager, width=1.8, mix=1.0)
    rev = make_iduna_reverb(); rev.position = (700, 200)
    _set(rev, room_size=0.85, damping=0.4, mix=0.5)
    out = make_heimdall_master_out(); out.position = (900, 200)
    for m in (osc, lfo, flt, imager, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", flt.id, "audio_in")
    _connect(p, flt.id, "audio_out", imager.id, "audio_in")
    _connect(p, imager.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    # LFO → Cutoff (das schwebende Aurora-Atmen)
    _connect(p, lfo.id, "cv_out", flt.id, "cutoff")
    return p


def _build_glacier():
    """Glacier — Sine bass + tiefer LP + Skadi.Phaser + Max-Reverb (eisig kalt).

    Charakter: sehr tiefer Bass mit langsamem Phaser und maximal-
    weitem Reverb — eisige Kälte einer Gletscherwelt.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_sine_osc, make_forseti_lowpass,
        make_skadi_phaser, make_iduna_reverb,
        make_heimdall_master_out,
    )
    p = Patch(name="Glacier")
    osc = make_bragi_sine_osc(); osc.position = (60, 200)
    _set(osc, freq=87.31, gain=0.45)  # F2 — tiefer Bass
    flt = make_forseti_lowpass(); flt.position = (260, 200)
    _set(flt, cutoff=520.0, resonance=0.3)  # sehr tief
    phaser = make_skadi_phaser(); phaser.position = (460, 200)
    _set(phaser, rate=0.08, depth=0.85, feedback=0.55, mix=0.6)  # sehr langsam
    rev = make_iduna_reverb(); rev.position = (660, 200)
    _set(rev, room_size=0.95, damping=0.25, mix=0.6)  # MAX — eisige Weite
    out = make_heimdall_master_out(); out.position = (860, 200)
    for m in (osc, flt, phaser, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", flt.id, "audio_in")
    _connect(p, flt.id, "audio_out", phaser.id, "audio_in")
    _connect(p, phaser.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_whisper():
    """Whisper — Triangle L + Noise R + Highpass-Filter (flüstern intim).

    Charakter: leise Triangle plus gefiltertes Rauschen erzeugen
    das Hauchen eines Geflüsters direkt am Ohr.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_triangle_osc, make_bragi_noise_osc,
        make_forseti_highpass, make_forseti_lowpass,
        make_iduna_reverb, make_heimdall_master_out,
    )
    p = Patch(name="Whisper")
    # L: leise Triangle als Ton
    osc_l = make_bragi_triangle_osc(); osc_l.position = (60, 100)
    _set(osc_l, freq=329.63, gain=0.20)  # E4 leise
    flt_l = make_forseti_lowpass(); flt_l.position = (260, 100)
    _set(flt_l, cutoff=2000.0, resonance=0.2)
    rev_l = make_iduna_reverb(); rev_l.position = (460, 100)
    _set(rev_l, room_size=0.55, damping=0.6, mix=0.4)  # nahe Mikrofon-Atmo
    # R: Hauch — Noise mit Highpass
    osc_r = make_bragi_noise_osc(); osc_r.position = (60, 280)
    _set(osc_r, gain=0.12)  # sehr leise
    hp_r = make_forseti_highpass(); hp_r.position = (260, 280)
    _set(hp_r, cutoff=3000.0)  # nur Höhen — Hauch
    rev_r = make_iduna_reverb(); rev_r.position = (460, 280)
    _set(rev_r, room_size=0.55, damping=0.6, mix=0.4)
    out = make_heimdall_master_out(); out.position = (680, 190)
    for m in (osc_l, flt_l, rev_l, osc_r, hp_r, rev_r, out):
        p.add_module(m)
    _connect(p, osc_l.id, "audio_out", flt_l.id, "audio_in")
    _connect(p, flt_l.id, "audio_out", rev_l.id, "audio_in")
    _connect(p, rev_l.id, "audio_out", out.id, "audio_in_l")
    _connect(p, osc_r.id, "audio_out", hp_r.id, "audio_in")
    _connect(p, hp_r.id, "audio_out", rev_r.id, "audio_in")
    _connect(p, rev_r.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_cathedral_ice():
    """Cathedral-Ice — Sine + StereoImager-Wide + Phaser + Max-Reverb (kalt-kathedral).

    Charakter: extreme Stereo-Breite + langer Reverb + langsamer
    Phaser geben den Eindruck einer eis-kalten Kathedrale.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_sine_osc, make_forseti_lowpass,
        make_skadi_phaser, make_skadi_stereo_imager,
        make_iduna_reverb, make_heimdall_master_out,
    )
    p = Patch(name="Cathedral-Ice")
    osc = make_bragi_sine_osc(); osc.position = (60, 200)
    _set(osc, freq=146.83, gain=0.4)  # D3
    flt = make_forseti_lowpass(); flt.position = (260, 200)
    _set(flt, cutoff=1800.0, resonance=0.15)
    phaser = make_skadi_phaser(); phaser.position = (460, 200)
    _set(phaser, rate=0.1, depth=0.7, feedback=0.4, mix=0.55)
    imager = make_skadi_stereo_imager(); imager.position = (660, 200)
    _set(imager, width=2.0, mix=1.0)  # MAX-Breite
    rev = make_iduna_reverb(); rev.position = (860, 200)
    _set(rev, room_size=0.97, damping=0.18, mix=0.65)  # MAX
    out = make_heimdall_master_out(); out.position = (1060, 200)
    for m in (osc, flt, phaser, imager, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", flt.id, "audio_in")
    _connect(p, flt.id, "audio_out", phaser.id, "audio_in")
    _connect(p, phaser.id, "audio_out", imager.id, "audio_in")
    _connect(p, imager.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_solar_wind():
    """Solar-Wind — Noise + Bandpass + LFO→Phaser-rate (strömend).

    Charakter: gefiltertes Rauschen mit Phaser, dessen Rate vom LFO
    moduliert wird — das gibt das pulsierende Strömen des Sonnenwinds.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_noise_osc, make_loki_lfo_sine,
        make_forseti_bandpass, make_skadi_phaser,
        make_iduna_reverb, make_heimdall_master_out,
    )
    p = Patch(name="Solar-Wind")
    osc = make_bragi_noise_osc(); osc.position = (80, 200)
    _set(osc, gain=0.3)
    lfo = make_loki_lfo_sine(); lfo.position = (80, 60)
    _set(lfo, rate=0.18, depth=2.0)  # langsam pulsierend
    flt = make_forseti_bandpass(); flt.position = (300, 200)
    _set(flt, cutoff=1200.0, resonance=1.5)
    phaser = make_skadi_phaser(); phaser.position = (500, 200)
    _set(phaser, rate=0.4, depth=0.7, feedback=0.5, mix=0.6)
    rev = make_iduna_reverb(); rev.position = (700, 200)
    _set(rev, room_size=0.85, damping=0.4, mix=0.5)
    out = make_heimdall_master_out(); out.position = (900, 200)
    for m in (osc, lfo, flt, phaser, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", flt.id, "audio_in")
    _connect(p, flt.id, "audio_out", phaser.id, "audio_in")
    _connect(p, phaser.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    # LFO → Phaser-Rate — pulsierende Strömung
    _connect(p, lfo.id, "cv_out", phaser.id, "rate")
    return p


def _build_underwater():
    """Underwater — Sine + LP-HARD + Skadi.Chorus + Fenrir.Decimator (gedämpft).

    Charakter: alles wirkt durch Wasser gedämpft (LP HARD), Chorus
    gibt unterwasser-ähnliche Wellenbewegung, Decimator slight
    erzeugt das blubbernde Aliasing.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_sine_osc, make_forseti_lowpass,
        make_skadi_chorus, make_fenrir_decimator,
        make_iduna_reverb, make_heimdall_master_out,
    )
    p = Patch(name="Underwater")
    osc = make_bragi_sine_osc(); osc.position = (60, 200)
    _set(osc, freq=174.61, gain=0.5)  # F3
    flt = make_forseti_lowpass(); flt.position = (260, 200)
    _set(flt, cutoff=600.0, resonance=0.6)  # HARD — Wasser-Dämpfung
    chorus = make_skadi_chorus(); chorus.position = (460, 200)
    _set(chorus, rate=0.35, depth=0.8, mix=0.65)  # tief — Wellenbewegung
    deci = make_fenrir_decimator(); deci.position = (660, 200)
    _set(deci, target_sr=14000.0, mix=0.35)  # slight Aliasing
    rev = make_iduna_reverb(); rev.position = (860, 200)
    _set(rev, room_size=0.7, damping=0.7, mix=0.45)  # gedämpft
    out = make_heimdall_master_out(); out.position = (1060, 200)
    for m in (osc, flt, chorus, deci, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", flt.id, "audio_in")
    _connect(p, flt.id, "audio_out", chorus.id, "audio_in")
    _connect(p, chorus.id, "audio_out", deci.id, "audio_in")
    _connect(p, deci.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_nightfall():
    """Nightfall — Sine bass L + Triangle R + Tilt(-) + huge Reverb (Dämmerung).

    Charakter: tiefer Bass mit hellem Oberton, Tilt nach unten gekippt
    für die warm-dunkle Abendstimmung. Stereo-Aufteilung der Stimmen.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_sine_osc, make_bragi_triangle_osc,
        make_forseti_tilt, make_iduna_reverb,
        make_heimdall_master_out,
    )
    p = Patch(name="Nightfall")
    # L: Bass D2
    osc_l = make_bragi_sine_osc(); osc_l.position = (60, 100)
    _set(osc_l, freq=73.42, gain=0.4)  # D2
    tilt_l = make_forseti_tilt(); tilt_l.position = (260, 100)
    _set(tilt_l, tilt=-0.4)  # warm-dunkel
    rev_l = make_iduna_reverb(); rev_l.position = (460, 100)
    _set(rev_l, room_size=0.9, damping=0.5, mix=0.55)
    # R: Oberton hell aber Tilt drückt ihn weich
    osc_r = make_bragi_triangle_osc(); osc_r.position = (60, 280)
    _set(osc_r, freq=293.66, gain=0.3)  # D4
    tilt_r = make_forseti_tilt(); tilt_r.position = (260, 280)
    _set(tilt_r, tilt=-0.3)
    rev_r = make_iduna_reverb(); rev_r.position = (460, 280)
    _set(rev_r, room_size=0.9, damping=0.5, mix=0.55)
    out = make_heimdall_master_out(); out.position = (680, 190)
    for m in (osc_l, tilt_l, rev_l, osc_r, tilt_r, rev_r, out):
        p.add_module(m)
    _connect(p, osc_l.id, "audio_out", tilt_l.id, "audio_in")
    _connect(p, tilt_l.id, "audio_out", rev_l.id, "audio_in")
    _connect(p, rev_l.id, "audio_out", out.id, "audio_in_l")
    _connect(p, osc_r.id, "audio_out", tilt_r.id, "audio_in")
    _connect(p, tilt_r.id, "audio_out", rev_r.id, "audio_in")
    _connect(p, rev_r.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_dust():
    """Dust — Triangle + S&H-LFO an gain + BitCrush(subtil) (körnig staubig).

    Charakter: Sample&Hold-LFO an gain erzeugt zufällige Pegelsprünge,
    BitCrush slight zerklirrt die Glätte — wie umherwirbelnder Staub.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_triangle_osc, make_loki_lfo_sample_hold,
        make_fenrir_bit_crush, make_iduna_reverb,
        make_heimdall_master_out,
    )
    p = Patch(name="Dust")
    osc = make_bragi_triangle_osc(); osc.position = (80, 200)
    _set(osc, freq=220.0, gain=0.5)  # A3
    sh = make_loki_lfo_sample_hold(); sh.position = (80, 60)
    _set(sh, rate=4.0, depth=0.25)  # körnig zufällig
    crush = make_fenrir_bit_crush(); crush.position = (300, 200)
    _set(crush, bits=10.0, mix=0.4)  # subtil
    rev = make_iduna_reverb(); rev.position = (520, 200)
    _set(rev, room_size=0.75, damping=0.55, mix=0.45)
    out = make_heimdall_master_out(); out.position = (740, 200)
    for m in (osc, sh, crush, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", crush.id, "audio_in")
    _connect(p, crush.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    # S&H → osc.gain (zufällige Staub-Pegelsprünge)
    _connect(p, sh.id, "cv_out", osc.id, "gain")
    return p


def _build_memory():
    """Memory — Sine + Long-Delay + Tilt(-) + Reverb (verschwommene Erinnerung).

    Charakter: lange Delays mit Feedback erzeugen verschwommene Echos
    wie verblasste Erinnerungen, dazu warmer Tilt nach unten.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_sine_osc, make_iduna_delay,
        make_forseti_tilt, make_iduna_reverb,
        make_heimdall_master_out,
    )
    p = Patch(name="Memory")
    osc = make_bragi_sine_osc(); osc.position = (60, 200)
    _set(osc, freq=196.0, gain=0.4)  # G3
    delay = make_iduna_delay(); delay.position = (260, 200)
    _set(delay, time=1.2, feedback=0.65, mix=0.55, tone=2500.0)  # lang verblassend
    tilt = make_forseti_tilt(); tilt.position = (460, 200)
    _set(tilt, tilt=-0.35)  # warm
    rev = make_iduna_reverb(); rev.position = (660, 200)
    _set(rev, room_size=0.85, damping=0.55, mix=0.5)
    out = make_heimdall_master_out(); out.position = (860, 200)
    for m in (osc, delay, tilt, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", delay.id, "audio_in")
    _connect(p, delay.id, "audio_out", tilt.id, "audio_in")
    _connect(p, tilt.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_weightless():
    """Weightless — Sine + LFO-Vibrato + deep Chorus + Imager + Max-Reverb.

    Charakter: schwerelos fließend — ganz langsame LFO an gain
    (atmend), tief modulierter Chorus, weiter Imager, voller Reverb.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_sine_osc, make_loki_lfo_sine,
        make_skadi_chorus, make_skadi_stereo_imager,
        make_iduna_reverb, make_heimdall_master_out,
    )
    p = Patch(name="Weightless")
    osc = make_bragi_sine_osc(); osc.position = (80, 200)
    _set(osc, freq=261.63, gain=0.45)
    lfo = make_loki_lfo_sine(); lfo.position = (80, 60)
    _set(lfo, rate=0.15, depth=0.15)  # ganz sanftes Atmen
    chorus = make_skadi_chorus(); chorus.position = (300, 200)
    _set(chorus, rate=0.3, depth=0.8, mix=0.65)  # tief
    imager = make_skadi_stereo_imager(); imager.position = (500, 200)
    _set(imager, width=1.7, mix=1.0)
    rev = make_iduna_reverb(); rev.position = (700, 200)
    _set(rev, room_size=0.93, damping=0.3, mix=0.6)  # voll
    out = make_heimdall_master_out(); out.position = (900, 200)
    for m in (osc, lfo, chorus, imager, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", chorus.id, "audio_in")
    _connect(p, chorus.id, "audio_out", imager.id, "audio_in")
    _connect(p, imager.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    # LFO → osc.gain (sanftes Atmen)
    _connect(p, lfo.id, "cv_out", osc.id, "gain")
    return p


def _build_cosmos():
    """Cosmos — Stereo Sine bass L + Triangle high R + Phaser + Imager + Max.

    Charakter: weite Stereo-Aufteilung von Bass + Höhen, jeweils mit
    Phaser-Bewegung und maximaler Reverb. Kosmische Weite.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_sine_osc, make_bragi_triangle_osc,
        make_forseti_lowpass, make_skadi_phaser,
        make_skadi_stereo_imager, make_iduna_reverb,
        make_heimdall_master_out,
    )
    p = Patch(name="Cosmos")
    # L: tief
    osc_l = make_bragi_sine_osc(); osc_l.position = (40, 100)
    _set(osc_l, freq=55.0, gain=0.4)  # A1 sehr tief
    flt_l = make_forseti_lowpass(); flt_l.position = (240, 100)
    _set(flt_l, cutoff=400.0, resonance=0.3)
    phaser_l = make_skadi_phaser(); phaser_l.position = (440, 100)
    _set(phaser_l, rate=0.07, depth=0.8, feedback=0.4, mix=0.55)
    imager_l = make_skadi_stereo_imager(); imager_l.position = (640, 100)
    _set(imager_l, width=1.9, mix=1.0)
    rev_l = make_iduna_reverb(); rev_l.position = (840, 100)
    _set(rev_l, room_size=0.96, damping=0.25, mix=0.6)
    # R: hoch
    osc_r = make_bragi_triangle_osc(); osc_r.position = (40, 280)
    _set(osc_r, freq=659.26, gain=0.25)  # E5
    flt_r = make_forseti_lowpass(); flt_r.position = (240, 280)
    _set(flt_r, cutoff=2000.0, resonance=0.2)
    phaser_r = make_skadi_phaser(); phaser_r.position = (440, 280)
    _set(phaser_r, rate=0.18, depth=0.7, feedback=0.45, mix=0.55)
    imager_r = make_skadi_stereo_imager(); imager_r.position = (640, 280)
    _set(imager_r, width=1.9, mix=1.0)
    rev_r = make_iduna_reverb(); rev_r.position = (840, 280)
    _set(rev_r, room_size=0.96, damping=0.25, mix=0.6)
    out = make_heimdall_master_out(); out.position = (1060, 190)
    for m in (osc_l, flt_l, phaser_l, imager_l, rev_l,
              osc_r, flt_r, phaser_r, imager_r, rev_r, out):
        p.add_module(m)
    _connect(p, osc_l.id, "audio_out", flt_l.id, "audio_in")
    _connect(p, flt_l.id, "audio_out", phaser_l.id, "audio_in")
    _connect(p, phaser_l.id, "audio_out", imager_l.id, "audio_in")
    _connect(p, imager_l.id, "audio_out", rev_l.id, "audio_in")
    _connect(p, rev_l.id, "audio_out", out.id, "audio_in_l")
    _connect(p, osc_r.id, "audio_out", flt_r.id, "audio_in")
    _connect(p, flt_r.id, "audio_out", phaser_r.id, "audio_in")
    _connect(p, phaser_r.id, "audio_out", imager_r.id, "audio_in")
    _connect(p, imager_r.id, "audio_out", rev_r.id, "audio_in")
    _connect(p, rev_r.id, "audio_out", out.id, "audio_in_r")
    return p


# ─── Preset-Liste ─────────────────────────────────────────────────


def _build_all() -> list[dict]:
    """Baut alle 12 Ambient-v1-Patches.  Wird **lazy** beim ersten
    Vault-Import aufgerufen."""
    builders = [
        ("Mist",          "Noise + Lowpass + sanfter Phaser (dunstig wabernd).",
         ["drone", "noise", "phaser", "soft"], "—", _build_mist),
        ("Aurora",        "Triangle + LFO→Cutoff + StereoImager (tanzende Polarlichter).",
         ["pad", "lfo", "wide", "moving"], "C4", _build_aurora),
        ("Glacier",       "Sine bass + LP + Phaser + Max-Reverb (eisig kalt).",
         ["drone", "cold", "bass", "phaser"], "F2", _build_glacier),
        ("Whisper",       "Triangle L + Noise R + HP-Filter (flüstern intim).",
         ["whisper", "noise", "intimate", "stereo"], "E4", _build_whisper),
        ("Cathedral-Ice", "Sine + StereoImager-Wide + Phaser + Max-Reverb (kalt-kathedral).",
         ["pad", "wide", "ice", "huge"], "D3", _build_cathedral_ice),
        ("Solar-Wind",    "Noise + Bandpass + LFO→Phaser-rate (strömend).",
         ["drone", "wind", "noise", "modulated"], "—", _build_solar_wind),
        ("Underwater",    "Sine + LP-HARD + Chorus + Decimator(slight) (gedämpft).",
         ["pad", "muffled", "chorus", "decimator"], "F3", _build_underwater),
        ("Nightfall",     "Sine bass L + Triangle R + Tilt(-) + huge Reverb (Dämmerung).",
         ["pad", "warm", "stereo", "huge"], "D2", _build_nightfall),
        ("Dust",          "Triangle + S&H-LFO + BitCrush(subtil) (körnig staubig).",
         ["pad", "grainy", "sample-hold", "bitcrush"], "A3", _build_dust),
        ("Memory",        "Sine + Long-Delay + Tilt(-) + Reverb (verschwommen).",
         ["pad", "delay", "warm", "fading"], "G3", _build_memory),
        ("Weightless",    "Sine + LFO-Vibrato + deep Chorus + Imager + Max-Reverb.",
         ["pad", "floating", "chorus", "wide"], "C4", _build_weightless),
        ("Cosmos",        "Stereo Sine bass L + Triangle high R + Phaser + Imager + Max.",
         ["pad", "huge", "stereo", "phaser", "wide"], "A1", _build_cosmos),
    ]

    presets = []
    for name, desc, tags, key, builder in builders:
        patch_dict = _build_patch_dict(name, builder)
        if patch_dict is None:
            logger.warning("[AmbientPresets-v1] %s skipped (build failed)", name)
            continue
        presets.append({
            "name": name,
            "description": desc,
            "tags": tags,
            "musical_key": key,
            "bpm": None,
            "author": AMBIENT_FACTORY_AUTHOR,
            "icon_svg": "",
            "patch": patch_dict,
        })
    return presets


class _LazyPresetList:
    """Wrapper: baut die Patches erst beim ersten Iterieren."""

    def __init__(self):
        self._cache: Optional[list[dict]] = None

    def _ensure(self) -> list[dict]:
        if self._cache is None:
            self._cache = _build_all()
            logger.info(
                "[AmbientPresets-v1] built %d Ambient presets (%s) lazily",
                len(self._cache), AMBIENT_FACTORY_VERSION,
            )
        return self._cache

    def __iter__(self):
        return iter(self._ensure())

    def __len__(self):
        return len(self._ensure())

    def __getitem__(self, i):
        return self._ensure()[i]


AMBIENT_PRESETS = _LazyPresetList()


__all__ = [
    "AMBIENT_PRESETS",
    "AMBIENT_FACTORY_VERSION",
    "AMBIENT_FACTORY_AUTHOR",
]
