"""
pydaw.flux.ui_widgets.number_box — Frigg.NumberBox (Phase U-2)
==============================================================

PureData-Style Number-Box: kleines Rechteck mit numerischem Wert.
Drag (vertikal) ändert den Wert wie ein SpinBox-Drag, Doppelklick
öffnet ein Eingabe-Dialog.

Eingebaut in v0.0.21.195.
"""

from __future__ import annotations

import logging
from typing import Optional

logger = logging.getLogger(__name__)


try:
    from PyQt6.QtCore import Qt, QRectF, QSize, pyqtSignal
    from PyQt6.QtGui import QColor, QPainter, QPen, QBrush, QFont
    from PyQt6.QtWidgets import QWidget, QSizePolicy, QInputDialog
    _QT_AVAILABLE = True
except ImportError:
    _QT_AVAILABLE = False


def _clamp(x: float, lo: float, hi: float) -> float:
    if lo > hi:
        lo, hi = hi, lo
    return max(lo, min(hi, x))


def _format_number(v: float) -> str:
    abs_v = abs(v)
    if abs_v >= 1000:
        return f"{v:.0f}"
    if abs_v >= 10:
        return f"{v:.1f}"
    return f"{v:.2f}"


if _QT_AVAILABLE:

    class NumberBoxWidget(QWidget):  # type: ignore[misc]
        """Number-Box: Drag = Wert, Doppelklick = Eingabe-Dialog.

        Signale
        -------
        ``value_changed(float)``
        """

        DRAG_PIXELS_PER_UNIT = 4   # 4 px = 1 Unit (für Range >=10 schneller)
        DEFAULT_HEIGHT = 22

        COL_BG = "#0a0e14"
        COL_BORDER = "#1a1f29"
        COL_TEXT = "#e6edf3"
        COL_TRIANGLE = "#3df0e0"

        value_changed = pyqtSignal(float)

        def __init__(
            self,
            value: float = 0.0,
            minimum: float = -1e6,
            maximum: float = 1e6,
            default: Optional[float] = None,
            parent=None,
        ):
            super().__init__(parent)
            if maximum <= minimum:
                maximum = minimum + 1.0
            self._minimum = float(minimum)
            self._maximum = float(maximum)
            self._default = float(default) if default is not None else float(value)
            self._value = _clamp(float(value), self._minimum, self._maximum)

            self.setMinimumSize(56, self.DEFAULT_HEIGHT)
            self.setMaximumSize(96, self.DEFAULT_HEIGHT + 4)
            self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)

            self._dragging = False
            self._drag_origin_y = 0
            self._drag_origin_value = 0.0
            self.setMouseTracking(True)

        @property
        def value(self) -> float:
            return self._value

        def set_value(self, value: float, *, emit_signal: bool = True) -> None:
            new_v = _clamp(float(value), self._minimum, self._maximum)
            if new_v == self._value:
                return
            self._value = new_v
            if emit_signal:
                self.value_changed.emit(self._value)
            self.update()

        def mousePressEvent(self, event):  # type: ignore[override]
            if event.button() == Qt.MouseButton.LeftButton:
                self._dragging = True
                self._drag_origin_y = event.position().y()
                self._drag_origin_value = self._value
                self.setCursor(Qt.CursorShape.SizeVerCursor)
                event.accept()
            else:
                super().mousePressEvent(event)

        def mouseMoveEvent(self, event):  # type: ignore[override]
            if not self._dragging:
                return
            dy = self._drag_origin_y - event.position().y()
            range_ = self._maximum - self._minimum
            # Skalierung: bei Range >=100, eine Einheit pro Pixel; bei
            # kleiner Range ein Hundertstel pro Pixel
            if range_ >= 1000:
                step = dy
            elif range_ >= 100:
                step = dy * 0.1
            elif range_ >= 10:
                step = dy * 0.01
            else:
                step = dy * 0.001
            if event.modifiers() & Qt.KeyboardModifier.ShiftModifier:
                step *= 0.1
            self.set_value(self._drag_origin_value + step, emit_signal=True)

        def mouseReleaseEvent(self, event):  # type: ignore[override]
            if event.button() == Qt.MouseButton.LeftButton and self._dragging:
                self._dragging = False
                self.unsetCursor()
                event.accept()
            else:
                super().mouseReleaseEvent(event)

        def mouseDoubleClickEvent(self, event):  # type: ignore[override]
            if event.button() == Qt.MouseButton.LeftButton:
                v, ok = QInputDialog.getDouble(
                    self, "Number Box", "Wert:",
                    self._value, self._minimum, self._maximum, 4,
                )
                if ok:
                    self.set_value(v, emit_signal=True)
                event.accept()
            else:
                super().mouseDoubleClickEvent(event)

        def paintEvent(self, event):  # type: ignore[override]
            painter = QPainter(self)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            painter.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)

            w = self.width()
            h = self.height()
            rect = QRectF(0, 0, w, h)

            painter.setBrush(QBrush(QColor(self.COL_BG)))
            painter.setPen(QPen(QColor(self.COL_BORDER), 1.0))
            painter.drawRoundedRect(rect, 2.0, 2.0)

            # PD-Style Triangle-Marker links
            tri_x = 4
            tri_y = h / 2
            painter.setBrush(QBrush(QColor(self.COL_TRIANGLE)))
            painter.setPen(Qt.PenStyle.NoPen)
            from PyQt6.QtGui import QPolygonF
            from PyQt6.QtCore import QPointF
            tri = QPolygonF([
                QPointF(tri_x, tri_y - 4),
                QPointF(tri_x + 5, tri_y),
                QPointF(tri_x, tri_y + 4),
            ])
            painter.drawPolygon(tri)

            # Wert-Text rechts vom Triangle
            painter.setPen(QPen(QColor(self.COL_TEXT)))
            painter.setFont(QFont("monospace", 9))
            text_rect = QRectF(14, 0, w - 18, h)
            painter.drawText(
                text_rect,
                int(Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft),
                _format_number(self._value),
            )

            painter.end()

        def sizeHint(self):  # type: ignore[override]
            return QSize(72, self.DEFAULT_HEIGHT)

else:
    NumberBoxWidget = None  # type: ignore[assignment,misc]


__all__ = ["NumberBoxWidget"]
