"""
pydaw.services.motion_throttle_service — UI-Bewegungs-Drossel
==============================================================

**v0.0.21.203 — A-2 (Reduced-Motion + SENTINEL-FPS-Hook)**

Zentrale Anlaufstelle für *„weniger Bewegung in der UI"*. Drei Quellen
schalten den globalen Throttle ein:

1. **User-Setting** — User-Wahl „Reduced Motion" in den Settings.
   Permanent, vom User explizit gewünscht.
2. **SENTINEL-Hook** — Bei GIL-Starvation ALARM (>100ms Peak) schaltet
   Sentinel den Throttle automatisch ein und nach Erholung wieder aus.
3. **Programmatisch** — andere Services (z.B. Project-Load) können
   temporär drosseln (`set_temp_throttle("project_load", True)`).

Effektiver Throttle = ODER aus allen drei Quellen.

Listener registrieren sich mit ``register_listener(callback)``. Bei
jeder Status-Änderung wird `callback(effective: bool)` aufgerufen.
Aktuell hört der ``SagaRendererProxy`` und kann in Zukunft auch die
``AnimationEngine`` zuhören (Tick-Rate halbieren).

Singleton-Pattern (analog `flux_vault_db`, `preset_database`).

Nichts-Kaputt
-------------

* Pure Python, keine Qt-Abhängigkeit (Listener-Callbacks laufen direkt
  im Calling-Thread — Sentinel-Tick + Settings-Click sind beide UI-
  Thread also OK).
* Wenn der Service nicht initialisiert ist (z.B. Tests), sind alle
  API-Calls No-Ops.
* Bei jeder Throttle-Änderung wird *nur* dann gefeuert, wenn sich der
  effektive Status auch wirklich ändert (kein Spam).
"""
from __future__ import annotations

import logging
import threading
from typing import Callable, Optional

logger = logging.getLogger(__name__)


# Throttle-Listener-Signatur:
#     callback(effective_throttle: bool) -> None
ThrottleListener = Callable[[bool], None]


class MotionThrottleService:
    """Zentraler Throttle-Service. Singleton via ``get_motion_throttle()``."""

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._user_reduced_motion: bool = False
        self._sentinel_throttle: bool = False
        self._temp_throttles: dict[str, bool] = {}
        self._last_effective: bool = False
        self._listeners: list[ThrottleListener] = []
        # v0.0.21.204 (A-3): Auto-Load der User-Wahl aus settings_store.
        # Fail-soft: wenn settings_store nicht verfügbar ist (z.B.
        # Tests oder Standalone), bleibt der Default False.
        self._persist_loaded: bool = False
        self._try_load_persisted()

    # ─── Persistierung (A-3) ────────────────────────────────────

    def _try_load_persisted(self) -> None:
        """Lädt die gespeicherte User-Reduced-Motion-Wahl beim ersten
        Service-Init. Idempotent durch ``_persist_loaded``-Flag.

        Persist-Quelle ist `settings_store` (SQLite-backed via
        `SettingsDatabase`, QSettings-Fallback). Default = False.
        """
        if self._persist_loaded:
            return
        try:
            from pydaw.core.settings import SettingsKeys
            from pydaw.core.settings_store import get_value
            v = get_value(SettingsKeys.ui_reduced_motion, False)
            # SQLite/QSettings können bool als Int oder String returnen
            if isinstance(v, str):
                v = v.lower() in ("true", "1", "yes", "on")
            self._user_reduced_motion = bool(v)
            self._last_effective = self._compute_effective()
            self._persist_loaded = True
            logger.info(
                "[MotionThrottle] persisted user_reduced_motion=%s",
                self._user_reduced_motion,
            )
        except Exception as e:
            logger.debug(
                "[MotionThrottle] persist-load failed (fail-soft): %s", e,
            )
            self._persist_loaded = True   # nicht erneut versuchen

    def _persist(self) -> None:
        """Speichert die aktuelle User-Wahl. Fail-soft."""
        try:
            from pydaw.core.settings import SettingsKeys
            from pydaw.core.settings_store import set_value
            set_value(
                SettingsKeys.ui_reduced_motion,
                bool(self._user_reduced_motion),
            )
        except Exception as e:
            logger.debug(
                "[MotionThrottle] persist-save failed (fail-soft): %s", e,
            )

    # ─── Quellen ─────────────────────────────────────────────────

    def set_user_reduced_motion(self, enabled: bool) -> None:
        """User-Setting: Permanente Reduced-Motion-Wahl."""
        with self._lock:
            new_val = bool(enabled)
            if new_val == self._user_reduced_motion:
                return
            self._user_reduced_motion = new_val
            logger.info(
                "[MotionThrottle] user_reduced_motion=%s",
                self._user_reduced_motion,
            )
        # Außerhalb des Locks persistieren — settings_store macht
        # ggf. SQLite-IO, kein Fall für RLock-Bash.
        self._persist()
        self._fire_if_changed()

    def get_user_reduced_motion(self) -> bool:
        with self._lock:
            return self._user_reduced_motion

    def set_sentinel_throttle(self, throttled: bool) -> None:
        """SENTINEL-Hook: GIL-Starvation-State.

        Wird vom ``sentinel_anomaly._check_gil()`` getrieben:
        - Peak > GIL_STARVATION_CRIT_MS  → throttled=True
        - Anomaly resolved               → throttled=False

        Logged informativ (nicht warning), da das eine reaktive
        Schutz-Maßnahme ist und kein Fehler.
        """
        with self._lock:
            new_val = bool(throttled)
            if new_val == self._sentinel_throttle:
                return
            self._sentinel_throttle = new_val
            logger.info(
                "[MotionThrottle] sentinel_throttle=%s",
                self._sentinel_throttle,
            )
        self._fire_if_changed()

    def get_sentinel_throttle(self) -> bool:
        with self._lock:
            return self._sentinel_throttle

    def set_temp_throttle(self, key: str, throttled: bool) -> None:
        """Temporärer Throttle aus dritter Quelle (z.B. Project-Load).

        Multiple Keys werden via OR kombiniert. Wenn alle Keys False
        oder gelöscht sind, ist der Temp-Throttle inaktiv.
        """
        with self._lock:
            cur = self._temp_throttles.get(key, False)
            new = bool(throttled)
            if new == cur:
                return
            if new:
                self._temp_throttles[key] = True
            else:
                self._temp_throttles.pop(key, None)
            logger.debug(
                "[MotionThrottle] temp[%s]=%s (active=%d)",
                key, new, len(self._temp_throttles),
            )
        self._fire_if_changed()

    def clear_temp_throttles(self) -> None:
        """Alle Temp-Throttles wegwerfen (z.B. Test-Reset)."""
        with self._lock:
            if not self._temp_throttles:
                return
            self._temp_throttles.clear()
            logger.debug("[MotionThrottle] temp cleared")
        self._fire_if_changed()

    # ─── Listener ────────────────────────────────────────────────

    def register_listener(self, callback: ThrottleListener) -> None:
        """Callback registrieren. Wird sofort einmal aufgerufen mit
        dem aktuellen effektiven Status, damit der Listener
        synchron startet.
        """
        with self._lock:
            self._listeners.append(callback)
            current = self._compute_effective()
        # Initial-Sync außerhalb des Locks
        try:
            callback(current)
        except Exception as e:
            logger.warning(
                "[MotionThrottle] listener initial-sync failed: %s", e,
            )

    def unregister_listener(self, callback: ThrottleListener) -> bool:
        """Idempotent. True wenn entfernt wurde."""
        with self._lock:
            try:
                self._listeners.remove(callback)
                return True
            except ValueError:
                return False

    # ─── Effektiver Status ───────────────────────────────────────

    def get_effective_throttle(self) -> bool:
        """Aktueller effektiver Throttle (ODER aus allen Quellen)."""
        with self._lock:
            return self._compute_effective()

    def _compute_effective(self) -> bool:
        # Lock muss vom Caller gehalten werden
        if self._user_reduced_motion or self._sentinel_throttle:
            return True
        return any(self._temp_throttles.values())

    def _fire_if_changed(self) -> None:
        """Listener nur dann benachrichtigen wenn sich der effektive
        Wert tatsächlich geändert hat. Verhindert Flood bei
        Sentinel-Tick-Rate-Anstiegen.
        """
        with self._lock:
            new_eff = self._compute_effective()
            if new_eff == self._last_effective:
                return
            self._last_effective = new_eff
            listeners = list(self._listeners)
        # Listener außerhalb des Locks aufrufen — verhindert Deadlocks
        # wenn ein Listener selber wieder die API ruft.
        for cb in listeners:
            try:
                cb(new_eff)
            except Exception as e:
                logger.warning(
                    "[MotionThrottle] listener failed: %s", e,
                )
        logger.debug(
            "[MotionThrottle] effective=%s broadcast to %d listener(s)",
            new_eff, len(listeners),
        )

    # ─── Diagnose ────────────────────────────────────────────────

    def diagnose(self) -> dict:
        with self._lock:
            return {
                "user_reduced_motion": self._user_reduced_motion,
                "sentinel_throttle": self._sentinel_throttle,
                "temp_throttles": dict(self._temp_throttles),
                "effective": self._compute_effective(),
                "listeners": len(self._listeners),
            }


# ─── Singleton-Helper ────────────────────────────────────────────

_INSTANCE: Optional[MotionThrottleService] = None
_INSTANCE_LOCK = threading.Lock()


def get_motion_throttle() -> MotionThrottleService:
    """Singleton-Getter. Lazy-init thread-safe."""
    global _INSTANCE
    if _INSTANCE is None:
        with _INSTANCE_LOCK:
            if _INSTANCE is None:
                _INSTANCE = MotionThrottleService()
    return _INSTANCE


__all__ = [
    "MotionThrottleService",
    "ThrottleListener",
    "get_motion_throttle",
]
