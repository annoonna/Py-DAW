"""Fusion Oscillator — Bite (dual oscillator with FM, Sync, PWM, Ring Mod).

v0.0.20.573: Phase 2 — Techniques-driven dual oscillator.
"""
from __future__ import annotations
import math
import numpy as np
from typing import Optional
from .base import OscillatorBase

_WAVE_FUNCS = {
    0: lambda p: math.sin(2.0 * math.pi * p),                          # sine
    1: lambda p: (4.0 * p - 1.0 if p < 0.5 else 3.0 - 4.0 * p),     # triangle
    2: lambda p: 2.0 * p - 1.0,                                        # saw (naive)
    3: lambda p: (1.0 if p < 0.5 else -1.0),                          # pulse
}


class BiteOscillator(OscillatorBase):
    """Dual oscillator with Exp-FM, Hard Sync, PWM, Ring Mod."""

    NAME = "Bite"
    MODE_FM = 0
    MODE_SYNC = 1
    MODE_PWM = 2
    MODE_RING = 3

    def __init__(self, sr: int = 48000):
        super().__init__(sr)
        self._wave_a = 2      # 0=sine,1=tri,2=saw,3=pulse
        self._wave_b = 0
        self._width_a = 0.5
        self._width_b = 0.5
        self._ratio_b = 1.0   # 0.5..16
        self._mode = 0        # FM/Sync/PWM/Ring
        self._mix_a = 1.0
        self._mix_b = 0.0
        self._mix_rm = 0.0

        self._phase_a = 0.0
        self._phase_b = 0.0

    def set_param(self, key: str, value: float) -> None:
        if key == "wave_a":
            self._wave_a = int(round(float(value))) % 4
        elif key == "wave_b":
            self._wave_b = int(round(float(value))) % 4
        elif key == "width_a":
            self._width_a = max(0.01, min(0.99, float(value)))
        elif key == "width_b":
            self._width_b = max(0.01, min(0.99, float(value)))
        elif key == "ratio_b":
            self._ratio_b = max(0.5, min(16.0, float(value)))
        elif key == "mode":
            self._mode = int(round(float(value))) % 4
        elif key == "mix_a":
            self._mix_a = max(0.0, min(1.0, float(value)))
        elif key == "mix_b":
            self._mix_b = max(0.0, min(1.0, float(value)))
        elif key == "mix_rm":
            self._mix_rm = max(0.0, min(1.0, float(value)))
        else:
            super().set_param(key, value)

    def get_param(self, key: str) -> float:
        if key in ("wave_a", "wave_b", "width_a", "width_b", "ratio_b",
                    "mode", "mix_a", "mix_b", "mix_rm"):
            return getattr(self, f"_{key}", 0.0)
        return super().get_param(key)

    def param_names(self) -> list[str]:
        return ["wave_a", "wave_b", "width_a", "width_b",
                "ratio_b", "mode", "mix_a", "mix_b", "mix_rm"]

    def reset_phase(self) -> None:
        super().reset_phase()
        self._phase_a = 0.0
        self._phase_b = 0.0

    def _wave_sample(self, wave_id: int, phase: float, width: float) -> float:
        if wave_id == 3:  # pulse with variable width
            return 1.0 if phase < width else -1.0
        return _WAVE_FUNCS.get(wave_id, _WAVE_FUNCS[0])(phase)

    def render(self, frames: int, freq: float, sr: int,
               phase_mod_buf: Optional[np.ndarray] = None) -> np.ndarray:
        """v0.0.20.785: RING + PWM modes fully vectorized via _vec_wave helpers.
        FM + SYNC modes remain per-sample (inherently sequential feedback/sync).
        """
        freq_a = freq
        freq_b = freq * self._ratio_b
        dt_a = freq_a / sr
        dt_b = freq_b / sr

        # Cache all as locals
        mode = self._mode
        wave_a = self._wave_a
        wave_b = self._wave_b
        width_a = self._width_a
        width_b = self._width_b
        mix_a = self._mix_a
        mix_b = self._mix_b
        mix_rm = self._mix_rm
        has_rm = mix_rm > 0.001

        if mode == 3:  # RING — fully vectorizable
            from .basic_waves import _vec_wave
            indices = np.arange(frames, dtype=np.float64)
            phases_a = (self._phase_a + indices * dt_a) % 1.0
            phases_b = (self._phase_b + indices * dt_b) % 1.0
            self._phase_a = (self._phase_a + frames * dt_a) % 1.0
            self._phase_b = (self._phase_b + frames * dt_b) % 1.0

            osc_a = _vec_wave(wave_a, phases_a, dt_a, width_a)
            osc_b = _vec_wave(wave_b, phases_b, dt_b, width_b)
            out = osc_a * mix_a + osc_b * mix_b
            if has_rm:
                out += osc_a * osc_b * mix_rm
            return out

        elif mode == 2:  # PWM — vectorizable (osc_b modulates width)
            from .basic_waves import _vec_wave
            indices = np.arange(frames, dtype=np.float64)
            phases_a = (self._phase_a + indices * dt_a) % 1.0
            phases_b = (self._phase_b + indices * dt_b) % 1.0
            self._phase_a = (self._phase_a + frames * dt_a) % 1.0
            self._phase_b = (self._phase_b + frames * dt_b) % 1.0

            osc_b = _vec_wave(wave_b, phases_b, dt_b, width_b)
            # Modulated width for osc_a
            mod_width = np.clip(width_a + osc_b * mix_b * 0.4, 0.05, 0.95)

            # osc_a with per-sample varying width (wave_a specific)
            if wave_a == 3:  # pulse with variable width
                osc_a = np.where(phases_a < mod_width, 1.0, -1.0)
                # Simplified PolyBLEP for variable-width pulse
                if dt_a > 1e-12:
                    mask_lo = phases_a < dt_a
                    if np.any(mask_lo):
                        t_n = phases_a[mask_lo] / dt_a
                        osc_a[mask_lo] -= t_n + t_n - t_n * t_n - 1.0
                    mask_hi = phases_a > (1.0 - dt_a)
                    if np.any(mask_hi):
                        t_n = (phases_a[mask_hi] - 1.0) / dt_a
                        osc_a[mask_hi] -= t_n * t_n + t_n + t_n + 1.0
            else:
                osc_a = _vec_wave(wave_a, phases_a, dt_a, width_a)

            out = osc_a * mix_a + osc_b * mix_b
            if has_rm:
                out += osc_a * osc_b * mix_rm
            return out

        else:
            # FM (mode 0) and SYNC (mode 1) — per-sample (feedback/sync)
            out = np.empty(frames, dtype=np.float64)
            TWO_PI = 2.0 * math.pi
            _sin = math.sin
            phase_a = self._phase_a
            phase_b = self._phase_b

            def _ws(wid, p, w):
                if wid == 0:
                    return _sin(TWO_PI * p)
                elif wid == 1:
                    return 4.0 * p - 1.0 if p < 0.5 else 3.0 - 4.0 * p
                elif wid == 2:
                    return 2.0 * p - 1.0
                else:
                    return 1.0 if p < w else -1.0

            if mode == 0:  # FM
                for i in range(frames):
                    osc_b = _ws(wave_b, phase_b, width_b)
                    fm_mod = 2.0 ** (osc_b * mix_b * 2.0)
                    osc_a = _ws(wave_a, phase_a, width_a)
                    phase_a = (phase_a + dt_a * fm_mod) % 1.0
                    sample = osc_a * mix_a + osc_b * mix_b
                    if has_rm:
                        sample += osc_a * osc_b * mix_rm
                    out[i] = sample
                    phase_b = (phase_b + dt_b) % 1.0
            else:  # SYNC
                for i in range(frames):
                    osc_b = _ws(wave_b, phase_b, width_b)
                    new_phase_b = (phase_b + dt_b) % 1.0
                    if new_phase_b < phase_b:
                        phase_a = 0.0
                    osc_a = _ws(wave_a, phase_a, width_a)
                    phase_a = (phase_a + dt_a) % 1.0
                    sample = osc_a * mix_a + osc_b * mix_b
                    if has_rm:
                        sample += osc_a * osc_b * mix_rm
                    out[i] = sample
                    phase_b = new_phase_b

            self._phase_a = phase_a
            self._phase_b = phase_b
            return out
