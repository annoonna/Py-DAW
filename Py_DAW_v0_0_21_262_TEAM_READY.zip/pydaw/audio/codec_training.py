# -*- coding: utf-8 -*-
"""KI-Codec Training Pipeline — Musik-spezifisches Finetuning.

v0.0.21.029 — Block C Phase C3.1 + C3.2

Training pipeline for finetuning EnCodec on DAW-specific audio:
drums, vocals, synths, and mixed signals.

Requires: torch, encodec, torchaudio, soundfile
GPU recommended (CUDA/ROCm), CPU possible but slow.

Usage:
    python -m pydaw.audio.codec_training --data /path/to/stems --epochs 50

    # Or programmatically:
    from pydaw.audio.codec_training import CodecTrainer
    trainer = CodecTrainer(data_dir="/stems", codec_type="drums")
    trainer.train(epochs=50)
    trainer.export_onnx("dac_drums.onnx")
"""
from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

log = logging.getLogger(__name__)

# Instrument-specific codec configurations (C3.2)
CODEC_CONFIGS = {
    "drums": {
        "name": "DAC-Drums",
        "description": "Optimiert für Transienten (Kicks, Snares, HiHats)",
        "bandwidths": [1.5, 3.0, 6.0, 12.0, 24.0],
        "training_focus": "transient_preservation",
        "loss_weights": {"spectral": 0.3, "transient": 0.5, "perceptual": 0.2},
        "augmentations": ["pitch_shift", "time_stretch", "noise"],
        "sample_rate": 48000,
    },
    "vocals": {
        "name": "DAC-Vocals",
        "description": "Optimiert für Sprache/Gesang",
        "bandwidths": [1.5, 3.0, 6.0, 12.0, 24.0],
        "training_focus": "formant_preservation",
        "loss_weights": {"spectral": 0.2, "formant": 0.4, "perceptual": 0.4},
        "augmentations": ["pitch_shift", "reverb", "noise"],
        "sample_rate": 48000,
    },
    "synth": {
        "name": "DAC-Synth",
        "description": "Optimiert für harmonische Signale",
        "bandwidths": [1.5, 3.0, 6.0, 12.0, 24.0],
        "training_focus": "harmonic_preservation",
        "loss_weights": {"spectral": 0.4, "harmonic": 0.4, "perceptual": 0.2},
        "augmentations": ["pitch_shift", "filter_sweep"],
        "sample_rate": 48000,
    },
    "mix": {
        "name": "DAC-Mix",
        "description": "General-Purpose für gemischte Signale",
        "bandwidths": [1.5, 3.0, 6.0, 12.0, 24.0],
        "training_focus": "balanced",
        "loss_weights": {"spectral": 0.33, "transient": 0.33, "perceptual": 0.34},
        "augmentations": ["pitch_shift", "time_stretch", "noise", "eq"],
        "sample_rate": 48000,
    },
}


class CodecTrainer:
    """Train instrument-specific audio codecs.

    Finetunes EnCodec base model on domain-specific audio data.
    """

    def __init__(self, data_dir: str | Path, codec_type: str = "mix",
                 output_dir: Optional[str | Path] = None):
        self.data_dir = Path(data_dir)
        self.codec_type = codec_type
        self.config = CODEC_CONFIGS.get(codec_type, CODEC_CONFIGS["mix"])
        self.output_dir = Path(output_dir) if output_dir else self.data_dir / "models"
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self._model = None
        self._device = None

    def _check_requirements(self) -> bool:
        try:
            import torch
            import encodec
            return True
        except ImportError:
            log.error("Training requires: pip install torch encodec torchaudio")
            return False

    def _load_base_model(self):
        if self._model is not None:
            return
        import torch
        from encodec import EncodecModel

        self._device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self._model = EncodecModel.encodec_model_48khz()
        self._model = self._model.to(self._device)
        self._model.train()
        log.info("[TRAIN] Base model loaded on %s", self._device)

    def _collect_training_data(self) -> List[Path]:
        """Collect audio files from data directory."""
        extensions = {".wav", ".flac", ".ogg", ".mp3", ".aiff"}
        files = []
        for f in self.data_dir.rglob("*"):
            if f.is_file() and f.suffix.lower() in extensions:
                files.append(f)
        log.info("[TRAIN] Found %d training files in %s", len(files), self.data_dir)
        return files

    def train(self, epochs: int = 50, batch_size: int = 8,
              lr: float = 1e-4, segment_length: int = 48000 * 5) -> Dict[str, Any]:
        """Train the codec model.

        Args:
            epochs: Number of training epochs
            batch_size: Batch size
            lr: Learning rate
            segment_length: Audio segment length in samples (default 5s @ 48kHz)

        Returns:
            Training statistics
        """
        if not self._check_requirements():
            return {"error": "Missing requirements"}

        import torch
        import torch.nn.functional as F
        import soundfile as sf
        import numpy as np

        self._load_base_model()
        files = self._collect_training_data()
        if not files:
            return {"error": "No training data found"}

        optimizer = torch.optim.Adam(self._model.parameters(), lr=lr)
        weights = self.config["loss_weights"]

        stats = {"epochs": epochs, "losses": [], "best_loss": float("inf")}

        for epoch in range(epochs):
            epoch_loss = 0.0
            n_batches = 0

            for audio_file in files:
                try:
                    data, sr = sf.read(str(audio_file), dtype="float32")
                    if data.ndim == 1:
                        data = data.reshape(-1, 1)

                    # Random segment
                    if len(data) > segment_length:
                        start = np.random.randint(0, len(data) - segment_length)
                        data = data[start:start + segment_length]

                    # To tensor
                    wav = torch.from_numpy(data.T).unsqueeze(0).to(self._device)

                    # Forward
                    encoded = self._model.encode(wav)
                    decoded = self._model.decode(encoded)

                    # Spectral loss
                    loss_spec = F.l1_loss(decoded, wav)

                    # Transient loss (difference of differences)
                    if weights.get("transient", 0) > 0:
                        orig_diff = torch.diff(wav, dim=-1)
                        dec_diff = torch.diff(decoded, dim=-1)
                        loss_trans = F.l1_loss(dec_diff, orig_diff)
                    else:
                        loss_trans = torch.tensor(0.0)

                    # Combined loss
                    loss = (weights.get("spectral", 0.33) * loss_spec +
                            weights.get("transient", 0.33) * loss_trans)

                    optimizer.zero_grad()
                    loss.backward()
                    optimizer.step()

                    epoch_loss += loss.item()
                    n_batches += 1

                except Exception as e:
                    log.debug("[TRAIN] Skip %s: %s", audio_file.name, e)
                    continue

            avg_loss = epoch_loss / max(1, n_batches)
            stats["losses"].append(avg_loss)

            if avg_loss < stats["best_loss"]:
                stats["best_loss"] = avg_loss
                # Save best model
                self._save_checkpoint(epoch, avg_loss)

            if (epoch + 1) % 10 == 0:
                log.info("[TRAIN] Epoch %d/%d: loss=%.6f", epoch + 1, epochs, avg_loss)

        log.info("[TRAIN] Done: best_loss=%.6f", stats["best_loss"])
        return stats

    def _save_checkpoint(self, epoch: int, loss: float) -> None:
        import torch
        path = self.output_dir / f"dac_{self.codec_type}_best.pt"
        torch.save({
            "epoch": epoch,
            "loss": loss,
            "model_state": self._model.state_dict(),
            "config": self.config,
        }, str(path))

    def export_onnx(self, output_path: Optional[str] = None) -> Path:
        """C3.5: Export trained model to ONNX for Rust inference."""
        if not self._check_requirements():
            raise RuntimeError("Missing requirements")

        import torch

        if self._model is None:
            self._load_base_model()

        if output_path is None:
            output_path = str(self.output_dir / f"dac_{self.codec_type}.onnx")

        self._model.eval()
        dummy = torch.randn(1, 1, 48000 * 2).to(self._device)

        try:
            torch.onnx.export(
                self._model,
                dummy,
                output_path,
                opset_version=14,
                input_names=["audio"],
                output_names=["encoded"],
                dynamic_axes={"audio": {2: "length"}},
            )
            log.info("[TRAIN] ONNX exported: %s", output_path)
        except Exception as e:
            log.warning("[TRAIN] ONNX export failed: %s", e)

        return Path(output_path)


def list_codec_types() -> List[str]:
    """List available codec training types."""
    return list(CODEC_CONFIGS.keys())


def get_codec_config(codec_type: str) -> Dict[str, Any]:
    """Get configuration for a codec type."""
    return dict(CODEC_CONFIGS.get(codec_type, CODEC_CONFIGS["mix"]))


# CLI entry point
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Train DAW-specific audio codec")
    parser.add_argument("--data", required=True, help="Path to training audio files")
    parser.add_argument("--type", default="mix", choices=list_codec_types())
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--export-onnx", action="store_true")
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO)
    trainer = CodecTrainer(data_dir=args.data, codec_type=args.type)
    stats = trainer.train(epochs=args.epochs, lr=args.lr)
    print(f"Training done: {stats}")

    if args.export_onnx:
        trainer.export_onnx()
