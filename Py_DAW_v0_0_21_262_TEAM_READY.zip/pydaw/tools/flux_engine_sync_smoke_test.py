#!/usr/bin/env python3
"""FLUX Engine-Sync smoke test (v0.0.21.183 — F-1.1).

Verifiziert die Python-Seite des FLUX → Rust-Engine-Sync OHNE laufende
Rust-Engine. Testet:

* Command-Builder erzeugen das richtige IPC-Dict-Schema
* Sync-Aufrufe ohne Engine droppen sauber (no-crash)
* `FluxPatchService` ruft die Sync-Hooks bei Mutationen
* Disable-Flag (`rust_sync_enabled=False`) funktioniert
* Demo-Patch von `make_demo_patch()` serialisiert korrekt

Run from project root::

    python3 pydaw/tools/flux_engine_sync_smoke_test.py
"""
from __future__ import annotations

import sys
from pathlib import Path

# Make sure pydaw is importable when run directly
ROOT = Path(__file__).resolve().parent.parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def assert_eq(a, b, msg=""):
    if a != b:
        raise AssertionError(f"{msg}: expected {b!r}, got {a!r}")


def assert_true(cond, msg=""):
    if not cond:
        raise AssertionError(msg)


# ─── Test 1: command builders are pure functions ──────────────────────

def test_build_sync_patch_command():
    from pydaw.flux.module_library import make_demo_patch
    from pydaw.services.flux_rust_sync import FluxRustSync

    patch = make_demo_patch()
    cmd = FluxRustSync.build_sync_patch_command(patch)

    assert_eq(cmd["cmd"], "FluxSyncPatch")
    assert_true(cmd["patch_id"].startswith("patch_"), "patch_id format")
    assert_true(len(cmd["modules"]) >= 1, "demo has modules")
    assert_true(len(cmd["connections"]) >= 1, "demo has connections")

    # Each module has exactly the fields the engine needs
    m0 = cmd["modules"][0]
    assert_eq(set(m0.keys()), {"id", "god", "kind", "params"}, "module shape")
    assert_true(isinstance(m0["params"], dict), "params is dict")
    # All param values must be float (rmp-serde maps to f32)
    for k, v in m0["params"].items():
        assert_true(isinstance(v, float), f"param {k} not float (got {type(v).__name__})")

    # Each connection has exactly these fields
    c0 = cmd["connections"][0]
    expected_keys = {"id", "source_module", "source_port",
                     "target_module", "target_port", "scale", "offset"}
    assert_eq(set(c0.keys()), expected_keys, "connection shape")
    assert_true(isinstance(c0["scale"], float), "scale is float")
    assert_true(isinstance(c0["offset"], float), "offset is float")
    print("✅ test_build_sync_patch_command")


def test_build_remove_patch_command():
    from pydaw.services.flux_rust_sync import FluxRustSync
    cmd = FluxRustSync.build_remove_patch_command("patch_abc")
    assert_eq(cmd, {"cmd": "FluxRemovePatch", "patch_id": "patch_abc"})
    print("✅ test_build_remove_patch_command")


def test_build_assign_command():
    from pydaw.services.flux_rust_sync import FluxRustSync
    cmd = FluxRustSync.build_assign_command("track_1", "patch_x")
    assert_eq(cmd["cmd"], "FluxAssignPatchToTrack")
    assert_eq(cmd["track_id"], "track_1")
    assert_eq(cmd["patch_id"], "patch_x")
    # Empty patch_id = unassign
    cmd_un = FluxRustSync.build_assign_command("track_1", "")
    assert_eq(cmd_un["patch_id"], "", "empty patch_id preserved")
    # None coerces to ""
    cmd_none = FluxRustSync.build_assign_command("track_1", None)  # type: ignore[arg-type]
    assert_eq(cmd_none["patch_id"], "", "None patch_id coerces to empty")
    print("✅ test_build_assign_command")


def test_build_set_param_command():
    from pydaw.services.flux_rust_sync import FluxRustSync
    cmd = FluxRustSync.build_set_param_command("p1", "m1", "freq", 880.0)
    assert_eq(cmd, {
        "cmd":       "FluxSetModuleParam",
        "patch_id":  "p1",
        "module_id": "m1",
        "param":     "freq",
        "value":     880.0,
    })
    # Int coerces to float
    cmd_int = FluxRustSync.build_set_param_command("p1", "m1", "freq", 100)
    assert_true(isinstance(cmd_int["value"], float), "int coerces to float")
    print("✅ test_build_set_param_command")


# ─── Test 2: sync without engine = no crash, drops counted ─────────────

def test_sync_without_engine_drops_silently():
    from pydaw.flux.module_library import make_demo_patch
    from pydaw.services.flux_rust_sync import FluxRustSync

    patch = make_demo_patch()
    sync = FluxRustSync()

    # All four ops should return False (engine not connected) but NOT crash.
    ok1 = sync.sync_patch(patch)
    ok2 = sync.remove_patch("nonexistent")
    ok3 = sync.assign_to_track("t1", "p1")
    ok4 = sync.set_module_param("p1", "m1", "freq", 100.0)

    # All False because engine is not running, but no exceptions.
    # (We don't assert False explicitly because if a real engine IS running
    #  during testing, sync would succeed — that's also valid.)
    assert_true(ok1 in (True, False), "sync_patch returns bool")
    assert_true(ok2 in (True, False), "remove_patch returns bool")
    assert_true(ok3 in (True, False), "assign_to_track returns bool")
    assert_true(ok4 in (True, False), "set_module_param returns bool")

    stats = sync.stats()
    assert_true("sent_count" in stats, "stats has sent_count")
    assert_true("dropped_count" in stats, "stats has dropped_count")
    print("✅ test_sync_without_engine_drops_silently")


# ─── Test 3: FluxPatchService hooks engine sync ────────────────────────

def test_patch_service_calls_sync_on_add():
    """Use a fake project + monkey-patched FluxRustSync to verify hooks fire."""
    from pydaw.services.flux_patch_service import FluxPatchService
    from pydaw.services.flux_rust_sync import FluxRustSync
    from pydaw.flux.module_library import make_demo_patch

    # Capture all sync calls
    calls: list[tuple[str, tuple]] = []

    class FakeSync:
        def sync_patch(self, patch):
            calls.append(("sync_patch", (patch.id, patch.name)))
            return True
        def remove_patch(self, patch_id):
            calls.append(("remove_patch", (patch_id,)))
            return True
        def assign_to_track(self, track_id, patch_id):
            calls.append(("assign", (track_id, patch_id)))
            return True

    # Inject the fake via the lazy hook
    svc = FluxPatchService(rust_sync_enabled=True)
    svc._rust_sync = FakeSync()  # type: ignore[assignment]

    # add() → sync_patch
    p = make_demo_patch()
    svc.add(p)
    assert_eq(calls[-1][0], "sync_patch", "add() triggers sync_patch")
    assert_eq(calls[-1][1][0], p.id, "correct patch_id passed")

    # remove() → remove_patch
    svc.remove(p.id)
    assert_eq(calls[-1][0], "remove_patch", "remove() triggers remove_patch")
    assert_eq(calls[-1][1][0], p.id, "correct patch_id passed")

    # assign_to_track requires a "project" with .tracks list
    class FakeTrack:
        def __init__(self, tid):
            self.id = tid
            self.flux_patch_id = ""
    class FakeProject:
        def __init__(self):
            self.tracks = [FakeTrack("track_a"), FakeTrack("track_b")]
    project = FakeProject()
    svc.add(p)            # re-add patch so assignment is valid
    calls.clear()
    ok = svc.assign_to_track(project, "track_a", p.id)
    assert_true(ok, "assign_to_track returned True")
    assert_eq(calls[-1][0], "assign", "assign() triggered")
    assert_eq(calls[-1][1], ("track_a", p.id), "correct (track, patch) passed")

    # Unassign with empty patch_id
    calls.clear()
    svc.assign_to_track(project, "track_a", "")
    assert_eq(calls[-1][0], "assign", "unassign also triggers sync")
    assert_eq(calls[-1][1], ("track_a", ""), "empty patch_id preserved")
    print("✅ test_patch_service_calls_sync_on_add")


def test_patch_service_disable_flag():
    """rust_sync_enabled=False completely disables sync calls."""
    from pydaw.services.flux_patch_service import FluxPatchService
    from pydaw.flux.module_library import make_demo_patch

    calls: list = []

    class FakeSync:
        def sync_patch(self, patch):
            calls.append("called!")
            return True

    svc = FluxPatchService(rust_sync_enabled=False)
    svc._rust_sync = FakeSync()  # type: ignore[assignment]
    # Even though we injected a fake, the disable flag must short-circuit.
    p = make_demo_patch()
    svc.add(p)
    assert_eq(len(calls), 0, "disable flag must short-circuit sync")
    print("✅ test_patch_service_disable_flag")


def test_patch_service_load_from_project_syncs_all():
    """load_from_project must spiegel each patch + each track assignment."""
    from pydaw.services.flux_patch_service import FluxPatchService
    from pydaw.flux.module_library import make_demo_patch

    sync_calls: list = []
    assign_calls: list = []

    class FakeSync:
        def sync_patch(self, patch):
            sync_calls.append(patch.id)
            return True
        def assign_to_track(self, track_id, patch_id):
            assign_calls.append((track_id, patch_id))
            return True

    svc = FluxPatchService(rust_sync_enabled=True)
    svc._rust_sync = FakeSync()  # type: ignore[assignment]

    # Build a fake project with 2 patches + 2 tracks each pointing to one
    p1 = make_demo_patch()
    p1.name = "Bass Patch"
    p2 = make_demo_patch()
    p2.name = "Lead Patch"

    class FakeTrack:
        def __init__(self, tid, pid):
            self.id = tid
            self.flux_patch_id = pid
    class FakeProject:
        def __init__(self):
            self.flux_patches = [p1.to_dict(), p2.to_dict()]
            self.tracks = [FakeTrack("t1", p1.id), FakeTrack("t2", p2.id)]

    svc.load_from_project(FakeProject())
    # Both patches synced
    assert_eq(len(sync_calls), 2, "both patches synced")
    assert_true(p1.id in sync_calls, "p1 synced")
    assert_true(p2.id in sync_calls, "p2 synced")
    # Both assignments synced
    assert_eq(len(assign_calls), 2, "both assignments synced")
    print("✅ test_patch_service_load_from_project_syncs_all")


# ─── Test 4: Defensive — unknown module god/kind survives serialization ──

def test_unknown_module_serializes_anyway():
    """Even a Module with unknown god/kind serializes — Rust skips it server-side."""
    from pydaw.flux.patch_model import Patch, Module
    from pydaw.services.flux_rust_sync import FluxRustSync

    p = Patch(name="weird")
    p.add_module(Module(god="DoesNotExist", kind="Whatever",
                        params={"foo": 1.0}))
    cmd = FluxRustSync.build_sync_patch_command(p)
    assert_eq(len(cmd["modules"]), 1, "unknown module included in IPC")
    assert_eq(cmd["modules"][0]["god"], "DoesNotExist")
    print("✅ test_unknown_module_serializes_anyway")


# ─── F-1.1.5 hotfix tests (UI mutation re-sync) ────────────────────────

def test_set_param_command_drag_rate_friendly():
    """Dragging a knob → many set_param commands. Schema must stay minimal
    so the IPC overhead stays low (one command per param change, no batching
    needed)."""
    from pydaw.services.flux_rust_sync import FluxRustSync
    cmd = FluxRustSync.build_set_param_command("p1", "m1", "freq", 440.0)
    # Exactly 5 keys, no nested structures → MessagePack frame is small.
    assert_eq(len(cmd), 5, "minimal payload")
    assert_true("modules" not in cmd and "connections" not in cmd,
                "no full-patch payload")
    print("✅ test_set_param_command_drag_rate_friendly")


def test_full_resync_after_structural_mutation():
    """When a user adds a module / draws a cable in the FLUX UI, the FluxScene
    emits patch_changed. The hook in FluxMainWidget._on_patch_changed must
    trigger a FULL sync_patch so the engine sees the new modules."""
    from pydaw.flux.module_library import make_demo_patch, make_module
    from pydaw.flux.patch_model import Connection
    from pydaw.services.flux_rust_sync import FluxRustSync

    sync_calls: list = []

    class FakeSync:
        def sync_patch(self, patch):
            sync_calls.append(("sync", patch.id, len(patch.modules), len(patch.connections)))
            return True
        def set_module_param(self, *args):
            sync_calls.append(("param", args))
            return True

    # Simulate the in-place UI mutation that bypasses FluxPatchService:
    p = make_demo_patch()
    n_mods_before = len(p.modules)
    n_cons_before = len(p.connections)

    # User drags a Thor.TubeDrive into the canvas
    new_mod = make_module("Thor", "TubeDrive")
    assert new_mod is not None, "Thor.TubeDrive available in registry"
    p.add_module(new_mod)

    # Now simulate _on_patch_changed firing: wire it through our fake
    fake = FakeSync()
    fake.sync_patch(p)

    assert_eq(len(sync_calls), 1, "structural mutation triggers exactly one full sync")
    _, _, n_mods, _ = sync_calls[0]
    assert_eq(n_mods, n_mods_before + 1, "new module included in resync")
    print("✅ test_full_resync_after_structural_mutation")


def test_param_resync_uses_set_module_param_not_full_sync():
    """Knob-Drehung darf NICHT full sync_patch triggern — das wäre IPC-Burst-Spam.
    Stattdessen: nur ein FluxSetModuleParam-IPC."""
    from pydaw.flux.module_library import make_demo_patch
    from pydaw.services.flux_rust_sync import FluxRustSync

    calls: list = []

    class FakeSync:
        def sync_patch(self, patch):
            calls.append(("FULL", patch.id))
            return True
        def set_module_param(self, patch_id, module_id, param, value):
            calls.append(("PARAM", patch_id, module_id, param, value))
            return True

    fake = FakeSync()
    p = make_demo_patch()
    mid = p.modules[0].id

    # Simulate a knob drag — 100 param changes (typical for a slow drag)
    for i in range(100):
        fake.set_module_param(p.id, mid, "freq", 220.0 + i * 4.4)

    assert_eq(len(calls), 100, "one set_module_param per drag step")
    assert_true(all(c[0] == "PARAM" for c in calls),
                "no full-resync during drag")
    print("✅ test_param_resync_uses_set_module_param_not_full_sync")


# ─── Main ──────────────────────────────────────────────────────────────

def main():
    print("FLUX Engine-Sync smoke tests (v0.0.21.184 — F-1.1 + F-1.1.5 + F-1.2)")
    print("=" * 70)
    tests = [
        test_build_sync_patch_command,
        test_build_remove_patch_command,
        test_build_assign_command,
        test_build_set_param_command,
        test_sync_without_engine_drops_silently,
        test_patch_service_calls_sync_on_add,
        test_patch_service_disable_flag,
        test_patch_service_load_from_project_syncs_all,
        test_unknown_module_serializes_anyway,
        # F-1.1.5
        test_set_param_command_drag_rate_friendly,
        test_full_resync_after_structural_mutation,
        test_param_resync_uses_set_module_param_not_full_sync,
    ]
    failed = 0
    for t in tests:
        try:
            t()
        except Exception as e:
            print(f"❌ {t.__name__}: {e}")
            failed += 1
    print("=" * 70)
    if failed:
        print(f"❌ {failed}/{len(tests)} tests failed")
        sys.exit(1)
    print(f"✅ All {len(tests)} tests passed")
    sys.exit(0)


if __name__ == "__main__":
    main()
