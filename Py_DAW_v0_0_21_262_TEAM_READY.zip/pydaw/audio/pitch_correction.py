"""Pitch Correction Engine (P1B) — Melodyne-style single-note pitch editing.

Detects pitched segments ("blobs") in mono audio and allows per-blob
pitch correction. Non-destructive: the original audio is never modified;
corrections are applied at render time.

Architecture
------------
1. **PitchBlob** — detected note with start/end sample, detected pitch,
   target pitch (corrected), and confidence.
2. **detect_pitch_blobs()** — YIN-based pitch detection that segments
   the audio into pitched regions.
3. **apply_pitch_corrections()** — renders corrected audio using
   phase-vocoder pitch-shifting (no time change).

v0.0.20.806 — Phase P1B
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field, asdict
from typing import List, Optional, Dict, Any

log = logging.getLogger(__name__)

try:
    import numpy as np
except Exception:
    np = None  # type: ignore


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class PitchBlob:
    """A detected pitched segment in the audio.

    All positions are in samples (not beats).
    """
    id: str = ""
    start_sample: int = 0
    end_sample: int = 0
    detected_freq_hz: float = 440.0
    detected_midi: float = 69.0       # fractional MIDI note (A4=69)
    target_midi: float = 69.0         # corrected pitch (user-editable)
    confidence: float = 0.0           # 0..1 detection confidence
    is_corrected: bool = False        # True if user changed target_midi
    # Optional: drift curve (list of {sample_offset, cents_deviation})
    drift_curve: List[Dict[str, float]] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "PitchBlob":
        try:
            return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})
        except Exception:
            return cls()

    @property
    def shift_semitones(self) -> float:
        """How many semitones to shift (positive = up)."""
        return self.target_midi - self.detected_midi

    @property
    def detected_note_name(self) -> str:
        return _midi_to_name(self.detected_midi)

    @property
    def target_note_name(self) -> str:
        return _midi_to_name(self.target_midi)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]


def _midi_to_name(midi: float) -> str:
    """Convert fractional MIDI note to note name + octave + cents."""
    try:
        note_int = int(round(midi))
        cents = round((midi - note_int) * 100)
        name = _NOTE_NAMES[note_int % 12]
        octave = (note_int // 12) - 1
        if abs(cents) < 1:
            return f"{name}{octave}"
        return f"{name}{octave}{cents:+d}c"
    except Exception:
        return "?"


def _freq_to_midi(freq: float) -> float:
    """Hz → fractional MIDI note number."""
    if freq <= 0:
        return 0.0
    return 69.0 + 12.0 * math.log2(freq / 440.0)


def _midi_to_freq(midi: float) -> float:
    """Fractional MIDI → Hz."""
    return 440.0 * (2.0 ** ((midi - 69.0) / 12.0))


def _snap_to_nearest_semitone(midi: float) -> float:
    """Snap fractional MIDI to nearest integer semitone."""
    return float(round(midi))


def _snap_to_scale(midi: float, scale_root: int = 0,
                   scale_intervals: Optional[List[int]] = None) -> float:
    """Snap fractional MIDI to nearest note in a scale.

    scale_root: 0=C, 1=C#, ... 11=B
    scale_intervals: list of semitone offsets from root (e.g. major = [0,2,4,5,7,9,11])
    """
    if scale_intervals is None:
        scale_intervals = [0, 2, 4, 5, 7, 9, 11]  # major scale

    note_int = int(round(midi))
    pc = note_int % 12
    octave = note_int // 12

    # Find nearest scale degree
    best_dist = 999
    best_note = note_int
    for interval in scale_intervals:
        scale_pc = (scale_root + interval) % 12
        # Check same octave and adjacent
        for oct_offset in [-1, 0, 1]:
            candidate = (octave + oct_offset) * 12 + scale_pc
            dist = abs(candidate - midi)
            if dist < best_dist:
                best_dist = dist
                best_note = candidate

    return float(best_note)


# ---------------------------------------------------------------------------
# YIN pitch detection
# ---------------------------------------------------------------------------

def _yin_pitch(frame: "np.ndarray", sr: int, threshold: float = 0.15) -> tuple:
    """YIN pitch detection on a single frame.

    Returns (freq_hz, confidence) or (0.0, 0.0) if unvoiced.
    """
    if np is None:
        return (0.0, 0.0)

    N = len(frame)
    tau_max = N // 2
    if tau_max < 4:
        return (0.0, 0.0)

    # Step 1-2: Difference function (autocorrelation-based)
    d = np.zeros(tau_max, dtype=np.float64)
    for tau in range(1, tau_max):
        diff = frame[:tau_max] - frame[tau:tau + tau_max]
        d[tau] = np.sum(diff * diff)

    # Step 3: Cumulative mean normalized difference
    d_prime = np.ones(tau_max, dtype=np.float64)
    running_sum = 0.0
    for tau in range(1, tau_max):
        running_sum += d[tau]
        if running_sum > 1e-10:
            d_prime[tau] = d[tau] * tau / running_sum
        else:
            d_prime[tau] = 1.0

    # Step 4: Absolute threshold
    tau_est = 0
    for tau in range(2, tau_max):
        if d_prime[tau] < threshold:
            # Find local minimum
            while tau + 1 < tau_max and d_prime[tau + 1] < d_prime[tau]:
                tau += 1
            tau_est = tau
            break

    if tau_est == 0:
        return (0.0, 0.0)

    # Step 5: Parabolic interpolation for sub-sample accuracy
    if 0 < tau_est < tau_max - 1:
        s0 = d_prime[tau_est - 1]
        s1 = d_prime[tau_est]
        s2 = d_prime[tau_est + 1]
        denom = 2.0 * s1 - s2 - s0
        if abs(denom) > 1e-10:
            tau_refined = tau_est + (s0 - s2) / (2.0 * denom)
        else:
            tau_refined = float(tau_est)
    else:
        tau_refined = float(tau_est)

    if tau_refined <= 0:
        return (0.0, 0.0)

    freq = float(sr) / tau_refined
    confidence = max(0.0, min(1.0, 1.0 - float(d_prime[tau_est])))

    # Sanity: human voice/instrument range 20 Hz - 10 kHz
    if freq < 20.0 or freq > 10000.0:
        return (0.0, 0.0)

    return (freq, confidence)


def detect_pitch_blobs(
    audio: "np.ndarray",
    sr: int = 48000,
    *,
    frame_ms: float = 30.0,
    hop_ms: float = 10.0,
    min_confidence: float = 0.5,
    min_duration_ms: float = 50.0,
    merge_cents: float = 50.0,
) -> List[PitchBlob]:
    """Detect pitched segments in mono audio.

    Parameters
    ----------
    audio : 1D float32 array
    sr : sample rate
    frame_ms : analysis window size in ms
    hop_ms : hop size in ms
    min_confidence : minimum YIN confidence to consider voiced
    min_duration_ms : minimum blob duration to keep
    merge_cents : merge adjacent frames within this tolerance

    Returns
    -------
    List of PitchBlob with detected pitches.
    """
    if np is None:
        return []

    audio = np.asarray(audio, dtype=np.float64).flatten()
    if len(audio) < 256:
        return []

    frame_len = max(128, int(frame_ms * 0.001 * sr))
    hop_len = max(64, int(hop_ms * 0.001 * sr))
    min_samples = max(1, int(min_duration_ms * 0.001 * sr))

    # Per-frame pitch detection
    pitch_data = []  # (center_sample, freq_hz, confidence)
    pos = 0
    while pos + frame_len <= len(audio):
        frame = audio[pos:pos + frame_len]
        freq, conf = _yin_pitch(frame, sr)
        if freq > 0 and conf >= min_confidence:
            midi = _freq_to_midi(freq)
            pitch_data.append((pos + frame_len // 2, freq, midi, conf))
        else:
            pitch_data.append((pos + frame_len // 2, 0.0, 0.0, 0.0))
        pos += hop_len

    if not pitch_data:
        return []

    # Segment into blobs: group consecutive voiced frames with similar pitch
    blobs: List[PitchBlob] = []
    blob_start = -1
    blob_freqs: List[float] = []
    blob_midis: List[float] = []
    blob_confs: List[float] = []
    blob_samples: List[int] = []

    blob_counter = 0

    for i, (center, freq, midi, conf) in enumerate(pitch_data):
        voiced = freq > 0 and conf >= min_confidence

        if voiced:
            if blob_start < 0:
                # Start new blob
                blob_start = center - frame_len // 2
                blob_freqs = [freq]
                blob_midis = [midi]
                blob_confs = [conf]
                blob_samples = [center]
            else:
                # Check if pitch is close enough to merge
                avg_midi = sum(blob_midis) / len(blob_midis)
                if abs(midi - avg_midi) * 100 <= merge_cents:
                    blob_freqs.append(freq)
                    blob_midis.append(midi)
                    blob_confs.append(conf)
                    blob_samples.append(center)
                else:
                    # Close current blob, start new
                    _close_blob(blobs, blob_start, center - hop_len // 2,
                                blob_freqs, blob_midis, blob_confs,
                                blob_counter, min_samples)
                    blob_counter += 1
                    blob_start = center - frame_len // 2
                    blob_freqs = [freq]
                    blob_midis = [midi]
                    blob_confs = [conf]
                    blob_samples = [center]
        else:
            if blob_start >= 0:
                # Close current blob
                _close_blob(blobs, blob_start, center - hop_len // 2,
                            blob_freqs, blob_midis, blob_confs,
                            blob_counter, min_samples)
                blob_counter += 1
                blob_start = -1
                blob_freqs = []
                blob_midis = []
                blob_confs = []
                blob_samples = []

    # Close last blob if open
    if blob_start >= 0 and blob_freqs:
        end_sample = min(len(audio), blob_samples[-1] + frame_len // 2)
        _close_blob(blobs, blob_start, end_sample,
                    blob_freqs, blob_midis, blob_confs,
                    blob_counter, min_samples)

    return blobs


def _close_blob(
    blobs: List[PitchBlob],
    start: int, end: int,
    freqs: List[float], midis: List[float], confs: List[float],
    counter: int, min_samples: int,
) -> None:
    """Create a PitchBlob from accumulated frame data."""
    if end - start < min_samples:
        return
    if not freqs:
        return

    avg_freq = sum(freqs) / len(freqs)
    avg_midi = sum(midis) / len(midis)
    avg_conf = sum(confs) / len(confs)

    blob = PitchBlob(
        id=f"pb_{counter:04d}",
        start_sample=max(0, int(start)),
        end_sample=max(0, int(end)),
        detected_freq_hz=float(avg_freq),
        detected_midi=float(avg_midi),
        target_midi=float(avg_midi),  # no correction by default
        confidence=float(avg_conf),
        is_corrected=False,
    )
    blobs.append(blob)


# ---------------------------------------------------------------------------
# Pitch correction (rendering)
# ---------------------------------------------------------------------------

def _pitch_shift_pv(audio: "np.ndarray", semitones: float, sr: int,
                    n_fft: int = 2048, hop: int = 512) -> "np.ndarray":
    """Pitch-shift mono audio by given semitones using phase vocoder.

    This is pitch-shift only (no time change): we time-stretch by the
    inverse ratio, then resample back to original length.
    """
    if np is None or abs(semitones) < 0.01:
        return audio

    ratio = 2.0 ** (semitones / 12.0)  # >1 = up, <1 = down
    # To pitch-shift: stretch time by 1/ratio, then resample by ratio
    from pydaw.audio.time_stretch import _pv_time_stretch_mono

    # Step 1: Time-stretch (preserves pitch, changes length)
    stretched = _pv_time_stretch_mono(audio, 1.0 / ratio, n_fft=n_fft, hop=hop)

    # Step 2: Resample back to original length (changes pitch)
    target_len = len(audio)
    if len(stretched) < 2:
        return audio

    indices = np.linspace(0.0, len(stretched) - 1, target_len, dtype=np.float64)
    idx_int = np.clip(indices.astype(np.int64), 0, len(stretched) - 2)
    idx_frac = (indices - idx_int).astype(np.float32)
    result = stretched[idx_int] * (1.0 - idx_frac) + stretched[idx_int + 1] * idx_frac

    return result.astype(np.float32)


def apply_pitch_corrections(
    audio: "np.ndarray",
    blobs: List[PitchBlob],
    sr: int = 48000,
    *,
    crossfade_ms: float = 5.0,
) -> "np.ndarray":
    """Apply pitch corrections to audio based on PitchBlob targets.

    Non-destructive: only modifies regions where is_corrected=True or
    target_midi != detected_midi.

    Parameters
    ----------
    audio : 1D float32 mono
    blobs : list of PitchBlob with target_midi set
    sr : sample rate
    crossfade_ms : crossfade at blob boundaries to avoid clicks

    Returns
    -------
    Corrected audio (same length as input).
    """
    if np is None:
        return audio

    audio = np.asarray(audio, dtype=np.float32).flatten()
    result = audio.copy()
    xfade_samples = max(1, int(crossfade_ms * 0.001 * sr))

    for blob in blobs:
        shift = blob.target_midi - blob.detected_midi
        if abs(shift) < 0.05:
            continue  # no correction needed

        start = max(0, blob.start_sample)
        end = min(len(audio), blob.end_sample)
        if end - start < 64:
            continue

        # Extract region with extra samples for crossfade
        pad = xfade_samples * 2
        region_start = max(0, start - pad)
        region_end = min(len(audio), end + pad)
        region = audio[region_start:region_end].copy()

        # Pitch-shift the region
        shifted = _pitch_shift_pv(region, shift, sr)

        if len(shifted) < (end - start):
            continue

        # Extract the corrected segment (without padding)
        offset = start - region_start
        corrected = shifted[offset:offset + (end - start)]

        if len(corrected) < (end - start):
            # Pad if needed
            corrected = np.pad(corrected, (0, (end - start) - len(corrected)))

        # Apply crossfade at boundaries
        seg_len = end - start
        if xfade_samples > 0 and seg_len > xfade_samples * 2:
            fade_in = np.linspace(0.0, 1.0, xfade_samples, dtype=np.float32)
            fade_out = np.linspace(1.0, 0.0, xfade_samples, dtype=np.float32)

            # Fade in: blend original → corrected
            corrected[:xfade_samples] = (
                audio[start:start + xfade_samples] * (1.0 - fade_in) +
                corrected[:xfade_samples] * fade_in
            )
            # Fade out: blend corrected → original
            corrected[-xfade_samples:] = (
                corrected[-xfade_samples:] * fade_out +
                audio[end - xfade_samples:end] * (1.0 - fade_out)
            )

        result[start:end] = corrected[:seg_len]

    return result


# ---------------------------------------------------------------------------
# Batch correction modes
# ---------------------------------------------------------------------------

def auto_correct_to_chromatic(blobs: List[PitchBlob]) -> List[PitchBlob]:
    """Snap all blobs to nearest semitone."""
    for blob in blobs:
        blob.target_midi = _snap_to_nearest_semitone(blob.detected_midi)
        blob.is_corrected = abs(blob.target_midi - blob.detected_midi) > 0.05
    return blobs


def auto_correct_to_scale(
    blobs: List[PitchBlob],
    scale_root: int = 0,
    scale_intervals: Optional[List[int]] = None,
) -> List[PitchBlob]:
    """Snap all blobs to nearest note in a musical scale."""
    for blob in blobs:
        blob.target_midi = _snap_to_scale(blob.detected_midi, scale_root, scale_intervals)
        blob.is_corrected = abs(blob.target_midi - blob.detected_midi) > 0.05
    return blobs


def set_correction_amount(blobs: List[PitchBlob], amount: float = 1.0) -> List[PitchBlob]:
    """Adjust correction strength. amount=0 → no correction, 1 → full snap."""
    amount = max(0.0, min(1.0, amount))
    for blob in blobs:
        if blob.is_corrected:
            snapped = blob.target_midi
            blob.target_midi = blob.detected_midi + (snapped - blob.detected_midi) * amount
    return blobs


# ---------------------------------------------------------------------------
# Scale definitions for UI
# ---------------------------------------------------------------------------

SCALES = {
    "Chromatic": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11],
    "Major": [0, 2, 4, 5, 7, 9, 11],
    "Minor (Natural)": [0, 2, 3, 5, 7, 8, 10],
    "Minor (Harmonic)": [0, 2, 3, 5, 7, 8, 11],
    "Minor (Melodic)": [0, 2, 3, 5, 7, 9, 11],
    "Pentatonic Major": [0, 2, 4, 7, 9],
    "Pentatonic Minor": [0, 3, 5, 7, 10],
    "Blues": [0, 3, 5, 6, 7, 10],
    "Dorian": [0, 2, 3, 5, 7, 9, 10],
    "Mixolydian": [0, 2, 4, 5, 7, 9, 10],
    "Phrygian": [0, 1, 3, 5, 7, 8, 10],
    "Lydian": [0, 2, 4, 6, 7, 9, 11],
    "Whole Tone": [0, 2, 4, 6, 8, 10],
}

SCALE_ROOTS = {
    "C": 0, "C#": 1, "D": 2, "D#": 3, "E": 4, "F": 5,
    "F#": 6, "G": 7, "G#": 8, "A": 9, "A#": 10, "B": 11,
}
