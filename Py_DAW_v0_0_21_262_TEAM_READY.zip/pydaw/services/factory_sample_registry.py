"""factory_sample_registry.py — SQLite-backed Factory Sample Definitions.

v0.0.20.889 — Phase 4 der SQLite Migration Roadmap.

Stores factory sample definitions (name, filename, category, generator, args)
in SQLite instead of hardcoded Python lists. RAM-cached for fast lookup.

Old factory_sample_gen.py lists (_DRUM_SAMPLES, _MELODIC_SAMPLES) remain
fully functional as fallback — this module only ADDS a database layer
for querying sample definitions without importing the generator.

Usage:
    from pydaw.services.factory_sample_registry import FactorySampleRegistry
    reg = FactorySampleRegistry.get()
    reg.ensure_loaded()
    drums = reg.get_by_category("drums")
    kick = reg.get_by_name("kick_808")
    all_samples = reg.get_all()
"""

import json
import sqlite3
import logging
from pathlib import Path
from typing import Dict, List, Optional

log = logging.getLogger(__name__)


class FactorySampleRegistry:
    """Factory sample definitions in SQLite, RAM-cached.

    Singleton. Loads all rows into dicts on first access.
    Does NOT generate samples — that stays in factory_sample_gen.py.
    This is purely a metadata registry for querying what samples exist.
    """

    _instance: Optional["FactorySampleRegistry"] = None

    @classmethod
    def get(cls) -> "FactorySampleRegistry":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._db_path = Path.home() / ".config" / "ChronoScaleStudio" / "pydaw.db"
        self._cache: List[dict] = []                    # all rows
        self._by_name: Dict[str, dict] = {}             # name → row
        self._by_category: Dict[str, List[dict]] = {}   # category → [rows]
        self._loaded = False

    def ensure_loaded(self) -> None:
        """Create table, seed factory data if empty, load into RAM. Idempotent."""
        if self._loaded:
            return
        try:
            self._init_db()
            self._load_to_ram()
            self._loaded = True
            log.info("[FactorySampleRegistry] Loaded %d sample definitions", len(self._cache))
        except Exception as e:
            log.warning("[FactorySampleRegistry] Failed to load: %s", e)

    # ── Public API ──────────────────────────────────────────────

    def get_all(self) -> List[dict]:
        """All sample definitions."""
        self.ensure_loaded()
        return list(self._cache)

    def get_by_name(self, name: str) -> Optional[dict]:
        """Single sample definition by name (e.g. 'kick_808')."""
        self.ensure_loaded()
        return self._by_name.get(name)

    def get_by_category(self, category: str) -> List[dict]:
        """All samples in a category ('drums' or 'melodic')."""
        self.ensure_loaded()
        return list(self._by_category.get(category, []))

    def get_filename(self, name: str) -> Optional[str]:
        """Get the WAV filename for a sample name."""
        self.ensure_loaded()
        row = self._by_name.get(name)
        return row.get("filename") if row else None

    def get_generator_info(self, name: str) -> Optional[dict]:
        """Get generator function name and args for a sample."""
        self.ensure_loaded()
        row = self._by_name.get(name)
        if not row:
            return None
        return {
            "generator": row.get("generator", ""),
            "args": json.loads(row.get("args", "[]")) if row.get("args") else [],
        }

    def get_sample_path(self, name: str) -> Optional[str]:
        """Get the expected filesystem path for a sample."""
        self.ensure_loaded()
        row = self._by_name.get(name)
        if not row:
            return None
        base = Path.home() / ".config" / "ChronoScaleStudio" / "factory_samples"
        category = row.get("category", "drums")
        filename = row.get("filename", f"{name}.wav")
        return str(base / category / filename)

    def get_all_paths_by_category(self, category: str) -> Dict[str, str]:
        """Return {name: expected_path} for all samples in a category."""
        self.ensure_loaded()
        base = Path.home() / ".config" / "ChronoScaleStudio" / "factory_samples"
        result = {}
        for row in self._by_category.get(category, []):
            name = row["name"]
            filename = row.get("filename", f"{name}.wav")
            cat = row.get("category", "drums")
            result[name] = str(base / cat / filename)
        return result

    def search_by_tags(self, query: str) -> List[dict]:
        """Simple tag-based search."""
        self.ensure_loaded()
        q = query.lower()
        results = []
        for row in self._cache:
            tags = (row.get("tags") or "").lower()
            desc = (row.get("description") or "").lower()
            name = (row.get("name") or "").lower()
            if q in tags or q in desc or q in name:
                results.append(row)
        return results

    def add_sample(self, name: str, filename: str, category: str,
                   generator: str, args: Optional[list] = None,
                   description: str = "", tags: str = "") -> bool:
        """Add or update a sample definition. Returns True on success."""
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.execute(
                    """INSERT OR REPLACE INTO factory_samples
                       (name, filename, category, generator, args, description, tags)
                       VALUES (?,?,?,?,?,?,?)""",
                    (name, filename, category, generator,
                     json.dumps(args or []),
                     description, tags)
                )
                conn.commit()
            finally:
                conn.close()
            self._loaded = False
            self.ensure_loaded()
            return True
        except Exception as e:
            log.warning("[FactorySampleRegistry] Failed to add sample: %s", e)
            return False

    # ── Internal ────────────────────────────────────────────────

    def _init_db(self) -> None:
        """Create table + seed factory data if empty."""
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(self._db_path))
        try:
            conn.executescript(_SCHEMA_SQL)
            count = conn.execute("SELECT COUNT(*) FROM factory_samples").fetchone()[0]
            if count == 0:
                self._seed_factory_data(conn)
            conn.commit()
        finally:
            conn.close()

    def _load_to_ram(self) -> None:
        """Load all rows into RAM for fast lookup."""
        conn = sqlite3.connect(str(self._db_path))
        conn.row_factory = sqlite3.Row
        try:
            rows = conn.execute("SELECT * FROM factory_samples ORDER BY category, name").fetchall()
            self._cache.clear()
            self._by_name.clear()
            self._by_category.clear()
            for row in rows:
                d = dict(row)
                name = d["name"]
                cat = d.get("category", "drums")
                self._cache.append(d)
                self._by_name[name] = d
                self._by_category.setdefault(cat, []).append(d)
        finally:
            conn.close()

    def _seed_factory_data(self, conn: sqlite3.Connection) -> None:
        """Insert all built-in sample definitions."""
        for row in _FACTORY_SAMPLES:
            try:
                conn.execute(
                    """INSERT OR IGNORE INTO factory_samples
                       (name, filename, category, generator, args, description, tags)
                       VALUES (?,?,?,?,?,?,?)""",
                    row
                )
            except Exception:
                pass


# ── Schema ──────────────────────────────────────────────────────

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS factory_samples (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    filename TEXT NOT NULL,
    category TEXT NOT NULL,
    generator TEXT NOT NULL,
    args TEXT,
    description TEXT,
    tags TEXT
);
CREATE INDEX IF NOT EXISTS idx_factory_samples_category ON factory_samples(category);
CREATE INDEX IF NOT EXISTS idx_factory_samples_name ON factory_samples(name);
"""

# ── Factory Data ────────────────────────────────────────────────
# Format: (name, filename, category, generator, args_json, description, tags)

_FACTORY_SAMPLES = [
    # ═══ DRUMS ═══
    ("kick_808", "kick_808.wav", "drums", "_synth_kick", '["808"]',
     "Classic 808 Kick — deep sub bass with pitch sweep", "kick,808,bass,sub,tr-808"),
    ("kick_909", "kick_909.wav", "drums", "_synth_kick", '["909"]',
     "909 Kick — punchy attack with body", "kick,909,punchy,tr-909"),
    ("kick_acoustic", "kick_acoustic.wav", "drums", "_synth_kick", '["acoustic"]',
     "Acoustic-style kick synthesis", "kick,acoustic,natural"),
    ("snare_808", "snare_808.wav", "drums", "_synth_snare", '["808"]',
     "808 Snare — short noise burst with tone", "snare,808,noise,tr-808"),
    ("snare_909", "snare_909.wav", "drums", "_synth_snare", '["909"]',
     "909 Snare — crispy noise with body", "snare,909,crispy,tr-909"),
    ("snare_acoustic", "snare_acoustic.wav", "drums", "_synth_snare", '["acoustic"]',
     "Acoustic-style snare synthesis", "snare,acoustic,natural"),
    ("hihat_closed", "hihat_closed.wav", "drums", "_synth_hihat", '[false]',
     "Closed Hi-Hat — short metallic", "hihat,closed,hat,metal"),
    ("hihat_open", "hihat_open.wav", "drums", "_synth_hihat", '[true]',
     "Open Hi-Hat — sustained metallic shimmer", "hihat,open,hat,metal,shimmer"),
    ("clap", "clap.wav", "drums", "_synth_clap", '[]',
     "Hand Clap — layered noise bursts", "clap,hand,noise"),
    ("tom_high", "tom_high.wav", "drums", "_synth_tom", '[200]',
     "High Tom — 200Hz pitch sweep", "tom,high,pitched"),
    ("tom_mid", "tom_mid.wav", "drums", "_synth_tom", '[140]',
     "Mid Tom — 140Hz pitch sweep", "tom,mid,pitched"),
    ("tom_low", "tom_low.wav", "drums", "_synth_tom", '[80]',
     "Low Tom — 80Hz deep sweep", "tom,low,deep"),
    ("cowbell", "cowbell.wav", "drums", "_synth_cowbell", '[]',
     "Cowbell — dual-oscillator metallic", "cowbell,bell,metal,percussion"),
    ("rim", "rim.wav", "drums", "_synth_rim", '[]',
     "Rim Shot — short filtered noise click", "rim,rimshot,click,percussion"),

    # ═══ MELODIC ═══
    ("bass_sub_A1", "bass_sub_A1.wav", "melodic", "_synth_bass", '[55, "sub"]',
     "Sub Bass A1 — pure sine 55Hz", "bass,sub,sine,A1,low"),
    ("bass_saw_A1", "bass_saw_A1.wav", "melodic", "_synth_bass", '[55, "saw"]',
     "Saw Bass A1 — filtered sawtooth", "bass,saw,sawtooth,A1,analog"),
    ("bass_square_A1", "bass_square_A1.wav", "melodic", "_synth_bass", '[55, "square"]',
     "Square Bass A1 — hollow square wave", "bass,square,hollow,A1"),
    ("pad_C4", "pad_C4.wav", "melodic", "_synth_pad", '[261.63, 2.0]',
     "Pad C4 — detuned saw pad 2s", "pad,saw,warm,C4,ambient"),
    ("pad_E4", "pad_E4.wav", "melodic", "_synth_pad", '[329.63, 2.0]',
     "Pad E4 — detuned saw pad 2s", "pad,saw,warm,E4,ambient"),
    ("pad_G4", "pad_G4.wav", "melodic", "_synth_pad", '[392.0, 2.0]',
     "Pad G4 — detuned saw pad 2s", "pad,saw,warm,G4,ambient"),
    ("pluck_A4", "pluck_A4.wav", "melodic", "_synth_pluck", '[440]',
     "Pluck A4 — Karplus-Strong string pluck", "pluck,string,A4,karplus"),
    ("pluck_C5", "pluck_C5.wav", "melodic", "_synth_pluck", '[523.25]',
     "Pluck C5 — Karplus-Strong string pluck", "pluck,string,C5,karplus"),
    ("pluck_E5", "pluck_E5.wav", "melodic", "_synth_pluck", '[659.25]',
     "Pluck E5 — Karplus-Strong string pluck", "pluck,string,E5,karplus"),
    ("bell_C5", "bell_C5.wav", "melodic", "_synth_bell", '[523.25]',
     "Bell C5 — FM bell with inharmonics", "bell,fm,C5,metallic"),
    ("bell_E5", "bell_E5.wav", "melodic", "_synth_bell", '[659.25]',
     "Bell E5 — FM bell with inharmonics", "bell,fm,E5,metallic"),
    ("string_A3", "string_A3.wav", "melodic", "_synth_string", '[220]',
     "String A3 — ensemble detuned saws", "string,ensemble,A3,analog"),
    ("string_D4", "string_D4.wav", "melodic", "_synth_string", '[293.66]',
     "String D4 — ensemble detuned saws", "string,ensemble,D4,analog"),
    ("organ_C4", "organ_C4.wav", "melodic", "_synth_organ", '[261.63]',
     "Organ C4 — Hammond-style drawbar organ", "organ,hammond,drawbar,C4"),
    ("lead_saw_A4", "lead_saw_A4.wav", "melodic", "_synth_lead", '[440, "saw"]',
     "Lead Saw A4 — bright filtered sawtooth", "lead,saw,bright,A4"),
    ("lead_square_A4", "lead_square_A4.wav", "melodic", "_synth_lead", '[440, "square"]',
     "Lead Square A4 — classic square lead", "lead,square,classic,A4"),
]
