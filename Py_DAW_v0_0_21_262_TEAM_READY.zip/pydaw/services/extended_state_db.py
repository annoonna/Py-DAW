"""extended_state_db.py — SQLite-backed state for remaining migration phases.

v0.0.20.893 — Phases 11, 14, 16-18, 23-24, 29-30.

This module covers all P5-dependent phases that don't warrant their own file:

Phase 11: AutomationState — Query API for automation (track→parameter)
Phase 14: UndoHistory — Undo snapshots in SQLite (crash recovery)
Phase 16: MacroRecordings — Saved macro recordings
Phase 17: CollabState — Collaboration session history
Phase 18: ScriptingHistory — Python scripting console history
Phase 23: NoteExpressions — MPE expression data index
Phase 24: GitIntegration — Git commit/branch history
Phase 29: FXSystem — FX chain presets and state
Phase 30: AudioEngineState — Engine config and benchmarks

All tables share the app-wide pydaw.db via DbManager pattern.

Usage:
    from pydaw.services.extended_state_db import ExtendedStateDB
    db = ExtendedStateDB.get()
    db.ensure_loaded()
    db.save_undo_snapshot(project_path, label, state_json)
    db.save_macro(name, actions_json, duration)
    db.add_script_history(code, result)
"""

import json
import sqlite3
import logging
import time
from pathlib import Path
from typing import Dict, List, Optional, Any

log = logging.getLogger(__name__)


_SCHEMA_SQL = """
-- Phase 14: Undo History (crash recovery)
CREATE TABLE IF NOT EXISTS undo_history (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    project_path    TEXT NOT NULL,
    label           TEXT NOT NULL DEFAULT '',
    state_json      TEXT NOT NULL DEFAULT '{}',
    created_at      REAL NOT NULL DEFAULT 0.0
);
CREATE INDEX IF NOT EXISTS idx_uh_proj ON undo_history(project_path, created_at DESC);

-- Phase 16: Macro Recordings
CREATE TABLE IF NOT EXISTS macro_recordings (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    name            TEXT NOT NULL DEFAULT 'Macro',
    description     TEXT NOT NULL DEFAULT '',
    actions_json    TEXT NOT NULL DEFAULT '[]',
    action_count    INTEGER NOT NULL DEFAULT 0,
    duration_sec    REAL NOT NULL DEFAULT 0.0,
    script_code     TEXT NOT NULL DEFAULT '',
    created_at      REAL NOT NULL DEFAULT 0.0
);

-- Phase 17: Collaboration Session History
CREATE TABLE IF NOT EXISTS collab_sessions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      TEXT NOT NULL DEFAULT '',
    project_path    TEXT NOT NULL DEFAULT '',
    host_user       TEXT NOT NULL DEFAULT '',
    peer_count      INTEGER NOT NULL DEFAULT 0,
    ops_synced      INTEGER NOT NULL DEFAULT 0,
    started_at      REAL NOT NULL DEFAULT 0.0,
    ended_at        REAL NOT NULL DEFAULT 0.0,
    status          TEXT NOT NULL DEFAULT 'completed'
);
CREATE INDEX IF NOT EXISTS idx_cs_proj ON collab_sessions(project_path);

-- Phase 18: Scripting History
CREATE TABLE IF NOT EXISTS script_history (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    code            TEXT NOT NULL DEFAULT '',
    result          TEXT NOT NULL DEFAULT '',
    success         INTEGER NOT NULL DEFAULT 1,
    executed_at     REAL NOT NULL DEFAULT 0.0
);
CREATE INDEX IF NOT EXISTS idx_sh_time ON script_history(executed_at DESC);

-- Phase 23: Note Expression Index
CREATE TABLE IF NOT EXISTS note_expression_index (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    project_path    TEXT NOT NULL,
    clip_id         TEXT NOT NULL,
    track_id        TEXT NOT NULL DEFAULT '',
    has_pitch_bend  INTEGER NOT NULL DEFAULT 0,
    has_pressure    INTEGER NOT NULL DEFAULT 0,
    has_slide       INTEGER NOT NULL DEFAULT 0,
    has_timbre      INTEGER NOT NULL DEFAULT 0,
    expression_count INTEGER NOT NULL DEFAULT 0,
    UNIQUE(project_path, clip_id)
);

-- Phase 24: Git Integration History
CREATE TABLE IF NOT EXISTS git_history (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    project_path    TEXT NOT NULL,
    commit_hash     TEXT NOT NULL DEFAULT '',
    branch          TEXT NOT NULL DEFAULT 'main',
    message         TEXT NOT NULL DEFAULT '',
    author          TEXT NOT NULL DEFAULT '',
    committed_at    REAL NOT NULL DEFAULT 0.0
);
CREATE INDEX IF NOT EXISTS idx_gh_proj ON git_history(project_path, committed_at DESC);

-- Phase 29: FX Chain Presets
CREATE TABLE IF NOT EXISTS fx_chain_presets (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    name            TEXT NOT NULL DEFAULT '',
    category        TEXT NOT NULL DEFAULT '',
    chain_json      TEXT NOT NULL DEFAULT '[]',
    device_count    INTEGER NOT NULL DEFAULT 0,
    description     TEXT NOT NULL DEFAULT '',
    is_factory      INTEGER NOT NULL DEFAULT 0,
    created_at      REAL NOT NULL DEFAULT 0.0
);

-- Phase 30: Audio Engine State
CREATE TABLE IF NOT EXISTS engine_state (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    key             TEXT NOT NULL UNIQUE,
    value           TEXT NOT NULL DEFAULT '',
    updated_at      REAL NOT NULL DEFAULT 0.0
);
"""


class ExtendedStateDB:
    """SQLite-backed state for phases 11, 14, 16-18, 23-24, 29-30.

    Singleton. All writes go directly to disk (WAL mode).
    """

    _instance: Optional["ExtendedStateDB"] = None
    _MAX_UNDO_SNAPSHOTS = 50  # Per project
    _MAX_SCRIPT_HISTORY = 500

    @classmethod
    def get(cls) -> "ExtendedStateDB":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._db_path = Path.home() / ".config" / "ChronoScaleStudio" / "pydaw.db"
        self._loaded = False

    def ensure_loaded(self) -> None:
        if self._loaded:
            return
        try:
            self._db_path.parent.mkdir(parents=True, exist_ok=True)
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.executescript(_SCHEMA_SQL)
                conn.commit()
            finally:
                conn.close()
            self._loaded = True
            log.info("[ExtendedStateDB] Tables ready")
        except Exception as e:
            log.warning("[ExtendedStateDB] Init failed: %s", e)

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self._db_path))
        conn.row_factory = sqlite3.Row
        return conn

    # ══════════════════════════════════════════════════════════════
    # Phase 14: Undo History (crash recovery)
    # ══════════════════════════════════════════════════════════════

    def save_undo_snapshot(self, project_path: str, label: str,
                           state_json: str) -> None:
        """Save an undo snapshot for crash recovery."""
        try:
            conn = self._conn()
            try:
                conn.execute(
                    "INSERT INTO undo_history (project_path, label, state_json, created_at) "
                    "VALUES (?, ?, ?, ?)",
                    (project_path, label, state_json, time.time()),
                )
                # Prune old snapshots
                conn.execute(
                    """DELETE FROM undo_history WHERE id NOT IN (
                       SELECT id FROM undo_history WHERE project_path=?
                       ORDER BY created_at DESC LIMIT ?
                    ) AND project_path=?""",
                    (project_path, self._MAX_UNDO_SNAPSHOTS, project_path),
                )
                conn.commit()
            finally:
                conn.close()
        except Exception as e:
            log.debug("[ExtendedStateDB] save_undo_snapshot failed: %s", e)

    def get_undo_snapshots(self, project_path: str,
                            limit: int = 20) -> List[dict]:
        """Get recent undo snapshots for a project."""
        try:
            conn = self._conn()
            try:
                rows = conn.execute(
                    "SELECT id, project_path, label, created_at FROM undo_history "
                    "WHERE project_path=? ORDER BY created_at DESC LIMIT ?",
                    (project_path, limit),
                ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    def get_undo_snapshot_state(self, snapshot_id: int) -> Optional[str]:
        """Get the full state JSON for a specific snapshot."""
        try:
            conn = self._conn()
            try:
                row = conn.execute(
                    "SELECT state_json FROM undo_history WHERE id=?",
                    (snapshot_id,),
                ).fetchone()
                return row["state_json"] if row else None
            finally:
                conn.close()
        except Exception:
            return None

    # ══════════════════════════════════════════════════════════════
    # Phase 16: Macro Recordings
    # ══════════════════════════════════════════════════════════════

    def save_macro(self, name: str, actions_json: str,
                   duration_sec: float = 0.0,
                   action_count: int = 0,
                   script_code: str = "",
                   description: str = "") -> int:
        """Save a macro recording. Returns ID."""
        try:
            conn = self._conn()
            try:
                cur = conn.execute(
                    """INSERT INTO macro_recordings
                       (name, description, actions_json, action_count,
                        duration_sec, script_code, created_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?)""",
                    (name, description, actions_json, action_count,
                     duration_sec, script_code, time.time()),
                )
                conn.commit()
                return cur.lastrowid or 0
            finally:
                conn.close()
        except Exception as e:
            log.debug("[ExtendedStateDB] save_macro failed: %s", e)
            return 0

    def get_macros(self, limit: int = 50) -> List[dict]:
        """Get saved macros (without full actions_json for speed)."""
        try:
            conn = self._conn()
            try:
                rows = conn.execute(
                    "SELECT id, name, description, action_count, duration_sec, created_at "
                    "FROM macro_recordings ORDER BY created_at DESC LIMIT ?",
                    (limit,),
                ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    def get_macro(self, macro_id: int) -> Optional[dict]:
        """Get a full macro recording including actions."""
        try:
            conn = self._conn()
            try:
                row = conn.execute(
                    "SELECT * FROM macro_recordings WHERE id=?",
                    (macro_id,),
                ).fetchone()
                return dict(row) if row else None
            finally:
                conn.close()
        except Exception:
            return None

    def delete_macro(self, macro_id: int) -> None:
        try:
            conn = self._conn()
            try:
                conn.execute("DELETE FROM macro_recordings WHERE id=?", (macro_id,))
                conn.commit()
            finally:
                conn.close()
        except Exception:
            pass

    # ══════════════════════════════════════════════════════════════
    # Phase 17: Collaboration Session History
    # ══════════════════════════════════════════════════════════════

    def log_collab_session(self, session_id: str, project_path: str,
                            host_user: str = "", peer_count: int = 0,
                            ops_synced: int = 0, started_at: float = 0.0,
                            ended_at: float = 0.0,
                            status: str = "completed") -> None:
        """Record a collaboration session."""
        try:
            conn = self._conn()
            try:
                conn.execute(
                    """INSERT INTO collab_sessions
                       (session_id, project_path, host_user, peer_count,
                        ops_synced, started_at, ended_at, status)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                    (session_id, project_path, host_user, peer_count,
                     ops_synced, started_at, ended_at or time.time(), status),
                )
                conn.commit()
            finally:
                conn.close()
        except Exception as e:
            log.debug("[ExtendedStateDB] log_collab_session failed: %s", e)

    def get_collab_sessions(self, project_path: str = "",
                             limit: int = 30) -> List[dict]:
        try:
            conn = self._conn()
            try:
                if project_path:
                    rows = conn.execute(
                        "SELECT * FROM collab_sessions WHERE project_path=? "
                        "ORDER BY started_at DESC LIMIT ?",
                        (project_path, limit),
                    ).fetchall()
                else:
                    rows = conn.execute(
                        "SELECT * FROM collab_sessions ORDER BY started_at DESC LIMIT ?",
                        (limit,),
                    ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    # ══════════════════════════════════════════════════════════════
    # Phase 18: Scripting History
    # ══════════════════════════════════════════════════════════════

    def add_script_history(self, code: str, result: str = "",
                            success: bool = True) -> None:
        """Record a script execution."""
        try:
            conn = self._conn()
            try:
                conn.execute(
                    "INSERT INTO script_history (code, result, success, executed_at) "
                    "VALUES (?, ?, ?, ?)",
                    (code, result, 1 if success else 0, time.time()),
                )
                # Prune old entries
                conn.execute(
                    """DELETE FROM script_history WHERE id NOT IN (
                       SELECT id FROM script_history ORDER BY executed_at DESC LIMIT ?
                    )""",
                    (self._MAX_SCRIPT_HISTORY,),
                )
                conn.commit()
            finally:
                conn.close()
        except Exception as e:
            log.debug("[ExtendedStateDB] add_script_history failed: %s", e)

    def get_script_history(self, limit: int = 50) -> List[dict]:
        try:
            conn = self._conn()
            try:
                rows = conn.execute(
                    "SELECT * FROM script_history ORDER BY executed_at DESC LIMIT ?",
                    (limit,),
                ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    def search_script_history(self, query: str, limit: int = 20) -> List[dict]:
        try:
            conn = self._conn()
            try:
                rows = conn.execute(
                    "SELECT * FROM script_history WHERE code LIKE ? "
                    "ORDER BY executed_at DESC LIMIT ?",
                    (f"%{query}%", limit),
                ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    # ══════════════════════════════════════════════════════════════
    # Phase 23: Note Expression Index
    # ══════════════════════════════════════════════════════════════

    def sync_note_expressions(self, project_path: str,
                               clip_id: str, track_id: str = "",
                               has_pitch_bend: bool = False,
                               has_pressure: bool = False,
                               has_slide: bool = False,
                               has_timbre: bool = False,
                               expression_count: int = 0) -> None:
        """Update expression index for a clip."""
        try:
            conn = self._conn()
            try:
                conn.execute(
                    """INSERT INTO note_expression_index
                       (project_path, clip_id, track_id,
                        has_pitch_bend, has_pressure, has_slide, has_timbre,
                        expression_count)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                       ON CONFLICT(project_path, clip_id) DO UPDATE SET
                           track_id=excluded.track_id,
                           has_pitch_bend=excluded.has_pitch_bend,
                           has_pressure=excluded.has_pressure,
                           has_slide=excluded.has_slide,
                           has_timbre=excluded.has_timbre,
                           expression_count=excluded.expression_count
                    """,
                    (project_path, clip_id, track_id,
                     1 if has_pitch_bend else 0, 1 if has_pressure else 0,
                     1 if has_slide else 0, 1 if has_timbre else 0,
                     expression_count),
                )
                conn.commit()
            finally:
                conn.close()
        except Exception as e:
            log.debug("[ExtendedStateDB] sync_note_expressions failed: %s", e)

    def get_clips_with_expressions(self, project_path: str) -> List[dict]:
        """Find all clips that have MPE expression data."""
        try:
            conn = self._conn()
            try:
                rows = conn.execute(
                    "SELECT * FROM note_expression_index WHERE project_path=? "
                    "AND expression_count > 0",
                    (project_path,),
                ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    # ══════════════════════════════════════════════════════════════
    # Phase 24: Git Integration History
    # ══════════════════════════════════════════════════════════════

    def log_git_commit(self, project_path: str, commit_hash: str,
                        branch: str = "main", message: str = "",
                        author: str = "") -> None:
        try:
            conn = self._conn()
            try:
                conn.execute(
                    """INSERT INTO git_history
                       (project_path, commit_hash, branch, message, author, committed_at)
                       VALUES (?, ?, ?, ?, ?, ?)""",
                    (project_path, commit_hash, branch, message, author, time.time()),
                )
                conn.commit()
            finally:
                conn.close()
        except Exception as e:
            log.debug("[ExtendedStateDB] log_git_commit failed: %s", e)

    def get_git_history(self, project_path: str,
                         limit: int = 50) -> List[dict]:
        try:
            conn = self._conn()
            try:
                rows = conn.execute(
                    "SELECT * FROM git_history WHERE project_path=? "
                    "ORDER BY committed_at DESC LIMIT ?",
                    (project_path, limit),
                ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    # ══════════════════════════════════════════════════════════════
    # Phase 29: FX Chain Presets
    # ══════════════════════════════════════════════════════════════

    def save_fx_chain_preset(self, name: str, chain_json: str,
                              category: str = "", device_count: int = 0,
                              description: str = "",
                              is_factory: bool = False) -> int:
        """Save an FX chain preset. Returns ID."""
        try:
            conn = self._conn()
            try:
                cur = conn.execute(
                    """INSERT INTO fx_chain_presets
                       (name, category, chain_json, device_count,
                        description, is_factory, created_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?)""",
                    (name, category, chain_json, device_count,
                     description, 1 if is_factory else 0, time.time()),
                )
                conn.commit()
                return cur.lastrowid or 0
            finally:
                conn.close()
        except Exception as e:
            log.debug("[ExtendedStateDB] save_fx_chain_preset failed: %s", e)
            return 0

    def get_fx_chain_presets(self, category: str = "",
                              limit: int = 100) -> List[dict]:
        try:
            conn = self._conn()
            try:
                if category:
                    rows = conn.execute(
                        "SELECT * FROM fx_chain_presets WHERE category=? "
                        "ORDER BY name LIMIT ?",
                        (category, limit),
                    ).fetchall()
                else:
                    rows = conn.execute(
                        "SELECT * FROM fx_chain_presets ORDER BY name LIMIT ?",
                        (limit,),
                    ).fetchall()
                return [dict(r) for r in rows]
            finally:
                conn.close()
        except Exception:
            return []

    def delete_fx_chain_preset(self, preset_id: int) -> None:
        try:
            conn = self._conn()
            try:
                conn.execute(
                    "DELETE FROM fx_chain_presets WHERE id=? AND is_factory=0",
                    (preset_id,),
                )
                conn.commit()
            finally:
                conn.close()
        except Exception:
            pass

    # ══════════════════════════════════════════════════════════════
    # Phase 30: Audio Engine State
    # ══════════════════════════════════════════════════════════════

    def set_engine_state(self, key: str, value: str) -> None:
        """Store an engine config key-value pair."""
        try:
            conn = self._conn()
            try:
                conn.execute(
                    """INSERT INTO engine_state (key, value, updated_at)
                       VALUES (?, ?, ?)
                       ON CONFLICT(key) DO UPDATE SET
                           value=excluded.value, updated_at=excluded.updated_at""",
                    (key, value, time.time()),
                )
                conn.commit()
            finally:
                conn.close()
        except Exception as e:
            log.debug("[ExtendedStateDB] set_engine_state failed: %s", e)

    def get_engine_state(self, key: str, default: str = "") -> str:
        """Get an engine config value."""
        try:
            conn = self._conn()
            try:
                row = conn.execute(
                    "SELECT value FROM engine_state WHERE key=?", (key,),
                ).fetchone()
                return str(row["value"]) if row else default
            finally:
                conn.close()
        except Exception:
            return default

    def get_all_engine_state(self) -> Dict[str, str]:
        """Get all engine state key-value pairs."""
        try:
            conn = self._conn()
            try:
                rows = conn.execute("SELECT key, value FROM engine_state").fetchall()
                return {r["key"]: r["value"] for r in rows}
            finally:
                conn.close()
        except Exception:
            return {}

    # ══════════════════════════════════════════════════════════════
    # Maintenance
    # ══════════════════════════════════════════════════════════════

    def stats(self) -> Dict[str, int]:
        """Return row counts per table."""
        result = {}
        tables = ("undo_history", "macro_recordings", "collab_sessions",
                  "script_history", "note_expression_index", "git_history",
                  "fx_chain_presets", "engine_state")
        try:
            conn = self._conn()
            try:
                for table in tables:
                    row = conn.execute(f"SELECT COUNT(*) as cnt FROM {table}").fetchone()
                    result[table] = int(row["cnt"]) if row else 0
            finally:
                conn.close()
        except Exception:
            pass
        return result
