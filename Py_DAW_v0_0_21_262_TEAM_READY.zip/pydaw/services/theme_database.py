"""theme_database.py — SQLite-backed Theme System.

v0.0.20.890 — Phase 9 der SQLite Migration Roadmap.

Stores theme definitions (palette, fonts, CSS overrides) in SQLite.
Old system (BUILTIN_THEMES dict in theme_manager.py) remains as fallback.

User-created themes are persisted in DB and survive app updates.
Built-in themes are seeded on first run.

Usage:
    from pydaw.services.theme_database import ThemeDatabase
    db = ThemeDatabase.get()
    db.ensure_loaded()

    themes = db.get_all()
    dark = db.get_theme("dark")
    active = db.get_active_theme()
    db.set_active("midnight")

    # Custom theme
    db.save_theme("my_theme", "My Custom Theme",
                  palette={"bg_primary": "#111", "accent_primary": "#f0f"},
                  font_family="JetBrains Mono", font_size=12)
"""

import json
import sqlite3
import logging
from pathlib import Path
from typing import Dict, List, Optional

log = logging.getLogger(__name__)


class ThemeDatabase:
    """SQLite-backed theme store.

    Singleton. Themes cached in RAM. Writes go to disk immediately
    (themes change very rarely).
    """

    _instance: Optional["ThemeDatabase"] = None

    @classmethod
    def get(cls) -> "ThemeDatabase":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._db_path = Path.home() / ".config" / "ChronoScaleStudio" / "pydaw.db"
        self._cache: Dict[str, dict] = {}       # theme_id → row
        self._active_id: Optional[str] = None
        self._loaded = False

    def ensure_loaded(self) -> None:
        """Create table, seed built-in themes, load into RAM. Idempotent."""
        if self._loaded:
            return
        try:
            self._init_db()
            self._load_to_ram()
            self._loaded = True
            log.info("[ThemeDB] Loaded %d themes, active=%s",
                     len(self._cache), self._active_id)
        except Exception as e:
            log.warning("[ThemeDB] Failed to load: %s", e)

    # ── Public API ──────────────────────────────────────────────

    def get_all(self) -> List[dict]:
        """All themes sorted by name."""
        self.ensure_loaded()
        return sorted(self._cache.values(), key=lambda t: t.get("name", ""))

    def get_theme(self, theme_id: str) -> Optional[dict]:
        """Get a theme by ID."""
        self.ensure_loaded()
        return self._cache.get(theme_id)

    def get_active_theme(self) -> Optional[dict]:
        """Get the currently active theme."""
        self.ensure_loaded()
        if self._active_id:
            return self._cache.get(self._active_id)
        return self._cache.get("dark")  # fallback

    def get_active_id(self) -> str:
        """Get the active theme ID."""
        self.ensure_loaded()
        return self._active_id or "dark"

    def set_active(self, theme_id: str) -> bool:
        """Set the active theme."""
        self.ensure_loaded()
        if theme_id not in self._cache:
            return False
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.execute("UPDATE themes SET is_active = 0")
                conn.execute(
                    "UPDATE themes SET is_active = 1 WHERE id = ?", (theme_id,))
                conn.commit()
            finally:
                conn.close()
            self._active_id = theme_id
            # Update cache
            for tid, t in self._cache.items():
                t["is_active"] = 1 if tid == theme_id else 0
            return True
        except Exception:
            return False

    def get_palette(self, theme_id: str) -> Dict[str, str]:
        """Get the color palette dict for a theme."""
        self.ensure_loaded()
        t = self._cache.get(theme_id)
        if not t:
            return {}
        try:
            return json.loads(t.get("palette", "{}"))
        except Exception:
            return {}

    def get_builtin_ids(self) -> List[str]:
        """Get IDs of all built-in themes."""
        self.ensure_loaded()
        return [tid for tid, t in self._cache.items() if t.get("is_builtin")]

    def get_user_ids(self) -> List[str]:
        """Get IDs of all user-created themes."""
        self.ensure_loaded()
        return [tid for tid, t in self._cache.items() if not t.get("is_builtin")]

    def save_theme(self, theme_id: str, name: str, palette: dict,
                   font_family: str = "sans-serif", font_size: int = 11,
                   css_overrides: str = "", is_builtin: bool = False) -> bool:
        """Save or update a theme."""
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.execute(
                    """INSERT OR REPLACE INTO themes
                       (id, name, is_builtin, is_active, palette, css_overrides,
                        font_family, font_size)
                       VALUES (?,?,?,0,?,?,?,?)""",
                    (theme_id, name, int(is_builtin),
                     json.dumps(palette, ensure_ascii=False),
                     css_overrides, font_family, font_size)
                )
                conn.commit()
            finally:
                conn.close()
            self._loaded = False
            self.ensure_loaded()
            return True
        except Exception as e:
            log.warning("[ThemeDB] save_theme failed: %s", e)
            return False

    def delete_theme(self, theme_id: str) -> bool:
        """Delete a user theme (cannot delete built-in)."""
        self.ensure_loaded()
        t = self._cache.get(theme_id)
        if not t or t.get("is_builtin"):
            return False
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.execute("DELETE FROM themes WHERE id = ? AND is_builtin = 0",
                             (theme_id,))
                conn.commit()
            finally:
                conn.close()
            self._cache.pop(theme_id, None)
            if self._active_id == theme_id:
                self.set_active("dark")
            return True
        except Exception:
            return False

    def duplicate_theme(self, source_id: str, new_id: str, new_name: str) -> bool:
        """Duplicate a theme (for user customization)."""
        self.ensure_loaded()
        source = self._cache.get(source_id)
        if not source:
            return False
        palette = {}
        try:
            palette = json.loads(source.get("palette", "{}"))
        except Exception:
            pass
        return self.save_theme(
            new_id, new_name, palette,
            font_family=source.get("font_family", "sans-serif"),
            font_size=int(source.get("font_size", 11)),
            css_overrides=source.get("css_overrides", ""),
            is_builtin=False
        )

    # ── Internal ────────────────────────────────────────────────

    def _init_db(self) -> None:
        """Create table + seed factory themes."""
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(self._db_path))
        try:
            conn.executescript(_SCHEMA_SQL)
            count = conn.execute("SELECT COUNT(*) FROM themes").fetchone()[0]
            if count == 0:
                self._seed_factory_themes(conn)
            conn.commit()
        finally:
            conn.close()

    def _load_to_ram(self) -> None:
        """Load all themes into RAM."""
        conn = sqlite3.connect(str(self._db_path))
        conn.row_factory = sqlite3.Row
        try:
            rows = conn.execute("SELECT * FROM themes").fetchall()
            self._cache.clear()
            self._active_id = None
            for row in rows:
                d = dict(row)
                d["is_builtin"] = bool(d.get("is_builtin", 0))
                d["is_active"] = bool(d.get("is_active", 0))
                tid = d["id"]
                self._cache[tid] = d
                if d["is_active"]:
                    self._active_id = tid
        finally:
            conn.close()

    def _seed_factory_themes(self, conn: sqlite3.Connection) -> None:
        """Seed built-in themes."""
        for tid, name, palette, font_fam, font_sz in _FACTORY_THEMES:
            try:
                is_active = 1 if tid == "dark" else 0
                conn.execute(
                    """INSERT OR IGNORE INTO themes
                       (id, name, is_builtin, is_active, palette, css_overrides,
                        font_family, font_size)
                       VALUES (?,?,1,?,?,?,?,?)""",
                    (tid, name, is_active,
                     json.dumps(palette, ensure_ascii=False),
                     "", font_fam, font_sz)
                )
            except Exception:
                pass


# ── Schema ──────────────────────────────────────────────────────

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS themes (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    is_builtin INTEGER DEFAULT 0,
    is_active INTEGER DEFAULT 0,
    palette TEXT NOT NULL,
    css_overrides TEXT,
    font_family TEXT DEFAULT 'sans-serif',
    font_size INTEGER DEFAULT 11,
    created_at TEXT DEFAULT (datetime('now'))
);
"""

# ── Factory Themes ──────────────────────────────────────────────
# Format: (id, name, palette_dict, font_family, font_size)

_FACTORY_THEMES = [
    ("dark", "Dark", {
        "bg_primary": "#1e1e1e", "bg_secondary": "#252525", "bg_tertiary": "#2d2d2d",
        "bg_hover": "#3a3a3a", "bg_selected": "#37474f", "bg_header": "#1a1a1a",
        "fg_primary": "#eeeeee", "fg_secondary": "#b0b0b0", "fg_muted": "#666666",
        "fg_accent": "#4fc3f7", "accent_primary": "#4fc3f7", "accent_secondary": "#81c784",
        "accent_warning": "#ff9800", "accent_error": "#f44336", "accent_success": "#4caf50",
        "track_bg": "#2a2a2a", "clip_bg": "#3a5f3a", "clip_selected": "#4a7f4a",
        "playhead": "#ffffff", "grid_line": "#333333", "grid_bar": "#444444",
        "waveform": "#81c784", "midi_note": "#66bb6a", "automation": "#ff9800",
        "meter_green": "#4caf50", "meter_yellow": "#ff9800", "meter_red": "#f44336",
        "border": "#444444", "border_focus": "#4fc3f7", "border_subtle": "#333333",
    }, "sans-serif", 11),
    ("light", "Light", {
        "bg_primary": "#f5f5f5", "bg_secondary": "#e8e8e8", "bg_tertiary": "#ffffff",
        "bg_hover": "#d0d0d0", "bg_selected": "#bbdefb", "bg_header": "#e0e0e0",
        "fg_primary": "#212121", "fg_secondary": "#616161", "fg_muted": "#9e9e9e",
        "fg_accent": "#1565c0", "accent_primary": "#1565c0", "accent_secondary": "#2e7d32",
        "accent_warning": "#e65100", "accent_error": "#c62828", "accent_success": "#2e7d32",
        "track_bg": "#eeeeee", "clip_bg": "#c8e6c9", "clip_selected": "#a5d6a7",
        "playhead": "#000000", "grid_line": "#d0d0d0", "grid_bar": "#b0b0b0",
        "waveform": "#388e3c", "midi_note": "#43a047", "automation": "#e65100",
        "meter_green": "#4caf50", "meter_yellow": "#ff9800", "meter_red": "#f44336",
        "border": "#bdbdbd", "border_focus": "#1565c0", "border_subtle": "#e0e0e0",
    }, "sans-serif", 11),
    ("midnight", "Midnight", {
        "bg_primary": "#0d1117", "bg_secondary": "#161b22", "bg_tertiary": "#21262d",
        "bg_hover": "#30363d", "bg_selected": "#1f3a5f", "bg_header": "#010409",
        "fg_primary": "#e6edf3", "fg_secondary": "#8b949e", "fg_muted": "#484f58",
        "fg_accent": "#58a6ff", "accent_primary": "#58a6ff", "accent_secondary": "#3fb950",
        "accent_warning": "#d29922", "accent_error": "#f85149", "accent_success": "#3fb950",
        "track_bg": "#161b22", "clip_bg": "#1a3a2a", "clip_selected": "#264f36",
        "playhead": "#f0f6fc", "grid_line": "#21262d", "grid_bar": "#30363d",
        "waveform": "#3fb950", "midi_note": "#56d364", "automation": "#d29922",
        "meter_green": "#3fb950", "meter_yellow": "#d29922", "meter_red": "#f85149",
        "border": "#30363d", "border_focus": "#58a6ff", "border_subtle": "#21262d",
    }, "sans-serif", 11),
    ("solarized_dark", "Solarized Dark", {
        "bg_primary": "#002b36", "bg_secondary": "#073642", "bg_tertiary": "#073642",
        "bg_hover": "#586e75", "bg_selected": "#2aa198", "bg_header": "#001f28",
        "fg_primary": "#fdf6e3", "fg_secondary": "#93a1a1", "fg_muted": "#586e75",
        "fg_accent": "#268bd2", "accent_primary": "#268bd2", "accent_secondary": "#859900",
        "accent_warning": "#cb4b16", "accent_error": "#dc322f", "accent_success": "#859900",
        "track_bg": "#073642", "clip_bg": "#2a4a3a", "clip_selected": "#3a6a4a",
        "playhead": "#eee8d5", "grid_line": "#073642", "grid_bar": "#586e75",
        "waveform": "#859900", "midi_note": "#859900", "automation": "#cb4b16",
        "meter_green": "#859900", "meter_yellow": "#b58900", "meter_red": "#dc322f",
        "border": "#586e75", "border_focus": "#268bd2", "border_subtle": "#073642",
    }, "sans-serif", 11),
    ("high_contrast", "High Contrast", {
        "bg_primary": "#000000", "bg_secondary": "#1a1a1a", "bg_tertiary": "#2a2a2a",
        "bg_hover": "#444444", "bg_selected": "#005a9e", "bg_header": "#000000",
        "fg_primary": "#ffffff", "fg_secondary": "#e0e0e0", "fg_muted": "#808080",
        "fg_accent": "#00d4ff", "accent_primary": "#00d4ff", "accent_secondary": "#00ff00",
        "accent_warning": "#ffff00", "accent_error": "#ff0000", "accent_success": "#00ff00",
        "track_bg": "#1a1a1a", "clip_bg": "#006600", "clip_selected": "#009900",
        "playhead": "#ffffff", "grid_line": "#444444", "grid_bar": "#666666",
        "waveform": "#00ff00", "midi_note": "#00ff00", "automation": "#ffff00",
        "meter_green": "#00ff00", "meter_yellow": "#ffff00", "meter_red": "#ff0000",
        "border": "#808080", "border_focus": "#00d4ff", "border_subtle": "#444444",
    }, "sans-serif", 12),
]
