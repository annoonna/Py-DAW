"""param_registry.py — Zentrale Parameter-Registry, SQLite-backed, RAM-cached.

v0.0.20.887 — Phase 1 der SQLite Migration Roadmap.

Beim Start: DB → RAM (dict of dicts).
Laufzeit: nur dict lookups (<1µs).
Schreiben: selten (nur bei Plugin-Änderungen).

Usage:
    from pydaw.services.param_registry import ParamRegistry
    reg = ParamRegistry.get()
    reg.ensure_loaded()
    params = reg.get_params("aeterna")
    knob_val = reg.convert_to_knob("aeterna", "filter_cutoff", 5000)
"""

import sqlite3
import logging
from pathlib import Path
from typing import Dict, List, Optional, Any

log = logging.getLogger(__name__)


class ParamRegistry:
    """Zentrale Parameter-Registry — SQLite-backed, RAM-cached.

    Singleton. Beim Start: DB → RAM.
    Laufzeit: nur dict lookups (<1µs).
    """

    _instance: Optional["ParamRegistry"] = None

    @classmethod
    def get(cls) -> "ParamRegistry":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._db_path = Path.home() / ".config" / "ChronoScaleStudio" / "param_registry.db"
        self._cache: Dict[str, Dict[str, dict]] = {}   # instrument → param_name → row
        self._plugin_cache: Dict[str, str] = {}          # plugin_id → instrument
        self._loaded = False

    def ensure_loaded(self) -> None:
        """Load DB into RAM cache. Idempotent."""
        if self._loaded:
            return
        try:
            self._init_db()
            self._load_to_ram()
            self._loaded = True
            log.info("[ParamRegistry] Loaded %d instruments, %d total params",
                     len(self._cache),
                     sum(len(v) for v in self._cache.values()))
        except Exception as e:
            log.warning("[ParamRegistry] Failed to load: %s", e)

    def _init_db(self) -> None:
        """Create DB + tables if not exists. Seed with factory data."""
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(self._db_path))
        try:
            conn.executescript(_SCHEMA_SQL)
            # Check if empty → seed
            count = conn.execute("SELECT COUNT(*) FROM param_registry").fetchone()[0]
            if count == 0:
                self._seed_factory_data(conn)
            conn.commit()
        finally:
            conn.close()

    def _load_to_ram(self) -> None:
        """Load entire DB into nested dicts for O(1) lookup."""
        conn = sqlite3.connect(str(self._db_path))
        conn.row_factory = sqlite3.Row
        try:
            rows = conn.execute("SELECT * FROM param_registry").fetchall()
            self._cache.clear()
            self._plugin_cache.clear()
            for row in rows:
                inst = row["instrument"]
                pname = row["param_name"]
                if inst not in self._cache:
                    self._cache[inst] = {}
                self._cache[inst][pname] = dict(row)
                # Plugin ID → instrument mapping
                pid = row["plugin_id"]
                if pid and pid not in self._plugin_cache:
                    self._plugin_cache[pid] = inst
        finally:
            conn.close()

    # ── Public API ──────────────────────────────────────────────

    def get_instrument(self, plugin_id: str) -> str:
        """plugin_id → instrument name."""
        self.ensure_loaded()
        return self._plugin_cache.get(plugin_id, "")

    def get_params(self, instrument: str) -> Dict[str, dict]:
        """All params for an instrument as {param_name: row_dict}."""
        self.ensure_loaded()
        return dict(self._cache.get(instrument, {}))

    def get_param(self, instrument: str, param_name: str) -> Optional[dict]:
        """Single param definition."""
        self.ensure_loaded()
        return self._cache.get(instrument, {}).get(param_name)

    def list_instruments(self) -> List[str]:
        """List all known instrument names."""
        self.ensure_loaded()
        return list(self._cache.keys())

    def get_params_by_category(self, instrument: str, category: str) -> Dict[str, dict]:
        """Get all params for an instrument filtered by category."""
        self.ensure_loaded()
        return {
            k: v for k, v in self._cache.get(instrument, {}).items()
            if v.get("category") == category
        }

    def search_params(self, query: str) -> List[dict]:
        """Search params across all instruments by name or tags."""
        self.ensure_loaded()
        q = query.lower()
        results = []
        for inst_params in self._cache.values():
            for pdef in inst_params.values():
                name = str(pdef.get("param_name", "")).lower()
                tags = str(pdef.get("tags", "")).lower()
                desc = str(pdef.get("description", "")).lower()
                if q in name or q in tags or q in desc:
                    results.append(pdef)
        return results

    def convert_to_knob(self, instrument: str, param_name: str, value: float) -> int:
        """Convert a real-world value (Hz, seconds, etc.) to a knob integer.

        Uses the value_type field to determine scaling:
        - linear: proportional mapping
        - exponential: sqrt mapping (knob → value is squared)
        - quadratic: square mapping
        - boolean: 0 or knob_max
        - discrete: round to nearest int
        """
        p = self.get_param(instrument, param_name)
        if p is None:
            return 50

        vtype = p.get("value_type", "linear")
        in_min = float(p.get("input_min", 0))
        in_max = float(p.get("input_max", 1))
        k_min = int(p.get("knob_min", 0))
        k_max = int(p.get("knob_max", 100))

        if vtype == "boolean":
            return k_max if float(value) > 0.5 else k_min

        # Normalize to 0..1
        span = in_max - in_min
        if span <= 0:
            return k_min
        normalized = max(0.0, min(1.0, (float(value) - in_min) / span))

        # Apply curve
        if vtype == "exponential":
            normalized = normalized ** 0.5   # sqrt → knob space
        elif vtype == "quadratic":
            normalized = normalized ** 2.0

        # Scale to knob range
        return int(round(k_min + normalized * (k_max - k_min)))

    def convert_from_knob(self, instrument: str, param_name: str, knob_value: int) -> float:
        """Convert a knob integer back to a real-world value."""
        p = self.get_param(instrument, param_name)
        if p is None:
            return float(knob_value)

        vtype = p.get("value_type", "linear")
        in_min = float(p.get("input_min", 0))
        in_max = float(p.get("input_max", 1))
        k_min = int(p.get("knob_min", 0))
        k_max = int(p.get("knob_max", 100))

        if vtype == "boolean":
            return 1.0 if int(knob_value) > (k_min + k_max) // 2 else 0.0

        # Normalize knob to 0..1
        k_span = k_max - k_min
        if k_span <= 0:
            return in_min
        normalized = max(0.0, min(1.0, (float(knob_value) - k_min) / k_span))

        # Reverse curve
        if vtype == "exponential":
            normalized = normalized ** 2.0   # square to reverse sqrt
        elif vtype == "quadratic":
            normalized = normalized ** 0.5   # sqrt to reverse square

        return in_min + normalized * (in_max - in_min)

    def convert_to_engine(self, instrument: str, param_name: str, value: float) -> float:
        """Convert a real-world value to engine value."""
        p = self.get_param(instrument, param_name)
        if p is None:
            return float(value)

        e_min = float(p.get("engine_min", 0))
        e_max = float(p.get("engine_max", 1))
        in_min = float(p.get("input_min", 0))
        in_max = float(p.get("input_max", 1))

        span = in_max - in_min
        if span <= 0:
            return e_min
        normalized = max(0.0, min(1.0, (float(value) - in_min) / span))

        return e_min + normalized * (e_max - e_min)

    def apply_preset(self, widget: Any, plugin_id: str, params: dict) -> int:
        """Universal preset apply — uses registry to route params correctly.

        Returns: number of params successfully applied.
        """
        instrument = self.get_instrument(plugin_id)
        if not instrument:
            return 0

        registry = self.get_params(instrument)
        if not registry:
            return 0

        applied = 0
        knobs = getattr(widget, "_knobs", None)
        engine = getattr(widget, "engine", None)

        for param_name, value in params.items():
            if param_name.startswith("__"):
                continue  # skip meta keys

            pdef = registry.get(param_name)
            if pdef is None:
                continue

            method = pdef.get("apply_method", "set_param")
            engine_key = pdef.get("engine_key", param_name)
            knob_key = pdef.get("knob_key") or engine_key

            try:
                if method == "set_param" and engine and hasattr(engine, "set_param"):
                    engine_val = self.convert_to_engine(instrument, param_name, value)
                    engine.set_param(engine_key, engine_val)
                    applied += 1

                elif method == "knob_direct" and isinstance(knobs, dict):
                    knob = knobs.get(knob_key)
                    if knob is not None:
                        knob_val = self.convert_to_knob(instrument, param_name, value)
                        knob.blockSignals(True)
                        try:
                            knob.setValue(knob_val)
                        finally:
                            knob.blockSignals(False)
                        applied += 1

                # Update UI knob if available (even for set_param method)
                if isinstance(knobs, dict) and knob_key in knobs:
                    knob = knobs[knob_key]
                    knob_val = self.convert_to_knob(instrument, param_name, value)
                    try:
                        if hasattr(knob, "setValueExternal"):
                            knob.setValueExternal(knob_val)
                        else:
                            knob.blockSignals(True)
                            try:
                                knob.setValue(knob_val)
                            finally:
                                knob.blockSignals(False)
                    except Exception:
                        pass

            except Exception as e:
                log.debug("[ParamRegistry] apply_preset %s.%s failed: %s",
                          instrument, param_name, e)

        return applied

    def add_param(self, instrument: str, plugin_id: str, param_name: str,
                  engine_key: str, **kwargs) -> None:
        """Add or update a parameter definition (writes to DB + cache)."""
        self.ensure_loaded()
        conn = sqlite3.connect(str(self._db_path))
        try:
            knob_key = kwargs.get("knob_key", engine_key)
            conn.execute(
                "INSERT OR REPLACE INTO param_registry "
                "(instrument, plugin_id, param_name, engine_key, knob_key, "
                " value_type, input_min, input_max, knob_min, knob_max, "
                " engine_min, engine_max, default_value, category, tags, "
                " description, unit, apply_method) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (instrument, plugin_id, param_name, engine_key, knob_key,
                 kwargs.get("value_type", "linear"),
                 kwargs.get("input_min", 0.0),
                 kwargs.get("input_max", 1.0),
                 kwargs.get("knob_min", 0),
                 kwargs.get("knob_max", 100),
                 kwargs.get("engine_min", 0.0),
                 kwargs.get("engine_max", 1.0),
                 kwargs.get("default_value", 0.5),
                 kwargs.get("category"),
                 kwargs.get("tags"),
                 kwargs.get("description"),
                 kwargs.get("unit"),
                 kwargs.get("apply_method", "set_param"))
            )
            conn.commit()
        finally:
            conn.close()
        # Reload cache
        self._loaded = False
        self.ensure_loaded()

    def _seed_factory_data(self, conn: sqlite3.Connection) -> None:
        """Seed the registry with all known instrument parameters."""
        for row in _FACTORY_PARAMS:
            try:
                conn.execute(
                    "INSERT OR IGNORE INTO param_registry "
                    "(instrument, plugin_id, param_name, engine_key, knob_key, "
                    " value_type, input_min, input_max, knob_min, knob_max, "
                    " engine_min, engine_max, default_value, category, tags, "
                    " description, unit, apply_method) "
                    "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    row
                )
            except Exception:
                pass
        log.info("[ParamRegistry] Seeded %d factory params", len(_FACTORY_PARAMS))


# ── Schema SQL ──────────────────────────────────────────────────

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS param_registry (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    instrument TEXT NOT NULL,
    plugin_id TEXT NOT NULL,
    param_name TEXT NOT NULL,
    engine_key TEXT NOT NULL,
    knob_key TEXT,
    value_type TEXT DEFAULT 'linear',
    input_min REAL DEFAULT 0.0,
    input_max REAL DEFAULT 1.0,
    knob_min INTEGER DEFAULT 0,
    knob_max INTEGER DEFAULT 100,
    engine_min REAL DEFAULT 0.0,
    engine_max REAL DEFAULT 1.0,
    default_value REAL DEFAULT 0.5,
    category TEXT,
    tags TEXT,
    description TEXT,
    unit TEXT,
    apply_method TEXT DEFAULT 'set_param',
    apply_detail TEXT,
    UNIQUE(instrument, param_name)
);
CREATE INDEX IF NOT EXISTS idx_param_instrument ON param_registry(instrument);
CREATE INDEX IF NOT EXISTS idx_param_plugin ON param_registry(plugin_id);
CREATE INDEX IF NOT EXISTS idx_param_category ON param_registry(category);
"""

# ── Factory Data ──────────────────────────────────────────────────
# Format: (instrument, plugin_id, param_name, engine_key, knob_key,
#          value_type, input_min, input_max, knob_min, knob_max,
#          engine_min, engine_max, default_value, category, tags,
#          description, unit, apply_method)

_FACTORY_PARAMS = [
    # ═══ AETERNA ═══
    ("aeterna", "chrono.aeterna", "filter_cutoff", "filter_cutoff", "filter_cutoff",
     "linear", 20, 20000, 0, 100, 0.0, 1.0, 0.68, "filter", "cutoff,brightness,tone",
     "Filter Cutoff Frequenz", "Hz", "set_param"),
    ("aeterna", "chrono.aeterna", "filter_resonance", "filter_resonance", "filter_resonance",
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.18, "filter", "resonance,q",
     "Filter Resonanz", "", "set_param"),
    ("aeterna", "chrono.aeterna", "amp_attack", "aeg_attack", "aeg_attack",
     "linear", 0.001, 5, 0, 100, 0.0, 1.0, 0.01, "envelope", "attack,adsr",
     "Amplitude Attack", "s", "set_param"),
    ("aeterna", "chrono.aeterna", "amp_decay", "aeg_decay", "aeg_decay",
     "linear", 0.001, 5, 0, 100, 0.0, 1.0, 0.3, "envelope", "decay,adsr",
     "Amplitude Decay", "s", "set_param"),
    ("aeterna", "chrono.aeterna", "amp_sustain", "aeg_sustain", "aeg_sustain",
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.7, "envelope", "sustain,adsr",
     "Amplitude Sustain", "", "set_param"),
    ("aeterna", "chrono.aeterna", "amp_release", "aeg_release", "aeg_release",
     "linear", 0.001, 10, 0, 100, 0.0, 1.0, 0.5, "envelope", "release,adsr",
     "Amplitude Release", "s", "set_param"),
    ("aeterna", "chrono.aeterna", "chorus_mix", "chorus_mix", None,
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.0, "effect", "chorus,modulation",
     "Chorus Mix", "", "set_param"),
    ("aeterna", "chrono.aeterna", "reverb_mix", "reverb_mix", None,
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.0, "effect", "reverb,space",
     "Reverb Mix", "", "set_param"),
    ("aeterna", "chrono.aeterna", "delay_mix", "delay_mix", None,
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.0, "effect", "delay,echo",
     "Delay Mix", "", "set_param"),
    ("aeterna", "chrono.aeterna", "drive", "drive", None,
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.0, "effect", "drive,distortion,saturation",
     "Drive Amount", "", "set_param"),
    ("aeterna", "chrono.aeterna", "stereo_spread", "stereo_spread", "stereo_spread",
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.34, "output", "stereo,width,spread",
     "Stereo Spread", "", "set_param"),

    # ═══ FUSION ═══
    ("fusion", "chrono.fusion", "filter_cutoff", "flt.cutoff", "flt.cutoff",
     "exponential", 20, 20000, 0, 100, 20.0, 20000.0, 8000, "filter", "cutoff,brightness",
     "SVF Filter Cutoff", "Hz", "knob_direct"),
    ("fusion", "chrono.fusion", "filter_resonance", "flt.resonance", "flt.resonance",
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.0, "filter", "resonance,q",
     "SVF Filter Resonance", "", "knob_direct"),
    ("fusion", "chrono.fusion", "amp_attack", "aeg.attack", "aeg.attack",
     "quadratic", 0, 10, 0, 100, 0.0, 10.0, 0.02, "envelope", "attack,adsr",
     "Amp Envelope Attack", "s", "knob_direct"),
    ("fusion", "chrono.fusion", "amp_decay", "aeg.decay", "aeg.decay",
     "quadratic", 0, 10, 0, 100, 0.0, 10.0, 2.0, "envelope", "decay,adsr",
     "Amp Envelope Decay", "s", "knob_direct"),
    ("fusion", "chrono.fusion", "amp_sustain", "aeg.sustain", "aeg.sustain",
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.7, "envelope", "sustain,adsr",
     "Amp Envelope Sustain", "", "knob_direct"),
    ("fusion", "chrono.fusion", "amp_release", "aeg.release", "aeg.release",
     "quadratic", 0, 10, 0, 100, 0.0, 10.0, 0.3, "envelope", "release,adsr",
     "Amp Envelope Release", "s", "knob_direct"),
    ("fusion", "chrono.fusion", "drive", "flt.drive", "flt.drive",
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.0, "effect", "drive,saturation",
     "Filter Drive", "", "knob_direct"),

    # ═══ BRRR ═══
    ("brrr", "chrono.brrr", "amp_attack", "buzz_attack", "buzz_attack",
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.0, "envelope", "attack,adsr",
     "Buzz Layer Attack", "s", "import_state"),
    ("brrr", "chrono.brrr", "amp_decay", "buzz_decay", "buzz_decay",
     "linear", 0.01, 2, 1, 200, 0.01, 2.0, 0.4, "envelope", "decay,adsr",
     "Buzz Layer Decay", "s", "import_state"),
    ("brrr", "chrono.brrr", "amp_sustain", "buzz_sustain", "buzz_sustain",
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.4, "envelope", "sustain,adsr",
     "Buzz Layer Sustain", "", "import_state"),
    ("brrr", "chrono.brrr", "amp_release", "buzz_release", "buzz_release",
     "linear", 0.01, 2, 1, 200, 0.01, 2.0, 0.2, "envelope", "release,adsr",
     "Buzz Layer Release", "s", "import_state"),
    ("brrr", "chrono.brrr", "filter_cutoff", "bp_freq", "bp_freq",
     "exponential", 20, 20000, 20, 20000, 20.0, 20000.0, 1000, "filter", "cutoff,bandpass",
     "Bandpass Filter Frequenz", "Hz", "import_state"),
    ("brrr", "chrono.brrr", "filter_resonance", "bp_q", "bp_q",
     "linear", 0.1, 30, 1, 300, 0.1, 30.0, 1.0, "filter", "resonance,q,bandpass",
     "Bandpass Filter Q", "", "import_state"),
    ("brrr", "chrono.brrr", "chorus_mix", "fm_depth", "fm_depth",
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.2, "effect", "fm,modulation",
     "FM/PAD Depth", "", "import_state"),
    ("brrr", "chrono.brrr", "reverb_mix", "flutter_volume", "flutter_volume",
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.5, "effect", "flutter,modulation",
     "Flutter/Modulation Amount", "", "import_state"),

    # ═══ BACHORGEL ═══
    ("bachorgel", "chrono.bach_orgel", "filter_cutoff", "cutoff", "cut",
     "linear", 20, 20000, 0, 100, 0.0, 1.0, 0.68, "filter", "cutoff,brightness",
     "Synthesis Cutoff", "Hz", "knob_direct"),
    ("bachorgel", "chrono.bach_orgel", "amp_attack", "attack", "attack",
     "linear", 0, 5, 0, 100, 0.0, 1.0, 0.03, "envelope", "attack",
     "Synthesis Attack", "s", "knob_direct"),
    ("bachorgel", "chrono.bach_orgel", "amp_release", "release", "release",
     "linear", 0, 5, 0, 100, 0.0, 1.0, 0.4, "envelope", "release",
     "Synthesis Release", "s", "knob_direct"),

    # ═══ SAMPLER ═══
    ("sampler", "chrono.pro_audio_sampler", "filter_cutoff", "cutoff_hz", "cutoff",
     "exponential", 20, 20000, 0, 100, 20.0, 20000.0, 8000, "filter", "cutoff",
     "Filter Cutoff", "Hz", "widget_method"),
    ("sampler", "chrono.pro_audio_sampler", "amp_attack", "a", "a",
     "linear", 0.001, 5, 0, 100, 0.001, 5.0, 0.02, "envelope", "attack",
     "ADSR Attack", "s", "widget_method"),
    ("sampler", "chrono.pro_audio_sampler", "chorus_mix", "chorus_mix", "chorus",
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.0, "effect", "chorus",
     "Chorus Send", "", "widget_method"),
    ("sampler", "chrono.pro_audio_sampler", "reverb_mix", "reverb_mix", "reverb",
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.0, "effect", "reverb",
     "Reverb Send", "", "widget_method"),

    # ═══ DRUM MACHINE ═══
    ("drum_machine", "chrono.drum_machine", "amp_attack", "attack", "attack",
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.0, "envelope", "attack",
     "Pad Attack", "s", "set_param"),
    ("drum_machine", "chrono.drum_machine", "amp_decay", "decay", "decay",
     "linear", 0.01, 2, 0, 100, 0.01, 2.0, 0.3, "envelope", "decay",
     "Pad Decay", "s", "set_param"),
    ("drum_machine", "chrono.drum_machine", "filter_cutoff", "cutoff", "cutoff",
     "exponential", 20, 20000, 0, 100, 0.0, 1.0, 0.8, "filter", "cutoff",
     "Pad Filter Cutoff", "Hz", "set_param"),

    # ═══ ADVANCED SAMPLER ═══
    ("advanced_sampler", "chrono.advanced_sampler", "filter_cutoff", "cutoff", "cutoff",
     "exponential", 20, 20000, 0, 100, 20.0, 20000.0, 12000, "filter", "cutoff",
     "Zone Filter Cutoff", "Hz", "widget_method"),
    ("advanced_sampler", "chrono.advanced_sampler", "amp_attack", "attack", "attack",
     "linear", 0.001, 5, 0, 100, 0.001, 5.0, 0.01, "envelope", "attack",
     "Zone Amp Attack", "s", "widget_method"),
    ("advanced_sampler", "chrono.advanced_sampler", "amp_decay", "decay", "decay",
     "linear", 0.001, 5, 0, 100, 0.001, 5.0, 0.3, "envelope", "decay",
     "Zone Amp Decay", "s", "widget_method"),
    ("advanced_sampler", "chrono.advanced_sampler", "amp_sustain", "sustain", "sustain",
     "linear", 0, 1, 0, 100, 0.0, 1.0, 0.8, "envelope", "sustain",
     "Zone Amp Sustain", "", "widget_method"),
    ("advanced_sampler", "chrono.advanced_sampler", "amp_release", "release", "release",
     "linear", 0.001, 10, 0, 100, 0.001, 10.0, 0.3, "envelope", "release",
     "Zone Amp Release", "s", "widget_method"),
]
