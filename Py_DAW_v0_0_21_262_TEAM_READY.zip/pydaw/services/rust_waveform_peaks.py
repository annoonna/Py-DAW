"""Rust Waveform Peaks Integration — v0.0.21.056 (R6.2–R6.4).

Bridges Rust-generated waveform peaks into the Python UI:
  - Listens for WaveformPeaks events from RustEngineBridge
  - Decodes base64 peak data into numpy min/max arrays
  - Injects into ArrangerCanvas._peaks_cache for immediate display
  - Also provides peaks for the Audio Editor

Usage:
    from pydaw.services.rust_waveform_peaks import RustWaveformPeaksService

    svc = RustWaveformPeaksService(bridge, arranger_canvas)
    # Automatically hooks into bridge.generic_event
    # Request peaks for a clip:
    svc.request_peaks("clip_001", "/path/to/audio.wav")
"""

from __future__ import annotations

import base64
import logging
import struct
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from pydaw.services.rust_engine_bridge import RustEngineBridge

log = logging.getLogger(__name__)

try:
    import numpy as np
    _NP = True
except ImportError:
    _NP = False


class RustWaveformPeaksService:
    """Manages Rust-generated waveform peaks for UI display."""

    def __init__(self, bridge: "RustEngineBridge",
                 arranger_canvas=None, audio_editor=None):
        self._bridge = bridge
        self._arranger = arranger_canvas
        self._audio_editor = audio_editor
        # Map clip_id → file path (for cache key)
        self._clip_paths: dict[str, str] = {}
        # Map clip_id → pending callback
        self._callbacks: dict[str, list] = {}

        # Connect to bridge events
        try:
            bridge.generic_event.connect(self._on_event)
        except Exception:
            log.debug("RustWaveformPeaksService: could not connect to bridge")

    def request_peaks(self, clip_id: str, file_path: str,
                      peaks_per_second: int = 200,
                      callback=None):
        """Request waveform peaks from Rust for a clip.

        Args:
            clip_id: Clip ID (must be loaded in Rust ClipStore).
            file_path: Absolute path to the audio file (used as cache key).
            peaks_per_second: Resolution (200 = good for arranger, 1000 for editor).
            callback: Optional callback(mins, maxs, sample_rate) on completion.
        """
        self._clip_paths[clip_id] = file_path
        if callback:
            self._callbacks.setdefault(clip_id, []).append(callback)
        self._bridge.generate_waveform_peaks(clip_id, peaks_per_second)
        log.debug("Requested Rust peaks: clip=%s pps=%d", clip_id, peaks_per_second)

    def _on_event(self, event: dict):
        """Handle WaveformPeaks event from bridge."""
        if event.get("type") != "WaveformPeaks":
            return

        clip_id = event.get("clip_id", "")
        peaks_b64 = event.get("peaks_b64", "")
        num_peaks = event.get("num_peaks", 0)
        sample_rate = event.get("sample_rate", 48000)
        pps = event.get("peaks_per_second", 200)

        if not peaks_b64 or num_peaks == 0:
            log.warning("Empty WaveformPeaks for clip %s", clip_id)
            return

        if not _NP:
            log.warning("numpy not available — cannot decode Rust peaks")
            return

        try:
            raw = base64.b64decode(peaks_b64)
            # f32 LE: [min0, max0, min1, max1, ...]
            floats = np.frombuffer(raw, dtype=np.float32)
            if len(floats) != num_peaks * 2:
                log.warning("Peak data size mismatch: expected %d, got %d",
                            num_peaks * 2, len(floats))
                return

            mins = floats[0::2].copy()  # even indices
            maxs = floats[1::2].copy()  # odd indices
            # Legacy peaks array (absolute max per block)
            peaks = np.maximum(np.abs(mins), np.abs(maxs))

            log.info("Decoded Rust peaks: clip=%s, %d peaks, sr=%d",
                     clip_id, num_peaks, sample_rate)

            # Inject into arranger cache
            file_path = self._clip_paths.get(clip_id, "")
            if file_path and self._arranger is not None:
                self._inject_arranger_cache(
                    file_path, peaks, mins, maxs, sample_rate, pps)

            # Fire callbacks
            for cb in self._callbacks.pop(clip_id, []):
                try:
                    cb(mins, maxs, sample_rate)
                except Exception as e:
                    log.error("Peak callback error: %s", e)

        except Exception as e:
            log.error("Error decoding WaveformPeaks: %s", e)

    def _inject_arranger_cache(self, file_path: str,
                               peaks, mins, maxs,
                               sample_rate: int, pps: int):
        """Inject Rust peaks into the ArrangerCanvas._peaks_cache."""
        try:
            import os
            p = os.path.abspath(file_path)
            try:
                mtime_ns = int(os.stat(p).st_mtime_ns)
            except Exception:
                mtime_ns = 0

            block_size = max(1, sample_rate // pps)

            # Import the dataclass from arranger_canvas
            from pydaw.ui.arranger_canvas import _PeaksData

            pd = _PeaksData(
                mtime_ns=mtime_ns,
                block_size=block_size,
                samplerate=sample_rate,
                peaks=peaks,
                mins=mins,
                maxs=maxs,
            )
            self._arranger._peaks_cache[p] = pd
            self._arranger._peaks_pending.discard(p)
            self._arranger.update()
            log.debug("Injected Rust peaks into arranger cache: %s", p)
        except Exception as e:
            log.error("Failed to inject peaks into arranger: %s", e)
