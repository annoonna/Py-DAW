"""Mastering Service (P3C) — Offline mastering chain.

Pure Python + numpy. Processes audio buffers.

Features:
- Mastering Wizard: measure → recommend → apply
- LUFS-Target: adjust gain to reach platform targets
- True-Peak Limiter: brickwall with lookahead
- Multi-band processing (3-band)
- A/B comparison (before/after metrics)

v0.0.20.808 — Phase P3C
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Tuple, Any

log = logging.getLogger(__name__)

try:
    import numpy as np
except Exception:
    np = None  # type: ignore


# ---------------------------------------------------------------------------
# Platform targets
# ---------------------------------------------------------------------------

PLATFORM_TARGETS: Dict[str, Dict[str, float]] = {
    "Spotify": {"lufs": -14.0, "true_peak_dbfs": -1.0},
    "Apple Music": {"lufs": -16.0, "true_peak_dbfs": -1.0},
    "YouTube": {"lufs": -14.0, "true_peak_dbfs": -1.0},
    "Tidal": {"lufs": -14.0, "true_peak_dbfs": -1.0},
    "Amazon Music": {"lufs": -14.0, "true_peak_dbfs": -2.0},
    "Broadcast (EBU R128)": {"lufs": -23.0, "true_peak_dbfs": -1.0},
    "CD Master": {"lufs": -9.0, "true_peak_dbfs": -0.3},
    "Club/DJ": {"lufs": -6.0, "true_peak_dbfs": -0.1},
}


def get_platform_names() -> List[str]:
    return list(PLATFORM_TARGETS.keys())


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class MasteringConfig:
    """Configuration for mastering chain."""
    target_lufs: float = -14.0
    true_peak_ceiling_dbfs: float = -1.0
    limiter_release_ms: float = 50.0
    limiter_lookahead_ms: float = 1.0
    # Multi-band
    low_gain_db: float = 0.0
    mid_gain_db: float = 0.0
    high_gain_db: float = 0.0
    low_crossover_hz: float = 250.0
    high_crossover_hz: float = 4000.0
    # Width
    stereo_width: float = 1.0       # 0=mono, 1=unchanged, 2=wider
    # Soft clip
    soft_clip: bool = False
    soft_clip_threshold_db: float = -3.0

    def to_dict(self) -> dict:
        return {k: round(v, 2) if isinstance(v, float) else v
                for k, v in self.__dict__.items()}

    @classmethod
    def for_platform(cls, platform: str) -> "MasteringConfig":
        target = PLATFORM_TARGETS.get(platform, PLATFORM_TARGETS["Spotify"])
        return cls(
            target_lufs=target["lufs"],
            true_peak_ceiling_dbfs=target["true_peak_dbfs"],
        )


@dataclass
class MasteringResult:
    """Result of mastering processing."""
    input_lufs: float = -96.0
    input_peak_dbfs: float = -96.0
    output_lufs: float = -96.0
    output_peak_dbfs: float = -96.0
    gain_applied_db: float = 0.0
    limiter_gr_max_db: float = 0.0    # max gain reduction
    is_clipping: bool = False
    meets_target: bool = False
    description: str = ""

    def to_dict(self) -> dict:
        return {
            "input_lufs": round(self.input_lufs, 1),
            "input_peak_dbfs": round(self.input_peak_dbfs, 1),
            "output_lufs": round(self.output_lufs, 1),
            "output_peak_dbfs": round(self.output_peak_dbfs, 1),
            "gain_applied_db": round(self.gain_applied_db, 1),
            "limiter_gr_max_db": round(self.limiter_gr_max_db, 1),
            "is_clipping": self.is_clipping,
            "meets_target": self.meets_target,
            "description": self.description,
        }


# ---------------------------------------------------------------------------
# LUFS / Peak helpers (reuse from smart_mixer where possible)
# ---------------------------------------------------------------------------

def _measure_lufs_simple(audio: "np.ndarray", sr: int) -> float:
    """Simplified LUFS."""
    if np is None or len(audio) < 256:
        return -96.0
    audio = np.asarray(audio, dtype=np.float64).flatten()
    rms = float(np.sqrt(np.mean(audio ** 2)))
    if rms < 1e-10:
        return -96.0
    return -0.691 + 10.0 * math.log10(rms ** 2 + 1e-20)


def _measure_true_peak(audio: "np.ndarray", sr: int) -> float:
    """True peak with 4x oversampling (ITU-R BS.1770)."""
    if np is None or len(audio) < 4:
        return -96.0
    audio = np.asarray(audio, dtype=np.float64).flatten()

    # 4x oversampling via linear interpolation (simplified)
    n = len(audio)
    indices = np.linspace(0, n - 1, n * 4, dtype=np.float64)
    idx_int = np.clip(indices.astype(np.int64), 0, n - 2)
    idx_frac = indices - idx_int
    oversampled = audio[idx_int] * (1.0 - idx_frac) + audio[idx_int + 1] * idx_frac

    peak = float(np.max(np.abs(oversampled)))
    if peak < 1e-10:
        return -96.0
    return 20.0 * math.log10(peak)


# ---------------------------------------------------------------------------
# True-Peak Limiter
# ---------------------------------------------------------------------------

def true_peak_limit(
    audio: "np.ndarray",
    sr: int = 48000,
    *,
    ceiling_dbfs: float = -1.0,
    release_ms: float = 50.0,
    lookahead_ms: float = 1.0,
) -> Tuple["np.ndarray", float]:
    """Apply true-peak brickwall limiting.

    Returns (limited_audio, max_gain_reduction_db).
    """
    if np is None:
        return (audio, 0.0)

    audio = np.asarray(audio, dtype=np.float64)
    is_stereo = audio.ndim == 2

    if is_stereo:
        mono = np.max(np.abs(audio), axis=1)
    else:
        mono = np.abs(audio.flatten())

    ceiling_linear = 10.0 ** (ceiling_dbfs / 20.0)
    lookahead_samples = max(1, int(lookahead_ms * 0.001 * sr))
    release_samples = max(1, int(release_ms * 0.001 * sr))
    release_coeff = math.exp(-1.0 / release_samples)

    # Compute gain reduction envelope
    n = len(mono)
    gain_env = np.ones(n, dtype=np.float64)

    for i in range(n):
        # Look ahead for peak
        look_end = min(n, i + lookahead_samples)
        peak_ahead = float(np.max(mono[i:look_end]))

        if peak_ahead > ceiling_linear:
            needed_gr = ceiling_linear / peak_ahead
        else:
            needed_gr = 1.0

        if i > 0:
            # Smooth release
            gain_env[i] = min(needed_gr, gain_env[i - 1] + (1.0 - gain_env[i - 1]) * (1.0 - release_coeff))
            gain_env[i] = min(gain_env[i], needed_gr)
        else:
            gain_env[i] = needed_gr

    max_gr = float(np.min(gain_env))
    max_gr_db = 20.0 * math.log10(max(1e-10, max_gr)) if max_gr < 0.999 else 0.0

    # Apply
    if is_stereo:
        result = audio * gain_env[:, np.newaxis]
    else:
        result = audio.flatten() * gain_env

    return (result.astype(np.float64), max_gr_db)


# ---------------------------------------------------------------------------
# Soft clipper
# ---------------------------------------------------------------------------

def soft_clip(audio: "np.ndarray", threshold_db: float = -3.0) -> "np.ndarray":
    """Soft-clip audio above threshold using tanh saturation."""
    if np is None:
        return audio
    audio = np.asarray(audio, dtype=np.float64)
    threshold = 10.0 ** (threshold_db / 20.0)

    # Normalize to threshold, apply tanh, scale back
    normalized = audio / max(threshold, 1e-10)
    clipped = np.tanh(normalized) * threshold
    return clipped


# ---------------------------------------------------------------------------
# Simple 3-band EQ (for mastering tonal shaping)
# ---------------------------------------------------------------------------

def _apply_3band_eq(
    audio: "np.ndarray",
    sr: int,
    low_gain_db: float, mid_gain_db: float, high_gain_db: float,
    low_xover: float = 250.0, high_xover: float = 4000.0,
) -> "np.ndarray":
    """Apply 3-band EQ using FFT."""
    if np is None or (abs(low_gain_db) < 0.1 and abs(mid_gain_db) < 0.1 and abs(high_gain_db) < 0.1):
        return audio

    audio = np.asarray(audio, dtype=np.float64)
    is_stereo = audio.ndim == 2

    def eq_channel(ch):
        n = len(ch)
        spec = np.fft.rfft(ch)
        freqs = np.fft.rfftfreq(n, 1.0 / sr)

        gains = np.ones_like(freqs, dtype=np.float64)
        gains[freqs < low_xover] *= 10.0 ** (low_gain_db / 20.0)
        mask_mid = (freqs >= low_xover) & (freqs < high_xover)
        gains[mask_mid] *= 10.0 ** (mid_gain_db / 20.0)
        gains[freqs >= high_xover] *= 10.0 ** (high_gain_db / 20.0)

        spec *= gains
        return np.fft.irfft(spec, n=n)

    if is_stereo:
        left = eq_channel(audio[:, 0])
        right = eq_channel(audio[:, 1])
        n = min(len(left), len(right))
        return np.stack([left[:n], right[:n]], axis=1)
    else:
        return eq_channel(audio.flatten())


# ---------------------------------------------------------------------------
# Stereo width adjustment
# ---------------------------------------------------------------------------

def adjust_stereo_width(audio: "np.ndarray", width: float = 1.0) -> "np.ndarray":
    """Adjust stereo width. 0=mono, 1=unchanged, 2=wider."""
    if np is None or abs(width - 1.0) < 0.01:
        return audio
    audio = np.asarray(audio, dtype=np.float64)
    if audio.ndim != 2 or audio.shape[1] < 2:
        return audio

    mid = (audio[:, 0] + audio[:, 1]) * 0.5
    side = (audio[:, 0] - audio[:, 1]) * 0.5

    side *= max(0.0, width)
    left = mid + side
    right = mid - side

    return np.stack([left, right], axis=1)


# ---------------------------------------------------------------------------
# Full mastering chain
# ---------------------------------------------------------------------------

def master_audio(
    audio: "np.ndarray",
    sr: int = 48000,
    config: Optional[MasteringConfig] = None,
) -> Tuple["np.ndarray", MasteringResult]:
    """Apply full mastering chain.

    Chain order:
    1. 3-band EQ (tonal shaping)
    2. Stereo width
    3. Gain to target LUFS
    4. Soft clip (optional)
    5. True-peak limiter
    6. Final measurement

    Returns (mastered_audio, result).
    """
    if np is None:
        return (audio, MasteringResult(description="numpy nicht verfügbar"))

    if config is None:
        config = MasteringConfig()

    audio = np.asarray(audio, dtype=np.float64)
    is_stereo = audio.ndim == 2 and audio.shape[1] >= 2

    # Input measurement
    mono_in = np.mean(audio, axis=1) if is_stereo else audio.flatten()
    input_lufs = _measure_lufs_simple(mono_in, sr)
    input_peak = _measure_true_peak(mono_in, sr)

    result = audio.copy()

    # 1. 3-band EQ
    if abs(config.low_gain_db) > 0.1 or abs(config.mid_gain_db) > 0.1 or abs(config.high_gain_db) > 0.1:
        result = _apply_3band_eq(result, sr,
                                  config.low_gain_db, config.mid_gain_db, config.high_gain_db,
                                  config.low_crossover_hz, config.high_crossover_hz)

    # 2. Stereo width
    if is_stereo and abs(config.stereo_width - 1.0) > 0.01:
        result = adjust_stereo_width(result, config.stereo_width)

    # 3. Gain to target LUFS
    mono_current = np.mean(result, axis=1) if is_stereo else result.flatten()
    current_lufs = _measure_lufs_simple(mono_current, sr)
    if current_lufs > -90:
        gain_db = config.target_lufs - current_lufs
        gain_db = max(-24.0, min(24.0, gain_db))
        gain_linear = 10.0 ** (gain_db / 20.0)
        result = result * gain_linear
    else:
        gain_db = 0.0

    # 4. Soft clip
    if config.soft_clip:
        result = soft_clip(result, config.soft_clip_threshold_db)

    # 5. True-peak limiter
    limited, max_gr_db = true_peak_limit(
        result, sr,
        ceiling_dbfs=config.true_peak_ceiling_dbfs,
        release_ms=config.limiter_release_ms,
        lookahead_ms=config.limiter_lookahead_ms,
    )
    result = limited

    # 6. Final measurement
    mono_out = np.mean(result, axis=1) if is_stereo else result.flatten()
    output_lufs = _measure_lufs_simple(mono_out, sr)
    output_peak = _measure_true_peak(mono_out, sr)

    meets = output_peak <= config.true_peak_ceiling_dbfs + 0.5
    is_clip = output_peak > -0.1

    desc_parts = [
        f"Input: {input_lufs:.1f} LUFS / {input_peak:.1f} dBTP",
        f"Output: {output_lufs:.1f} LUFS / {output_peak:.1f} dBTP",
        f"Gain: {gain_db:+.1f} dB",
    ]
    if max_gr_db < -0.1:
        desc_parts.append(f"Limiter GR: {max_gr_db:.1f} dB")
    if meets:
        desc_parts.append("✅ Ziel erreicht")
    else:
        desc_parts.append("⚠ True Peak über Ceiling")

    mastering_result = MasteringResult(
        input_lufs=input_lufs,
        input_peak_dbfs=input_peak,
        output_lufs=output_lufs,
        output_peak_dbfs=output_peak,
        gain_applied_db=gain_db,
        limiter_gr_max_db=max_gr_db,
        is_clipping=is_clip,
        meets_target=meets,
        description=" | ".join(desc_parts),
    )

    return (result.astype(np.float32), mastering_result)


# ---------------------------------------------------------------------------
# A/B comparison
# ---------------------------------------------------------------------------

def compare_ab(
    original: "np.ndarray",
    mastered: "np.ndarray",
    sr: int = 48000,
) -> Dict[str, Any]:
    """Compare original and mastered audio side by side."""
    if np is None:
        return {"error": "numpy nicht verfügbar"}

    orig_mono = np.mean(np.asarray(original, dtype=np.float64), axis=1) if original.ndim > 1 else original.flatten()
    mast_mono = np.mean(np.asarray(mastered, dtype=np.float64), axis=1) if mastered.ndim > 1 else mastered.flatten()

    return {
        "original": {
            "lufs": round(_measure_lufs_simple(orig_mono, sr), 1),
            "true_peak": round(_measure_true_peak(orig_mono, sr), 1),
        },
        "mastered": {
            "lufs": round(_measure_lufs_simple(mast_mono, sr), 1),
            "true_peak": round(_measure_true_peak(mast_mono, sr), 1),
        },
        "gain_diff_db": round(
            _measure_lufs_simple(mast_mono, sr) - _measure_lufs_simple(orig_mono, sr), 1
        ),
    }
