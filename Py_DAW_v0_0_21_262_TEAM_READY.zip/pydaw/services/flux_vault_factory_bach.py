"""
pydaw.services.flux_vault_factory_bach — V-2 Bach-Style Factory-Presets

**v0.0.21.201 — Bach v1 (Klassik-Barock-Edition)**
==================================================

Erste Iteration der Bach-Style-Presets nach dem **Sacred-v2-Charakter-
Modul-Schema** aus v0.0.21.199:

> Jeder Preset bekommt ein einzigartiges Charakter-Modul, das ihn
> unverwechselbar macht. Reverb-Mix moderat (0.25-0.45 typisch).

Die Bach-Familie holt Klangfarben aus dem 17.-18. Jahrhundert in das
modulare FLUX-System: Pfeifenorgel-Reedy-Sound, Cembalo-perlend,
zwei-stimmige polyphone Inventionen, sub-bass Pedal-Solo, dichter
Leipziger Plenum-Stop.

| Preset           | Charakter-Modul              | Klang-Identität |
|------------------|------------------------------|-----------------|
| Toccata          | Square + Bandpass-Res + Saturation | reedy aufmerksamkeitserregend |
| Fugue            | Stereo Triangle L + Saw R + EQ4 | zwei-stimmige Polyphonie |
| Prelude          | Sine + Forseti.Tilt(+) + sanfter Reverb | klar fließend |
| Cantata          | Saw + Skadi.Chorus + Vidar.Compressor | vox-artig warm |
| Aria             | Triangle + EQ4 (Mid-Cut) + sanfter Reverb | Solostimme |
| Invention        | Stereo 2-Stimmen Triangle + Forseti.Tilt | Lehrwerk-Polyphonie |
| Sinfonia         | Stereo Saw L + Square R + Thor.Saturation | drei-stimmig dicht |
| Goldberg         | Saw + Fenrir.BitCrush(subtil) + EQ4 | Cembalo-Sound |
| Fantasia         | Square + Skadi.Phaser + Sub-Bass | Improvisations-Charakter |
| Chorale          | Stereo Hymnal Sine L + Triangle R + EQ4 | Gemeindegesang |
| Pedal-Solo       | Sub-Square 65Hz + LFO-Vibrato + Tube | tiefe Pedal-Tritte |
| Leipzig-Stop     | Plenum Square + Bandpass-Res + Tube + Max-Reverb | volles Werk |

Versions-Marker ``"FLUX Factory (Bach v1)"`` für sauberes Re-Seeding.
"""

from __future__ import annotations

import logging
from typing import Optional

logger = logging.getLogger(__name__)


BACH_FACTORY_VERSION = "v1"
BACH_FACTORY_AUTHOR = f"FLUX Factory (Bach {BACH_FACTORY_VERSION})"


# ─── Helper ───────────────────────────────────────────────────────


def _connect(patch, src_id: str, src_port: str,
             tgt_id: str, tgt_port: str) -> bool:
    """Helper: Connection hinzufügen, defensiv gegen fehlende Module."""
    from pydaw.flux.patch_model import Connection
    src = patch.get_module(src_id)
    tgt = patch.get_module(tgt_id)
    if src is None or tgt is None:
        return False
    return patch.add_connection(Connection(
        source_module=src_id, source_port=src_port,
        target_module=tgt_id, target_port=tgt_port,
    ))


def _set(module, **params) -> None:
    """Helper: Module-Params setzen (defensiv gegen fehlende Keys)."""
    if module is None:
        return
    for k, v in params.items():
        if k in module.params:
            module.params[k] = v


def _build_patch_dict(name: str, builder) -> Optional[dict]:
    """Wrappt einen Patch-Builder in to_dict, defensiv gegen Fehler."""
    try:
        from pydaw.flux.patch_model import Patch
        p = builder()
        if not isinstance(p, Patch):
            return None
        p.name = name
        return p.to_dict()
    except Exception as e:
        logger.warning("[BachPresets-v1] build %s failed: %s", name, e)
        return None


# ─── Patch-Builder pro Variant (Bach v1) ──────────────────────────


def _build_toccata():
    """Toccata — Square + Bandpass-Res + Thor.Saturation (reedy aufweckend).

    Charakter: scharfer Bandpass auf Square, dazu sanfte Saturation —
    das ergibt den klassischen Toccata-Pfeifenorgel-Aufmacher.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_square_osc, make_forseti_bandpass,
        make_thor_saturation, make_iduna_reverb,
        make_heimdall_master_out,
    )
    p = Patch(name="Toccata")
    osc = make_bragi_square_osc(); osc.position = (60, 200)
    _set(osc, freq=146.83, gain=0.4)  # D3
    flt = make_forseti_bandpass(); flt.position = (260, 200)
    _set(flt, cutoff=1400.0, resonance=0.75)  # reedy
    sat = make_thor_saturation(); sat.position = (460, 200)
    _set(sat, amount=0.5, mix=0.7)
    rev = make_iduna_reverb(); rev.position = (660, 200)
    _set(rev, room_size=0.7, damping=0.45, mix=0.32)
    out = make_heimdall_master_out(); out.position = (860, 200)
    for m in (osc, flt, sat, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", flt.id, "audio_in")
    _connect(p, flt.id, "audio_out", sat.id, "audio_in")
    _connect(p, sat.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_fugue():
    """Fugue — Stereo Triangle L + Saw R + EQ4 (zwei-stimmige Polyphonie).

    Charakter: zwei kontrastierende Stimmen (Subjekt L, Antwort R) mit
    deutlichem EQ-Mid-Boost für Sprach-Klarheit. Klassisch barock.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_triangle_osc, make_bragi_saw_osc,
        make_forseti_eq4, make_iduna_reverb,
        make_heimdall_master_out,
    )
    p = Patch(name="Fugue")
    # L: Subjekt — Triangle (klar, hell)
    osc_l = make_bragi_triangle_osc(); osc_l.position = (60, 100)
    _set(osc_l, freq=261.63, gain=0.4)  # C4
    eq_l = make_forseti_eq4(); eq_l.position = (260, 100)
    _set(eq_l, low_gain=-2.0, lo_mid_gain=3.0, hi_mid_gain=2.0, high_gain=-1.0)
    rev_l = make_iduna_reverb(); rev_l.position = (460, 100)
    _set(rev_l, room_size=0.55, damping=0.4, mix=0.28)
    # R: Antwort — Saw eine Quint höher (G4, klassische Beantwortung)
    osc_r = make_bragi_saw_osc(); osc_r.position = (60, 280)
    _set(osc_r, freq=392.0, gain=0.30)  # G4
    eq_r = make_forseti_eq4(); eq_r.position = (260, 280)
    _set(eq_r, low_gain=-3.0, lo_mid_gain=2.0, hi_mid_gain=4.0, high_gain=-2.0)
    rev_r = make_iduna_reverb(); rev_r.position = (460, 280)
    _set(rev_r, room_size=0.55, damping=0.4, mix=0.28)
    out = make_heimdall_master_out(); out.position = (680, 190)
    for m in (osc_l, eq_l, rev_l, osc_r, eq_r, rev_r, out):
        p.add_module(m)
    _connect(p, osc_l.id, "audio_out", eq_l.id, "audio_in")
    _connect(p, eq_l.id, "audio_out", rev_l.id, "audio_in")
    _connect(p, rev_l.id, "audio_out", out.id, "audio_in_l")
    _connect(p, osc_r.id, "audio_out", eq_r.id, "audio_in")
    _connect(p, eq_r.id, "audio_out", rev_r.id, "audio_in")
    _connect(p, rev_r.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_prelude():
    """Prelude — Sine + Forseti.Tilt(+) + sanfter Reverb (klar fließend).

    Charakter: heller Tilt-EQ auf einem reinen Sine ergibt den klaren,
    fließenden Charakter eines Wohltemperierten-Klavier-Preludes.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_sine_osc, make_forseti_tilt,
        make_iduna_reverb, make_heimdall_master_out,
    )
    p = Patch(name="Prelude")
    osc = make_bragi_sine_osc(); osc.position = (80, 200)
    _set(osc, freq=261.63, gain=0.5)  # C4
    tilt = make_forseti_tilt(); tilt.position = (300, 200)
    _set(tilt, tilt=0.55)  # heller
    rev = make_iduna_reverb(); rev.position = (520, 200)
    _set(rev, room_size=0.5, damping=0.35, mix=0.25)
    out = make_heimdall_master_out(); out.position = (740, 200)
    for m in (osc, tilt, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", tilt.id, "audio_in")
    _connect(p, tilt.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_cantata():
    """Cantata — Saw + Skadi.Chorus + Vidar.Compressor (vox-artig warm).

    Charakter: weicher Chorus + Compressor erzeugt eine vokale, fast
    chorisch klingende Mid-Range-Stimme. Geeignet für Aria-Begleitung.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_saw_osc, make_forseti_lowpass,
        make_skadi_chorus, make_vidar_compressor,
        make_iduna_reverb, make_heimdall_master_out,
    )
    p = Patch(name="Cantata")
    osc = make_bragi_saw_osc(); osc.position = (60, 200)
    _set(osc, freq=220.0, gain=0.35)  # A3
    flt = make_forseti_lowpass(); flt.position = (260, 200)
    _set(flt, cutoff=2800.0, resonance=0.3)
    chorus = make_skadi_chorus(); chorus.position = (460, 200)
    _set(chorus, rate=0.5, depth=0.55, mix=0.55)
    comp = make_vidar_compressor(); comp.position = (660, 200)
    _set(comp, threshold=-18.0, ratio=2.5, attack_ms=12.0,
         release_ms=120.0, makeup=2.0)
    rev = make_iduna_reverb(); rev.position = (860, 200)
    _set(rev, room_size=0.6, damping=0.45, mix=0.3)
    out = make_heimdall_master_out(); out.position = (1060, 200)
    for m in (osc, flt, chorus, comp, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", flt.id, "audio_in")
    _connect(p, flt.id, "audio_out", chorus.id, "audio_in")
    _connect(p, chorus.id, "audio_out", comp.id, "audio_in")
    _connect(p, comp.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_aria():
    """Aria — Triangle + EQ4 (Vox-Mid-Boost) + sanfter Reverb (Solostimme).

    Charakter: Triangle ist klar wie eine Bratsche, EQ4 hebt die
    Vokal-Formanten an. Eine ruhige Solo-Aria.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_triangle_osc, make_forseti_eq4,
        make_iduna_reverb, make_heimdall_master_out,
    )
    p = Patch(name="Aria")
    osc = make_bragi_triangle_osc(); osc.position = (80, 200)
    _set(osc, freq=329.63, gain=0.5)  # E4
    eq = make_forseti_eq4(); eq.position = (300, 200)
    _set(eq, low_gain=-1.5, lo_mid_gain=4.0,
         hi_mid_gain=1.5, high_gain=-2.0)  # Vox-Formant-Anhebung
    rev = make_iduna_reverb(); rev.position = (520, 200)
    _set(rev, room_size=0.6, damping=0.4, mix=0.3)
    out = make_heimdall_master_out(); out.position = (740, 200)
    for m in (osc, eq, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", eq.id, "audio_in")
    _connect(p, eq.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_invention():
    """Invention — Stereo 2-Stimmen Triangle + Tilt (didaktische Polyphonie).

    Charakter: Bachs Inventionen — zwei klare Stimmen die sich
    abwechseln. Beide Triangle, leicht unterschiedlicher Tilt.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_triangle_osc, make_forseti_tilt,
        make_iduna_reverb, make_heimdall_master_out,
    )
    p = Patch(name="Invention")
    # L: Oberstimme
    osc_l = make_bragi_triangle_osc(); osc_l.position = (60, 100)
    _set(osc_l, freq=523.25, gain=0.35)  # C5
    tilt_l = make_forseti_tilt(); tilt_l.position = (260, 100)
    _set(tilt_l, tilt=0.3)  # leicht hell
    rev_l = make_iduna_reverb(); rev_l.position = (460, 100)
    _set(rev_l, room_size=0.5, damping=0.35, mix=0.25)
    # R: Unterstimme (Quart tiefer)
    osc_r = make_bragi_triangle_osc(); osc_r.position = (60, 280)
    _set(osc_r, freq=392.0, gain=0.35)  # G4
    tilt_r = make_forseti_tilt(); tilt_r.position = (260, 280)
    _set(tilt_r, tilt=0.1)  # neutral-leicht hell
    rev_r = make_iduna_reverb(); rev_r.position = (460, 280)
    _set(rev_r, room_size=0.5, damping=0.35, mix=0.25)
    out = make_heimdall_master_out(); out.position = (680, 190)
    for m in (osc_l, tilt_l, rev_l, osc_r, tilt_r, rev_r, out):
        p.add_module(m)
    _connect(p, osc_l.id, "audio_out", tilt_l.id, "audio_in")
    _connect(p, tilt_l.id, "audio_out", rev_l.id, "audio_in")
    _connect(p, rev_l.id, "audio_out", out.id, "audio_in_l")
    _connect(p, osc_r.id, "audio_out", tilt_r.id, "audio_in")
    _connect(p, tilt_r.id, "audio_out", rev_r.id, "audio_in")
    _connect(p, rev_r.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_sinfonia():
    """Sinfonia — Stereo Saw L + Square R + Thor.Saturation (drei-stimmig dicht).

    Charakter: ein Saw + ein Square auf zwei Kanälen, beide durch
    sanftes Saturation — ergibt einen vollen drei-stimmigen Eindruck
    durch Obertöne.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_saw_osc, make_bragi_square_osc,
        make_forseti_lowpass, make_thor_saturation,
        make_iduna_reverb, make_heimdall_master_out,
    )
    p = Patch(name="Sinfonia")
    # L: Saw — Mittelstimme
    osc_l = make_bragi_saw_osc(); osc_l.position = (60, 100)
    _set(osc_l, freq=261.63, gain=0.30)  # C4
    flt_l = make_forseti_lowpass(); flt_l.position = (240, 100)
    _set(flt_l, cutoff=3000.0, resonance=0.25)
    sat_l = make_thor_saturation(); sat_l.position = (420, 100)
    _set(sat_l, amount=0.4, mix=0.65)
    rev_l = make_iduna_reverb(); rev_l.position = (600, 100)
    _set(rev_l, room_size=0.6, damping=0.4, mix=0.3)
    # R: Square — Oberstimme
    osc_r = make_bragi_square_osc(); osc_r.position = (60, 280)
    _set(osc_r, freq=392.0, gain=0.25)  # G4
    flt_r = make_forseti_lowpass(); flt_r.position = (240, 280)
    _set(flt_r, cutoff=2400.0, resonance=0.3)
    sat_r = make_thor_saturation(); sat_r.position = (420, 280)
    _set(sat_r, amount=0.35, mix=0.6)
    rev_r = make_iduna_reverb(); rev_r.position = (600, 280)
    _set(rev_r, room_size=0.6, damping=0.4, mix=0.3)
    out = make_heimdall_master_out(); out.position = (820, 190)
    for m in (osc_l, flt_l, sat_l, rev_l,
              osc_r, flt_r, sat_r, rev_r, out):
        p.add_module(m)
    _connect(p, osc_l.id, "audio_out", flt_l.id, "audio_in")
    _connect(p, flt_l.id, "audio_out", sat_l.id, "audio_in")
    _connect(p, sat_l.id, "audio_out", rev_l.id, "audio_in")
    _connect(p, rev_l.id, "audio_out", out.id, "audio_in_l")
    _connect(p, osc_r.id, "audio_out", flt_r.id, "audio_in")
    _connect(p, flt_r.id, "audio_out", sat_r.id, "audio_in")
    _connect(p, sat_r.id, "audio_out", rev_r.id, "audio_in")
    _connect(p, rev_r.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_goldberg():
    """Goldberg — Saw + Fenrir.BitCrush(subtil) + EQ4 (Cembalo-Sound).

    Charakter: leichter BitCrush gibt dem Saw die zerklirrend-perlende
    Cembalo-Charakteristik, EQ4 hebt die Höhen für den typischen
    Schnurr-Ton.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_saw_osc, make_fenrir_bit_crush,
        make_forseti_eq4, make_iduna_reverb,
        make_heimdall_master_out,
    )
    p = Patch(name="Goldberg")
    osc = make_bragi_saw_osc(); osc.position = (60, 200)
    _set(osc, freq=440.0, gain=0.4)  # A4
    crush = make_fenrir_bit_crush(); crush.position = (260, 200)
    _set(crush, bits=11.0, mix=0.45)  # subtil — Cembalo-Klangkante
    eq = make_forseti_eq4(); eq.position = (460, 200)
    _set(eq, low_gain=-3.0, lo_mid_gain=0.0,
         hi_mid_gain=2.5, high_gain=4.0)  # Höhen-Boost
    rev = make_iduna_reverb(); rev.position = (660, 200)
    _set(rev, room_size=0.45, damping=0.3, mix=0.22)  # kurz, perlend
    out = make_heimdall_master_out(); out.position = (860, 200)
    for m in (osc, crush, eq, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", crush.id, "audio_in")
    _connect(p, crush.id, "audio_out", eq.id, "audio_in")
    _connect(p, eq.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_fantasia():
    """Fantasia — Square + Skadi.Phaser + Sub-Bass-Drone (Improvisations-Charakter).

    Charakter: Phaser-Bewegung über Square + Sub-Bass-Pedalton schafft
    Bach-Fantasia-Atmosphäre — improvisatorisch, mit harmonischer
    Spannung.

    L: Sub-Bass-Pedal C2 mit Lowpass
    R: Square Oberstimme C4 mit Phaser
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_sine_osc, make_bragi_square_osc,
        make_forseti_lowpass, make_skadi_phaser,
        make_iduna_reverb, make_heimdall_master_out,
    )
    p = Patch(name="Fantasia")
    # L: Pedal C2
    osc_l = make_bragi_sine_osc(); osc_l.position = (60, 100)
    _set(osc_l, freq=65.41, gain=0.4)  # C2
    flt_l = make_forseti_lowpass(); flt_l.position = (260, 100)
    _set(flt_l, cutoff=600.0, resonance=0.2)
    rev_l = make_iduna_reverb(); rev_l.position = (460, 100)
    _set(rev_l, room_size=0.7, damping=0.45, mix=0.35)
    # R: Manual mit Phaser
    osc_r = make_bragi_square_osc(); osc_r.position = (60, 280)
    _set(osc_r, freq=261.63, gain=0.3)  # C4
    flt_r = make_forseti_lowpass(); flt_r.position = (260, 280)
    _set(flt_r, cutoff=2200.0, resonance=0.4)
    phaser = make_skadi_phaser(); phaser.position = (460, 280)
    _set(phaser, rate=0.3, depth=0.7, feedback=0.45, mix=0.55)
    rev_r = make_iduna_reverb(); rev_r.position = (660, 280)
    _set(rev_r, room_size=0.7, damping=0.4, mix=0.35)
    out = make_heimdall_master_out(); out.position = (880, 190)
    for m in (osc_l, flt_l, rev_l,
              osc_r, flt_r, phaser, rev_r, out):
        p.add_module(m)
    _connect(p, osc_l.id, "audio_out", flt_l.id, "audio_in")
    _connect(p, flt_l.id, "audio_out", rev_l.id, "audio_in")
    _connect(p, rev_l.id, "audio_out", out.id, "audio_in_l")
    _connect(p, osc_r.id, "audio_out", flt_r.id, "audio_in")
    _connect(p, flt_r.id, "audio_out", phaser.id, "audio_in")
    _connect(p, phaser.id, "audio_out", rev_r.id, "audio_in")
    _connect(p, rev_r.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_chorale():
    """Chorale — Stereo Sine L + Triangle R + EQ4 (Gemeindegesang).

    Charakter: Hymnal-Stereo wie ein Bach-Choral — beide Seiten klar
    aber unterschiedlich gefärbt durch verschiedene Wellenformen.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_sine_osc, make_bragi_triangle_osc,
        make_forseti_eq4, make_iduna_reverb,
        make_heimdall_master_out,
    )
    p = Patch(name="Chorale")
    # L: Sine — Bass
    osc_l = make_bragi_sine_osc(); osc_l.position = (60, 100)
    _set(osc_l, freq=146.83, gain=0.4)  # D3
    eq_l = make_forseti_eq4(); eq_l.position = (260, 100)
    _set(eq_l, low_gain=2.0, lo_mid_gain=1.0,
         hi_mid_gain=-1.0, high_gain=-2.0)
    rev_l = make_iduna_reverb(); rev_l.position = (460, 100)
    _set(rev_l, room_size=0.7, damping=0.4, mix=0.35)  # warmer Kirchenraum
    # R: Triangle — Sopran
    osc_r = make_bragi_triangle_osc(); osc_r.position = (60, 280)
    _set(osc_r, freq=440.0, gain=0.3)  # A4
    eq_r = make_forseti_eq4(); eq_r.position = (260, 280)
    _set(eq_r, low_gain=-3.0, lo_mid_gain=0.0,
         hi_mid_gain=3.0, high_gain=2.0)
    rev_r = make_iduna_reverb(); rev_r.position = (460, 280)
    _set(rev_r, room_size=0.7, damping=0.4, mix=0.35)
    out = make_heimdall_master_out(); out.position = (680, 190)
    for m in (osc_l, eq_l, rev_l, osc_r, eq_r, rev_r, out):
        p.add_module(m)
    _connect(p, osc_l.id, "audio_out", eq_l.id, "audio_in")
    _connect(p, eq_l.id, "audio_out", rev_l.id, "audio_in")
    _connect(p, rev_l.id, "audio_out", out.id, "audio_in_l")
    _connect(p, osc_r.id, "audio_out", eq_r.id, "audio_in")
    _connect(p, eq_r.id, "audio_out", rev_r.id, "audio_in")
    _connect(p, rev_r.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_pedal_solo():
    """Pedal-Solo — Sub-Square 65Hz + LFO-Vibrato + Thor.TubeDrive (Pedal-Tritte).

    Charakter: tiefer Square + leichtes LFO-Vibrato auf gain + Tube-
    Drive für reedy Pedal-Pfeifen-Sound. Niedrigste Lage.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_square_osc, make_loki_lfo_sine,
        make_forseti_lowpass, make_thor_tube_drive,
        make_iduna_reverb, make_heimdall_master_out,
    )
    p = Patch(name="Pedal-Solo")
    osc = make_bragi_square_osc(); osc.position = (80, 200)
    _set(osc, freq=65.41, gain=0.45)  # C2
    lfo = make_loki_lfo_sine(); lfo.position = (80, 60)
    _set(lfo, rate=4.5, depth=0.08)  # leichtes Vibrato
    flt = make_forseti_lowpass(); flt.position = (300, 200)
    _set(flt, cutoff=900.0, resonance=0.5)
    drive = make_thor_tube_drive(); drive.position = (520, 200)
    _set(drive, drive=8.0, tone=0.4, mix=0.7)  # warmer Pfeifenkörper
    rev = make_iduna_reverb(); rev.position = (740, 200)
    _set(rev, room_size=0.75, damping=0.5, mix=0.32)
    out = make_heimdall_master_out(); out.position = (940, 200)
    for m in (osc, lfo, flt, drive, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", flt.id, "audio_in")
    _connect(p, flt.id, "audio_out", drive.id, "audio_in")
    _connect(p, drive.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    # LFO → osc.gain (Vibrato)
    _connect(p, lfo.id, "cv_out", osc.id, "gain")
    return p


def _build_leipzig_stop():
    """Leipzig-Stop — Plenum Square + Bandpass-Res + Tube-Drive + Max-Reverb.

    Charakter: das volle Werk in der Thomaskirche — alle Register ge-
    zogen. Bandpass+Tube für Pfeifenton, großer Reverb für Kirchenraum.
    Dieser Preset darf reverb-dominiert klingen — DAS ist Leipzig.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_square_osc, make_forseti_bandpass,
        make_thor_tube_drive, make_skadi_stereo_imager,
        make_iduna_reverb, make_heimdall_master_out,
    )
    p = Patch(name="Leipzig-Stop")
    osc = make_bragi_square_osc(); osc.position = (60, 200)
    _set(osc, freq=130.81, gain=0.4)  # C3 - Plenum-Lage
    flt = make_forseti_bandpass(); flt.position = (260, 200)
    _set(flt, cutoff=1100.0, resonance=0.7)  # reedy
    drive = make_thor_tube_drive(); drive.position = (460, 200)
    _set(drive, drive=14.0, tone=0.5, mix=0.7)  # Pfeifen-Wärme
    imager = make_skadi_stereo_imager(); imager.position = (660, 200)
    _set(imager, width=1.7, mix=1.0)  # voll/breit
    rev = make_iduna_reverb(); rev.position = (860, 200)
    _set(rev, room_size=0.92, damping=0.3, mix=0.55)  # MAX — Kirchenraum
    out = make_heimdall_master_out(); out.position = (1060, 200)
    for m in (osc, flt, drive, imager, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", flt.id, "audio_in")
    _connect(p, flt.id, "audio_out", drive.id, "audio_in")
    _connect(p, drive.id, "audio_out", imager.id, "audio_in")
    _connect(p, imager.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    return p


# ─── Preset-Liste ─────────────────────────────────────────────────


def _build_all() -> list[dict]:
    """Baut alle 12 Bach-v1-Patches.  Wird **lazy** beim ersten
    Vault-Import aufgerufen."""
    builders = [
        ("Toccata",       "Square + Bandpass-Res + Saturation (reedy aufweckend).",
         ["organ", "reedy", "saturation", "barock"], "D3", _build_toccata),
        ("Fugue",         "Stereo Triangle L + Saw R + EQ4 (zwei-stimmige Polyphonie).",
         ["polyphonic", "stereo", "fugue", "barock"], "C4", _build_fugue),
        ("Prelude",       "Sine + Tilt(+) + sanfter Reverb (klar fließend).",
         ["bright", "flowing", "tilt", "wtc"], "C4", _build_prelude),
        ("Cantata",       "Saw + Chorus + Compressor (vox-artig warm).",
         ["vocal", "warm", "chorus", "cantata"], "A3", _build_cantata),
        ("Aria",          "Triangle + EQ4 (Vox-Mid-Boost) + sanfter Reverb (Solostimme).",
         ["solo", "vocal", "aria", "warm"], "E4", _build_aria),
        ("Invention",     "Stereo 2-Stimmen Triangle + Tilt (didaktische Polyphonie).",
         ["polyphonic", "stereo", "didactic", "barock"], "C5", _build_invention),
        ("Sinfonia",      "Stereo Saw L + Square R + Saturation (drei-stimmig dicht).",
         ["polyphonic", "dense", "saturation", "stereo"], "C4", _build_sinfonia),
        ("Goldberg",      "Saw + BitCrush(subtil) + EQ4 (Cembalo-Sound).",
         ["harpsichord", "perling", "bitcrush", "barock"], "A4", _build_goldberg),
        ("Fantasia",      "Square + Phaser + Sub-Bass-Drone (Improvisations-Charakter).",
         ["fantasia", "phaser", "improvisation", "stereo"], "C2", _build_fantasia),
        ("Chorale",       "Stereo Sine L + Triangle R + EQ4 (Gemeindegesang).",
         ["chorale", "stereo", "hymnal", "warm"], "D3", _build_chorale),
        ("Pedal-Solo",    "Sub-Square 65Hz + LFO-Vibrato + TubeDrive (Pedal-Tritte).",
         ["bass", "pedal", "vibrato", "tube"], "C2", _build_pedal_solo),
        ("Leipzig-Stop",  "Plenum Square + Bandpass + Tube + Max-Reverb (volles Werk).",
         ["plenum", "huge", "organ", "leipzig"], "C3", _build_leipzig_stop),
    ]

    presets = []
    for name, desc, tags, key, builder in builders:
        patch_dict = _build_patch_dict(name, builder)
        if patch_dict is None:
            logger.warning("[BachPresets-v1] %s skipped (build failed)", name)
            continue
        presets.append({
            "name": name,
            "description": desc,
            "tags": tags,
            "musical_key": key,
            "bpm": None,
            "author": BACH_FACTORY_AUTHOR,
            "icon_svg": "",
            "patch": patch_dict,
        })
    return presets


class _LazyPresetList:
    """Wrapper: baut die Patches erst beim ersten Iterieren."""

    def __init__(self):
        self._cache: Optional[list[dict]] = None

    def _ensure(self) -> list[dict]:
        if self._cache is None:
            self._cache = _build_all()
            logger.info(
                "[BachPresets-v1] built %d Bach presets (%s) lazily",
                len(self._cache), BACH_FACTORY_VERSION,
            )
        return self._cache

    def __iter__(self):
        return iter(self._ensure())

    def __len__(self):
        return len(self._ensure())

    def __getitem__(self, i):
        return self._ensure()[i]


BACH_PRESETS = _LazyPresetList()


__all__ = [
    "BACH_PRESETS",
    "BACH_FACTORY_VERSION",
    "BACH_FACTORY_AUTHOR",
]
