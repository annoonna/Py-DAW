"""CS2 Slice-0 helpers for project-header and transport runtime wiring.

Safety-first goal:
- keep the legacy Project and TransportService alive
- open a single, explicit command path for the Slice-0 core fields
- avoid broad architectural churn while CS2 is still in bootstrap mode
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
import copy
import logging
import math
from typing import Any

from pydaw.model.project import Project


log = logging.getLogger(__name__)


_DEF_TS = "4/4"
_SNAP_DIVISION_TO_BEATS: dict[str, float] = {
    "1/1": 4.0,
    "1/2": 2.0,
    "1/4": 1.0,
    "1/8": 0.5,
    "1/16": 0.25,
    "1/32": 0.125,
    "1/64": 0.0625,
}


def _norm_ts(value: str) -> str:
    ts = str(value or _DEF_TS).strip()
    return ts or _DEF_TS


def _float_default(value: Any, default: float) -> float:
    try:
        if value is None:
            return float(default)
        return float(value)
    except Exception:
        return float(default)


def _int_default(value: Any, default: int) -> int:
    try:
        if value is None:
            return int(default)
        return int(value)
    except Exception:
        return int(default)



def _norm_snap_division(value: Any) -> str:
    snap = str(value or "1/16").strip()
    return snap or "1/16"


def time_signature_to_beats_per_bar(value: Any) -> float:
    ts = str(value or _DEF_TS).strip()
    try:
        if "/" not in ts:
            return 4.0
        lhs, rhs = ts.split("/", 1)
        num = float(lhs.strip())
        den = float(rhs.strip())
        if den <= 0:
            return 4.0
        return max(0.25, float(num) * (4.0 / float(den)))
    except Exception:
        return 4.0


def grid_snap_to_beats(value: Any, *, beats_per_bar: float | None = None) -> float:
    snap = _norm_snap_division(value)
    lowered = snap.lower()
    if "bar" in lowered:
        return max(0.25, float(beats_per_bar if beats_per_bar is not None else 4.0))
    if "beat" in lowered:
        return 1.0
    return float(_SNAP_DIVISION_TO_BEATS.get(snap, 0.25))


def snap_division_to_beats(value: Any) -> float:
    return grid_snap_to_beats(value)


def snap_beat_to_grid(beat: Any, *, snap_beats: Any, enabled: bool = True) -> float:
    """Pure Arranger/PianoRoll beat snapping helper for UI-driven ruler actions."""

    snapped = max(0.0, _float_default(beat, 0.0))
    grid = max(0.0, _float_default(snap_beats, 0.0))
    if (not enabled) or grid <= 1e-9:
        return snapped
    return max(0.0, round(snapped / grid) * grid)


def arranger_ruler_min_beats(snap_beats: Any, *, floor_beats: float = 0.25) -> float:
    """Return the minimum safe ruler region length for loop/punch editing."""

    return max(_float_default(floor_beats, 0.25), _float_default(snap_beats, 0.0))


def normalize_arranger_ruler_region(
    start: Any,
    end: Any,
    *,
    snap_beats: Any,
    floor_beats: float = 0.25,
) -> tuple[float, float]:
    """Normalize loop/punch ruler regions while preserving a minimum visible length."""

    s = max(0.0, _float_default(start, 0.0))
    e = max(0.0, _float_default(end, s))
    if e < s:
        s, e = e, s
    min_len = arranger_ruler_min_beats(snap_beats, floor_beats=floor_beats)
    e = max(s + min_len, e)
    return float(s), float(e)


def default_arranger_loop_region(anchor_beat: Any, *, snap_beats: Any, default_beats: float = 1.0) -> tuple[float, float]:
    """Return the default loop region created from a single ruler click."""

    start = max(0.0, _float_default(anchor_beat, 0.0))
    min_len = max(arranger_ruler_min_beats(snap_beats), _float_default(default_beats, 1.0))
    return normalize_arranger_ruler_region(start, start + min_len, snap_beats=snap_beats)


def default_arranger_punch_region_from_here(
    in_beat: Any,
    current_out_beat: Any,
    *,
    snap_beats: Any,
    multiplier: float = 4.0,
) -> tuple[float, float]:
    """Return a safe punch region for the "Punch In hier setzen" ruler action."""

    start = max(0.0, _float_default(in_beat, 0.0))
    base_len = max(
        arranger_ruler_min_beats(snap_beats),
        max(0.0, _float_default(snap_beats, 0.0)) * max(1.0, _float_default(multiplier, 4.0)),
    )
    target_end = max(start + base_len, _float_default(current_out_beat, start + base_len))
    return normalize_arranger_ruler_region(start, target_end, snap_beats=snap_beats)


def fraction_label_to_beats(value: Any, *, default: float = 0.25) -> float:
    """Pure fraction-label -> beat mapping for UI-only note/grid helpers.

    Keeps the long-standing timeline convention intact where a quarter note is
    one beat. Unknown values intentionally fall back to the caller-provided
    default instead of raising.
    """

    try:
        label = _norm_snap_division(value)
        return float(_SNAP_DIVISION_TO_BEATS.get(label, default))
    except Exception:
        return float(default)


def beats_to_fraction_label(value: Any, *, default: str = "?") -> str:
    """Return a stable fraction label for a beat duration.

    Supports the UI's dotted-duration convention by recognizing 1.5x multiples
    of the canonical fraction map.
    """

    try:
        beats = float(value)
    except Exception:
        return str(default)
    for base, frac in sorted(_SNAP_DIVISION_TO_BEATS.items(), key=lambda item: -item[1]):
        beat_value = float(frac)
        if abs(beats - beat_value) < 1e-6:
            return str(base)
        if abs(beats - (beat_value * 1.5)) < 1e-6:
            return f"{base}."
    return f"{beats:g} beat"


def beats_to_bar_beat_sub(value: Any, *, beats_per_bar: float = 4.0, substeps_per_beat: int = 100) -> str:
    """Format beats as 1-based Bar.Beat.Sub text for low-risk UI displays."""

    beats = _float_default(value, 0.0)
    bpb = max(1e-6, _float_default(beats_per_bar, 4.0))
    subs = max(1, _int_default(substeps_per_beat, 100))
    bar = int(beats / bpb) + 1
    beat_in_bar = int(beats % bpb) + 1
    sub = int((beats % 1.0) * subs)
    return f"{bar}.{beat_in_bar}.{sub:02d}"


def beats_to_legacy_bbs_tick_text(value: Any, *, beats_per_bar: float = 4.0) -> str:
    """Format beats as historic ``Bar.Beat.Step.Tick`` text.

    This intentionally preserves the export dialog's long-standing, coarse
    whole-beat display semantics: fractional beat positions are truncated to
    the containing beat and rendered as ``.1.00``. The helper is pure and safe
    to mirror into small UI-only labels without changing engine/export logic.
    """

    beats = max(0.0, _float_default(value, 0.0))
    bpb = max(1e-6, _float_default(beats_per_bar, 4.0))
    whole_beats = max(0, int(math.floor(beats + 1e-9)))
    bar = int(whole_beats / bpb) + 1
    beat_in_bar = int(whole_beats % bpb) + 1
    return f"{bar}.{beat_in_bar}.1.00"


def round_beats_up_to_full_bars(
    value: Any,
    *,
    beats_per_bar: float = 4.0,
    extra_bars: int = 1,
    min_total_beats: float | None = None,
) -> float:
    """Round a beat length up to full bars and optionally add comfort bars.

    This helper is intentionally pure and UI-facing: editors can keep their
    historic "round up to whole bars + a little extra room" behavior without
    re-implementing local time-signature math.
    """

    beats = max(0.0, _float_default(value, 0.0))
    bpb = max(1e-6, _float_default(beats_per_bar, 4.0))
    extra = max(0, _int_default(extra_bars, 1))
    min_beats = max(bpb, _float_default(min_total_beats, bpb) if min_total_beats is not None else bpb)
    bars = int(math.ceil((beats / bpb) - 1e-9)) + extra
    bars = max(1, bars)
    return max(min_beats, float(bars) * bpb)


def round_beat_to_bar_boundary(value: Any, *, beats_per_bar: float = 4.0, mode: str = "nearest") -> float:
    """Snap a beat position to the surrounding bar grid in a pure helper."""

    beats = max(0.0, _float_default(value, 0.0))
    bpb = max(1e-6, _float_default(beats_per_bar, 4.0))
    ratio = beats / bpb
    mode_norm = str(mode or "nearest").strip().lower()
    if mode_norm in {"down", "floor", "start"}:
        steps = math.floor(ratio + 1e-9)
    elif mode_norm in {"up", "ceil", "end"}:
        steps = math.ceil(ratio - 1e-9)
    else:
        steps = round(ratio)
    return max(0.0, float(steps) * bpb)


def is_bar_boundary_beat(value: Any, *, beats_per_bar: float = 4.0, epsilon: float = 1e-4) -> bool:
    """Return True when a beat lies on a bar boundary for lightweight UI marks."""

    beats = max(0.0, _float_default(value, 0.0))
    bpb = max(1e-6, _float_default(beats_per_bar, 4.0))
    ratio = beats / bpb
    return abs(ratio - round(ratio)) <= max(1e-9, _float_default(epsilon, 1e-4))


def beat_to_bar_number(value: Any, *, beats_per_bar: float = 4.0) -> int:
    """Return the historic 1-based bar number for a beat position."""

    beats = max(0.0, _float_default(value, 0.0))
    bpb = max(1e-6, _float_default(beats_per_bar, 4.0))
    return max(1, int(math.floor((beats / bpb) + 1e-9)) + 1)


def ui_bar_to_beat(value: Any, *, beats_per_bar: float = 4.0) -> float:
    """Map the toolbar's 1-based bar number display back to a beat position."""

    return max(0.0, (_float_default(value, 1.0) - 1.0) * max(1e-6, _float_default(beats_per_bar, 4.0)))


def beat_to_ui_bar(value: Any, *, beats_per_bar: float = 4.0) -> float:
    """Map a beat position to the toolbar's historic 1-based bar display."""

    return 1.0 + (_float_default(value, 0.0) / max(1e-6, _float_default(beats_per_bar, 4.0)))


def read_grid_snap_from_project(project: Project) -> "CS2GridSnapReadModel":
    """Pure Slice-0 Grid/Snap reader for low-risk utility/side views."""
    header = LegacyProjectCoreAdapter().read(project)
    model = CS2GridSnapReadModel(
        snap_division=_norm_snap_division(header.snap_division),
        snap_beats=grid_snap_to_beats(
            header.snap_division,
            beats_per_bar=time_signature_to_beats_per_bar(header.time_signature),
        ),
    )
    log.debug(
        "[CS2-L] Pure Slice-0 grid/snap read division=%s beats=%.6f",
        model.snap_division,
        model.snap_beats,
    )
    return model


def read_arranger_ruler_from_context(source: Any | None, *, transport: Any | None = None) -> "CS2ArrangerRulerReadModel":
    """Shared low-risk reader for Arranger ruler / loop / punch semantics.

    Preference order:
    1. existing ProjectService/Slice-0 readmodel when available
    2. pure project-object + optional transport fallback
    """

    try:
        reader = getattr(source, "slice0_read_arranger_ruler_semantics", None)
        if callable(reader):
            model = reader(transport=transport)
            log.debug(
                "[CS2-U] Shared Arranger ruler reader via service snap=%s min=%.6f",
                getattr(model, "snap_division", "1/16"),
                float(getattr(model, "ruler_min_beats", 0.25) or 0.25),
            )
            return model
    except Exception:
        pass
    project = _project_from_grid_snap_source(source)
    header = LegacyProjectCoreAdapter().read(project) if project is not None else CS2ProjectHeader()
    grid = read_grid_snap_from_project(project) if project is not None else CS2GridSnapReadModel()
    beats_per_bar = max(0.25, float(time_signature_to_beats_per_bar(getattr(header, "time_signature", _DEF_TS))))
    runtime = LegacyTransportRuntimeAdapter().read(transport) if transport is not None else CS2TransportRuntime()
    model = CS2ArrangerRulerReadModel(
        snap_division=_norm_snap_division(getattr(grid, "snap_division", "1/16")),
        snap_beats=max(0.0, float(getattr(grid, "snap_beats", 0.25) or 0.25)),
        beats_per_bar=beats_per_bar,
        ruler_min_beats=arranger_ruler_min_beats(getattr(grid, "snap_beats", 0.25)),
        playhead_beat=max(0.0, float(getattr(runtime, "current_beat", 0.0) or 0.0)),
        loop_enabled=bool(getattr(runtime, "loop_enabled", False)),
        loop_start=max(0.0, float(getattr(runtime, "loop_start", 0.0) or 0.0)),
        loop_end=max(0.0, float(getattr(runtime, "loop_end", 16.0) or 16.0)),
        punch_enabled=bool(getattr(header, "punch_enabled", False)),
        punch_in_beat=max(0.0, float(getattr(header, "punch_in_beat", 4.0) or 4.0)),
        punch_out_beat=max(0.0, float(getattr(header, "punch_out_beat", 16.0) or 16.0)),
    )
    log.debug(
        "[CS2-U] Shared Arranger ruler reader via pure fallback snap=%s min=%.6f",
        model.snap_division,
        model.ruler_min_beats,
    )
    return model


def _project_from_grid_snap_source(source: Any | None) -> Project | None:
    try:
        if isinstance(source, Project):
            return source
    except Exception:
        pass
    try:
        return getattr(getattr(source, "ctx", None), "project", None)
    except Exception:
        return None


def read_grid_snap_from_context(source: Any | None) -> "CS2GridSnapReadModel":
    """Shared low-risk Grid/Snap reader for UI helpers and small side views.

    Preference order:
    1. existing ProjectService/Slice-0 readmodel when available
    2. pure project-object reader via the legacy Slice-0 adapter
    3. tiny normalized fallback when neither is available
    """
    project = _project_from_grid_snap_source(source)
    try:
        reader = getattr(source, "slice0_read_grid_snap", None)
        if callable(reader):
            model = reader()
            div = _norm_snap_division(getattr(model, "snap_division", "1/16"))
            beats = _float_default(getattr(model, "snap_beats", None), 0.0)
            if beats <= 1e-9:
                beats = grid_snap_to_beats(
                    div,
                    beats_per_bar=time_signature_to_beats_per_bar(getattr(project, "time_signature", _DEF_TS)) if project is not None else None,
                )
            out = CS2GridSnapReadModel(snap_division=div, snap_beats=max(1e-6, float(beats)))
            log.debug(
                "[CS2-N] Shared grid/snap context read via service division=%s beats=%.6f",
                out.snap_division,
                out.snap_beats,
            )
            return out
    except Exception as exc:
        log.debug("[CS2-N] Shared grid/snap service reader fallback active: %s", exc)
    if project is not None:
        model = read_grid_snap_from_project(project)
        log.debug(
            "[CS2-N] Shared grid/snap context read via project division=%s beats=%.6f",
            model.snap_division,
            model.snap_beats,
        )
        return model
    div = _norm_snap_division(getattr(source, "snap_division", "1/16") if source is not None else "1/16")
    model = CS2GridSnapReadModel(snap_division=div, snap_beats=max(1e-6, grid_snap_to_beats(div)))
    log.debug(
        "[CS2-N] Shared grid/snap context fallback division=%s beats=%.6f",
        model.snap_division,
        model.snap_beats,
    )
    return model


@dataclass
class CS2ProjectHeader:
    version: str = ""
    name: str = "Neues Projekt"
    created_utc: str = ""
    modified_utc: str = ""
    sample_rate: int = 48000
    bpm: float = 120.0
    time_signature: str = _DEF_TS
    snap_division: str = "1/16"
    punch_enabled: bool = False
    punch_in_beat: float = 4.0
    punch_out_beat: float = 16.0
    pre_roll_bars: int = 0
    post_roll_bars: int = 0


@dataclass
class CS2GridSnapReadModel:
    snap_division: str = "1/16"
    snap_beats: float = 0.25


@dataclass
class CS2ArrangerRulerReadModel:
    snap_division: str = "1/16"
    snap_beats: float = 0.25
    beats_per_bar: float = 4.0
    ruler_min_beats: float = 0.25
    playhead_beat: float = 0.0
    loop_enabled: bool = False
    loop_start: float = 0.0
    loop_end: float = 16.0
    punch_enabled: bool = False
    punch_in_beat: float = 4.0
    punch_out_beat: float = 16.0


@dataclass
class CS2TransportRuntime:
    playing: bool = False
    current_beat: float = 0.0
    loop_enabled: bool = False
    loop_start: float = 0.0
    loop_end: float = 16.0
    metronome_enabled: bool = False
    count_in_bars: int = 0
    external_playhead_samples: int | None = None
    external_sample_rate: float = 44100.0


class LegacyProjectCoreAdapter:
    """Map the small Slice-0 project header to and from the legacy Project."""

    def read(self, project: Project) -> CS2ProjectHeader:
        return CS2ProjectHeader(
            version=str(getattr(project, "version", "") or ""),
            name=str(getattr(project, "name", "Neues Projekt") or "Neues Projekt"),
            created_utc=str(getattr(project, "created_utc", "") or ""),
            modified_utc=str(getattr(project, "modified_utc", "") or ""),
            sample_rate=_int_default(getattr(project, "sample_rate", 48000), 48000),
            bpm=_float_default(getattr(project, "bpm", 120.0), 120.0),
            time_signature=_norm_ts(getattr(project, "time_signature", _DEF_TS)),
            snap_division=_norm_snap_division(getattr(project, "snap_division", "1/16")),
            punch_enabled=bool(getattr(project, "punch_enabled", False)),
            punch_in_beat=_float_default(getattr(project, "punch_in_beat", 4.0), 4.0),
            punch_out_beat=_float_default(getattr(project, "punch_out_beat", 16.0), 16.0),
            pre_roll_bars=_int_default(getattr(project, "pre_roll_bars", 0), 0),
            post_roll_bars=_int_default(getattr(project, "post_roll_bars", 0), 0),
        )

    def write(self, header: CS2ProjectHeader, project: Project) -> None:
        project.version = str(header.version or getattr(project, "version", ""))
        project.name = str(header.name or getattr(project, "name", "Neues Projekt"))
        project.created_utc = str(header.created_utc or getattr(project, "created_utc", ""))
        project.modified_utc = str(header.modified_utc or getattr(project, "modified_utc", ""))
        project.sample_rate = int(max(1, int(header.sample_rate or 48000)))
        project.bpm = float(max(10.0, float(header.bpm or 120.0)))
        project.time_signature = _norm_ts(header.time_signature)
        project.snap_division = _norm_snap_division(header.snap_division)
        project.punch_enabled = bool(header.punch_enabled)
        project.punch_in_beat = max(0.0, float(header.punch_in_beat or 0.0))
        project.punch_out_beat = max(project.punch_in_beat + 0.25, float(header.punch_out_beat or 0.0))
        project.pre_roll_bars = max(0, min(8, int(header.pre_roll_bars or 0)))
        project.post_roll_bars = max(0, min(8, int(header.post_roll_bars or 0)))


def _normalized_header(header: CS2ProjectHeader) -> CS2ProjectHeader:
    temp = Project()
    adapter = LegacyProjectCoreAdapter()
    adapter.write(header, temp)
    return adapter.read(temp)


class Slice0ProjectPersistenceAdapter:
    """Centralize Slice-0 save/load normalization for the project header."""

    def __init__(self):
        self.project_adapter = LegacyProjectCoreAdapter()

    def read(self, project: Project) -> CS2ProjectHeader:
        return _normalized_header(self.project_adapter.read(project))

    def normalize_project(self, project: Project) -> CS2ProjectHeader:
        header = self.read(project)
        self.project_adapter.write(header, project)
        return copy.deepcopy(header)

    def payload_patch(self, project: Project) -> dict[str, Any]:
        return asdict(self.read(project))


class Slice0ProjectMetaMirrorAdapter:
    """Persist/recover the Slice-0 header through the legacy SQLite mirror."""

    HEADER_EXTRA_KEY = "cs2_project_header"

    def __init__(self):
        self.persistence = Slice0ProjectPersistenceAdapter()

    def merge_extra(self, project: Project, extra: dict[str, Any] | None = None) -> tuple[CS2ProjectHeader, dict[str, Any]]:
        merged = copy.deepcopy(extra or {})
        header = self.persistence.read(project)
        merged[self.HEADER_EXTRA_KEY] = asdict(header)
        return header, merged

    def _from_mapping(self, data: dict[str, Any], *, default_name: str = "Recovered Project") -> CS2ProjectHeader:
        header = CS2ProjectHeader(
            version=str(data.get("version", "") or ""),
            name=str(data.get("name", default_name) or default_name),
            created_utc=str(data.get("created_utc", "") or ""),
            modified_utc=str(data.get("modified_utc", "") or ""),
            sample_rate=_int_default(data.get("sample_rate", 48000), 48000),
            bpm=_float_default(data.get("bpm", 120.0), 120.0),
            time_signature=_norm_ts(data.get("time_signature", _DEF_TS)),
            snap_division=_norm_snap_division(data.get("snap_division", "1/16")),
            punch_enabled=bool(data.get("punch_enabled", False)),
            punch_in_beat=_float_default(data.get("punch_in_beat", 4.0), 4.0),
            punch_out_beat=_float_default(data.get("punch_out_beat", 16.0), 16.0),
            pre_roll_bars=_int_default(data.get("pre_roll_bars", 0), 0),
            post_roll_bars=_int_default(data.get("post_roll_bars", 0), 0),
        )
        return _normalized_header(header)

    def header_from_meta(self, meta: dict[str, Any], extra: dict[str, Any] | None = None) -> CS2ProjectHeader:
        extra = extra or {}
        header_blob = extra.get(self.HEADER_EXTRA_KEY)
        if isinstance(header_blob, dict):
            return self._from_mapping(header_blob, default_name=str(meta.get("project_name", "Recovered Project") or "Recovered Project"))
        legacy_data = {
            "version": extra.get("version", ""),
            "name": meta.get("project_name", extra.get("name", "Recovered Project")),
            "created_utc": extra.get("created_utc", ""),
            "modified_utc": extra.get("modified_utc", ""),
            "sample_rate": meta.get("sample_rate", 48000),
            "bpm": meta.get("bpm", 120.0),
            "time_signature": meta.get("time_signature", _DEF_TS),
            "snap_division": meta.get("snap_division", "1/16"),
            "punch_enabled": bool(meta.get("punch_enabled", 0)),
            "punch_in_beat": meta.get("punch_in_beat", 4.0),
            "punch_out_beat": meta.get("punch_out_beat", 16.0),
            "pre_roll_bars": meta.get("pre_roll_bars", 0),
            "post_roll_bars": meta.get("post_roll_bars", 0),
        }
        return self._from_mapping(legacy_data, default_name=str(meta.get("project_name", "Recovered Project") or "Recovered Project"))

    def apply_to_project_dict(self, meta: dict[str, Any], extra: dict[str, Any] | None, result: dict[str, Any]) -> CS2ProjectHeader:
        header = self.header_from_meta(meta, extra)
        result.update(asdict(header))
        return header


class LegacyTransportConfigAdapter:
    """Project-header -> legacy TransportService projection."""

    def apply(self, header: CS2ProjectHeader, transport: Any) -> None:
        transport.set_bpm(float(header.bpm))
        transport.set_time_signature(_norm_ts(header.time_signature))
        transport.set_punch_region(float(header.punch_in_beat), float(header.punch_out_beat))
        transport.set_punch(bool(header.punch_enabled))
        transport.set_pre_roll_bars(int(header.pre_roll_bars))
        transport.set_post_roll_bars(int(header.post_roll_bars))


class LegacyTransportRuntimeAdapter:
    """Legacy TransportService <-> Slice-0 runtime snapshot."""

    def read(self, transport: Any) -> CS2TransportRuntime:
        return CS2TransportRuntime(
            playing=bool(getattr(transport, "playing", False)),
            current_beat=_float_default(getattr(transport, "current_beat", 0.0), 0.0),
            loop_enabled=bool(getattr(transport, "loop_enabled", False)),
            loop_start=_float_default(getattr(transport, "loop_start", 0.0), 0.0),
            loop_end=_float_default(getattr(transport, "loop_end", 16.0), 16.0),
            metronome_enabled=bool(getattr(transport, "metronome_enabled", False)),
            count_in_bars=_int_default(getattr(transport, "count_in_bars", 0), 0),
            external_playhead_samples=getattr(transport, "_external_playhead_samples", None),
            external_sample_rate=_float_default(getattr(transport, "_external_sample_rate", 44100.0), 44100.0),
        )

    def apply(self, runtime: CS2TransportRuntime, transport: Any, *, include_position: bool = True, include_playing: bool = False) -> None:
        transport.set_metronome(bool(runtime.metronome_enabled))
        transport.set_count_in_bars(int(runtime.count_in_bars))
        self.apply_loop(runtime, transport)
        if include_position:
            try:
                transport.seek(float(runtime.current_beat))
            except Exception:
                pass
        if runtime.external_playhead_samples is None:
            try:
                transport._clear_external_clock()
            except Exception:
                try:
                    transport._clear_external_playhead()
                except Exception:
                    pass
        else:
            try:
                transport._set_external_playhead_samples(
                    int(runtime.external_playhead_samples),
                    float(runtime.external_sample_rate),
                )
            except Exception:
                pass
        if include_playing:
            transport.set_playing(bool(runtime.playing))

    def apply_loop(self, runtime: CS2TransportRuntime, transport: Any) -> None:
        transport.set_loop_region(float(runtime.loop_start), float(runtime.loop_end))
        transport.set_loop(bool(runtime.loop_enabled))


class Slice0CoreTransportCoordinator:
    """Thin adapter coordinator for the first CS2 technical slice."""

    def __init__(self, transport: Any | None = None):
        self.transport = transport
        self.project_adapter = LegacyProjectCoreAdapter()
        self.transport_config_adapter = LegacyTransportConfigAdapter()
        self.transport_runtime_adapter = LegacyTransportRuntimeAdapter()
        self.project_header = CS2ProjectHeader()
        self.transport_runtime = CS2TransportRuntime()

    def attach_transport(self, transport: Any) -> None:
        self.transport = transport

    def bootstrap(self, project: Project, transport: Any | None = None) -> None:
        if transport is not None:
            self.transport = transport
        if self.transport is None:
            return
        self.project_header = self.project_adapter.read(project)
        self.transport_runtime = self.transport_runtime_adapter.read(self.transport)
        self.transport_config_adapter.apply(self.project_header, self.transport)

    def commit_project_header(self, project: Project, transport: Any | None = None) -> None:
        if transport is not None:
            self.transport = transport
        self.project_adapter.write(self.project_header, project)
        if self.transport is not None:
            self.transport_config_adapter.apply(self.project_header, self.transport)

    def set_bpm(self, project: Project, bpm: float, transport: Any | None = None) -> None:
        self.project_header = self.project_adapter.read(project)
        self.project_header.bpm = float(max(10.0, float(bpm)))
        self.commit_project_header(project, transport=transport)

    def set_time_signature(self, project: Project, time_signature: str, transport: Any | None = None) -> None:
        self.project_header = self.project_adapter.read(project)
        self.project_header.time_signature = _norm_ts(time_signature)
        self.commit_project_header(project, transport=transport)

    def set_snap_division(self, project: Project, snap_division: str, transport: Any | None = None) -> None:
        self.project_header = self.project_adapter.read(project)
        self.project_header.snap_division = _norm_snap_division(snap_division)
        log.debug("[CS2-J] Slice-0 write snap_division=%s", self.project_header.snap_division)
        self.commit_project_header(project, transport=transport)

    def read_grid_snap(self, project: Project) -> CS2GridSnapReadModel:
        model = read_grid_snap_from_project(project)
        log.debug(
            "[CS2-J] Slice-0 grid/snap readmodel division=%s beats=%.6f",
            model.snap_division,
            model.snap_beats,
        )
        return model

    def set_punch(self, project: Project, *, enabled: bool | None = None, in_beat: float | None = None, out_beat: float | None = None, transport: Any | None = None) -> None:
        self.project_header = self.project_adapter.read(project)
        if enabled is not None:
            self.project_header.punch_enabled = bool(enabled)
        if in_beat is not None:
            self.project_header.punch_in_beat = max(0.0, float(in_beat))
        if out_beat is not None:
            self.project_header.punch_out_beat = max(self.project_header.punch_in_beat + 0.25, float(out_beat))
        else:
            self.project_header.punch_out_beat = max(self.project_header.punch_in_beat + 0.25, float(self.project_header.punch_out_beat))
        self.commit_project_header(project, transport=transport)

    def set_pre_roll(self, project: Project, bars: int, transport: Any | None = None) -> None:
        self.project_header = self.project_adapter.read(project)
        self.project_header.pre_roll_bars = max(0, min(8, int(bars)))
        self.commit_project_header(project, transport=transport)

    def set_post_roll(self, project: Project, bars: int, transport: Any | None = None) -> None:
        self.project_header = self.project_adapter.read(project)
        self.project_header.post_roll_bars = max(0, min(8, int(bars)))
        self.commit_project_header(project, transport=transport)

    def set_loop_runtime(self, *, enabled: bool, start: float, end: float, transport: Any | None = None) -> None:
        if transport is not None:
            self.transport = transport
        if self.transport is None:
            return
        self.transport_runtime = self.transport_runtime_adapter.read(self.transport)
        self.transport_runtime.loop_enabled = bool(enabled)
        self.transport_runtime.loop_start = max(0.0, float(start))
        self.transport_runtime.loop_end = max(self.transport_runtime.loop_start + 0.25, float(end))
        self.transport_runtime_adapter.apply_loop(self.transport_runtime, self.transport)

    def read_arranger_ruler_semantics(self, project: Project, transport: Any | None = None) -> CS2ArrangerRulerReadModel:
        if transport is not None:
            self.transport = transport
        header = self.project_adapter.read(project)
        runtime = self.transport_runtime_adapter.read(self.transport) if self.transport is not None else CS2TransportRuntime()
        snap_beats = max(0.0, float(grid_snap_to_beats(header.snap_division, beats_per_bar=time_signature_to_beats_per_bar(header.time_signature))))
        model = CS2ArrangerRulerReadModel(
            snap_division=_norm_snap_division(header.snap_division),
            snap_beats=snap_beats,
            beats_per_bar=max(0.25, float(time_signature_to_beats_per_bar(header.time_signature))),
            ruler_min_beats=arranger_ruler_min_beats(snap_beats),
            playhead_beat=max(0.0, float(getattr(runtime, "current_beat", 0.0) or 0.0)),
            loop_enabled=bool(getattr(runtime, "loop_enabled", False)),
            loop_start=max(0.0, float(getattr(runtime, "loop_start", 0.0) or 0.0)),
            loop_end=max(0.0, float(getattr(runtime, "loop_end", 16.0) or 16.0)),
            punch_enabled=bool(header.punch_enabled),
            punch_in_beat=max(0.0, float(header.punch_in_beat or 0.0)),
            punch_out_beat=max(0.0, float(header.punch_out_beat or 16.0)),
        )
        log.debug(
            "[CS2-U] Slice-0 arranger ruler readmodel snap=%s snap_beats=%.6f min=%.6f loop=%s %.3f-%.3f punch=%s %.3f-%.3f playhead=%.3f",
            model.snap_division,
            model.snap_beats,
            model.ruler_min_beats,
            model.loop_enabled,
            model.loop_start,
            model.loop_end,
            model.punch_enabled,
            model.punch_in_beat,
            model.punch_out_beat,
            model.playhead_beat,
        )
        return model

    def project_header_snapshot(self) -> CS2ProjectHeader:
        return copy.deepcopy(self.project_header)

    def transport_runtime_snapshot(self) -> CS2TransportRuntime:
        return copy.deepcopy(self.transport_runtime)


# ---------------------------------------------------------------------------
# CS2-V — Arranger Clip-Edit pure helpers  (v0.0.21.134)
# ---------------------------------------------------------------------------
# These are stateless, side-effect-free helpers for clip Move / Resize /
# Left-Trim / Split / New-Clip semantics.  They centralise the snap, clamp
# and validation logic that was previously inlined across arranger_canvas.py
# and project_service.py.
# ---------------------------------------------------------------------------

@dataclass
class CS2ClipLeftTrimResult:
    """Return type for compute_clip_left_trim()."""
    start_beats: float
    length_beats: float
    offset_beats: float
    offset_seconds: float


@dataclass
class CS2ClipSplitResult:
    """Return type for validate_clip_split()."""
    left_length: float
    right_length: float
    right_start: float


@dataclass
class CS2NewClipBounds:
    """Return type for compute_new_clip_bounds()."""
    start_beats: float
    length_beats: float


def snap_clip_position(
    beat: Any,
    *,
    snap_beats: Any,
    enabled: bool = True,
) -> float:
    """Snap a clip start position to the grid.

    Mirrors the Ruler snap logic from CS2-U but is explicitly named for
    clip-edit context so that logging can distinguish CS2-V from CS2-U.
    """
    b = max(0.0, float(beat))
    if not enabled:
        return b
    g = _float_default(snap_beats, 0.0)
    if g <= 0.0:
        return b
    return max(0.0, round(b / g) * g)


def clamp_clip_length(
    length: Any,
    *,
    snap_beats: Any,
    min_beats: float = 0.25,
) -> float:
    """Clamp and optionally snap a clip length (right-resize).

    The returned length is always >= max(snap_beats, min_beats, 0.25).
    """
    g = _float_default(snap_beats, 0.0)
    floor = max(min_beats, 0.25)
    if g > 0.0:
        floor = max(floor, g)
    ln = max(floor, float(length))
    if g > 0.0:
        ln = max(floor, round(ln / g) * g)
    return ln


def compute_clip_left_trim(
    *,
    origin_start: float,
    origin_length: float,
    delta_beats: float,
    snap_beats: Any,
    enabled: bool = True,
    origin_offset_beats: float = 0.0,
    origin_offset_seconds: float = 0.0,
    bpm: float = 120.0,
) -> CS2ClipLeftTrimResult:
    """Compute new start / length / offsets after a left-edge trim drag.

    Pure function — does NOT mutate any clip.
    """
    new_start = float(origin_start) + float(delta_beats)
    if enabled:
        new_start = snap_clip_position(new_start, snap_beats=snap_beats, enabled=True)
    else:
        new_start = max(0.0, new_start)

    actual_delta = new_start - float(origin_start)
    new_len = float(origin_length) - actual_delta

    g = _float_default(snap_beats, 0.0)
    min_len = max(0.25, g) if g > 0 else 0.25
    if new_len < min_len:
        new_len = min_len
        new_start = float(origin_start) + (float(origin_length) - new_len)
        if enabled and g > 0:
            new_start = max(0.0, round(new_start / g) * g)
        actual_delta = new_start - float(origin_start)

    safe_bpm = max(1e-6, float(bpm))
    off_beats = max(0.0, float(origin_offset_beats) + actual_delta)
    off_secs = max(0.0, float(origin_offset_seconds) + actual_delta * 60.0 / safe_bpm)

    return CS2ClipLeftTrimResult(
        start_beats=max(0.0, new_start),
        length_beats=max(0.25, new_len),
        offset_beats=off_beats,
        offset_seconds=off_secs,
    )


def validate_clip_split(
    *,
    clip_start: float,
    clip_length: float,
    split_beat: float,
    min_piece_beats: float = 0.25,
) -> CS2ClipSplitResult | None:
    """Validate a clip split and return left/right lengths.

    Returns None when the split is invalid (outside clip or pieces too small).
    Pure function — does NOT mutate any clip.
    """
    cs = float(clip_start)
    cl = float(clip_length)
    sb = float(split_beat)
    mp = max(0.25, float(min_piece_beats))
    ce = cs + cl
    if sb <= cs or sb >= ce:
        return None
    left = sb - cs
    right = ce - sb
    if left < mp or right < mp:
        return None
    return CS2ClipSplitResult(left_length=left, right_length=right, right_start=sb)


def compute_new_clip_bounds(
    *,
    anchor_beat: float,
    current_beat: float,
    snap_beats: Any,
    enabled: bool = True,
    min_length: float = 0.25,
) -> CS2NewClipBounds:
    """Compute start and length for a newly drawn clip from drag gesture.

    The anchor is where the mouse-down happened; current is the live mouse
    position.  The caller has already converted pixel→beat.
    """
    a = float(anchor_beat)
    c = float(current_beat)
    if enabled:
        a = snap_clip_position(a, snap_beats=snap_beats, enabled=True)
        c = snap_clip_position(c, snap_beats=snap_beats, enabled=True)
    start = min(a, c)
    end = max(a, c)
    length = end - start

    g = _float_default(snap_beats, 0.0)
    floor = max(min_length, 0.25)
    if enabled and g > 0:
        floor = max(floor, g)
    if length < floor:
        length = floor

    return CS2NewClipBounds(start_beats=max(0.0, start), length_beats=length)
