"""
pydaw.flux.ui_widgets.number_flow — Frigg.NumberFlow (v0.0.21.231)
====================================================================

**Live-Probe-Display für CV/RUNE-Signale.**

Anno-Auftrag (mit zwei Screenshots): „könntest du noch ein number modul
bauen wo ich sehe das da zahlen durch gehen also nubers mit ein und
ausgängen ich will an lfo sehen ob da was durch kommt".

Im Gegensatz zu ``Frigg.VolvaNumber`` (rein editierbares Display ohne
Eingang) und ``Frigg.NumberBox`` (Editor-only) ist ``NumberFlow`` ein
**Probe**:

* hat einen ``cv_in`` Eingangs-Port (akzeptiert auch RUNE über die v.219
  Permissive-Connections-Bridge)
* zeigt den Wert live an (gerendert vom Audio-Preview, gepollt vom
  FluxScene-Tick)
* reicht den Wert unverändert an einen ``cv_out`` Ausgang weiter
* hält eine kleine 64-Sample-Sparkline-Historie für visuelles
  Live-Tracking (sichtbarer „Wellenform-Snapshot" unter der Zahl)

Use-Case: zwischen einen LFO und das Ziel-Modul gesetzt, um zu sehen ob
und welche Werte durch das Kabel fließen — wie ein Multimeter im Patch.

Design (Norse-Probe-Aesthetic)
------------------------------

* Kompaktes monospace Number-Display oben (großer Cyan-Wert mit Glow)
* Kleine Sparkline darunter (cyan Linie, neueste Werte rechts)
* Subtiler Pulse-Rahmen wenn der Wert sich ändert
* Min/Max-Indikatoren am Rand der Sparkline
* Read-only — kein Click/Drag/Wheel (die DATEN kommen vom Patch, nicht
  vom User)

Signal-Vertrag
--------------

* ``set_value(v, *, emit_signal=False)`` — wird aus dem FluxScene-Tick
  aufgerufen mit dem aktuellen Probe-Wert. ``emit_signal=False`` weil
  das ein read-only Display ist; es feuert kein ``value_changed``.
* ``value_changed`` Signal existiert (für API-Konsistenz mit den anderen
  Frigg-Widgets) feuert aber nie im Normal-Betrieb.
"""

from __future__ import annotations

import collections
import logging
from typing import Optional

logger = logging.getLogger(__name__)

try:
    from PyQt6.QtCore import (
        Qt, QPointF, QRectF, QSize, pyqtSignal,
    )
    from PyQt6.QtGui import (
        QColor, QPainter, QPen, QBrush, QFont, QPainterPath,
    )
    from PyQt6.QtWidgets import QWidget, QSizePolicy
    _QT_AVAILABLE = True
except ImportError:
    _QT_AVAILABLE = False


def _clamp(v: float, lo: float, hi: float) -> float:
    if v < lo:
        return lo
    if v > hi:
        return hi
    return v


if _QT_AVAILABLE:

    class NumberFlowWidget(QWidget):  # type: ignore[misc]
        """Live-Probe-Display für Werte die durch ein Patch-Kabel fließen.

        Wird embedded in Frigg.NumberFlow-Modul-Items. Updates kommen
        vom FluxScene-Tick (~20 Hz) der ``set_value()`` mit dem Wert
        aus ``audio_preview._module_values[mod_id]`` aufruft.
        """

        DEFAULT_W = 130
        DEFAULT_H = 78

        # Sparkline-History — wieviele Samples in der Historie
        HISTORY_LEN = 64

        # Style-Tokens (Norse-Cyan + zarte Probe-Aesthetik)
        BG_COLOR        = QColor(14, 20, 30)              # tiefes Dunkelblau
        BORDER_COL      = QColor(70, 110, 140, 200)
        ACTIVE_BORDER   = QColor(125, 215, 230, 220)      # bei Wert-Wechsel
        DIGIT_COL       = QColor(125, 215, 230)           # Norse-Cyan
        DIGIT_GLOW      = QColor(125, 215, 230, 90)
        SPARK_LINE_COL  = QColor(125, 215, 230, 220)
        SPARK_FILL_COL  = QColor(125, 215, 230, 40)
        SPARK_GRID_COL  = QColor(70, 110, 140, 80)
        UNIT_COL        = QColor(160, 200, 220, 180)
        IDLE_HINT_COL   = QColor(120, 150, 170, 130)

        value_changed = pyqtSignal(float)

        def __init__(
            self,
            value: float = 0.0,
            decimals: int = 3,
            unit: str = "",
            module_id: Optional[str] = None,
            parent=None,
        ):
            super().__init__(parent)
            self._value = float(value)
            self._decimals = max(0, min(6, int(decimals)))
            self._unit = str(unit or "")
            self._module_id = str(module_id or "numflow_unbound")

            # API-Compat zu anderen Frigg-Widgets (PropertiesPanel/Bridge)
            self._minimum = -1e9
            self._maximum = 1e9
            self._default = 0.0

            # Sparkline-Ringbuffer
            self._history: collections.deque[float] = collections.deque(
                [0.0] * self.HISTORY_LEN, maxlen=self.HISTORY_LEN
            )

            # Pulse-Animation (Border heller wenn Wert sich gerade ändert)
            self._pulse_charge: float = 0.0   # 0..1, decay über paint-Calls

            # Tracking ob seit Init überhaupt schon ein Wert reinkam
            # (vorher zeigen wir „—" statt eine möglicherweise irreführende 0)
            self._has_received_value: bool = False

            self.setMinimumSize(self.DEFAULT_W, self.DEFAULT_H)
            self.setSizePolicy(QSizePolicy.Policy.Preferred,
                               QSizePolicy.Policy.Preferred)
            # KEIN MouseTracking — read-only Widget

        # ─── Signal-Vertrag (für API-Konsistenz) ────────────────────

        @property
        def minimum(self) -> float:
            return self._minimum

        @property
        def maximum(self) -> float:
            return self._maximum

        def set_value(self, value: float, *, emit_signal: bool = False) -> None:
            """Pusht einen neuen Wert ins Display + History.

            Wird aus dem FluxScene-Tick mit dem Live-Wert aus
            ``audio_preview._module_values[mod_id]`` aufgerufen.
            ``emit_signal=False`` Default, weil dieses Widget ein
            **Display** ist und keine User-Edits emittiert.
            """
            try:
                fv = float(value)
            except (TypeError, ValueError):
                fv = 0.0
            # Decay des Pulse-Glows + neuer Pulse wenn sich der Wert
            # tatsächlich geändert hat (verhindert konstanten Glow bei
            # statischen Signalen).
            self._pulse_charge = max(0.0, self._pulse_charge - 0.07)
            if abs(fv - self._value) > 1e-9 or not self._has_received_value:
                self._pulse_charge = min(1.0, self._pulse_charge + 0.4)
                self._value = fv
            self._history.append(fv)
            self._has_received_value = True
            try:
                self.update()
            except RuntimeError:
                # Widget deleted (set_patch cleanup) — silent ignore
                return
            if emit_signal:
                self.value_changed.emit(self._value)

        def value(self) -> float:
            return self._value

        def reset_to_default(self) -> None:
            # Read-only: nur Visualisierung clearen
            self._history = collections.deque(
                [0.0] * self.HISTORY_LEN, maxlen=self.HISTORY_LEN
            )
            self._has_received_value = False
            self._value = 0.0
            self._pulse_charge = 0.0
            self.update()

        # ─── Painting ──────────────────────────────────────────────

        def sizeHint(self) -> QSize:
            return QSize(self.DEFAULT_W, self.DEFAULT_H)

        def paintEvent(self, event) -> None:
            p = QPainter(self)
            try:
                p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
                full_rect = self.rect().adjusted(2, 2, -2, -2)

                # Hintergrund + dynamischer Border (heller bei Pulse-Charge)
                border_col = QColor(self.BORDER_COL)
                if self._pulse_charge > 0.01:
                    # Lerp BORDER → ACTIVE_BORDER
                    t = self._pulse_charge
                    r = int(self.BORDER_COL.red()   * (1 - t) + self.ACTIVE_BORDER.red()   * t)
                    g = int(self.BORDER_COL.green() * (1 - t) + self.ACTIVE_BORDER.green() * t)
                    b = int(self.BORDER_COL.blue()  * (1 - t) + self.ACTIVE_BORDER.blue()  * t)
                    a = int(self.BORDER_COL.alpha() * (1 - t) + self.ACTIVE_BORDER.alpha() * t)
                    border_col = QColor(r, g, b, a)
                p.setBrush(QBrush(self.BG_COLOR))
                p.setPen(QPen(border_col, 1.2))
                p.drawRoundedRect(QRectF(full_rect), 5, 5)

                # Geometrie-Aufteilung: oberer ⅔ = Number, unterer ⅓ = Sparkline
                num_h = int(full_rect.height() * 0.62)
                num_rect = QRectF(
                    full_rect.left(), full_rect.top(),
                    full_rect.width(), num_h,
                )
                spark_rect = QRectF(
                    full_rect.left() + 4, full_rect.top() + num_h,
                    full_rect.width() - 8,
                    full_rect.height() - num_h - 4,
                )

                # ── Number ──
                self._draw_number(p, num_rect)

                # ── Sparkline ──
                self._draw_sparkline(p, spark_rect)
            finally:
                p.end()

        def _draw_number(self, p: QPainter, rect: QRectF) -> None:
            text = self._format_value()
            font = QFont("monospace", 13, QFont.Weight.Bold)
            p.setFont(font)
            # Glow-Schicht
            p.setPen(QPen(self.DIGIT_GLOW, 3))
            p.drawText(rect, Qt.AlignmentFlag.AlignCenter, text)
            # Echte Zahl
            p.setPen(QPen(self.DIGIT_COL, 1))
            p.drawText(rect, Qt.AlignmentFlag.AlignCenter, text)

        def _draw_sparkline(self, p: QPainter, rect: QRectF) -> None:
            if rect.width() < 4 or rect.height() < 4:
                return

            # Hintergrund-Mittellinie (zero-axis)
            grid_pen = QPen(self.SPARK_GRID_COL, 0.8, Qt.PenStyle.DotLine)
            p.setPen(grid_pen)
            mid_y = rect.top() + rect.height() / 2
            p.drawLine(QPointF(rect.left(), mid_y),
                       QPointF(rect.right(), mid_y))

            if not self._has_received_value:
                # Idle-Hint statt einer flachen Null-Linie
                p.setPen(QPen(self.IDLE_HINT_COL, 1, Qt.PenStyle.DashLine))
                p.drawLine(
                    QPointF(rect.left() + 4, mid_y),
                    QPointF(rect.right() - 4, mid_y),
                )
                return

            # Min/Max im History-Buffer ermitteln (für autoscale)
            hist = list(self._history)
            mn = min(hist)
            mx = max(hist)
            span = mx - mn
            if span < 1e-9:
                # Konstantes Signal → einzelne Linie in der Mitte zeigen
                # statt durch 0 zu teilen
                p.setPen(QPen(self.SPARK_LINE_COL, 1.5))
                p.drawLine(
                    QPointF(rect.left() + 1, mid_y),
                    QPointF(rect.right() - 1, mid_y),
                )
                return

            n = len(hist)
            x_step = rect.width() / max(1, n - 1)
            # Mapping: hist[i] → y in [rect.bottom()-1, rect.top()+1]
            margin = 1.5
            usable_h = rect.height() - 2 * margin

            def y_for(v: float) -> float:
                t = (v - mn) / span
                # invert (high values → top)
                return rect.bottom() - margin - t * usable_h

            # Filled area (subtle)
            path = QPainterPath()
            path.moveTo(rect.left(), rect.bottom())
            for i, v in enumerate(hist):
                x = rect.left() + i * x_step
                path.lineTo(x, y_for(v))
            path.lineTo(rect.right(), rect.bottom())
            path.closeSubpath()
            p.setBrush(QBrush(self.SPARK_FILL_COL))
            p.setPen(Qt.PenStyle.NoPen)
            p.drawPath(path)

            # Outline
            p.setPen(QPen(self.SPARK_LINE_COL, 1.4))
            p.setBrush(Qt.BrushStyle.NoBrush)
            line = QPainterPath()
            line.moveTo(rect.left(), y_for(hist[0]))
            for i, v in enumerate(hist[1:], start=1):
                x = rect.left() + i * x_step
                line.lineTo(x, y_for(v))
            p.drawPath(line)

            # Min/Max-Tag rechts oben/unten (klein)
            p.setFont(QFont("monospace", 7))
            p.setPen(QPen(self.UNIT_COL))
            p.drawText(
                QRectF(rect.right() - 38, rect.top() - 1, 36, 9),
                Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignTop,
                f"↑{self._compact_format(mx)}",
            )
            p.drawText(
                QRectF(rect.right() - 38, rect.bottom() - 9, 36, 9),
                Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignBottom,
                f"↓{self._compact_format(mn)}",
            )

        def _format_value(self) -> str:
            if not self._has_received_value:
                return "—"
            if self._decimals == 0:
                txt = f"{self._value:.0f}"
            else:
                txt = f"{self._value:.{self._decimals}f}"
            if self._unit:
                txt = f"{txt}{self._unit}"
            return txt

        @staticmethod
        def _compact_format(v: float) -> str:
            """Kurzform für Sparkline-Endmarker.

            Beispiele: 0.0123→".012", 1.234→"1.23", 12345→"12k",
            -123456→"-123k", 1.2e7→"12M".
            """
            av = abs(v)
            if av >= 1e6:
                return f"{v/1e6:.0f}M"
            if av >= 1e3:
                return f"{v/1e3:.0f}k"
            if av >= 10:
                return f"{v:.0f}"
            if av >= 1:
                return f"{v:.2f}"
            if av >= 0.001:
                return f"{v:.3f}"
            if av < 1e-9:
                return "0"
            return f"{v:.1e}"

else:
    NumberFlowWidget = None  # type: ignore[assignment,misc]


__all__ = ["NumberFlowWidget"]
