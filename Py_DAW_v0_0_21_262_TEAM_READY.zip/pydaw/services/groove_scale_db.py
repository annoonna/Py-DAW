"""groove_scale_db.py — SQLite-backed Groove Templates + Scale Database.

v0.0.20.890 — Phase 15 der SQLite Migration Roadmap.

Stores groove templates (swing, MPC, humanize) and musical scales in SQLite.
Old systems (groove_templates.py factory list + scales.json) remain as fallback.

Benefits:
- User-created grooves persist across sessions
- Scales queryable by category without loading full JSON
- Both searchable via standard SQL

Usage:
    from pydaw.services.groove_scale_db import GrooveScaleDB
    db = GrooveScaleDB.get()
    db.ensure_loaded()

    # Grooves
    grooves = db.get_all_grooves()
    swings = db.get_grooves_by_category("Swing")
    db.add_groove("My Funk Groove", "Custom", swing_pct=62,
                  timing=[0.0, 0.03, ...], velocity=[1.0, 0.8, ...])

    # Scales
    scales = db.get_all_scales()
    kirchentonarten = db.get_scales_by_category("Kirchentonarten")
    dorian = db.get_scale("dorian")
"""

import json
import sqlite3
import logging
from pathlib import Path
from typing import Dict, List, Optional, Any

log = logging.getLogger(__name__)


class GrooveScaleDB:
    """SQLite-backed groove template and scale database.

    Singleton. RAM-cached.
    """

    _instance: Optional["GrooveScaleDB"] = None

    @classmethod
    def get(cls) -> "GrooveScaleDB":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._db_path = Path.home() / ".config" / "ChronoScaleStudio" / "pydaw.db"
        # Grooves
        self._grooves: List[dict] = []
        self._grooves_by_cat: Dict[str, List[dict]] = {}
        self._grooves_by_id: Dict[str, dict] = {}
        # Scales
        self._scales: List[dict] = []
        self._scales_by_cat: Dict[str, List[dict]] = {}
        self._scales_by_id: Dict[str, dict] = {}
        self._loaded = False

    def ensure_loaded(self) -> None:
        """Create tables, seed factory data, load into RAM. Idempotent."""
        if self._loaded:
            return
        try:
            self._init_db()
            self._load_to_ram()
            self._loaded = True
            log.info("[GrooveScaleDB] Loaded %d grooves, %d scales",
                     len(self._grooves), len(self._scales))
        except Exception as e:
            log.warning("[GrooveScaleDB] Failed to load: %s", e)

    # ── Groove API ──────────────────────────────────────────────

    def get_all_grooves(self) -> List[dict]:
        """All groove templates."""
        self.ensure_loaded()
        return list(self._grooves)

    def get_groove(self, groove_id: str) -> Optional[dict]:
        """Get a groove by ID."""
        self.ensure_loaded()
        return self._grooves_by_id.get(groove_id)

    def get_grooves_by_category(self, category: str) -> List[dict]:
        """Get grooves by category ('Swing', 'MPC', 'Drummer', etc.)."""
        self.ensure_loaded()
        return list(self._grooves_by_cat.get(category, []))

    def get_groove_categories(self) -> List[str]:
        """Get all groove categories."""
        self.ensure_loaded()
        return sorted(self._grooves_by_cat.keys())

    def add_groove(self, name: str, category: str, swing_pct: float = 0,
                   timing: Optional[List[float]] = None,
                   velocity: Optional[List[float]] = None,
                   is_builtin: bool = False) -> bool:
        """Add or update a groove template."""
        groove_id = name.lower().replace(" ", "_").replace("%", "pct")
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.execute(
                    """INSERT OR REPLACE INTO groove_templates
                       (id, name, category, swing_pct, timing_offsets,
                        velocity_pattern, is_builtin)
                       VALUES (?,?,?,?,?,?,?)""",
                    (groove_id, name, category, swing_pct,
                     json.dumps(timing or []),
                     json.dumps(velocity or []),
                     int(is_builtin))
                )
                conn.commit()
            finally:
                conn.close()
            self._loaded = False
            self.ensure_loaded()
            return True
        except Exception as e:
            log.warning("[GrooveScaleDB] add_groove failed: %s", e)
            return False

    def delete_groove(self, groove_id: str) -> bool:
        """Delete a user groove (cannot delete built-in)."""
        self.ensure_loaded()
        g = self._grooves_by_id.get(groove_id)
        if not g or g.get("is_builtin"):
            return False
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.execute(
                    "DELETE FROM groove_templates WHERE id = ? AND is_builtin = 0",
                    (groove_id,))
                conn.commit()
            finally:
                conn.close()
            self._loaded = False
            self.ensure_loaded()
            return True
        except Exception:
            return False

    # ── Scale API ───────────────────────────────────────────────

    def get_all_scales(self) -> List[dict]:
        """All musical scales."""
        self.ensure_loaded()
        return list(self._scales)

    def get_scale(self, scale_id: str) -> Optional[dict]:
        """Get a scale by ID."""
        self.ensure_loaded()
        return self._scales_by_id.get(scale_id)

    def get_scales_by_category(self, category: str) -> List[dict]:
        """Get scales by category ('Kirchentonarten', 'Blues & Jazz', etc.)."""
        self.ensure_loaded()
        return list(self._scales_by_cat.get(category, []))

    def get_scale_categories(self) -> List[str]:
        """Get all scale categories."""
        self.ensure_loaded()
        return sorted(self._scales_by_cat.keys())

    def get_scale_intervals(self, scale_id: str) -> List[int]:
        """Get the interval list for a scale (e.g. [0,2,4,5,7,9,11] for major)."""
        self.ensure_loaded()
        s = self._scales_by_id.get(scale_id)
        if not s:
            return list(range(12))  # chromatic fallback
        try:
            return json.loads(s.get("intervals", "[]"))
        except Exception:
            return list(range(12))

    def add_scale(self, name: str, intervals: List[int],
                  category: str = "Custom", root_note: int = 0) -> bool:
        """Add a user-defined scale."""
        scale_id = name.lower().replace(" ", "_").replace("(", "").replace(")", "")
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.execute(
                    """INSERT OR REPLACE INTO scales
                       (id, name, intervals, category, root_note)
                       VALUES (?,?,?,?,?)""",
                    (scale_id, name, json.dumps(intervals), category, root_note)
                )
                conn.commit()
            finally:
                conn.close()
            self._loaded = False
            self.ensure_loaded()
            return True
        except Exception as e:
            log.warning("[GrooveScaleDB] add_scale failed: %s", e)
            return False

    # ── Internal ────────────────────────────────────────────────

    def _init_db(self) -> None:
        """Create tables + seed factory data."""
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(self._db_path))
        try:
            conn.executescript(_SCHEMA_SQL)
            g_count = conn.execute("SELECT COUNT(*) FROM groove_templates").fetchone()[0]
            s_count = conn.execute("SELECT COUNT(*) FROM scales").fetchone()[0]
            if g_count == 0:
                self._seed_factory_grooves(conn)
            if s_count == 0:
                self._seed_factory_scales(conn)
            conn.commit()
        finally:
            conn.close()

    def _load_to_ram(self) -> None:
        """Load all data into RAM caches."""
        conn = sqlite3.connect(str(self._db_path))
        conn.row_factory = sqlite3.Row
        try:
            # Grooves
            rows = conn.execute(
                "SELECT * FROM groove_templates ORDER BY category, name"
            ).fetchall()
            self._grooves.clear()
            self._grooves_by_cat.clear()
            self._grooves_by_id.clear()
            for row in rows:
                d = dict(row)
                d["is_builtin"] = bool(d.get("is_builtin", 0))
                gid = d["id"]
                cat = d.get("category", "")
                self._grooves.append(d)
                self._grooves_by_id[gid] = d
                self._grooves_by_cat.setdefault(cat, []).append(d)

            # Scales
            rows = conn.execute(
                "SELECT * FROM scales ORDER BY category, name"
            ).fetchall()
            self._scales.clear()
            self._scales_by_cat.clear()
            self._scales_by_id.clear()
            for row in rows:
                d = dict(row)
                sid = d["id"]
                cat = d.get("category", "")
                self._scales.append(d)
                self._scales_by_id[sid] = d
                self._scales_by_cat.setdefault(cat, []).append(d)
        finally:
            conn.close()

    def _seed_factory_grooves(self, conn: sqlite3.Connection) -> None:
        """Seed built-in groove templates."""
        for gid, name, cat, swing, timing, velocity in _FACTORY_GROOVES:
            try:
                conn.execute(
                    """INSERT OR IGNORE INTO groove_templates
                       (id, name, category, swing_pct, timing_offsets,
                        velocity_pattern, is_builtin)
                       VALUES (?,?,?,?,?,?,1)""",
                    (gid, name, cat, swing,
                     json.dumps(timing), json.dumps(velocity))
                )
            except Exception:
                pass

    def _seed_factory_scales(self, conn: sqlite3.Connection) -> None:
        """Seed scales from scales.json if available, else use hardcoded basics."""
        # Try loading from scales.json first
        try:
            scales_json = Path(__file__).parent.parent / "notation" / "scales" / "scales.json"
            if scales_json.exists():
                import json as _json
                data = _json.loads(scales_json.read_text(encoding="utf-8"))
                for system, scales_dict in data.items():
                    for scale_name, scale_data in scales_dict.items():
                        sid = scale_name.lower().replace(" ", "_").replace(
                            "(", "").replace(")", "").replace("ö", "oe").replace(
                            "ä", "ae").replace("ü", "ue")
                        intervals = scale_data if isinstance(scale_data, list) else []
                        try:
                            conn.execute(
                                """INSERT OR IGNORE INTO scales
                                   (id, name, intervals, category, root_note)
                                   VALUES (?,?,?,?,0)""",
                                (sid, scale_name, json.dumps(intervals), system)
                            )
                        except Exception:
                            pass
                return
        except Exception:
            pass

        # Fallback: hardcoded basic scales
        for sid, name, intervals, cat in _FACTORY_SCALES:
            try:
                conn.execute(
                    """INSERT OR IGNORE INTO scales
                       (id, name, intervals, category, root_note)
                       VALUES (?,?,?,?,0)""",
                    (sid, name, json.dumps(intervals), cat)
                )
            except Exception:
                pass


# ── Schema ──────────────────────────────────────────────────────

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS groove_templates (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    category TEXT,
    swing_pct REAL DEFAULT 0,
    timing_offsets TEXT,
    velocity_pattern TEXT,
    is_builtin INTEGER DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_groove_category ON groove_templates(category);

CREATE TABLE IF NOT EXISTS scales (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    intervals TEXT NOT NULL,
    category TEXT,
    root_note INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_scale_category ON scales(category);
"""

# ── Factory Groove Templates ───────────────────────────────────
# Format: (id, name, category, swing_pct, timing_offsets, velocity_pattern)

def _swing_timing(pct: float, steps: int = 16) -> List[float]:
    """Generate swing timing offsets."""
    shift = (pct / 100.0) * 0.25 * 0.5
    return [shift if i % 2 == 1 else 0.0 for i in range(steps)]

_FACTORY_GROOVES = [
    ("swing_straight", "Swing 50% (Straight)", "Swing", 0.0,
     [0.0] * 16, [1.0] * 16),
    ("swing_light", "Swing 55% (Light)", "Swing", 30.0,
     _swing_timing(30.0), [1.0] * 16),
    ("swing_medium", "Swing 60% (Medium)", "Swing", 55.0,
     _swing_timing(55.0), [1.0] * 16),
    ("swing_triplet", "Swing 66% (Triplet)", "Swing", 80.0,
     _swing_timing(80.0), [1.0] * 16),
    ("swing_heavy", "Swing 70% (Heavy)", "Swing", 100.0,
     _swing_timing(100.0), [1.0] * 16),
    ("mpc_55", "MPC 55%", "MPC", 55.0,
     _swing_timing(55.0), [1.0, 0.85, 0.9, 0.8] * 4),
    ("mpc_62", "MPC 62%", "MPC", 62.0,
     _swing_timing(62.0), [1.0, 0.82, 0.88, 0.78] * 4),
    ("mpc_70", "MPC 70%", "MPC", 70.0,
     _swing_timing(70.0), [1.0, 0.78, 0.85, 0.75] * 4),
    ("tr808", "TR-808", "Machine", 0.0,
     [0.0] * 16,
     [1.0, 0.7, 0.8, 0.65, 0.95, 0.7, 0.8, 0.6,
      1.0, 0.7, 0.8, 0.65, 0.95, 0.7, 0.8, 0.6]),
    ("drummer_rock", "Live Drummer (Rock)", "Drummer", 0.0,
     [0.0, 0.005, -0.003, 0.008, 0.0, 0.004, -0.002, 0.006,
      0.0, 0.003, -0.004, 0.007, 0.0, 0.005, -0.001, 0.009],
     [1.0, 0.75, 0.85, 0.7, 0.95, 0.72, 0.82, 0.68,
      1.0, 0.73, 0.83, 0.7, 0.92, 0.7, 0.8, 0.65]),
    ("drummer_jazz", "Live Drummer (Jazz)", "Drummer", 55.0,
     _swing_timing(55.0),
     [1.0, 0.6, 0.75, 0.55, 0.9, 0.58, 0.72, 0.52,
      0.95, 0.6, 0.7, 0.55, 0.88, 0.58, 0.68, 0.5]),
    ("drummer_hiphop", "Live Drummer (Hip-Hop)", "Drummer", 62.0,
     _swing_timing(62.0),
     [1.0, 0.65, 0.8, 0.6, 0.92, 0.62, 0.78, 0.58,
      0.98, 0.63, 0.76, 0.6, 0.9, 0.6, 0.75, 0.55]),
]

# ── Factory Scales (hardcoded fallback) ─────────────────────────
# Format: (id, name, intervals, category)

_FACTORY_SCALES = [
    ("chromatic", "Alle Noten", list(range(12)), "Keine Einschränkung"),
    ("major", "Ionisch (Dur)", [0, 2, 4, 5, 7, 9, 11], "Kirchentonarten"),
    ("dorian", "Dorisch", [0, 2, 3, 5, 7, 9, 10], "Kirchentonarten"),
    ("phrygian", "Phrygisch", [0, 1, 3, 5, 7, 8, 10], "Kirchentonarten"),
    ("lydian", "Lydisch", [0, 2, 4, 6, 7, 9, 11], "Kirchentonarten"),
    ("mixolydian", "Mixolydisch", [0, 2, 4, 5, 7, 9, 10], "Kirchentonarten"),
    ("aeolian", "Äolisch (Moll)", [0, 2, 3, 5, 7, 8, 10], "Kirchentonarten"),
    ("locrian", "Lokrisch", [0, 1, 3, 5, 6, 8, 10], "Kirchentonarten"),
    ("pentatonic_major", "Pentatonik Dur", [0, 2, 4, 7, 9], "Pentatonik"),
    ("pentatonic_minor", "Pentatonik Moll", [0, 3, 5, 7, 10], "Pentatonik"),
    ("blues", "Blues (Hexatonisch)", [0, 3, 5, 6, 7, 10], "Blues & Jazz"),
    ("harmonic_minor", "Harmonisch Moll", [0, 2, 3, 5, 7, 8, 11], "12-TET (Basic)"),
    ("melodic_minor", "Melodisch Moll", [0, 2, 3, 5, 7, 9, 11], "12-TET (Basic)"),
    ("whole_tone", "Ganztonleiter", [0, 2, 4, 6, 8, 10], "Exotisch"),
    ("diminished", "Vermindert (HW)", [0, 1, 3, 4, 6, 7, 9, 10], "Exotisch"),
    ("hirajoshi", "Hirajōshi", [0, 2, 3, 7, 8], "Japan"),
]
