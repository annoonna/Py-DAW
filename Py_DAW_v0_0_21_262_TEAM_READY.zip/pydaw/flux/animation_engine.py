"""
pydaw.flux.animation_engine — A-1 Zentraler Animations-Service
==============================================================

**Eingebaut in v0.0.21.197** als Voraussetzung für die FLUX-Sigil-Widgets
(PulseRing, AuroraSlider, RuneToggle, SparkBang). Spezifikation:
``PROJECT_DOCS/FLUX_GROVE_MANIFEST.md`` Sektion „FLUX Animations-Lexikon".

Kernidee
--------

Statt dass jedes Widget seine eigene QTimer/lerp/easing-Logik baut,
gibt es **einen** zentralen Service mit **benannten Curves**. Alle
Sigil-Widgets melden sich an, bekommen pro Frame einen Phase-Wert
``[0.0..1.0]`` zurück und malen daraus ihre Animation. So bleibt die
visuelle Identität des FLUX-Pantheons konsistent — kein Modul erfindet
eigene Bewegungen.

Die 14 benannten Curves (aus dem Manifest):

================  =============  =================================  =============
Name              Trigger        Beschreibung                       Default-Dauer
================  =============  =================================  =============
Pulse-Wave        Wert-Change    Welle nach außen vom Zentrum        400 ms
Aurora-Drift      Idle-Loop      Sanftes Wellen des Hintergrunds     4000 ms
Spark-Burst       Trigger-Klick  12 Funken radial auswärts            600 ms
Rune-Glow         Aktivierung    Pulsierendes Glühen (in/out)         800 ms
Mist-Drift        Idle-Loop      Nebel-Hintergrund langsam fließend  5500 ms
Yggdrasil-Pulse   Lese-Aktiv.    Wurzeln pulsieren (per-read)        200 ms
Constellation     Idle, immer    Sterne-Funken, asynchron            2500 ms
Frost-Crystal     Skadi aktiv    Kristall-Wachs-Animation            1000 ms
Tide-Ebb          Idle-Loop      Sanftes Wellen-Auf-und-Ab           4000 ms
Echo-Ring         Reverb/Delay   Konzentrische Ringe nach außen      1500 ms
Ember-Glow        Hel/Dist.      Glut-Pulsieren (warm)                500 ms
Shimmer           Wert-Display   Goldglanz-Streifen                   300 ms
Lunar-Phase       Mani-Meter     Mond-Phase folgt RMS                Echtzeit
Raven-Flap        Send-Trigger   Kurzes Flügelschlagen                250 ms
================  =============  =================================  =============

Architektur
-----------

::

    AnimationEngine (Singleton)
      ├── _global_timer (QTimer, 16 ms)   ← treibt alle Animationen
      ├── _subscribers: dict[id, _Sub]    ← {widget_id: subscription}
      ├── _reduced_motion: bool           ← User-Setting (Settings-Hook)
      ├── _frame_budget_ms: float         ← SENTINEL-aware FPS-Cap
      └── tick() → für jede Subscription:
                     phase = _curve(t_norm)
                     widget.update()  (asynchron via QTimer)

Subscriptions sind **leichtgewichtig**: ein Widget ruft
``engine.subscribe(my_id, "Pulse-Wave", duration_ms=400, on_frame=fn)``
und bekommt pro Frame ``fn(phase: float, frame: int)`` mit
``phase ∈ [0..1]``. Beim ``unsubscribe`` oder beim Phase-Ende wird
``fn`` nicht mehr aufgerufen.

Idle-Loops (Aurora-Drift, Mist-Drift, …) laufen **kontinuierlich**:
sobald ``phase`` 1.0 erreicht, springt der Wert auf 0.0 zurück. Bei
One-Shots (Pulse-Wave, Spark-Burst, …) wird die Subscription nach
einem Cycle automatisch entfernt.

Nichts-Kaputt-Garantie
----------------------

* **Reine Python-Schicht** — keine Rust-/IPC-Änderungen
* **Defensiv gegen fehlendes Qt** — wenn PyQt6 fehlt, gibt das
  Modul ``AnimationEngine = None`` und `get_animation_engine()`
  liefert eine No-Op-Stub-Instanz
* **Defensiv gegen exception in on_frame** — wirft Subscription
  raus und loggt
* **Frame-Budget** — wenn SENTINEL meldet dass die GIL eng wird,
  reduziert die Engine ihre Tick-Rate (60 → 30 → 15 fps fallback)
* **Reduced-Motion-Setting** — User kann in den Settings
  „Animationen reduzieren" aktivieren; Idle-Loops werden gestoppt,
  nur One-Shots bleiben (kürzere Dauer)
"""

from __future__ import annotations

import logging
import math
import time
from dataclasses import dataclass, field
from typing import Callable, Optional

logger = logging.getLogger(__name__)


# ─── Qt-Verfügbarkeit ─────────────────────────────────────────────

try:
    from PyQt6.QtCore import QObject, QTimer, pyqtSignal
    _QT_AVAILABLE = True
except ImportError:
    _QT_AVAILABLE = False


# ─── Easing-Funktionen ────────────────────────────────────────────


def _clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def _ease_linear(t: float) -> float:
    return _clamp(t)


def _ease_out(t: float) -> float:
    """Ease-out cubic: schnell starten, langsam enden."""
    t = _clamp(t)
    return 1.0 - (1.0 - t) ** 3


def _ease_in(t: float) -> float:
    """Ease-in cubic: langsam starten, schnell enden."""
    t = _clamp(t)
    return t ** 3


def _ease_in_out(t: float) -> float:
    """Ease-in-out cubic — sanftes Wellen, perfekt für Idle-Loops."""
    t = _clamp(t)
    if t < 0.5:
        return 4.0 * t * t * t
    p = 2.0 * t - 2.0
    return 1.0 + p * p * p / 2.0


def _ease_sine_loop(t: float) -> float:
    """Sinus-Loop: 0..1..0 (Pulse-Idle wie Aurora-Drift)."""
    t = _clamp(t)
    return 0.5 - 0.5 * math.cos(2.0 * math.pi * t)


# ─── Animations-Definitionen ──────────────────────────────────────


# Manifest-Liste der 14 benannten FLUX-Curves
ANIM_PULSE_WAVE        = "Pulse-Wave"
ANIM_AURORA_DRIFT      = "Aurora-Drift"
ANIM_SPARK_BURST       = "Spark-Burst"
ANIM_RUNE_GLOW         = "Rune-Glow"
ANIM_MIST_DRIFT        = "Mist-Drift"
ANIM_YGGDRASIL_PULSE   = "Yggdrasil-Pulse"
ANIM_CONSTELLATION     = "Constellation-Twinkle"
ANIM_FROST_CRYSTAL     = "Frost-Crystal"
ANIM_TIDE_EBB          = "Tide-Ebb"
ANIM_ECHO_RING         = "Echo-Ring"
ANIM_EMBER_GLOW        = "Ember-Glow"
ANIM_SHIMMER           = "Shimmer"
ANIM_LUNAR_PHASE       = "Lunar-Phase"
ANIM_RAVEN_FLAP        = "Raven-Flap"


@dataclass(frozen=True)
class _AnimSpec:
    """Spezifikation einer benannten Animation."""
    name: str
    default_duration_ms: int
    is_loop: bool                      # True = Idle-Loop, False = One-Shot
    easing: Callable[[float], float]   # Phase-Kurve
    description: str


_ANIM_REGISTRY: dict[str, _AnimSpec] = {
    ANIM_PULSE_WAVE: _AnimSpec(
        ANIM_PULSE_WAVE, 400, False, _ease_out,
        "Welle nach außen vom Zentrum",
    ),
    ANIM_AURORA_DRIFT: _AnimSpec(
        ANIM_AURORA_DRIFT, 4000, True, _ease_sine_loop,
        "Sanftes Wellen des Hintergrunds",
    ),
    ANIM_SPARK_BURST: _AnimSpec(
        ANIM_SPARK_BURST, 600, False, _ease_out,
        "12 Funken radial auswärts",
    ),
    ANIM_RUNE_GLOW: _AnimSpec(
        ANIM_RUNE_GLOW, 800, True, _ease_sine_loop,
        "Pulsierendes Glühen (in/out)",
    ),
    ANIM_MIST_DRIFT: _AnimSpec(
        ANIM_MIST_DRIFT, 5500, True, _ease_sine_loop,
        "Nebel-Hintergrund langsam fließend",
    ),
    ANIM_YGGDRASIL_PULSE: _AnimSpec(
        ANIM_YGGDRASIL_PULSE, 200, False, _ease_out,
        "Wurzeln pulsieren synchron mit Read",
    ),
    ANIM_CONSTELLATION: _AnimSpec(
        ANIM_CONSTELLATION, 2500, True, _ease_sine_loop,
        "Subtile Sterne-Funken, asynchron",
    ),
    ANIM_FROST_CRYSTAL: _AnimSpec(
        ANIM_FROST_CRYSTAL, 1000, False, _ease_out,
        "Kristall-Wachs-Animation",
    ),
    ANIM_TIDE_EBB: _AnimSpec(
        ANIM_TIDE_EBB, 4000, True, _ease_sine_loop,
        "Sanftes Wellen-Auf-und-Ab",
    ),
    ANIM_ECHO_RING: _AnimSpec(
        ANIM_ECHO_RING, 1500, False, _ease_out,
        "Konzentrische Ringe nach außen",
    ),
    ANIM_EMBER_GLOW: _AnimSpec(
        ANIM_EMBER_GLOW, 500, True, _ease_sine_loop,
        "Glut-Pulsieren (warm)",
    ),
    ANIM_SHIMMER: _AnimSpec(
        ANIM_SHIMMER, 300, False, _ease_in_out,
        "Goldglanz-Streifen über Display",
    ),
    ANIM_LUNAR_PHASE: _AnimSpec(
        ANIM_LUNAR_PHASE, 0, True, _ease_linear,    # Echtzeit (extern getrieben)
        "Mond-Phase folgt RMS-Pegel",
    ),
    ANIM_RAVEN_FLAP: _AnimSpec(
        ANIM_RAVEN_FLAP, 250, False, _ease_out,
        "Kurzes Flügelschlagen",
    ),
}


def list_animations() -> list[tuple[str, int, bool, str]]:
    """Diagnose-Helper: alle registrierten Curves listen.

    Returns: [(name, default_ms, is_loop, description), …]
    """
    return [
        (s.name, s.default_duration_ms, s.is_loop, s.description)
        for s in _ANIM_REGISTRY.values()
    ]


def is_animation_known(name: str) -> bool:
    """Diagnose: ist eine Animation registriert?"""
    return name in _ANIM_REGISTRY


# ─── Subscription ─────────────────────────────────────────────────


@dataclass
class _Sub:
    """Eine aktive Animations-Subscription."""
    sub_id: str
    spec: _AnimSpec
    duration_ms: int
    start_ms: float
    on_frame: Callable[[float, int], None]
    frame: int = 0
    # Phase-Offset für Constellation-asynchron (jeder Stern ein anderer
    # Startwert), per-subscriber gesetzt. 0..1.
    phase_offset: float = 0.0


# ─── Hauptklasse ──────────────────────────────────────────────────


# Einheitlicher Tick — 16 ms ≈ 60 fps. Bei Throttling wird das
# Intervall auf 33 (30 fps) oder 66 (15 fps) erhöht.
TICK_INTERVAL_60FPS = 16
TICK_INTERVAL_30FPS = 33
TICK_INTERVAL_15FPS = 66


if _QT_AVAILABLE:

    class AnimationEngine(QObject):  # type: ignore[misc]
        """Singleton-Service für alle FLUX-Sigil-Animationen.

        Lebt unter ``pydaw.flux.animation_engine.get_animation_engine()``.
        Wird vom `flux_main_widget` einmalig instanziiert; alle Sigil-
        Widgets `subscribe()`-en in ihrem ``__init__``.

        Performance-Verhalten
        ---------------------

        * Tick-Loop läuft **nur** wenn mindestens 1 aktive Subscription
          existiert. Bei 0 Subscriptions stoppt der Timer (kein Idle-CPU).
        * Frame-Budget per `set_fps_target(fps)`-Hook für SENTINEL: bei
          GIL-Druck reduziert SENTINEL die Ziel-FPS, der Timer adaptiert.
        * `set_reduced_motion(True)` stoppt sofort alle Idle-Loops und
          kürzt Restdauer aller One-Shots auf <= 150 ms.
        """

        # Diagnose-Signale (z.B. für SENTINEL-Panel)
        fps_changed       = pyqtSignal(int)
        subscriber_count  = pyqtSignal(int)

        def __init__(self, parent=None):
            super().__init__(parent)
            self._subscribers: dict[str, _Sub] = {}
            self._timer = QTimer(self)
            self._timer.setInterval(TICK_INTERVAL_60FPS)
            self._timer.timeout.connect(self._tick)
            self._reduced_motion = False
            self._fps_target = 60
            # Diagnose: Anzahl Frames seit Start, Zeitstempel des
            # letzten Ticks (für Frame-Budget-Messung).
            self._total_frames = 0
            self._last_tick_ms = 0.0

        # ─── Subscription-API ──────────────────────────────────────

        def subscribe(
            self,
            sub_id: str,
            anim_name: str,
            on_frame: Callable[[float, int], None],
            *,
            duration_ms: Optional[int] = None,
            phase_offset: float = 0.0,
        ) -> bool:
            """Subscribe ein Widget für eine benannte Animation.

            Parameters
            ----------
            sub_id
                Eindeutige Subscription-ID. Per Konvention:
                ``f"{module_id}::{anim_name}"`` damit ein Widget pro
                Animation max. eine Subscription hat. Existiert die
                ID schon, wird sie durch die neue ersetzt (nützlich
                fürs Re-Triggern eines Pulse-Wave).
            anim_name
                Einer der registrierten Namen (siehe ANIM_*).
            on_frame
                Callable(phase, frame) — wird bei jedem Tick aufgerufen.
                ``phase`` ist die ge-easete Position ``[0..1]``;
                ``frame`` ist der Counter seit Start (kann für
                Particle-Animationen nützlich sein).
            duration_ms
                Optional. Wenn ``None``, wird ``spec.default_duration_ms``
                verwendet. Für Loops ist das die Loop-Periode, für
                One-Shots die Gesamtdauer.
            phase_offset
                Initialer Phase-Offset ``[0..1]``. Genutzt für
                Constellation-Twinkle (jeder Stern ein anderer Start).

            Returns
            -------
            ``True`` wenn registriert, ``False`` bei unbekannter
            Animation. Wirft KEINE Exception — Widgets dürfen jederzeit
            subscriben.
            """
            spec = _ANIM_REGISTRY.get(anim_name)
            if spec is None:
                logger.warning("[FLUX-ANIM] unknown animation: %r", anim_name)
                return False

            # Reduced-Motion: Idle-Loops blockieren, One-Shots auf
            # max 150 ms zusammenstauchen
            effective_duration = (
                duration_ms if duration_ms is not None
                else spec.default_duration_ms
            )
            if self._reduced_motion:
                if spec.is_loop:
                    logger.debug(
                        "[FLUX-ANIM] reduced-motion blocks idle-loop %s",
                        anim_name,
                    )
                    return False
                effective_duration = min(effective_duration, 150)

            sub = _Sub(
                sub_id=sub_id,
                spec=spec,
                duration_ms=max(1, int(effective_duration)),
                start_ms=time.monotonic() * 1000.0,
                on_frame=on_frame,
                phase_offset=_clamp(phase_offset),
            )
            self._subscribers[sub_id] = sub
            self.subscriber_count.emit(len(self._subscribers))
            if not self._timer.isActive():
                self._timer.start()
            return True

        def unsubscribe(self, sub_id: str) -> bool:
            """Subscription entfernen. Idempotent."""
            existed = self._subscribers.pop(sub_id, None) is not None
            if existed:
                self.subscriber_count.emit(len(self._subscribers))
            if not self._subscribers and self._timer.isActive():
                self._timer.stop()
            return existed

        def unsubscribe_prefix(self, prefix: str) -> int:
            """Alle Subscriptions mit ID-Prefix entfernen.

            Bequem fürs Widget-Aufräumen: ein Widget unsubscribed
            mit seiner Module-ID als Prefix alle eigenen Animationen.
            Gibt die Anzahl entfernter Subscriptions zurück.
            """
            to_remove = [k for k in self._subscribers if k.startswith(prefix)]
            for k in to_remove:
                self._subscribers.pop(k, None)
            if to_remove:
                self.subscriber_count.emit(len(self._subscribers))
            if not self._subscribers and self._timer.isActive():
                self._timer.stop()
            return len(to_remove)

        def re_trigger(self, sub_id: str) -> bool:
            """Subscription zurücksetzen (wieder bei Phase 0 starten).

            Praktisch für One-Shots wie Pulse-Wave oder Spark-Burst,
            die bei jedem User-Click neu beginnen sollen.
            """
            sub = self._subscribers.get(sub_id)
            if sub is None:
                return False
            sub.start_ms = time.monotonic() * 1000.0
            sub.frame = 0
            return True

        # ─── Settings-API ──────────────────────────────────────────

        @property
        def reduced_motion(self) -> bool:
            return self._reduced_motion

        def set_reduced_motion(self, enabled: bool) -> None:
            """User-Setting: Animationen reduzieren.

            Wirkung:
            * Alle Idle-Loops werden sofort entfernt
            * One-Shots bleiben aktiv aber werden auf max 150 ms gekürzt
            * Neue Idle-Subscriptions werden abgelehnt
            """
            new_val = bool(enabled)
            if new_val == self._reduced_motion:
                return
            self._reduced_motion = new_val
            if new_val:
                # Alle Idle-Loops kappen
                to_remove = [
                    k for k, s in self._subscribers.items()
                    if s.spec.is_loop
                ]
                for k in to_remove:
                    self._subscribers.pop(k, None)
                self.subscriber_count.emit(len(self._subscribers))
                if not self._subscribers and self._timer.isActive():
                    self._timer.stop()
            logger.info("[FLUX-ANIM] reduced_motion=%s", new_val)

        def set_fps_target(self, fps: int) -> None:
            """SENTINEL-Hook: Ziel-FPS setzen. Erlaubt: 60, 30, 15.

            SENTINEL ruft das auf wenn Audio-Thread-GIL-Druck > Schwelle
            steigt. Animation wird ruckeliger aber Audio bleibt stabil.
            """
            fps_clamped = 60 if fps >= 50 else (30 if fps >= 25 else 15)
            if fps_clamped == self._fps_target:
                return
            self._fps_target = fps_clamped
            interval = {
                60: TICK_INTERVAL_60FPS,
                30: TICK_INTERVAL_30FPS,
                15: TICK_INTERVAL_15FPS,
            }[fps_clamped]
            self._timer.setInterval(interval)
            self.fps_changed.emit(fps_clamped)
            logger.info("[FLUX-ANIM] fps_target=%d (interval=%dms)",
                        fps_clamped, interval)

        # ─── Diagnose ──────────────────────────────────────────────

        def stats(self) -> dict:
            """Aktuelle Engine-Stats — für Frigg.PerfMonitor / SENTINEL."""
            return {
                "subscribers": len(self._subscribers),
                "fps_target": self._fps_target,
                "reduced_motion": self._reduced_motion,
                "total_frames": self._total_frames,
                "active_animations": sorted({
                    s.spec.name for s in self._subscribers.values()
                }),
            }

        # ─── Tick-Loop ─────────────────────────────────────────────

        def _tick(self) -> None:
            """Ein Animations-Frame.

            Iteriert defensiv: wenn ein on_frame() wirft, wird die
            Subscription rausgeworfen aber der Tick läuft weiter.

            v0.0.21.198 Hotfix: ``RuntimeError`` (Qt's "wrapped C/C++
            object has been deleted") wird **silent gedroppt** — kein
            Warning. Das passiert bei jedem ``scene.set_patch()`` /
            Track-Switch wenn alte Sigil-Widgets durch QGraphicsProxy-
            Widget-Cleanup gelöscht werden ohne dass ihr ``closeEvent``
            zuverlässig getriggert wird. Wir fangen es hier zentral.
            """
            now_ms = time.monotonic() * 1000.0
            self._total_frames += 1
            self._last_tick_ms = now_ms

            # Snapshot machen — Subscriptions können sich während des
            # Ticks selbst entfernen (z.B. wenn ein on_frame eine
            # andere subscribe macht)
            ended: list[str] = []
            for sub_id, sub in list(self._subscribers.items()):
                elapsed = now_ms - sub.start_ms
                t_norm = (elapsed / sub.duration_ms) + sub.phase_offset

                if sub.spec.is_loop:
                    # Loop: t_norm modulo 1.0
                    t_norm = t_norm - math.floor(t_norm)
                    phase = sub.spec.easing(t_norm)
                    try:
                        sub.on_frame(phase, sub.frame)
                    except RuntimeError as e:
                        # Qt-deleted-object: silent drop
                        logger.debug(
                            "[FLUX-ANIM] silent drop loop %s (Qt deleted): %s",
                            sub_id, e,
                        )
                        ended.append(sub_id)
                    except Exception as e:
                        logger.warning(
                            "[FLUX-ANIM] on_frame raised in loop %s/%s: %s",
                            sub_id, sub.spec.name, e,
                        )
                        ended.append(sub_id)
                else:
                    # One-Shot: bei t >= 1.0 ein letztes Frame mit
                    # phase=1.0 senden, dann beenden
                    if t_norm >= 1.0:
                        try:
                            sub.on_frame(1.0, sub.frame)
                        except RuntimeError:
                            pass  # silent — Widget ist eh weg
                        except Exception as e:
                            logger.warning(
                                "[FLUX-ANIM] on_frame raised in oneshot final %s/%s: %s",
                                sub_id, sub.spec.name, e,
                            )
                        ended.append(sub_id)
                    else:
                        phase = sub.spec.easing(_clamp(t_norm))
                        try:
                            sub.on_frame(phase, sub.frame)
                        except RuntimeError as e:
                            # Qt-deleted-object: silent drop
                            logger.debug(
                                "[FLUX-ANIM] silent drop oneshot %s (Qt deleted): %s",
                                sub_id, e,
                            )
                            ended.append(sub_id)
                        except Exception as e:
                            logger.warning(
                                "[FLUX-ANIM] on_frame raised in oneshot %s/%s: %s",
                                sub_id, sub.spec.name, e,
                            )
                            ended.append(sub_id)

                sub.frame += 1

            # Aufräumen
            for sub_id in ended:
                self._subscribers.pop(sub_id, None)
            if ended:
                self.subscriber_count.emit(len(self._subscribers))
            if not self._subscribers and self._timer.isActive():
                self._timer.stop()

else:
    # Qt fehlt — wir bieten ein None-Symbol an, damit Import nicht scheitert.
    AnimationEngine = None  # type: ignore[assignment,misc]


# ─── No-Op-Stub fürs Headless-Testing ─────────────────────────────


class _NoOpAnimationEngine:
    """Stub für Umgebungen ohne Qt — alle Methoden sind No-Ops.

    Damit Sigil-Widgets defensiv ``get_animation_engine().subscribe(...)``
    aufrufen können, ohne in Headless-Tests zu crashen.
    """

    @property
    def reduced_motion(self) -> bool:
        return False

    def subscribe(self, *args, **kwargs) -> bool:
        return False

    def unsubscribe(self, *args, **kwargs) -> bool:
        return False

    def unsubscribe_prefix(self, *args, **kwargs) -> int:
        return 0

    def re_trigger(self, *args, **kwargs) -> bool:
        return False

    def set_reduced_motion(self, *args, **kwargs) -> None:
        return None

    def set_fps_target(self, *args, **kwargs) -> None:
        return None

    def stats(self) -> dict:
        return {"subscribers": 0, "stub": True}


# ─── Singleton-Accessor ───────────────────────────────────────────


_ENGINE_INSTANCE = None  # type: ignore[assignment]


def get_animation_engine():
    """Singleton-Accessor.

    Liefert eine ``AnimationEngine``-Instanz (Qt verfügbar) oder eine
    No-Op-Stub-Instanz (Qt fehlt). Das Aufruf-Verhalten ist identisch:
    Subscribes geben einfach ``False`` zurück und niemand crasht.
    """
    global _ENGINE_INSTANCE
    if _ENGINE_INSTANCE is None:
        if _QT_AVAILABLE and AnimationEngine is not None:
            _ENGINE_INSTANCE = AnimationEngine()
            logger.debug("[FLUX-ANIM] AnimationEngine initialized (Qt)")
        else:
            _ENGINE_INSTANCE = _NoOpAnimationEngine()
            logger.debug("[FLUX-ANIM] AnimationEngine no-op stub (no Qt)")
    return _ENGINE_INSTANCE


__all__ = [
    "AnimationEngine",
    "get_animation_engine",
    "list_animations",
    "is_animation_known",
    # Animation-Namen-Konstanten
    "ANIM_PULSE_WAVE", "ANIM_AURORA_DRIFT", "ANIM_SPARK_BURST",
    "ANIM_RUNE_GLOW", "ANIM_MIST_DRIFT", "ANIM_YGGDRASIL_PULSE",
    "ANIM_CONSTELLATION", "ANIM_FROST_CRYSTAL", "ANIM_TIDE_EBB",
    "ANIM_ECHO_RING", "ANIM_EMBER_GLOW", "ANIM_SHIMMER",
    "ANIM_LUNAR_PHASE", "ANIM_RAVEN_FLAP",
]
