"""
pydaw.flux.saga — Saga (Sigil-Sight) Visualisierungs-Subsystem
==============================================================

**v0.0.21.202 — S-0: Saga-Stack-Bootstrap**

Saga ist die 13. Pantheon-Familie in FLUX (siehe ``yggdrasil.py::GODS``).
Sie ist KEINE Klang-Quelle und KEIN FX — sie ist ein **System-Display**:
sie *sieht* das, was im Audio-Graphen passiert, und stellt es im Modul-
Body als Stippling-Punkt-Wolke dar.

S-0 liefert das **Saga.Magic**-Modul standalone:

  - 24 parametrische Formen (Heart, Pentagram, Norse-Sigils,
    Lissajous, Lotus, Spiral, …)
  - Pure-Python-Sampler (rust-frei)
  - Optionaler Rust-IPC-Bridge (graceful degradation)
  - Cleanup-Pakt-konform (alle Subscriptions sauber freigegeben)
  - Audio Pass-Through (Saga.Magic verändert das Audio nicht)

S-1+ erweitert auf alle anderen Pantheon-Familien (Bragi → Waveform,
Forseti → Filter-Bode, Iduna → Delay-Tap-Pattern, etc.).

Design-Prinzip: **Hybrid-Standard** — Heavy-Lifting in Rust, dünne
Python-Proxy-Schicht. In S-0 ist das Heavy-Lifting noch in Python
gehalten (für Bootstrap-Geschwindigkeit), aber die API ist so
geschnitten, dass eine spätere Rust-Migration den Python-Code nicht
ändern muss.
"""
from __future__ import annotations

# Re-Exports für bequeme Importe
from pydaw.flux.saga.shape_sampler import (
    SagaShapeSampler,
    sample_shape_to_points,
)

__all__ = [
    "SagaShapeSampler",
    "sample_shape_to_points",
]
