"""sentinel_crash_analyzer.py — Crash Analyzer (Phase S5).

v0.0.20.904 — Phase S5 der SENTINEL_ROADMAP.

Automatische Crash-Report Generierung bei Exception/Segfault.
Sammelt Blackbox-Daten vom Flight Recorder + System-State.
Installiert sys.excepthook + signal.signal Handler.
"""

from __future__ import annotations

import json
import logging
import signal
import sys
import time
import traceback as tb_module
from typing import Any, Dict, Optional

log = logging.getLogger(__name__)


class SentinelCrashAnalyzer:
    """Crash analyzer — catches exceptions and generates reports.

    Installs sys.excepthook to catch unhandled exceptions.
    On crash: dumps Flight Recorder blackbox into sentinel_crashes.
    """

    _instance: Optional["SentinelCrashAnalyzer"] = None
    _original_excepthook = None

    @classmethod
    def get(cls) -> "SentinelCrashAnalyzer":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._db = None
        self._recorder = None
        self._installed = False
        self._session_id = ""
        self._crash_count = 0

    def install(self, recorder=None, session_id: str = "") -> None:
        """Install crash handlers (excepthook + signal handlers)."""
        self._recorder = recorder
        self._session_id = session_id

        try:
            from pydaw.services.sentinel_db import SentinelDB
            self._db = SentinelDB.get()
            self._db.ensure_loaded()
        except Exception:
            pass

        if not self._installed:
            SentinelCrashAnalyzer._original_excepthook = sys.excepthook
            sys.excepthook = self._excepthook
            self._installed = True

            # Signal handlers for segfault (Linux)
            try:
                signal.signal(signal.SIGSEGV, self._signal_handler)
                signal.signal(signal.SIGABRT, self._signal_handler)
            except Exception:
                pass

            log.info("[SENTINEL] Crash Analyzer installed (excepthook + signals)")

    def uninstall(self) -> None:
        if self._installed and SentinelCrashAnalyzer._original_excepthook:
            sys.excepthook = SentinelCrashAnalyzer._original_excepthook
            self._installed = False

    def _excepthook(self, exc_type, exc_value, exc_tb) -> None:
        """Custom excepthook — generates crash report before default handler."""
        try:
            tb_str = "".join(tb_module.format_exception(exc_type, exc_value, exc_tb))
            self._generate_report(
                crash_type="exception",
                component=self._classify_component(tb_str),
                error_message=str(exc_value),
                traceback_str=tb_str,
            )
        except Exception:
            pass  # Never crash inside the crash handler

        # Call original hook
        if SentinelCrashAnalyzer._original_excepthook:
            SentinelCrashAnalyzer._original_excepthook(exc_type, exc_value, exc_tb)

    def _signal_handler(self, signum, frame) -> None:
        """Handle SIGSEGV/SIGABRT — last-resort crash report."""
        sig_name = {
            signal.SIGSEGV: "segfault",
            signal.SIGABRT: "abort",
        }.get(signum, f"signal_{signum}")

        try:
            frame_info = ""
            if frame:
                frame_info = f"{frame.f_code.co_filename}:{frame.f_lineno} in {frame.f_code.co_name}"

            self._generate_report(
                crash_type=sig_name,
                component="native",
                error_message=f"Signal {signum} ({sig_name}) at {frame_info}",
                traceback_str=frame_info,
            )
        except Exception:
            pass

        # Re-raise with default handler
        signal.signal(signum, signal.SIG_DFL)

    def _generate_report(self, crash_type: str, component: str = "",
                           error_message: str = "",
                           traceback_str: str = "") -> int:
        """Generate and store a crash report with blackbox data."""
        self._crash_count += 1

        # Get blackbox from Flight Recorder
        blackbox = {}
        if self._recorder:
            try:
                blackbox = self._recorder.get_blackbox()
            except Exception:
                pass

        system_state = blackbox.get("system_state", {})
        track_state = blackbox.get("track_state", {})

        crash_id = 0
        if self._db:
            crash_id = self._db.log_crash(
                crash_type=crash_type,
                component=component,
                error_message=error_message[:2000],
                traceback_str=traceback_str[:5000],
                blackbox=blackbox,
                system_state=system_state,
                track_state=track_state,
                session_id=self._session_id,
            )

        log.error("[SENTINEL] Crash #%d: %s in %s — %s (report ID: %d)",
                  self._crash_count, crash_type, component,
                  error_message[:200], crash_id)

        # v0.0.20.905: Auto-learn pattern from crash (S8)
        if crash_id:
            try:
                from pydaw.services.sentinel_patterns import SentinelPatternLearner
                learner = SentinelPatternLearner.get()
                if learner._running:
                    learner.analyze_crash(crash_id)
            except Exception:
                pass  # Pattern learning is optional

        return crash_id

    def report_exception(self, exc: Exception, component: str = "") -> int:
        """Manually report a caught exception (non-fatal)."""
        tb_str = tb_module.format_exc()
        return self._generate_report(
            crash_type="caught_exception",
            component=component,
            error_message=str(exc),
            traceback_str=tb_str,
        )

    def report_plugin_crash(self, plugin_id: str, track_id: str = "",
                              error: str = "") -> int:
        """Report a plugin crash (sandbox worker died)."""
        return self._generate_report(
            crash_type="plugin_crash",
            component=f"plugin:{plugin_id}",
            error_message=error or f"Plugin {plugin_id} crashed",
        )

    def _classify_component(self, traceback_str: str) -> str:
        """Classify crash component from traceback."""
        tb_lower = traceback_str.lower()
        if "collab" in tb_lower:
            return "collab"
        if "device_panel" in tb_lower or "plugin" in tb_lower:
            return "plugin"
        if "audio_engine" in tb_lower or "engine" in tb_lower:
            return "engine"
        if "mixer" in tb_lower:
            return "mixer"
        if "arranger" in tb_lower or "pianoroll" in tb_lower:
            return "editor"
        if "main_window" in tb_lower:
            return "ui"
        return "unknown"

    @property
    def crash_count(self) -> int:
        return self._crash_count

    def get_last_crash(self) -> Optional[dict]:
        """Get the most recent crash report."""
        if not self._db:
            return None
        crashes = self._db.get_crashes(limit=1)
        return crashes[0] if crashes else None
