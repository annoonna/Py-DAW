"""
pydaw.services.saga_shapes_db — S-0 SQLite-Backend für Saga-Shapes
==================================================================

**Eingebaut in v0.0.21.202** (Phase S-0 nach FLUX_SAGA_MANIFEST §2.2).

Hält die 24 Factory-Shapes in einer eigenen SQLite-DB
``~/.config/ChronoScaleStudio/saga_shapes.db``. Die DB enthält:

* ``saga_shape``         — die 24 Factory-Formen + spätere User-Shapes
* ``saga_palette``       — Color-Schemes (Norse-Cyan etc.)
* ``saga_renderer_map``  — Modul-Kind → Renderer-Typ (für S-1+)
* ``saga_user_shape``    — User-Custom-Shapes (V-4+, leer in S-0)
* ``meta``               — Schema-Version

S-0 Architektur-Notiz
---------------------

Im Manifest §2.4 sind Formen als SAGA-VM-Bytecode in `parametric_fn BLOB`
geplant. **In S-0 speichern wir den Form-Namen** (TEXT) als Verweis auf
die Python-Implementierung in ``saga_factory_shapes.py``. Damit ist die
DB-Schema-Form **bytecode-ready** (Spalte heißt weiterhin ``parametric_fn``,
ist aber TEXT statt BLOB). In Folge-Phasen (z.B. S-2) kann der Bytecode-
Pfad addiert werden, ohne das Schema zu brechen — entweder durch eine
neue Spalte oder durch BLOB-Marshalling der Bytecode-Sequenz.

Singleton-Pattern wie ``flux_vault_db.py`` und ``preset_database.py``.
``ensure_loaded()`` ist idempotent und Re-Seed-fähig (Author-Marker-
Check à la Sacred-v2).

Nichts-Kaputt-Garantie
----------------------

* **Reine Python-Schicht** — keine Rust-Änderungen
* **Defensiv gegen fehlendes SQLite** (stdlib)
* **Idempotente Initialisierung** — ``ensure_loaded()`` mehrfach aufrufbar
* **Schema-Migration safe** — ``CREATE TABLE IF NOT EXISTS``
* **User-Shapes (``is_factory=0``) bleiben unangetastet** beim Re-Seed
* **Eigene DB-Datei** — keine Kollision mit ``flux_vault.db`` oder
  ``preset_database.db``
"""
from __future__ import annotations

import logging
import os
import sqlite3
import threading
from pathlib import Path
from typing import Optional

from pydaw.services.saga_factory_shapes import (
    SAGA_FACTORY_AUTHOR,
    SAGA_FACTORY_SHAPES_VERSION,
    SHAPE_DEFINITIONS,
)


logger = logging.getLogger(__name__)


# DB-Schema-Version. Bei Schema-Änderungen incrementieren und
# Migration-Routine ergänzen.
SAGA_SCHEMA_VERSION = "1"


# ─── Default-Pfade ────────────────────────────────────────────────


def _default_db_path() -> Path:
    """``~/.config/ChronoScaleStudio/saga_shapes.db``.

    XDG-konform unter Linux. Bei nicht-Unix Systemen: ~/AppData oder
    Fallback auf $HOME.
    """
    if os.name == "posix":
        cfg_root = os.environ.get("XDG_CONFIG_HOME") or str(Path.home() / ".config")
    else:
        # Win/Mac
        cfg_root = str(Path.home() / ".config")
    return Path(cfg_root) / "ChronoScaleStudio" / "saga_shapes.db"


# ─── Singleton ────────────────────────────────────────────────────


class SagaShapesDB:
    """Singleton-DB für die 24 Saga-Factory-Shapes + User-Shapes.

    Threadsafe via internem Lock; alle DB-Zugriffe gehen durch denselben
    Lock. Read-Only-Zugriffe auf die in-Memory-Cache (`_shape_cache`)
    sind lock-free.
    """

    _instance_lock = threading.Lock()
    _instance: Optional["SagaShapesDB"] = None

    @classmethod
    def instance(cls, db_path: Optional[Path] = None) -> "SagaShapesDB":
        """Liefert das Singleton. Beim ersten Aufruf wird die DB
        initialisiert und die 24 Factory-Shapes ge-seeded."""
        with cls._instance_lock:
            if cls._instance is None:
                cls._instance = cls(db_path or _default_db_path())
                cls._instance.ensure_loaded()
            return cls._instance

    def __init__(self, db_path: Path) -> None:
        self.db_path = Path(db_path)
        self._lock = threading.RLock()
        self._loaded = False
        # Cache: shape_id → (name, category, parametric_fn_marker)
        self._shape_cache: dict[int, tuple[str, str, str]] = {}

    # ─── Lifecycle ────────────────────────────────────────────────

    def ensure_loaded(self) -> None:
        """Erzeugt die DB falls nötig, seedet die 24 Factory-Shapes,
        und füllt den In-Memory-Cache.

        Idempotent. Re-Seed-Logik per Author-Marker-Check:
        - wenn 24 Shapes mit AKTUELLEM Marker existieren → kein Re-Seed
        - wenn fewer / older marker → alle Factory-Shapes löschen und
          neu seeden (User-Shapes in `saga_user_shape` bleiben).
        """
        with self._lock:
            if self._loaded:
                return
            self.db_path.parent.mkdir(parents=True, exist_ok=True)
            with sqlite3.connect(str(self.db_path)) as conn:
                self._create_schema(conn)
                self._seed_factory_shapes_if_empty(conn)
                self._refresh_cache(conn)
                conn.commit()
            self._loaded = True
            logger.info(
                "[SagaShapesDB] Ready (path=%s, %d factory shapes)",
                self.db_path, len(self._shape_cache),
            )

    # ─── Schema ───────────────────────────────────────────────────

    def _create_schema(self, conn: sqlite3.Connection) -> None:
        """Erzeugt alle Tabellen, idempotent. Setzt Schema-Version.

        Die Schema-Form folgt FLUX_SAGA_MANIFEST §2.2 mit der einen
        Abweichung: ``parametric_fn`` ist TEXT (Form-Name als Verweis
        auf ``saga_factory_shapes.py``-Implementierung) statt BLOB
        (SAGA-VM-Bytecode). S-2+ kann auf BLOB upgraden.
        """
        c = conn.cursor()

        # Meta-Tabelle (Schema-Version, Build-Author etc.)
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS meta (
                key   TEXT PRIMARY KEY,
                value TEXT NOT NULL
            )
            """
        )

        # Form-Definition (Factory + zukünftige User-Shapes hier nicht;
        # User-Shapes leben in saga_user_shape weil S-0 sie nicht baut).
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS saga_shape (
                id              INTEGER PRIMARY KEY,
                name            TEXT NOT NULL,
                category        TEXT NOT NULL,
                is_factory      INTEGER NOT NULL DEFAULT 1,
                parametric_fn   TEXT NOT NULL,
                default_density REAL NOT NULL DEFAULT 0.7,
                default_speed   REAL NOT NULL DEFAULT 0.5,
                point_count     INTEGER NOT NULL DEFAULT 256,
                description     TEXT NOT NULL DEFAULT '',
                icon_svg        TEXT,
                author          TEXT NOT NULL DEFAULT '',
                version         TEXT NOT NULL DEFAULT 'v1'
            )
            """
        )
        c.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_saga_shape_category
            ON saga_shape (category)
            """
        )
        c.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_saga_shape_factory
            ON saga_shape (is_factory)
            """
        )

        # Color-Palette für eine Form. In S-0 noch leer; S-1+ befüllt.
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS saga_palette (
                id              INTEGER PRIMARY KEY,
                name            TEXT NOT NULL UNIQUE,
                hue_base        INTEGER NOT NULL,
                hue_modulation  REAL NOT NULL DEFAULT 0.0,
                alpha_min       INTEGER NOT NULL DEFAULT 60,
                alpha_max       INTEGER NOT NULL DEFAULT 220
            )
            """
        )

        # Renderer-Map: Modul-Kind → Renderer-Typ. In S-0 nur Saga.Magic.
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS saga_renderer_map (
                module_kind     TEXT PRIMARY KEY,
                renderer_type   TEXT NOT NULL,
                enabled         INTEGER NOT NULL DEFAULT 1,
                body_min_height INTEGER NOT NULL DEFAULT 60
            )
            """
        )

        # User-Shapes (V-4+ Phase, leer in S-0).
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS saga_user_shape (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                name            TEXT NOT NULL,
                category        TEXT NOT NULL,
                parametric_fn   TEXT NOT NULL,
                created_at      TEXT NOT NULL,
                icon_svg        TEXT
            )
            """
        )

        # Schema-Version-Stempel
        c.execute(
            "INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
            ("schema_version", SAGA_SCHEMA_VERSION),
        )
        c.execute(
            "INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
            ("factory_author", SAGA_FACTORY_AUTHOR),
        )
        c.execute(
            "INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
            ("factory_version", SAGA_FACTORY_SHAPES_VERSION),
        )

    # ─── Seed-Logik ───────────────────────────────────────────────

    def _seed_factory_shapes_if_empty(self, conn: sqlite3.Connection) -> None:
        """Seeded die 24 Factory-Shapes, falls die DB leer (keine
        passenden Author-Marker-Einträge) ist.

        Re-Seed-Verhalten (analog Sacred-v2):
        - wenn 24 Shapes mit aktuellem ``author`` und ``is_factory=1``
          existieren → kein Re-Seed
        - sonst: alle ``is_factory=1``-Einträge löschen und neu schreiben
        - User-Shapes (``saga_user_shape``) bleiben unberührt
        """
        c = conn.cursor()

        # Sind alle 24 mit aktueller Version da?
        c.execute(
            "SELECT COUNT(*) FROM saga_shape WHERE is_factory=1 AND author=?",
            (SAGA_FACTORY_AUTHOR,),
        )
        existing_current = c.fetchone()[0]
        if existing_current >= len(SHAPE_DEFINITIONS):
            logger.debug(
                "[SagaShapesDB] %d factory shapes already up-to-date (skip seed)",
                existing_current,
            )
            return

        # Re-Seed: alte Factory-Shapes weg, neue rein.
        # User-Shapes (`saga_user_shape`) sind hier komplett unberührt.
        c.execute("DELETE FROM saga_shape WHERE is_factory=1")
        deleted_count = c.rowcount

        rows = [
            (
                shape.id,
                shape.name,
                shape.category,
                1,                         # is_factory
                shape.name,                # parametric_fn = Python-Lookup-Key
                float(shape.default_density),
                0.5,                       # default_speed
                int(shape.default_point_count),
                shape.description,
                None,                      # icon_svg (S-1+)
                SAGA_FACTORY_AUTHOR,
                SAGA_FACTORY_SHAPES_VERSION,
            )
            for shape in SHAPE_DEFINITIONS
        ]
        c.executemany(
            """
            INSERT INTO saga_shape
                (id, name, category, is_factory, parametric_fn,
                 default_density, default_speed, point_count, description,
                 icon_svg, author, version)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            rows,
        )

        # Renderer-Map: in S-0 nur Saga.Magic.
        c.execute(
            """
            INSERT OR REPLACE INTO saga_renderer_map
                (module_kind, renderer_type, enabled, body_min_height)
            VALUES (?, ?, ?, ?)
            """,
            ("Saga.Magic", "magic", 1, 100),
        )

        # Default-Palette (Norse-Cyan)
        c.execute(
            """
            INSERT OR REPLACE INTO saga_palette
                (id, name, hue_base, hue_modulation, alpha_min, alpha_max)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (0, "Norse-Cyan", 185, 0.15, 60, 220),
        )

        logger.info(
            "[SagaShapesDB] Seeded %d factory shapes (deleted %d old) — author='%s'",
            len(rows), deleted_count, SAGA_FACTORY_AUTHOR,
        )

    # ─── Read-API ─────────────────────────────────────────────────

    def _refresh_cache(self, conn: sqlite3.Connection) -> None:
        """Lädt alle Factory-Shapes in den In-Memory-Cache."""
        self._shape_cache.clear()
        c = conn.cursor()
        c.execute(
            """
            SELECT id, name, category, parametric_fn
            FROM saga_shape
            WHERE is_factory=1
            ORDER BY id
            """
        )
        for row in c.fetchall():
            sid, name, category, parametric_fn = row
            self._shape_cache[int(sid)] = (str(name), str(category), str(parametric_fn))

    def get_shape_meta(self, shape_id: int) -> Optional[tuple[str, str, str]]:
        """Liefert (name, category, parametric_fn) zur ID, oder None.

        Greift NUR auf den Cache zu — kein DB-Hit. Das ist der Hot-Path
        für den Renderer.
        """
        return self._shape_cache.get(int(shape_id))

    def list_shape_ids(self) -> list[int]:
        """Liefert alle Factory-Shape-IDs (sortiert)."""
        return sorted(self._shape_cache.keys())

    def factory_count(self) -> int:
        """Anzahl der Factory-Shapes im Cache."""
        return len(self._shape_cache)

    # ─── Health-Check ─────────────────────────────────────────────

    def diagnose(self) -> dict:
        """Liefert Diagnose-Info (für Tests + UI-Debug-Panel)."""
        with self._lock:
            with sqlite3.connect(str(self.db_path)) as conn:
                c = conn.cursor()
                c.execute("SELECT COUNT(*) FROM saga_shape WHERE is_factory=1")
                factory_n = c.fetchone()[0]
                c.execute("SELECT COUNT(*) FROM saga_user_shape")
                user_n = c.fetchone()[0]
                c.execute("SELECT COUNT(*) FROM saga_palette")
                palette_n = c.fetchone()[0]
                c.execute("SELECT COUNT(*) FROM saga_renderer_map")
                renderer_n = c.fetchone()[0]
                c.execute("SELECT value FROM meta WHERE key='schema_version'")
                row = c.fetchone()
                schema_v = row[0] if row else "?"
                c.execute("SELECT value FROM meta WHERE key='factory_author'")
                row = c.fetchone()
                marker = row[0] if row else "?"
            return {
                "db_path": str(self.db_path),
                "schema_version": schema_v,
                "factory_author_marker": marker,
                "factory_shapes": factory_n,
                "user_shapes": user_n,
                "palettes": palette_n,
                "renderer_map_entries": renderer_n,
                "cache_size": len(self._shape_cache),
            }


__all__ = [
    "SagaShapesDB",
    "SAGA_SCHEMA_VERSION",
]
