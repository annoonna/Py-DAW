"""Reference Track Analyser (P2B) — Compare your mix against a reference.

Pure Python + numpy. No ML dependencies.
Compares LUFS, spectral balance, dynamic range, stereo characteristics.

Features:
- LUFS comparison (integrated + momentary)
- Spectral tilt comparison (6-band)
- Dynamic range comparison (crest factor, RMS variation)
- Stereo width / correlation comparison
- Concrete actionable suggestions

v0.0.20.809 — Phase P2B
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Tuple, Any

log = logging.getLogger(__name__)

try:
    import numpy as np
except Exception:
    np = None  # type: ignore


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------

@dataclass
class SpectralBand:
    """Energy analysis for a frequency band."""
    name: str = ""
    freq_lo: float = 0.0
    freq_hi: float = 0.0
    energy_db: float = -96.0
    energy_ratio: float = 0.0  # 0..1 of total

    def to_dict(self) -> dict:
        return {
            "name": self.name, "freq_lo": self.freq_lo, "freq_hi": self.freq_hi,
            "energy_db": round(self.energy_db, 1),
            "energy_ratio": round(self.energy_ratio, 3),
        }


@dataclass
class AudioProfile:
    """Complete audio profile for comparison."""
    lufs_integrated: float = -23.0
    lufs_short_term_max: float = -18.0
    true_peak_db: float = -1.0
    rms_db: float = -18.0
    crest_factor_db: float = 12.0
    dynamic_range_db: float = 10.0
    stereo_width: float = 0.5
    stereo_correlation: float = 0.9
    spectral_bands: List[SpectralBand] = field(default_factory=list)
    spectral_centroid_hz: float = 2000.0
    spectral_tilt: float = 0.0  # positive=bright, negative=dark

    def to_dict(self) -> dict:
        return {
            "lufs_integrated": round(self.lufs_integrated, 1),
            "lufs_short_term_max": round(self.lufs_short_term_max, 1),
            "true_peak_db": round(self.true_peak_db, 1),
            "rms_db": round(self.rms_db, 1),
            "crest_factor_db": round(self.crest_factor_db, 1),
            "dynamic_range_db": round(self.dynamic_range_db, 1),
            "stereo_width": round(self.stereo_width, 3),
            "stereo_correlation": round(self.stereo_correlation, 3),
            "spectral_bands": [b.to_dict() for b in self.spectral_bands],
            "spectral_centroid_hz": round(self.spectral_centroid_hz, 0),
            "spectral_tilt": round(self.spectral_tilt, 2),
        }


@dataclass
class ComparisonResult:
    """Comparison between mix and reference."""
    category: str = ""        # "loudness"|"spectrum"|"dynamics"|"stereo"
    parameter: str = ""       # e.g. "LUFS", "Low Energy"
    mix_value: float = 0.0
    ref_value: float = 0.0
    diff: float = 0.0
    severity: str = "ok"      # "ok"|"minor"|"moderate"|"major"
    suggestion: str = ""

    def to_dict(self) -> dict:
        return {
            "category": self.category, "parameter": self.parameter,
            "mix_value": round(self.mix_value, 1),
            "ref_value": round(self.ref_value, 1),
            "diff": round(self.diff, 1),
            "severity": self.severity,
            "suggestion": self.suggestion,
        }


@dataclass
class ReferenceReport:
    """Full comparison report."""
    overall_score: float = 0.0       # 0..100
    overall_rating: str = "unknown"  # "excellent"|"good"|"fair"|"needs_work"
    comparisons: List[ComparisonResult] = field(default_factory=list)
    summary: str = ""
    suggestions: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "overall_score": round(self.overall_score, 1),
            "overall_rating": self.overall_rating,
            "comparisons": [c.to_dict() for c in self.comparisons],
            "summary": self.summary,
            "suggestions": self.suggestions,
        }


# ---------------------------------------------------------------------------
# Band definitions
# ---------------------------------------------------------------------------

_BANDS = [
    ("Sub", 20.0, 80.0),
    ("Low", 80.0, 250.0),
    ("Low-Mid", 250.0, 1000.0),
    ("Mid", 1000.0, 4000.0),
    ("High-Mid", 4000.0, 10000.0),
    ("High", 10000.0, 20000.0),
]


# ---------------------------------------------------------------------------
# Analysis helpers
# ---------------------------------------------------------------------------

def _safe_db(linear: float) -> float:
    """Convert linear amplitude to dB, clamped."""
    return 20.0 * math.log10(max(1e-10, abs(linear)))


def analyze_audio_buffer(
    samples: Any,
    sample_rate: float = 44100.0,
) -> AudioProfile:
    """Analyze an audio buffer (numpy array) and return its AudioProfile.

    Args:
        samples: numpy array, shape (N,) for mono or (N, 2) for stereo
        sample_rate: sample rate in Hz

    Returns:
        AudioProfile with all measurements.
    """
    if np is None:
        return AudioProfile()

    samples = np.asarray(samples, dtype=np.float64)

    # Ensure 2D stereo
    if samples.ndim == 1:
        samples = np.column_stack([samples, samples])
    elif samples.ndim == 2 and samples.shape[1] == 1:
        samples = np.column_stack([samples[:, 0], samples[:, 0]])

    if samples.shape[0] == 0:
        return AudioProfile()

    left = samples[:, 0]
    right = samples[:, 1]
    mono = (left + right) * 0.5

    # RMS
    rms = float(np.sqrt(np.mean(mono ** 2)))
    rms_db = _safe_db(rms)

    # Peak
    peak = float(np.max(np.abs(mono)))
    peak_db = _safe_db(peak)

    # Crest factor
    crest_db = peak_db - rms_db

    # LUFS approximation (ITU-R BS.1770 simplified)
    # K-weighted filter approximation: pre-emphasis high shelf
    lufs_integrated = rms_db - 0.691  # simplified approximation

    # Short-term LUFS (3s windows)
    window_samples = int(3.0 * sample_rate)
    st_lufs_max = -96.0
    if len(mono) > window_samples:
        for i in range(0, len(mono) - window_samples, window_samples // 2):
            chunk = mono[i:i + window_samples]
            chunk_rms = float(np.sqrt(np.mean(chunk ** 2)))
            chunk_lufs = _safe_db(chunk_rms) - 0.691
            st_lufs_max = max(st_lufs_max, chunk_lufs)
    else:
        st_lufs_max = lufs_integrated

    # Dynamic range (RMS variation)
    block_size = int(0.4 * sample_rate)
    block_rms_vals = []
    for i in range(0, len(mono) - block_size, block_size):
        chunk = mono[i:i + block_size]
        br = float(np.sqrt(np.mean(chunk ** 2)))
        if br > 1e-10:
            block_rms_vals.append(_safe_db(br))
    if block_rms_vals:
        dynamic_range_db = max(block_rms_vals) - min(block_rms_vals)
    else:
        dynamic_range_db = 0.0

    # Spectral analysis
    n_fft = min(8192, len(mono))
    if n_fft >= 512:
        spectrum = np.abs(np.fft.rfft(mono[:n_fft]))
        freqs = np.fft.rfftfreq(n_fft, d=1.0 / sample_rate)
        total_energy = float(np.sum(spectrum ** 2))
        if total_energy < 1e-20:
            total_energy = 1.0

        bands: List[SpectralBand] = []
        for name, flo, fhi in _BANDS:
            mask = (freqs >= flo) & (freqs < fhi)
            band_energy = float(np.sum(spectrum[mask] ** 2))
            ratio = band_energy / total_energy
            bands.append(SpectralBand(
                name=name, freq_lo=flo, freq_hi=fhi,
                energy_db=_safe_db(math.sqrt(band_energy / max(1, np.sum(mask)))),
                energy_ratio=ratio,
            ))

        # Spectral centroid
        if np.sum(spectrum) > 0:
            centroid = float(np.sum(freqs * spectrum) / np.sum(spectrum))
        else:
            centroid = 2000.0

        # Spectral tilt (linear regression slope on log spectrum)
        log_spectrum = np.log10(spectrum[1:n_fft // 4] + 1e-10)
        log_freqs = np.log10(freqs[1:n_fft // 4] + 1e-10)
        if len(log_spectrum) > 2:
            coeffs = np.polyfit(log_freqs, log_spectrum, 1)
            tilt = float(coeffs[0])
        else:
            tilt = 0.0
    else:
        bands = []
        centroid = 2000.0
        tilt = 0.0

    # Stereo analysis
    if left.shape == right.shape and len(left) > 0:
        mid = (left + right) * 0.5
        side = (left - right) * 0.5
        mid_rms = float(np.sqrt(np.mean(mid ** 2)))
        side_rms = float(np.sqrt(np.mean(side ** 2)))
        width = side_rms / max(mid_rms + side_rms, 1e-10)

        # Correlation
        if np.std(left) > 1e-10 and np.std(right) > 1e-10:
            correlation = float(np.corrcoef(left[:min(len(left), 44100 * 10)],
                                            right[:min(len(right), 44100 * 10)])[0, 1])
        else:
            correlation = 1.0
    else:
        width = 0.0
        correlation = 1.0

    return AudioProfile(
        lufs_integrated=lufs_integrated,
        lufs_short_term_max=st_lufs_max,
        true_peak_db=peak_db,
        rms_db=rms_db,
        crest_factor_db=crest_db,
        dynamic_range_db=dynamic_range_db,
        stereo_width=width,
        stereo_correlation=correlation,
        spectral_bands=bands,
        spectral_centroid_hz=centroid,
        spectral_tilt=tilt,
    )


# ---------------------------------------------------------------------------
# Comparison engine
# ---------------------------------------------------------------------------

def _classify_severity(diff_abs: float, thresholds: Tuple[float, float, float]) -> str:
    """Classify difference severity."""
    if diff_abs <= thresholds[0]:
        return "ok"
    elif diff_abs <= thresholds[1]:
        return "minor"
    elif diff_abs <= thresholds[2]:
        return "moderate"
    else:
        return "major"


def compare_to_reference(
    mix: AudioProfile,
    reference: AudioProfile,
) -> ReferenceReport:
    """Compare a mix profile against a reference profile.

    Returns:
        ReferenceReport with per-parameter comparisons and suggestions.
    """
    comparisons: List[ComparisonResult] = []
    suggestions: List[str] = []
    scores: List[float] = []  # per-dimension score 0..1

    # ── Loudness ──────────────────────────────────────────────────────
    lufs_diff = mix.lufs_integrated - reference.lufs_integrated
    sev = _classify_severity(abs(lufs_diff), (1.0, 3.0, 6.0))
    suggestion = ""
    if lufs_diff > 2.0:
        suggestion = f"Mix ist {lufs_diff:.1f} dB lauter als Referenz — Limiter-Ceiling senken"
        suggestions.append(suggestion)
    elif lufs_diff < -2.0:
        suggestion = f"Mix ist {abs(lufs_diff):.1f} dB leiser als Referenz — Makeup-Gain erhöhen"
        suggestions.append(suggestion)
    comparisons.append(ComparisonResult(
        category="loudness", parameter="LUFS (integriert)",
        mix_value=mix.lufs_integrated, ref_value=reference.lufs_integrated,
        diff=lufs_diff, severity=sev, suggestion=suggestion,
    ))
    scores.append(max(0, 1.0 - abs(lufs_diff) / 10.0))

    # True Peak
    peak_diff = mix.true_peak_db - reference.true_peak_db
    sev = _classify_severity(abs(peak_diff), (1.0, 3.0, 6.0))
    suggestion = ""
    if mix.true_peak_db > -0.3:
        suggestion = "True Peak nahe 0 dBFS — Inter-Sample-Peaks riskant, Limiter-Ceiling auf -1 dBTP"
        suggestions.append(suggestion)
    comparisons.append(ComparisonResult(
        category="loudness", parameter="True Peak",
        mix_value=mix.true_peak_db, ref_value=reference.true_peak_db,
        diff=peak_diff, severity=sev, suggestion=suggestion,
    ))

    # ── Dynamics ──────────────────────────────────────────────────────
    crest_diff = mix.crest_factor_db - reference.crest_factor_db
    sev = _classify_severity(abs(crest_diff), (2.0, 4.0, 8.0))
    suggestion = ""
    if crest_diff < -3.0:
        suggestion = (f"Mix ist {abs(crest_diff):.1f} dB stärker komprimiert als Referenz — "
                      f"weniger Kompression oder langsamerer Attack")
        suggestions.append(suggestion)
    elif crest_diff > 3.0:
        suggestion = (f"Mix hat {crest_diff:.1f} dB mehr Dynamik als Referenz — "
                      f"Bus-Kompression oder Limiting erhöhen")
        suggestions.append(suggestion)
    comparisons.append(ComparisonResult(
        category="dynamics", parameter="Crest Factor",
        mix_value=mix.crest_factor_db, ref_value=reference.crest_factor_db,
        diff=crest_diff, severity=sev, suggestion=suggestion,
    ))
    scores.append(max(0, 1.0 - abs(crest_diff) / 12.0))

    # Dynamic range
    dr_diff = mix.dynamic_range_db - reference.dynamic_range_db
    sev = _classify_severity(abs(dr_diff), (2.0, 5.0, 10.0))
    comparisons.append(ComparisonResult(
        category="dynamics", parameter="Dynamic Range",
        mix_value=mix.dynamic_range_db, ref_value=reference.dynamic_range_db,
        diff=dr_diff, severity=sev,
    ))

    # ── Spectrum ──────────────────────────────────────────────────────
    if mix.spectral_bands and reference.spectral_bands:
        for mb, rb in zip(mix.spectral_bands, reference.spectral_bands):
            ratio_diff = mb.energy_ratio - rb.energy_ratio
            abs_diff = abs(ratio_diff)
            sev = _classify_severity(abs_diff, (0.03, 0.08, 0.15))
            suggestion = ""
            if abs_diff > 0.05:
                direction = "zu viel" if ratio_diff > 0 else "zu wenig"
                action = "absenken" if ratio_diff > 0 else "anheben"
                suggestion = (f"{mb.name} ({mb.freq_lo:.0f}-{mb.freq_hi:.0f} Hz): "
                              f"{direction} Energie — EQ {action}")
                suggestions.append(suggestion)

            comparisons.append(ComparisonResult(
                category="spectrum", parameter=f"Band: {mb.name}",
                mix_value=mb.energy_ratio * 100,
                ref_value=rb.energy_ratio * 100,
                diff=ratio_diff * 100,
                severity=sev, suggestion=suggestion,
            ))
            scores.append(max(0, 1.0 - abs_diff / 0.2))

    # Spectral tilt
    tilt_diff = mix.spectral_tilt - reference.spectral_tilt
    sev = _classify_severity(abs(tilt_diff), (0.3, 0.6, 1.0))
    suggestion = ""
    if tilt_diff > 0.4:
        suggestion = "Mix ist heller als Referenz — High-Shelf absenken oder Low-End anheben"
        suggestions.append(suggestion)
    elif tilt_diff < -0.4:
        suggestion = "Mix ist dunkler als Referenz — Präsenz/Air EQ anheben"
        suggestions.append(suggestion)
    comparisons.append(ComparisonResult(
        category="spectrum", parameter="Spectral Tilt",
        mix_value=mix.spectral_tilt, ref_value=reference.spectral_tilt,
        diff=tilt_diff, severity=sev, suggestion=suggestion,
    ))
    scores.append(max(0, 1.0 - abs(tilt_diff) / 1.5))

    # ── Stereo ────────────────────────────────────────────────────────
    width_diff = mix.stereo_width - reference.stereo_width
    sev = _classify_severity(abs(width_diff), (0.05, 0.15, 0.3))
    suggestion = ""
    if width_diff > 0.1:
        suggestion = "Mix ist breiter als Referenz — Stereo-Width reduzieren oder Mono-Check"
        suggestions.append(suggestion)
    elif width_diff < -0.1:
        suggestion = "Mix ist enger als Referenz — Stereo-Widener oder Pan-Spread erhöhen"
        suggestions.append(suggestion)
    comparisons.append(ComparisonResult(
        category="stereo", parameter="Stereo Width",
        mix_value=mix.stereo_width, ref_value=reference.stereo_width,
        diff=width_diff, severity=sev, suggestion=suggestion,
    ))
    scores.append(max(0, 1.0 - abs(width_diff) / 0.4))

    # Correlation
    corr_diff = mix.stereo_correlation - reference.stereo_correlation
    sev = _classify_severity(abs(corr_diff), (0.05, 0.15, 0.3))
    suggestion = ""
    if mix.stereo_correlation < 0.3:
        suggestion = "Sehr niedrige Stereo-Korrelation — mögliche Phasenprobleme prüfen"
        suggestions.append(suggestion)
    comparisons.append(ComparisonResult(
        category="stereo", parameter="Stereo Correlation",
        mix_value=mix.stereo_correlation, ref_value=reference.stereo_correlation,
        diff=corr_diff, severity=sev, suggestion=suggestion,
    ))

    # ── Overall score ─────────────────────────────────────────────────
    if scores:
        overall = (sum(scores) / len(scores)) * 100
    else:
        overall = 50.0

    if overall >= 85:
        rating = "excellent"
    elif overall >= 70:
        rating = "good"
    elif overall >= 50:
        rating = "fair"
    else:
        rating = "needs_work"

    rating_de = {
        "excellent": "Exzellent", "good": "Gut",
        "fair": "Akzeptabel", "needs_work": "Überarbeitung nötig",
    }

    major_issues = [c for c in comparisons if c.severity in ("major", "moderate")]
    summary_parts = [f"Gesamt-Score: {overall:.0f}/100 ({rating_de.get(rating, rating)})"]
    if major_issues:
        summary_parts.append(
            f"{len(major_issues)} Bereiche mit größeren Abweichungen"
        )
    if not suggestions:
        summary_parts.append("Mix ist sehr nah an der Referenz")

    return ReferenceReport(
        overall_score=overall,
        overall_rating=rating,
        comparisons=comparisons,
        summary=". ".join(summary_parts),
        suggestions=suggestions[:8],
    )
