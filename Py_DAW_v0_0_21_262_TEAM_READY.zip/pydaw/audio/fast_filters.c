/*
 * Py_DAW — Fast IIR Filters (C Extension)
 * v0.0.20.786
 *
 * SVF (Cytomic/Simper Trapezoidal) and Moog Ladder (Huovilainen).
 * Called via ctypes from Python. Zero-allocation, inline math.
 *
 * Build:  gcc -O3 -march=native -ffast-math -shared -fPIC -o fast_filters.so fast_filters.c -lm
 */

#include <math.h>
#include <stdint.h>

/* ═══════════════════════════════════════════════════════════
 *  SVF — State Variable Filter (Cytomic/Simper)
 * ═══════════════════════════════════════════════════════════ */

/*
 * svf_process: Process buffer through SVF.
 *
 * buf_in:  input samples (double*)
 * buf_out: output samples (double*)
 * n:       number of samples
 * cutoff:  cutoff frequency (Hz)
 * resonance: 0..1
 * sr:      sample rate
 * mode:    0=LP, 1=HP, 2=BP
 * drive:   drive amount (0..1, 0=off)
 * res_limit: resonance limit (0..1)
 * state:   double[2] — ic1eq, ic2eq (read/write, persistent)
 */
void svf_process(const double *buf_in, double *buf_out, int n,
                 double cutoff, double resonance, double sr,
                 int mode, double drive, double res_limit,
                 double *state)
{
    /* Clamp cutoff */
    double sr_half = sr * 0.49;
    if (cutoff < 20.0) cutoff = 20.0;
    else if (cutoff > sr_half) cutoff = sr_half;

    /* Resonance → Q */
    double q = 0.5 + resonance * 24.5 * res_limit;

    /* SVF coefficients (Simper) */
    double g = tan(M_PI * cutoff / sr);
    double k = 1.0 / q;
    double a1 = 1.0 / (1.0 + g * (g + k));
    double a2 = g * a1;
    double a3 = g * a2;

    double ic1 = state[0];
    double ic2 = state[1];

    /* Drive */
    double drive_gain = 1.0 + drive * 8.0;
    int has_drive = (drive_gain > 1.01);

    if (has_drive) {
        double tanh_drive = tanh(drive_gain);
        double inv_tanh_drive = 1.0 / tanh_drive;

        if (mode == 0) { /* LP + drive */
            for (int i = 0; i < n; i++) {
                double v0 = tanh(buf_in[i] * drive_gain) * inv_tanh_drive;
                double v3 = v0 - ic2;
                double v1 = a1 * ic1 + a2 * v3;
                double v2 = ic2 + a2 * ic1 + a3 * v3;
                ic1 = 2.0 * v1 - ic1;
                ic2 = 2.0 * v2 - ic2;
                buf_out[i] = v2;
            }
        } else if (mode == 1) { /* HP + drive */
            for (int i = 0; i < n; i++) {
                double v0 = tanh(buf_in[i] * drive_gain) * inv_tanh_drive;
                double v3 = v0 - ic2;
                double v1 = a1 * ic1 + a2 * v3;
                double v2 = ic2 + a2 * ic1 + a3 * v3;
                ic1 = 2.0 * v1 - ic1;
                ic2 = 2.0 * v2 - ic2;
                buf_out[i] = v0 - k * v1 - v2;
            }
        } else { /* BP + drive */
            for (int i = 0; i < n; i++) {
                double v0 = tanh(buf_in[i] * drive_gain) * inv_tanh_drive;
                double v3 = v0 - ic2;
                double v1 = a1 * ic1 + a2 * v3;
                double v2 = ic2 + a2 * ic1 + a3 * v3;
                ic1 = 2.0 * v1 - ic1;
                ic2 = 2.0 * v2 - ic2;
                buf_out[i] = v1;
            }
        }
    } else {
        /* No drive — most common path */
        if (mode == 0) { /* LP */
            for (int i = 0; i < n; i++) {
                double v3 = buf_in[i] - ic2;
                double v1 = a1 * ic1 + a2 * v3;
                double v2 = ic2 + a2 * ic1 + a3 * v3;
                ic1 = 2.0 * v1 - ic1;
                ic2 = 2.0 * v2 - ic2;
                buf_out[i] = v2;
            }
        } else if (mode == 1) { /* HP */
            for (int i = 0; i < n; i++) {
                double v0 = buf_in[i];
                double v3 = v0 - ic2;
                double v1 = a1 * ic1 + a2 * v3;
                double v2 = ic2 + a2 * ic1 + a3 * v3;
                ic1 = 2.0 * v1 - ic1;
                ic2 = 2.0 * v2 - ic2;
                buf_out[i] = v0 - k * v1 - v2;
            }
        } else { /* BP */
            for (int i = 0; i < n; i++) {
                double v3 = buf_in[i] - ic2;
                double v1 = a1 * ic1 + a2 * v3;
                double v2 = ic2 + a2 * ic1 + a3 * v3;
                ic1 = 2.0 * v1 - ic1;
                ic2 = 2.0 * v2 - ic2;
                buf_out[i] = v1;
            }
        }
    }

    state[0] = ic1;
    state[1] = ic2;
}


/* ═══════════════════════════════════════════════════════════
 *  Moog Ladder — 4-pole Transistor Ladder (Huovilainen)
 * ═══════════════════════════════════════════════════════════ */

/*
 * ladder_process: Process buffer through Moog Ladder.
 *
 * buf_in:  input samples (double*)
 * buf_out: output samples (double*)
 * n:       number of samples
 * cutoff:  cutoff frequency (Hz)
 * resonance: 0..1
 * sr:      sample rate
 * drive:   drive amount (0..1, 0=off)
 * res_limit: resonance limit (0..1)
 * state:   double[4] — s0, s1, s2, s3 (read/write, persistent)
 */
void ladder_process(const double *buf_in, double *buf_out, int n,
                    double cutoff, double resonance, double sr,
                    double drive, double res_limit,
                    double *state)
{
    /* Clamp cutoff */
    double sr_half = sr * 0.49;
    if (cutoff < 20.0) cutoff = 20.0;
    else if (cutoff > sr_half) cutoff = sr_half;

    /* Resonance 0..4 */
    double k = resonance * 4.0 * res_limit;

    /* Drive */
    double drive_gain = 1.0 + drive * 8.0;
    int has_drive = (drive_gain > 1.01);

    /* Huovilainen coefficient */
    double g = 1.0 - exp(-2.0 * M_PI * cutoff / sr);

    double s0 = state[0], s1 = state[1], s2 = state[2], s3 = state[3];

    if (has_drive) {
        for (int i = 0; i < n; i++) {
            double x = tanh(buf_in[i] * drive_gain);
            double u = x - k * s3;
            s0 += g * (tanh(u)  - tanh(s0));
            s1 += g * (tanh(s0) - tanh(s1));
            s2 += g * (tanh(s1) - tanh(s2));
            s3 += g * (tanh(s2) - tanh(s3));
            buf_out[i] = s3;
        }
    } else {
        for (int i = 0; i < n; i++) {
            double u = buf_in[i] - k * s3;
            s0 += g * (tanh(u)  - tanh(s0));
            s1 += g * (tanh(s0) - tanh(s1));
            s2 += g * (tanh(s1) - tanh(s2));
            s3 += g * (tanh(s2) - tanh(s3));
            buf_out[i] = s3;
        }
    }

    state[0] = s0;
    state[1] = s1;
    state[2] = s2;
    state[3] = s3;
}


/* ═══════════════════════════════════════════════════════════
 *  Comb Filter with Damping
 * ═══════════════════════════════════════════════════════════ */

/*
 * comb_process: Process buffer through Comb filter.
 *
 * buf_in:    input samples
 * buf_out:   output samples
 * n:         number of samples
 * delay_buf: pre-allocated circular buffer (double[max_delay])
 * buf_len:   length of delay buffer
 * delay_samples: delay in fractional samples
 * feedback:  -1..+1
 * damp_g:    damping LP coefficient (0..1)
 * wp:        write position (int*, read/write)
 * damp_state: LP state (double*, read/write)
 */
void comb_process(const double *buf_in, double *buf_out, int n,
                  double *delay_buf, int buf_len,
                  double delay_samples, double feedback, double damp_g,
                  int *wp, double *damp_state)
{
    int w = *wp;
    double ds = *damp_state;
    int delay_int = (int)delay_samples;
    double delay_frac = delay_samples - delay_int;
    double one_minus_frac = 1.0 - delay_frac;

    for (int i = 0; i < n; i++) {
        int rp1 = (w - delay_int + buf_len) % buf_len;
        int rp2 = (w - delay_int - 1 + buf_len) % buf_len;
        double delayed = delay_buf[rp1] * one_minus_frac + delay_buf[rp2] * delay_frac;

        ds += damp_g * (delayed - ds);
        delay_buf[w] = buf_in[i] + ds * feedback;

        buf_out[i] = delayed;
        w = (w + 1) % buf_len;
    }

    *wp = w;
    *damp_state = ds;
}
