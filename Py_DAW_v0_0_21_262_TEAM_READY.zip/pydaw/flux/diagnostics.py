"""v0.0.21.241 — Patch-Diagnose-Service für „stumme Oszi"-Probleme.

Anno (v.240 → v.241): „einige der oszilatoren in flux funktionieren nicht
und sind stumm obwohl sie lautstärke haben".

Diagnose-Audit (v.241): Alle 19 Bragi-Oszis produzieren bei direktem
DSP-Test sauberen Output. Das „stumm"-Symptom kommt aus dem PATCH-
Routing, nicht aus der DSP. Häufigste Ursachen:

    1. Kein Heimdall.MasterOut im Patch
    2. MasterOut da, aber audio_in_l/audio_in_r unverbunden
    3. Frigg.Knob auf value=0.0 → gain wird gegen 0 gezogen
    4. Ratatosk.Mtof/Ftom ohne rune_in-Verbindung → freq=0 → stumm
    5. Oszillator nicht im Render-Pfad zum Master (kein Topo-Path)

Dieses Modul scannt einen Patch VOR dem Audio-Render und liefert
klare, anwendbare Diagnose-Meldungen.

Architektur: pure-Python, keine Qt-Deps. Nutzbar von:
- audio_preview.play_patch (Pre-Render-Check)
- Test-Suite
- zukünftig: UI-Status-Label, Tooltip am Modul, Settings-Dialog

Schmal & additiv — bestehender Renderer wird NICHT angefasst.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, List

from pydaw.flux.patch_model import Patch, Module


# ─── Diagnose-Datenstruktur ─────────────────────────────────────────

@dataclass(frozen=True)
class Diagnosis:
    """Eine einzelne Befundeinheit aus dem Patch-Scan."""
    severity: str               # 'error' | 'warning' | 'info'
    code: str                   # kurzer maschinen-lesbarer Code
    message: str                # User-facing Text (deutsch, konkret)
    module_ids: tuple[str, ...] = ()  # zugehörige Module im Patch
    fix_hint: Optional[str] = None    # Wie der User das beheben kann


# ─── Helpers ────────────────────────────────────────────────────────

def _has_audio_path_to_master(patch: Patch, master: Module,
                              source_id: str) -> bool:
    """Prüft ob source_id über Audio-Connections den master erreicht.

    BFS rückwärts ab master.audio_in_l/r — wir sammeln alle
    Module deren audio_out (rekursiv) auf master.audio_in_l/r läuft.
    """
    visited: set[str] = set()
    # Start: alle Module die direkt auf master.audio_in_l/r feeden
    frontier: set[str] = set()
    for c in patch.connections:
        if c.target_module == master.id and c.target_port in (
            'audio_in_l', 'audio_in_r',
        ):
            frontier.add(c.source_module)
    # BFS rückwärts: was feedet die Frontier?
    while frontier:
        next_layer: set[str] = set()
        for mid in frontier:
            if mid in visited:
                continue
            visited.add(mid)
            if mid == source_id:
                return True
            # Suche alle Module die dieses Modul über AUDIO speisen
            for c in patch.connections:
                if c.target_module == mid:
                    next_layer.add(c.source_module)
        frontier = next_layer
    return False


def _module_audio_out_used(patch: Patch, mid: str) -> bool:
    """True wenn module.audio_out (oder ähnliche Audio-Outputs) verbunden ist."""
    for c in patch.connections:
        if c.source_module == mid and 'audio' in c.source_port.lower():
            return True
    return False


def _is_oscillator(module: Module) -> bool:
    """Heuristik: ist das Modul ein Sound-erzeugender Oszi?"""
    # Bragi.* mit "Osc" im Namen + ein paar weitere Sound-Quellen
    if module.god == 'Bragi' and 'Osc' in module.kind:
        return True
    if module.god == 'Bragi' and module.kind in (
        'NoiseOsc',  # bereits durch Heuristik abgedeckt, hier defensiv
    ):
        return True
    # Zerberus.Sampler ist auch Sound-Quelle
    if module.god == 'Zerberus' and 'Sampler' in module.kind:
        return True
    # Saga.Magic ist Visualizer, NICHT Sound-Quelle → nicht include
    return False


def _find_param_value(patch: Patch, target_mid: str,
                      target_port: str) -> Optional[float]:
    """Findet den effektiven CV-Wert eines Param-Inputs.

    Priorität:
      1. Wenn ein CV-Connector auf den Port führt: vom Source ablesen
         (rekursive Auflösung von Frigg.Knob/SliderV value-Param).
      2. Sonst: Modul-Default-Param.

    Returns: float-Wert oder None wenn nicht ermittelbar.
    """
    target = patch.get_module(target_mid)
    if target is None:
        return None
    # Suche eingehende Connection auf target_port
    for c in patch.connections:
        if c.target_module == target_mid and c.target_port == target_port:
            src = patch.get_module(c.source_module)
            if src is None:
                continue
            # Frigg.Knob / SliderV / SliderH / NumberBox: 'value' ist der Wert
            if src.god == 'Frigg' and src.kind in (
                'Knob', 'SliderV', 'SliderH', 'NumberBox',
                'AuroraSliderV', 'AuroraSliderH',
            ):
                v = src.params.get('value')
                if isinstance(v, (int, float)):
                    return float(v)
            # Frigg.Toggle: 'value' ist 0 oder 1
            if src.god == 'Frigg' and src.kind in ('Toggle', 'RuneToggle'):
                v = src.params.get('value')
                if isinstance(v, (int, float)):
                    return float(v)
            # Andere: nicht statisch berechenbar (LFO, Mtof etc.)
            return None
    # Kein CV-Input → Modul-Default-Param
    v = target.params.get(target_port)
    if isinstance(v, (int, float)):
        return float(v)
    return None


# ─── Diagnose-Checks ────────────────────────────────────────────────

def _check_empty_patch(patch: Patch) -> List[Diagnosis]:
    if not patch.modules:
        return [Diagnosis(
            severity='error', code='empty_patch',
            message='Patch ist leer — füge mindestens ein Modul hinzu.',
            fix_hint='Drag-and-Drop ein Modul aus der linken Palette in den Canvas.',
        )]
    return []


def _check_master_present(patch: Patch) -> List[Diagnosis]:
    masters = [m for m in patch.modules
               if m.god == 'Heimdall' and m.kind == 'MasterOut']
    if not masters:
        return [Diagnosis(
            severity='error', code='no_master',
            message='Kein Heimdall.MasterOut im Patch — ohne Master kommt '
                    'nichts an die Soundkarte.',
            fix_hint='Füge ein Heimdall.MasterOut hinzu und verbinde '
                     'audio_out deines Oszis mit MasterOut.audio_in_l '
                     'und audio_in_r.',
        )]
    if len(masters) > 1:
        return [Diagnosis(
            severity='warning', code='multiple_masters',
            message=f'{len(masters)} MasterOut-Module gefunden — nur das '
                    'erste wird genutzt, die anderen sind tot.',
            module_ids=tuple(m.id for m in masters[1:]),
            fix_hint='Lösche die überzähligen MasterOut-Module.',
        )]
    return []


def _check_master_connected(patch: Patch) -> List[Diagnosis]:
    """Prüft ob der MasterOut audio_in_l ODER audio_in_r verbunden hat."""
    master = next(
        (m for m in patch.modules
         if m.god == 'Heimdall' and m.kind == 'MasterOut'),
        None,
    )
    if master is None:
        return []  # _check_master_present hat das schon gemeldet
    has_l = any(
        c.target_module == master.id and c.target_port == 'audio_in_l'
        for c in patch.connections
    )
    has_r = any(
        c.target_module == master.id and c.target_port == 'audio_in_r'
        for c in patch.connections
    )
    if not has_l and not has_r:
        return [Diagnosis(
            severity='error', code='master_not_connected',
            message='Heimdall.MasterOut ist NICHT verbunden — verbinde '
                    'audio_out deines Oszis (oder den Output-Effekt) mit '
                    'MasterOut.audio_in_l / audio_in_r.',
            module_ids=(master.id,),
            fix_hint='Klick auf den Oszi-Output (audio_out, gelber Punkt) '
                     'und ziehe Cable zu MasterOut.audio_in_l. Dann '
                     'gleiche Cable zu audio_in_r für Stereo.',
        )]
    if has_l and not has_r:
        return [Diagnosis(
            severity='warning', code='master_mono_left',
            message='Nur audio_in_l ist verbunden — Output ist nur auf '
                    'dem linken Kanal hörbar.',
            module_ids=(master.id,),
            fix_hint='Verbinde dieselbe Quelle auch mit MasterOut.audio_in_r '
                     'für Stereo.',
        )]
    if has_r and not has_l:
        return [Diagnosis(
            severity='warning', code='master_mono_right',
            message='Nur audio_in_r ist verbunden — Output ist nur auf '
                    'dem rechten Kanal hörbar.',
            module_ids=(master.id,),
            fix_hint='Verbinde dieselbe Quelle auch mit MasterOut.audio_in_l '
                     'für Stereo.',
        )]
    return []


def _check_oscillators_reach_master(patch: Patch) -> List[Diagnosis]:
    """Findet Oszillatoren die nicht zum Master durchverdrahtet sind."""
    master = next(
        (m for m in patch.modules
         if m.god == 'Heimdall' and m.kind == 'MasterOut'),
        None,
    )
    if master is None:
        return []
    diags: List[Diagnosis] = []
    orphans: list[str] = []
    for m in patch.modules:
        if not _is_oscillator(m):
            continue
        if not _module_audio_out_used(patch, m.id):
            orphans.append(m.id)
            continue
        if not _has_audio_path_to_master(patch, master, m.id):
            orphans.append(m.id)
    if orphans:
        # Sammle Modul-Labels für lesbare Meldung
        labels = []
        for mid in orphans[:5]:  # max 5 zeigen
            mm = patch.get_module(mid)
            if mm is not None:
                labels.append(f'{mm.god}.{mm.kind}')
        more = f' (+{len(orphans)-5} weitere)' if len(orphans) > 5 else ''
        diags.append(Diagnosis(
            severity='warning', code='orphan_oscillator',
            message=f'{len(orphans)} Oszillator(en) erreichen den Master '
                    f'nicht: {", ".join(labels)}{more}.',
            module_ids=tuple(orphans),
            fix_hint='Verbinde audio_out → MasterOut.audio_in_l '
                     '(direkt oder über FX-Module wie Forseti.Lowpass).',
        ))
    return diags


def _check_zero_gain(patch: Patch) -> List[Diagnosis]:
    """Findet Oszis deren effektiver `gain` (oder Knob davor) auf 0 steht."""
    diags: List[Diagnosis] = []
    for m in patch.modules:
        if not _is_oscillator(m):
            continue
        # Prüfe gain-Port wenn vorhanden
        gain_port = next((p for p in m.inputs if p.name == 'gain'), None)
        if gain_port is None:
            continue
        gain_value = _find_param_value(patch, m.id, 'gain')
        if gain_value is not None and gain_value < 1e-6:
            # Gain ist effektiv 0 — finden wir die Quelle:
            cv_source = None
            for c in patch.connections:
                if c.target_module == m.id and c.target_port == 'gain':
                    src = patch.get_module(c.source_module)
                    if src is not None:
                        cv_source = f'{src.god}.{src.kind}'
                    break
            if cv_source:
                msg = (f'{m.god}.{m.kind}.gain wird durch {cv_source} '
                       f'auf 0.0 gezogen — Oszi ist stumm.')
                hint = (f'Drehe den {cv_source}-Wert über 0 oder '
                        'lösche die Verbindung zum gain-Input.')
            else:
                msg = (f'{m.god}.{m.kind}.gain ist als Modul-Param 0.0 '
                       '— Oszi ist stumm.')
                hint = 'Setze den gain-Param im Properties-Panel über 0.'
            diags.append(Diagnosis(
                severity='warning', code='zero_gain',
                message=msg, module_ids=(m.id,), fix_hint=hint,
            ))
    return diags


def _check_mtof_unconnected(patch: Patch) -> List[Diagnosis]:
    """Mtof/Ftom ohne rune_in-Verbindung produzieren leere Listen.

    Wenn dieses Mtof dann in einen Oszi.freq fließt, fällt der Oszi
    auf seinen Default-freq zurück (also nicht stumm an sich, ABER
    der User hat sich vermutlich an Mtof gewünscht dass es seine
    'Note' ausgibt — und ist verwirrt warum die Note nicht greift).
    """
    diags: List[Diagnosis] = []
    for m in patch.modules:
        if m.god != 'Ratatosk' or m.kind not in ('Mtof', 'Ftom'):
            continue
        # Hat rune_in eine Connection?
        has_input = any(
            c.target_module == m.id and c.target_port == 'rune_in'
            for c in patch.connections
        )
        # Wird rune_out überhaupt gelesen?
        has_output = any(
            c.source_module == m.id and c.source_port == 'rune_out'
            for c in patch.connections
        )
        if has_output and not has_input:
            diags.append(Diagnosis(
                severity='warning', code='mtof_no_trigger',
                message=f'{m.god}.{m.kind} hat rune_out verbunden, aber '
                        'KEINE rune_in-Quelle — wird leere Liste senden, '
                        'angeschlossener Oszi-freq fällt auf Default '
                        'zurück.',
                module_ids=(m.id,),
                fix_hint=f'Verbinde z.B. Vör.Int.rune_out (mit value=60 '
                         f'für C4) → {m.god}.{m.kind}.rune_in. Oder '
                         'Norns.Metro → Ullr.Random → Plus(48) → Mtof.',
            ))
    return diags


# ─── v0.0.21.242: Live-Activity-Check ───────────────────────────────

def _check_live_activity(patch: Patch, audio_preview) -> List[Diagnosis]:
    """v0.0.21.242: Probe-Render starten + Activity pro Modul prüfen.

    Diese Funktion läuft NUR wenn ``audio_preview`` (FluxAudioPreview-
    Instanz) übergeben wird. Sie macht einen kurzen 0.3s-Probe-Render
    und liest die `_module_activity` Werte. Module die nach dem
    Probe-Render activity == 0 haben, obwohl sie eigentlich Sound
    produzieren sollten (Oszis, Sampler), werden als „dead in render"
    gemeldet.

    Anno-Use-Case (v.242): „14 Oszis sind stumm". Statische Diagnose
    findet keine Probleme (Patch sieht OK aus). Live-Activity-Check
    findet die echten stummen Module — egal warum.

    Args:
        patch: der Patch
        audio_preview: FluxAudioPreview-Instanz mit `_render_patch()`
                       und `get_activity()` Methoden

    Returns:
        Liste von Diagnose-Objekten — pro stummem Sound-Quelle eine
        Diagnose.
    """
    if audio_preview is None:
        return []
    diags: List[Diagnosis] = []
    # Probe-Render (kurz, leise, nur zum activity-Sampling)
    try:
        # Reset activity bevor wir messen
        if hasattr(audio_preview, 'reset_activity'):
            audio_preview.reset_activity()
        elif hasattr(audio_preview, '_module_activity'):
            audio_preview._module_activity.clear()
        # 0.3s ist genug für Filter-Settling + Envelope-Build-up
        audio_preview._render_patch(patch, duration_sec=0.3)
    except Exception:
        # Render-Fehler ist OK — andere Diagnosen haben das ggf. schon
        # gemeldet. Live-Check fällt einfach raus.
        return diags
    # Pro Sound-Quelle (Oszi/Sampler) prüfen ob sie Activity hatte
    silent_sources: list[Module] = []
    for m in patch.modules:
        if not _is_oscillator(m):
            continue
        try:
            act = float(audio_preview.get_activity(m.id)) \
                if hasattr(audio_preview, 'get_activity') \
                else float(audio_preview._module_activity.get(m.id, 0.0))
        except Exception:
            act = 0.0
        if act < 0.001:
            silent_sources.append(m)
    if silent_sources:
        labels = []
        for m in silent_sources[:5]:
            labels.append(f'{m.god}.{m.kind}')
        more = f' (+{len(silent_sources)-5})' if len(silent_sources) > 5 else ''
        diags.append(Diagnosis(
            severity='warning', code='silent_in_render',
            message=f'{len(silent_sources)} Sound-Quelle(n) zeigen KEINE '
                    f'Aktivität im Probe-Render: {", ".join(labels)}'
                    f'{more}.',
            module_ids=tuple(m.id for m in silent_sources),
            fix_hint='DSP läuft, aber Output ist 0. Mögliche Ursachen: '
                     'gain-Param 0, alle CV-Inputs auf 0 gezogen, ein '
                     'Trigger/Gate-Input fehlt. Klick die einzelnen '
                     'Module an und prüfe ihre Param-Werte.',
        ))
    return diags


# ─── Public API ─────────────────────────────────────────────────────

def diagnose_patch(patch: Patch,
                   audio_preview=None) -> List[Diagnosis]:
    """Hauptfunktion — sammelt alle Diagnosen für einen Patch.

    Reihenfolge der Checks ist wichtig: erst die fundamentalen
    Probleme (kein Master, leerer Patch), dann subtilere
    (orphan-Oszi, gain=0, Mtof-no-trigger). Optional läuft auch
    ein Live-Activity-Check wenn ``audio_preview`` übergeben wird.

    Args:
        patch: der zu prüfende Patch
        audio_preview: optional FluxAudioPreview-Instanz für den
                       Live-Activity-Check (v.242). Wenn None, wird
                       nur die statische Diagnose gefahren.

    Returns:
        Liste von Diagnosis-Objekten, sortiert nach severity
        (error → warning → info), dann in Reihenfolge der Checks.
    """
    diags: List[Diagnosis] = []
    # Fundamentale Checks zuerst — weitere Checks brauchen Patch+Master
    diags.extend(_check_empty_patch(patch))
    if not patch.modules:
        return diags  # früh raus wenn leer
    diags.extend(_check_master_present(patch))
    diags.extend(_check_master_connected(patch))
    diags.extend(_check_oscillators_reach_master(patch))
    diags.extend(_check_zero_gain(patch))
    diags.extend(_check_mtof_unconnected(patch))
    # v.242: optional Live-Activity-Check (braucht Probe-Render)
    if audio_preview is not None:
        diags.extend(_check_live_activity(patch, audio_preview))
    # Sortiere: error vor warning vor info
    severity_order = {'error': 0, 'warning': 1, 'info': 2}
    diags.sort(key=lambda d: severity_order.get(d.severity, 99))
    return diags


def format_diagnosis_summary(diags: List[Diagnosis],
                             max_lines: int = 3) -> str:
    """Formattiert eine kompakte Zusammenfassung für Status-Labels.

    Gibt max die ersten ``max_lines`` Diagnosen zurück, mit
    Severity-Symbolen. Für längere Anzeige gibt's
    format_diagnosis_full().
    """
    if not diags:
        return ''
    sym = {'error': '⚠', 'warning': '⚠', 'info': 'ℹ'}
    lines = []
    for d in diags[:max_lines]:
        lines.append(f'{sym.get(d.severity, "•")} {d.message}')
    extra = len(diags) - max_lines
    if extra > 0:
        lines.append(f'… +{extra} weitere Hinweise')
    return ' / '.join(lines)


def format_diagnosis_full(diags: List[Diagnosis]) -> str:
    """Vollständiger Diagnose-Bericht (mehrzeilig, mit Fix-Hints)."""
    if not diags:
        return '✓ Patch sieht gut aus — keine offensichtlichen Probleme.'
    sym = {'error': '🔴', 'warning': '🟡', 'info': '🔵'}
    lines = []
    for d in diags:
        head = f'{sym.get(d.severity, "•")} [{d.code}] {d.message}'
        lines.append(head)
        if d.fix_hint:
            lines.append(f'   → {d.fix_hint}')
    return '\n'.join(lines)
