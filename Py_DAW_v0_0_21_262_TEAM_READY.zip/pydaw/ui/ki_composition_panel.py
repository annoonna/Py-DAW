"""ki_composition_panel.py — KI-Kompositions-Panel (v0.0.20.987)

KK13: Kompositions-Assistent Panel

PyQt6 Dock Widget for the DAW with:
  - Style browser (epoch tiles)
  - Mix slider (Barock ↔ Jazz)
  - Document drop (PDF/DOCX → analyze)
  - Live preview (generate → play via AETERNA)
  - "Surprise me" button (random style + seed)
  - Song library (save/load generated songs)

Usage:
    # In main_window.py:
    from pydaw.ui.ki_composition_panel import KICompositionPanel
    panel = KICompositionPanel(self)
    self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, panel)
"""

import random
import logging
from typing import Optional

from PyQt6.QtCore import Qt, pyqtSignal, QMimeData, QThread, QTimer
from PyQt6.QtGui import QFont, QDragEnterEvent, QDropEvent
from PyQt6.QtWidgets import (
    QDockWidget, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QComboBox, QSlider, QSpinBox,
    QGroupBox, QFormLayout, QTextEdit, QProgressBar,
    QScrollArea, QGridLayout, QFrame, QFileDialog,
)

log = logging.getLogger(__name__)


class _GenerateWorker(QThread):
    """Background-Thread für Song-Generation (blockiert nicht die UI)."""
    finished = pyqtSignal(object)   # GeneratedSong or None
    error = pyqtSignal(str)
    progress = pyqtSignal(int, str)  # percent, message

    def __init__(self, gen_func, gen_kwargs, parent=None):
        super().__init__(parent)
        self._gen_func = gen_func
        self._gen_kwargs = gen_kwargs

    def run(self):
        try:
            self.progress.emit(20, "Melodie generieren…")
            song = self._gen_func(**self._gen_kwargs)
            self.progress.emit(90, "Tracks aufbauen…")
            self.finished.emit(song)
        except Exception as e:
            self.error.emit(str(e))


class EpochTile(QPushButton):
    """Clickable tile for an epoch style."""

    def __init__(self, epoch_id: str, name: str, era: str, parent=None):
        super().__init__(parent)
        self.epoch_id = epoch_id
        self.setText(f"{name}\n{era}")
        self.setFixedSize(120, 60)
        self.setCheckable(True)
        self.setStyleSheet("""
            QPushButton {
                background: #1a1a2e; color: #e0e0e0; border: 1px solid #333;
                border-radius: 6px; font-size: 10px; padding: 4px;
            }
            QPushButton:checked {
                background: #2d1b4e; border: 2px solid #ff6e40;
            }
            QPushButton:hover { background: #252540; }
        """)


class KICompositionPanel(QDockWidget):
    """KI Composition Assistant — Dock Widget.

    Provides a UI for generating music using the KI composition engine.
    """

    song_generated = pyqtSignal(dict)  # emitted when a song is generated

    def __init__(self, parent=None):
        super().__init__("🎼 KI-Komposition", parent)
        self.setObjectName("kiCompositionPanel")
        self.setAllowedAreas(
            Qt.DockWidgetArea.LeftDockWidgetArea |
            Qt.DockWidgetArea.RightDockWidgetArea
        )
        self.setMinimumWidth(280)

        self._selected_epoch = "rock"
        self._build_ui()

    def _build_ui(self):
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setSpacing(8)

        # ── Title ──
        title = QLabel("🎼 KI-Kompositions-Assistent")
        title.setFont(QFont("", 12, QFont.Weight.Bold))
        title.setStyleSheet("color: #ff6e40;")
        layout.addWidget(title)

        # ── Style Browser ──
        style_group = QGroupBox("Stil wählen")
        style_layout = QVBoxLayout(style_group)

        # Epoch tiles in grid
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setMaximumHeight(200)
        tile_widget = QWidget()
        tile_grid = QGridLayout(tile_widget)
        tile_grid.setSpacing(4)

        self._epoch_tiles = {}
        epochs = [
            ("medieval", "Mittelalter", "800–1400"),
            ("renaissance", "Renaissance", "1400–1600"),
            ("baroque", "Barock", "1600–1750"),
            ("classical", "Klassik", "1750–1820"),
            ("romantic", "Romantik", "1820–1900"),
            ("impressionism", "Impressionismus", "1880–1920"),
            ("jazz", "Jazz", "1900–"),
            ("blues", "Blues", "1870–"),
            ("rock", "Rock/Pop", "1950–"),
            ("electronic", "Electronic", "1970–"),
            ("hiphop", "Hip-Hop", "1980–"),
            ("metal", "Metal", "1970–"),
            ("latin", "Latin", "Salsa/Bossa"),
            ("film", "Filmmusik", "1930–"),
            ("minimalism", "Minimal", "1960–"),
            ("ambient", "Ambient", "1970–"),
        ]
        for i, (eid, name, era) in enumerate(epochs):
            tile = EpochTile(eid, name, era)
            tile.clicked.connect(lambda checked, e=eid: self._on_epoch_selected(e))
            tile_grid.addWidget(tile, i // 4, i % 4)
            self._epoch_tiles[eid] = tile

        # Default selection
        if "rock" in self._epoch_tiles:
            self._epoch_tiles["rock"].setChecked(True)

        scroll.setWidget(tile_widget)
        style_layout.addWidget(scroll)

        # Mix slider
        mix_layout = QHBoxLayout()
        self._mix_label_a = QLabel("Rock")
        self._mix_slider = QSlider(Qt.Orientation.Horizontal)
        self._mix_slider.setRange(0, 100)
        self._mix_slider.setValue(0)
        self._mix_slider.setToolTip("Stil-Mix: links = Stil A, rechts = Stil B")
        self._mix_label_b = QLabel("Jazz")
        mix_layout.addWidget(self._mix_label_a)
        mix_layout.addWidget(self._mix_slider)
        mix_layout.addWidget(self._mix_label_b)
        style_layout.addLayout(mix_layout)

        layout.addWidget(style_group)

        # ── Parameters ──
        param_group = QGroupBox("Parameter")
        param_form = QFormLayout(param_group)

        self._cmb_key = QComboBox()
        for note in ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]:
            self._cmb_key.addItem(note)
        param_form.addRow("Tonart:", self._cmb_key)

        self._cmb_mode = QComboBox()
        for mode in ["major", "minor", "dorian", "mixolydian", "phrygian",
                      "lydian", "aeolian", "harmonic_minor"]:
            self._cmb_mode.addItem(mode)
        param_form.addRow("Modus:", self._cmb_mode)

        self._spin_tempo = QSpinBox()
        self._spin_tempo.setRange(40, 280)
        self._spin_tempo.setValue(120)
        self._spin_tempo.setSuffix(" BPM")
        param_form.addRow("Tempo:", self._spin_tempo)

        self._spin_bars = QSpinBox()
        self._spin_bars.setRange(4, 256)
        self._spin_bars.setValue(32)
        self._spin_bars.setSuffix(" Takte")
        param_form.addRow("Länge:", self._spin_bars)

        self._cmb_method = QComboBox()
        self._cmb_method.addItems(["markov", "fractal", "lsystem", "cantus"])
        param_form.addRow("Methode:", self._cmb_method)

        self._spin_seed = QSpinBox()
        self._spin_seed.setRange(0, 999999)
        self._spin_seed.setValue(0)
        self._spin_seed.setSpecialValueText("Zufällig")
        param_form.addRow("Seed:", self._spin_seed)

        layout.addWidget(param_group)

        # ── Buttons ──
        btn_layout = QHBoxLayout()

        self._btn_generate = QPushButton("🎵 Generieren")
        self._btn_generate.setStyleSheet(
            "QPushButton { background: #ff6e40; color: white; "
            "font-weight: bold; padding: 8px; border-radius: 4px; }"
            "QPushButton:hover { background: #ff8a65; }"
        )
        self._btn_generate.clicked.connect(self._on_generate)
        btn_layout.addWidget(self._btn_generate)

        self._btn_surprise = QPushButton("🎲 Überrasch mich!")
        self._btn_surprise.setStyleSheet(
            "QPushButton { background: #7c4dff; color: white; "
            "padding: 8px; border-radius: 4px; }"
            "QPushButton:hover { background: #b388ff; }"
        )
        self._btn_surprise.clicked.connect(self._on_surprise)
        btn_layout.addWidget(self._btn_surprise)

        layout.addLayout(btn_layout)

        # Mood generator
        mood_layout = QHBoxLayout()
        self._cmb_mood = QComboBox()
        self._cmb_mood.addItems([
            "joy", "sorrow", "peace", "celebration",
            "hope", "mystery", "triumph", "love",
        ])
        self._btn_mood = QPushButton("🎭 Aus Stimmung")
        self._btn_mood.clicked.connect(self._on_generate_from_mood)
        mood_layout.addWidget(self._cmb_mood)
        mood_layout.addWidget(self._btn_mood)
        layout.addLayout(mood_layout)

        # Import button
        self._btn_import = QPushButton("📄 Dokument importieren...")
        self._btn_import.clicked.connect(self._on_import_document)
        layout.addWidget(self._btn_import)

        # Chorale variation
        chorale_layout = QHBoxLayout()
        self._cmb_chorale = QComboBox()
        self._chorale_ids = [
            "ein_feste_burg", "lobe_den_herren", "nun_danket",
            "o_haupt_voll_blut", "stille_nacht", "vom_himmel_hoch",
            "christ_lag", "wachet_auf",
        ]
        self._chorale_titles = [
            "Ein feste Burg (Luther 1529)",
            "Lobe den Herren (Neander 1680)",
            "Nun danket alle Gott (Rinkart 1636)",
            "O Haupt voll Blut (Hassler/Bach)",
            "Stille Nacht (Gruber 1818)",
            "Vom Himmel hoch (Luther 1535)",
            "Christ lag in Todesbanden (Luther)",
            "Wachet auf (Nicolai 1599)",
        ]
        for title in self._chorale_titles:
            self._cmb_chorale.addItem(title)
        self._btn_chorale = QPushButton("📖 Choral-Variation")
        self._btn_chorale.clicked.connect(self._on_chorale_variation)
        chorale_layout.addWidget(self._cmb_chorale)
        chorale_layout.addWidget(self._btn_chorale)
        layout.addLayout(chorale_layout)

        # ── Result ──
        self._result_label = QLabel("")
        self._result_label.setWordWrap(True)
        self._result_label.setStyleSheet("color: #aaa; font-size: 11px;")
        layout.addWidget(self._result_label)

        # ── Progress ──
        self._progress = QProgressBar()
        self._progress.setVisible(False)
        layout.addWidget(self._progress)

        layout.addStretch()
        self.setWidget(container)

        # Enable drag & drop
        container.setAcceptDrops(True)

    # ── Slots ──

    def _on_epoch_selected(self, epoch_id: str):
        # Uncheck all other tiles
        for eid, tile in self._epoch_tiles.items():
            tile.setChecked(eid == epoch_id)
        self._selected_epoch = epoch_id
        self._mix_label_a.setText(epoch_id.title())

    def _on_generate(self):
        """Generate a song in background thread (UI bleibt responsiv)."""
        from pydaw.services.ki_song_generator import SongGenerator
        gen = SongGenerator()

        kwargs = dict(
            style=self._selected_epoch,
            key=self._cmb_key.currentText(),
            mode=self._cmb_mode.currentText(),
            tempo=self._spin_tempo.value(),
            duration_bars=self._spin_bars.value(),
            seed=self._spin_seed.value(),
            method=self._cmb_method.currentText(),
        )
        self._start_generation(gen.generate, kwargs)

    def _start_generation(self, gen_func, gen_kwargs):
        """Start generation in background thread with progress bar."""
        # Disable buttons during generation
        self._btn_generate.setEnabled(False)
        self._btn_surprise.setEnabled(False)
        self._btn_mood.setEnabled(False)
        self._btn_chorale.setEnabled(False)

        # Show progress
        self._progress.setVisible(True)
        self._progress.setRange(0, 100)
        self._progress.setValue(10)
        self._result_label.setText("🎵 Generiere Song…")

        # Animate progress
        self._progress_timer = QTimer(self)
        self._progress_val = 10
        def _tick():
            if self._progress_val < 85:
                self._progress_val += 3
                self._progress.setValue(self._progress_val)
        self._progress_timer.timeout.connect(_tick)
        self._progress_timer.start(100)

        # Start worker thread
        self._worker = _GenerateWorker(gen_func, gen_kwargs, self)
        self._worker.finished.connect(self._on_generation_done)
        self._worker.error.connect(self._on_generation_error)
        self._worker.progress.connect(
            lambda pct, msg: (self._progress.setValue(pct),
                              self._result_label.setText(f"🎵 {msg}"))
        )
        self._worker.start()

    def _on_generation_done(self, song):
        """Called when background generation completes."""
        self._progress_timer.stop()
        self._progress.setValue(95)
        self._result_label.setText("🎹 Tracks in DAW einfügen…")

        # Insert into DAW (quick — runs on main thread)
        self._show_result(song)
        self._insert_song_into_daw(song)

        self._progress.setValue(100)
        QTimer.singleShot(1500, lambda: self._progress.setVisible(False))

        # Re-enable buttons
        self._btn_generate.setEnabled(True)
        self._btn_surprise.setEnabled(True)
        self._btn_mood.setEnabled(True)
        self._btn_chorale.setEnabled(True)

        self.song_generated.emit({
            "title": song.title,
            "tracks": len(song.tracks),
            "style": song.style,
            "key": song.key,
            "tempo": song.tempo,
            "bars": song.duration_bars,
            "seed": song.seed,
        })

    def _on_generation_error(self, error_msg):
        """Called when generation fails."""
        self._progress_timer.stop()
        self._progress.setVisible(False)
        self._result_label.setText(f"❌ Fehler: {error_msg}")
        log.warning("[KI-Panel] Generation failed: %s", error_msg)

        self._btn_generate.setEnabled(True)
        self._btn_surprise.setEnabled(True)
        self._btn_mood.setEnabled(True)
        self._btn_chorale.setEnabled(True)

    def _on_surprise(self):
        """Generate with random parameters (background thread)."""
        epochs = list(self._epoch_tiles.keys())
        epoch = random.choice(epochs)
        self._on_epoch_selected(epoch)

        keys = ["C", "D", "E", "F", "G", "A", "Bb", "Eb"]
        self._cmb_key.setCurrentText(random.choice(keys))

        modes = ["major", "minor", "dorian", "mixolydian"]
        self._cmb_mode.setCurrentText(random.choice(modes))

        self._spin_tempo.setValue(random.randint(60, 180))
        self._spin_seed.setValue(random.randint(1, 999999))
        self._cmb_method.setCurrentText(random.choice(["markov", "fractal", "lsystem"]))

        self._on_generate()

    def _on_generate_from_mood(self):
        """Generate from selected mood (background thread)."""
        from pydaw.services.ki_song_generator import SongGenerator
        gen = SongGenerator()
        mood = self._cmb_mood.currentText()
        kwargs = dict(
            mood=mood,
            duration_bars=self._spin_bars.value(),
            seed=self._spin_seed.value(),
        )
        self._start_generation(gen.generate_from_mood, kwargs)

    def _on_import_document(self):
        """Import — PDF/Bilder → OMR Notenerkennung, MIDI/XML → direkt, Text → Analyse."""
        from pathlib import Path as P

        path, _ = QFileDialog.getOpenFileName(
            self, "Dokument / Notenblatt importieren",
            "", "Alle (*.pdf *.png *.jpg *.jpeg *.tiff *.bmp *.mid *.midi *.xml *.txt *.docx);;"
                "Notenblätter (*.pdf *.png *.jpg *.jpeg *.tiff *.bmp);;"
                "MIDI (*.mid *.midi *.xml);;"
                "Text (*.txt *.docx)",
        )
        if not path:
            return

        ext = P(path).suffix.lower()

        # ── PDF / Bilder → OMR (Notenblatt scannen) ──
        if ext in (".pdf", ".png", ".jpg", ".jpeg", ".tiff", ".tif", ".bmp"):
            self._result_label.setText("📷 Notenblatt wird gescannt…")
            self._progress.setVisible(True)
            self._progress.setRange(0, 0)  # indeterminate
            self._btn_import.setEnabled(False)

            def _do_omr(**_kw):
                from pydaw.services.ki_omr import OMRService
                return OMRService().scan_file(path)

            self._omr_path = path
            self._worker = _GenerateWorker(_do_omr, {}, self)
            self._worker.finished.connect(self._on_omr_done)
            self._worker.error.connect(self._on_generation_error)
            self._worker.start()
            return

        # ── MIDI / MusicXML → Noten direkt laden ──
        if ext in (".mid", ".midi", ".xml", ".musicxml"):
            try:
                from pydaw.services.ki_document_import import import_document
                doc = import_document(path)
                if doc.error:
                    self._result_label.setText(f"⚠️ {doc.error}")
                    return
                if doc.midi_notes:
                    from pydaw.services.ki_song_generator import SongGenerator
                    gen = SongGenerator()
                    kwargs = dict(
                        style=self._selected_epoch,
                        key=self._cmb_key.currentText(),
                        mode=self._cmb_mode.currentText(),
                        tempo=self._spin_tempo.value(),
                        duration_bars=self._spin_bars.value(),
                        seed=self._spin_seed.value(),
                        source_melody=doc.midi_notes[:64],
                    )
                    self._start_generation(gen.generate, kwargs)
            except Exception as e:
                self._result_label.setText(f"❌ {e}")
            return

        # ── Text → Stimmungsanalyse → Song generieren ──
        try:
            from pydaw.services.ki_document_import import import_document
            doc = import_document(path)
            if doc.text:
                from pydaw.services.ki_song_generator import SongGenerator
                gen = SongGenerator()
                kwargs = dict(text=doc.text,
                              duration_bars=self._spin_bars.value(),
                              seed=self._spin_seed.value())
                self._start_generation(gen.generate_from_text, kwargs)
        except Exception as e:
            self._result_label.setText(f"❌ {e}")

    def _on_omr_done(self, result):
        """OMR Scan fertig — Noten in DAW einfügen."""
        from pathlib import Path as P

        self._progress.setVisible(False)
        self._btn_import.setEnabled(True)

        source_path = getattr(self, '_omr_path', 'scan')

        if hasattr(result, 'error') and result.error:
            self._result_label.setText(f"⚠️ OMR: {result.error}")
            return

        if not hasattr(result, 'total_notes') or result.total_notes == 0:
            self._result_label.setText(
                "⚠️ Keine Noten erkannt.\n"
                "• Scan mit höherer Auflösung (300 DPI)\n"
                "• MIDI/MusicXML statt Bild-PDF nutzen"
            )
            return

        # OMR Noten → DAW Track
        try:
            from pydaw.services.ki_song_generator import GeneratedTrack, GeneratedSong
            from pydaw.services.ki_arrangement import SongStructure

            notes = []
            for page in result.pages:
                for note in page.notes:
                    notes.append({
                        "midi": note.midi,
                        "start_beat": note.beat,
                        "duration_beats": note.duration,
                        "velocity": note.velocity,
                    })

            filename = P(source_path).stem
            track = GeneratedTrack(
                name=f"OMR: {filename}",
                instrument="piano",
                notes=notes, role="melody",
            )

            dur_bars = max(4, int(len(notes) / 4) + 1)
            song = GeneratedSong(
                title=f"OMR: {filename}",
                style="scan", key="C major", tempo=120,
                time_signature=(4, 4),
                duration_bars=dur_bars, seed=0,
                tracks=[track],
                structure=SongStructure(
                    title=filename, style="scan",
                    total_bars=dur_bars, sections=[], tempo=120,
                ),
                description=f"OMR: {result.total_notes} Noten",
            )

            self._show_result(song)
            self._insert_song_into_daw(song)

            # Show OMR stats including lyrics, repeats, chords
            extra_info = []
            for page in result.pages:
                lyrics = getattr(page, 'lyrics', [])
                repeats = getattr(page, 'repeats', [])
                chords = getattr(page, 'chords', [])
                if lyrics:
                    extra_info.append(f"📝 Liedtext: {sum(l.get('word_count',0) for l in lyrics)} Wörter")
                if repeats:
                    rtypes = [r['type'] for r in repeats]
                    extra_info.append(f"🔁 Wiederholungen: {len(repeats)} ({', '.join(set(rtypes))})")
                if chords:
                    extra_info.append(f"🎸 Akkord-Regionen: {len(chords)}")

                # Generate preview image
                gray_img = getattr(page, 'gray_image', None)
                if gray_img is not None:
                    try:
                        from pydaw.services.ki_omr import OMRService
                        preview_png = OMRService().generate_preview(gray_img, page)
                        import tempfile, os
                        preview_path = os.path.join(
                            tempfile.gettempdir(), f"omr_preview_p{page.page_number}.png"
                        )
                        with open(preview_path, 'wb') as f:
                            f.write(preview_png)
                        extra_info.append(f"🖼️ Vorschau: {preview_path}")
                    except Exception:
                        pass

            extra = "\n".join(extra_info)
            self._result_label.setText(
                self._result_label.text() +
                f"\n📷 OMR: {result.total_notes} Noten aus "
                f"{len(result.pages)} Seite(n) gescannt"
                + (f"\n{extra}" if extra else "")
            )

        except Exception as e:
            self._result_label.setText(f"❌ OMR: {e}")

    def _on_chorale_variation(self):
        """Scanne Choral → Analysiere → Erzeuge Variation (background thread)."""
        from pydaw.services.ki_song_generator import SongGenerator
        gen = SongGenerator()
        idx = self._cmb_chorale.currentIndex()
        chorale_id = self._chorale_ids[idx] if idx < len(self._chorale_ids) else "ein_feste_burg"
        kwargs = dict(
            chorale_id=chorale_id,
            style=self._selected_epoch,
            seed=self._spin_seed.value(),
            duration_bars=self._spin_bars.value(),
        )
        self._start_generation(gen.generate_from_chorale, kwargs)

    def _show_result(self, song):
        """Display generation result."""
        track_info = ", ".join(f"{t.name}({len(t.notes)})" for t in song.tracks)
        self._result_label.setText(
            f"✅ {song.title}\n"
            f"Stil: {song.style} | {song.key} | {song.tempo} BPM\n"
            f"Tracks: {track_info}\n"
            f"Seed: {song.seed} | Takte: {song.duration_bars}"
        )

    def _insert_song_into_daw(self, song):
        """Insert generated song as real tracks + MIDI clips into the DAW.

        v0.0.20.991: Uses processEvents() to keep UI responsive during insertion.
        """
        try:
            from PyQt6.QtWidgets import QApplication

            project_svc = self._find_project_service()
            if project_svc is None:
                self._result_label.setText(
                    self._result_label.text() + "\n⚠️ Kein Projekt geladen"
                )
                return

            # Set BPM
            try:
                project = project_svc.ctx.project
                if hasattr(project, "bpm"):
                    project.bpm = song.tempo
                elif hasattr(project, "tempo_bpm"):
                    project.tempo_bpm = song.tempo
            except Exception:
                pass

            created_tracks = 0
            created_notes = 0

            for gen_track in song.tracks:
                if not gen_track.notes:
                    continue

                # Create track
                track = project_svc.add_track(
                    kind="instrument",
                    name=f"🎼 {gen_track.name} ({song.style})",
                )
                track_id = str(track.id)

                # Clip length
                max_beat = max(
                    (n.get("start_beat", 0) + n.get("duration_beats", 1))
                    for n in gen_track.notes
                ) if gen_track.notes else 4.0
                clip_length = max(4.0, max_beat)

                # Create MIDI clip
                clip_id = project_svc.add_midi_clip_at(
                    track_id=track_id, start_beats=0.0,
                    length_beats=clip_length,
                    label=f"KI: {gen_track.name}",
                )

                # Batch-add notes (processEvents every 50 notes)
                notes_list = project_svc.ctx.project.midi_notes.get(clip_id, [])
                from pydaw.model.midi import MidiNote

                for i, nd in enumerate(gen_track.notes):
                    try:
                        note = MidiNote(
                            pitch=max(0, min(127, int(nd.get("midi", 60)))),
                            start_beats=float(nd.get("start_beat", 0)),
                            length_beats=max(0.0625, float(nd.get("duration_beats", 1.0))),
                            velocity=max(1, min(127, int(nd.get("velocity", 100)))),
                        )
                        notes_list.append(note)
                        created_notes += 1
                    except Exception:
                        continue

                    # Keep UI alive every 100 notes
                    if i % 100 == 99:
                        QApplication.processEvents()

                project_svc.ctx.project.midi_notes[clip_id] = notes_list
                created_tracks += 1
                QApplication.processEvents()

            # Refresh arranger UI to show new tracks + clips
            try:
                main_win = self._find_main_window()
                if main_win:
                    # Emit project changed
                    if hasattr(project_svc, "project_changed"):
                        project_svc.project_changed.emit()
                    # Force arranger redraw
                    arranger = getattr(main_win, "arranger", None)
                    if arranger:
                        arranger.update()
                        canvas = getattr(arranger, "canvas", None)
                        if canvas:
                            canvas.update()
            except Exception:
                pass

            self._result_label.setText(
                self._result_label.text() +
                f"\n🎹 {created_tracks} Tracks, {created_notes} Noten eingefügt!"
            )

        except Exception as e:
            log.warning("[KI-Panel] Insert failed: %s", e)
            self._result_label.setText(
                self._result_label.text() + f"\n⚠️ Insert: {e}"
            )

    def _find_project_service(self):
        """Find the ProjectService via the parent MainWindow."""
        try:
            main_win = self._find_main_window()
            if main_win is None:
                return None
            # Try various paths to find the project service
            svc = getattr(main_win, "services", None)
            if svc:
                ps = getattr(svc, "project", None)
                if ps:
                    return ps
            # Direct attribute
            ps = getattr(main_win, "_bound_project_service", None)
            if ps:
                return ps
            ps = getattr(main_win, "project_service", None)
            if ps:
                return ps
        except Exception:
            pass
        return None

    def _find_main_window(self):
        """Walk up the parent chain to find MainWindow."""
        widget = self.parent()
        while widget is not None:
            if hasattr(widget, "menuBar") and hasattr(widget, "services"):
                return widget
            widget = widget.parent() if hasattr(widget, "parent") else None
        return None
