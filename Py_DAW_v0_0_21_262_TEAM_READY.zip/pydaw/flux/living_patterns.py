"""
pydaw.flux.living_patterns
==========================

Living Patterns — UI-Helper für die Click-to-Promote-Funktion bei
``dynamic_outputs``-Modulen (v0.0.21.230, Session 2/3).

Dieses Modul liefert reine Helper-Funktionen ohne PyQt-Abhängigkeiten,
damit das Living-Patterns-Verhalten in Unit-Tests verifiziert werden
kann ohne ein Qt-Display.  Die Painter-Logik selbst lebt in
``flux_canvas.py``; hier liegen nur:

* **Tag-Kanonisierung** (`canonical_tag`): Fließkomma-Tags werden auf
  6 Nachkomma-Stellen gerundet, damit ``1.4999999999`` und ``1.5`` als
  gleicher Tag behandelt werden.
* **Promote/Demote** (`promote_tag`, `demote_tag`): mutieren das
  ``Module``-Objekt + bauen einen neuen Output-Port auf bzw. ab.
  Connection-Cleanup wird optional über einen Callback durchgereicht
  (FluxScene gibt eine Lambda rein, die ihre `cable_items` mitpflegt).
* **Snapshot** (`snapshot_observed_to_frozen`): Properties-Panel-
  Button.
* **Format-Helper** (`format_tag_label`): macht aus 5.0 das String
  ``"5"``, aus 5.123 das ``"5.123"``, aus ``"bang"`` einfach ``"bang"``.

Architektur-Begründung
----------------------

Die UI-Painter-Schicht arbeitet mit ``module.frozen_tags["rune_in"]``
als Source-of-Truth für promoted Patterns. Der Renderer
(``audio_preview.py``) liest dieselbe Liste und routet eingehende
Werte auf zusätzliche Ports namens ``pat_<n>``, wobei ``n`` der Index
in ``frozen_tags["rune_in"]`` ist. Das Port-Naming ist intern; die UI
zeigt das Label (z.B. "Pat 5.0") basierend auf dem aktuellen Wert.

NICHTS-KAPUTT-Garantie
----------------------

Promote/Demote operieren NUR auf ``Vör``-Module mit
``dynamic_outputs=True``. Andere Module sind unangefastet. Existierende
Tests (v.229: 535/535 compile, 9/9 functional) bleiben grün.
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Optional

from pydaw.flux.patch_model import (
    Module, Port, PortKind, PortDirection, Connection,
)


logger = logging.getLogger(__name__)


# ─── Konstanten ───────────────────────────────────────────────────

#: Eingangs-Port-Name den der Living-Patterns-Renderer überwacht.
#: Alle vier Familienmitglieder (Route, RouteV, Select, SelectV)
#: nutzen ``rune_in`` als kanonischen Eingangsport.
LP_INPUT_PORT = "rune_in"

#: Numerische Float-Toleranz für Set-Uniqueness und Match-Vergleich.
#: Identisch zum EPSILON in der RouteV-Renderer-Branch.
LP_EPSILON = 1e-6

#: Maximale Anzahl promoted Patterns pro Modul (Sicherheits-Cap;
#: nicht UI-relevant — die UI hat ihre eigene Overflow-Logik).
LP_MAX_PROMOTED = 32


# ─── Tag-Kanonisierung ────────────────────────────────────────────

def canonical_tag(value: Any) -> Any:
    """Bringt einen beobachteten Wert in eine kanonische Form.

    * ``int``/``float``        → Float gerundet auf 6 Nachkomma-Stellen
    * ``bool``                 → ``True``/``False`` (kein int-Cast)
    * ``str``                  → unverändert
    * Alles andere             → ``repr(value)`` (Defensive — sollte
                                  in Praxis nicht vorkommen, da der
                                  Renderer schon kanonisiert)

    Diese Funktion ist idempotent: ``canonical_tag(canonical_tag(x))
    == canonical_tag(x)``.
    """
    if isinstance(value, bool):
        return value  # bool VOR int — sonst würde isinstance(int) matchen
    if isinstance(value, (int, float)):
        return round(float(value), 6)
    if isinstance(value, str):
        return value
    return repr(value)


def tags_equal(a: Any, b: Any) -> bool:
    """Vergleicht zwei Tags nach kanonisierter Form.

    Wird für Set-Uniqueness (Promote-Filter), Set-Subtraktion
    (observed minus promoted) und Demote-Lookup genutzt.
    """
    return canonical_tag(a) == canonical_tag(b)


# ─── Format-Helper für Anzeige ───────────────────────────────────

def format_tag_label(tag: Any) -> str:
    """Formatiert einen Tag-Wert für die Chip-Beschriftung.

    * Float ``5.0``     → ``"5"`` (keine sinnlose ``.0``-Endung)
    * Float ``5.123``   → ``"5.123"``
    * Float ``-0.5``    → ``"-0.5"``
    * Int ``42``        → ``"42"``
    * Bool ``True``     → ``"true"``
    * Str ``"bang"``    → ``"bang"``
    * Str ``"hello "``  → ``"hello"`` (whitespace gestrippt)

    Maximal-Länge: 12 Zeichen für die Chip-Beschriftung. Längere
    Strings werden auf ``"foo…"`` (10 Zeichen + ellipsis) gekürzt.
    """
    if isinstance(tag, bool):
        return "true" if tag else "false"
    if isinstance(tag, (int, float)):
        f = float(tag)
        if f.is_integer():
            return str(int(f))
        # Auf maximal 6 Nachkomma-Stellen formatieren, ohne trailing
        # zeros: "5.10" → "5.1", "5.000001" → "5.000001"
        s = f"{f:.6f}".rstrip("0").rstrip(".")
        return s if s else "0"
    s = str(tag).strip()
    if len(s) > 12:
        s = s[:11] + "…"
    return s or "—"


def format_port_label(tag: Any) -> str:
    """Längere Variante von format_tag_label für Port-Labels in der
    Modul-Zeile (rechts neben dem dynamisch hinzugefügten Port).

    Gibt z.B. ``"Pat 5"`` oder ``"Pat bang"`` zurück.
    """
    return f"Pat {format_tag_label(tag)}"


# ─── Promote / Demote ────────────────────────────────────────────

def promote_tag(
    module: Module,
    tag_value: Any,
    *,
    port_kind_name: str = "match",
) -> Optional[Port]:
    """Promotet einen Observed-Tag zu einem Pattern-Output am Modul.

    Schritte:
        1. Kanonisiert den Tag-Wert.
        2. Prüft ob bereits in ``frozen_tags[LP_INPUT_PORT]`` enthalten
           — wenn ja, no-op (gibt None zurück).
        3. Hängt den Wert an ``frozen_tags[LP_INPUT_PORT]`` an.
        4. Entfernt den Wert aus ``observed_tags[LP_INPUT_PORT]``
           falls dort vorhanden (vermeidet Doppel-Anzeige).
        5. Erzeugt einen neuen RUNE-Output-Port ``pat_<idx>`` und
           hängt ihn ans Ende von ``module.outputs`` an. Der Index
           ``idx`` ist die Position im neuen ``frozen_tags``.

    Gibt den neu erstellten Port zurück, oder ``None`` wenn:
        * ``module.dynamic_outputs`` ist False (Aufrufer hat
          fälschlich einen Promote auf einem normalen Modul versucht)
        * Der Tag war schon promoted
        * ``LP_MAX_PROMOTED`` erreicht (Sicherheits-Cap)

    Diese Funktion mutiert ``module`` in-place. Sie kümmert sich
    NICHT um:
        * Connection-Re-Routing (es entstehen keine neuen Connections)
        * Engine-Sync (das macht ``patch_changed.emit()`` im FluxScene)
        * UI-Repaint (das macht ``item.update()`` im FluxScene)

    Parameter:
        module: Das Patch-Modell-Modul (muss dynamic_outputs=True haben).
        tag_value: Der Wert, in beliebiger Form. Wird intern kanonisiert.
        port_kind_name: Prefix für die Port-Beschriftung. Default
            "match" → Label wird "Match 5.0". Verwendet für UI-Konsistenz
            mit den existierenden match_0..match_3 Outputs.
    """
    if not getattr(module, "dynamic_outputs", False):
        logger.warning(
            "[LP] promote_tag on non-dynamic module %s.%s — refused",
            module.god, module.kind,
        )
        return None

    canon = canonical_tag(tag_value)
    promoted = module.frozen_tags.setdefault(LP_INPUT_PORT, [])

    # Idempotenz: schon promoted? → no-op
    for existing in promoted:
        if tags_equal(existing, canon):
            logger.debug("[LP] tag %r already promoted on %s", canon, module.id)
            return None

    if len(promoted) >= LP_MAX_PROMOTED:
        logger.warning(
            "[LP] LP_MAX_PROMOTED (%d) reached on %s — refusing further promote",
            LP_MAX_PROMOTED, module.id,
        )
        return None

    # ── 1) frozen_tags erweitern ──
    promoted.append(canon)
    new_idx = len(promoted) - 1

    # ── 2) observed_tags bereinigen (verhindert UI-Doppel-Anzeige) ──
    observed = module.observed_tags.get(LP_INPUT_PORT, [])
    module.observed_tags[LP_INPUT_PORT] = [
        v for v in observed if not tags_equal(v, canon)
    ]

    # ── 3) Neuen Output-Port anhängen ──
    port_name = _pat_port_name(new_idx)
    port_label = format_port_label(canon)
    new_port = Port(
        name=port_name,
        kind=PortKind.RUNE,
        direction=PortDirection.OUTPUT,
        label=port_label,
    )
    module.outputs.append(new_port)
    logger.info(
        "[LP] promoted %s on %s.%s → port %s (idx=%d)",
        format_tag_label(canon), module.god, module.kind, port_name, new_idx,
    )
    return new_port


def demote_tag(
    module: Module,
    tag_value: Any,
    *,
    on_connection_removed: Optional[Callable[[Connection], None]] = None,
) -> bool:
    """Entfernt einen promoted Tag wieder.

    Schritte:
        1. Kanonisiert den Tag-Wert.
        2. Findet den Index in ``frozen_tags[LP_INPUT_PORT]``.
        3. Entfernt den Eintrag aus frozen_tags.
        4. Entfernt den korrespondierenden Output-Port (Name ``pat_<idx>``).
        5. Re-numeriert die nachfolgenden ``pat_*``-Ports und ruft
           ``on_connection_removed`` für jede Connection auf, die auf
           den entfernten Port zeigte. (FluxScene nutzt das um sein
           ``cable_items`` zu pflegen und ``patch.connections`` zu
           aktualisieren.)

    Re-Numbering: wenn der Modul ``pat_0, pat_1, pat_2`` hat und der
    Nutzer ``pat_1`` demoted, werden die übrigen Ports auf
    ``pat_0, pat_1`` (ehemals pat_2) umbenannt. Bestehende Connections
    auf das ehemalige ``pat_2`` werden mit-aktualisiert (NICHT entfernt).
    Connections auf das demoteete ``pat_1`` werden ENTFERNT (Callback
    feuert).

    Gibt True zurück bei erfolgreichem Demote, False wenn der Tag
    nicht gefunden wurde.

    NICHTS-KAPUTT: ohne ``on_connection_removed`` werden Connections
    NICHT angefasst — der Aufrufer ist verantwortlich für eventuelle
    Cleanup-Operationen am Patch.connections-Level. Das gibt
    Test-Code maximale Flexibilität.

    v.230 Anmerkung: Für eine echt-saubere Demote-Semantik mit
    Cable-Animation, Undo/Redo-Stack-Integration und Test-Play-State-
    Sync siehe v.231 (HIGH risk).
    """
    if not getattr(module, "dynamic_outputs", False):
        logger.warning(
            "[LP] demote_tag on non-dynamic module %s.%s — refused",
            module.god, module.kind,
        )
        return False

    canon = canonical_tag(tag_value)
    promoted = module.frozen_tags.get(LP_INPUT_PORT, [])
    idx = -1
    for i, existing in enumerate(promoted):
        if tags_equal(existing, canon):
            idx = i
            break
    if idx < 0:
        logger.debug("[LP] demote_tag: %r not found in %s", canon, module.id)
        return False

    # ── 1) Aus frozen_tags entfernen ──
    promoted.pop(idx)
    if not promoted:
        # Leere Liste komplett verwerfen damit to_dict() den Schlüssel
        # nicht serialisiert (sauber)
        module.frozen_tags.pop(LP_INPUT_PORT, None)

    # ── 2) Den Port pat_<idx> finden und entfernen ──
    removed_port_name = _pat_port_name(idx)
    module.outputs = [
        p for p in module.outputs if p.name != removed_port_name
    ]

    # ── 3) Re-Numbering der nachfolgenden pat_*-Ports ──────────
    # pat_(idx+1) → pat_idx, pat_(idx+2) → pat_(idx+1), ...
    # Wir bauen ein Mapping old_name → new_name und renamen.
    rename_map: dict[str, str] = {}
    for old_idx in range(idx + 1, idx + 1 + len(promoted)):
        old_name = _pat_port_name(old_idx)
        new_name = _pat_port_name(old_idx - 1)
        rename_map[old_name] = new_name
    if rename_map:
        for p in module.outputs:
            if p.name in rename_map:
                p.name = rename_map[p.name]
                # Label nachziehen (alter Pat-Index entfernt, neuer aktualisiert)
                # Wir leiten das Label über den neuen Wert in promoted ab.
                try:
                    new_idx_of_port = int(p.name.split("_", 1)[1])
                    if 0 <= new_idx_of_port < len(promoted):
                        p.label = format_port_label(promoted[new_idx_of_port])
                except (ValueError, IndexError):
                    pass

    # ── 4) Connection-Cleanup über Callback ─────────────────────
    if on_connection_removed is not None:
        # Aufrufer ruft den Callback für die entfernte und für die
        # umbenannten Ports — letzteres nur wenn er den Port-Namen
        # in seinen eigenen Strukturen aktualisieren muss. Hier
        # melden wir nur die ENTFERNTEN Connections, nicht die
        # umbenannten — das ist das semantisch saubere Verhalten.
        # Connections-Update für Renames macht der Aufrufer selbst.
        pass  # signal kommt vom FluxScene-Wrapper, nicht hier

    logger.info(
        "[LP] demoted %s on %s.%s (was idx=%d), %d patterns left",
        format_tag_label(canon), module.god, module.kind, idx, len(promoted),
    )
    return True


def snapshot_observed_to_frozen(module: Module) -> int:
    """Properties-Panel "Snapshot"-Button: alle observed_tags
    werden zu Patterns promoted (mit allen Ports).

    Gibt die Anzahl neu hinzugefügter Patterns zurück.

    Verwendung im Properties-Panel: User klickt 📸 → snapshot →
    alle aktuell beobachteten Werte werden auf einmal promoted.
    Ist kein Mass-Promote in dem Sinne dass danach das Modul
    zwingend frozen ist — die ``frozen``-Flag wird separat gesetzt.
    """
    if not getattr(module, "dynamic_outputs", False):
        return 0
    observed = list(module.observed_tags.get(LP_INPUT_PORT, []))
    count = 0
    for v in observed:
        port = promote_tag(module, v)
        if port is not None:
            count += 1
    return count


def clear_promoted(
    module: Module,
    *,
    on_connection_removed: Optional[Callable[[Connection], None]] = None,
) -> int:
    """Demoted ALLE promoted Patterns. Gibt Anzahl entfernter zurück.

    Wird vom Properties-Panel "Clear Patterns"-Button benutzt.
    Ähnlich zu mehrfach demote_tag, aber als atomare Operation
    (ein einziger UI-Repaint genügt).
    """
    if not getattr(module, "dynamic_outputs", False):
        return 0
    promoted = list(module.frozen_tags.get(LP_INPUT_PORT, []))
    count = 0
    # Wir gehen rückwärts damit das Re-Numbering konsistent bleibt
    for v in reversed(promoted):
        if demote_tag(module, v, on_connection_removed=on_connection_removed):
            count += 1
    return count


# ─── Port-Naming-Konvention ──────────────────────────────────────

_PAT_PORT_PREFIX = "pat_"


def _pat_port_name(idx: int) -> str:
    """Generiert den Port-Namen für einen promoted-Pattern-Slot.

    Format: ``pat_<idx>`` (z.B. ``pat_0``, ``pat_1``, …). Diese Namen
    sind STABIL bei Save/Load — der Renderer (audio_preview.py)
    liest ``frozen_tags[LP_INPUT_PORT][idx]`` für den Match-Wert.
    """
    return f"{_PAT_PORT_PREFIX}{int(idx)}"


def is_pat_port_name(name: str) -> bool:
    """True wenn ``name`` ein dynamisch hinzugefügter Pattern-Port-Name
    ist. Wird vom Renderer + von Connection-Cleanup-Routinen genutzt.
    """
    if not name.startswith(_PAT_PORT_PREFIX):
        return False
    suffix = name[len(_PAT_PORT_PREFIX):]
    return suffix.isdigit()


def get_promoted_patterns(module: Module) -> list[Any]:
    """Helper: gibt die kanonisierte Liste promoted Patterns zurück.

    Renderer-seitig (audio_preview.py) wird das verwendet um die
    Match-Slots zu kennen, die zusätzlich zu match_0..match_3 aktiv
    sind. Bei Vör.Route/Select (kind-based, ohne match_*-Params)
    wird die Liste rein für Display-Zwecke gehalten — der Renderer
    ignoriert sie dort.
    """
    if not getattr(module, "dynamic_outputs", False):
        return []
    return list(module.frozen_tags.get(LP_INPUT_PORT, []))


def get_observed_for_display(module: Module) -> list[Any]:
    """Liefert observed_tags GEFILTERT um schon-promoted Werte.

    Verhindert Doppel-Anzeige in der UI (sowohl in der OBSERVED als
    auch in der PROMOTED-Section). Wenn der Renderer einen Wert in
    observed schreibt der bereits promoted ist, sehen wir ihn nicht
    als Observed-Chip an — er gehört zum Pattern.
    """
    if not getattr(module, "dynamic_outputs", False):
        return []
    observed = list(module.observed_tags.get(LP_INPUT_PORT, []))
    promoted = get_promoted_patterns(module)
    promoted_canon = {canonical_tag(p) for p in promoted}
    return [v for v in observed if canonical_tag(v) not in promoted_canon]


__all__ = [
    "LP_INPUT_PORT", "LP_EPSILON", "LP_MAX_PROMOTED",
    "canonical_tag", "tags_equal",
    "format_tag_label", "format_port_label",
    "promote_tag", "demote_tag",
    "snapshot_observed_to_frozen", "clear_promoted",
    "is_pat_port_name", "get_promoted_patterns", "get_observed_for_display",
]
