"""Sandbox Mixin — Extracted from main_window.py (v0.0.20.906).

Contains plugin sandbox handlers: toggle, monitor start/stop, status polling,
restart-all, status dialog, crash log dialog, plugin blacklist dialog.

Self-contained: only references self.statusBar(), self.mixer,
self._sandbox_status, self._sandbox_timer, self._crash_log,
SettingsKeys, set_value — all provided by MainWindow.

~180 lines extracted.
"""

from __future__ import annotations

import logging

log = logging.getLogger(__name__)


class SandboxMixin:
    """Plugin sandbox handlers — mixed into MainWindow."""

    def _toggle_plugin_sandbox(self, checked: bool) -> None:
        """Toggle plugin sandbox (crash-safe subprocess hosting)."""
        checked = bool(checked)
        try:
            from pydaw.core.settings import SettingsKeys
            from pydaw.core.settings_store import set_value
            set_value(SettingsKeys.audio_plugin_sandbox_enabled, checked)
        except Exception:
            pass

        try:
            if checked:
                self.statusBar().showMessage(
                    "🛡️ Plugin Sandbox: AN — Plugins werden crash-sicher geladen (beim nächsten Laden)", 3000
                )
                self._start_sandbox_monitor()
            else:
                self.statusBar().showMessage(
                    "Plugin Sandbox: AUS — Plugins laufen im Hauptprozess", 3000
                )
                self._stop_sandbox_monitor()
        except Exception:
            pass

    # ── v0.0.20.702: Sandbox Status Monitor ────────────────────────────────

    def _start_sandbox_monitor(self) -> None:
        """Start periodic sandbox status polling (2 Hz)."""
        # v0.0.20.704: Initialize crash log
        if not hasattr(self, '_crash_log') or self._crash_log is None:
            try:
                from pydaw.ui.crash_indicator_widget import CrashLog
                self._crash_log = CrashLog()
            except Exception:
                self._crash_log = None

        # v0.0.20.704: Wire crash callback to log entries
        try:
            from pydaw.services.sandbox_process_manager import get_process_manager
            mgr = get_process_manager()
            if self._crash_log is not None:
                def _on_crash(track_id, slot_id, error_msg,
                              crash_log=self._crash_log):
                    try:
                        from pydaw.ui.crash_indicator_widget import CrashLogEntry
                        entry = CrashLogEntry(
                            track_id=track_id, slot_id=slot_id,
                            error_message=error_msg)
                        crash_log.add(entry)
                    except Exception:
                        pass
                mgr.set_crash_callback(_on_crash)
        except Exception:
            pass

        if not hasattr(self, '_sandbox_timer') or self._sandbox_timer is None:
            from PyQt6.QtCore import QTimer
            self._sandbox_timer = QTimer(self)
            self._sandbox_timer.setInterval(500)  # 2 Hz
            self._sandbox_timer.timeout.connect(self._poll_sandbox_status)
        if not self._sandbox_timer.isActive():
            self._sandbox_timer.start()

    def _stop_sandbox_monitor(self) -> None:
        """Stop sandbox status polling."""
        if hasattr(self, '_sandbox_timer') and self._sandbox_timer is not None:
            self._sandbox_timer.stop()
        # Hide status widget
        if hasattr(self, '_sandbox_status') and self._sandbox_status is not None:
            self._sandbox_status.setVisible(False)

    def _poll_sandbox_status(self) -> None:
        """Poll sandbox process manager and update statusbar + mixer strips."""
        try:
            from pydaw.services.sandbox_process_manager import get_process_manager
            mgr = get_process_manager()
            status_list = mgr.get_all_status()
            if not status_list:
                if hasattr(self, '_sandbox_status') and self._sandbox_status:
                    self._sandbox_status.update_status(0, 0, 0)
                return

            total = len(status_list)
            crashed = sum(1 for s in status_list if s.get("crashed", False))
            alive = sum(1 for s in status_list if s.get("alive", False))

            if hasattr(self, '_sandbox_status') and self._sandbox_status:
                self._sandbox_status.update_status(total, crashed, alive)

            # v0.0.20.704: Update mixer strips with crash state
            try:
                mixer = getattr(self, 'mixer', None)
                if mixer is not None and hasattr(mixer, '_strips'):
                    # Build map: track_id → status
                    crash_map = {}
                    for s in status_list:
                        tid = s.get("track_id", "")
                        if not tid:
                            continue
                        if s.get("crashed", False):
                            crash_map[tid] = ("crashed", s.get("error", ""),
                                              s.get("crash_count", 0))
                        elif s.get("alive", False):
                            crash_map[tid] = ("running", "", 0)
                        else:
                            crash_map[tid] = ("disabled", s.get("error", ""), 0)

                    for tid, strip in mixer._strips.items():
                        if tid in crash_map:
                            state, err, cc = crash_map[tid]
                            if hasattr(strip, 'set_sandbox_state'):
                                strip.set_sandbox_state(state, err, cc)
                        else:
                            if hasattr(strip, 'set_sandbox_state'):
                                strip.set_sandbox_state("hidden")
            except Exception:
                pass
        except Exception:
            pass

    # ── v0.0.20.704: Sandbox Dialog Handlers (P6C) ────────────────────────

    def _on_sandbox_restart_all(self) -> None:
        """Restart all sandboxed plugin workers."""
        try:
            from pydaw.services.sandbox_process_manager import get_process_manager
            mgr = get_process_manager()
            status_list = mgr.get_all_status()
            count = 0
            for s in status_list:
                tid = s.get("track_id", "")
                sid = s.get("slot_id", "")
                if tid and sid:
                    mgr.restart(tid, sid)
                    count += 1
            self.statusBar().showMessage(
                f"🔄 {count} Plugin-Worker werden neu gestartet…", 3000)
        except Exception as e:
            self.statusBar().showMessage(f"Fehler: {e}", 3000)

    def _on_sandbox_status_dialog(self) -> None:
        """Open the Sandbox Status Dialog (P6C)."""
        try:
            from pydaw.ui.sandbox_status_dialog import SandboxStatusDialog
            dlg = SandboxStatusDialog(parent=self)
            dlg.show()
        except Exception as e:
            self.statusBar().showMessage(f"Sandbox-Status Fehler: {e}", 3000)

    def _on_crash_log_dialog(self) -> None:
        """Open the Crash Log Dialog (P6B/P6C)."""
        try:
            from pydaw.ui.sandbox_status_dialog import CrashLogDialog
            crash_log = getattr(self, '_crash_log', None)
            if crash_log is None:
                try:
                    from pydaw.ui.crash_indicator_widget import CrashLog
                    self._crash_log = CrashLog()
                    crash_log = self._crash_log
                except Exception:
                    pass
            dlg = CrashLogDialog(crash_log=crash_log, parent=self)
            dlg.show()
        except Exception as e:
            self.statusBar().showMessage(f"Crash-Log Fehler: {e}", 3000)

    def _on_plugin_blacklist_dialog(self) -> None:
        """Open the Plugin Blacklist Dialog (v0.0.20.725)."""
        try:
            from pydaw.ui.plugin_blacklist_dialog import PluginBlacklistDialog
            dlg = PluginBlacklistDialog(parent=self)
            dlg.exec()
        except Exception as e:
            self.statusBar().showMessage(f"Blacklist-Dialog Fehler: {e}", 3000)
