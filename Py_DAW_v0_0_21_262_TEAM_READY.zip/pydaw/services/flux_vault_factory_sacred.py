"""
pydaw.services.flux_vault_factory_sacred — V-1+ Sacred-Style Factory-Presets

**v0.0.21.199 — Sacred v2 (Charakter-Edition)**
================================================

Zweite Iteration der Sacred-Pilot-Presets nach Annos Live-Test:

> *„jedes preset klingt gleich"*

Diagnose: in v.197 hatten alle Presets das gleiche Schema —
Oszillator → optional Filter → Iduna.Reverb mit Mix 0.5-0.7 → MasterOut.
Bei so dominantem Reverb-Tail klingt alles weichgespült verwaschen,
und die Frequenz-Unterschiede zwischen den Presets sind irrelevant
weil der MIDI-Note-Input die `freq`-Default-Werte überschreibt.

v2-Strategie
------------

Jeder Preset bekommt ein **einzigartiges Charakter-Modul**, das ihn
unverwechselbar macht. Reverb-Mix wird moderat (0.25-0.45 typisch)
außer bei Cathedral und Sancta-Sanctorum wo der Reverb als Charakter
gewollt ist.

| Preset            | Charakter-Modul             | Klang-Identität |
|-------------------|------------------------------|-----------------|
| Vesper            | Skadi.Chorus (warm, langsam) | weicher Schimmer-Pad |
| Matins            | Forseti.Tilt (heller)        | klare Mid-Höhen |
| Compline          | Skadi.Phaser                 | mystische Bewegung |
| Te Deum           | Thor.TubeDrive + Vidar.Comp  | warmer Tube-Punch |
| Hymnal-Pad        | Stereo Saw L + Triangle R + Chorus | gemischter Stereo-Akkord |
| Choir-Drone       | Loki.LFO (DEEP) + Skadi.Phaser | atmend pulsierend |
| Pipe-Organ        | Bandpass-Resonance + Thor.Saturation | aggressive reedy Schärfe |
| Bell-Tower        | Stereo-Harmonie + Fenrir.BitCrush | metallisch perkussiv |
| Cathedral         | Skadi.StereoImager + Max-Reverb | extrem weiter Raum |
| Stained-Glass     | Fenrir.BitCrush HARD + Skadi.Phaser | kristallin schimmernd |
| Incense           | LFO HARD auf Cutoff + Skadi.Flanger | dramatischer Sweep |
| Sancta-Sanctorum  | Sub-Bass 65Hz + Stereo-Phaser + Max-Reverb | tief unendlich |

Versionsverwaltung
------------------

Sacred v2 nutzt einen **Author-Marker** ``"FLUX Factory (Sacred v2)"``
zur Versionserkennung. Beim DB-Seed prüft ``_seed_factory_presets_if_empty``
ob 12 Presets mit DIESEM Marker existieren — wenn nicht, werden alle
alten ``is_factory=1, style='sacred'`` Einträge gelöscht und durch v2
ersetzt. User-Patches (``is_factory=0``) bleiben unangetastet.
"""

from __future__ import annotations

import logging
from typing import Optional

logger = logging.getLogger(__name__)


# Versions-Marker — wenn der Author-String hier nicht passt, re-seedet
# der DB-Service alle Sacred-Presets neu. Das stellt sicher dass User
# auf ein Update mit überarbeiteten Presets bekommen.
SACRED_FACTORY_VERSION = "v2"
SACRED_FACTORY_AUTHOR = f"FLUX Factory (Sacred {SACRED_FACTORY_VERSION})"


# ─── Helper ───────────────────────────────────────────────────────


def _connect(patch, src_id: str, src_port: str,
             tgt_id: str, tgt_port: str) -> bool:
    """Helper: Connection hinzufügen, defensiv gegen fehlende Module."""
    from pydaw.flux.patch_model import Connection
    src = patch.get_module(src_id)
    tgt = patch.get_module(tgt_id)
    if src is None or tgt is None:
        return False
    return patch.add_connection(Connection(
        source_module=src_id, source_port=src_port,
        target_module=tgt_id, target_port=tgt_port,
    ))


def _set(module, **params) -> None:
    """Helper: Module-Params setzen (defensiv gegen fehlende Keys)."""
    if module is None:
        return
    for k, v in params.items():
        if k in module.params:
            module.params[k] = v


def _build_patch_dict(name: str, builder) -> Optional[dict]:
    """Wrappt einen Patch-Builder in to_dict, defensiv gegen Fehler."""
    try:
        from pydaw.flux.patch_model import Patch
        p = builder()
        if not isinstance(p, Patch):
            return None
        p.name = name
        return p.to_dict()
    except Exception as e:
        logger.warning("[SacredPresets-v2] build %s failed: %s", name, e)
        return None


# ─── Patch-Builder pro Variant (Sacred v2) ────────────────────────


def _build_vesper():
    """Vesper — Sine + Skadi.Chorus + sanfter Reverb (warmer Abend-Pad).

    Charakter: warmer Chorus-Schimmer, NICHT reverb-dominiert.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_sine_osc, make_skadi_chorus, make_iduna_reverb,
        make_heimdall_master_out,
    )
    p = Patch(name="Vesper")
    osc = make_bragi_sine_osc(); osc.position = (80, 200)
    _set(osc, freq=220.0, gain=0.5)
    chorus = make_skadi_chorus(); chorus.position = (300, 200)
    _set(chorus, rate=0.4, depth=0.7, mix=0.6)
    rev = make_iduna_reverb(); rev.position = (520, 200)
    _set(rev, room_size=0.7, damping=0.4, mix=0.4)
    out = make_heimdall_master_out(); out.position = (740, 200)
    for m in (osc, chorus, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", chorus.id, "audio_in")
    _connect(p, chorus.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_matins():
    """Matins — Triangle + Forseti.Tilt + kurzer Reverb (heller Morgen).

    Charakter: helle Mid-Höhen-Anhebung durch Tilt, klar und brillant.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_triangle_osc, make_forseti_tilt,
        make_iduna_reverb, make_heimdall_master_out,
    )
    p = Patch(name="Matins")
    osc = make_bragi_triangle_osc(); osc.position = (80, 200)
    _set(osc, freq=330.0, gain=0.55)
    tilt = make_forseti_tilt(); tilt.position = (300, 200)
    _set(tilt, tilt=0.4)  # nach oben gekippt → heller
    rev = make_iduna_reverb(); rev.position = (520, 200)
    _set(rev, room_size=0.5, damping=0.3, mix=0.3)
    out = make_heimdall_master_out(); out.position = (740, 200)
    for m in (osc, tilt, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", tilt.id, "audio_in")
    _connect(p, tilt.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_compline():
    """Compline — dunkler Stereo-Drone mit Phaser-Mystik (Nachtgebet).

    Charakter: Phaser-Bewegung erzeugt mystische Nacht-Atmosphäre.
    L: Bass-Sinus mit dunklem Filter durch Phaser nass
    R: Quint-Triangle mit Filter direkt zu Master (dry, klar)
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_sine_osc, make_bragi_triangle_osc,
        make_forseti_lowpass, make_skadi_phaser,
        make_iduna_reverb, make_heimdall_master_out,
    )
    p = Patch(name="Compline")
    # L: Bass A2 mit Phaser
    osc_l = make_bragi_sine_osc(); osc_l.position = (60, 100)
    _set(osc_l, freq=110.0, gain=0.45)
    flt_l = make_forseti_lowpass(); flt_l.position = (260, 100)
    _set(flt_l, cutoff=900.0, resonance=0.2)
    phaser = make_skadi_phaser(); phaser.position = (460, 100)
    _set(phaser, rate=0.2, depth=0.8, feedback=0.5, mix=0.7)
    rev = make_iduna_reverb(); rev.position = (660, 100)
    _set(rev, room_size=0.85, damping=0.5, mix=0.45)
    # R: Quint E3 trocken
    osc_r = make_bragi_triangle_osc(); osc_r.position = (60, 280)
    _set(osc_r, freq=164.81, gain=0.35)
    flt_r = make_forseti_lowpass(); flt_r.position = (260, 280)
    _set(flt_r, cutoff=1200.0, resonance=0.15)
    out = make_heimdall_master_out(); out.position = (880, 200)
    for m in (osc_l, flt_l, phaser, rev, osc_r, flt_r, out):
        p.add_module(m)
    _connect(p, osc_l.id, "audio_out", flt_l.id, "audio_in")
    _connect(p, flt_l.id, "audio_out", phaser.id, "audio_in")
    _connect(p, phaser.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, osc_r.id, "audio_out", flt_r.id, "audio_in")
    _connect(p, flt_r.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_te_deum():
    """Te Deum — Saw + Tube-Drive + Compressor (epischer Lobgesang).

    Charakter: warmer Tube-Drive für Wärme + Compression für Punch.
    Nicht reverb-dominiert sondern direkt-präsent.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_saw_osc, make_forseti_lowpass,
        make_thor_tube_drive, make_vidar_compressor,
        make_iduna_reverb, make_heimdall_master_out,
    )
    p = Patch(name="Te Deum")
    osc = make_bragi_saw_osc(); osc.position = (60, 200)
    _set(osc, freq=261.63, gain=0.4)
    flt = make_forseti_lowpass(); flt.position = (260, 200)
    _set(flt, cutoff=4000.0, resonance=0.3)
    drive = make_thor_tube_drive(); drive.position = (460, 200)
    _set(drive, drive=4.0, tone=0.6, mix=0.7)  # mild Tube-Wärme
    comp = make_vidar_compressor(); comp.position = (660, 200)
    _set(comp, threshold=-15.0, ratio=3.0, attack_ms=10.0,
         release_ms=80.0, makeup=3.0)
    rev = make_iduna_reverb(); rev.position = (860, 200)
    _set(rev, room_size=0.65, damping=0.4, mix=0.3)
    out = make_heimdall_master_out(); out.position = (1060, 200)
    for m in (osc, flt, drive, comp, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", flt.id, "audio_in")
    _connect(p, flt.id, "audio_out", drive.id, "audio_in")
    _connect(p, drive.id, "audio_out", comp.id, "audio_in")
    _connect(p, comp.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_hymnal_pad():
    """Hymnal-Pad — Stereo Saw (L) + Triangle (R) mit Chorus.

    Charakter: Saw L + Triangle R erzeugt unterschiedliche Klangfarben
    pro Kanal, Chorus verbreitert beide.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_saw_osc, make_bragi_triangle_osc,
        make_forseti_lowpass, make_skadi_chorus,
        make_iduna_reverb, make_heimdall_master_out,
    )
    p = Patch(name="Hymnal-Pad")
    # L: Saw C4 (warm, breit)
    osc_l = make_bragi_saw_osc(); osc_l.position = (60, 100)
    _set(osc_l, freq=261.63, gain=0.30)
    flt_l = make_forseti_lowpass(); flt_l.position = (240, 100)
    _set(flt_l, cutoff=2400.0, resonance=0.2)
    chorus_l = make_skadi_chorus(); chorus_l.position = (420, 100)
    _set(chorus_l, rate=0.3, depth=0.6, mix=0.5)
    rev_l = make_iduna_reverb(); rev_l.position = (600, 100)
    _set(rev_l, room_size=0.7, damping=0.4, mix=0.35)
    # R: Triangle G4 (klar, hell)
    osc_r = make_bragi_triangle_osc(); osc_r.position = (60, 280)
    _set(osc_r, freq=392.00, gain=0.30)
    flt_r = make_forseti_lowpass(); flt_r.position = (240, 280)
    _set(flt_r, cutoff=3200.0, resonance=0.15)
    chorus_r = make_skadi_chorus(); chorus_r.position = (420, 280)
    _set(chorus_r, rate=0.5, depth=0.5, mix=0.5)  # leicht andere Rate
    rev_r = make_iduna_reverb(); rev_r.position = (600, 280)
    _set(rev_r, room_size=0.7, damping=0.4, mix=0.35)
    out = make_heimdall_master_out(); out.position = (820, 200)
    for m in (osc_l, flt_l, chorus_l, rev_l,
              osc_r, flt_r, chorus_r, rev_r, out):
        p.add_module(m)
    _connect(p, osc_l.id, "audio_out", flt_l.id, "audio_in")
    _connect(p, flt_l.id, "audio_out", chorus_l.id, "audio_in")
    _connect(p, chorus_l.id, "audio_out", rev_l.id, "audio_in")
    _connect(p, rev_l.id, "audio_out", out.id, "audio_in_l")
    _connect(p, osc_r.id, "audio_out", flt_r.id, "audio_in")
    _connect(p, flt_r.id, "audio_out", chorus_r.id, "audio_in")
    _connect(p, chorus_r.id, "audio_out", rev_r.id, "audio_in")
    _connect(p, rev_r.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_choir_drone():
    """Choir-Drone — Triangle + DEEP LFO an gain + Phaser (atmend lebendig).

    Charakter: starkes LFO-Pulsieren UND Phaser-Bewegung — wirkt wie
    ein atmender Choir.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_triangle_osc, make_loki_lfo_sine,
        make_skadi_phaser, make_iduna_reverb,
        make_heimdall_master_out,
    )
    p = Patch(name="Choir-Drone")
    osc = make_bragi_triangle_osc(); osc.position = (80, 200)
    _set(osc, freq=146.83, gain=0.5)
    lfo = make_loki_lfo_sine(); lfo.position = (80, 60)
    _set(lfo, rate=0.4, depth=0.35)  # DEUTLICH stärker als v.197 (war 0.05)
    phaser = make_skadi_phaser(); phaser.position = (300, 200)
    _set(phaser, rate=0.25, depth=0.7, feedback=0.4, mix=0.6)
    rev = make_iduna_reverb(); rev.position = (520, 200)
    _set(rev, room_size=0.7, damping=0.5, mix=0.4)
    out = make_heimdall_master_out(); out.position = (740, 200)
    for m in (osc, lfo, phaser, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", phaser.id, "audio_in")
    _connect(p, phaser.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    # LFO → osc.gain (atmen)
    _connect(p, lfo.id, "cv_out", osc.id, "gain")
    return p


def _build_pipe_organ():
    """Pipe-Organ — Square + Bandpass-Resonance + Thor.Saturation (reedy aggressiv).

    Charakter: aggressive Saturation auf Bandpass-Resonance gibt den
    klassischen reedy Orgelton.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_square_osc, make_forseti_bandpass,
        make_thor_saturation, make_iduna_reverb,
        make_heimdall_master_out,
    )
    p = Patch(name="Pipe-Organ")
    osc = make_bragi_square_osc(); osc.position = (60, 200)
    _set(osc, freq=130.81, gain=0.4)
    flt = make_forseti_bandpass(); flt.position = (260, 200)
    _set(flt, cutoff=1200.0, resonance=0.85)  # SCHARF
    sat = make_thor_saturation(); sat.position = (460, 200)
    _set(sat, amount=0.6, mix=0.8)
    rev = make_iduna_reverb(); rev.position = (660, 200)
    _set(rev, room_size=0.75, damping=0.4, mix=0.3)
    out = make_heimdall_master_out(); out.position = (860, 200)
    for m in (osc, flt, sat, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", flt.id, "audio_in")
    _connect(p, flt.id, "audio_out", sat.id, "audio_in")
    _connect(p, sat.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_bell_tower():
    """Bell-Tower — Stereo-Harmonie + Delay + BitCrush (metallisch perkussiv).

    Charakter: Harmonik-Stereo + leichter BitCrush + Delay-Echo erzeugt
    Glocken-Tower-Imitat. KEIN dominanter Reverb — Delay trägt den Klang.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_sine_osc, make_iduna_delay,
        make_fenrir_bit_crush, make_iduna_reverb,
        make_heimdall_master_out,
    )
    p = Patch(name="Bell-Tower")
    # L: Hoher Sinus 880
    osc_l = make_bragi_sine_osc(); osc_l.position = (60, 100)
    _set(osc_l, freq=880.0, gain=0.4)
    dly_l = make_iduna_delay(); dly_l.position = (260, 100)
    _set(dly_l, time=0.45, feedback=0.55, mix=0.5)
    crush_l = make_fenrir_bit_crush(); crush_l.position = (460, 100)
    _set(crush_l, bits=12.0, mix=0.4)  # leicht metallisch
    rev_l = make_iduna_reverb(); rev_l.position = (660, 100)
    _set(rev_l, room_size=0.6, damping=0.3, mix=0.25)
    # R: Quint Sinus 1320 (Glocken-Obertöne)
    osc_r = make_bragi_sine_osc(); osc_r.position = (60, 280)
    _set(osc_r, freq=1320.0, gain=0.30)
    dly_r = make_iduna_delay(); dly_r.position = (260, 280)
    _set(dly_r, time=0.30, feedback=0.50, mix=0.45)  # andere Delay-Zeit
    crush_r = make_fenrir_bit_crush(); crush_r.position = (460, 280)
    _set(crush_r, bits=10.0, mix=0.5)  # mehr Metall
    out = make_heimdall_master_out(); out.position = (880, 190)
    for m in (osc_l, dly_l, crush_l, rev_l,
              osc_r, dly_r, crush_r, out):
        p.add_module(m)
    _connect(p, osc_l.id, "audio_out", dly_l.id, "audio_in")
    _connect(p, dly_l.id, "audio_out", crush_l.id, "audio_in")
    _connect(p, crush_l.id, "audio_out", rev_l.id, "audio_in")
    _connect(p, rev_l.id, "audio_out", out.id, "audio_in_l")
    _connect(p, osc_r.id, "audio_out", dly_r.id, "audio_in")
    _connect(p, dly_r.id, "audio_out", crush_r.id, "audio_in")
    _connect(p, crush_r.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_cathedral():
    """Cathedral — Sine + Skadi.StereoImager + Maximum-Reverb (riesiger Raum).

    Charakter: extreme Stereo-Breite + langer Reverb-Tail. DAS ist der
    eine Preset wo Reverb dominieren DARF — das macht ihn cathedral.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_sine_osc, make_forseti_lowpass,
        make_skadi_stereo_imager, make_iduna_reverb,
        make_heimdall_master_out,
    )
    p = Patch(name="Cathedral")
    osc = make_bragi_sine_osc(); osc.position = (60, 200)
    _set(osc, freq=174.61, gain=0.4)
    flt = make_forseti_lowpass(); flt.position = (260, 200)
    _set(flt, cutoff=2200.0, resonance=0.1)
    imager = make_skadi_stereo_imager(); imager.position = (460, 200)
    _set(imager, width=2.0, mix=1.0)  # maximale Breite
    rev = make_iduna_reverb(); rev.position = (660, 200)
    _set(rev, room_size=0.97, damping=0.2, mix=0.6)  # MAXIMUM
    out = make_heimdall_master_out(); out.position = (860, 200)
    for m in (osc, flt, imager, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", flt.id, "audio_in")
    _connect(p, flt.id, "audio_out", imager.id, "audio_in")
    _connect(p, imager.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_stained_glass():
    """Stained-Glass — Triangle + HARTER BitCrush + Phaser (kristallin schimmernd).

    Charakter: aggressive BitCrush bricht den klaren Triangle in
    kristalline Splitter, Phaser lässt sie schimmern.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_triangle_osc, make_fenrir_bit_crush,
        make_skadi_phaser, make_iduna_reverb,
        make_heimdall_master_out,
    )
    p = Patch(name="Stained-Glass")
    osc = make_bragi_triangle_osc(); osc.position = (60, 200)
    _set(osc, freq=440.0, gain=0.45)
    crush = make_fenrir_bit_crush(); crush.position = (260, 200)
    _set(crush, bits=8.0, mix=0.6)  # HARD — bricht den Klang in Glas-Splitter
    phaser = make_skadi_phaser(); phaser.position = (460, 200)
    _set(phaser, rate=0.6, depth=0.7, feedback=0.5, mix=0.6)
    rev = make_iduna_reverb(); rev.position = (660, 200)
    _set(rev, room_size=0.65, damping=0.35, mix=0.35)
    out = make_heimdall_master_out(); out.position = (860, 200)
    for m in (osc, crush, phaser, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", crush.id, "audio_in")
    _connect(p, crush.id, "audio_out", phaser.id, "audio_in")
    _connect(p, phaser.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_incense():
    """Incense — Saw + STARKER LFO an Cutoff + Skadi.Flanger (dramatisch).

    Charakter: dramatischer Filter-Sweep durch starken LFO + Flanger-
    Bewegung — wirkt wie aufsteigender Weihrauch.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_saw_osc, make_loki_lfo_sine,
        make_forseti_lowpass, make_skadi_flanger,
        make_iduna_reverb, make_heimdall_master_out,
    )
    p = Patch(name="Incense")
    osc = make_bragi_saw_osc(); osc.position = (60, 200)
    _set(osc, freq=196.0, gain=0.4)
    lfo = make_loki_lfo_sine(); lfo.position = (60, 60)
    _set(lfo, rate=0.18, depth=2.5)  # SEHR stark — Cutoff fährt extrem
    flt = make_forseti_lowpass(); flt.position = (260, 200)
    _set(flt, cutoff=1000.0, resonance=0.6)
    flanger = make_skadi_flanger(); flanger.position = (460, 200)
    _set(flanger, rate=0.35, depth=0.6, feedback=0.55, mix=0.5)
    rev = make_iduna_reverb(); rev.position = (660, 200)
    _set(rev, room_size=0.75, damping=0.45, mix=0.35)
    out = make_heimdall_master_out(); out.position = (860, 200)
    for m in (osc, lfo, flt, flanger, rev, out):
        p.add_module(m)
    _connect(p, osc.id, "audio_out", flt.id, "audio_in")
    _connect(p, flt.id, "audio_out", flanger.id, "audio_in")
    _connect(p, flanger.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    # LFO → Filter-Cutoff (das macht das „Aufsteigen")
    _connect(p, lfo.id, "cv_out", flt.id, "cutoff")
    return p


def _build_sancta_sanctorum():
    """Sancta-Sanctorum — Sub-Bass 65Hz + Stereo-Phaser + Maximum-Reverb.

    Charakter: tiefer Sub-Bass auf L mit Delay+MaxReverb,
    Triangle-Oberton auf R mit Phaser für mystische Bewegung.
    Niedrigste Frequenz aller Sacred-Presets.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_sine_osc, make_bragi_triangle_osc,
        make_forseti_lowpass, make_skadi_phaser,
        make_iduna_delay, make_iduna_reverb,
        make_heimdall_master_out,
    )
    p = Patch(name="Sancta-Sanctorum")
    # L: SUB-BASS-Drone 65Hz (deutlich tiefer als v.197 G2=98Hz)
    osc_l = make_bragi_sine_osc(); osc_l.position = (40, 100)
    _set(osc_l, freq=65.41, gain=0.4)  # C2 — Sub-Bass-Bereich
    flt_l = make_forseti_lowpass(); flt_l.position = (240, 100)
    _set(flt_l, cutoff=400.0, resonance=0.2)  # tief gedämpft
    dly = make_iduna_delay(); dly.position = (440, 100)
    _set(dly, time=1.5, feedback=0.6, mix=0.4)  # langes Echo
    rev_l = make_iduna_reverb(); rev_l.position = (640, 100)
    _set(rev_l, room_size=0.97, damping=0.2, mix=0.65)  # MAX
    # R: Triangle-Oberton mit Phaser-Mystik
    osc_r = make_bragi_triangle_osc(); osc_r.position = (40, 280)
    _set(osc_r, freq=130.81, gain=0.30)  # C3 - eine Oktave höher
    flt_r = make_forseti_lowpass(); flt_r.position = (240, 280)
    _set(flt_r, cutoff=1500.0, resonance=0.15)
    phaser = make_skadi_phaser(); phaser.position = (440, 280)
    _set(phaser, rate=0.15, depth=0.85, feedback=0.6, mix=0.7)  # langsam, tief
    rev_r = make_iduna_reverb(); rev_r.position = (640, 280)
    _set(rev_r, room_size=0.85, damping=0.3, mix=0.4)
    out = make_heimdall_master_out(); out.position = (860, 190)
    for m in (osc_l, flt_l, dly, rev_l,
              osc_r, flt_r, phaser, rev_r, out):
        p.add_module(m)
    _connect(p, osc_l.id, "audio_out", flt_l.id, "audio_in")
    _connect(p, flt_l.id, "audio_out", dly.id, "audio_in")
    _connect(p, dly.id, "audio_out", rev_l.id, "audio_in")
    _connect(p, rev_l.id, "audio_out", out.id, "audio_in_l")
    _connect(p, osc_r.id, "audio_out", flt_r.id, "audio_in")
    _connect(p, flt_r.id, "audio_out", phaser.id, "audio_in")
    _connect(p, phaser.id, "audio_out", rev_r.id, "audio_in")
    _connect(p, rev_r.id, "audio_out", out.id, "audio_in_r")
    return p


# ─── Preset-Liste ─────────────────────────────────────────────────


def _build_all() -> list[dict]:
    """Baut alle 12 Sacred-v2-Patches.  Wird **lazy** beim ersten
    Vault-Import aufgerufen."""
    builders = [
        ("Vesper",           "Sine + Skadi.Chorus + sanfter Reverb (warmer Abend-Pad).",
         ["pad", "warm", "chorus", "evening"], "A2", _build_vesper),
        ("Matins",           "Triangle + Forseti.Tilt + kurzer Reverb (heller Morgen).",
         ["pad", "bright", "tilt", "morning"], "E4", _build_matins),
        ("Compline",         "Stereo-Drone mit Phaser-Mystik (Nachtgebet).",
         ["drone", "dark", "phaser", "stereo", "night"], "A2", _build_compline),
        ("Te Deum",          "Saw + Tube-Drive + Compressor (epischer Lobgesang).",
         ["pad", "warm", "drive", "punchy"], "C4", _build_te_deum),
        ("Hymnal-Pad",       "Stereo Saw (L) + Triangle (R) mit Chorus.",
         ["pad", "stereo", "chorus", "harmonic"], "C4", _build_hymnal_pad),
        ("Choir-Drone",      "Triangle + DEEP LFO + Skadi.Phaser (atmend lebendig).",
         ["drone", "choir", "phaser", "breathing"], "D3", _build_choir_drone),
        ("Pipe-Organ",       "Square + Bandpass-Res + Thor.Saturation (reedy).",
         ["organ", "reedy", "saturation", "vintage"], "C3", _build_pipe_organ),
        ("Bell-Tower",       "Stereo-Harmonie + Delay + BitCrush (metallisch).",
         ["bell", "metallic", "delay", "stereo"], "A5", _build_bell_tower),
        ("Cathedral",        "Sine + StereoImager + Max-Reverb (riesiger Raum).",
         ["pad", "spacious", "stereo-wide", "huge"], "F3", _build_cathedral),
        ("Stained-Glass",    "Triangle + HARTER BitCrush + Phaser (kristallin).",
         ["pad", "crystal", "bitcrush", "shimmer"], "A4", _build_stained_glass),
        ("Incense",          "Saw + LFO-Sweep + Skadi.Flanger (dramatisch).",
         ["sweep", "rising", "flanger", "atmospheric"], "G3", _build_incense),
        ("Sancta-Sanctorum", "Sub-Bass 65Hz + Stereo-Phaser + Max-Reverb.",
         ["drone", "sub-bass", "phaser", "infinite", "sacred"], "C2", _build_sancta_sanctorum),
    ]

    presets = []
    for name, desc, tags, key, builder in builders:
        patch_dict = _build_patch_dict(name, builder)
        if patch_dict is None:
            logger.warning("[SacredPresets-v2] %s skipped (build failed)", name)
            continue
        presets.append({
            "name": name,
            "description": desc,
            "tags": tags,
            "musical_key": key,
            "bpm": None,
            "author": SACRED_FACTORY_AUTHOR,  # Versions-Marker!
            "icon_svg": "",
            "patch": patch_dict,
        })
    return presets


class _LazyPresetList:
    """Wrapper: baut die Patches erst beim ersten Iterieren."""

    def __init__(self):
        self._cache: Optional[list[dict]] = None

    def _ensure(self) -> list[dict]:
        if self._cache is None:
            self._cache = _build_all()
            logger.info(
                "[SacredPresets-v2] built %d Sacred presets (%s) lazily",
                len(self._cache), SACRED_FACTORY_VERSION,
            )
        return self._cache

    def __iter__(self):
        return iter(self._ensure())

    def __len__(self):
        return len(self._ensure())

    def __getitem__(self, i):
        return self._ensure()[i]


# Public-API: SACRED_PRESETS verhält sich wie `list[dict]`, lazy-build.
SACRED_PRESETS = _LazyPresetList()


__all__ = [
    "SACRED_PRESETS",
    "SACRED_FACTORY_VERSION",
    "SACRED_FACTORY_AUTHOR",
]
