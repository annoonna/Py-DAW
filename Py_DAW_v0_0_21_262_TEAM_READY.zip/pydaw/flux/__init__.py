"""
pydaw.flux — Modulare Sound-Plattform (Inspired von SunVox/Reaktor/Bitwig Grid/Pure Data)

Architektur-Überblick:
    yggdrasil.py       — Mythologie-Registry (Götter = Modul-Familien + Farben)
    patch_model.py     — Datenmodell (Patch, Module, Port, Connection)
    module_library.py  — Factory + Registry der DSP-Module
    flux_canvas.py     — PyQt6 QGraphicsScene mit Wächter-Stil-Optik
    flux_main_widget.py — Hauptwidget (Canvas + Palette + Properties)

Neue Module hinzufügen:
    1. yggdrasil.py        → ggf. neuen Gott registrieren
    2. module_library.py   → Factory-Funktion + MODULE_REGISTRY-Eintrag
    3. pydaw_engine/src/flux/{god}.rs → DSP-Implementation in Rust
"""

from pydaw.flux.patch_model import (
    Patch, Module, Connection, Port, PortKind, PortDirection,
)
from pydaw.flux.yggdrasil import GODS, get_god, FluxColor, FluxCategory
from pydaw.flux.module_library import (
    MODULE_REGISTRY, list_available_modules, make_module, make_demo_patch,
)

__all__ = [
    "Patch", "Module", "Connection", "Port", "PortKind", "PortDirection",
    "GODS", "get_god", "FluxColor", "FluxCategory",
    "MODULE_REGISTRY", "list_available_modules", "make_module", "make_demo_patch",
]
