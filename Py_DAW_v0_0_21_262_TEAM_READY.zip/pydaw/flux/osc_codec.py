"""
pydaw.flux.osc_codec — OSC 1.0 Message Encoder/Decoder

Minimaler OSC-Codec für Hermod-Familie. Implementiert OSC 1.0 Spec
für UDP-Single-Messages (kein Bundle-Support — Bundles wären für
v.229+ Phase 6 Erweiterung).

Format einer OSC-Message:
    [path \\0 padded to 4 bytes]
    [, types \\0 padded to 4 bytes]   z.B. ',ifs\\0\\0\\0\\0'
    [args binary, je nach type]

Type-Tags (subset):
    'i' — int32 (big-endian)
    'f' — float32 (big-endian)
    's' — null-terminated string, padded to 4-byte
    'T' / 'F' — true / false (kein arg-bytes, OSC 1.1)
    'N' — nil (kein arg-bytes, OSC 1.1)

Bewusst nicht unterstützt (für v.228):
    Bundles (#bundle), Blob-Type 'b', RGBA, MIDI, Time-Tags.

Anno-Direktive (PD-Vergleich): genau das Subset das `netreceive -u -b`
+ `oscparse` in PD abdeckt.
"""
from __future__ import annotations

import struct
import logging
from typing import Optional

logger = logging.getLogger(__name__)


def _pad4(b: bytes) -> bytes:
    """Pad bytes to 4-byte boundary with null bytes."""
    rem = len(b) % 4
    if rem == 0:
        return b
    return b + b'\x00' * (4 - rem)


def encode_osc(path: str, args: list) -> bytes:
    """Encode OSC 1.0 message: path + types + args.

    Args werden auto-typisiert: int → 'i', float → 'f', str → 's'.
    Andere Typen werden als String konvertiert.

    Returns:
        Bytes-encoded OSC message (UDP-payload-ready).
    """
    if not path or not path.startswith('/'):
        # OSC paths müssen mit '/' beginnen
        path = '/' + (path or "")
    path_b = _pad4(path.encode('ascii', errors='replace') + b'\x00')

    types_str = ','
    for a in args:
        if isinstance(a, bool):  # bool muss VOR int weil bool isinstance int
            types_str += 'T' if a else 'F'
        elif isinstance(a, int):
            types_str += 'i'
        elif isinstance(a, float):
            types_str += 'f'
        elif isinstance(a, str):
            types_str += 's'
        else:
            types_str += 's'  # fallback: konvertiere zu String
    types_b = _pad4(types_str.encode('ascii') + b'\x00')

    args_b = b''
    for a in args:
        if isinstance(a, bool):
            pass  # T/F haben keine arg-bytes
        elif isinstance(a, int):
            try:
                args_b += struct.pack('>i', a)
            except struct.error:
                # Out of int32 range — clamp
                clamped = max(-2**31, min(2**31 - 1, a))
                args_b += struct.pack('>i', clamped)
        elif isinstance(a, float):
            try:
                args_b += struct.pack('>f', a)
            except struct.error:
                args_b += struct.pack('>f', 0.0)
        elif isinstance(a, str):
            args_b += _pad4(a.encode('ascii', errors='replace') + b'\x00')
        else:
            # Fallback: stringify
            args_b += _pad4(str(a).encode('ascii', errors='replace') + b'\x00')

    return path_b + types_b + args_b


def decode_osc(data: bytes) -> Optional[tuple[str, list]]:
    """Decode OSC 1.0 message: returns (path, args_list) or None.

    Robust gegen malformed input — gibt None zurück wenn parse-fail,
    statt Exception zu werfen (für Audio-Pfad wichtig).
    """
    if not data or len(data) < 4:
        return None
    try:
        # Path
        null_pos = data.find(b'\x00')
        if null_pos < 0:
            return None
        path = data[:null_pos].decode('ascii', errors='replace')
        pos = ((null_pos // 4) + 1) * 4  # round up to 4-byte boundary

        # No args case
        if pos >= len(data):
            return path, []

        # Types
        if data[pos:pos + 1] != b',':
            # Invalid type-tag prefix — return path, no args
            return path, []
        type_null = data.find(b'\x00', pos)
        if type_null < 0:
            return path, []
        types = data[pos + 1:type_null].decode('ascii', errors='replace')
        pos = ((type_null // 4) + 1) * 4

        # Args
        args = []
        for t in types:
            if pos >= len(data):
                break
            if t == 'i':
                if pos + 4 > len(data):
                    break
                args.append(struct.unpack('>i', data[pos:pos + 4])[0])
                pos += 4
            elif t == 'f':
                if pos + 4 > len(data):
                    break
                args.append(struct.unpack('>f', data[pos:pos + 4])[0])
                pos += 4
            elif t == 's':
                sn = data.find(b'\x00', pos)
                if sn < 0:
                    break
                args.append(data[pos:sn].decode('ascii', errors='replace'))
                pos = ((sn // 4) + 1) * 4
            elif t == 'T':
                args.append(True)
            elif t == 'F':
                args.append(False)
            elif t == 'N':
                args.append(None)
            else:
                # Unbekannter Type-Tag — abort to avoid mis-aligned reads
                logger.debug("[OSC] unbekannter type-tag %r — stop parsing", t)
                break
        return path, args
    except (struct.error, UnicodeDecodeError, IndexError) as e:
        logger.debug("[OSC] decode fehlgeschlagen: %s", e)
        return None


__all__ = ["encode_osc", "decode_osc"]
