"""instrument_registry.py — SQLite-backed Instrument Definitions Registry.

v0.0.20.889 — Phase 3 der SQLite Migration Roadmap.

Stores instrument metadata (name, category, engine/widget class, capabilities)
in SQLite instead of hardcoded Python. RAM-cached for fast lookups.

Old registry.py (hardcoded InstrumentSpec list) remains fully functional
as fallback — this module only ADDS a database layer for metadata queries.

Usage:
    from pydaw.services.instrument_registry import InstrumentRegistry
    reg = InstrumentRegistry.get()
    reg.ensure_loaded()
    all_instruments = reg.get_all()
    aeterna = reg.get_by_id("chrono.aeterna")
    synths = reg.get_by_category("synth")
"""

import sqlite3
import logging
from pathlib import Path
from typing import Dict, List, Optional

log = logging.getLogger(__name__)


class InstrumentRegistry:
    """Instrument definitions in SQLite, RAM-cached.

    Singleton. On startup loads all rows into dicts.
    Runtime: dict lookups only (<1µs).
    """

    _instance: Optional["InstrumentRegistry"] = None

    @classmethod
    def get(cls) -> "InstrumentRegistry":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._db_path = Path.home() / ".config" / "ChronoScaleStudio" / "pydaw.db"
        self._cache: Dict[str, dict] = {}          # plugin_id → row
        self._by_category: Dict[str, List[dict]] = {}  # category → [rows]
        self._ordered: List[dict] = []              # sorted by sort_order
        self._loaded = False

    def ensure_loaded(self) -> None:
        """Create table, seed factory data if empty, load into RAM. Idempotent."""
        if self._loaded:
            return
        try:
            self._init_db()
            self._load_to_ram()
            self._loaded = True
            log.info("[InstrumentRegistry] Loaded %d instruments", len(self._cache))
        except Exception as e:
            log.warning("[InstrumentRegistry] Failed to load: %s", e)

    # ── Public API ──────────────────────────────────────────────

    def get_all(self) -> List[dict]:
        """All instruments sorted by sort_order."""
        self.ensure_loaded()
        return list(self._ordered)

    def get_by_id(self, plugin_id: str) -> Optional[dict]:
        """Single instrument by plugin_id (e.g. 'chrono.aeterna')."""
        self.ensure_loaded()
        return self._cache.get(plugin_id)

    def get_by_category(self, category: str) -> List[dict]:
        """All instruments in a category (e.g. 'synth', 'sampler')."""
        self.ensure_loaded()
        return list(self._by_category.get(category, []))

    def get_display_name(self, plugin_id: str) -> str:
        """Get display name for a plugin_id, or plugin_id if not found."""
        self.ensure_loaded()
        row = self._cache.get(plugin_id)
        if row:
            return row.get("display_name") or row.get("name", plugin_id)
        return plugin_id

    def get_icon(self, plugin_id: str) -> str:
        """Get icon emoji for a plugin_id."""
        self.ensure_loaded()
        row = self._cache.get(plugin_id)
        if row:
            return row.get("icon", "🎹")
        return "🎹"

    def has_capability(self, plugin_id: str, capability: str) -> bool:
        """Check if instrument has a specific capability.

        Capabilities: 'set_param', 'import_state', 'apply_preset', 'needs_samples'
        """
        self.ensure_loaded()
        row = self._cache.get(plugin_id)
        if not row:
            return False
        key = f"has_{capability}" if not capability.startswith("has_") else capability
        if key == "needs_samples":
            key = "needs_samples"
        return bool(row.get(key, 0))

    def get_engine_class(self, plugin_id: str) -> Optional[str]:
        """Get the engine class path for an instrument."""
        self.ensure_loaded()
        row = self._cache.get(plugin_id)
        return row.get("engine_class") if row else None

    def get_widget_class(self, plugin_id: str) -> Optional[str]:
        """Get the widget class path for an instrument."""
        self.ensure_loaded()
        row = self._cache.get(plugin_id)
        return row.get("widget_class") if row else None

    def add_instrument(self, plugin_id: str, name: str, display_name: str,
                       category: str = "synth", **kwargs) -> bool:
        """Add or update an instrument definition. Returns True on success."""
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.execute(
                    """INSERT OR REPLACE INTO instruments
                       (id, name, display_name, category, engine_class, widget_class,
                        has_set_param, has_import_state, has_apply_preset, needs_samples,
                        icon, description, sort_order)
                       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (plugin_id, name, display_name, category,
                     kwargs.get("engine_class", ""),
                     kwargs.get("widget_class", ""),
                     int(kwargs.get("has_set_param", 1)),
                     int(kwargs.get("has_import_state", 0)),
                     int(kwargs.get("has_apply_preset", 0)),
                     int(kwargs.get("needs_samples", 0)),
                     kwargs.get("icon", "🎹"),
                     kwargs.get("description", ""),
                     int(kwargs.get("sort_order", 99)))
                )
                conn.commit()
            finally:
                conn.close()
            # Reload cache
            self._loaded = False
            self.ensure_loaded()
            return True
        except Exception as e:
            log.warning("[InstrumentRegistry] Failed to add instrument: %s", e)
            return False

    # ── Internal ────────────────────────────────────────────────

    def _init_db(self) -> None:
        """Create table + seed factory data if empty."""
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(self._db_path))
        try:
            conn.executescript(_SCHEMA_SQL)
            count = conn.execute("SELECT COUNT(*) FROM instruments").fetchone()[0]
            if count == 0:
                self._seed_factory_data(conn)
            conn.commit()
        finally:
            conn.close()

    def _load_to_ram(self) -> None:
        """Load all rows into dicts for O(1) lookup."""
        conn = sqlite3.connect(str(self._db_path))
        conn.row_factory = sqlite3.Row
        try:
            rows = conn.execute(
                "SELECT * FROM instruments ORDER BY sort_order, name"
            ).fetchall()
            self._cache.clear()
            self._by_category.clear()
            self._ordered.clear()
            for row in rows:
                d = dict(row)
                pid = d["id"]
                cat = d.get("category", "other")
                self._cache[pid] = d
                self._by_category.setdefault(cat, []).append(d)
                self._ordered.append(d)
        finally:
            conn.close()

    def _seed_factory_data(self, conn: sqlite3.Connection) -> None:
        """Insert all built-in instrument definitions."""
        for row in _FACTORY_INSTRUMENTS:
            try:
                conn.execute(
                    """INSERT OR IGNORE INTO instruments
                       (id, name, display_name, category, engine_class, widget_class,
                        has_set_param, has_import_state, has_apply_preset, needs_samples,
                        icon, description, sort_order)
                       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    row
                )
            except Exception:
                pass


# ── Schema ──────────────────────────────────────────────────────

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS instruments (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    display_name TEXT NOT NULL,
    category TEXT,
    engine_class TEXT,
    widget_class TEXT,
    has_set_param INTEGER DEFAULT 1,
    has_import_state INTEGER DEFAULT 0,
    has_apply_preset INTEGER DEFAULT 0,
    needs_samples INTEGER DEFAULT 0,
    icon TEXT,
    description TEXT,
    sort_order INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_instruments_category ON instruments(category);
"""

# ── Factory Data ────────────────────────────────────────────────
# Format: (id, name, display_name, category, engine_class, widget_class,
#          has_set_param, has_import_state, has_apply_preset, needs_samples,
#          icon, description, sort_order)

_FACTORY_INSTRUMENTS = [
    (
        "chrono.aeterna", "AETERNA", "AETERNA — Flagship Synth",
        "synth",
        "pydaw.plugins.aeterna.aeterna_engine.AeternaEngine",
        "pydaw.plugins.aeterna.aeterna_widget.AeternaWidget",
        1, 0, 0, 0,
        "🌌", "The Morphogenetic Engine: Formel-/Chaos-/Terrain-Synth mit sakralen Presets und Random-Math.",
        10
    ),
    (
        "chrono.fusion", "Fusion", "Fusion — Hybrid Synth",
        "synth",
        "pydaw.plugins.fusion.fusion_engine.FusionEngine",
        "pydaw.plugins.fusion.fusion_widget.FusionWidget",
        0, 0, 0, 0,
        "🔀", "Semi-modularer Hybrid-Synthesizer mit austauschbaren OSC/FLT/ENV Modulen.",
        20
    ),
    (
        "chrono.brrr", "BRRR Flutter Synth", "BRRR — Flutter Synth",
        "synth",
        "pydaw.plugins.brrr.brrr_engine.BrrrEngine",
        "pydaw.plugins.brrr.brrr_widget.BrrrWidget",
        0, 1, 0, 0,
        "🌀", "S&H-Flutter Synthesizer: FM-Buzz + Noise mit Sample-and-Hold LFO ±3 Oktaven (ZynAddSubFX Port).",
        30
    ),
    (
        "chrono.bach_orgel", "Bachs Orgel", "Bachs Orgel — Barock Orgel",
        "organ",
        "pydaw.plugins.bach_orgel.bach_orgel_engine.BachOrgelEngine",
        "pydaw.plugins.bach_orgel.bach_orgel_widget.BachOrgelWidget",
        0, 0, 1, 0,
        "⛪", "Barocke Orgel-Synthese mit Presets (Gottesdienst/Plenum/Flöte) und Automation.",
        40
    ),
    (
        "chrono.pro_audio_sampler", "Pro Audio Sampler", "Pro Audio Sampler",
        "sampler",
        "pydaw.plugins.sampler.sampler_engine.SamplerEngine",
        "pydaw.plugins.sampler.sampler_widget.SamplerWidget",
        0, 0, 0, 1,
        "🎤", "WAV Sampler mit Pitch/Filter/FX/ADHSR, Preview-Sync (PianoRoll/Notation).",
        50
    ),
    (
        "chrono.advanced_sampler", "Advanced Sampler", "Advanced Multi-Sample Sampler",
        "sampler",
        "pydaw.plugins.sampler.multisample_engine.MultiSampleEngine",
        "pydaw.plugins.sampler.multisample_widget.MultiSampleEditorWidget",
        0, 0, 0, 1,
        "🎼", "Multi-Sample Sampler: Key×Velocity Zones, Round-Robin, Filter+ADSR, Mod-Matrix, Auto-Mapping.",
        60
    ),
    (
        "chrono.pro_drum_machine", "Pro Drum Machine", "Pro Drum Machine — 16 Pad",
        "drums",
        "pydaw.plugins.drum_machine.drum_machine_engine.DrumMachineEngine",
        "pydaw.plugins.drum_machine.drum_machine_widget.DrumMachineWidget",
        0, 0, 0, 1,
        "🥁", "16-Pad Drum Machine (C1=Slot1) mit per-Slot Sampler + Pattern-Generator.",
        70
    ),
]
