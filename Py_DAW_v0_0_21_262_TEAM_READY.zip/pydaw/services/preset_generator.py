"""Synth Preset Generator (P2D) — KI-Preset & Sound-Design tools.

Pure Python, no ML dependencies. Works offline.

Features:
- Description → Preset: "Warmer 80er Pad mit langem Attack" → AETERNA/Fusion preset dict
- Sound-Matching: Find closest preset parameters for a given audio profile
- Smart-Randomize: Musically-aware parameter variation (not pure random)
- Preset-Descriptions: Preset params → human-readable description

v0.0.20.809 — Phase P2D
"""

from __future__ import annotations

import logging
import math
import random
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Tuple, Any

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Constants: preset parameter ranges and semantic mappings
# ---------------------------------------------------------------------------

# AETERNA parameter names → (min, max, default)
_AETERNA_PARAMS: Dict[str, Tuple[float, float, float]] = {
    "osc1_waveform": (0, 5, 0),        # 0=sine 1=saw 2=square 3=tri 4=noise 5=wavetable
    "osc1_level": (0.0, 1.0, 0.8),
    "osc1_octave": (-2, 2, 0),
    "osc1_detune": (-100.0, 100.0, 0.0),
    "osc2_waveform": (0, 5, 1),
    "osc2_level": (0.0, 1.0, 0.5),
    "osc2_octave": (-2, 2, 0),
    "osc2_detune": (-100.0, 100.0, 5.0),
    "filter_type": (0, 4, 0),          # 0=LP 1=HP 2=BP 3=Notch 4=Off
    "filter_cutoff": (20.0, 20000.0, 8000.0),
    "filter_resonance": (0.0, 1.0, 0.2),
    "filter_env_amount": (-1.0, 1.0, 0.3),
    "amp_attack": (0.001, 10.0, 0.01),
    "amp_decay": (0.01, 10.0, 0.3),
    "amp_sustain": (0.0, 1.0, 0.7),
    "amp_release": (0.01, 20.0, 0.5),
    "filter_attack": (0.001, 10.0, 0.01),
    "filter_decay": (0.01, 10.0, 0.5),
    "filter_sustain": (0.0, 1.0, 0.3),
    "filter_release": (0.01, 20.0, 0.5),
    "lfo1_rate": (0.01, 50.0, 2.0),
    "lfo1_shape": (0, 4, 0),           # 0=sine 1=tri 2=square 3=saw 4=s&h
    "lfo1_amount": (0.0, 1.0, 0.0),
    "chorus_mix": (0.0, 1.0, 0.0),
    "reverb_mix": (0.0, 1.0, 0.0),
    "delay_mix": (0.0, 1.0, 0.0),
    "unison_voices": (1, 16, 1),
    "unison_detune": (0.0, 100.0, 0.0),
    "unison_spread": (0.0, 1.0, 0.5),
    "master_volume": (0.0, 1.0, 0.75),
}

# Semantic keywords → parameter adjustments
_KEYWORD_MAP: Dict[str, Dict[str, Any]] = {
    # Timbral
    "warm": {"filter_cutoff": 3000, "filter_resonance": 0.15, "osc1_waveform": 1,
             "chorus_mix": 0.2},
    "bright": {"filter_cutoff": 16000, "filter_resonance": 0.1, "osc2_level": 0.6},
    "dark": {"filter_cutoff": 1200, "filter_resonance": 0.2},
    "harsh": {"filter_cutoff": 12000, "filter_resonance": 0.6, "osc1_waveform": 2},
    "soft": {"filter_cutoff": 4000, "filter_resonance": 0.1, "amp_attack": 0.15,
             "master_volume": 0.6},
    "clean": {"filter_cutoff": 18000, "filter_resonance": 0.0},
    "dirty": {"filter_resonance": 0.5, "osc2_detune": 15.0},
    "metallic": {"filter_resonance": 0.7, "filter_cutoff": 5000, "osc2_octave": 1},
    "gritty": {"filter_resonance": 0.4, "osc2_detune": 25.0},
    "silky": {"filter_cutoff": 6000, "filter_resonance": 0.05, "chorus_mix": 0.3},

    # Envelope / character
    "plucky": {"amp_attack": 0.001, "amp_decay": 0.2, "amp_sustain": 0.0,
               "amp_release": 0.15, "filter_env_amount": 0.6,
               "filter_decay": 0.15, "filter_sustain": 0.0},
    "pad": {"amp_attack": 1.5, "amp_decay": 2.0, "amp_sustain": 0.8,
            "amp_release": 3.0, "reverb_mix": 0.3},
    "lead": {"amp_attack": 0.005, "amp_sustain": 0.9, "filter_cutoff": 8000,
             "filter_env_amount": 0.4},
    "bass": {"osc1_octave": -1, "osc2_octave": -1, "filter_cutoff": 2000,
             "filter_env_amount": 0.5, "amp_attack": 0.001},
    "stab": {"amp_attack": 0.001, "amp_decay": 0.1, "amp_sustain": 0.0,
             "amp_release": 0.08},
    "arp": {"amp_attack": 0.001, "amp_decay": 0.15, "amp_sustain": 0.3,
            "amp_release": 0.1},
    "drone": {"amp_attack": 3.0, "amp_sustain": 1.0, "amp_release": 5.0,
              "lfo1_rate": 0.1, "lfo1_amount": 0.3},
    "bell": {"amp_attack": 0.001, "amp_decay": 2.0, "amp_sustain": 0.0,
             "amp_release": 2.0, "osc2_octave": 2, "filter_cutoff": 12000},
    "string": {"amp_attack": 0.4, "amp_sustain": 0.85, "amp_release": 0.8,
               "osc1_waveform": 1, "chorus_mix": 0.25},
    "brass": {"amp_attack": 0.05, "filter_env_amount": 0.7,
              "filter_decay": 0.3, "osc1_waveform": 1},
    "organ": {"amp_attack": 0.005, "amp_sustain": 1.0, "amp_release": 0.05,
              "osc1_waveform": 0, "osc2_waveform": 0, "osc2_octave": 1},

    # FX / Modulation
    "chorus": {"chorus_mix": 0.4},
    "reverb": {"reverb_mix": 0.4},
    "delay": {"delay_mix": 0.3},
    "wobble": {"lfo1_rate": 4.0, "lfo1_amount": 0.5, "lfo1_shape": 0},
    "pulsing": {"lfo1_rate": 2.0, "lfo1_amount": 0.4, "lfo1_shape": 2},
    "evolving": {"lfo1_rate": 0.1, "lfo1_amount": 0.6},
    "vibrato": {"lfo1_rate": 5.0, "lfo1_amount": 0.15, "lfo1_shape": 0},

    # Unison / Width
    "fat": {"unison_voices": 4, "unison_detune": 20.0, "unison_spread": 0.7},
    "thick": {"unison_voices": 3, "unison_detune": 15.0, "osc2_level": 0.7},
    "thin": {"unison_voices": 1, "osc2_level": 0.0},
    "wide": {"unison_voices": 4, "unison_spread": 1.0, "chorus_mix": 0.2},
    "mono": {"unison_voices": 1, "unison_spread": 0.0},
    "supersaw": {"osc1_waveform": 1, "osc2_waveform": 1, "unison_voices": 7,
                 "unison_detune": 30.0, "unison_spread": 0.8},

    # Era / Style
    "80er": {"osc1_waveform": 1, "chorus_mix": 0.3, "reverb_mix": 0.25,
             "filter_cutoff": 5000},
    "80s": {"osc1_waveform": 1, "chorus_mix": 0.3, "reverb_mix": 0.25,
            "filter_cutoff": 5000},
    "analog": {"osc1_waveform": 1, "osc2_detune": 8.0, "filter_resonance": 0.2},
    "digital": {"osc1_waveform": 5, "filter_cutoff": 14000},
    "retro": {"osc1_waveform": 2, "filter_cutoff": 4000, "chorus_mix": 0.2},
    "modern": {"unison_voices": 4, "filter_cutoff": 10000},
    "cinematic": {"reverb_mix": 0.5, "amp_attack": 2.0, "amp_release": 4.0,
                  "unison_voices": 4, "unison_detune": 10.0},
}

# Waveform names
_WAVEFORM_NAMES = {0: "Sine", 1: "Saw", 2: "Square", 3: "Triangle", 4: "Noise", 5: "Wavetable"}
_FILTER_NAMES = {0: "Lowpass", 1: "Highpass", 2: "Bandpass", 3: "Notch", 4: "Off"}
_LFO_SHAPE_NAMES = {0: "Sine", 1: "Triangle", 2: "Square", 3: "Saw", 4: "S&H"}


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------

@dataclass
class PresetResult:
    """Generated preset result."""
    name: str = ""
    description: str = ""
    params: Dict[str, float] = field(default_factory=dict)
    matched_keywords: List[str] = field(default_factory=list)
    target_synth: str = "aeterna"  # "aeterna"|"fusion"

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "description": self.description,
            "params": {k: round(v, 4) if isinstance(v, float) else v
                       for k, v in self.params.items()},
            "matched_keywords": self.matched_keywords,
            "target_synth": self.target_synth,
        }


# ---------------------------------------------------------------------------
# P2D-1: Description → Preset
# ---------------------------------------------------------------------------

def description_to_preset(
    description: str,
    synth: str = "aeterna",
    seed: Optional[int] = None,
) -> PresetResult:
    """Convert a natural language description to synth preset parameters.

    Args:
        description: e.g. "Warmer 80er Pad mit langem Attack und Chorus"
        synth: target synthesizer ("aeterna" or "fusion")
        seed: random seed for reproducibility

    Returns:
        PresetResult with parameter dict.
    """
    if seed is not None:
        random.seed(seed)

    desc_lower = description.lower()

    # Start with defaults
    params: Dict[str, float] = {}
    for pname, (_, _, default) in _AETERNA_PARAMS.items():
        params[pname] = default

    # Match keywords and apply modifications
    matched: List[str] = []
    for keyword, adjustments in _KEYWORD_MAP.items():
        if keyword in desc_lower:
            matched.append(keyword)
            for pname, value in adjustments.items():
                if pname in params:
                    params[pname] = value

    # Parse explicit numerical hints
    import re

    # Attack
    m = re.search(r"attack\s*[=:]?\s*([\d.]+)\s*(?:s|sec|ms)?", desc_lower)
    if m:
        val = float(m.group(1))
        if val > 50:
            val /= 1000.0  # ms → s
        params["amp_attack"] = max(0.001, min(10.0, val))

    # Release
    m = re.search(r"release\s*[=:]?\s*([\d.]+)\s*(?:s|sec|ms)?", desc_lower)
    if m:
        val = float(m.group(1))
        if val > 50:
            val /= 1000.0
        params["amp_release"] = max(0.01, min(20.0, val))

    # Cutoff
    m = re.search(r"(?:cutoff|filter)\s*[=:]?\s*([\d.]+)\s*(?:hz|khz)?", desc_lower)
    if m:
        val = float(m.group(1))
        if val < 100:
            val *= 1000.0  # kHz → Hz
        params["filter_cutoff"] = max(20.0, min(20000.0, val))

    # Unison voices
    m = re.search(r"(\d+)\s*(?:voice|voices|stimm|unison)", desc_lower)
    if m:
        params["unison_voices"] = max(1, min(16, int(m.group(1))))

    # Clamp all params
    for pname, val in list(params.items()):
        if pname in _AETERNA_PARAMS:
            lo, hi, _ = _AETERNA_PARAMS[pname]
            params[pname] = max(lo, min(hi, val))

    # Generate name
    name_parts = []
    if matched:
        name_parts = [k.capitalize() for k in matched[:3]]
    if not name_parts:
        name_parts = ["Custom"]
    preset_name = " ".join(name_parts)

    return PresetResult(
        name=preset_name,
        description=f"Generiert aus: '{description}'",
        params=params,
        matched_keywords=matched,
        target_synth=synth,
    )


# ---------------------------------------------------------------------------
# P2D-2: Sound Matching
# ---------------------------------------------------------------------------

@dataclass
class SoundMatchResult:
    """Result of matching an audio profile to synth params."""
    suggested_params: Dict[str, float] = field(default_factory=dict)
    match_score: float = 0.0  # 0..1
    description: str = ""
    hints: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "suggested_params": {k: round(v, 4) if isinstance(v, float) else v
                                  for k, v in self.suggested_params.items()},
            "match_score": round(self.match_score, 2),
            "description": self.description,
            "hints": self.hints,
        }


def match_sound_to_preset(
    audio_features: Dict[str, float],
    synth: str = "aeterna",
) -> SoundMatchResult:
    """Suggest synth parameters that approximate given audio features.

    Args:
        audio_features: dict with keys like "spectral_centroid_hz",
            "low_energy", "mid_energy", "high_energy", "rms_db",
            "dynamic_range_db", "stereo_width"

    Returns:
        SoundMatchResult with suggested parameters.
    """
    params: Dict[str, float] = {}
    for pname, (_, _, default) in _AETERNA_PARAMS.items():
        params[pname] = default

    hints: List[str] = []
    centroid = audio_features.get("spectral_centroid_hz", 2000.0)
    low_e = audio_features.get("low_energy", 0.33)
    high_e = audio_features.get("high_energy", 0.33)
    rms = audio_features.get("rms_db", -18.0)
    dyn_range = audio_features.get("dynamic_range_db", 12.0)
    width = audio_features.get("stereo_width", 0.5)

    # Filter cutoff from spectral centroid
    params["filter_cutoff"] = max(200.0, min(18000.0, centroid * 1.5))
    hints.append(f"Filter-Cutoff ≈ {params['filter_cutoff']:.0f} Hz (aus Spektral-Centroid)")

    # Brightness detection
    if centroid > 5000:
        params["filter_cutoff"] = 16000
        params["osc1_waveform"] = 1  # saw
        hints.append("Heller Sound → Saw-Waveform, offener Filter")
    elif centroid < 1500:
        params["filter_cutoff"] = 2500
        params["filter_resonance"] = 0.2
        hints.append("Dunkler Sound → tiefer Cutoff, leichte Resonanz")

    # Low energy → bass preset
    if low_e > 0.45:
        params["osc1_octave"] = -1
        params["osc2_octave"] = -1
        hints.append("Viel Low-End → Bass-Register (-1 Oktave)")

    # Dynamic range → envelope
    if dyn_range > 15:
        params["amp_attack"] = 0.8
        params["amp_release"] = 2.0
        hints.append("Hohe Dynamik → längerer Attack/Release (Pad-artig)")
    elif dyn_range < 5:
        params["amp_attack"] = 0.001
        params["amp_decay"] = 0.2
        params["amp_sustain"] = 0.9
        hints.append("Komprimiert → schneller Attack, hoher Sustain")

    # Stereo width → unison
    if width > 0.4:
        voices = min(8, max(2, int(width * 10)))
        params["unison_voices"] = voices
        params["unison_detune"] = width * 40
        params["unison_spread"] = min(1.0, width * 1.5)
        hints.append(f"Breites Stereobild → {voices} Unison-Voices")

    # Clamp
    for pname, val in list(params.items()):
        if pname in _AETERNA_PARAMS:
            lo, hi, _ = _AETERNA_PARAMS[pname]
            params[pname] = max(lo, min(hi, val))

    return SoundMatchResult(
        suggested_params=params,
        match_score=0.65,
        description="Preset-Annäherung basierend auf Audio-Analyse",
        hints=hints,
    )


# ---------------------------------------------------------------------------
# P2D-3: Smart Randomize
# ---------------------------------------------------------------------------

def smart_randomize(
    base_params: Optional[Dict[str, float]] = None,
    amount: float = 0.3,
    preserve: Optional[List[str]] = None,
    seed: Optional[int] = None,
    character: str = "balanced",
) -> PresetResult:
    """Musically-aware parameter randomization.

    Unlike pure random, this preserves musical relationships and avoids
    combinations that sound objectively bad.

    Args:
        base_params: starting preset (None = defaults)
        amount: randomization intensity 0..1
        preserve: list of param names to NOT randomize
        seed: random seed
        character: "balanced"|"gentle"|"wild"|"timbral"|"rhythmic"

    Returns:
        PresetResult with randomized parameters.
    """
    if seed is not None:
        random.seed(seed)

    preserve_set = set(preserve or [])

    # Start with base or defaults
    params: Dict[str, float] = {}
    for pname, (_, _, default) in _AETERNA_PARAMS.items():
        if base_params and pname in base_params:
            params[pname] = base_params[pname]
        else:
            params[pname] = default

    # Define which params to randomize based on character
    if character == "timbral":
        target_params = {"osc1_waveform", "osc2_waveform", "osc2_level", "osc2_detune",
                         "filter_cutoff", "filter_resonance", "filter_env_amount",
                         "chorus_mix", "unison_voices", "unison_detune"}
    elif character == "rhythmic":
        target_params = {"amp_attack", "amp_decay", "amp_sustain", "amp_release",
                         "filter_attack", "filter_decay", "filter_sustain",
                         "filter_release", "filter_env_amount", "lfo1_rate", "lfo1_amount"}
    elif character == "gentle":
        target_params = {"filter_cutoff", "filter_resonance", "osc2_detune",
                         "chorus_mix", "reverb_mix", "lfo1_rate", "lfo1_amount"}
    elif character == "wild":
        target_params = set(_AETERNA_PARAMS.keys())
    else:  # balanced
        target_params = set(_AETERNA_PARAMS.keys()) - {"master_volume"}

    # Apply randomization
    for pname in target_params:
        if pname in preserve_set:
            continue
        if pname not in _AETERNA_PARAMS:
            continue

        lo, hi, _ = _AETERNA_PARAMS[pname]
        current = params[pname]
        param_range = hi - lo

        if isinstance(lo, int) and isinstance(hi, int):
            # Discrete params: random choice with bias toward current
            if random.random() < amount:
                params[pname] = random.randint(int(lo), int(hi))
        else:
            # Continuous: Gaussian around current value
            sigma = param_range * amount * 0.3
            new_val = random.gauss(current, sigma)
            params[pname] = max(lo, min(hi, new_val))

    # Musical constraints (avoid objectively bad combos)
    # 1. If filter is very resonant, don't let cutoff be extreme
    if params.get("filter_resonance", 0) > 0.8:
        params["filter_cutoff"] = max(200, min(12000, params.get("filter_cutoff", 5000)))

    # 2. If attack is very long, ensure some sustain
    if params.get("amp_attack", 0) > 2.0:
        params["amp_sustain"] = max(0.3, params.get("amp_sustain", 0.7))

    # 3. Unison voices should be odd for better spread
    uv = int(params.get("unison_voices", 1))
    if uv > 1 and uv % 2 == 0:
        params["unison_voices"] = uv + 1

    # Clamp
    for pname, val in list(params.items()):
        if pname in _AETERNA_PARAMS:
            lo, hi, _ = _AETERNA_PARAMS[pname]
            params[pname] = max(lo, min(hi, val))

    return PresetResult(
        name=f"Random ({character.capitalize()} {amount:.0%})",
        description=f"Smart-Randomize: {character}, Intensität {amount:.0%}",
        params=params,
        matched_keywords=[character],
        target_synth="aeterna",
    )


# ---------------------------------------------------------------------------
# P2D-4: Preset Description Generator
# ---------------------------------------------------------------------------

def describe_preset(
    params: Dict[str, float],
    name: str = "",
) -> str:
    """Generate a human-readable description of a preset from its parameters.

    Args:
        params: synth parameter dict
        name: optional preset name

    Returns:
        Multi-line description string.
    """
    lines: List[str] = []
    if name:
        lines.append(f"**{name}**\n")

    # Oscillators
    wf1 = _WAVEFORM_NAMES.get(int(params.get("osc1_waveform", 0)), "?")
    wf2 = _WAVEFORM_NAMES.get(int(params.get("osc2_waveform", 0)), "?")
    oct1 = int(params.get("osc1_octave", 0))
    oct2 = int(params.get("osc2_octave", 0))
    det = params.get("osc2_detune", 0)
    osc2_lvl = params.get("osc2_level", 0)

    osc_desc = f"Osc1: {wf1}"
    if oct1 != 0:
        osc_desc += f" ({oct1:+d} Okt)"
    if osc2_lvl > 0.05:
        osc_desc += f" + Osc2: {wf2}"
        if oct2 != 0:
            osc_desc += f" ({oct2:+d} Okt)"
        if abs(det) > 1.0:
            osc_desc += f", Detune {det:+.0f} ct"
    lines.append(f"🎵 {osc_desc}")

    # Filter
    ftype = _FILTER_NAMES.get(int(params.get("filter_type", 0)), "?")
    cutoff = params.get("filter_cutoff", 8000)
    reso = params.get("filter_resonance", 0)
    fenv = params.get("filter_env_amount", 0)

    if int(params.get("filter_type", 0)) != 4:  # not Off
        f_desc = f"{ftype} @ {cutoff:.0f} Hz"
        if reso > 0.05:
            f_desc += f", Reso {reso:.0%}"
        if abs(fenv) > 0.05:
            f_desc += f", Env {fenv:+.0%}"
        lines.append(f"🎛 Filter: {f_desc}")

    # Amp Envelope
    atk = params.get("amp_attack", 0.01)
    dec = params.get("amp_decay", 0.3)
    sus = params.get("amp_sustain", 0.7)
    rel = params.get("amp_release", 0.5)

    env_char = _classify_envelope(atk, dec, sus, rel)
    lines.append(
        f"📈 Hüllkurve: {env_char} "
        f"(A={_format_time(atk)}, D={_format_time(dec)}, "
        f"S={sus:.0%}, R={_format_time(rel)})"
    )

    # Unison
    uv = int(params.get("unison_voices", 1))
    if uv > 1:
        udet = params.get("unison_detune", 0)
        uspr = params.get("unison_spread", 0.5)
        lines.append(f"🔊 Unison: {uv} Voices, Detune {udet:.0f} ct, Spread {uspr:.0%}")

    # LFO
    lfo_amt = params.get("lfo1_amount", 0)
    if lfo_amt > 0.02:
        lfo_rate = params.get("lfo1_rate", 2)
        lfo_shape = _LFO_SHAPE_NAMES.get(int(params.get("lfo1_shape", 0)), "?")
        lines.append(f"〰️ LFO: {lfo_shape} @ {lfo_rate:.1f} Hz, Amount {lfo_amt:.0%}")

    # FX
    fx_parts: List[str] = []
    if params.get("chorus_mix", 0) > 0.05:
        fx_parts.append(f"Chorus {params['chorus_mix']:.0%}")
    if params.get("reverb_mix", 0) > 0.05:
        fx_parts.append(f"Reverb {params['reverb_mix']:.0%}")
    if params.get("delay_mix", 0) > 0.05:
        fx_parts.append(f"Delay {params['delay_mix']:.0%}")
    if fx_parts:
        lines.append(f"✨ FX: {', '.join(fx_parts)}")

    # Overall character
    character = _describe_character(params)
    if character:
        lines.append(f"\n💡 Charakter: {character}")

    return "\n".join(lines)


def _format_time(seconds: float) -> str:
    """Format time value nicely."""
    if seconds < 0.01:
        return f"{seconds * 1000:.0f}µs"
    elif seconds < 1.0:
        return f"{seconds * 1000:.0f}ms"
    else:
        return f"{seconds:.1f}s"


def _classify_envelope(atk: float, dec: float, sus: float, rel: float) -> str:
    """Classify envelope as a musical category."""
    if atk < 0.005 and sus < 0.1 and dec < 0.3:
        return "Plucky / Staccato"
    elif atk < 0.005 and sus > 0.7:
        return "Instant-On / Lead"
    elif atk > 1.0 and rel > 2.0:
        return "Pad / Fläche"
    elif atk < 0.01 and dec < 0.15:
        return "Percussive / Stab"
    elif atk > 0.3 and atk < 1.5:
        return "Strings / Schwellend"
    elif sus > 0.9:
        return "Organ-artig / Sustained"
    else:
        return "Standard"


def _describe_character(params: Dict[str, float]) -> str:
    """Generate overall character description from params."""
    traits: List[str] = []

    cutoff = params.get("filter_cutoff", 8000)
    if cutoff < 2000:
        traits.append("dunkel")
    elif cutoff > 12000:
        traits.append("hell")

    uv = int(params.get("unison_voices", 1))
    if uv >= 4:
        traits.append("breit/fett")
    elif uv == 1 and params.get("chorus_mix", 0) < 0.1:
        traits.append("fokussiert/mono")

    atk = params.get("amp_attack", 0.01)
    if atk > 1.0:
        traits.append("weich/langsam")
    elif atk < 0.005:
        traits.append("perkussiv/schnell")

    if params.get("reverb_mix", 0) > 0.3:
        traits.append("räumlich")
    if params.get("chorus_mix", 0) > 0.2:
        traits.append("schwebend")
    if params.get("osc2_detune", 0) > 10:
        traits.append("verstimmt/lebendig")
    if params.get("filter_resonance", 0) > 0.5:
        traits.append("resonant/spitz")
    if params.get("lfo1_amount", 0) > 0.3:
        traits.append("moduliert/bewegt")

    return ", ".join(traits) if traits else "neutral/vielseitig"
