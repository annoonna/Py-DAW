"""
pydaw.services.saga_factory_shapes — 24 Factory-Shapes für Saga.Magic
======================================================================

**v0.0.21.202 — S-0 (Saga-Stack-Bootstrap)**
============================================

Liefert die 24 Form-Definitionen, die Saga.Magic im Modul-Body
darstellen kann. Jede Form ist eine `ShapeDefinition` mit:

  - ``id``           — Stable Integer 0..23 (Default 0 = Heart ❤)
  - ``name``         — Anzeigename
  - ``category``     — geometric | norse | lissajous | organic
  - ``sample_fn``    — `Callable[[float], tuple[float, float]]` —
                       parametrisches Sampling: t∈[0..1] → (x, y) im
                       Einheitsquadrat [-1..1]²
  - ``description``  — Tooltip-Text
  - ``default_density``      — initialer Punkt-Density-Wert
  - ``default_point_count``  — wie viele Punkte standardmäßig

Architektur-Wahl (S-0)
----------------------

Im Manifest §2.4 sind die Formen als SAGA-VM-Bytecode in der DB
geplant. **In S-0 laufen die Formen direkt als Python-Lambdas** —
das gibt sofort funktionsfähige Visualisierungen ohne Rust-Bytecode-
Interpreter und ist IDENTISCH zum Schema, das später mit Bytecode
abgelöst werden kann (gleiche Signatur). Der Bytecode-Pfad kommt
in einer Folgesession.

Charakter-Grundsatz
-------------------

Kein „alles auf 0.5" — jede Form ist erkennbar verschieden:
- Heart ist herzförmig
- Pentagram ist 5-strahlig spitzig
- Lissajous-Knoten sind dichte Verschlingungen
- Norse-Sigils respektieren ihre traditionellen Proportionen
- Organic-Formen (Lotus, Sun-Wheel, Spiral) füllen den Raum eher
  zentralsymmetrisch

Alle Formen sind in **Einheits-Bbox [-1..1]² normalisiert**, so dass
der Renderer (sei es Python `QPainter` oder Rust+IPC später) sie
linear in den Modul-Body skalieren kann.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Callable, Optional


# Versions-Marker — für künftige Migrations-Pfade
SAGA_FACTORY_SHAPES_VERSION = "v1"
SAGA_FACTORY_AUTHOR = f"Saga Factory (v1) — S-0"


# ─── Datenmodell ─────────────────────────────────────────────────


@dataclass(frozen=True)
class ShapeDefinition:
    """Definition einer Saga.Magic-Form.

    `sample_fn(t)` MUSS für jeden t∈[0..1] ein Tupel `(x, y)` mit
    `x, y ∈ [-1..1]` zurückgeben. Skalierung in den Modul-Body
    erledigt der Renderer.
    """
    id: int
    name: str
    category: str
    sample_fn: Callable[[float], tuple[float, float]] = field(repr=False)
    description: str = ""
    default_density: float = 0.7
    default_point_count: int = 256

    def sample(self, t: float) -> tuple[float, float]:
        """Wrapper mit Bounds-Clamp gegen Numerische Sonderfälle."""
        x, y = self.sample_fn(t)
        # Clamp gegen pathologische numerische Ausreisser
        return (max(-1.0, min(1.0, x)), max(-1.0, min(1.0, y)))

    def sample_polyline(self, n: int = 256) -> list[tuple[float, float]]:
        """Sampelt ``n`` Punkte gleichmäßig über t∈[0..1] — mit Clamp."""
        if n < 2:
            n = 2
        # Verwendet `self.sample()` (nicht `sample_fn` direkt) damit der
        # Bbox-Clamp greift — sonst können numerische Sonderfälle wie
        # Cardioids leichter Y-Overflow Punkte aus [-1..1]² rausschieben.
        return [self.sample(i / (n - 1)) for i in range(n)]


# ─── Geometrisch (id 0..5) ────────────────────────────────────────


def _shape_heart(t: float) -> tuple[float, float]:
    """Standard-Herz nach klassischer Parametrisierung.

    x = 16·sin³(t)
    y = 13·cos(t) - 5·cos(2t) - 2·cos(3t) - cos(4t)
    """
    a = t * 2.0 * math.pi
    s = math.sin(a)
    x = 16.0 * (s * s * s)
    y = 13.0 * math.cos(a) - 5.0 * math.cos(2.0 * a) - 2.0 * math.cos(3.0 * a) - math.cos(4.0 * a)
    # Normalisierung auf [-1..1]² (Y nach unten = positiv in Qt; Herz
    # zeigt nach oben → wir spiegeln Y)
    return (x / 17.0, -y / 17.0)


def _shape_pentagram(t: float) -> tuple[float, float]:
    """5/2-Stern-Polygon — dezent abgerundet.

    Pentagramm wird als Stern-Polygon konstruiert: 5 äussere Spitzen
    (Radius 1.0) abwechselnd mit 5 inneren Knoten (Radius 0.4).
    """
    n_segments = 10
    seg_t = (t * n_segments) % n_segments
    seg_idx = int(seg_t)
    local = seg_t - seg_idx

    def pt(i: int) -> tuple[float, float]:
        # gerade Indizes: außen, ungerade: innen
        r = 1.0 if (i % 2 == 0) else 0.382
        a = (i / 10.0) * 2.0 * math.pi - math.pi / 2.0
        return (r * math.cos(a), r * math.sin(a))

    p0 = pt(seg_idx)
    p1 = pt((seg_idx + 1) % n_segments)
    return (p0[0] + (p1[0] - p0[0]) * local,
            p0[1] + (p1[1] - p0[1]) * local)


def _shape_hexagram(t: float) -> tuple[float, float]:
    """Hexagram — zwei ineinander gedrehte Dreiecke (Davidstern).

    Wir rendern die zwei Dreiecke als getrennte Rampen über t.
    Der erste halbe t-Bereich [0..0.5] zeichnet das aufrechte
    Dreieck, der zweite [0.5..1] das gespiegelte.
    """
    if t < 0.5:
        seg_t = t * 2.0 * 3.0
        seg_idx = int(seg_t)
        local = seg_t - seg_idx

        def pt(i: int) -> tuple[float, float]:
            a = (i / 3.0) * 2.0 * math.pi - math.pi / 2.0
            return (math.cos(a), math.sin(a))
    else:
        seg_t = (t - 0.5) * 2.0 * 3.0
        seg_idx = int(seg_t)
        local = seg_t - seg_idx

        def pt(i: int) -> tuple[float, float]:
            a = (i / 3.0) * 2.0 * math.pi + math.pi / 2.0
            return (math.cos(a), math.sin(a))

    p0 = pt(seg_idx % 3)
    p1 = pt((seg_idx + 1) % 3)
    return (p0[0] + (p1[0] - p0[0]) * local,
            p0[1] + (p1[1] - p0[1]) * local)


def _shape_lemniscate(t: float) -> tuple[float, float]:
    """Lemniscate (∞-Schleife) — Bernoulli-Variante.

    x = cos(t) / (1 + sin²t)
    y = sin(t)·cos(t) / (1 + sin²t)
    """
    a = t * 2.0 * math.pi
    sin_a = math.sin(a)
    cos_a = math.cos(a)
    denom = 1.0 + sin_a * sin_a
    x = cos_a / denom
    y = sin_a * cos_a / denom
    return (x, y * 2.0)  # Y leicht streckend für visuelle Balance


def _shape_cardioid(t: float) -> tuple[float, float]:
    """Cardioide r = 1 - sin(θ) — Apfelkurve."""
    a = t * 2.0 * math.pi
    r = (1.0 - math.sin(a)) * 0.5
    x = r * math.cos(a)
    y = r * math.sin(a) - 0.25
    return (x, y)


def _shape_rose5(t: float) -> tuple[float, float]:
    """Rose-5: r = sin(5θ/2) — 5-Petal-Blüte (vgl. Manifest-Bild 2)."""
    a = t * 2.0 * math.pi * 2.0  # ×2 damit alle 5 Blätter gerendert werden
    r = abs(math.sin(2.5 * a))
    x = r * math.cos(a)
    y = r * math.sin(a)
    return (x, y)


# ─── Norse-Sigils (id 6..11) ──────────────────────────────────────


def _shape_yggdrasil(t: float) -> tuple[float, float]:
    """Stilisierter Lebensbaum: Stamm + 3 obere Äste + 3 untere Wurzeln.

    Wir teilen t in 7 Segmente (Stamm + 6 Verzweigungen).
    """
    segments = 7
    seg_t = (t * segments) % segments
    seg_idx = int(seg_t)
    local = seg_t - seg_idx

    if seg_idx == 0:
        # Stamm — vertikal von unten nach oben
        return (0.0, -1.0 + local * 2.0)
    elif seg_idx <= 3:
        # 3 obere Äste — vom Top zu drei Punkten am oberen Rand
        branch_idx = seg_idx - 1  # 0..2
        angles = [-math.pi/3, 0.0, math.pi/3]  # links, oben, rechts
        a = math.pi/2 + angles[branch_idx]
        end_x = math.cos(a) * 0.85
        end_y = -math.sin(a) * 0.85  # Y inverted für „nach oben"
        # Vom Top (0, 1) zum Endpunkt
        return (0.0 + (end_x - 0.0) * local, 1.0 + (end_y - 1.0) * local)
    else:
        # 3 untere Wurzeln — vom Bottom (0,-1) zu drei Punkten am unteren Rand
        root_idx = seg_idx - 4  # 0..2
        angles = [-math.pi/3, 0.0, math.pi/3]
        a = -math.pi/2 + angles[root_idx]
        end_x = math.cos(a) * 0.85
        end_y = math.sin(a) * 0.85
        return (0.0 + (end_x - 0.0) * local, -1.0 + (end_y - (-1.0)) * local)


def _shape_vegvisir(t: float) -> tuple[float, float]:
    """Vegvisir — 8-Achsen-Wegweiser (4 Diagonalen + 4 Cardinals)."""
    n_axes = 8
    seg_t = (t * n_axes) % n_axes
    seg_idx = int(seg_t)
    local = seg_t - seg_idx
    a = (seg_idx / n_axes) * 2.0 * math.pi
    end_x = math.cos(a) * 0.95
    end_y = math.sin(a) * 0.95
    # Bei jeder Achse: vom Center 0,0 nach (end_x,end_y) und zurück
    if local < 0.5:
        return (end_x * (local * 2.0), end_y * (local * 2.0))
    else:
        return (end_x * ((1.0 - local) * 2.0), end_y * ((1.0 - local) * 2.0))


def _shape_aegishjalmur(t: float) -> tuple[float, float]:
    """Aegishjalmur — 8 dreigliedrige Speichen (Helm der Furcht)."""
    n_spokes = 8
    seg_per_spoke = 4  # outward, dot1, dot2, return
    total_segs = n_spokes * seg_per_spoke
    seg_t = (t * total_segs) % total_segs
    seg_idx = int(seg_t)
    local = seg_t - seg_idx
    spoke_idx = seg_idx // seg_per_spoke
    sub_idx = seg_idx % seg_per_spoke
    a = (spoke_idx / n_spokes) * 2.0 * math.pi
    if sub_idx == 0:
        # outward 0 → 0.7
        r = local * 0.7
    elif sub_idx == 1:
        # 0.7 → 0.95 (mit kleinem Cross-Tick wäre besser, aber simpel hier)
        r = 0.7 + local * 0.25
    elif sub_idx == 2:
        # hold am Endpunkt — visuell ein „Ankerpunkt"
        r = 0.95
    else:
        # zurück zum Center 0.95 → 0
        r = 0.95 * (1.0 - local)
    return (r * math.cos(a), r * math.sin(a))


def _shape_mjolnir(t: float) -> tuple[float, float]:
    """Mjölnir — Thors Hammer: Kopf (Rechteck oben) + Stiel (vertikal).

    Wir rendern die Umrisslinie als geschlossener Polygon-Pfad.
    """
    # Hammer-Geometrie (Einheits-Bbox):
    #   Kopf-Rechteck: x∈[-0.6, 0.6], y∈[0.3, 0.95]
    #   Stiel:         x∈[-0.12, 0.12], y∈[-0.95, 0.3]
    # Polygon-Punkte (im Uhrzeigersinn, oben links startend):
    poly = [
        (-0.60,  0.95),  # 0: Kopf links oben
        ( 0.60,  0.95),  # 1: Kopf rechts oben
        ( 0.60,  0.30),  # 2: Kopf rechts unten
        ( 0.12,  0.30),  # 3: Kopf-Stiel-Übergang rechts
        ( 0.12, -0.95),  # 4: Stiel rechts unten
        (-0.12, -0.95),  # 5: Stiel links unten
        (-0.12,  0.30),  # 6: Stiel-Kopf-Übergang links
        (-0.60,  0.30),  # 7: Kopf links unten
    ]
    n = len(poly)
    seg_t = (t * n) % n
    seg_idx = int(seg_t)
    local = seg_t - seg_idx
    p0 = poly[seg_idx]
    p1 = poly[(seg_idx + 1) % n]
    return (p0[0] + (p1[0] - p0[0]) * local,
            p0[1] + (p1[1] - p0[1]) * local)


def _shape_triquetra(t: float) -> tuple[float, float]:
    """Triquetra — 3 ineinander verschlungene Vesica-Piscis.

    Drei Kreissegmente, je um 120° versetzt, jeder ein Bogen statt
    voller Kreis (für die Verschlingungs-Anmutung).
    """
    n_arcs = 3
    seg_t = (t * n_arcs) % n_arcs
    seg_idx = int(seg_t)
    local = seg_t - seg_idx
    base_angle = (seg_idx / n_arcs) * 2.0 * math.pi - math.pi / 2.0
    # Bogen-Center: außen, Radius 0.65, Startwinkel base_angle
    cx = math.cos(base_angle) * 0.55
    cy = math.sin(base_angle) * 0.55
    # Bogen-Sweep: 270° (das gibt den gewundenen Look)
    arc_start = base_angle + math.pi
    arc_sweep = 1.5 * math.pi
    a = arc_start + arc_sweep * local
    return (cx + math.cos(a) * 0.55, cy + math.sin(a) * 0.55)


def _shape_valknut(t: float) -> tuple[float, float]:
    """Valknut — Odins 3 ineinander verschlungene Dreiecke."""
    # 3 Dreiecke, jedes um 120° versetzt
    n_triangles = 3
    sides_per = 3
    total_segs = n_triangles * sides_per
    seg_t = (t * total_segs) % total_segs
    seg_idx = int(seg_t)
    local = seg_t - seg_idx
    tri_idx = seg_idx // sides_per
    side_idx = seg_idx % sides_per
    base_rot = (tri_idx / n_triangles) * 2.0 * math.pi / 3.0

    def vert(i: int) -> tuple[float, float]:
        a = (i / 3.0) * 2.0 * math.pi - math.pi / 2.0 + base_rot
        return (math.cos(a) * 0.85, math.sin(a) * 0.85)

    p0 = vert(side_idx)
    p1 = vert((side_idx + 1) % 3)
    return (p0[0] + (p1[0] - p0[0]) * local,
            p0[1] + (p1[1] - p0[1]) * local)


# ─── Lissajous & Knoten (id 12..17) ──────────────────────────────


def _shape_lissajous_3_2(t: float) -> tuple[float, float]:
    """Lissajous 3:2 — x = sin(3t+φ), y = sin(2t)."""
    a = t * 2.0 * math.pi
    phase = math.pi / 4.0
    return (math.sin(3.0 * a + phase), math.sin(2.0 * a))


def _shape_lissajous_5_4(t: float) -> tuple[float, float]:
    """Lissajous 5:4 — komplexer."""
    a = t * 2.0 * math.pi
    phase = math.pi / 3.0
    return (math.sin(5.0 * a + phase), math.sin(4.0 * a))


def _shape_lissajous_7_6(t: float) -> tuple[float, float]:
    """Lissajous 7:6 — sehr dicht."""
    a = t * 2.0 * math.pi
    phase = math.pi / 6.0
    return (math.sin(7.0 * a + phase), math.sin(6.0 * a))


def _shape_trefoil_knot(t: float) -> tuple[float, float]:
    """Trefoil-Knot 2D-Projektion (vgl. Manifest-Bild 3).

    3D-Trefoil:
        x = sin(t) + 2·sin(2t)
        y = cos(t) - 2·cos(2t)
        z = -sin(3t)
    Wir verwerfen Z und normalisieren auf [-1..1]².
    """
    a = t * 2.0 * math.pi
    x = math.sin(a) + 2.0 * math.sin(2.0 * a)
    y = math.cos(a) - 2.0 * math.cos(2.0 * a)
    return (x / 3.0, y / 3.0)


def _shape_lissajous_knot_3d(t: float) -> tuple[float, float]:
    """Lissajous-Knot 3D 2D-projiziert (vgl. Manifest-Bild 5).

    x = cos(3t)·cos(2t+π/3)
    y = cos(3t)·sin(2t+π/3)
    Z verwerfen.
    """
    a = t * 2.0 * math.pi
    cos3 = math.cos(3.0 * a)
    a2 = 2.0 * a + math.pi / 3.0
    x = cos3 * math.cos(a2)
    y = cos3 * math.sin(a2)
    return (x, y)


def _shape_torus_knot_3_2(t: float) -> tuple[float, float]:
    """Klassischer T(3,2) Torus-Knoten 2D-projiziert.

    p=3, q=2:
        x = (R + r·cos(qt))·cos(pt)
        y = (R + r·cos(qt))·sin(pt)
    """
    a = t * 2.0 * math.pi
    R, r = 0.7, 0.3
    p, q = 3.0, 2.0
    factor = R + r * math.cos(q * a)
    x = factor * math.cos(p * a)
    y = factor * math.sin(p * a)
    return (x, y)


# ─── Organic & Mystisch (id 18..23) ──────────────────────────────


def _shape_lotus_bloom(t: float) -> tuple[float, float]:
    """Lotus-Bloom — 8-blättrige Blume, jedes Blatt eine Cardioide."""
    n_petals = 8
    seg_t = (t * n_petals) % n_petals
    petal_idx = int(seg_t)
    local = seg_t - petal_idx
    # Globale Petal-Rotation um Center
    petal_rot = (petal_idx / n_petals) * 2.0 * math.pi
    # Lokale Cardioide (kleine, in +X-Richtung)
    a = local * 2.0 * math.pi
    r = (1.0 - math.cos(a)) * 0.4
    px = r * math.cos(a)
    py = r * math.sin(a)
    # In Petal-Frame rotieren
    cos_r = math.cos(petal_rot)
    sin_r = math.sin(petal_rot)
    x = px * cos_r - py * sin_r
    y = px * sin_r + py * cos_r
    return (x, y)


def _shape_sun_wheel(t: float) -> tuple[float, float]:
    """Sun-Wheel — 12 Speichen mit Endpoint-Cluster."""
    n_spokes = 12
    seg_per_spoke = 2  # outward, return
    total_segs = n_spokes * seg_per_spoke
    seg_t = (t * total_segs) % total_segs
    seg_idx = int(seg_t)
    local = seg_t - seg_idx
    spoke_idx = seg_idx // seg_per_spoke
    sub_idx = seg_idx % seg_per_spoke
    a = (spoke_idx / n_spokes) * 2.0 * math.pi
    if sub_idx == 0:
        r = local * 0.95  # outward
    else:
        r = 0.95 * (1.0 - local)  # return
    return (r * math.cos(a), r * math.sin(a))


def _shape_spiral(t: float) -> tuple[float, float]:
    """Goldener Schnitt — Fibonacci-Spirale."""
    # Goldener Winkel
    golden_angle = math.pi * (3.0 - math.sqrt(5.0))  # ~137.5°
    n_revolutions = 4.0
    a = t * n_revolutions * 2.0 * math.pi
    r = t  # 0..1
    # Mit goldenem Winkel modulieren für Fibonacci-Look
    a_eff = a + golden_angle * r * 5.0
    return (r * math.cos(a_eff), r * math.sin(a_eff))


def _shape_dragon_curve(t: float) -> tuple[float, float]:
    """Dragon-Curve nach 12 L-System-Iterationen.

    Direkte Iteration wäre teuer (4096 Punkte). Wir approximieren
    durch eine charakteristische Untermenge der Polygon-Punkte.
    """
    # Vorberechnete Dragon-Curve-Punkte (Iteration 6, 64 Linien)
    # via Heighway-Dragon-Iteration. Diese werden lazy beim Import
    # einmal berechnet.
    pts = _dragon_curve_points()
    n = len(pts)
    seg_t = (t * (n - 1))
    seg_idx = int(seg_t)
    if seg_idx >= n - 1:
        return pts[n - 1]
    local = seg_t - seg_idx
    p0 = pts[seg_idx]
    p1 = pts[seg_idx + 1]
    return (p0[0] + (p1[0] - p0[0]) * local,
            p0[1] + (p1[1] - p0[1]) * local)


_DRAGON_CACHE: Optional[list[tuple[float, float]]] = None


def _dragon_curve_points() -> list[tuple[float, float]]:
    """Lazy-cached Heighway-Dragon-Curve (Iteration 6 = 65 Punkte).

    Die L-System-Regel:
        F → F + G
        G → F - G
    Mit + = rechts drehen 90°, - = links drehen.
    Schrittweise Punkt-Generierung.
    """
    global _DRAGON_CACHE
    if _DRAGON_CACHE is not None:
        return _DRAGON_CACHE

    iterations = 6
    # Generiere die Sequenz von 0/1 (linke/rechte Drehungen)
    # Bekannter Trick: für n iterations gibt's 2^n - 1 Drehungen
    # Wir machen die Drehungen direkt via Bit-Trick aus iterations.
    n_segments = (1 << iterations)
    points = [(0.0, 0.0)]
    direction = 0  # 0=Ost, 1=Nord, 2=West, 3=Süd
    x, y = 0.0, 0.0
    step = 1.0
    for i in range(1, n_segments):
        # Der bekannte Bit-Trick für Dragon-Curve-Drehungen:
        # turn-direction = ((((i & -i) << 1) & i) != 0) ? right : left
        turn_right = ((((i & -i) << 1) & i) != 0)
        if turn_right:
            direction = (direction + 1) % 4
        else:
            direction = (direction - 1) % 4
        if direction == 0: x += step
        elif direction == 1: y += step
        elif direction == 2: x -= step
        elif direction == 3: y -= step
        points.append((x, y))

    # Normalisierung: Bbox finden, dann auf [-1..1]² skalieren
    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    xmin, xmax = min(xs), max(xs)
    ymin, ymax = min(ys), max(ys)
    cx = (xmin + xmax) * 0.5
    cy = (ymin + ymax) * 0.5
    extent = max(xmax - xmin, ymax - ymin) * 0.55  # 0.55 für leichten Innen-Margin
    if extent <= 0.0:
        extent = 1.0
    normalized = [((x - cx) / extent, (y - cy) / extent) for x, y in points]
    _DRAGON_CACHE = normalized
    return normalized


def _shape_phoenix_spiral(t: float) -> tuple[float, float]:
    """Phoenix-Spirale — Doppel-Spirale mit Auflösungs-Schweif.

    Zwei gegenläufige Spiralen, der Schweif klingt am Ende ab.
    """
    if t < 0.5:
        # Erste Spirale (auswärts)
        local = t * 2.0
        a = local * 5.0 * math.pi
        r = local * 0.95
    else:
        # Zweite Spirale (gegenläufig, Auflösung)
        local = (t - 0.5) * 2.0
        a = -local * 5.0 * math.pi + math.pi
        # Schweif: r klingt von 0.95 auf 0.0 ab
        r = (1.0 - local) * 0.95
    return (r * math.cos(a), r * math.sin(a))


def _shape_cosmic_egg(t: float) -> tuple[float, float]:
    """Cosmic-Egg / Ouroboros — Schlange beißt sich in den Schwanz.

    Ein Kreis, aber ovaler (Y-stretched), und mit einem leichten
    "Bauch" am unteren Rand zur Andeutung der Schlangen-Form.
    """
    a = t * 2.0 * math.pi
    # Oval mit leichter unterer Verdickung
    r_x = 0.80
    r_y = 0.95 + 0.05 * math.sin(a + math.pi)  # leicht eiförmig
    x = r_x * math.cos(a)
    y = r_y * math.sin(a)
    return (x, y)


# ─── Registry ────────────────────────────────────────────────────


SHAPE_DEFINITIONS: list[ShapeDefinition] = [
    # Geometrisch (id 0..5)
    ShapeDefinition(
        id=0, name="Heart", category="geometric", sample_fn=_shape_heart,
        description="Klassisches Herz ❤ — Default-Form für Saga.Magic.",
        default_density=0.7, default_point_count=256,
    ),
    ShapeDefinition(
        id=1, name="Pentagram", category="geometric", sample_fn=_shape_pentagram,
        description="5/2-Stern-Polygon, mystisch und scharfkantig.",
        default_density=0.6, default_point_count=200,
    ),
    ShapeDefinition(
        id=2, name="Hexagram", category="geometric", sample_fn=_shape_hexagram,
        description="Davidstern — zwei ineinander gedrehte Dreiecke.",
        default_density=0.6, default_point_count=200,
    ),
    ShapeDefinition(
        id=3, name="Lemniscate", category="geometric", sample_fn=_shape_lemniscate,
        description="Bernoulli-Lemniscate (∞-Schleife) — sanft und unendlich.",
        default_density=0.7, default_point_count=256,
    ),
    ShapeDefinition(
        id=4, name="Cardioid", category="geometric", sample_fn=_shape_cardioid,
        description="Apfelkurve r = 1 - sin(θ).",
        default_density=0.7, default_point_count=256,
    ),
    ShapeDefinition(
        id=5, name="Rose-5", category="geometric", sample_fn=_shape_rose5,
        description="5-blättrige Rose r = sin(5θ/2).",
        default_density=0.7, default_point_count=300,
    ),
    # Norse-Sigils (id 6..11)
    ShapeDefinition(
        id=6, name="Yggdrasil", category="norse", sample_fn=_shape_yggdrasil,
        description="Lebensbaum: Stamm + 3 obere Äste + 3 untere Wurzeln.",
        default_density=0.5, default_point_count=180,
    ),
    ShapeDefinition(
        id=7, name="Vegvisir", category="norse", sample_fn=_shape_vegvisir,
        description="Wegweiser-Sigil — 8 Achsen vom Center nach außen.",
        default_density=0.5, default_point_count=200,
    ),
    ShapeDefinition(
        id=8, name="Aegishjalmur", category="norse", sample_fn=_shape_aegishjalmur,
        description="Helm der Furcht — 8 dreigliedrige Speichen.",
        default_density=0.6, default_point_count=256,
    ),
    ShapeDefinition(
        id=9, name="Mjolnir", category="norse", sample_fn=_shape_mjolnir,
        description="Thors Hammer — Kopf-Rechteck + Stiel-Polygon-Umriss.",
        default_density=0.6, default_point_count=200,
    ),
    ShapeDefinition(
        id=10, name="Triquetra", category="norse", sample_fn=_shape_triquetra,
        description="3 ineinander verschlungene Vesica-Piscis-Bögen.",
        default_density=0.7, default_point_count=240,
    ),
    ShapeDefinition(
        id=11, name="Valknut", category="norse", sample_fn=_shape_valknut,
        description="Odins 3 ineinander verschlungene Dreiecke.",
        default_density=0.6, default_point_count=240,
    ),
    # Lissajous & Knoten (id 12..17)
    ShapeDefinition(
        id=12, name="Lissajous-3:2", category="lissajous", sample_fn=_shape_lissajous_3_2,
        description="Lissajous mit Frequenzverhältnis 3:2.",
        default_density=0.8, default_point_count=400,
    ),
    ShapeDefinition(
        id=13, name="Lissajous-5:4", category="lissajous", sample_fn=_shape_lissajous_5_4,
        description="Lissajous 5:4 — komplexer Knoten.",
        default_density=0.8, default_point_count=400,
    ),
    ShapeDefinition(
        id=14, name="Lissajous-7:6", category="lissajous", sample_fn=_shape_lissajous_7_6,
        description="Lissajous 7:6 — sehr dichte Verschlingung.",
        default_density=0.8, default_point_count=500,
    ),
    ShapeDefinition(
        id=15, name="Trefoil-Knot", category="lissajous", sample_fn=_shape_trefoil_knot,
        description="3D-Trefoil 2D-projiziert (vgl. Manifest-Bild 3).",
        default_density=0.8, default_point_count=400,
    ),
    ShapeDefinition(
        id=16, name="Lissajous-Knot-3D", category="lissajous", sample_fn=_shape_lissajous_knot_3d,
        description="Komplexer 3D-Lissajous-Knot (vgl. Manifest-Bild 5).",
        default_density=0.9, default_point_count=500,
    ),
    ShapeDefinition(
        id=17, name="Torus-Knot-3:2", category="lissajous", sample_fn=_shape_torus_knot_3_2,
        description="Klassischer Torus-Knoten T(3,2).",
        default_density=0.8, default_point_count=400,
    ),
    # Organic & Mystisch (id 18..23)
    ShapeDefinition(
        id=18, name="Lotus-Bloom", category="organic", sample_fn=_shape_lotus_bloom,
        description="8-blättrige Blume aus Cardioiden.",
        default_density=0.7, default_point_count=320,
    ),
    ShapeDefinition(
        id=19, name="Sun-Wheel", category="organic", sample_fn=_shape_sun_wheel,
        description="12 Speichen vom Center nach außen.",
        default_density=0.6, default_point_count=240,
    ),
    ShapeDefinition(
        id=20, name="Spiral", category="organic", sample_fn=_shape_spiral,
        description="Goldene Fibonacci-Spirale (4 Umläufe).",
        default_density=0.8, default_point_count=400,
    ),
    ShapeDefinition(
        id=21, name="Dragon-Curve", category="organic", sample_fn=_shape_dragon_curve,
        description="Heighway-Dragon-Curve nach 6 Iterationen.",
        default_density=0.9, default_point_count=300,
    ),
    ShapeDefinition(
        id=22, name="Phoenix-Spiral", category="organic", sample_fn=_shape_phoenix_spiral,
        description="Doppel-Spirale mit Auflösungs-Schweif.",
        default_density=0.7, default_point_count=300,
    ),
    ShapeDefinition(
        id=23, name="Cosmic-Egg", category="organic", sample_fn=_shape_cosmic_egg,
        description="Ouroboros — Schlange-beißt-sich-in-den-Schwanz.",
        default_density=0.6, default_point_count=200,
    ),
]


SHAPE_BY_ID: dict[int, ShapeDefinition] = {s.id: s for s in SHAPE_DEFINITIONS}
SHAPE_BY_NAME: dict[str, ShapeDefinition] = {s.name: s for s in SHAPE_DEFINITIONS}

DEFAULT_SHAPE_ID = 0  # Heart


def get_shape(shape_id: int) -> ShapeDefinition:
    """Liefert die Shape-Definition zu einer ID. Defaults auf Heart bei
    unbekannter ID — defensiv gegen out-of-range-Inputs aus Patches."""
    return SHAPE_BY_ID.get(shape_id, SHAPE_BY_ID[DEFAULT_SHAPE_ID])


def list_shapes() -> list[tuple[int, str, str, str]]:
    """Für die UI: alle 24 Formen mit ID, Name, Kategorie, Beschreibung.

    Returns: List of (id, name, category, description).
    """
    return [(s.id, s.name, s.category, s.description) for s in SHAPE_DEFINITIONS]


def shapes_by_category(category: str) -> list[ShapeDefinition]:
    """Alle Formen einer Kategorie (geometric/norse/lissajous/organic)."""
    return [s for s in SHAPE_DEFINITIONS if s.category == category]


__all__ = [
    "SAGA_FACTORY_SHAPES_VERSION", "SAGA_FACTORY_AUTHOR",
    "ShapeDefinition",
    "SHAPE_DEFINITIONS", "SHAPE_BY_ID", "SHAPE_BY_NAME",
    "DEFAULT_SHAPE_ID",
    "get_shape", "list_shapes", "shapes_by_category",
]
