"""native_bridge.py — Python↔Rust Native DSP Bridge (v0.0.20.983)

NS1: PyO3 UI-Hilfsfunktionen

Tries to import pydaw_native (Rust/PyO3 module built with maturin).
If not available, falls back to pure Python/numpy implementations.

The Rust versions are 10-100x faster for waveform, FFT, and metering.

Usage:
    from pydaw.services.native_bridge import native

    peaks = native.waveform_peaks(samples, 1000)
    spectrum = native.fft_magnitude(samples, 4096)
    rms_l, rms_r, peak_l, peak_r = native.rms_peak(left, right)
"""

import logging
import numpy as np
from typing import Tuple, Optional

log = logging.getLogger(__name__)

# Try loading native Rust module
_NATIVE_AVAILABLE = False
_native = None

try:
    import pydaw_native as _native
    _NATIVE_AVAILABLE = True
    log.info("pydaw_native (Rust/PyO3) loaded — using native DSP functions")
except ImportError:
    log.info("pydaw_native not available — using Python fallback (slower)")


class NativeBridge:
    """Unified interface for native DSP functions.

    Automatically uses Rust when available, Python fallback otherwise.
    All functions accept numpy arrays and return numpy arrays.
    """

    @property
    def is_native(self) -> bool:
        """True if Rust native module is loaded."""
        return _NATIVE_AVAILABLE

    @property
    def backend_name(self) -> str:
        return "rust/pyo3" if _NATIVE_AVAILABLE else "python/numpy"

    # ── NS1.1: Waveform ─────────────────────────────────────────────────

    def waveform_peaks(
        self, samples: np.ndarray, num_peaks: int
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Calculate min/max peaks for waveform overview.

        Returns (min_peaks, max_peaks) as float32 arrays.
        """
        samples = np.asarray(samples, dtype=np.float32).ravel()

        if _NATIVE_AVAILABLE:
            return _native.waveform_peaks(samples, num_peaks)

        # Python fallback
        if len(samples) == 0 or num_peaks == 0:
            return np.zeros(num_peaks, np.float32), np.zeros(num_peaks, np.float32)

        chunks = np.array_split(samples, num_peaks)
        mins = np.array([c.min() if len(c) > 0 else 0.0 for c in chunks], dtype=np.float32)
        maxs = np.array([c.max() if len(c) > 0 else 0.0 for c in chunks], dtype=np.float32)
        return mins, maxs

    def waveform_rms(self, samples: np.ndarray, num_points: int) -> np.ndarray:
        """Calculate RMS waveform for smooth display."""
        samples = np.asarray(samples, dtype=np.float32).ravel()

        if _NATIVE_AVAILABLE:
            return _native.waveform_rms(samples, num_points)

        if len(samples) == 0 or num_points == 0:
            return np.zeros(num_points, np.float32)

        chunks = np.array_split(samples, num_points)
        return np.array(
            [np.sqrt(np.mean(c ** 2)) if len(c) > 0 else 0.0 for c in chunks],
            dtype=np.float32,
        )

    # ── NS1.2: FFT / Spectrum ───────────────────────────────────────────

    def fft_magnitude(
        self, samples: np.ndarray, fft_size: int = 4096
    ) -> np.ndarray:
        """Compute FFT magnitude spectrum with Hanning window.

        Returns float32 array of dB magnitudes (fft_size/2 + 1 bins).
        """
        samples = np.asarray(samples, dtype=np.float32).ravel()

        if _NATIVE_AVAILABLE:
            return _native.fft_magnitude(samples, fft_size)

        # Python fallback
        padded = np.zeros(fft_size, dtype=np.float32)
        copy_len = min(len(samples), fft_size)
        padded[:copy_len] = samples[:copy_len]
        padded[:copy_len] *= np.hanning(copy_len).astype(np.float32)

        spectrum = np.fft.rfft(padded)
        magnitudes = np.abs(spectrum) * (2.0 / fft_size)
        magnitudes = np.maximum(magnitudes, 1e-10)
        db = 20.0 * np.log10(magnitudes)
        return db.astype(np.float32)

    def fft_magnitude_blackman(
        self, samples: np.ndarray, fft_size: int = 4096
    ) -> np.ndarray:
        """FFT with Blackman-Harris window (better sidelobe rejection)."""
        samples = np.asarray(samples, dtype=np.float32).ravel()

        if _NATIVE_AVAILABLE:
            return _native.fft_magnitude_blackman(samples, fft_size)

        padded = np.zeros(fft_size, dtype=np.float32)
        copy_len = min(len(samples), fft_size)
        padded[:copy_len] = samples[:copy_len]
        padded[:copy_len] *= np.blackman(copy_len).astype(np.float32)

        spectrum = np.fft.rfft(padded)
        magnitudes = np.abs(spectrum) * (2.0 / fft_size)
        magnitudes = np.maximum(magnitudes, 1e-10)
        db = 20.0 * np.log10(magnitudes)
        return db.astype(np.float32)

    def mel_scale(
        self, magnitudes: np.ndarray, num_mel_bins: int = 128,
        sample_rate: float = 48000.0,
    ) -> np.ndarray:
        """Convert linear FFT bins to Mel scale."""
        magnitudes = np.asarray(magnitudes, dtype=np.float32).ravel()

        if _NATIVE_AVAILABLE:
            return _native.mel_scale(magnitudes, num_mel_bins, sample_rate)

        # Python fallback
        freq_max = sample_rate / 2.0
        mel_max = 2595.0 * np.log10(1.0 + freq_max / 700.0)
        num_fft = len(magnitudes)
        mel_out = np.full(num_mel_bins, -200.0, dtype=np.float32)

        for m in range(num_mel_bins):
            mel_lo = mel_max * m / num_mel_bins
            mel_hi = mel_max * (m + 1) / num_mel_bins
            freq_lo = 700.0 * (10.0 ** (mel_lo / 2595.0) - 1.0)
            freq_hi = 700.0 * (10.0 ** (mel_hi / 2595.0) - 1.0)
            bin_lo = int(freq_lo / freq_max * (num_fft - 1))
            bin_hi = min(int(freq_hi / freq_max * (num_fft - 1)), num_fft - 1)
            if bin_lo <= bin_hi and bin_lo < num_fft:
                mel_out[m] = magnitudes[bin_lo:bin_hi + 1].max()

        return mel_out

    # ── NS1.3: Metering ─────────────────────────────────────────────────

    def rms_peak(
        self, samples_l: np.ndarray, samples_r: np.ndarray
    ) -> Tuple[float, float, float, float]:
        """Calculate RMS and peak for stereo audio.

        Returns (rms_l, rms_r, peak_l, peak_r) in dBFS.
        """
        left = np.asarray(samples_l, dtype=np.float32).ravel()
        right = np.asarray(samples_r, dtype=np.float32).ravel()

        if _NATIVE_AVAILABLE:
            return _native.rms_peak(left, right)

        def _calc(s):
            if len(s) == 0:
                return -200.0, -200.0
            rms = float(np.sqrt(np.mean(s ** 2)))
            peak = float(np.max(np.abs(s)))
            rms_db = 20.0 * np.log10(max(rms, 1e-10))
            peak_db = 20.0 * np.log10(max(peak, 1e-10))
            return rms_db, peak_db

        rms_l, peak_l = _calc(left)
        rms_r, peak_r = _calc(right)
        return rms_l, rms_r, peak_l, peak_r

    def lufs_momentary(
        self, samples_l: np.ndarray, samples_r: np.ndarray,
        sample_rate: float = 48000.0,
    ) -> float:
        """Simplified EBU R128 momentary LUFS measurement."""
        left = np.asarray(samples_l, dtype=np.float32).ravel()
        right = np.asarray(samples_r, dtype=np.float32).ravel()

        if _NATIVE_AVAILABLE:
            return _native.lufs_momentary(left, right, sample_rate)

        # Python fallback: simplified K-weighting
        def k_weight(s):
            if len(s) < 2:
                return 0.0
            filtered = np.diff(s, prepend=0) * 0.05 + s
            return float(np.mean(filtered ** 2))

        mean_l = k_weight(left)
        mean_r = k_weight(right)
        total = mean_l + mean_r
        if total < 1e-20:
            return -200.0
        return -0.691 + 10.0 * np.log10(total)

    def true_peak(
        self, samples_l: np.ndarray, samples_r: np.ndarray
    ) -> Tuple[float, float]:
        """True peak with 4x oversampling. Returns (tp_l, tp_r) in dBTP."""
        left = np.asarray(samples_l, dtype=np.float32).ravel()
        right = np.asarray(samples_r, dtype=np.float32).ravel()

        if _NATIVE_AVAILABLE:
            return _native.true_peak(left, right)

        def _tp(s):
            if len(s) == 0:
                return -200.0
            # 4x oversample via linear interp
            x_orig = np.arange(len(s))
            x_new = np.linspace(0, len(s) - 1, len(s) * 4)
            upsampled = np.interp(x_new, x_orig, s)
            peak = float(np.max(np.abs(upsampled)))
            return 20.0 * np.log10(max(peak, 1e-10))

        return _tp(left), _tp(right)

    # ── NS1.4: Audio Utilities ──────────────────────────────────────────

    def normalize(
        self, samples: np.ndarray, target_db: float = -1.0
    ) -> np.ndarray:
        """Normalize audio to target peak level in dBFS."""
        samples = np.asarray(samples, dtype=np.float32).ravel()

        if _NATIVE_AVAILABLE:
            return _native.normalize(samples, target_db)

        peak = float(np.max(np.abs(samples)))
        if peak < 1e-10:
            return samples.copy()
        target_lin = 10.0 ** (target_db / 20.0)
        return (samples * (target_lin / peak)).astype(np.float32)

    def resample(
        self, samples: np.ndarray, from_sr: int, to_sr: int
    ) -> np.ndarray:
        """Linear-interpolation resampling (fast, approximate)."""
        samples = np.asarray(samples, dtype=np.float32).ravel()

        if from_sr == to_sr:
            return samples.copy()

        if _NATIVE_AVAILABLE:
            return _native.resample(samples, from_sr, to_sr)

        ratio = to_sr / from_sr
        new_len = int(len(samples) * ratio)
        x_orig = np.arange(len(samples))
        x_new = np.linspace(0, len(samples) - 1, new_len)
        return np.interp(x_new, x_orig, samples).astype(np.float32)

    def detect_bpm(
        self, samples: np.ndarray, sample_rate: int = 48000
    ) -> float:
        """Detect BPM using autocorrelation. Returns 0.0 on failure."""
        samples = np.asarray(samples, dtype=np.float32).ravel()

        if _NATIVE_AVAILABLE:
            return _native.detect_bpm(samples, sample_rate)

        # Python fallback: energy-based autocorrelation
        sr = float(sample_rate)
        if len(samples) < sr * 2:
            return 0.0

        hop = 512
        frame_size = 1024
        num_frames = (len(samples) - frame_size) // hop

        if num_frames < 4:
            return 0.0

        energies = np.array([
            np.sum(samples[i * hop:i * hop + frame_size] ** 2)
            for i in range(num_frames)
        ])

        onset = np.maximum(np.diff(energies), 0)
        if len(onset) < 10:
            return 0.0

        fps = sr / hop
        min_lag = int(fps * 60.0 / 200.0)
        max_lag = min(int(fps * 60.0 / 60.0), len(onset) // 2)

        if min_lag >= max_lag:
            return 0.0

        best_lag = min_lag
        best_corr = 0.0

        for lag in range(min_lag, max_lag + 1):
            corr = np.sum(onset[:len(onset) - lag] * onset[lag:])
            corr /= (len(onset) - lag)
            if corr > best_corr:
                best_corr = corr
                best_lag = lag

        if best_corr < 1e-10:
            return 0.0

        return 60.0 * fps / best_lag

    def detect_key(
        self, samples: np.ndarray, sample_rate: int = 48000
    ) -> str:
        """Detect musical key using chroma analysis.

        Returns key name like 'C major' or 'A minor'.
        """
        samples = np.asarray(samples, dtype=np.float32).ravel()

        if _NATIVE_AVAILABLE:
            return _native.detect_key(samples, sample_rate)

        # Python fallback: chroma + Krumhansl-Kessler
        if len(samples) < 4096:
            return "Unknown"

        fft_size = 4096
        chroma = np.zeros(12, dtype=np.float64)
        num_frames = len(samples) // fft_size

        for fi in range(num_frames):
            frame = samples[fi * fft_size:(fi + 1) * fft_size]
            windowed = frame * np.hanning(fft_size).astype(np.float32)
            spectrum = np.fft.rfft(windowed)
            mags = np.abs(spectrum)

            freqs = np.fft.rfftfreq(fft_size, 1.0 / sample_rate)
            mask = (freqs >= 60) & (freqs <= 5000)

            for freq, mag in zip(freqs[mask], mags[mask]):
                if freq < 1:
                    continue
                midi = 69.0 + 12.0 * np.log2(freq / 440.0)
                idx = int(round(midi)) % 12
                chroma[idx] += mag * mag

        max_c = chroma.max()
        if max_c > 0:
            chroma /= max_c

        major = np.array([6.35, 2.23, 3.48, 2.33, 4.38, 4.09,
                          2.52, 5.19, 2.39, 3.66, 2.29, 2.88])
        minor = np.array([6.33, 2.68, 3.52, 5.38, 2.60, 3.53,
                          2.54, 4.75, 3.98, 2.69, 3.34, 3.17])

        notes = ["C", "C#", "D", "D#", "E", "F",
                 "F#", "G", "G#", "A", "A#", "B"]

        best_key = "C major"
        best_corr = -1.0

        for root in range(12):
            rotated = np.roll(chroma, -root)

            for profile, label in [(major, "major"), (minor, "minor")]:
                corr = np.corrcoef(rotated, profile)[0, 1]
                if corr > best_corr:
                    best_corr = corr
                    best_key = f"{notes[root]} {label}"

        return best_key


# Singleton instance
native = NativeBridge()
"""Global NativeBridge instance. Import and use directly:

    from pydaw.services.native_bridge import native
    peaks = native.waveform_peaks(samples, 1000)
"""
