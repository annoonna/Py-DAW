"""
pydaw.flux.ui_widgets.bang — Frigg.Bang Trigger-Button (Phase U-2)
==================================================================

PureData-Style Bang: kreisförmiger Button. Klick → ein kurzer Puls
(value=1.0 für ~80ms, danach 0.0). Praktisch für Trigger-Inputs an
Envelopes oder Reset-Pins.

Eingebaut in v0.0.21.195.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


try:
    from PyQt6.QtCore import Qt, QRectF, QSize, QTimer, pyqtSignal
    from PyQt6.QtGui import QColor, QPainter, QPen, QBrush
    from PyQt6.QtWidgets import QWidget, QSizePolicy
    _QT_AVAILABLE = True
except ImportError:
    _QT_AVAILABLE = False


if _QT_AVAILABLE:

    class BangWidget(QWidget):  # type: ignore[misc]
        """Kreisförmiger PD-Bang: leuchtet kurz beim Klick.

        Signale
        -------
        ``value_changed(float)`` — feuert zweimal beim Klick:
            (1) sofort mit 1.0 (Puls an)
            (2) nach PULSE_MS ms mit 0.0 (Puls aus)
        Damit ist es ein „echter Trigger" wie in PureData.
        """

        DEFAULT_SIZE = 36
        PULSE_MS = 80                # Puls-Dauer (lang genug fürs Auge)

        COL_BG = "#0a0e14"
        COL_BORDER = "#1a1f29"
        COL_BORDER_HOT = "#ff6b9d"
        COL_FILL_OFF = "#13181f"
        COL_FILL_ON = "#ff6b9d"      # warm-rosa wie ein klassischer PD-Bang

        value_changed = pyqtSignal(float)

        def __init__(self, parent=None):
            super().__init__(parent)
            self._is_hot = False        # gerade leuchtend?
            size = self.DEFAULT_SIZE
            self.setMinimumSize(size, size)
            self.setMaximumSize(size + 4, size + 4)
            self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)

            # Timer für Off-Puls
            self._off_timer = QTimer(self)
            self._off_timer.setSingleShot(True)
            self._off_timer.setInterval(self.PULSE_MS)
            self._off_timer.timeout.connect(self._fire_off)

            self.setToolTip(self._tooltip())

        @property
        def value(self) -> float:
            return 1.0 if self._is_hot else 0.0

        def trigger(self) -> None:
            """Externer Trigger (z.B. via MIDI-Map)."""
            self._fire_on()

        def mousePressEvent(self, event):  # type: ignore[override]
            if event.button() == Qt.MouseButton.LeftButton:
                self._fire_on()
                event.accept()
            else:
                super().mousePressEvent(event)

        def _fire_on(self) -> None:
            self._is_hot = True
            self.value_changed.emit(1.0)
            self._off_timer.start()
            self.update()

        def _fire_off(self) -> None:
            self._is_hot = False
            self.value_changed.emit(0.0)
            self.update()

        def paintEvent(self, event):  # type: ignore[override]
            painter = QPainter(self)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)

            w = self.width()
            h = self.height()
            size = min(w, h) - 4
            x0 = (w - size) / 2
            y0 = (h - size) / 2
            rect = QRectF(x0, y0, size, size)

            # Hintergrund-Rahmen
            painter.setBrush(QBrush(QColor(self.COL_BG)))
            painter.setPen(QPen(QColor(self.COL_BORDER), 1.0))
            painter.drawRoundedRect(rect, 3.0, 3.0)

            # Innerer Kreis — leuchtet wenn Hot
            inner = rect.adjusted(size * 0.18, size * 0.18,
                                   -size * 0.18, -size * 0.18)
            if self._is_hot:
                painter.setBrush(QBrush(QColor(self.COL_FILL_ON)))
                painter.setPen(QPen(QColor(self.COL_BORDER_HOT), 1.2))
            else:
                painter.setBrush(QBrush(QColor(self.COL_FILL_OFF)))
                painter.setPen(QPen(QColor(self.COL_BORDER), 1.0))
            painter.drawEllipse(inner)

            painter.end()

        def _tooltip(self) -> str:
            return (
                "<b>Bang</b>: Trigger<br>"
                "<span style='color:#8b949e;'>Klick = Puls (1.0 → 0.0 nach 80ms)</span>"
            )

        def sizeHint(self):  # type: ignore[override]
            return QSize(self.DEFAULT_SIZE, self.DEFAULT_SIZE)

else:
    BangWidget = None  # type: ignore[assignment,misc]


__all__ = ["BangWidget"]
