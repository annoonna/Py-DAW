"""BRRR Widget — UI für den BRRRRRR2-Fantasy Synthesizer

Alle Parameter als CompactKnob → MIDI Learn + Automation.
Scrawl-Editor für Buzz- und Flutter-Hüllkurven.
Preset-Save/Load per JSON.
Vollständige State-Persistenz im Projekt (gleich wie Fusion).

v0.0.20.749 — Anno / Claude Sonnet 4.6
"""
from __future__ import annotations

import json
import math
import os
from pathlib import Path
from typing import Any, Optional

import numpy as np

from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QPushButton, QFileDialog, QGroupBox,
    QSizePolicy, QInputDialog, QFrame, QTabWidget,
)

from .compact_knob import CompactKnob
from .scrawl_editor import ScrawlEditorWidget
from .brrr_engine import BrrrEngine

# ── Preset-Definitionen ────────────────────────────────────────────────────────

BRRR_PRESETS: dict[str, dict] = {
    "BRRRRRR2 Fantasy (Original)": {
        "buzz_volume": 0.90, "buzz_attack": 0.000, "buzz_decay": 0.40,
        "buzz_sustain": 0.40, "buzz_release": 0.20, "fm_depth": 0.20,
        "detune_l": -18.0, "detune_r": 15.0,
        "flutter_volume": 0.50, "flutter_attack": 0.08, "flutter_release": 0.50,
        "sah_rate_a": 4.5, "sah_depth_a": 15.0, "sah_rate_b": 3.0, "sah_depth_b": 0.3,
        "bp_freq": 1400.0, "bp_q": 0.6, "gain": 1.4, "pan": 0.0, "vel_sensitivity": 0.85,
    },
    "Soft Flutter": {
        "buzz_volume": 0.50, "buzz_attack": 0.01, "buzz_decay": 0.5,
        "buzz_sustain": 0.0, "buzz_release": 0.3, "fm_depth": 0.10,
        "detune_l": -12.0, "detune_r": 10.0,
        "flutter_volume": 0.70, "flutter_attack": 0.6, "flutter_release": 0.8,
        "sah_rate_a": 3.5, "sah_depth_a": 20.0, "sah_rate_b": 2.0, "sah_depth_b": 0.4,
        "bp_freq": 1200.0, "bp_q": 0.5, "gain": 1.5, "pan": 0.0, "vel_sensitivity": 0.75,
    },
    "Hard Buzz Attack": {
        "buzz_volume": 0.95, "buzz_attack": 0.000, "buzz_decay": 0.15,
        "buzz_sustain": 0.0, "buzz_release": 0.08, "fm_depth": 0.45,
        "detune_l": -30.0, "detune_r": 25.0,
        "flutter_volume": 0.30, "flutter_attack": 0.15, "flutter_release": 0.35,
        "sah_rate_a": 6.0, "sah_depth_a": 8.0, "sah_rate_b": 5.0, "sah_depth_b": 0.15,
        "bp_freq": 2400.0, "bp_q": 0.8, "gain": 1.4, "pan": 0.0, "vel_sensitivity": 0.95,
    },
    "Deep Low BRRR": {
        "buzz_volume": 0.85, "buzz_attack": 0.000, "buzz_decay": 0.50,
        "buzz_sustain": 0.0, "buzz_release": 0.25, "fm_depth": 0.30,
        "detune_l": -20.0, "detune_r": 18.0,
        "flutter_volume": 0.60, "flutter_attack": 0.40, "flutter_release": 0.70,
        "sah_rate_a": 3.0, "sah_depth_a": 25.0, "sah_rate_b": 2.5, "sah_depth_b": 0.5,
        "bp_freq": 800.0, "bp_q": 0.5, "gain": 1.6, "pan": 0.0, "vel_sensitivity": 0.80,
    },
    "Space Firefly": {
        "buzz_volume": 0.60, "buzz_attack": 0.02, "buzz_decay": 0.6,
        "buzz_sustain": 0.0, "buzz_release": 0.4, "fm_depth": 0.15,
        "detune_l": -14.0, "detune_r": 12.0,
        "flutter_volume": 0.80, "flutter_attack": 0.80, "flutter_release": 1.0,
        "sah_rate_a": 5.0, "sah_depth_a": 30.0, "sah_rate_b": 4.0, "sah_depth_b": 0.6,
        "bp_freq": 2600.0, "bp_q": 0.7, "gain": 1.5, "pan": 0.0, "vel_sensitivity": 0.70,
    },
}

# ── Knob-Definitionen ─────────────────────────────────────────────────────────
# (attr_name, label, min_val, max_val, default, scale_factor)
_BUZZ_KNOBS = [
    ("buzz_volume",  "Volume",   0,  100,  90,  0.01),
    ("buzz_attack",  "Attack",   0,  100,   0,  0.005),
    ("buzz_decay",   "Decay",    1,  200,  40,  0.01),
    ("buzz_sustain", "Sustain",  0,  100,  40,  0.01),
    ("buzz_release", "Release",  1,  200,  20,  0.01),
    ("fm_depth",     "PAD Width",0,  100,  20,  0.01),
]
_DETUNE_KNOBS = [
    ("detune_l", "Detune L",  -100,  0,  -18,  1.0),
    ("detune_r", "Detune R",     0, 100,   15,  1.0),
]
_FLUTTER_KNOBS = [
    ("flutter_volume",  "Mod Amt",  0,  100,  50,  0.01),
    ("flutter_attack",  "Attack",   0,  200,   8,  0.01),
    ("flutter_release", "Release",  1,  200,  50,  0.01),
]
_SAH_KNOBS = [
    ("sah_rate_a",  "Vib Rate",  10,  200,  45,  0.1),
    ("sah_depth_a", "Vib Depth",  0,  500, 150,  0.1),
    ("sah_rate_b",  "Trem Rate", 10,  200,  30,  0.1),
    ("sah_depth_b", "Trem Dep",   0,  100,  30,  0.01),
]
_FILTER_KNOBS = [
    ("bp_freq", "BP Freq",  20,  800, 140,  10.0),
    ("bp_q",    "BP Q",      10,  300,   60,  0.01),
]
_GLOBAL_KNOBS = [
    ("gain",            "Gain",      0,  200, 140, 0.01),
    ("pan",             "Pan",     -100, 100,   0,  0.01),
    ("vel_sensitivity", "Velocity", 0,  100,  85,  0.01),
]


class BrrrWidget(QWidget):
    """BRRR Synthesizer-UI — vollständig in Py_DAW integriert."""

    PLUGIN_STATE_KEY = "brrr"

    def __init__(self, project_service=None, audio_engine=None,
                 automation_manager=None, parent=None):
        super().__init__(parent)
        self.project_service = project_service
        self.audio_engine = audio_engine
        self.automation_manager = automation_manager
        self.track_id: Optional[str] = None
        self._restoring_state = False

        sr = 48000
        try:
            if audio_engine:
                sr = int(audio_engine.get_effective_sample_rate())
        except Exception:
            pass
        self.engine = BrrrEngine(target_sr=sr)

        # Pull-Source für Audio-Engine
        self._pull_name: Optional[str] = None
        def _pull(frames: int, sr: int, _e=self.engine):
            return _e.pull(frames, sr)
        _pull._pydaw_track_id = lambda: (self.track_id or '')
        self._pull_fn = _pull

        # Knob-Registry (attr_name → (CompactKnob, scale))
        self._knobs: dict[str, tuple[CompactKnob, float]] = {}

        # State-Persistenz-Timer (wie Fusion)
        self._persist_timer = QTimer(self)
        self._persist_timer.setSingleShot(True)
        self._persist_timer.setInterval(120)
        self._persist_timer.timeout.connect(self._persist_state)

        self._build_ui()
        self._apply_styles()

    # ── Lifecycle ──────────────────────────────────────────────────────────

    def set_track_context(self, track_id: str) -> None:
        self.track_id = str(track_id or '')
        # SamplerRegistry registrieren → MIDI Live Preview
        try:
            from pydaw.plugins.sampler.sampler_registry import get_sampler_registry
            reg = get_sampler_registry()
            if not reg.has_sampler(self.track_id):
                reg.register(self.track_id, self.engine, self)
        except Exception:
            pass
        # Pull-Source registrieren
        try:
            if self.audio_engine and not self._pull_name and self.track_id:
                self._pull_name = f"brrr:{self.track_id}:{id(self) & 0xFFFF:04x}"
                self.audio_engine.register_pull_source(self._pull_name, self._pull_fn)
                self.audio_engine.ensure_preview_output()
        except Exception:
            pass
        self._restore_state()
        self._setup_automation()

    def shutdown(self) -> None:
        if self._persist_timer.isActive():
            self._persist_timer.stop()
            self._persist_state()
        try:
            if self.audio_engine and self._pull_name:
                self.audio_engine.unregister_pull_source(self._pull_name)
        except Exception:
            pass
        self._pull_name = None
        try:
            if self.track_id:
                from pydaw.plugins.sampler.sampler_registry import get_sampler_registry
                get_sampler_registry().unregister(self.track_id)
        except Exception:
            pass
        self.engine.all_notes_off()

    def note_on(self, pitch: int, velocity: int = 100) -> None:
        self.engine.note_on(pitch, velocity)

    def note_off(self, pitch: int = -1) -> None:
        self.engine.note_off(pitch)

    # ── UI-Aufbau ──────────────────────────────────────────────────────────

    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(6, 6, 6, 6)
        root.setSpacing(5)

        # Header
        header = QHBoxLayout()
        title = QLabel("🔊 BRRR — Flutter Synth")
        title.setStyleSheet("font-weight: bold; font-size: 13px; color: #ff9800;")
        header.addWidget(title)
        header.addStretch()
        root.addLayout(header)

        # Preset-Leiste
        root.addWidget(self._build_preset_bar())

        # Tabs: Sound | Envelopes | Scrawl
        tabs = QTabWidget()
        tabs.addTab(self._build_sound_tab(), "🎛 Sound")
        tabs.addTab(self._build_envelope_tab(), "✏️ Scrawl-Envs")
        tabs.addTab(self._build_global_tab(), "⚙️ Global")
        root.addWidget(tabs, 1)

    def _build_preset_bar(self) -> QWidget:
        bar = QWidget()
        lay = QHBoxLayout(bar)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(4)

        lay.addWidget(QLabel("Preset:"))
        from PyQt6.QtWidgets import QComboBox
        self._preset_combo = QComboBox()
        self._preset_combo.addItems(list(BRRR_PRESETS.keys()))
        self._preset_combo.setMinimumWidth(180)
        self._preset_combo.activated.connect(self._on_preset_selected)
        lay.addWidget(self._preset_combo, 1)

        load_btn = QPushButton("📂")
        load_btn.setFixedSize(26, 24)
        load_btn.setToolTip("Preset aus Datei laden")
        load_btn.clicked.connect(self._load_preset_file)
        lay.addWidget(load_btn)

        save_btn = QPushButton("💾")
        save_btn.setFixedSize(26, 24)
        save_btn.setToolTip("Preset als Datei speichern")
        save_btn.clicked.connect(self._save_preset_file)
        lay.addWidget(save_btn)

        return bar

    def _build_sound_tab(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setSpacing(6)

        # Layer A: Buzz
        buzz_box = QGroupBox("🔴 Layer A — PADsynth Buzz")
        bg = QGridLayout(buzz_box)
        for col, (attr, label, mn, mx, dflt, scale) in enumerate(_BUZZ_KNOBS):
            knob = self._make_knob(attr, label, mn, mx, dflt, scale)
            bg.addWidget(knob, 0, col)
        for col, (attr, label, mn, mx, dflt, scale) in enumerate(_DETUNE_KNOBS):
            knob = self._make_knob(attr, label, mn, mx, dflt, scale)
            bg.addWidget(knob, 1, col)
        lay.addWidget(buzz_box)

        # Layer B: Flutter
        flutter_box = QGroupBox("🟣 Modulation — Vibrato + Tremolo")
        fg = QGridLayout(flutter_box)
        for col, (attr, label, mn, mx, dflt, scale) in enumerate(_FLUTTER_KNOBS):
            knob = self._make_knob(attr, label, mn, mx, dflt, scale)
            fg.addWidget(knob, 0, col)
        for col, (attr, label, mn, mx, dflt, scale) in enumerate(_SAH_KNOBS):
            knob = self._make_knob(attr, label, mn, mx, dflt, scale)
            fg.addWidget(knob, 1, col)
        lay.addWidget(flutter_box)

        # Filter
        filt_box = QGroupBox("🎚 BandPass-Filter (Flutter-Klangfarbe)")
        fl = QHBoxLayout(filt_box)
        for attr, label, mn, mx, dflt, scale in _FILTER_KNOBS:
            fl.addWidget(self._make_knob(attr, label, mn, mx, dflt, scale))
        fl.addStretch()
        lay.addWidget(filt_box)

        lay.addStretch()
        return w

    def _build_envelope_tab(self) -> QWidget:
        """Scrawl-Editors für Buzz- und Flutter-Hüllkurve."""
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setSpacing(6)

        buzz_grp = QGroupBox("✏️ Buzz-Hüllkurve (Layer A)")
        bg = QVBoxLayout(buzz_grp)
        self._buzz_scrawl = ScrawlEditorWidget()
        self._buzz_scrawl.waveform_changed.connect(self._on_buzz_scrawl_changed)
        bg.addWidget(self._buzz_scrawl)
        # Standard-Form: schneller Transient
        self._buzz_scrawl.set_points([
            (0.0, 0.0), (0.02, 1.0), (0.25, 0.3), (0.6, 0.05), (1.0, 0.0)
        ])
        lay.addWidget(buzz_grp)

        flutter_grp = QGroupBox("✏️ Flutter-Hüllkurve (Layer B)")
        fg = QVBoxLayout(flutter_grp)
        self._flutter_scrawl = ScrawlEditorWidget()
        self._flutter_scrawl.waveform_changed.connect(self._on_flutter_scrawl_changed)
        fg.addWidget(self._flutter_scrawl)
        # Standard-Form: langsamer Attack
        self._flutter_scrawl.set_points([
            (0.0, 0.0), (0.3, 0.6), (0.5, 1.0), (0.9, 1.0), (1.0, 0.0)
        ])
        lay.addWidget(flutter_grp)

        # v0.0.20.761: KEIN Auto-Bake mehr beim Widget-Init!
        # Die visuellen Shapes im Editor sind nur Deko / Platzhalter.
        # Die Engine-Tabellen bleiben None (= kein Effekt = Original-Sound),
        # bis der User aktiv zeichnet oder ein State mit Scrawl-Daten geladen wird.

        return w

    def _build_global_tab(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)

        glob_box = QGroupBox("⚙️ Global")
        gl = QHBoxLayout(glob_box)
        for attr, label, mn, mx, dflt, scale in _GLOBAL_KNOBS:
            gl.addWidget(self._make_knob(attr, label, mn, mx, dflt, scale))
        gl.addStretch()
        lay.addWidget(glob_box)

        info = QLabel(
            "<b>BRRR Synth</b> — Port von ZynAddSubFX BRRRRRR2 Fantasy<br>"
            "<small>Layer A: FM-Buzz mit Power-Welle + Harmonische 25 (kein Sustain)<br>"
            "Layer B: Rauschwelle + S&H-LFO Pitch-Flutter ±3 Oktaven (das BRRRRRR!)<br>"
            "Alle Parameter per MIDI-Learn und Automation steuerbar.</small>"
        )
        info.setWordWrap(True)
        info.setStyleSheet("color: #888; font-size: 10px; padding: 8px;")
        lay.addWidget(info)
        lay.addStretch()
        return w

    # ── Knob Factory ───────────────────────────────────────────────────────

    def _make_knob(self, attr: str, label: str,
                   mn: int, mx: int, dflt: int, scale: float) -> CompactKnob:
        k = CompactKnob(label)
        k.setRange(mn, mx)
        k.setValue(dflt)
        k.valueChanged.connect(lambda v, a=attr, s=scale: self._on_knob(a, v, s))
        self._knobs[attr] = (k, scale)
        # Automation-Binding vorbereiten
        k.setObjectName(f"brrr.{attr}")
        return k

    def _on_knob(self, attr: str, raw_val: int, scale: float) -> None:
        real_val = raw_val * scale
        try:
            setattr(self.engine, attr, real_val)
        except Exception:
            pass
        # BR-3: Forward to Rust engine
        self._send_rust_param(attr, real_val)
        self._schedule_persist()

    # ── Rust Engine Forwarding (BR-3) ─────────────────────────────────────

    # 1:1 mapping — Python attr names match Rust param names
    _RUST_PARAM_MAP = {
        "buzz_volume": "buzz_volume", "buzz_attack": "buzz_attack",
        "buzz_decay": "buzz_decay", "buzz_sustain": "buzz_sustain",
        "buzz_release": "buzz_release", "fm_depth": "fm_depth",
        "detune_l": "detune_l", "detune_r": "detune_r",
        "flutter_volume": "flutter_volume", "flutter_attack": "flutter_attack",
        "flutter_release": "flutter_release",
        "sah_rate_a": "vib_rate", "sah_depth_a": "vib_depth",
        "sah_rate_b": "trem_rate", "sah_depth_b": "trem_depth",
        "bp_freq": "bp_freq", "bp_q": "bp_q",
        "gain": "gain", "pan": "pan", "vel_sensitivity": "vel_sensitivity",
    }

    def _send_rust_param(self, attr: str, value: float) -> None:
        """Forward a parameter change to the Rust engine via IPC."""
        try:
            rust_name = self._RUST_PARAM_MAP.get(attr)
            if rust_name is None:
                return
            if not self.track_id or self.audio_engine is None:
                return
            bridge = None
            try:
                from pydaw.services.rust_engine_bridge import RustEngineBridge
                bridge = RustEngineBridge.instance()
            except Exception:
                pass
            if bridge is not None and hasattr(bridge, 'set_instrument_param'):
                bridge.set_instrument_param(self.track_id, rust_name, float(value))
        except Exception:
            pass

    def _sync_all_to_rust(self) -> None:
        """Send ALL current params to Rust engine (takeover sync)."""
        try:
            if not self.track_id or self.audio_engine is None:
                return
            bridge = None
            try:
                from pydaw.services.rust_engine_bridge import RustEngineBridge
                bridge = RustEngineBridge.instance()
            except Exception:
                pass
            if bridge is None or not hasattr(bridge, 'set_instrument_param'):
                return
            for py_key, rust_name in self._RUST_PARAM_MAP.items():
                try:
                    val = getattr(self.engine, py_key, None)
                    if val is not None:
                        bridge.set_instrument_param(self.track_id, rust_name, float(val))
                except Exception:
                    pass
        except Exception:
            pass

    # ── Scrawl-Hüllkurven ─────────────────────────────────────────────────

    def _on_buzz_scrawl_changed(self, pts: list) -> None:
        self._bake_buzz_scrawl(pts)
        self._schedule_persist()

    def _on_flutter_scrawl_changed(self, pts: list) -> None:
        self._bake_flutter_scrawl(pts)
        self._schedule_persist()

    def _bake_buzz_scrawl(self, pts: Optional[list] = None) -> None:
        if pts is None:
            pts = self._buzz_scrawl.canvas.get_points()
        if not pts:
            self.engine.buzz_scrawl_table = None
            return
        tbl = _interp_scrawl(pts, 256)
        # Normalisieren auf 0..1 (Amplitude)
        tbl = (np.array(tbl) + 1.0) * 0.5
        self.engine.buzz_scrawl_table = tbl.astype(np.float64)

    def _bake_flutter_scrawl(self, pts: Optional[list] = None) -> None:
        if pts is None:
            pts = self._flutter_scrawl.canvas.get_points()
        if not pts:
            self.engine.flutter_scrawl_table = None
            return
        tbl = _interp_scrawl(pts, 256)
        tbl = (np.array(tbl) + 1.0) * 0.5
        self.engine.flutter_scrawl_table = tbl.astype(np.float64)

    # ── Preset-Verwaltung ─────────────────────────────────────────────────

    def _on_preset_selected(self, idx: int) -> None:
        name = self._preset_combo.currentText()
        preset = BRRR_PRESETS.get(name)
        if preset:
            self._apply_preset(preset)

    def _apply_preset(self, preset: dict) -> None:
        self._restoring_state = True
        try:
            self.engine.import_state(preset)
            # Knobs aktualisieren
            for attr, (knob, scale) in self._knobs.items():
                val = preset.get(attr)
                if val is not None:
                    raw = int(round(float(val) / scale)) if scale != 0 else int(val)
                    knob.blockSignals(True)
                    try:
                        knob.setValue(raw)
                    finally:
                        knob.blockSignals(False)
        finally:
            self._restoring_state = False
        self._schedule_persist()
        # BR-3: Sync all params to Rust after preset change
        self._sync_all_to_rust()

    def _save_preset_file(self) -> None:
        name, ok = QInputDialog.getText(self, "Preset speichern", "Preset-Name:")
        if not ok or not name.strip():
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Preset speichern", str(Path.home() / f"{name}.brrr.json"),
            "BRRR Preset (*.brrr.json *.json)"
        )
        if not path:
            return
        state = self.engine.export_state()
        state["preset_name"] = name.strip()
        # Scrawl-Punkte
        state["buzz_scrawl_pts"]    = self._buzz_scrawl.canvas.get_points()
        state["flutter_scrawl_pts"] = self._flutter_scrawl.canvas.get_points()
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(state, f, indent=2)
        except Exception as e:
            from PyQt6.QtWidgets import QMessageBox
            QMessageBox.warning(self, "Fehler", str(e))

    def _load_preset_file(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Preset laden", str(Path.home()),
            "BRRR Preset (*.brrr.json *.json)"
        )
        if not path or not os.path.isfile(path):
            return
        try:
            with open(path, encoding="utf-8") as f:
                state = json.load(f)
        except Exception as e:
            from PyQt6.QtWidgets import QMessageBox
            QMessageBox.warning(self, "Fehler", str(e))
            return
        self._apply_preset(state)
        # Scrawl-Punkte wiederherstellen
        bsp = state.get("buzz_scrawl_pts")
        if bsp:
            self._buzz_scrawl.set_points([(float(p[0]), float(p[1])) for p in bsp])
        fsp = state.get("flutter_scrawl_pts")
        if fsp:
            self._flutter_scrawl.set_points([(float(p[0]), float(p[1])) for p in fsp])

    # ── State-Persistenz (Projekt-Save) ───────────────────────────────────

    def _schedule_persist(self) -> None:
        if not self._restoring_state:
            self._persist_timer.start()

    def _persist_state(self) -> None:
        if self._restoring_state:
            return
        try:
            ps = self.project_service
            if not ps or not self.track_id:
                return
            proj = getattr(getattr(ps, 'ctx', None), 'project', None)
            if not proj:
                return
            trk = next((t for t in proj.tracks if t.id == self.track_id), None)
            if not trk:
                return
            state = self.engine.export_state()
            state["buzz_scrawl_pts"]    = self._buzz_scrawl.canvas.get_points()
            state["flutter_scrawl_pts"] = self._flutter_scrawl.canvas.get_points()
            if not isinstance(getattr(trk, 'instrument_state', None), dict):
                trk.instrument_state = {}
            trk.instrument_state[self.PLUGIN_STATE_KEY] = state
            # v0.0.20.760: NICHT _emit_updated() aufrufen!
            # Das löst eine komplette UI-Rebuild aller Widgets aus und friert die GUI ein.
            # Der State wird beim nächsten project_save korrekt mitgespeichert.
        except Exception:
            pass

    def _restore_state(self) -> None:
        try:
            ps = self.project_service
            if not ps or not self.track_id:
                return
            proj = getattr(getattr(ps, 'ctx', None), 'project', None)
            if not proj:
                return
            trk = next((t for t in proj.tracks if t.id == self.track_id), None)
            if not trk:
                return
            ist = getattr(trk, 'instrument_state', None) or {}
            state = ist.get(self.PLUGIN_STATE_KEY)
            if not isinstance(state, dict):
                return
            self._restoring_state = True
            try:
                self._apply_preset(state)
                bsp = state.get("buzz_scrawl_pts")
                if bsp:
                    self._buzz_scrawl.set_points([(float(p[0]),float(p[1])) for p in bsp])
                    self._bake_buzz_scrawl(bsp)
                fsp = state.get("flutter_scrawl_pts")
                if fsp:
                    self._flutter_scrawl.set_points([(float(p[0]),float(p[1])) for p in fsp])
                    self._bake_flutter_scrawl(fsp)
            finally:
                self._restoring_state = False
            # BR-3: Sync all params to Rust after state restore
            self._sync_all_to_rust()
        except Exception:
            self._restoring_state = False

    # ── Automation + MIDI Learn ─────────────────────────────────────────

    def _setup_automation(self) -> None:
        """Bind all knobs to AutomationManager → Rechtsklick-Menü + MIDI Learn."""
        try:
            am = self.automation_manager
            tid = self.track_id or ''
            if not am or not tid:
                return
            for attr, (knob, scale) in self._knobs.items():
                try:
                    pid = f"trk:{tid}:brrr:{attr}"
                    if getattr(knob, '_parameter_id', '') == pid:
                        continue
                    lo = float(knob.minimum())
                    hi = float(knob.maximum())
                    knob.bind_automation(
                        am, pid,
                        name=f"BRRR {attr}",
                        track_id=tid,
                        minimum=lo,
                        maximum=hi,
                        default=float(knob.value()),
                    )
                except Exception:
                    pass
        except Exception:
            pass

    # ── Styles ────────────────────────────────────────────────────────────

    def _apply_styles(self) -> None:
        self.setStyleSheet("""
            QGroupBox {
                border: 1px solid #444;
                border-radius: 5px;
                margin-top: 8px;
                font-size: 10px;
                color: #bbb;
                padding-top: 6px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 8px;
            }
            QTabWidget::pane { border: 1px solid #444; }
            QTabBar::tab { padding: 3px 10px; font-size: 10px; }
            QTabBar::tab:selected { background: #333; color: #ff9800; }
        """)


# ── Scrawl-Interpolation ──────────────────────────────────────────────────────

def _interp_scrawl(points: list, n: int = 256) -> list:
    """Interpoliert Scrawl-Punkte auf n Samples (linear)."""
    if not points:
        return [0.0] * n
    pts = sorted(points, key=lambda p: p[0])
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    out = []
    for i in range(n):
        t = i / (n - 1)
        # Lineare Interpolation
        for j in range(len(xs) - 1):
            if xs[j] <= t <= xs[j + 1]:
                span = xs[j + 1] - xs[j]
                if span < 1e-9:
                    out.append(float(ys[j]))
                else:
                    frac = (t - xs[j]) / span
                    out.append(float(ys[j] + frac * (ys[j + 1] - ys[j])))
                break
        else:
            out.append(float(ys[-1]) if t >= xs[-1] else float(ys[0]))
    return out
