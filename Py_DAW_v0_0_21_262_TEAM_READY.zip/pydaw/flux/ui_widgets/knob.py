"""
pydaw.flux.ui_widgets.knob — AnimatedKnob (Phase U-1)
=====================================================

PureData-/Max-for-Live-Style rundes Knob-Widget mit Lerp-Animation.

**Eingebaut in v0.0.21.194** — erstes der FLUX-PD-Widgets aus
`PROJECT_DOCS/FLUX_UI_MODULES_ROADMAP.md` Phase U-1.

Akzeptanz-Kriterien
-------------------

✅ Rundes Knob-Widget mit Arc-Indikator (LED-Ring)
✅ Lerp-Animation (16ms-Frame, 0.2 Lerp-Faktor) — sanftes Einschwingen
✅ Vertikales Drag = Wert (oben = mehr, unten = weniger)
✅ Horizontales Drag (oder Shift+Drag) = Fine-Tune (Faktor 0.1)
✅ Doppelklick = Reset auf Default
✅ Mausrad = Wert ±1 Step (Step = Range/100)
✅ Value-Tooltip (Hover) + Value-Label unter dem Knob
✅ Behält die `param_changed(name, value)`-Signal-Architektur

Architektur
-----------

::

    AnimatedKnob (QWidget)
      ├── _value_target   ← was der User aktuell drehen will
      ├── _value_displayed ← was tatsächlich gemalt wird (lerpt zum Target)
      ├── _animation_timer (QTimer, 16 ms) ← treibt _value_displayed an
      └── value_changed(float)   ← Signal feuert nur bei _value_target-Änderung

Das **Lerp** ist rein visuell — das `value_changed`-Signal feuert
**sofort** wenn der User dreht, NICHT erst wenn die Animation
abgeschlossen ist. So bleibt das Audio-Feedback in Echtzeit, während
das visuelle Feedback weich nachgleitet.

Nichts-Kaputt-Garantie
----------------------

* Reines Qt-Widget — kein Audio-Code, kein IPC, kein Threading
* Falls PyQt6 fehlt → Datei lädt zwar, `AnimatedKnob` ist aber `None`
  (analog zur _QT_AVAILABLE-Logik in `flux_main_widget.py`)
"""

from __future__ import annotations

import logging
import math
from typing import Optional

logger = logging.getLogger(__name__)


# ─── Qt-Verfügbarkeit ─────────────────────────────────────────────

try:
    from PyQt6.QtCore import (
        Qt, QPointF, QRectF, QSize, QTimer, pyqtSignal,
    )
    from PyQt6.QtGui import (
        QColor, QPainter, QPen, QBrush, QFont, QPainterPath,
        QLinearGradient, QRadialGradient, QMouseEvent, QWheelEvent,
        QPaintEvent,
    )
    from PyQt6.QtWidgets import QWidget, QSizePolicy, QToolTip
    _QT_AVAILABLE = True
except ImportError:
    _QT_AVAILABLE = False


# ─── Hilfs-Funktionen ─────────────────────────────────────────────


def _clamp(x: float, lo: float, hi: float) -> float:
    """Klammere x in das Intervall [lo, hi]."""
    if lo > hi:
        lo, hi = hi, lo
    return max(lo, min(hi, x))


def _lerp(a: float, b: float, t: float) -> float:
    """Lineare Interpolation a → b mit Faktor t∈[0,1]."""
    return a + (b - a) * t


def _format_value(value: float, unit: str, max_abs: float) -> str:
    """Formatiere einen Float so dass er aussieht wie ein typischer
    DAW-Knob-Wert — abhängig von der Größenordnung des Wertebereichs.

    Beispiele
    ---------
    >>> _format_value(440.0, "Hz", 20000.0)
    '440 Hz'
    >>> _format_value(0.5, "", 1.0)
    '0.50'
    >>> _format_value(-12.3, "dB", 24.0)
    '-12.3 dB'
    """
    abs_v = abs(value)
    if max_abs >= 1000:
        # Kilo-Range (Hz, ms): keine Nachkommastellen oberhalb 100
        if abs_v >= 100:
            text = f"{value:.0f}"
        elif abs_v >= 10:
            text = f"{value:.1f}"
        else:
            text = f"{value:.2f}"
    elif max_abs >= 10:
        # 1..100-Range: 1 Nachkommastelle
        text = f"{value:.1f}"
    else:
        # 0..1-Range: 2 Nachkommastellen
        text = f"{value:.2f}"
    return f"{text} {unit}".strip()


# ─── Hauptklasse ──────────────────────────────────────────────────


if _QT_AVAILABLE:

    class AnimatedKnob(QWidget):  # type: ignore[misc]
        """Rundes, animiertes Knob-Widget im PureData-/Max-Stil.

        Signale
        -------
        ``value_changed(float)`` — feuert sofort wenn der User dreht
            (drag, mouse wheel, double-click reset). Feuert NICHT für
            jeden Animationsframe — nur bei tatsächlicher User-Änderung.

        Parameter
        ---------
        name
            Param-Name (z.B. "freq"). Wird im Tooltip angezeigt.
        value
            Initialwert.
        minimum, maximum
            Wertebereich. ``maximum > minimum`` wird sichergestellt;
            falls sie gleich sind, ist das Knob fest auf ``minimum``.
        default
            Wert für Doppelklick-Reset. Falls ``None`` → Initial-Value.
        unit
            Anzeige-Einheit ("Hz", "dB", "ms", …).
        compact
            Wenn ``True``, kein Label unter dem Knob — nur das Knob.
            Default ``False`` zeigt einen kleinen Wert-Text drunter.
        """

        # Lerp-Konstanten (aus FLUX_UI_MODULES_ROADMAP.md U-1)
        ANIM_INTERVAL_MS = 16          # ~60 fps
        ANIM_LERP_FACTOR = 0.20        # 20 % der Differenz pro Frame
        ANIM_EPSILON = 1e-4            # Stop-Schwelle (relativ zur Range)

        # Drag-Verhalten
        DRAG_PIXELS_FOR_FULL_RANGE = 200      # 200 px vertikal = 0..max
        DRAG_FINE_TUNE_DIVISOR = 10           # Shift = Faktor 10 langsamer
        WHEEL_STEPS_PER_RANGE = 100           # 1 Wheel-Step = 1/100 Range

        # Geometrie
        DEFAULT_KNOB_SIZE = 44                # Pixel — kompakt
        ARC_START_DEG = -135                  # Knob-Anfangswinkel (links unten)
        ARC_SPAN_DEG = 270                    # Knob-Drehbereich
        ARC_THICKNESS = 4                     # Pixel — LED-Ring

        # Farben (FLUX-Stil, harmoniert mit flux_main_widget.py)
        COL_RING_BG = "#1a1f29"               # leerer Ring
        COL_RING_ACTIVE = "#3df0e0"           # aktiver Arc (cyan)
        COL_BODY_OUTER = "#0a0e14"            # Knob-Außenring
        COL_BODY_INNER = "#13181f"            # Knob-Mitte
        COL_INDICATOR = "#7df0e0"             # Wert-Indikator (Strich)
        COL_TEXT = "#e6edf3"                  # Text (Wert + Label)
        COL_TEXT_DIM = "#8b949e"              # gedimmter Text

        value_changed = pyqtSignal(float)

        def __init__(
            self,
            name: str = "param",
            value: float = 0.0,
            minimum: float = 0.0,
            maximum: float = 1.0,
            default: Optional[float] = None,
            unit: str = "",
            compact: bool = False,
            parent=None,
        ):
            super().__init__(parent)
            self._name = str(name)
            # Robust gegen min == max (würde Division durch Null geben)
            if maximum <= minimum:
                # Erlaube degenerate Range mit Δ=1 als Fallback
                maximum = minimum + 1.0
            self._minimum = float(minimum)
            self._maximum = float(maximum)
            self._default = float(default) if default is not None else float(value)
            self._unit = str(unit)
            self._compact = bool(compact)

            # Wertepaar: Target = Logik-Wert, Displayed = visuelle Animation
            self._value_target = _clamp(float(value), self._minimum, self._maximum)
            self._value_displayed = self._value_target

            # Drag-State
            self._dragging = False
            self._drag_origin_y = 0
            self._drag_origin_x = 0
            self._drag_origin_value = 0.0
            self._drag_fine = False  # Shift gehalten

            # Animation-Timer (lazy — startet nur bei Δ)
            self._timer = QTimer(self)
            self._timer.setInterval(self.ANIM_INTERVAL_MS)
            self._timer.timeout.connect(self._tick_animation)

            # Größen-Setup — kompaktes Layout
            base = self.DEFAULT_KNOB_SIZE
            label_h = 0 if self._compact else 14
            self.setMinimumSize(base, base + label_h)
            self.setMaximumSize(base + 8, base + label_h + 4)
            self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)

            self.setMouseTracking(True)
            self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
            self.setToolTip(self._tooltip_text())

        # ─── Public API ──────────────────────────────────────────

        @property
        def value(self) -> float:
            """Aktueller logischer Wert (Target — was an die Engine geht)."""
            return self._value_target

        @property
        def name(self) -> str:
            return self._name

        @property
        def minimum(self) -> float:
            return self._minimum

        @property
        def maximum(self) -> float:
            return self._maximum

        def set_value(self, value: float, *, emit_signal: bool = True) -> None:
            """Setze einen neuen Zielwert. Animiert sanft dorthin.

            Wenn ``emit_signal=False``, wird das ``value_changed``-Signal
            nicht gefeuert (z.B. für externe Sync wie SpinBox→Knob, um
            Echo-Loops zu vermeiden).
            """
            new_target = _clamp(float(value), self._minimum, self._maximum)
            if new_target == self._value_target:
                return
            self._value_target = new_target
            if emit_signal:
                self.value_changed.emit(self._value_target)
            # Animation starten falls noch nicht laufend
            if not self._timer.isActive():
                self._timer.start()
            self.setToolTip(self._tooltip_text())
            # Sofortiges Repaint schadet nicht — der Lerp tickert weiter
            self.update()

        def set_value_immediate(self, value: float, *, emit_signal: bool = False) -> None:
            """Springe ohne Animation auf einen Wert. Nützlich für initiales
            Laden eines Patches, damit nicht alle Knobs gleichzeitig hochlerpen.
            """
            new_target = _clamp(float(value), self._minimum, self._maximum)
            self._value_target = new_target
            self._value_displayed = new_target
            if emit_signal:
                self.value_changed.emit(self._value_target)
            self._timer.stop()
            self.setToolTip(self._tooltip_text())
            self.update()

        def reset_to_default(self) -> None:
            """Doppelklick-Verhalten: zurück auf Default-Wert."""
            self.set_value(self._default, emit_signal=True)

        # ─── Animation ───────────────────────────────────────────

        def _tick_animation(self) -> None:
            """Wird vom Timer alle 16ms aufgerufen — lerpt
            ``_value_displayed`` Richtung ``_value_target``."""
            range_ = self._maximum - self._minimum
            if range_ <= 0:
                self._value_displayed = self._value_target
                self._timer.stop()
                self.update()
                return
            delta = self._value_target - self._value_displayed
            if abs(delta) < range_ * self.ANIM_EPSILON:
                # Snap: dicht genug, Animation beenden
                self._value_displayed = self._value_target
                self._timer.stop()
                self.update()
                return
            self._value_displayed = _lerp(
                self._value_displayed, self._value_target, self.ANIM_LERP_FACTOR
            )
            self.update()

        # ─── Drag / Mouse / Wheel ────────────────────────────────

        def mousePressEvent(self, event):  # type: ignore[override]
            if event.button() == Qt.MouseButton.LeftButton:
                self._dragging = True
                self._drag_origin_y = event.position().y()
                self._drag_origin_x = event.position().x()
                self._drag_origin_value = self._value_target
                self._drag_fine = bool(
                    event.modifiers() & Qt.KeyboardModifier.ShiftModifier
                )
                self.setCursor(Qt.CursorShape.SizeVerCursor)
                event.accept()
            else:
                super().mousePressEvent(event)

        def mouseMoveEvent(self, event):  # type: ignore[override]
            if not self._dragging:
                return
            # Shift-Status während Drag dynamisch — User darf mid-drag
            # auf Fine-Tune schalten
            self._drag_fine = bool(
                event.modifiers() & Qt.KeyboardModifier.ShiftModifier
            )
            dy = self._drag_origin_y - event.position().y()  # nach oben = positiv
            range_ = self._maximum - self._minimum
            sensitivity = self.DRAG_PIXELS_FOR_FULL_RANGE
            if self._drag_fine:
                sensitivity *= self.DRAG_FINE_TUNE_DIVISOR
            new_value = self._drag_origin_value + (dy / sensitivity) * range_
            new_value = _clamp(new_value, self._minimum, self._maximum)
            if new_value != self._value_target:
                self._value_target = new_value
                self.value_changed.emit(self._value_target)
                if not self._timer.isActive():
                    self._timer.start()
                self.setToolTip(self._tooltip_text())
                self.update()

        def mouseReleaseEvent(self, event):  # type: ignore[override]
            if event.button() == Qt.MouseButton.LeftButton and self._dragging:
                self._dragging = False
                self._drag_fine = False
                self.unsetCursor()
                event.accept()
            else:
                super().mouseReleaseEvent(event)

        def mouseDoubleClickEvent(self, event):  # type: ignore[override]
            if event.button() == Qt.MouseButton.LeftButton:
                self.reset_to_default()
                event.accept()
            else:
                super().mouseDoubleClickEvent(event)

        def wheelEvent(self, event):  # type: ignore[override]
            steps = event.angleDelta().y() / 120.0  # 1 Notch = 120
            if steps == 0:
                event.ignore()
                return
            range_ = self._maximum - self._minimum
            divisor = self.WHEEL_STEPS_PER_RANGE
            if event.modifiers() & Qt.KeyboardModifier.ShiftModifier:
                divisor *= self.DRAG_FINE_TUNE_DIVISOR  # Shift+Wheel = fein
            step = range_ / divisor
            self.set_value(self._value_target + steps * step, emit_signal=True)
            event.accept()

        # ─── Painting ────────────────────────────────────────────

        def _value_to_angle_deg(self, value: float) -> float:
            """Wert → Winkel im Bogen (relativ zu START_DEG)."""
            range_ = self._maximum - self._minimum
            if range_ <= 0:
                return 0.0
            t = (value - self._minimum) / range_
            t = _clamp(t, 0.0, 1.0)
            return self.ARC_START_DEG + t * self.ARC_SPAN_DEG

        def paintEvent(self, event):  # type: ignore[override]
            painter = QPainter(self)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            painter.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)

            w = self.width()
            h = self.height()
            label_h = 0 if self._compact else 14
            knob_h = h - label_h
            knob_d = min(w, knob_h) - 2  # 1 px Rand oben/unten
            cx = w / 2.0
            cy = knob_h / 2.0 + 1
            r_outer = knob_d / 2.0
            r_inner = r_outer - self.ARC_THICKNESS - 1
            if r_inner < 4:
                r_inner = 4

            # 1) Hintergrund-Ring (leerer Bogen)
            ring_rect = QRectF(
                cx - r_outer, cy - r_outer,
                2 * r_outer, 2 * r_outer,
            )
            pen_bg = QPen(QColor(self.COL_RING_BG))
            pen_bg.setWidth(self.ARC_THICKNESS)
            pen_bg.setCapStyle(Qt.PenCapStyle.FlatCap)
            painter.setPen(pen_bg)
            painter.setBrush(Qt.BrushStyle.NoBrush)
            # Qt: drawArc misst in 16tel Grad, 0° = 3 Uhr, gegen Uhrzeigersinn
            # Wir wollen Start unten-links (-135° in Uhrzeigersinn-Koord) und
            # 270° in Uhrzeigersinn. → Start_Qt = 180+45 = 225°, Span_Qt = -270°
            qt_start = int(225 * 16)
            qt_span_full = int(-270 * 16)
            painter.drawArc(ring_rect, qt_start, qt_span_full)

            # 2) Aktiver Arc (Wert-Ring) — basiert auf displayed (animiert!)
            range_ = self._maximum - self._minimum
            if range_ > 0:
                t_disp = (self._value_displayed - self._minimum) / range_
                t_disp = _clamp(t_disp, 0.0, 1.0)
                qt_span_active = int(-270 * t_disp * 16)
                pen_fg = QPen(QColor(self.COL_RING_ACTIVE))
                pen_fg.setWidth(self.ARC_THICKNESS)
                pen_fg.setCapStyle(Qt.PenCapStyle.RoundCap)
                painter.setPen(pen_fg)
                painter.drawArc(ring_rect, qt_start, qt_span_active)

            # 3) Knob-Body (Kreis mit Gradient)
            body_rect = QRectF(
                cx - r_inner, cy - r_inner,
                2 * r_inner, 2 * r_inner,
            )
            grad = QRadialGradient(QPointF(cx, cy - r_inner * 0.3), r_inner * 1.2)
            grad.setColorAt(0.0, QColor(self.COL_BODY_INNER).lighter(140))
            grad.setColorAt(0.7, QColor(self.COL_BODY_INNER))
            grad.setColorAt(1.0, QColor(self.COL_BODY_OUTER))
            painter.setBrush(QBrush(grad))
            outline_pen = QPen(QColor(self.COL_BODY_OUTER))
            outline_pen.setWidth(1)
            painter.setPen(outline_pen)
            painter.drawEllipse(body_rect)

            # 4) Wert-Indikator (Strich vom Mittelpunkt nach außen)
            angle_deg = self._value_to_angle_deg(self._value_displayed)
            # Drehe in Qt-Koordinaten: 0° = 3 Uhr, math.cos/sin sind ok
            # Unsere ARC_START -135° entspricht "links unten" in geometrischer
            # Standard-Koord (x rechts, y oben). Qt y wächst nach unten →
            # wir negieren sin().
            angle_rad = math.radians(angle_deg)
            ix1 = cx + math.cos(angle_rad) * (r_inner * 0.30)
            iy1 = cy - math.sin(angle_rad) * (r_inner * 0.30)
            ix2 = cx + math.cos(angle_rad) * (r_inner * 0.85)
            iy2 = cy - math.sin(angle_rad) * (r_inner * 0.85)
            indicator_pen = QPen(QColor(self.COL_INDICATOR))
            indicator_pen.setWidth(2)
            indicator_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
            painter.setPen(indicator_pen)
            painter.drawLine(QPointF(ix1, iy1), QPointF(ix2, iy2))

            # 5) Optional: Wert-Label unter dem Knob
            if not self._compact and label_h > 0:
                f = QFont("monospace", 7)
                painter.setFont(f)
                painter.setPen(QColor(self.COL_TEXT_DIM))
                # Auf Drag oder bei Animation den AKTUELLEN Target-Wert
                # zeigen, sonst displayed (für sanften Fade)
                shown = self._value_target if self._dragging else self._value_displayed
                txt = _format_value(shown, self._unit, abs(self._maximum) + abs(self._minimum) + 1)
                rect = QRectF(0, knob_h, w, label_h)
                painter.drawText(
                    rect, int(Qt.AlignmentFlag.AlignCenter), txt,
                )

            painter.end()

        # ─── Tooltip / Diagnose ──────────────────────────────────

        def _tooltip_text(self) -> str:
            """Mehrzeiliger Tooltip mit Wert + Range + Bedienungs-Hinweisen."""
            v = _format_value(
                self._value_target, self._unit,
                abs(self._maximum) + abs(self._minimum) + 1,
            )
            range_text = (
                f"{self._minimum:g} … {self._maximum:g}"
                + (f" {self._unit}" if self._unit else "")
            )
            return (
                f"<b>{self._name}</b>: {v}<br>"
                f"<span style='color:#8b949e;'>Range: {range_text}<br>"
                f"Default: {self._default:g}<br>"
                f"Drag = Wert · Shift = Fine · 2× Klick = Reset · Wheel = Step</span>"
            )

        def sizeHint(self):  # type: ignore[override]
            base = self.DEFAULT_KNOB_SIZE
            label_h = 0 if self._compact else 14
            return QSize(base + 4, base + label_h + 2)

else:
    # Qt fehlt — wir bieten ein None-Symbol an, damit Import nicht scheitert.
    AnimatedKnob = None  # type: ignore[assignment,misc]
    logger.debug("[FLUX-UI] AnimatedKnob: PyQt6 nicht verfügbar — Widget deaktiviert")


__all__ = ["AnimatedKnob"]
