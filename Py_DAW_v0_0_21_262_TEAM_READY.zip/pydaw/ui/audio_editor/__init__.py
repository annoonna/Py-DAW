"""Audio clip editor UI."""
