"""video_interchange_export.py — AAF/XML/OMF/EDL Export for VE16 (v0.0.20.951).

Professional NLE interchange export:
  - AAF (Advanced Authoring Format) — Pro Tools compatible
  - FCP XML (Final Cut Pro XML) — DaVinci/Premiere compatible
  - OMF (Open Media Framework) — Legacy interchange
  - EDL (Edit Decision List) — CMX 3600 standard

Architecture:
  Each export function takes a video project state (clips, transitions,
  effects) and writes the corresponding interchange file format.
  Uses the existing clip data from VideoStateDB and project model.

What NO other DAW has:
  - NLE interchange export from inside a music DAW
  - Beat-position to timecode conversion for export
  - Combined audio+video timeline export

Usage:
    from pydaw.services.video_interchange_export import (
        export_xml, export_edl, export_aaf_stub, export_omf_stub)
    export_xml(project_data, "/path/output.xml")
    export_edl(project_data, "/path/output.edl", fps=24.0)
"""

from __future__ import annotations

import json
import logging
import os
import time
import uuid
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple
from xml.dom import minidom

log = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# Project data extraction
# ═══════════════════════════════════════════════════════════════

@dataclass
class ExportClip:
    """A clip for interchange export."""
    clip_id: str = ""
    name: str = ""
    file_path: str = ""
    track_index: int = 0
    start_time: float = 0.0     # seconds on timeline
    end_time: float = 0.0       # seconds on timeline
    source_in: float = 0.0      # seconds in source file
    source_out: float = 0.0     # seconds in source file
    opacity: float = 1.0
    speed: float = 1.0
    is_video: bool = True
    is_audio: bool = True
    transition_in: str = ""     # dissolve, wipe, etc.
    transition_duration: float = 0.0

    @property
    def duration(self) -> float:
        return self.end_time - self.start_time

    @property
    def source_duration(self) -> float:
        return self.source_out - self.source_in


@dataclass
class ExportProject:
    """Project data for interchange export."""
    name: str = "Py_DAW Project"
    fps: float = 24.0
    sample_rate: int = 48000
    width: int = 1920
    height: int = 1080
    clips: List[ExportClip] = field(default_factory=list)
    bpm: float = 120.0
    duration: float = 0.0


def _seconds_to_tc(seconds: float, fps: float = 24.0,
                    drop_frame: bool = False) -> str:
    """Convert seconds to SMPTE timecode HH:MM:SS:FF."""
    if seconds < 0:
        seconds = 0
    total_frames = int(round(seconds * fps))

    if drop_frame and fps in (29.97, 59.94):
        # Drop-frame calculation
        d = int(fps / 29.97)
        frames_per_min = int(round(fps * 60))
        frames_per_10min = int(round(fps * 600))
        drop_per_min = 2 * d

        tens = total_frames // frames_per_10min
        remainder = total_frames % frames_per_10min
        if remainder < drop_per_min:
            frames_adj = total_frames
        else:
            frames_adj = total_frames + drop_per_min * (
                (remainder - drop_per_min) // (frames_per_min - drop_per_min) + 1)

        f = frames_adj % int(round(fps))
        s = (frames_adj // int(round(fps))) % 60
        m = (frames_adj // (int(round(fps)) * 60)) % 60
        h = frames_adj // (int(round(fps)) * 3600)
        sep = ";"
    else:
        f_int = int(round(fps))
        f = total_frames % f_int
        s = (total_frames // f_int) % 60
        m = (total_frames // (f_int * 60)) % 60
        h = total_frames // (f_int * 3600)
        sep = ":"

    return f"{h:02d}:{m:02d}:{s:02d}{sep}{f:02d}"


def _seconds_to_frames(seconds: float, fps: float = 24.0) -> int:
    """Convert seconds to frame count."""
    return int(round(seconds * fps))


# ═══════════════════════════════════════════════════════════════
# EDL Export (CMX 3600)
# ═══════════════════════════════════════════════════════════════

def export_edl(project: ExportProject, output_path: str,
                title: str = "", fps: float = 0) -> bool:
    """Export as CMX 3600 Edit Decision List.
    
    Standard EDL format used by all major NLEs.
    
    Args:
        project: ExportProject with clips
        output_path: Where to save the .edl file
        title: EDL title (defaults to project name)
        fps: Override FPS (0 = use project fps)
    
    Returns:
        True if export successful
    """
    try:
        fps = fps or project.fps
        title = title or project.name

        lines = [
            f"TITLE: {title}",
            f"FCM: {'DROP FRAME' if fps in (29.97, 59.94) else 'NON-DROP FRAME'}",
            "",
        ]

        edit_num = 1
        for clip in sorted(project.clips, key=lambda c: c.start_time):
            # EDL format: edit# reel_name channel transition
            # source_in source_out record_in record_out
            reel = os.path.splitext(os.path.basename(clip.file_path))[0][:8]
            reel = reel.upper().replace(" ", "_")

            if clip.is_video and clip.is_audio:
                channel = "AA/V"
            elif clip.is_video:
                channel = "V"
            else:
                channel = "AA"

            # Transition
            if clip.transition_in and clip.transition_in != "cut":
                trans = "D"  # Dissolve
                trans_dur = _seconds_to_frames(clip.transition_duration, fps)
                trans_str = f"{trans}    {trans_dur:03d}"
            else:
                trans_str = "C"

            src_in = _seconds_to_tc(clip.source_in, fps)
            src_out = _seconds_to_tc(clip.source_out, fps)
            rec_in = _seconds_to_tc(clip.start_time, fps)
            rec_out = _seconds_to_tc(clip.end_time, fps)

            line = (f"{edit_num:03d}  {reel:<8s} {channel:<5s} "
                    f"{trans_str:<8s} "
                    f"{src_in} {src_out} {rec_in} {rec_out}")
            lines.append(line)

            # Speed effect
            if abs(clip.speed - 1.0) > 0.01:
                speed_fps = fps * clip.speed
                lines.append(f"M2   {reel:<8s} {speed_fps:07.2f} "
                             f"{src_in}")

            # File path comment
            lines.append(f"* FROM CLIP NAME: {clip.name or clip.file_path}")
            lines.append(f"* SOURCE FILE: {clip.file_path}")
            lines.append("")

            edit_num += 1

        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")

        log.info("EDL exported: %s (%d edits)", output_path, edit_num - 1)
        return True

    except Exception as exc:
        log.error("EDL export failed: %s", exc)
        return False


# ═══════════════════════════════════════════════════════════════
# FCP XML Export
# ═══════════════════════════════════════════════════════════════

def export_xml(project: ExportProject, output_path: str) -> bool:
    """Export as Final Cut Pro XML (FCPXML-like).
    
    Compatible with DaVinci Resolve, Premiere Pro, Final Cut.
    
    Args:
        project: ExportProject with clips
        output_path: Where to save the .xml file
    
    Returns:
        True if export successful
    """
    try:
        fps = project.fps
        timebase = int(round(fps))

        root = ET.Element("xmeml", version="5")
        seq = ET.SubElement(root, "sequence")

        ET.SubElement(seq, "name").text = project.name
        ET.SubElement(seq, "duration").text = str(
            _seconds_to_frames(project.duration, fps))

        rate = ET.SubElement(seq, "rate")
        ET.SubElement(rate, "timebase").text = str(timebase)
        ET.SubElement(rate, "ntsc").text = (
            "TRUE" if fps in (23.976, 29.97, 59.94) else "FALSE")

        # Timecode
        tc = ET.SubElement(seq, "timecode")
        tc_rate = ET.SubElement(tc, "rate")
        ET.SubElement(tc_rate, "timebase").text = str(timebase)
        ET.SubElement(tc, "string").text = "00:00:00:00"
        ET.SubElement(tc, "frame").text = "0"
        ET.SubElement(tc, "displayformat").text = (
            "DF" if fps in (29.97, 59.94) else "NDF")

        media = ET.SubElement(seq, "media")

        # Video track
        video = ET.SubElement(media, "video")
        fmt = ET.SubElement(video, "format")
        sc = ET.SubElement(fmt, "samplecharacteristics")
        ET.SubElement(sc, "width").text = str(project.width)
        ET.SubElement(sc, "height").text = str(project.height)

        vtrack = ET.SubElement(video, "track")

        for clip in sorted(project.clips,
                            key=lambda c: c.start_time):
            if not clip.is_video:
                continue

            clipitem = ET.SubElement(vtrack, "clipitem",
                                     id=clip.clip_id or str(uuid.uuid4()))
            ET.SubElement(clipitem, "name").text = (
                clip.name or os.path.basename(clip.file_path))
            ET.SubElement(clipitem, "duration").text = str(
                _seconds_to_frames(clip.source_duration, fps))
            ET.SubElement(clipitem, "start").text = str(
                _seconds_to_frames(clip.start_time, fps))
            ET.SubElement(clipitem, "end").text = str(
                _seconds_to_frames(clip.end_time, fps))
            ET.SubElement(clipitem, "in").text = str(
                _seconds_to_frames(clip.source_in, fps))
            ET.SubElement(clipitem, "out").text = str(
                _seconds_to_frames(clip.source_out, fps))

            cr = ET.SubElement(clipitem, "rate")
            ET.SubElement(cr, "timebase").text = str(timebase)

            # File reference
            fref = ET.SubElement(clipitem, "file", id=f"file-{clip.clip_id}")
            ET.SubElement(fref, "name").text = os.path.basename(clip.file_path)
            ET.SubElement(fref, "pathurl").text = f"file://{clip.file_path}"

            media_ref = ET.SubElement(fref, "media")
            vmedia = ET.SubElement(media_ref, "video")
            vsc = ET.SubElement(vmedia, "samplecharacteristics")
            ET.SubElement(vsc, "width").text = str(project.width)
            ET.SubElement(vsc, "height").text = str(project.height)

            # Opacity filter
            if clip.opacity < 1.0:
                filt = ET.SubElement(clipitem, "filter")
                eff = ET.SubElement(filt, "effect")
                ET.SubElement(eff, "name").text = "Basic Motion"
                ET.SubElement(eff, "effectid").text = "opacity"
                ET.SubElement(eff, "effecttype").text = "motion"
                param = ET.SubElement(eff, "parameter")
                ET.SubElement(param, "parameterid").text = "opacity"
                ET.SubElement(param, "name").text = "Opacity"
                ET.SubElement(param, "value").text = str(clip.opacity * 100)

            # Speed effect
            if abs(clip.speed - 1.0) > 0.01:
                speed_el = ET.SubElement(clipitem, "timeMap")
                ET.SubElement(speed_el, "timemaptype").text = "speed"
                rate_el = ET.SubElement(speed_el, "rate")
                ET.SubElement(rate_el, "timebase").text = str(
                    int(round(fps * clip.speed)))

            # Transition
            if clip.transition_in and clip.transition_in != "cut":
                trans = ET.SubElement(clipitem, "transitionitem")
                ET.SubElement(trans, "name").text = clip.transition_in.title()
                ET.SubElement(trans, "duration").text = str(
                    _seconds_to_frames(clip.transition_duration, fps))
                ET.SubElement(trans, "alignment").text = "start"

        # Audio track
        audio = ET.SubElement(media, "audio")
        atrack = ET.SubElement(audio, "track")

        for clip in sorted(project.clips,
                            key=lambda c: c.start_time):
            if not clip.is_audio:
                continue

            aclip = ET.SubElement(atrack, "clipitem",
                                   id=f"a-{clip.clip_id}")
            ET.SubElement(aclip, "name").text = (
                clip.name or os.path.basename(clip.file_path))
            ET.SubElement(aclip, "start").text = str(
                _seconds_to_frames(clip.start_time, fps))
            ET.SubElement(aclip, "end").text = str(
                _seconds_to_frames(clip.end_time, fps))
            ET.SubElement(aclip, "in").text = str(
                _seconds_to_frames(clip.source_in, fps))
            ET.SubElement(aclip, "out").text = str(
                _seconds_to_frames(clip.source_out, fps))

            afref = ET.SubElement(aclip, "file",
                                   id=f"file-a-{clip.clip_id}")
            ET.SubElement(afref, "pathurl").text = f"file://{clip.file_path}"

        # Pretty print
        xml_str = ET.tostring(root, encoding="unicode")
        pretty = minidom.parseString(xml_str).toprettyxml(indent="  ")
        # Remove extra xml declaration
        pretty_lines = pretty.split("\n")
        if pretty_lines[0].startswith("<?xml"):
            pretty = "\n".join(pretty_lines[1:])
        pretty = '<?xml version="1.0" encoding="UTF-8"?>\n' + \
                 '<!DOCTYPE xmeml>\n' + pretty

        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(pretty)

        log.info("XML exported: %s (%d clips)", output_path,
                 len(project.clips))
        return True

    except Exception as exc:
        log.error("XML export failed: %s", exc)
        return False


# ═══════════════════════════════════════════════════════════════
# AAF Export (Stub — full AAF requires pyaaf2)
# ═══════════════════════════════════════════════════════════════

def export_aaf_stub(project: ExportProject, output_path: str) -> bool:
    """Export AAF (Advanced Authoring Format) — stub implementation.
    
    Full AAF export requires the pyaaf2 library.
    This stub creates a JSON manifest that can be converted
    to AAF using external tools.
    
    Compatible with Pro Tools, Media Composer.
    """
    try:
        manifest = {
            "format": "aaf_manifest",
            "version": "1.0",
            "project": project.name,
            "fps": project.fps,
            "sample_rate": project.sample_rate,
            "resolution": f"{project.width}x{project.height}",
            "clips": [],
        }

        for clip in sorted(project.clips, key=lambda c: c.start_time):
            manifest["clips"].append({
                "name": clip.name or os.path.basename(clip.file_path),
                "file": clip.file_path,
                "track": clip.track_index,
                "timeline_start_tc": _seconds_to_tc(
                    clip.start_time, project.fps),
                "timeline_end_tc": _seconds_to_tc(
                    clip.end_time, project.fps),
                "source_in_tc": _seconds_to_tc(
                    clip.source_in, project.fps),
                "source_out_tc": _seconds_to_tc(
                    clip.source_out, project.fps),
                "speed": clip.speed,
                "opacity": clip.opacity,
                "transition": clip.transition_in,
            })

        manifest["note"] = (
            "This is a Py_DAW AAF manifest. "
            "Use pyaaf2 or external AAF tools to convert to binary AAF. "
            "All timecodes are in the project frame rate."
        )

        # Save as .aaf.json (or .aaf if user expects binary)
        ext = os.path.splitext(output_path)[1]
        if ext.lower() == ".aaf":
            output_path = output_path + ".json"

        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=2, ensure_ascii=False)

        log.info("AAF manifest exported: %s (%d clips)",
                 output_path, len(project.clips))
        return True

    except Exception as exc:
        log.error("AAF export failed: %s", exc)
        return False


# ═══════════════════════════════════════════════════════════════
# OMF Export (Stub)
# ═══════════════════════════════════════════════════════════════

def export_omf_stub(project: ExportProject, output_path: str) -> bool:
    """Export OMF (Open Media Framework) — stub implementation.
    
    OMF is a legacy format. This creates a compatible EDL + manifest
    that can be used with OMF conversion tools.
    """
    try:
        # OMF is essentially a binary format; we export a companion
        # manifest plus an EDL which most tools can convert
        base = os.path.splitext(output_path)[0]
        edl_path = base + ".edl"
        manifest_path = base + ".omf.json"

        # Export EDL
        export_edl(project, edl_path)

        # Export manifest
        manifest = {
            "format": "omf_manifest",
            "version": "2.1",
            "project": project.name,
            "fps": project.fps,
            "sample_rate": project.sample_rate,
            "media_files": list(set(c.file_path for c in project.clips)),
            "clip_count": len(project.clips),
            "note": "OMF manifest + EDL. Use OMF tools to create binary OMF.",
        }

        os.makedirs(os.path.dirname(manifest_path) or ".", exist_ok=True)
        with open(manifest_path, "w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=2, ensure_ascii=False)

        log.info("OMF manifest exported: %s + %s", manifest_path, edl_path)
        return True

    except Exception as exc:
        log.error("OMF export failed: %s", exc)
        return False


# ═══════════════════════════════════════════════════════════════
# Convenience: Build ExportProject from DAW state
# ═══════════════════════════════════════════════════════════════

def build_export_project(project_service,
                          fps: float = 24.0) -> ExportProject:
    """Build ExportProject from current DAW project state.
    
    Extracts video clips, their properties, and timeline positions.
    """
    ep = ExportProject(fps=fps)

    try:
        ps = project_service
        proj = getattr(ps, 'project', None)
        if proj is None:
            ctx = getattr(ps, 'ctx', None)
            proj = getattr(ctx, 'project', None) if ctx else None
        if not proj:
            return ep

        ep.name = getattr(proj, 'name', 'Untitled')
        bpm = getattr(proj, 'bpm', 120.0)
        ep.bpm = bpm

        for clip in (proj.clips or []):
            kind = str(getattr(clip, 'kind', ''))
            if kind != 'video':
                continue

            file_path = str(getattr(clip, 'file_path', '') or
                           getattr(clip, 'path', ''))
            start_beat = float(getattr(clip, 'start', 0) or
                               getattr(clip, 'start_beat', 0))
            length_beats = float(getattr(clip, 'length', 0) or
                                  getattr(clip, 'length_beats', 0))

            start_sec = start_beat * 60.0 / bpm if bpm > 0 else 0
            end_sec = (start_beat + length_beats) * 60.0 / bpm if bpm > 0 else 0
            duration_sec = end_sec - start_sec

            ec = ExportClip(
                clip_id=str(getattr(clip, 'id', '')),
                name=str(getattr(clip, 'name', '') or
                         os.path.basename(file_path)),
                file_path=file_path,
                track_index=int(getattr(clip, 'track_index', 0)),
                start_time=start_sec,
                end_time=end_sec,
                source_in=0.0,
                source_out=duration_sec,
                is_video=True,
                is_audio=True,
            )

            # Load clip properties from DB
            try:
                from pydaw.services.video_state_db import VideoStateDB
                db = VideoStateDB.instance()
                props = db.load_clip_props(ec.clip_id)
                if props:
                    ec.opacity = props.get("opacity", 1.0)
                    ec.speed = props.get("speed", 1.0)
            except Exception:
                pass

            ep.clips.append(ec)

        if ep.clips:
            ep.duration = max(c.end_time for c in ep.clips)

    except Exception as exc:
        log.error("Build export project: %s", exc)

    return ep
