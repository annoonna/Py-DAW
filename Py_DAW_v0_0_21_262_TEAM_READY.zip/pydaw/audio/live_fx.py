"""Live Audio Effects (P4C) — Real-time buffer-based audio manipulation.

Designed for live performance use. All effects operate on ring buffers
and produce output in real-time audio callback context.

Features:
- Stutter: capture buffer → chop + retrigger
- Live Looper: record → overdub → play → stop (like Ableton Looper)
- Beat Repeat: rhythmic auto-repeat with variation

v0.0.20.808 — Phase P4C
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any

log = logging.getLogger(__name__)

try:
    import numpy as np
except Exception:
    np = None  # type: ignore


# ---------------------------------------------------------------------------
# Stutter Effect
# ---------------------------------------------------------------------------

@dataclass
class StutterConfig:
    """Configuration for stutter effect."""
    divisions: int = 8             # how many slices per beat
    active_slice: int = 0          # which slice to repeat (-1 = off)
    reverse: bool = False          # play slice backwards
    pitch_semitones: float = 0.0   # pitch shift on repeat
    gate: float = 1.0              # 0..1 gate length
    volume: float = 1.0            # 0..1
    enabled: bool = False


class StutterEffect:
    """Live stutter/glitch effect.

    Captures a buffer of audio and allows retriggering slices
    at various subdivisions, reversed, pitch-shifted.
    """

    def __init__(self, sr: int = 48000, max_beats: int = 4):
        self._sr = sr
        self._max_samples = int(max_beats * sr * 60.0 / 60.0)  # at 60 BPM minimum
        self._buffer: Optional["np.ndarray"] = None
        self._write_pos = 0
        self._config = StutterConfig()
        self._phase = 0  # playback phase within slice

    def set_config(self, config: StutterConfig) -> None:
        self._config = config

    def capture(self, audio: "np.ndarray") -> None:
        """Capture audio into stutter buffer."""
        if np is None:
            return
        audio = np.asarray(audio, dtype=np.float32).flatten()
        if self._buffer is None:
            self._buffer = np.zeros(self._max_samples, dtype=np.float32)
            self._write_pos = 0
        n = min(len(audio), self._max_samples - self._write_pos)
        if n > 0:
            self._buffer[self._write_pos:self._write_pos + n] = audio[:n]
            self._write_pos = (self._write_pos + n) % self._max_samples

    def process(self, frames: int, bpm: float = 120.0) -> "np.ndarray":
        """Generate stutter output for the given number of frames."""
        if np is None or self._buffer is None or not self._config.enabled:
            return np.zeros(frames, dtype=np.float32) if np else None

        cfg = self._config
        if cfg.active_slice < 0 or cfg.divisions < 1:
            return np.zeros(frames, dtype=np.float32)

        # Calculate slice length in samples
        beat_samples = int(self._sr * 60.0 / max(30.0, bpm))
        slice_samples = max(64, beat_samples // cfg.divisions)

        # Extract the active slice from buffer
        slice_start = (cfg.active_slice * slice_samples) % self._write_pos
        slice_end = min(slice_start + slice_samples, self._write_pos)
        slice_data = self._buffer[slice_start:slice_end].copy()

        if len(slice_data) < 16:
            return np.zeros(frames, dtype=np.float32)

        if cfg.reverse:
            slice_data = slice_data[::-1].copy()

        # Apply gate
        gate_samples = max(1, int(len(slice_data) * cfg.gate))
        if gate_samples < len(slice_data):
            slice_data[gate_samples:] = 0.0

        # Generate output by repeating slice
        output = np.zeros(frames, dtype=np.float32)
        pos = self._phase
        for i in range(frames):
            idx = pos % len(slice_data)
            output[i] = slice_data[idx] * cfg.volume
            pos += 1
        self._phase = pos % len(slice_data)

        return output

    def reset(self) -> None:
        self._phase = 0
        self._buffer = None
        self._write_pos = 0


# ---------------------------------------------------------------------------
# Live Looper
# ---------------------------------------------------------------------------

class LooperState:
    EMPTY = "empty"
    RECORDING = "recording"
    PLAYING = "playing"
    OVERDUBBING = "overdubbing"
    STOPPED = "stopped"


@dataclass
class LooperConfig:
    """Configuration for live looper."""
    max_bars: int = 16
    feedback: float = 1.0           # 0..1 overdub feedback
    half_speed: bool = False
    reverse: bool = False
    volume: float = 1.0
    input_monitor: bool = True


class LiveLooper:
    """Ableton-style live looper.

    State machine: Empty → Recording → Playing ↔ Overdubbing → Stopped

    Usage:
        looper.toggle()  # start recording
        looper.toggle()  # stop recording, start playing
        looper.toggle()  # start overdubbing
        looper.toggle()  # back to playing
        looper.stop()    # stop
        looper.clear()   # clear buffer
    """

    def __init__(self, sr: int = 48000, channels: int = 2):
        self._sr = sr
        self._channels = channels
        self._state = LooperState.EMPTY
        self._config = LooperConfig()
        self._buffer: Optional["np.ndarray"] = None
        self._loop_length = 0        # in samples
        self._play_pos = 0
        self._rec_pos = 0
        self._max_samples = int(sr * 60.0 / 60.0 * 4 * 16)  # 16 bars at 60 BPM

    @property
    def state(self) -> str:
        return self._state

    @property
    def loop_length_samples(self) -> int:
        return self._loop_length

    def set_config(self, config: LooperConfig) -> None:
        self._config = config
        self._max_samples = int(self._sr * 60.0 / 60.0 * 4 * config.max_bars)

    def toggle(self) -> str:
        """Toggle looper state. Returns new state."""
        if self._state == LooperState.EMPTY:
            self._start_recording()
            return self._state
        elif self._state == LooperState.RECORDING:
            self._stop_recording()
            return self._state
        elif self._state == LooperState.PLAYING:
            self._state = LooperState.OVERDUBBING
            return self._state
        elif self._state == LooperState.OVERDUBBING:
            self._state = LooperState.PLAYING
            return self._state
        elif self._state == LooperState.STOPPED:
            self._state = LooperState.PLAYING
            self._play_pos = 0
            return self._state
        return self._state

    def stop(self) -> None:
        if self._state == LooperState.RECORDING:
            self._stop_recording()
        self._state = LooperState.STOPPED

    def clear(self) -> None:
        self._buffer = None
        self._loop_length = 0
        self._play_pos = 0
        self._rec_pos = 0
        self._state = LooperState.EMPTY

    def undo(self) -> None:
        """Undo last overdub (simple: halve the overdub layer)."""
        if self._buffer is not None and self._loop_length > 0:
            self._buffer[:self._loop_length] *= self._config.feedback

    def _start_recording(self) -> None:
        if np is None:
            return
        self._buffer = np.zeros((self._max_samples, self._channels), dtype=np.float32)
        self._rec_pos = 0
        self._state = LooperState.RECORDING

    def _stop_recording(self) -> None:
        self._loop_length = max(1, self._rec_pos)
        self._play_pos = 0
        self._state = LooperState.PLAYING

    def process(self, input_audio: "np.ndarray", frames: int) -> "np.ndarray":
        """Process audio through looper.

        input_audio: shape (frames, channels)
        Returns: output audio shape (frames, channels)
        """
        if np is None:
            return input_audio

        ch = self._channels
        output = np.zeros((frames, ch), dtype=np.float32)

        if input_audio.ndim == 1:
            input_audio = np.stack([input_audio] * ch, axis=1)
        elif input_audio.shape[1] < ch:
            input_audio = np.pad(input_audio, ((0, 0), (0, ch - input_audio.shape[1])))

        if self._state == LooperState.RECORDING:
            if self._buffer is not None:
                n = min(frames, self._max_samples - self._rec_pos)
                if n > 0:
                    self._buffer[self._rec_pos:self._rec_pos + n] = input_audio[:n, :ch]
                    self._rec_pos += n
            if self._config.input_monitor:
                output = input_audio[:frames, :ch].copy()

        elif self._state in (LooperState.PLAYING, LooperState.OVERDUBBING):
            if self._buffer is not None and self._loop_length > 0:
                for i in range(frames):
                    pos = self._play_pos % self._loop_length

                    if self._state == LooperState.OVERDUBBING:
                        # Mix input with existing buffer
                        self._buffer[pos] = (
                            self._buffer[pos] * self._config.feedback +
                            input_audio[i, :ch]
                        )

                    output[i] = self._buffer[pos] * self._config.volume
                    self._play_pos += 1

        return output.astype(np.float32)


# ---------------------------------------------------------------------------
# Beat Repeat
# ---------------------------------------------------------------------------

@dataclass
class BeatRepeatConfig:
    """Configuration for beat repeat effect."""
    interval_beats: float = 4.0     # how often to trigger (in beats)
    grid: float = 0.25              # repeat grid (1/16 = 0.25)
    gate: float = 0.5               # 0..1 how long repeat lasts
    variation: int = 0              # 0=straight, 1=halving, 2=triplet
    pitch_decay: float = 0.0        # semitones per repeat (0=no change)
    volume_decay: float = 0.0       # dB per repeat (0=no decay)
    chance: float = 1.0             # 0..1 probability of triggering
    mix: float = 0.5                # 0..1 (0=dry, 1=wet)
    enabled: bool = False


class BeatRepeatEffect:
    """Automatic rhythmic repetition effect (like Ableton Beat Repeat).

    Periodically captures a segment of audio and repeats it rhythmically,
    optionally with pitch decay and volume decay.
    """

    def __init__(self, sr: int = 48000):
        self._sr = sr
        self._config = BeatRepeatConfig()
        self._buffer: Optional["np.ndarray"] = None
        self._capture_samples = 0
        self._repeat_phase = 0
        self._is_repeating = False
        self._repeat_count = 0
        self._beat_counter = 0.0
        self._last_trigger_beat = -999.0
        self._rng_state = 42

    def set_config(self, config: BeatRepeatConfig) -> None:
        self._config = config

    def process(
        self,
        audio: "np.ndarray",
        frames: int,
        current_beat: float,
        bpm: float = 120.0,
    ) -> "np.ndarray":
        """Process audio through beat repeat.

        audio: input mono or stereo
        frames: number of frames
        current_beat: current transport position in beats
        bpm: tempo

        Returns: processed audio (same shape as input).
        """
        if np is None or not self._config.enabled:
            return audio

        audio = np.asarray(audio, dtype=np.float32)
        cfg = self._config
        output = audio.copy()

        beat_samples = int(self._sr * 60.0 / max(30.0, bpm))
        grid_samples = max(64, int(beat_samples * cfg.grid))

        # Check if we should trigger
        beats_since_trigger = current_beat - self._last_trigger_beat
        if beats_since_trigger >= cfg.interval_beats and not self._is_repeating:
            # Probability check
            import random
            rng = random.Random(self._rng_state + int(current_beat * 100))
            if rng.random() < cfg.chance:
                self._trigger_repeat(audio, grid_samples)
                self._last_trigger_beat = current_beat

        # If repeating, mix repeated audio
        if self._is_repeating and self._buffer is not None:
            gate_samples = max(1, int(grid_samples * cfg.gate * 4))
            if self._repeat_phase >= gate_samples:
                self._is_repeating = False
                self._repeat_phase = 0
                self._repeat_count = 0
            else:
                wet = np.zeros_like(audio)
                seg_len = len(self._buffer)
                for i in range(frames):
                    idx = self._repeat_phase % seg_len
                    if audio.ndim == 1:
                        wet[i] = self._buffer[idx]
                    else:
                        wet[i] = self._buffer[idx]
                    self._repeat_phase += 1

                    # Advance repeat count at segment boundaries
                    if self._repeat_phase % seg_len == 0:
                        self._repeat_count += 1

                # Volume decay
                if cfg.volume_decay != 0 and self._repeat_count > 0:
                    decay_linear = 10.0 ** (cfg.volume_decay * self._repeat_count / 20.0)
                    wet *= max(0.0, min(2.0, decay_linear))

                # Mix
                output = audio * (1.0 - cfg.mix) + wet * cfg.mix

        return output

    def _trigger_repeat(self, audio: "np.ndarray", grid_samples: int) -> None:
        """Capture a segment for repetition."""
        if np is None:
            return
        # Capture one grid unit from current audio
        seg_len = min(len(audio), grid_samples)
        if seg_len < 16:
            return

        if audio.ndim == 1:
            self._buffer = audio[:seg_len].copy()
        else:
            self._buffer = audio[:seg_len].copy()

        self._capture_samples = seg_len
        self._repeat_phase = 0
        self._repeat_count = 0
        self._is_repeating = True

    def reset(self) -> None:
        self._buffer = None
        self._is_repeating = False
        self._repeat_phase = 0
        self._repeat_count = 0


# ---------------------------------------------------------------------------
# Capture MIDI (P4A)
# ---------------------------------------------------------------------------

def capture_recent_midi(
    midi_buffer: List[Dict[str, Any]],
    *,
    lookback_beats: float = 8.0,
    current_beat: float = 0.0,
    quantize_grid: float = 0.0,
) -> List[Dict[str, Any]]:
    """Capture recently played MIDI notes into a clip.

    midi_buffer: list of note dicts with 'pitch', 'start', 'duration', 'velocity'
    lookback_beats: how many beats back to capture
    current_beat: current transport position
    quantize_grid: snap to grid (0 = no quantize)

    Returns: list of note dicts normalized to start at beat 0.
    """
    if not midi_buffer:
        return []

    start_beat = max(0.0, current_beat - lookback_beats)

    captured = []
    for note in midi_buffer:
        try:
            s = float(note.get("start", 0))
            if s >= start_beat and s < current_beat:
                n = dict(note)
                n["start"] = s - start_beat

                if quantize_grid > 0:
                    n["start"] = round(n["start"] / quantize_grid) * quantize_grid

                captured.append(n)
        except Exception:
            continue

    return sorted(captured, key=lambda n: n.get("start", 0))
