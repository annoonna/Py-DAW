"""Scale database + constraint helpers.

We use the shared JSON from ``pydaw/notation/scales/scales.json`` (already part of the project)
and expose small helpers:

- ``allowed_pitch_classes(...)`` -> list[int] (0..11)
- ``apply_scale_constraint(pitch, allowed, mode)`` -> int | None

Modes:
    - ``snap``: out-of-scale pitches are moved to nearest allowed pitch
    - ``reject``: out-of-scale pitches are rejected (return None)
"""

from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Iterable, Optional


_NOTE_NAMES = ["C", "C#", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B"]


def pc_name(pc: int) -> str:
    return _NOTE_NAMES[int(pc) % 12]


@lru_cache(maxsize=1)
def _load_scales_json() -> dict:
    """Load scales.json with multiple fallback paths.

    Supports:
      - Normal development:   pydaw/notation/scales/scales.json
      - Nuitka --include-data-dir:  <dist>/pydaw/notation/scales/scales.json
      - PyInstaller _MEIPASS:       <_MEIPASS>/pydaw/notation/scales/scales.json
      - Legacy fallback:      pydaw/data/scales/scales.json
    """
    import sys

    candidates: list[Path] = []

    # 1) Relative to this file (normal dev + Nuitka --include-package)
    base = Path(__file__).resolve().parents[1]
    candidates.append(base / "notation" / "scales" / "scales.json")
    candidates.append(base / "data" / "scales" / "scales.json")

    # 2) PyInstaller frozen bundle (_MEIPASS)
    meipass = getattr(sys, "_MEIPASS", None)
    if meipass:
        mp = Path(meipass)
        candidates.append(mp / "pydaw" / "notation" / "scales" / "scales.json")
        candidates.append(mp / "pydaw" / "data" / "scales" / "scales.json")
        candidates.append(mp / "notation" / "scales" / "scales.json")

    # 3) Nuitka frozen: __compiled__ attribute or __nuitka_binary_dir
    nuitka_dir = getattr(sys, "__nuitka_binary_dir", None)
    if nuitka_dir:
        nd = Path(nuitka_dir)
        candidates.append(nd / "pydaw" / "notation" / "scales" / "scales.json")
        candidates.append(nd / "pydaw" / "data" / "scales" / "scales.json")

    # 4) Relative to sys.executable (frozen app fallback)
    exe_dir = Path(sys.executable).resolve().parent
    candidates.append(exe_dir / "pydaw" / "notation" / "scales" / "scales.json")
    candidates.append(exe_dir / "pydaw" / "data" / "scales" / "scales.json")

    for p in candidates:
        if p.exists():
            return json.loads(p.read_text(encoding="utf-8"))

    # Last resort: embedded minimal scales so the app doesn't crash
    import logging
    logging.getLogger(__name__).warning(
        "scales.json not found in any search path — using built-in minimal set. "
        "Searched: %s", [str(c) for c in candidates[:4]]
    )
    return _BUILTIN_MINIMAL_SCALES


# Minimal inline fallback so the app never crashes on missing scales.json
_BUILTIN_MINIMAL_SCALES: dict = {
    "Keine Einschränkung": {
        "Alle Noten": {"intervals_cent": list(range(0, 1200, 100))}
    },
    "Standard": {
        "Dur (Major)": {"intervals_cent": [0, 200, 400, 500, 700, 900, 1100]},
        "Moll (Minor)": {"intervals_cent": [0, 200, 300, 500, 700, 800, 1000]},
        "Pentatonik": {"intervals_cent": [0, 200, 400, 700, 900]},
        "Blues": {"intervals_cent": [0, 300, 500, 600, 700, 1000]},
        "Chromatisch": {"intervals_cent": list(range(0, 1200, 100))},
    },
}


def list_scale_categories() -> list[str]:
    d = _load_scales_json()
    return list(d.keys())


def list_scales_in_category(category: str) -> list[str]:
    d = _load_scales_json()
    cat = d.get(str(category), {}) if isinstance(d, dict) else {}
    if not isinstance(cat, dict):
        return []
    return list(cat.keys())


def allowed_pitch_classes(
    *,
    category: str,
    name: str,
    root_pc: int,
) -> list[int]:
    """Return allowed pitch classes (0..11) for the selected scale.

    The JSON stores intervals in *cents* (100 cents == one semitone in 12-TET).
    For our MIDI constraint we convert to semitone steps.
    """

    d = _load_scales_json()
    cat = d.get(str(category), {}) if isinstance(d, dict) else {}
    entry = cat.get(str(name), {}) if isinstance(cat, dict) else {}
    cents = entry.get("intervals_cent", []) if isinstance(entry, dict) else []

    out: set[int] = set()
    rp = int(root_pc) % 12

    # Special case: "Keine Einschränkung" -> allow all.
    if str(category) == "Keine Einschränkung":
        return list(range(12))

    for c in cents:
        try:
            semis = int(round(float(c) / 100.0))
        except Exception:
            continue
        out.add((rp + semis) % 12)
    if not out:
        # safe fallback
        return list(range(12))
    return sorted(out)


def is_pitch_allowed(pitch: int, allowed_pcs: Iterable[int]) -> bool:
    try:
        pcs = set(int(x) % 12 for x in allowed_pcs)
    except Exception:
        pcs = set()
    if not pcs:
        return True
    return (int(pitch) % 12) in pcs


def nearest_allowed_pitch(pitch: int, allowed_pcs: Iterable[int]) -> int:
    """Snap pitch to nearest pitch whose pitch-class is in allowed_pcs."""

    p = int(pitch)
    pcs = set(int(x) % 12 for x in allowed_pcs)
    if not pcs:
        return p
    if (p % 12) in pcs:
        return p

    # Search outward by semitone distance.
    for dist in range(1, 12):
        up = p + dist
        dn = p - dist
        if (up % 12) in pcs:
            return up
        if (dn % 12) in pcs:
            return dn
    return p


def apply_scale_constraint(pitch: int, allowed_pcs: Optional[Iterable[int]], mode: str) -> Optional[int]:
    """Apply constraint.

    Returns:
        - int: pitch to use
        - None: reject the note (only in 'reject' mode)
    """

    if allowed_pcs is None:
        return int(pitch)

    m = str(mode or "snap").lower().strip()
    if m == "reject":
        return int(pitch) if is_pitch_allowed(int(pitch), allowed_pcs) else None
    # default: snap
    return int(nearest_allowed_pitch(int(pitch), allowed_pcs))
