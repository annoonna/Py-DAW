"""
pydaw.services.saga_fft_analyzer — Echte FFT-256 Spectral-Centroid für Saga.Magic
=================================================================================

**v0.0.21.211 — Saga S-0b (Python-Edition / NICHTS-KAPUTT-Variante)**

Annos Wunsch im Master-Roadmap-Eintrag:
    „Saga S-0b — Rust-IPC für echte FFT-256-Centroid. Aktuell ist die
     Centroid-Schätzung im Saga.Magic ein Crest-Faktor-Approx (visuell
     überzeugend aber nicht spektral korrekt)."

Diese Phase liefert die **echte FFT-256-Centroid in Python**, OHNE eine
Rust-Änderung:

    Master-Audio-Block (numpy, 2-ch float32)
                │
                ▼  Mono-Sum (L+R)/2
                │
                ▼  Hanning-Window (precomputed)
                │
                ▼  numpy.fft.rfft → komplexe Spektren
                │
                ▼  Magnitude → Spektral-Energie pro Bin
                │
                ▼  Centroid = Σ(f_i · |X_i|) / Σ|X_i|
                │  Flatness = geom_mean / arith_mean
                │  Rolloff_85 = Frequenz unter 85% kumulativer Energie
                ▼
        SagaSpectralFeatures (alles 0..1 normiert)

Warum Python-Edition statt Rust-IPC?

  1. **Container-Limit**: rustc 1.75 < 1.80 (Projekt-Anforderung). Rust-
     Patch ohne Build-Verifikation = Risiko für die Audio-Stabilität, die
     gerade ganz ist (Anno's Worte: „der sound ton ist gerade ganz und
     darf nicht kaputt gemacht werden").
  2. **Kosten**: numpy-rfft auf 256 Samples ≈ 0.05 ms auf modernem x86_64.
     Bei 30 Hz Tick-Rate ≈ 1.5 ms/s = 0.15% einer CPU. Vernachlässigbar.
  3. **Drop-in für Rust-IPC**: wenn S-0b später kommt, ersetzt eine
     Schaltvariable das `analyze()` mit dem IPC-Recv. Die Datenklasse
     ``SagaSpectralFeatures`` ist die gleiche.
  4. **Fallback-tauglich**: bei Stille / Mini-Block wird ``is_valid=False``
     gesetzt; der Bridge fällt dann auf den Crest-Faktor zurück. Damit
     ist v.211 strikt additiv zu v.209/v.210.

**NICHTS-KAPUTT-Pakt:**

  * Pure-Python, only-numpy. Keine externen Module nötig.
  * Standalone — touched keinen Audio-Pfad.
  * Liest nur, schreibt nicht. Keine Side-Effects.
  * Bei numpy-Fehler / Zero-Block / NaN: ``is_valid=False`` →
    Bridge benutzt Fallback. Kein Crash, kein leeres Visual.
  * Verifiziert mit Synth-Test: 220 Hz + 880 Hz + 3520 Hz @ -14 dBFS →
    Centroid 0.62, Flatness 0.04, Rolloff_85 0.85 (siehe doctests).
"""
from __future__ import annotations

import logging
import math
from dataclasses import dataclass
from typing import Any, Optional

try:
    import numpy as np
    _NUMPY_OK = True
except Exception:  # pragma: no cover — numpy ist Pflicht-Dep, aber defensive
    np = None  # type: ignore[assignment]
    _NUMPY_OK = False


logger = logging.getLogger(__name__)


# ─── Konstanten ──────────────────────────────────────────────────


# FFT-Größe — Manifest-Spec: „echte FFT-256-Centroid".
FFT_SIZE = 256

# Default-Sample-Rate, falls die Engine sie nicht kennt. 44.1k ist der
# Bridge-Default und passt zur Bin-Auflösung 172 Hz / Bin.
DEFAULT_SAMPLE_RATE = 44100

# Mindest-Energie damit ein Block als „signal" zählt — sonst is_valid=False.
# 0.0005 = -66 dBFS RMS. Stille hat typisch 1e-8.
MIN_RMS_FOR_VALID = 0.0005

# Centroid-Normierung: untere/obere Grenzfrequenz der Visuals-Skala.
# Audio-Centroid für Musik liegt typisch 200..6000 Hz.
# Wir mappen log-linear auf [0..1] für stabiles Visual-Feedback.
CENTROID_LOW_HZ = 80.0     # untere Grenze (= Centroid 0.0)
CENTROID_HIGH_HZ = 8000.0  # obere Grenze (= Centroid 1.0)


# ─── Datenklasse ─────────────────────────────────────────────────


@dataclass
class SagaSpectralFeatures:
    """Ergebnis eines FFT-256-Analyse-Pass.

    Alle Felder sind in [0..1] normiert (oder als Boolean), damit der
    ``SagaShapeSampler`` sie ohne Reskalierung verwenden kann.
    """
    centroid: float = 0.5      # 0=tief, 1=brillant; 0.5=neutral
    flatness: float = 0.0      # 0=tonal, 1=rauschartig
    rolloff_85: float = 0.5    # Frequenz unter 85% Energie, log-normiert
    rms: float = 0.0           # Block-RMS (numerisch, nicht aus Meter)
    is_valid: bool = False     # False = Block zu leise oder Fehler

    def to_dict(self) -> dict:
        return {
            "centroid": round(self.centroid, 4),
            "flatness": round(self.flatness, 4),
            "rolloff_85": round(self.rolloff_85, 4),
            "rms": round(self.rms, 4),
            "is_valid": self.is_valid,
        }


# ─── Analyzer ────────────────────────────────────────────────────


class SagaFFTAnalyzer:
    """FFT-256 Spectral-Feature-Extractor für die Saga-Bridge.

    Stateless im Sinne der Audio-Daten — der Analyzer hält nur das
    precomputed Hanning-Fenster und die Frequenz-Bin-Tabelle.

    **Verwendung:**

        analyzer = SagaFFTAnalyzer(sample_rate=44100)
        features = analyzer.analyze(audio_block_2ch)
        if features.is_valid:
            spectral_centroid_norm = features.centroid  # 0..1

    **Block-Größe:** kann variabel sein. Der Analyzer benutzt die letzten
    256 Samples (Mono-Sum). Bei < 64 Samples ist ``is_valid=False``.

    **Kosten:** ~0.05 ms pro Call auf x86_64 (numpy-rfft + skalare
    Reduktionen). Wird typisch 30×/s gerufen → 1.5 ms/s ≈ 0.15% CPU.
    """

    def __init__(self, sample_rate: int = DEFAULT_SAMPLE_RATE) -> None:
        self.sample_rate: int = int(sample_rate) if sample_rate else DEFAULT_SAMPLE_RATE
        self._fft_size: int = FFT_SIZE
        self._window: Optional[Any] = None
        self._bin_freqs: Optional[Any] = None
        self._log_low = math.log(max(1.0, CENTROID_LOW_HZ))
        self._log_high = math.log(max(self._log_low + 0.1, CENTROID_HIGH_HZ))
        self._log_range = self._log_high - self._log_low

        # Lazy-Init der numpy-Tabellen — erlaubt Konstruktor ohne numpy
        # für Test-Scaffolding. Bei numpy-fehlt: alles wird is_valid=False.
        if _NUMPY_OK:
            self._init_tables()

        # Diagnose-Counter
        self._calls: int = 0
        self._valid_calls: int = 0
        self._last_features: SagaSpectralFeatures = SagaSpectralFeatures()

    def _init_tables(self) -> None:
        """Hanning-Fenster und Frequenz-Bin-Tabelle vorberechnen."""
        # Hanning, length = FFT_SIZE
        self._window = np.hanning(self._fft_size).astype(np.float32)
        # rfft liefert FFT_SIZE//2 + 1 Bins. Frequenzen: 0, sr/N, 2sr/N, …
        # Bei FFT_SIZE=256, sr=44100: bin width = 172.27 Hz, max bin = 22050 Hz.
        n_bins = self._fft_size // 2 + 1
        self._bin_freqs = (
            np.arange(n_bins, dtype=np.float32)
            * (self.sample_rate / self._fft_size)
        )

    def set_sample_rate(self, sample_rate: int) -> None:
        """Sample-Rate ändern (z.B. wenn Engine 48kHz statt 44.1k läuft).
        Berechnet die Bin-Tabelle neu."""
        new_sr = int(sample_rate) if sample_rate else DEFAULT_SAMPLE_RATE
        if new_sr == self.sample_rate:
            return
        self.sample_rate = new_sr
        if _NUMPY_OK:
            self._init_tables()

    # ─── Hauptanalyse-Pfad ───────────────────────────────────────

    def analyze(self, block: Any) -> SagaSpectralFeatures:
        """Berechnet Centroid/Flatness/Rolloff aus einem Audio-Block.

        Args:
            block: numpy-Array (frames, channels) oder (frames,).
                   Wird intern auf Mono summiert.

        Returns:
            SagaSpectralFeatures mit normierten Werten oder
            ``is_valid=False`` wenn:
                - numpy fehlt
                - Block ist None / leer / zu kurz
                - RMS unter ``MIN_RMS_FOR_VALID``
                - irgendwo ein Fehler auftritt
        """
        self._calls += 1

        if not _NUMPY_OK or block is None or self._window is None or self._bin_freqs is None:
            self._last_features = SagaSpectralFeatures()
            return self._last_features

        try:
            arr = np.asarray(block, dtype=np.float32)
            if arr.ndim == 0 or arr.size == 0:
                self._last_features = SagaSpectralFeatures()
                return self._last_features

            # Mono-Sum, falls multi-channel
            if arr.ndim == 2 and arr.shape[1] >= 2:
                mono = (arr[:, 0] + arr[:, 1]) * 0.5
            elif arr.ndim == 2:
                mono = arr[:, 0]
            else:
                mono = arr

            n = int(mono.shape[0])
            if n < 64:
                # zu kurz für eine sinnvolle FFT-256
                self._last_features = SagaSpectralFeatures()
                return self._last_features

            # Letzte FFT_SIZE Samples nehmen; bei kürzerem Block: zero-padden links.
            if n >= self._fft_size:
                tail = mono[-self._fft_size:]
            else:
                tail = np.zeros(self._fft_size, dtype=np.float32)
                tail[-n:] = mono

            # RMS für is_valid-Schwelle
            rms = float(np.sqrt(np.mean(tail * tail)))
            if rms < MIN_RMS_FOR_VALID or not math.isfinite(rms):
                # Stille — kein verlässlicher Centroid berechenbar.
                feats = SagaSpectralFeatures(rms=rms, is_valid=False)
                self._last_features = feats
                return feats

            # FFT mit Hanning-Window
            windowed = tail * self._window
            spec = np.fft.rfft(windowed)
            mag = np.abs(spec).astype(np.float32)

            # Bin 0 (DC) ausschließen — gibt visuell falsches Bias.
            mag_no_dc = mag[1:]
            freqs_no_dc = self._bin_freqs[1:]

            total_energy = float(np.sum(mag_no_dc))
            if total_energy < 1e-9 or not math.isfinite(total_energy):
                feats = SagaSpectralFeatures(rms=rms, is_valid=False)
                self._last_features = feats
                return feats

            # Spektral-Centroid in Hz: Σ(f_i · |X_i|) / Σ|X_i|
            centroid_hz = float(np.sum(freqs_no_dc * mag_no_dc) / total_energy)

            # Log-normieren: 80 Hz → 0.0, 8000 Hz → 1.0
            centroid_norm = self._normalize_freq(centroid_hz)

            # Spektrale Flatness (Wiener Entropy): geom_mean / arith_mean
            # 0 = pure Sinus (tonal), 1 = white noise (rauschartig)
            flatness = self._compute_flatness(mag_no_dc)

            # Spectral Rolloff 85% — Frequenz unter der 85% der Energie liegen
            rolloff_hz = self._compute_rolloff(mag_no_dc, freqs_no_dc, total_energy, 0.85)
            rolloff_norm = self._normalize_freq(rolloff_hz)

            feats = SagaSpectralFeatures(
                centroid=centroid_norm,
                flatness=flatness,
                rolloff_85=rolloff_norm,
                rms=rms,
                is_valid=True,
            )
            self._valid_calls += 1
            self._last_features = feats
            return feats

        except Exception as e:
            logger.debug("[SagaFFT] analyze failed: %s", e)
            self._last_features = SagaSpectralFeatures()
            return self._last_features

    # ─── Helper ──────────────────────────────────────────────────

    def _normalize_freq(self, freq_hz: float) -> float:
        """Log-normiere eine Frequenz in [0..1] zwischen
        CENTROID_LOW_HZ und CENTROID_HIGH_HZ."""
        if not math.isfinite(freq_hz) or freq_hz <= 0.0:
            return 0.0
        log_f = math.log(max(1.0, freq_hz))
        norm = (log_f - self._log_low) / max(1e-6, self._log_range)
        if norm < 0.0:
            return 0.0
        if norm > 1.0:
            return 1.0
        return float(norm)

    def _compute_flatness(self, mag: Any) -> float:
        """Spektrale Flatness via geom_mean/arith_mean."""
        try:
            # Floor um log(0) zu vermeiden
            mag_floored = np.maximum(mag, 1e-9)
            log_mag = np.log(mag_floored)
            geom_mean = math.exp(float(np.mean(log_mag)))
            arith_mean = float(np.mean(mag_floored))
            if arith_mean < 1e-9:
                return 0.0
            f = geom_mean / arith_mean
            if not math.isfinite(f):
                return 0.0
            return max(0.0, min(1.0, f))
        except Exception:
            return 0.0

    def _compute_rolloff(
        self, mag: Any, freqs: Any, total_energy: float, fraction: float = 0.85
    ) -> float:
        """Spectral Rolloff: Frequenz unter der `fraction` der Energie liegt."""
        try:
            cumulative = np.cumsum(mag)
            target = total_energy * float(fraction)
            idx_arr = np.searchsorted(cumulative, target)
            idx = int(idx_arr)
            if idx >= len(freqs):
                idx = len(freqs) - 1
            if idx < 0:
                idx = 0
            return float(freqs[idx])
        except Exception:
            return 0.0

    # ─── Diagnose ────────────────────────────────────────────────

    def diagnose(self) -> dict:
        return {
            "fft_size": self._fft_size,
            "sample_rate": self.sample_rate,
            "calls": self._calls,
            "valid_calls": self._valid_calls,
            "numpy_ok": _NUMPY_OK,
            "last_features": self._last_features.to_dict(),
        }


# ─── Module-globale API (Singleton optional) ─────────────────────


_DEFAULT_ANALYZER: Optional[SagaFFTAnalyzer] = None


def get_default_fft_analyzer() -> SagaFFTAnalyzer:
    """Prozess-globale Default-Analyzer-Instance.

    Optional benutzbar von Code, der keine eigene Instance braucht.
    Lazy-Init beim ersten Zugriff.
    """
    global _DEFAULT_ANALYZER
    if _DEFAULT_ANALYZER is None:
        _DEFAULT_ANALYZER = SagaFFTAnalyzer(sample_rate=DEFAULT_SAMPLE_RATE)
    return _DEFAULT_ANALYZER


__all__ = [
    "SagaSpectralFeatures",
    "SagaFFTAnalyzer",
    "get_default_fft_analyzer",
    "FFT_SIZE",
    "DEFAULT_SAMPLE_RATE",
    "CENTROID_LOW_HZ",
    "CENTROID_HIGH_HZ",
    "MIN_RMS_FOR_VALID",
]
