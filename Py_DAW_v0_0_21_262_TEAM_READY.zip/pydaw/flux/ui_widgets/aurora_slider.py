"""
pydaw.flux.ui_widgets.aurora_slider — Frigg.AuroraSliderV/H (Phase W-1)
=======================================================================

**Eingebaut in v0.0.21.197** als Norse-Sigil-Replacement für den
klassischen ``SliderWidget`` (v.195). Spezifikation:
``PROJECT_DOCS/FLUX_GROVE_MANIFEST.md`` Sektion „FLUX Sigil — eigene
Widget-Designs", Punkt 2.

Design (aus dem Manifest)
-------------------------

* Polarlicht-Streifen-Hintergrund der langsam fließt (Aurora-Drift)
* Wert-Position = wo der Streifen am hellsten ist
* Beim Drag „bewegt" sich das Aurora-Maximum mit
* Streifen kann Farbe ändern je nach verbundenem Ziel (cool-blau bei
  Filter, warm-gold bei VCA) — wird über ``set_connection_color()``
  von außen gesetzt

Animation: **Aurora-Drift** — Idle-Loop, sanftes Wellen 4 s Cycle.

Nichts-Kaputt-Garantie
----------------------

* Identischer Signal-Vertrag wie ``SliderWidget``
* Reine Python-Schicht
* Defensiv gegen fehlendes Qt
"""

from __future__ import annotations

import logging
import math
from typing import Optional

logger = logging.getLogger(__name__)


try:
    from PyQt6.QtCore import Qt, QPointF, QRectF, QSize, pyqtSignal
    from PyQt6.QtGui import (
        QColor, QPainter, QPen, QBrush, QLinearGradient, QFont,
    )
    from PyQt6.QtWidgets import QWidget, QSizePolicy
    _QT_AVAILABLE = True
except ImportError:
    _QT_AVAILABLE = False


from pydaw.flux.animation_engine import (
    get_animation_engine, ANIM_AURORA_DRIFT,
)


def _clamp(x: float, lo: float, hi: float) -> float:
    if lo > hi:
        lo, hi = hi, lo
    return max(lo, min(hi, x))


if _QT_AVAILABLE:

    class AuroraSliderWidget(QWidget):  # type: ignore[misc]
        """Sigil-Slider mit Polarlicht-Hintergrund.

        Signal-Vertrag (identisch zu SliderWidget):
        ``value_changed(float)``, ``set_value(v, *, emit_signal=...)``
        Felder: ``_minimum``, ``_maximum``, ``_default``
        """

        WHEEL_STEPS_PER_RANGE = 100
        DRAG_FINE_TUNE_DIVISOR = 10

        # Farben
        COL_BG          = "#0a0e14"
        COL_BORDER      = "#1a1f29"
        COL_AURORA_A    = "#0e7490"      # tief-cyan (Maximum-Halo)
        COL_AURORA_B    = "#3df0e0"      # hell-cyan (Maximum-Center)
        COL_AURORA_FAR  = "#0a0e14"      # weit weg vom Maximum (BG)
        COL_HANDLE      = "#7df0e0"
        COL_TEXT_DIM    = "#8b949e"

        value_changed = pyqtSignal(float)

        def __init__(
            self,
            value: float = 0.5,
            minimum: float = 0.0,
            maximum: float = 1.0,
            default: Optional[float] = None,
            orientation: str = "vertical",
            module_id: str = "",
            parent=None,
        ):
            super().__init__(parent)
            if maximum <= minimum:
                maximum = minimum + 1.0
            self._minimum = float(minimum)
            self._maximum = float(maximum)
            self._default = float(default) if default is not None else float(value)
            self._value = _clamp(float(value), self._minimum, self._maximum)
            self._orient = orientation if orientation in ("vertical", "horizontal") else "vertical"
            self._module_id = str(module_id) or f"aurora_{id(self):x}"
            self._connection_color: Optional[str] = None

            # Animation-State
            self._aurora_phase = 0.0       # Idle-Loop-Phase 0..1

            # Größen — etwas anders als SliderWidget weil Aurora "Atem"
            # braucht
            if self._orient == "vertical":
                self.setMinimumSize(28, 110)
                self.setMaximumSize(36, 180)
            else:
                self.setMinimumSize(110, 28)
                self.setMaximumSize(180, 36)
            self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)

            self._dragging = False
            self.setMouseTracking(True)
            self.setToolTip(self._tooltip())

            # Aurora-Drift Idle-Loop subscriben
            self._subscribe_idle()

        # ─── Public API ────────────────────────────────────────────

        @property
        def value(self) -> float:
            return self._value

        @property
        def minimum(self) -> float:
            return self._minimum

        @property
        def maximum(self) -> float:
            return self._maximum

        def set_value(self, value: float, *, emit_signal: bool = True) -> None:
            new_v = _clamp(float(value), self._minimum, self._maximum)
            if new_v == self._value:
                return
            self._value = new_v
            if emit_signal:
                self.value_changed.emit(self._value)
            self.setToolTip(self._tooltip())
            self.update()

        def reset_to_default(self) -> None:
            self.set_value(self._default, emit_signal=True)

        def set_connection_color(self, color: Optional[str]) -> None:
            """v.197: bei aktiver Connection den Aurora-Streifen einfärben."""
            self._connection_color = color
            self.update()

        def closeEvent(self, event):  # type: ignore[override]
            try:
                eng = get_animation_engine()
                eng.unsubscribe_prefix(f"{self._module_id}::")
            except Exception:
                pass
            super().closeEvent(event)

        # ─── Aurora-Idle ───────────────────────────────────────────

        def _subscribe_idle(self) -> None:
            eng = get_animation_engine()
            sub_id = f"{self._module_id}::aurora"
            eng.subscribe(
                sub_id, ANIM_AURORA_DRIFT,
                self._on_aurora_frame,
                duration_ms=4000,
            )

        def _on_aurora_frame(self, phase: float, frame: int) -> None:
            self._aurora_phase = float(phase)
            self.update()

        # ─── Mouse-Interaktion ─────────────────────────────────────

        def _value_from_position(self, x: float, y: float) -> float:
            range_ = self._maximum - self._minimum
            w = self.width()
            h = self.height()
            margin = 6
            if self._orient == "vertical":
                track_h = h - 2 * margin
                t = (h - margin - y) / max(track_h, 1.0)
            else:
                track_w = w - 2 * margin
                t = (x - margin) / max(track_w, 1.0)
            t = _clamp(t, 0.0, 1.0)
            return self._minimum + t * range_

        def mousePressEvent(self, event):  # type: ignore[override]
            if event.button() == Qt.MouseButton.LeftButton:
                self._dragging = True
                v = self._value_from_position(
                    event.position().x(), event.position().y(),
                )
                self.set_value(v, emit_signal=True)
                event.accept()
            else:
                super().mousePressEvent(event)

        def mouseMoveEvent(self, event):  # type: ignore[override]
            if self._dragging:
                v = self._value_from_position(
                    event.position().x(), event.position().y(),
                )
                self.set_value(v, emit_signal=True)

        def mouseReleaseEvent(self, event):  # type: ignore[override]
            if event.button() == Qt.MouseButton.LeftButton and self._dragging:
                self._dragging = False
                event.accept()
            else:
                super().mouseReleaseEvent(event)

        def mouseDoubleClickEvent(self, event):  # type: ignore[override]
            if event.button() == Qt.MouseButton.LeftButton:
                self.reset_to_default()
                event.accept()
            else:
                super().mouseDoubleClickEvent(event)

        def wheelEvent(self, event):  # type: ignore[override]
            steps = event.angleDelta().y() / 120.0
            if steps == 0:
                event.ignore()
                return
            range_ = self._maximum - self._minimum
            divisor = self.WHEEL_STEPS_PER_RANGE
            if event.modifiers() & Qt.KeyboardModifier.ShiftModifier:
                divisor *= self.DRAG_FINE_TUNE_DIVISOR
            step = range_ / divisor
            self.set_value(self._value + steps * step, emit_signal=True)
            event.accept()

        # ─── Painting ──────────────────────────────────────────────

        def paintEvent(self, event):  # type: ignore[override]
            painter = QPainter(self)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)

            w = self.width()
            h = self.height()
            margin = 4
            range_ = self._maximum - self._minimum
            t = (self._value - self._minimum) / range_ if range_ > 0 else 0.0

            # 1) Border / BG
            painter.setBrush(QBrush(QColor(self.COL_BG)))
            painter.setPen(QPen(QColor(self.COL_BORDER), 1.0))
            painter.drawRoundedRect(QRectF(0, 0, w, h), 3.0, 3.0)

            # 2) Aurora-Streifen — heller-Halo um die Wert-Position,
            #    moduliert durch die Idle-Phase (sanftes Atmen)
            aurora_color_b = self._connection_color or self.COL_AURORA_B
            aurora_color_a = self.COL_AURORA_A
            # Atem-Modulation: Helligkeit pulsiert dezent
            breath = 0.7 + 0.3 * self._aurora_phase   # 0.7..1.0

            track_inner = QRectF(margin, margin,
                                  w - 2 * margin, h - 2 * margin)
            if self._orient == "vertical":
                # Maximum sitzt bei y_max (oben = max)
                y_max = h - margin - t * (h - 2 * margin)
                grad = QLinearGradient(0, margin, 0, h - margin)
                # Drei Stops: weit_weg, max-color, weit_weg — mit
                # Maximum-Position als grad-Position (0..1)
                gp = (h - margin - y_max) / max(h - 2 * margin, 1.0)
                gp = _clamp(gp, 0.05, 0.95)
                # Aurora-Far-Stops fadeten in den BG
                grad.setColorAt(0.0,
                    QColor(self.COL_AURORA_FAR))
                # Außenringe des Halos
                halo_color = QColor(aurora_color_a)
                halo_color.setAlphaF(0.6 * breath)
                grad.setColorAt(_clamp(1.0 - gp - 0.30, 0.0, 1.0), halo_color)
                # Maximum: hellste Farbe
                max_color = QColor(aurora_color_b)
                max_color.setAlphaF(1.0 * breath)
                grad.setColorAt(_clamp(1.0 - gp, 0.0, 1.0), max_color)
                grad.setColorAt(_clamp(1.0 - gp + 0.30, 0.0, 1.0), halo_color)
                grad.setColorAt(1.0,
                    QColor(self.COL_AURORA_FAR))
                painter.setBrush(QBrush(grad))
                painter.setPen(Qt.PenStyle.NoPen)
                painter.drawRoundedRect(track_inner, 1.5, 1.5)

                # Handle: feiner Strich an der Wert-Position
                painter.setPen(QPen(QColor(self.COL_HANDLE), 1.5))
                painter.drawLine(int(margin), int(y_max),
                                  int(w - margin), int(y_max))
            else:
                x_max = margin + t * (w - 2 * margin)
                grad = QLinearGradient(margin, 0, w - margin, 0)
                gp = (x_max - margin) / max(w - 2 * margin, 1.0)
                gp = _clamp(gp, 0.05, 0.95)
                grad.setColorAt(0.0, QColor(self.COL_AURORA_FAR))
                halo_color = QColor(aurora_color_a)
                halo_color.setAlphaF(0.6 * breath)
                grad.setColorAt(_clamp(gp - 0.30, 0.0, 1.0), halo_color)
                max_color = QColor(aurora_color_b)
                max_color.setAlphaF(1.0 * breath)
                grad.setColorAt(gp, max_color)
                grad.setColorAt(_clamp(gp + 0.30, 0.0, 1.0), halo_color)
                grad.setColorAt(1.0, QColor(self.COL_AURORA_FAR))
                painter.setBrush(QBrush(grad))
                painter.setPen(Qt.PenStyle.NoPen)
                painter.drawRoundedRect(track_inner, 1.5, 1.5)

                painter.setPen(QPen(QColor(self.COL_HANDLE), 1.5))
                painter.drawLine(int(x_max), int(margin),
                                  int(x_max), int(h - margin))

            painter.end()

        # ─── Tooltip / sizeHint ────────────────────────────────────

        def _tooltip(self) -> str:
            return (
                f"<b>AuroraSlider</b>: {self._value:g}<br>"
                f"<span style='color:#8b949e;'>Range: {self._minimum:g} … "
                f"{self._maximum:g}<br>"
                "Drag · Wheel · 2× Klick = Reset</span>"
            )

        def sizeHint(self):  # type: ignore[override]
            if self._orient == "vertical":
                return QSize(28, 130)
            return QSize(130, 28)

else:
    AuroraSliderWidget = None  # type: ignore[assignment,misc]


__all__ = ["AuroraSliderWidget"]
