"""chord_progression_ai.py — Rule-Based Chord Progression Generator.

v0.0.20.909 — C4.1: KI-Kompositions-Feature.

Generates chord progressions using music-theory rules and Markov-chain
transitions. No LLM needed — pure algorithmic composition.

Usage:
    from pydaw.services.chord_progression_ai import ChordProgressionAI

    ai = ChordProgressionAI()
    chords = ai.suggest_progression(key="C", scale="major", length=8)
    # → [("C", "maj"), ("Am", "min"), ("F", "maj"), ("G", "maj"), ...]

    # From existing notes (analyze + continue)
    chords = ai.continue_from_notes(notes, key="C", scale="major", count=4)

    # Get MIDI notes for a chord
    midi = ai.chord_to_midi("C", "maj", octave=4)
    # → [60, 64, 67]  (C4, E4, G4)
"""

from __future__ import annotations

import logging
import random
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

log = logging.getLogger(__name__)

# ── Note/Scale definitions ──────────────────────────────────────────

NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]

# Intervals for each scale type (semitones from root)
SCALE_INTERVALS: Dict[str, List[int]] = {
    "major":           [0, 2, 4, 5, 7, 9, 11],
    "minor":           [0, 2, 3, 5, 7, 8, 10],
    "harmonic_minor":  [0, 2, 3, 5, 7, 8, 11],
    "melodic_minor":   [0, 2, 3, 5, 7, 9, 11],
    "dorian":          [0, 2, 3, 5, 7, 9, 10],
    "mixolydian":      [0, 2, 4, 5, 7, 9, 10],
    "phrygian":        [0, 1, 3, 5, 7, 8, 10],
    "lydian":          [0, 2, 4, 6, 7, 9, 11],
    "pentatonic":      [0, 2, 4, 7, 9],
    "blues":           [0, 3, 5, 6, 7, 10],
}

# Chord quality templates (intervals from root)
CHORD_TEMPLATES: Dict[str, List[int]] = {
    "maj":    [0, 4, 7],
    "min":    [0, 3, 7],
    "dim":    [0, 3, 6],
    "aug":    [0, 4, 8],
    "7":      [0, 4, 7, 10],
    "maj7":   [0, 4, 7, 11],
    "min7":   [0, 3, 7, 10],
    "dim7":   [0, 3, 6, 9],
    "sus2":   [0, 2, 7],
    "sus4":   [0, 5, 7],
}

# Diatonic chord qualities for major scale degrees (I–VII)
MAJOR_DIATONIC = ["maj", "min", "min", "maj", "maj", "min", "dim"]
MINOR_DIATONIC = ["min", "dim", "maj", "min", "min", "maj", "maj"]

# ── Transition probabilities (Markov chain) ──────────────────────────

# Common chord transitions in pop/rock (degree → {degree: probability})
# Degrees are 0-indexed (0=I, 1=II, 2=III, 3=IV, 4=V, 5=VI, 6=VII)
MAJOR_TRANSITIONS: Dict[int, Dict[int, float]] = {
    0: {3: 0.25, 4: 0.25, 5: 0.20, 1: 0.15, 2: 0.10, 6: 0.05},  # I →
    1: {4: 0.40, 0: 0.20, 3: 0.20, 6: 0.10, 5: 0.10},            # ii →
    2: {5: 0.30, 3: 0.25, 0: 0.20, 4: 0.15, 1: 0.10},            # iii →
    3: {4: 0.30, 0: 0.25, 1: 0.20, 5: 0.15, 2: 0.10},            # IV →
    4: {0: 0.40, 5: 0.25, 3: 0.15, 2: 0.10, 1: 0.10},            # V →
    5: {3: 0.30, 4: 0.25, 0: 0.20, 1: 0.15, 2: 0.10},            # vi →
    6: {0: 0.40, 4: 0.30, 2: 0.15, 5: 0.15},                      # vii° →
}

MINOR_TRANSITIONS: Dict[int, Dict[int, float]] = {
    0: {2: 0.25, 3: 0.25, 4: 0.20, 5: 0.15, 6: 0.10, 1: 0.05},
    1: {4: 0.35, 0: 0.30, 3: 0.20, 6: 0.15},
    2: {5: 0.30, 3: 0.25, 0: 0.20, 6: 0.15, 4: 0.10},
    3: {4: 0.30, 0: 0.25, 6: 0.20, 5: 0.15, 1: 0.10},
    4: {0: 0.40, 5: 0.25, 3: 0.20, 6: 0.15},
    5: {3: 0.30, 6: 0.25, 0: 0.20, 4: 0.15, 1: 0.10},
    6: {0: 0.35, 4: 0.25, 5: 0.20, 2: 0.10, 3: 0.10},
}

# ── Common progressions (presets) ──────────────────────────────────

COMMON_PROGRESSIONS: Dict[str, List[int]] = {
    "pop_1":       [0, 4, 5, 3],      # I–V–vi–IV
    "pop_2":       [0, 3, 4, 4],      # I–IV–V–V
    "sad":         [5, 3, 0, 4],      # vi–IV–I–V
    "blues":       [0, 0, 0, 0, 3, 3, 0, 0, 4, 3, 0, 4],  # 12-bar blues
    "jazz_251":    [1, 4, 0],          # ii–V–I
    "andalusian":  [5, 4, 3, 2],      # vi–V–IV–iii (Flamenco)
    "rock":        [0, 3, 4, 3],      # I–IV–V–IV
    "canon":       [0, 4, 5, 2, 3, 0, 3, 4],  # Pachelbel's Canon
}


@dataclass
class ChordSuggestion:
    """A suggested chord in a progression."""
    degree: int          # 0-indexed scale degree
    root_name: str       # e.g. "C", "Am"
    quality: str         # e.g. "maj", "min", "dim"
    midi_notes: List[int] = field(default_factory=list)  # MIDI pitches
    roman: str = ""      # Roman numeral (e.g. "I", "vi")


class ChordProgressionAI:
    """Rule-based chord progression generator."""

    def __init__(self, seed: Optional[int] = None):
        self._rng = random.Random(seed)

    # ── Public API ──────────────────────────────────────────────────

    def suggest_progression(
        self,
        key: str = "C",
        scale: str = "major",
        length: int = 4,
        preset: str = "",
        start_degree: int = 0,
    ) -> List[ChordSuggestion]:
        """Generate a chord progression.

        Args:
            key: Root note (e.g. "C", "F#", "Bb")
            scale: Scale type (major, minor, dorian, ...)
            length: Number of chords
            preset: Named preset (pop_1, sad, blues, ...) or "" for Markov
            start_degree: Starting scale degree (0=I) for Markov generation

        Returns:
            List of ChordSuggestion objects.
        """
        root_pc = self._name_to_pc(key)
        intervals = SCALE_INTERVALS.get(scale, SCALE_INTERVALS["major"])
        is_minor = scale in ("minor", "harmonic_minor", "melodic_minor",
                              "dorian", "phrygian")

        # Use preset if given
        if preset and preset in COMMON_PROGRESSIONS:
            degrees = list(COMMON_PROGRESSIONS[preset])
            # Extend/truncate to match length
            while len(degrees) < length:
                degrees.extend(COMMON_PROGRESSIONS[preset])
            degrees = degrees[:length]
        else:
            # Markov chain generation
            degrees = self._markov_generate(
                length, start_degree, is_minor
            )

        # Build chord suggestions
        diatonic = MINOR_DIATONIC if is_minor else MAJOR_DIATONIC
        result: List[ChordSuggestion] = []
        for deg in degrees:
            deg = deg % len(intervals)
            chord_root_pc = (root_pc + intervals[deg]) % 12
            quality = diatonic[deg] if deg < len(diatonic) else "maj"
            root_name = NOTE_NAMES[chord_root_pc]
            midi = self.chord_to_midi(root_name, quality, octave=4)
            roman = self._degree_to_roman(deg, quality)

            result.append(ChordSuggestion(
                degree=deg,
                root_name=root_name,
                quality=quality,
                midi_notes=midi,
                roman=roman,
            ))

        return result

    def suggest_from_preset(
        self, preset: str, key: str = "C", scale: str = "major"
    ) -> List[ChordSuggestion]:
        """Suggest a named progression preset."""
        prog = COMMON_PROGRESSIONS.get(preset)
        if not prog:
            return []
        return self.suggest_progression(
            key=key, scale=scale, length=len(prog), preset=preset
        )

    def get_preset_names(self) -> List[str]:
        """List all available preset names."""
        return list(COMMON_PROGRESSIONS.keys())

    def chord_to_midi(
        self, root: str, quality: str = "maj", octave: int = 4
    ) -> List[int]:
        """Convert a chord to MIDI note numbers.

        Args:
            root: Note name (e.g. "C", "F#")
            quality: Chord quality (maj, min, dim, 7, maj7, min7, ...)
            octave: Base octave (4 = middle C)

        Returns:
            List of MIDI note numbers.
        """
        root_pc = self._name_to_pc(root)
        base_midi = (octave + 1) * 12 + root_pc
        template = CHORD_TEMPLATES.get(quality, CHORD_TEMPLATES["maj"])
        return [base_midi + interval for interval in template]

    def analyze_key(self, pitches: List[int]) -> Tuple[str, str]:
        """Guess key and scale from a list of MIDI pitches.

        Simple heuristic: count pitch classes, compare to scale templates.
        Returns (key_name, scale_name).
        """
        if not pitches:
            return ("C", "major")

        # Count pitch class occurrences
        pc_counts = [0] * 12
        for p in pitches:
            pc_counts[p % 12] += 1

        best_key = "C"
        best_scale = "major"
        best_score = -1

        for root_pc in range(12):
            for scale_name, intervals in SCALE_INTERVALS.items():
                if scale_name in ("pentatonic", "blues"):
                    continue  # skip incomplete scales for key detection
                score = sum(
                    pc_counts[(root_pc + iv) % 12]
                    for iv in intervals
                )
                if score > best_score:
                    best_score = score
                    best_key = NOTE_NAMES[root_pc]
                    best_scale = scale_name

        return (best_key, best_scale)

    # ── Internal ────────────────────────────────────────────────────

    def _markov_generate(
        self, length: int, start: int, is_minor: bool
    ) -> List[int]:
        """Generate degree sequence using Markov chain."""
        transitions = MINOR_TRANSITIONS if is_minor else MAJOR_TRANSITIONS
        degrees = [start]

        for _ in range(length - 1):
            current = degrees[-1]
            trans = transitions.get(current, {0: 1.0})
            # Weighted random choice
            targets = list(trans.keys())
            weights = [trans[t] for t in targets]
            total = sum(weights)
            r = self._rng.random() * total
            cumulative = 0.0
            chosen = targets[0]
            for t, w in zip(targets, weights):
                cumulative += w
                if r <= cumulative:
                    chosen = t
                    break
            degrees.append(chosen)

        return degrees

    def _name_to_pc(self, name: str) -> int:
        """Convert note name to pitch class (0=C, 1=C#, ...)."""
        name = name.strip()
        # Handle flats
        flat_map = {"Db": 1, "Eb": 3, "Fb": 4, "Gb": 6, "Ab": 8, "Bb": 10, "Cb": 11}
        if name in flat_map:
            return flat_map[name]
        try:
            return NOTE_NAMES.index(name)
        except ValueError:
            # Try case-insensitive
            for i, n in enumerate(NOTE_NAMES):
                if n.lower() == name.lower():
                    return i
            return 0  # default C

    def _degree_to_roman(self, degree: int, quality: str) -> str:
        """Convert degree + quality to Roman numeral notation."""
        numerals = ["I", "II", "III", "IV", "V", "VI", "VII"]
        if degree >= len(numerals):
            return str(degree + 1)
        roman = numerals[degree]
        if quality in ("min", "min7"):
            roman = roman.lower()
        elif quality == "dim":
            roman = roman.lower() + "°"
        elif quality == "aug":
            roman = roman + "+"
        return roman
