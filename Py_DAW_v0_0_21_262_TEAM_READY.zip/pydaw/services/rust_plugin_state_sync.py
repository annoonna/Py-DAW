"""
pydaw.services.rust_plugin_state_sync
=====================================

Single-shot helper: triggers SavePluginState for every Rust-hosted
external plugin (VST2/VST3/CLAP) and waits briefly for the resulting
PluginState events. The bridge's event handler (rust_engine_bridge.py
PluginState branch) writes the returned state blob into
``track.audio_fx_chain.devices[slot].params['__rust_state_b64']``,
where it gets serialised with the project JSON and restored at load
time by ``audio_engine.py`` (`__rust_state_b64` round-trip).

Why this exists (v0.0.21.168)
-----------------------------

Until v.167 the project-save path called ``embed_project_state_blobs()``
which reads from ``audio_engine._vst_instrument_engines`` — the
*Python-direct* VST host. In Rust-Hybrid mode (active for Anno's
setup) the plugins are hosted **inside the Rust engine**, so that
dict is empty for them. Result: VST2 preset chosen via editor-helper
plays correctly during the session (because Rust got the chunk via
plugin_sync.sock), but on save the chunk was never extracted and
thus never written to disk. Anno's symptom: "vst2 wenn ich presets
wähle beim laden nicht wieder mit geladen werden ich muss sie immer
wieder neu laden".

The Rust side (engine.rs:1493 ``Command::SavePluginState``) is
already complete — it calls ``plugin.save_state()`` and emits a
``PluginState`` event with base64. The Python side just never asked
for it. This module asks.

Usage
-----

Call ``request_all_plugin_states(bridge, project)`` *before*
``embed_project_state_blobs()`` and ``embed_clap_project_state_blobs()``
in the save path. Returns the number of states requested. Also
sleeps briefly (default 300 ms) to let the event-driven IPC catch
up — that's enough on local Unix sockets, even with 20+ plugins.
"""

from __future__ import annotations

import logging
import time
from typing import Any, List, Tuple

logger = logging.getLogger(__name__)

# Plugin-IDs that indicate a Rust-hosted external plugin.
_EXT_PLUGIN_PREFIXES = ("ext.vst2:", "ext.vst3:", "ext.clap:")


def _iter_ext_plugin_slots(project: Any) -> List[Tuple[str, str, int]]:
    """Yield (track_id, chain_name, slot_index) for every ext.* device.

    Both audio_fx_chain and note_fx_chain are scanned. The chain_name
    is included so callers can log what was requested.
    """
    out: List[Tuple[str, str, int]] = []
    tracks = getattr(project, "tracks", None) or []
    for track in tracks:
        tid = str(getattr(track, "id", "") or "")
        if not tid:
            continue
        for chain_attr in ("audio_fx_chain", "note_fx_chain"):
            chain = getattr(track, chain_attr, None)
            if not isinstance(chain, dict):
                continue
            devices = chain.get("devices") or []
            for slot_idx, dev in enumerate(devices):
                if not isinstance(dev, dict):
                    continue
                pid = str(dev.get("plugin_id") or dev.get("type") or "").lower()
                if any(pid.startswith(p) for p in _EXT_PLUGIN_PREFIXES):
                    out.append((tid, chain_attr, slot_idx))

        # v0.0.21.168: Instrument-tracks have a separate "instrument slot"
        # which Rust addresses as slot 0. We trigger save for it too if
        # the track has an external plugin path/type.
        plugin_path = str(getattr(track, "plugin_path", "") or "")
        plugin_type = str(getattr(track, "plugin_type", "") or "").lower()
        if plugin_type in ("vst2", "vst3", "clap") or plugin_path.lower().endswith(
            (".vst3", ".clap", ".so", ".dll", ".dylib")
        ):
            # Instrument plugin lives at slot 0 from Rust's perspective
            out.append((tid, "instrument", 0))
    return out


def request_all_plugin_states(
    bridge: Any,
    project: Any,
    wait_ms: int = 300,
) -> int:
    """Ask Rust for every external-plugin state, then wait briefly.

    Args:
        bridge: The ``RustEngineBridge`` instance (or None — silent no-op).
        project: The Project model (or None — silent no-op).
        wait_ms: How long to sleep after firing the requests, so the
            ``PluginState`` events can come back and be merged into the
            project model by the bridge's event handler. 300 ms is
            generous on local Unix sockets; reduce if save latency
            becomes a problem.

    Returns:
        Number of state requests fired. ``0`` means either no
        Rust-hosted external plugins, or bridge/project is None.

    Notes:
        * Runs synchronously on the calling thread — keep ``wait_ms``
          short so save dialogs don't feel sluggish.
        * Failures on individual ``send_command`` calls are tolerated
          silently; one bad slot must not block project save.
        * The state arrives **after** this function returns control to
          the caller (asynchronously via the bridge IPC reader thread),
          but the ``time.sleep(wait_ms)`` ensures most events have
          arrived before ``embed_project_state_blobs()`` reads
          ``params['__rust_state_b64']``.
    """
    if bridge is None or project is None:
        return 0

    save_fn = getattr(bridge, "save_plugin_state", None)
    if not callable(save_fn):
        logger.debug("[STATE-SYNC] bridge has no save_plugin_state method")
        return 0

    slots = _iter_ext_plugin_slots(project)
    if not slots:
        logger.debug("[STATE-SYNC] no external Rust-hosted plugins found")
        return 0

    requested = 0
    for tid, chain_name, slot_idx in slots:
        try:
            save_fn(tid, slot_idx)
            requested += 1
        except Exception as e:
            # Don't let one bad slot block the others. Project-save must
            # remain robust even if the engine has gone away mid-save.
            logger.debug(
                "[STATE-SYNC] save_plugin_state failed: track=%s chain=%s slot=%d: %s",
                tid[:10], chain_name, slot_idx, e,
            )

    if requested > 0:
        logger.info(
            "[STATE-SYNC] Requested %d plugin states, waiting %dms for events",
            requested, wait_ms,
        )
        # Block the save thread briefly so the bridge IPC reader has
        # time to receive the PluginState events and stash the blobs
        # into the project model. 300 ms is plenty for local sockets;
        # the bottleneck is the Rust-side `effGetChunk` call which is
        # well under 1 ms per plugin.
        time.sleep(max(0.0, wait_ms / 1000.0))

    return requested


__all__ = ["request_all_plugin_states"]
