"""ki_text_analysis.py — Text & Verse Analysis for Composition (v0.0.20.987)

KK7: Text-Analyse (Gesangbücher / Liturgie)

Analyzes text to derive musical parameters:
  - Verse meter: Iambus, Trochee, Dactyl, Anapest → rhythm
  - Syllable counting per line → melody length
  - Rhyme detection: couplet, cross, embrace → melody repetition
  - Mood analysis: joy, sorrow, celebration → key + tempo
  - Liturgical assignment: Advent, Christmas, Passion, Easter → style
  - Language detection: German, Latin, English → stress patterns
  - Psalm tone system: 8 tones → recitation + flexa + mediatio

Pure Python — no NLP libraries required.
"""

import re
import logging
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple
from enum import Enum

log = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# Syllable Counting
# ═══════════════════════════════════════════════════════════════

# German vowel groups (diphthongs count as one syllable)
_DE_DIPHTHONGS = {"ei", "ai", "au", "eu", "äu", "ie"}
_VOWELS = set("aeiouyäöü")


def count_syllables_de(word: str) -> int:
    """Count syllables in a German word (heuristic)."""
    word = word.lower().strip()
    if not word:
        return 0
    count = 0
    i = 0
    while i < len(word):
        if word[i] in _VOWELS:
            # Check for diphthong
            if i + 1 < len(word) and word[i:i+2] in _DE_DIPHTHONGS:
                i += 2
            else:
                i += 1
            count += 1
        else:
            i += 1
    return max(1, count)


def count_syllables_en(word: str) -> int:
    """Count syllables in an English word (heuristic)."""
    word = word.lower().strip()
    if not word:
        return 0
    word = re.sub(r'e$', '', word)  # silent e
    vowel_groups = re.findall(r'[aeiouy]+', word)
    count = len(vowel_groups)
    return max(1, count)


def count_syllables_line(line: str, lang: str = "de") -> int:
    """Count total syllables in a text line."""
    words = re.findall(r'\w+', line)
    func = count_syllables_de if lang == "de" else count_syllables_en
    return sum(func(w) for w in words)


# ═══════════════════════════════════════════════════════════════
# Verse Meter Detection
# ═══════════════════════════════════════════════════════════════

class MeterType(Enum):
    IAMBUS = "iambus"           # u -  (weak-strong)
    TROCHEE = "trochee"         # - u  (strong-weak)
    DACTYL = "dactyl"           # - u u (strong-weak-weak)
    ANAPEST = "anapest"         # u u - (weak-weak-strong)
    SPONDEE = "spondee"         # - -  (strong-strong)
    FREE = "free"               # no regular pattern


@dataclass
class MeterAnalysis:
    """Result of verse meter analysis."""
    meter: MeterType
    confidence: float           # 0.0–1.0
    syllables_per_line: List[int]
    stress_pattern: str         # e.g. "u - u - u -"
    suggested_time_sig: Tuple[int, int]
    suggested_note_values: str  # e.g. "eighth-quarter alternating"


def detect_meter(lines: List[str], lang: str = "de") -> MeterAnalysis:
    """Detect verse meter from text lines.

    Uses syllable counting and common German/English patterns.
    """
    syllable_counts = [count_syllables_line(l, lang) for l in lines if l.strip()]

    if not syllable_counts:
        return MeterAnalysis(MeterType.FREE, 0.0, [], "", (4, 4), "quarter")

    avg_syllables = sum(syllable_counts) / len(syllable_counts)

    # Heuristic: even syllable count suggests iambus/trochee
    # Divisible by 3 suggests dactyl/anapest
    even_count = sum(1 for s in syllable_counts if s % 2 == 0)
    three_count = sum(1 for s in syllable_counts if s % 3 == 0)

    if three_count > len(syllable_counts) * 0.6:
        meter = MeterType.DACTYL
        time_sig = (6, 8)
        pattern = "- u u " * (int(avg_syllables) // 3)
        note_vals = "dotted-quarter + two-eighths"
    elif even_count > len(syllable_counts) * 0.6:
        # Default to iambus for German hymns
        meter = MeterType.IAMBUS if lang == "de" else MeterType.TROCHEE
        time_sig = (4, 4)
        pattern = "u - " * (int(avg_syllables) // 2)
        note_vals = "eighth-quarter alternating"
    else:
        meter = MeterType.FREE
        time_sig = (4, 4)
        pattern = "free"
        note_vals = "quarter"

    confidence = even_count / max(len(syllable_counts), 1)

    return MeterAnalysis(
        meter=meter,
        confidence=min(1.0, confidence),
        syllables_per_line=syllable_counts,
        stress_pattern=pattern.strip(),
        suggested_time_sig=time_sig,
        suggested_note_values=note_vals,
    )


# ═══════════════════════════════════════════════════════════════
# Rhyme Detection
# ═══════════════════════════════════════════════════════════════

class RhymeScheme(Enum):
    COUPLET = "couplet"         # AA BB CC
    CROSS = "cross"             # AB AB
    EMBRACE = "embrace"         # AB BA
    TAIL = "tail"               # AAB CCB
    NONE = "none"


def get_line_ending(line: str, syllables: int = 2) -> str:
    """Get the last N syllables of a line for rhyme comparison."""
    words = re.findall(r'\w+', line.lower())
    if not words:
        return ""
    last = words[-1]
    # Take last 3-4 characters as rhyme approximation
    return last[-min(4, len(last)):]


def detect_rhyme_scheme(lines: List[str]) -> Tuple[RhymeScheme, str]:
    """Detect rhyme scheme from text lines.

    Returns (scheme, pattern_string) e.g. (CROSS, "ABAB")
    """
    clean_lines = [l.strip() for l in lines if l.strip()]
    if len(clean_lines) < 4:
        return RhymeScheme.NONE, ""

    endings = [get_line_ending(l) for l in clean_lines[:8]]

    def rhymes(a: str, b: str) -> bool:
        if not a or not b:
            return False
        # Simple: last 2+ chars match
        min_len = min(len(a), len(b), 3)
        return a[-min_len:] == b[-min_len:]

    # Check couplet (AA BB)
    couplet_score = sum(1 for i in range(0, len(endings) - 1, 2)
                        if rhymes(endings[i], endings[i + 1]))
    # Check cross (AB AB)
    cross_score = 0
    if len(endings) >= 4:
        if rhymes(endings[0], endings[2]):
            cross_score += 1
        if rhymes(endings[1], endings[3]):
            cross_score += 1
    # Check embrace (AB BA)
    embrace_score = 0
    if len(endings) >= 4:
        if rhymes(endings[0], endings[3]):
            embrace_score += 1
        if rhymes(endings[1], endings[2]):
            embrace_score += 1

    if cross_score >= 2:
        return RhymeScheme.CROSS, "ABAB"
    elif couplet_score >= 2:
        return RhymeScheme.COUPLET, "AABB"
    elif embrace_score >= 2:
        return RhymeScheme.EMBRACE, "ABBA"
    return RhymeScheme.NONE, ""


# ═══════════════════════════════════════════════════════════════
# Mood / Sentiment Analysis
# ═══════════════════════════════════════════════════════════════

# German keywords by mood
MOOD_KEYWORDS_DE: Dict[str, List[str]] = {
    "joy": ["freude", "fröhlich", "jubel", "jauchzen", "lob", "preis", "dank",
            "singen", "froh", "heiter", "glück", "selig", "wonne"],
    "sorrow": ["trauer", "leid", "schmerz", "klag", "wein", "not", "elend",
               "jammer", "betrübt", "traurig", "kreuz", "qual"],
    "peace": ["friede", "ruh", "still", "sanft", "trost", "geborgen",
              "sicher", "rast", "schlaf", "abend"],
    "celebration": ["fest", "feier", "ehre", "kron", "thron", "majestät",
                    "herrlich", "pracht", "gloria", "halleluja", "hosianna"],
    "penitence": ["buß", "schuld", "sünd", "reue", "vergeb", "gnad",
                  "erbarme", "barmherzig"],
    "hope": ["hoffnung", "licht", "stern", "morgen", "aufersteh", "ewig",
             "verheißung", "treu", "zuversicht"],
    "awe": ["heilig", "ehrfurcht", "allmächtig", "wunder", "staunen",
            "unbegreiflich", "groß"],
}

# Liturgical season keywords
LITURGICAL_KEYWORDS: Dict[str, List[str]] = {
    "advent": ["advent", "komm", "erwart", "bereit", "wach", "maranatha"],
    "christmas": ["weihnacht", "krippe", "stall", "hirten", "engel", "stern",
                  "bethlehem", "geboren", "kind", "nacht"],
    "epiphany": ["könige", "weisen", "morgenland", "gold", "weihrauch", "myrrhe"],
    "passion": ["passion", "kreuz", "leiden", "golgatha", "dorn", "blut",
                "lamm", "opfer", "karfreitag"],
    "easter": ["ostern", "aufersteh", "auferstand", "grab", "leben", "sieg",
               "tod", "überwund"],
    "pentecost": ["pfingsten", "geist", "feuer", "wind", "flamm", "ausgieß",
                  "tauf", "kraft"],
    "trinity": ["dreifaltigkeit", "dreieinig", "trinität", "vater", "sohn"],
    "reformation": ["reformation", "luther", "feste burg", "glaub", "allein"],
}


@dataclass
class TextAnalysisResult:
    """Complete text analysis result."""
    text: str
    language: str
    lines: List[str]
    syllables_per_line: List[int]
    total_syllables: int
    meter: MeterAnalysis
    rhyme_scheme: RhymeScheme
    rhyme_pattern: str
    mood: str
    mood_confidence: float
    liturgical_season: str
    suggested_key: str
    suggested_tempo: int
    suggested_style: str


def analyze_text(text: str) -> TextAnalysisResult:
    """Complete text analysis for composition.

    Analyzes meter, rhyme, mood, liturgical season, and suggests
    musical parameters.
    """
    lines = [l for l in text.strip().split("\n") if l.strip()]
    lang = detect_language(text)

    # Syllables
    syllables = [count_syllables_line(l, lang) for l in lines]
    total = sum(syllables)

    # Meter
    meter = detect_meter(lines, lang)

    # Rhyme
    rhyme_scheme, rhyme_pattern = detect_rhyme_scheme(lines)

    # Mood
    mood, mood_conf = detect_mood(text)

    # Liturgical season
    season = detect_liturgical_season(text)

    # Musical suggestions based on analysis
    key, tempo, style = suggest_music_params(mood, season, meter)

    return TextAnalysisResult(
        text=text, language=lang, lines=lines,
        syllables_per_line=syllables, total_syllables=total,
        meter=meter, rhyme_scheme=rhyme_scheme, rhyme_pattern=rhyme_pattern,
        mood=mood, mood_confidence=mood_conf,
        liturgical_season=season,
        suggested_key=key, suggested_tempo=tempo, suggested_style=style,
    )


def detect_language(text: str) -> str:
    """Simple language detection (de/la/en)."""
    text_lower = text.lower()
    de_words = ["und", "der", "die", "das", "ein", "ist", "nicht", "von", "ich", "du"]
    la_words = ["et", "deus", "dominus", "gloria", "sanctus", "amen", "kyrie"]
    en_words = ["the", "and", "for", "with", "that", "this", "from", "have"]

    de_score = sum(1 for w in de_words if f" {w} " in f" {text_lower} ")
    la_score = sum(1 for w in la_words if w in text_lower)
    en_score = sum(1 for w in en_words if f" {w} " in f" {text_lower} ")

    if la_score > de_score and la_score > en_score:
        return "la"
    if en_score > de_score:
        return "en"
    return "de"


def detect_mood(text: str) -> Tuple[str, float]:
    """Detect mood from text keywords."""
    text_lower = text.lower()
    scores: Dict[str, int] = {}

    for mood, keywords in MOOD_KEYWORDS_DE.items():
        score = sum(1 for kw in keywords if kw in text_lower)
        if score > 0:
            scores[mood] = score

    if not scores:
        return "peace", 0.0

    best = max(scores, key=scores.get)
    total = sum(scores.values())
    confidence = scores[best] / max(total, 1)
    return best, confidence


def detect_liturgical_season(text: str) -> str:
    """Detect liturgical season from text."""
    text_lower = text.lower()
    scores: Dict[str, int] = {}

    for season, keywords in LITURGICAL_KEYWORDS.items():
        score = sum(1 for kw in keywords if kw in text_lower)
        if score > 0:
            scores[season] = score

    if not scores:
        return "ordinary"
    return max(scores, key=scores.get)


def suggest_music_params(mood: str, season: str,
                         meter: MeterAnalysis) -> Tuple[str, int, str]:
    """Suggest key, tempo, style from analysis."""
    mood_keys = {
        "joy": "D major", "sorrow": "D minor", "peace": "G major",
        "celebration": "Bb major", "penitence": "C minor",
        "hope": "A major", "awe": "Eb major",
    }
    mood_tempos = {
        "joy": 110, "sorrow": 60, "peace": 72, "celebration": 120,
        "penitence": 56, "hope": 88, "awe": 66,
    }
    season_styles = {
        "advent": "baroque", "christmas": "romantic",
        "passion": "baroque", "easter": "classical",
        "pentecost": "romantic", "ordinary": "baroque",
    }

    key = mood_keys.get(mood, "C major")
    tempo = mood_tempos.get(mood, 80)
    style = season_styles.get(season, "baroque")

    return key, tempo, style


# ═══════════════════════════════════════════════════════════════
# Psalm Tone System
# ═══════════════════════════════════════════════════════════════

@dataclass
class PsalmTone:
    """A psalm tone for chanting."""
    number: int
    mode: str
    intonation: List[int]       # opening notes (MIDI)
    tenor: int                  # reciting tone (MIDI)
    mediatio: List[int]         # middle cadence
    terminatio: List[int]       # final cadence
    flexa: List[int]            # optional flex point


PSALM_TONES: List[PsalmTone] = [
    PsalmTone(1, "dorian",     [62, 64], 69, [69, 67, 65], [67, 65, 64, 62], [69, 67]),
    PsalmTone(2, "hypodorian", [60, 62], 65, [65, 64, 62], [64, 62, 60], [65, 64]),
    PsalmTone(3, "phrygian",   [64, 65], 71, [71, 69, 67], [69, 67, 65, 64], [71, 69]),
    PsalmTone(4, "hypophrygian",[62, 64], 69, [69, 67, 65], [67, 65, 64, 62], [69, 67]),
    PsalmTone(5, "lydian",     [65, 67], 72, [72, 71, 69], [71, 69, 67, 65], [72, 71]),
    PsalmTone(6, "hypolydian", [65, 67], 69, [69, 67, 65], [67, 65, 64], [69, 67]),
    PsalmTone(7, "mixolydian", [67, 69], 74, [74, 72, 71], [72, 71, 69, 67], [74, 72]),
    PsalmTone(8, "hypomixolydian",[65, 67], 72, [72, 71, 69], [71, 69, 67, 65], [72, 71]),
]


def chant_psalm(text: str, tone_number: int = 1) -> List[Dict]:
    """Generate psalm chant from text using a psalm tone.

    Returns list of {midi, text, duration, type} events.
    """
    tone = PSALM_TONES[min(tone_number - 1, 7)]
    lines = [l.strip() for l in text.split("\n") if l.strip()]
    events = []
    beat = 0.0

    for i, line in enumerate(lines):
        words = line.split()
        half = len(words) // 2

        # Intonation (first line only or first of each verse pair)
        if i % 2 == 0:
            for note in tone.intonation:
                events.append({"midi": note, "start_beat": beat,
                               "duration": 0.5, "type": "intonation"})
                beat += 0.5

        # Recitation on tenor
        recit_words = words[:half]
        for w in recit_words:
            syl = count_syllables_de(w)
            for _ in range(syl):
                events.append({"midi": tone.tenor, "start_beat": beat,
                               "duration": 0.5, "type": "recitation", "text": w})
                beat += 0.5

        # Mediatio or Terminatio
        cadence = tone.mediatio if i % 2 == 0 else tone.terminatio
        for note in cadence:
            events.append({"midi": note, "start_beat": beat,
                           "duration": 0.75, "type": "cadence"})
            beat += 0.75

        beat += 0.5  # pause between lines

    return events
