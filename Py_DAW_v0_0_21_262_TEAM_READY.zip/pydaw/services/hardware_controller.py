"""hardware_controller.py — Clip Launcher MIDI Grid Mapping + Hardware Auto-Config.

v0.0.20.912 — C5.1 + C5.3: PRO Features.

C5.1: Maps MIDI controller grid pads (Launchpad, APC40, etc.) to
Clip Launcher slots. Supports note-on → launch, note-off → stop,
velocity-sensitive triggering, and scene launch via dedicated buttons.

C5.3: Auto-detection of MIDI controllers via USB-ID / device name,
with built-in profiles for popular controllers. OSC support for
TouchOSC / Lemur-style wireless controllers.

Usage:
    from pydaw.services.hardware_controller import (
        HardwareControllerService, ControllerProfile, BUILTIN_PROFILES,
    )

    svc = HardwareControllerService(launcher_service=launcher)

    # Auto-detect connected controllers
    svc.auto_detect()

    # Or manually assign a profile
    svc.assign_profile("launchpad_mini_mk3")

    # Process incoming MIDI
    svc.handle_midi_message(msg)

    # OSC
    svc.start_osc_server(port=8000)
"""

from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

log = logging.getLogger(__name__)

try:
    from PyQt6.QtCore import QObject, pyqtSignal
    _HAS_QT = True
except ImportError:
    QObject = object  # type: ignore
    pyqtSignal = lambda *a: None  # type: ignore
    _HAS_QT = False


# ---------------------------------------------------------------------------
# Controller Profiles — Built-in hardware configurations
# ---------------------------------------------------------------------------

@dataclass
class PadMapping:
    """Mapping of a single pad/button on a controller."""
    midi_note: int = 0       # MIDI note number for this pad
    row: int = 0             # Grid row (0 = top)
    col: int = 0             # Grid column (0 = left)
    color_on: int = 0        # LED color when slot is playing
    color_off: int = 0       # LED color when slot is stopped
    color_armed: int = 0     # LED color when slot is armed


@dataclass
class ControllerProfile:
    """Hardware controller profile — pad grid, buttons, LED feedback."""
    name: str = ""
    display_name: str = ""
    # Detection: USB vendor:product IDs or device name patterns
    usb_ids: List[Tuple[int, int]] = field(default_factory=list)  # (vendor, product)
    name_patterns: List[str] = field(default_factory=list)  # Substring match
    # Grid dimensions
    grid_rows: int = 8
    grid_cols: int = 8
    # Pad-to-grid mapping (MIDI note → row, col)
    pad_map: List[PadMapping] = field(default_factory=list)
    # Scene launch buttons (MIDI note → scene index)
    scene_notes: Dict[int, int] = field(default_factory=dict)
    # Transport buttons
    play_note: int = -1
    stop_note: int = -1
    record_note: int = -1
    # MIDI channel (0-15, -1 = any)
    midi_channel: int = -1
    # LED feedback support
    has_led_feedback: bool = False
    led_channel: int = 0  # Channel for LED sysex/notes
    # OSC config (for wireless controllers)
    osc_port: int = 0
    is_osc: bool = False


def _build_launchpad_mini_mk3() -> ControllerProfile:
    """Novation Launchpad Mini MK3 — 8×8 grid + scene buttons."""
    pads = []
    # Launchpad Mini MK3: notes 81-88 (top row), 71-78, ..., 11-18 (bottom)
    for row in range(8):
        for col in range(8):
            note = (8 - row) * 10 + (col + 1)  # 81,82...88, 71,72...78, etc.
            pads.append(PadMapping(
                midi_note=note, row=row, col=col,
                color_on=21,    # Green
                color_off=0,    # Off
                color_armed=5,  # Red
            ))
    # Scene buttons: notes 89, 79, 69, ... , 19
    scenes = {(8 - i) * 10 + 9: i for i in range(8)}
    return ControllerProfile(
        name="launchpad_mini_mk3",
        display_name="Novation Launchpad Mini MK3",
        usb_ids=[(0x1235, 0x0113)],
        name_patterns=["launchpad mini mk3", "launchpad mini"],
        grid_rows=8, grid_cols=8,
        pad_map=pads,
        scene_notes=scenes,
        has_led_feedback=True,
        led_channel=0,
        midi_channel=0,
    )


def _build_launchpad_x() -> ControllerProfile:
    """Novation Launchpad X — 8×8 grid + scene/function buttons."""
    pads = []
    for row in range(8):
        for col in range(8):
            note = (8 - row) * 10 + (col + 1)
            pads.append(PadMapping(
                midi_note=note, row=row, col=col,
                color_on=87, color_off=0, color_armed=72,
            ))
    scenes = {(8 - i) * 10 + 9: i for i in range(8)}
    return ControllerProfile(
        name="launchpad_x",
        display_name="Novation Launchpad X",
        usb_ids=[(0x1235, 0x0103)],
        name_patterns=["launchpad x"],
        grid_rows=8, grid_cols=8, pad_map=pads,
        scene_notes=scenes,
        has_led_feedback=True, led_channel=0, midi_channel=0,
    )


def _build_apc40_mk2() -> ControllerProfile:
    """Akai APC40 MK2 — 5×8 clip grid + scene + transport."""
    pads = []
    # APC40 MK2: clip launch grid notes 0-39 (row 0 = notes 0-7, row 1 = 8-15, ...)
    for row in range(5):
        for col in range(8):
            note = row * 8 + col
            pads.append(PadMapping(
                midi_note=note, row=row, col=col,
                color_on=1, color_off=0, color_armed=3,
            ))
    # Scene launch: notes 82-86
    scenes = {82 + i: i for i in range(5)}
    return ControllerProfile(
        name="apc40_mk2",
        display_name="Akai APC40 MK2",
        usb_ids=[(0x09E8, 0x0097)],
        name_patterns=["apc40", "apc 40"],
        grid_rows=5, grid_cols=8, pad_map=pads,
        scene_notes=scenes,
        play_note=91, stop_note=92, record_note=93,
        has_led_feedback=True, led_channel=0, midi_channel=0,
    )


def _build_apc_mini_mk2() -> ControllerProfile:
    """Akai APC Mini MK2 — 8×8 grid + scene buttons."""
    pads = []
    for row in range(8):
        for col in range(8):
            note = (7 - row) * 8 + col  # Bottom-up
            pads.append(PadMapping(
                midi_note=note, row=row, col=col,
                color_on=1, color_off=0, color_armed=3,
            ))
    scenes = {64 + i: i for i in range(8)}
    return ControllerProfile(
        name="apc_mini_mk2",
        display_name="Akai APC Mini MK2",
        usb_ids=[(0x09E8, 0x004F)],
        name_patterns=["apc mini"],
        grid_rows=8, grid_cols=8, pad_map=pads,
        scene_notes=scenes,
        has_led_feedback=True, led_channel=0, midi_channel=0,
    )


def _build_generic_8x8() -> ControllerProfile:
    """Generic 8×8 MIDI pad controller (notes 0-63)."""
    pads = []
    for row in range(8):
        for col in range(8):
            pads.append(PadMapping(
                midi_note=row * 8 + col, row=row, col=col,
            ))
    return ControllerProfile(
        name="generic_8x8",
        display_name="Generic 8×8 Grid Controller",
        grid_rows=8, grid_cols=8, pad_map=pads,
        midi_channel=-1,
    )


def _build_nanokey2() -> ControllerProfile:
    """Korg nanoKEY2 — 25-key keyboard, no grid but scene triggers."""
    # Map C2-B3 (notes 36-59) to 2 rows of 12
    pads = []
    for i in range(24):
        pads.append(PadMapping(
            midi_note=36 + i, row=i // 12, col=i % 12,
        ))
    return ControllerProfile(
        name="nanokey2",
        display_name="Korg nanoKEY2",
        usb_ids=[(0x0944, 0x0115)],
        name_patterns=["nanokey2", "nanokey 2"],
        grid_rows=2, grid_cols=12, pad_map=pads,
        midi_channel=-1,
    )


def _build_nanokontrol2() -> ControllerProfile:
    """Korg nanoKONTROL2 — faders/knobs/buttons, map S/M/R to scenes."""
    # No grid pads, but Solo/Mute/Record buttons → scene triggers
    scenes = {}
    # Solo buttons: CC 32-39 → treat note_on 32-39 as scene triggers
    for i in range(8):
        scenes[32 + i] = i  # S buttons
    return ControllerProfile(
        name="nanokontrol2",
        display_name="Korg nanoKONTROL2",
        usb_ids=[(0x0944, 0x0117)],
        name_patterns=["nanokontrol2", "nanokontrol 2"],
        grid_rows=0, grid_cols=0,
        scene_notes=scenes,
        play_note=41, stop_note=42, record_note=45,
        midi_channel=-1,
    )


def _build_touchosc() -> ControllerProfile:
    """TouchOSC — wireless OSC controller (iOS/Android)."""
    pads = []
    for row in range(8):
        for col in range(8):
            pads.append(PadMapping(
                midi_note=row * 8 + col, row=row, col=col,
            ))
    return ControllerProfile(
        name="touchosc",
        display_name="TouchOSC (Wireless)",
        is_osc=True, osc_port=8000,
        grid_rows=8, grid_cols=8, pad_map=pads,
    )


# Built-in profile registry
BUILTIN_PROFILES: Dict[str, ControllerProfile] = {}


def _register_builtins():
    for builder in [
        _build_launchpad_mini_mk3, _build_launchpad_x,
        _build_apc40_mk2, _build_apc_mini_mk2,
        _build_generic_8x8, _build_nanokey2, _build_nanokontrol2,
        _build_touchosc,
    ]:
        try:
            p = builder()
            BUILTIN_PROFILES[p.name] = p
        except Exception:
            pass


_register_builtins()


# ---------------------------------------------------------------------------
# HardwareControllerService
# ---------------------------------------------------------------------------

class HardwareControllerService(QObject if _HAS_QT else object):
    """MIDI/OSC grid controller → Clip Launcher bridge.

    Maps hardware pad presses to clip launcher slot launches,
    with LED feedback and auto-detection.
    """

    if _HAS_QT:
        controller_detected = pyqtSignal(str)  # profile_name
        pad_pressed = pyqtSignal(int, int, int)  # row, col, velocity
        status_message = pyqtSignal(str, int)

    def __init__(self, launcher_service=None, midi_service=None,
                 parent=None):
        if _HAS_QT and parent is not None:
            super().__init__(parent)
        elif _HAS_QT:
            super().__init__()
        self._launcher = launcher_service
        self._midi = midi_service
        self._profile: Optional[ControllerProfile] = None
        self._note_to_pad: Dict[int, PadMapping] = {}
        self._osc_thread: Optional[threading.Thread] = None
        self._osc_running = False
        self._on_slot_key: Optional[Callable] = None
        # Grid state for LED feedback
        self._grid_state: Dict[Tuple[int, int], str] = {}  # (row,col) → "playing"|"stopped"|"armed"

    # ------------------------------------------------------------------
    # Profile Management
    # ------------------------------------------------------------------

    def assign_profile(self, profile_name: str) -> bool:
        """Assign a controller profile by name."""
        profile = BUILTIN_PROFILES.get(profile_name)
        if not profile:
            log.warning("Unknown controller profile: %s", profile_name)
            return False
        self._profile = profile
        self._note_to_pad = {
            p.midi_note: p for p in profile.pad_map
        }
        log.info("Controller profile assigned: %s (%dx%d grid)",
                 profile.display_name, profile.grid_rows, profile.grid_cols)
        if _HAS_QT:
            try:
                self.controller_detected.emit(profile_name)
            except Exception:
                pass
        return True

    def get_profile(self) -> Optional[ControllerProfile]:
        """Get the current controller profile."""
        return self._profile

    def list_profiles(self) -> List[Dict[str, Any]]:
        """List all available controller profiles."""
        return [
            {
                "name": p.name,
                "display_name": p.display_name,
                "grid": f"{p.grid_rows}x{p.grid_cols}",
                "has_led": p.has_led_feedback,
                "is_osc": p.is_osc,
            }
            for p in BUILTIN_PROFILES.values()
        ]

    # ------------------------------------------------------------------
    # Auto-Detection
    # ------------------------------------------------------------------

    def auto_detect(self, device_names: Optional[List[str]] = None) -> Optional[str]:
        """Auto-detect connected controller by device name matching.

        Args:
            device_names: list of connected MIDI device names
                (if None, tries to get from MidiService)

        Returns:
            Profile name if detected, None otherwise
        """
        if device_names is None:
            if self._midi and hasattr(self._midi, 'list_inputs'):
                try:
                    device_names = self._midi.list_inputs()
                except Exception:
                    device_names = []
            else:
                device_names = []

        if not device_names:
            return None

        for dev_name in device_names:
            dev_lower = dev_name.lower()
            for profile in BUILTIN_PROFILES.values():
                if profile.is_osc:
                    continue  # OSC can't be auto-detected via MIDI
                for pattern in profile.name_patterns:
                    if pattern in dev_lower:
                        log.info("Auto-detected controller: %s → %s",
                                 dev_name, profile.display_name)
                        self.assign_profile(profile.name)
                        return profile.name

        log.debug("No known controller detected among: %s",
                  ", ".join(device_names))
        return None

    # ------------------------------------------------------------------
    # MIDI Message Handling → Clip Launcher
    # ------------------------------------------------------------------

    def handle_midi_message(self, msg) -> bool:
        """Process an incoming MIDI message for clip launcher control.

        Args:
            msg: mido Message (or dict with type, note, velocity, channel)

        Returns:
            True if the message was consumed (mapped to a clip action)
        """
        if not self._profile:
            return False

        try:
            # Extract fields from mido message or dict
            if hasattr(msg, 'type'):
                msg_type = msg.type
                note = getattr(msg, 'note', 0)
                velocity = getattr(msg, 'velocity', 0)
                channel = getattr(msg, 'channel', 0)
            elif isinstance(msg, dict):
                msg_type = msg.get('type', '')
                note = int(msg.get('note', 0))
                velocity = int(msg.get('velocity', 0))
                channel = int(msg.get('channel', 0))
            else:
                return False

            # Channel filter
            if self._profile.midi_channel >= 0 and channel != self._profile.midi_channel:
                return False

            # Note On → launch slot or scene
            if msg_type == 'note_on' and velocity > 0:
                return self._handle_note_on(note, velocity)

            # Note Off → stop slot (optional)
            elif msg_type == 'note_off' or (msg_type == 'note_on' and velocity == 0):
                return self._handle_note_off(note)

        except Exception as e:
            log.warning("Hardware controller MIDI error: %s", e)

        return False

    def _handle_note_on(self, note: int, velocity: int) -> bool:
        """Handle note-on: launch clip or scene."""
        profile = self._profile
        if not profile:
            return False

        # Check scene buttons
        if note in profile.scene_notes:
            scene_idx = profile.scene_notes[note]
            self._launch_scene(scene_idx)
            return True

        # Check transport buttons
        if note == profile.play_note and profile.play_note >= 0:
            self._transport_action("play")
            return True
        if note == profile.stop_note and profile.stop_note >= 0:
            self._transport_action("stop")
            return True
        if note == profile.record_note and profile.record_note >= 0:
            self._transport_action("record")
            return True

        # Check pad grid
        pad = self._note_to_pad.get(note)
        if pad:
            self._launch_slot(pad.row, pad.col, velocity)
            if _HAS_QT:
                try:
                    self.pad_pressed.emit(pad.row, pad.col, velocity)
                except Exception:
                    pass
            return True

        return False

    def _handle_note_off(self, note: int) -> bool:
        """Handle note-off (currently no-op, could implement toggle/stop)."""
        # Future: implement toggle-stop behavior for clip slots
        return note in self._note_to_pad

    # ------------------------------------------------------------------
    # Clip Launcher Integration
    # ------------------------------------------------------------------

    def _launch_slot(self, row: int, col: int, velocity: int = 127) -> None:
        """Launch a clip at grid position (row, col)."""
        slot_key = f"{col}:{row}"  # track:scene format
        log.debug("Grid launch: row=%d col=%d → slot_key=%s vel=%d",
                  row, col, slot_key, velocity)
        if self._launcher and hasattr(self._launcher, 'launch_slot'):
            try:
                self._launcher.launch_slot(slot_key)
                self._grid_state[(row, col)] = "playing"
            except Exception as e:
                log.warning("Slot launch failed: %s", e)
        elif self._on_slot_key:
            self._on_slot_key(slot_key, velocity)

    def _launch_scene(self, scene_idx: int) -> None:
        """Launch all clips in a scene row."""
        log.debug("Scene launch: scene=%d", scene_idx)
        if self._launcher and hasattr(self._launcher, 'launch_scene'):
            try:
                self._launcher.launch_scene(scene_idx)
            except Exception as e:
                log.warning("Scene launch failed: %s", e)

    def _transport_action(self, action: str) -> None:
        """Handle transport button (play/stop/record)."""
        log.debug("Transport: %s", action)
        # This would be wired to TransportService
        if _HAS_QT:
            try:
                self.status_message.emit(f"Transport: {action}", 2000)
            except Exception:
                pass

    # ------------------------------------------------------------------
    # LED Feedback
    # ------------------------------------------------------------------

    def send_led_update(self, row: int, col: int, state: str = "off") -> None:
        """Send LED color update to controller (if supported).

        Args:
            row, col: grid position
            state: "playing", "stopped", "armed", "off"
        """
        if not self._profile or not self._profile.has_led_feedback:
            return

        pad = None
        for p in self._profile.pad_map:
            if p.row == row and p.col == col:
                pad = p
                break
        if not pad:
            return

        color_map = {
            "playing": pad.color_on,
            "stopped": pad.color_off,
            "armed": pad.color_armed,
            "off": 0,
        }
        color = color_map.get(state, 0)

        # Send note-on with velocity = color on LED channel
        if self._midi and hasattr(self._midi, 'send_raw'):
            try:
                ch = self._profile.led_channel
                # Note-on: 0x90 + channel, note, velocity(=color)
                self._midi.send_raw([0x90 + ch, pad.midi_note, color])
            except Exception as e:
                log.warning("LED update failed: %s", e)

    def update_all_leds(self, grid_state: Dict[Tuple[int, int], str]) -> None:
        """Update all LEDs based on grid state dict."""
        if not self._profile or not self._profile.has_led_feedback:
            return
        for (row, col), state in grid_state.items():
            self.send_led_update(row, col, state)

    # ------------------------------------------------------------------
    # OSC Support (C5.3)
    # ------------------------------------------------------------------

    def start_osc_server(self, port: int = 8000) -> bool:
        """Start a simple OSC server for wireless controllers.

        Listens for OSC messages like /grid/row/col (float 0-1)
        and maps them to clip launcher slots.

        Returns True if started successfully.
        """
        if self._osc_running:
            return True

        try:
            import socket
            import struct

            def _osc_thread():
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                sock.bind(("0.0.0.0", port))
                sock.settimeout(1.0)
                log.info("OSC server started on port %d", port)

                while self._osc_running:
                    try:
                        data, addr = sock.recvfrom(4096)
                        self._parse_osc_message(data)
                    except socket.timeout:
                        continue
                    except Exception as e:
                        if self._osc_running:
                            log.warning("OSC recv error: %s", e)

                sock.close()
                log.info("OSC server stopped")

            self._osc_running = True
            self._osc_thread = threading.Thread(
                target=_osc_thread, daemon=True, name="OSC-Server"
            )
            self._osc_thread.start()
            return True

        except Exception as e:
            log.warning("OSC server failed to start: %s", e)
            self._osc_running = False
            return False

    def stop_osc_server(self) -> None:
        """Stop the OSC server."""
        self._osc_running = False
        if self._osc_thread:
            self._osc_thread.join(timeout=3.0)
            self._osc_thread = None

    def _parse_osc_message(self, data: bytes) -> None:
        """Parse a raw OSC message and handle grid/transport commands.

        Supported OSC addresses:
        - /grid/<row>/<col>  value=1.0 → launch, value=0.0 → stop
        - /scene/<idx>       value=1.0 → launch scene
        - /transport/play    value=1.0 → play
        - /transport/stop    value=1.0 → stop
        """
        try:
            # Basic OSC parsing (address string + float arg)
            if len(data) < 8:
                return
            # Find null terminator for address
            null_idx = data.index(0)
            address = data[:null_idx].decode('ascii', errors='ignore')
            # Skip padding + type tag
            # Simple float extraction from end
            if len(data) >= null_idx + 12:
                import struct
                # Last 4 bytes are typically the float value
                value = struct.unpack('>f', data[-4:])[0]
            else:
                value = 1.0

            parts = address.strip('/').split('/')
            if len(parts) >= 3 and parts[0] == 'grid':
                row = int(parts[1])
                col = int(parts[2])
                if value > 0.5:
                    self._launch_slot(row, col, int(value * 127))
            elif len(parts) >= 2 and parts[0] == 'scene':
                idx = int(parts[1])
                if value > 0.5:
                    self._launch_scene(idx)
            elif len(parts) >= 2 and parts[0] == 'transport':
                if value > 0.5:
                    self._transport_action(parts[1])

        except Exception as e:
            log.debug("OSC parse error: %s", e)

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------

    def shutdown(self) -> None:
        """Stop OSC server and clean up."""
        self.stop_osc_server()
        self._profile = None
        self._note_to_pad.clear()
