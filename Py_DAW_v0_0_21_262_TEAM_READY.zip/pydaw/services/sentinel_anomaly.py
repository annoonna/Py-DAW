"""sentinel_anomaly.py — Anomaly Detector + Echo-Loop Breaker (S3+S7).

v0.0.20.904 — Phases S3 + S7 der SENTINEL_ROADMAP.

Erkennt:
- Echo-Loops (>50 msg/s, confidence=1.0 → Stufe 5)
- CPU-Spikes (>200% Baseline → Stufe 2-3)
- Memory-Leaks (monotoner Anstieg → Stufe 2-3)
- Plugin-Timeouts (>5s → Stufe 4, >10s → Stufe 5)
- Thread-Deadlocks (>5s blocked → Stufe 4-5)
- Disk-Space-Warnung (<500MB → Stufe 2, <100MB → Stufe 3)

DESIGN-PRINZIP: Nur bewiesene Probleme (confidence>=0.95) erreichen
Stufe 4+. False Positives werden gelernt und vermieden.
"""

from __future__ import annotations

import logging
import os
import time
from collections import deque
from typing import Any, Callable, Dict, List, Optional, Tuple

log = logging.getLogger(__name__)

try:
    from PyQt6.QtCore import QObject, QTimer, pyqtSignal
    _QT = True
except ImportError:
    _QT = False

# ── Severity levels (match SENTINEL roadmap) ──
SEV_INFO = 1
SEV_HINT = 2
SEV_WARN = 3
SEV_ALARM = 4
SEV_EMERGENCY = 5

# ── Thresholds ──
ECHO_LOOP_THRESHOLD = 50       # messages/second → confidence=1.0
ECHO_LOOP_BREAK_THRESHOLD = 20 # messages/5sec for same op_type
CPU_SPIKE_RATIO = 2.0           # 200% of baseline
CPU_BASELINE_WINDOW = 30        # seconds for baseline average
MEMORY_LEAK_MB_PER_MIN = 5.0   # MB/minute
MEMORY_LEAK_MIN_DURATION = 300  # 5 minutes
PLUGIN_TIMEOUT_WARN = 5.0      # seconds
PLUGIN_TIMEOUT_CRIT = 10.0     # seconds
DISK_WARN_MB = 500
DISK_CRIT_MB = 100
GIL_STARVATION_MS = 30       # v0.0.21.190 — D-3: 15→30ms (warn).
                             # v.189-Live-Test bei Anno hat reproducible
                             # 30–70ms-Spikes beim Project-Load (5 FLUX-Patches
                             # IPC-Sync) und beim Stop (Engine-Cleanup) gezeigt —
                             # das sind erwartete, harmlose Bursts. 30ms gibt
                             # genug Headroom ohne echte Glitch-Quellen zu
                             # verstecken.
GIL_STARVATION_CRIT_MS = 100 # v0.0.21.190 — D-3: 50→100ms (critical).
                             # Anno's v.189-Log zeigt einmalig Peak=209ms beim
                             # Multi-Patch-Sync — das war ALARM bei 50ms-Schwelle,
                             # ist aber kein echtes Audio-Glitch-Risiko da der
                             # Audio-Thread während Sync sowieso try_lock-skipped.
                             # Bei echten Polyphonie-Tests in F-1.6 wäre die alte
                             # Schwelle Quelle für False-Positives, die die
                             # Stimmen-Stress-Messung verfälschen.


@staticmethod
def _disk_free_mb(path: str = ".") -> float:
    try:
        st = os.statvfs(path)
        return (st.f_bavail * st.f_frsize) / (1024 * 1024)
    except Exception:
        return -1.0


if _QT:

    class SentinelAnomaly(QObject):
        """Anomaly detector — checks for known problem patterns.

        Emits signals so the UI can display warnings/alerts.
        """

        # Signals for UI
        anomaly_detected = pyqtSignal(int, str, str)   # severity, type, description
        anomaly_resolved = pyqtSignal(int, str)         # anomaly_id, type
        echo_loop_broken = pyqtSignal(str, int)         # op_type, rate

        _instance: Optional["SentinelAnomaly"] = None

        @classmethod
        def get(cls) -> "SentinelAnomaly":
            if cls._instance is None:
                cls._instance = cls()
            return cls._instance

        def __init__(self, parent=None):
            super().__init__(parent)
            self._db = None
            self._recorder = None
            self._running = False

            # CPU baseline tracking
            self._cpu_history: deque = deque(maxlen=60)  # 30s at 500ms
            self._cpu_baseline: float = 10.0

            # Memory leak tracking
            self._mem_history: deque = deque(maxlen=150)  # 5min at 2s
            self._mem_start_time: float = 0.0

            # Echo-loop breaker state
            self._echo_cooldowns: Dict[str, float] = {}  # op_type → cooldown_until
            self._echo_broken_types: Dict[str, int] = {}  # op_type → break_count

            # Active anomalies (for dedup)
            self._active: Dict[str, int] = {}  # key → anomaly_id

            # v0.0.20.905 S12: Live-Mode flag (no auto-isolation when True)
            self._live_mode: bool = False

            # Check timer
            self._timer = QTimer(self)
            self._timer.setInterval(2000)
            self._timer.timeout.connect(self._check_all)

        def start(self, recorder=None) -> None:
            try:
                from pydaw.services.sentinel_db import SentinelDB
                self._db = SentinelDB.get()
                self._db.ensure_loaded()
            except Exception:
                pass
            self._recorder = recorder
            self._running = True
            self._mem_start_time = time.time()
            self._timer.start()
            log.info("[SENTINEL] Anomaly Detector started")

        def stop(self) -> None:
            self._timer.stop()
            self._running = False
            log.info("[SENTINEL] Anomaly Detector stopped")

        # ══════════════════════════════════════════════════════════
        # Main Check Loop (every 2s)
        # ══════════════════════════════════════════════════════════

        def _check_all(self) -> None:
            if not self._running:
                return
            try:
                self._check_echo_loops()
                self._check_cpu()
                self._check_memory()
                self._check_disk()
                self._check_gil()  # v0.0.20.942: GIL starvation detection
            except Exception as e:
                log.debug("[SENTINEL] check_all error: %s", e)

        # ══════════════════════════════════════════════════════════
        # S7: Echo-Loop Detection + Breaker
        # ══════════════════════════════════════════════════════════

        def check_message_rate(self, op_type: str, current_rate: int) -> bool:
            """Check if a message rate indicates an echo-loop.

            Called in real-time by collab_panel before sending.
            Returns True if message should be BLOCKED (echo-loop detected).
            """
            now = time.time()

            # Check cooldown
            cd = self._echo_cooldowns.get(op_type, 0)
            if cd > now:
                return True  # BLOCK — still in cooldown

            # Check rate
            if current_rate >= ECHO_LOOP_THRESHOLD:
                # CONFIRMED echo-loop — confidence=1.0
                self._echo_cooldowns[op_type] = now + 5.0  # 5s cooldown
                self._echo_broken_types[op_type] = self._echo_broken_types.get(op_type, 0) + 1

                desc = (f"Echo-Loop: {current_rate} '{op_type}' Messages/Sekunde "
                        f"(Schwelle: {ECHO_LOOP_THRESHOLD}) — 5s Cooldown aktiviert")
                log.warning("[SENTINEL] %s", desc)

                if self._db:
                    self._db.log_anomaly(
                        "echo_loop", SEV_EMERGENCY, f"collab:{op_type}",
                        desc, evidence={"rate": current_rate, "threshold": ECHO_LOOP_THRESHOLD},
                        action_taken="cooldown_5s",
                    )
                    self._db.log_action(
                        "broke_loop", f"collab:{op_type}",
                        reason=desc, severity=SEV_EMERGENCY, auto_action=True,
                    )

                self.echo_loop_broken.emit(op_type, current_rate)
                self.anomaly_detected.emit(SEV_EMERGENCY, "echo_loop", desc)
                return True  # BLOCK

            if current_rate >= ECHO_LOOP_BREAK_THRESHOLD:
                # Getting close — warn
                key = f"echo_warn:{op_type}"
                if key not in self._active:
                    desc = f"Hohe Message-Rate: {current_rate}/s fuer '{op_type}'"
                    if self._db:
                        aid = self._db.log_anomaly(
                            "high_message_rate", SEV_WARN, f"collab:{op_type}",
                            desc, evidence={"rate": current_rate},
                        )
                        self._active[key] = aid
                    self.anomaly_detected.emit(SEV_WARN, "high_message_rate", desc)

            return False  # Allow

        def _check_echo_loops(self) -> None:
            """Periodic check — clean up expired cooldowns."""
            now = time.time()
            expired = [k for k, v in self._echo_cooldowns.items() if v <= now]
            for k in expired:
                del self._echo_cooldowns[k]
                # Resolve active anomaly
                key = f"echo_warn:{k}"
                if key in self._active:
                    aid = self._active.pop(key)
                    if self._db:
                        self._db.resolve_anomaly(aid, "cooldown_expired")

        def is_op_blocked(self, op_type: str) -> bool:
            """Check if an op_type is currently blocked by echo-loop breaker."""
            return self._echo_cooldowns.get(op_type, 0) > time.time()

        # ══════════════════════════════════════════════════════════
        # CPU Spike Detection
        # ══════════════════════════════════════════════════════════

        def _check_cpu(self) -> None:
            if not self._recorder:
                return
            rb = self._recorder._ringbuffer
            if not rb:
                return

            last = rb[-1] if rb else {}
            cpu = last.get("cpu", 0)
            self._cpu_history.append(cpu)

            # Update baseline (average of last 30s)
            if len(self._cpu_history) >= 10:
                self._cpu_baseline = sum(self._cpu_history) / len(self._cpu_history)

            # Check for spike
            if self._cpu_baseline > 1.0 and cpu > self._cpu_baseline * CPU_SPIKE_RATIO:
                key = "cpu_spike"
                if key not in self._active:
                    desc = (f"CPU-Spike: {cpu:.0f}% "
                            f"(Baseline: {self._cpu_baseline:.0f}%)")
                    if self._db:
                        aid = self._db.log_anomaly(
                            "cpu_spike", SEV_HINT, "", desc,
                            evidence={"cpu": cpu, "baseline": self._cpu_baseline},
                        )
                        self._active[key] = aid
                    self.anomaly_detected.emit(SEV_HINT, "cpu_spike", desc)
            else:
                # Resolve if active
                if "cpu_spike" in self._active:
                    aid = self._active.pop("cpu_spike")
                    if self._db:
                        self._db.resolve_anomaly(aid)
                    self.anomaly_resolved.emit(aid, "cpu_spike")

        # ══════════════════════════════════════════════════════════
        # Memory Leak Detection
        # ══════════════════════════════════════════════════════════

        def _check_memory(self) -> None:
            if not self._recorder:
                return
            rb = self._recorder._ringbuffer
            if not rb:
                return

            last = rb[-1] if rb else {}
            mem = last.get("mem_mb", 0)
            if mem <= 0:
                return

            self._mem_history.append((time.time(), mem))

            # Need at least 5 min of data
            if len(self._mem_history) < 30:
                return

            first_t, first_m = self._mem_history[0]
            last_t, last_m = self._mem_history[-1]
            duration_min = (last_t - first_t) / 60.0

            if duration_min < 1.0:
                return

            growth_per_min = (last_m - first_m) / duration_min

            if growth_per_min > MEMORY_LEAK_MB_PER_MIN and duration_min > 3:
                key = "memory_leak"
                severity = SEV_WARN if (last_m - first_m) > 50 else SEV_HINT
                if key not in self._active:
                    desc = (f"Memory-Anstieg: +{growth_per_min:.1f} MB/Min "
                            f"(seit {duration_min:.0f} Min, total +{last_m - first_m:.0f} MB)")
                    if self._db:
                        aid = self._db.log_anomaly(
                            "memory_leak", severity, "", desc,
                            evidence={"growth_mb_per_min": growth_per_min,
                                      "duration_min": duration_min,
                                      "total_growth_mb": last_m - first_m},
                        )
                        self._active[key] = aid
                    self.anomaly_detected.emit(severity, "memory_leak", desc)

        # ══════════════════════════════════════════════════════════
        # Disk Space
        # ══════════════════════════════════════════════════════════

        def _check_disk(self) -> None:
            try:
                free = _disk_free_mb()
            except Exception:
                return
            if free < 0:
                return

            key = "disk_space"
            if free < DISK_CRIT_MB:
                if key not in self._active:
                    desc = f"Disk fast voll: nur noch {free:.0f} MB frei"
                    if self._db:
                        aid = self._db.log_anomaly(
                            "disk_space", SEV_WARN, "", desc,
                            evidence={"free_mb": free},
                        )
                        self._active[key] = aid
                    self.anomaly_detected.emit(SEV_WARN, "disk_space", desc)
            elif free < DISK_WARN_MB:
                if key not in self._active:
                    desc = f"Disk-Warnung: {free:.0f} MB frei"
                    if self._db:
                        aid = self._db.log_anomaly(
                            "disk_space", SEV_HINT, "", desc,
                            evidence={"free_mb": free},
                        )
                        self._active[key] = aid
                    self.anomaly_detected.emit(SEV_HINT, "disk_space", desc)
            else:
                if key in self._active:
                    aid = self._active.pop(key)
                    if self._db:
                        self._db.resolve_anomaly(aid)

        # ══════════════════════════════════════════════════════════
        # v0.0.20.942: GIL Starvation Detection
        # ══════════════════════════════════════════════════════════

        def _check_gil(self) -> None:
            """Detect GIL starvation — when UI thread holds GIL too long.

            Uses a background thread that measures how long time.sleep(0)
            actually takes. If GIL is held by another thread, sleep(0)
            will be delayed because it needs to re-acquire the GIL.

            This is the ONLY way to detect GIL contention in CPython.
            """
            try:
                import threading

                if not hasattr(self, '_gil_watchdog_running'):
                    self._gil_watchdog_running = True
                    self._gil_peak_ms = 0.0
                    self._gil_starvation_count = 0
                    self._gil_history: deque = deque(maxlen=30)

                    def _gil_watchdog():
                        """Background thread that probes GIL response time."""
                        while getattr(self, '_gil_watchdog_running', False):
                            t0 = time.perf_counter()
                            time.sleep(0.001)  # 1ms sleep — should return in ~1ms
                            elapsed_ms = (time.perf_counter() - t0) * 1000.0
                            gil_wait_ms = max(0, elapsed_ms - 1.0)  # subtract expected 1ms

                            if gil_wait_ms > 2.0:  # only log significant delays
                                self._gil_history.append(gil_wait_ms)
                                if gil_wait_ms > self._gil_peak_ms:
                                    self._gil_peak_ms = gil_wait_ms

                            time.sleep(0.050)  # probe every 50ms

                    t = threading.Thread(target=_gil_watchdog, daemon=True, name="SENTINEL-GIL")
                    t.start()
                    log.info("[SENTINEL] GIL watchdog started")

                # Analyze collected data
                if not hasattr(self, '_gil_history'):
                    return

                recent = list(self._gil_history)
                if not recent:
                    # No GIL starvation detected — resolve if active
                    key = "gil_starvation"
                    if key in self._active:
                        aid = self._active.pop(key)
                        if self._db:
                            self._db.resolve_anomaly(aid)
                    return

                avg_ms = sum(recent) / len(recent) if recent else 0
                peak_ms = self._gil_peak_ms

                key = "gil_starvation"

                if peak_ms > GIL_STARVATION_CRIT_MS:
                    self._gil_starvation_count += 1
                    # v0.0.21.203 (A-2): MotionThrottleService informieren —
                    # der Saga-Renderer und andere Animation-Komponenten
                    # reduzieren dann automatisch ihre Render-Last.
                    try:
                        from pydaw.services.motion_throttle_service import (
                            get_motion_throttle,
                        )
                        get_motion_throttle().set_sentinel_throttle(True)
                    except Exception as e:
                        log.debug("[SENTINEL] motion-throttle hook failed: %s", e)
                    if key not in self._active:
                        desc = (f"GIL-Starvation: Audio-Thread blockiert! "
                                f"Peak={peak_ms:.0f}ms, Avg={avg_ms:.1f}ms "
                                f"(Schwelle: {GIL_STARVATION_CRIT_MS}ms) — "
                                f"UI-Thread hält GIL zu lange → Audio-Glitches")
                        log.warning("[SENTINEL] %s", desc)
                        if self._db:
                            aid = self._db.log_anomaly(
                                "gil_starvation", SEV_ALARM, "audio",
                                desc, evidence={
                                    "peak_ms": round(peak_ms, 1),
                                    "avg_ms": round(avg_ms, 1),
                                    "samples": len(recent),
                                    "count": self._gil_starvation_count,
                                },
                            )
                            self._active[key] = aid
                        self.anomaly_detected.emit(SEV_ALARM, "gil_starvation", desc)

                elif peak_ms > GIL_STARVATION_MS:
                    if key not in self._active:
                        desc = (f"GIL-Warnung: Peak={peak_ms:.0f}ms, Avg={avg_ms:.1f}ms "
                                f"— möglicherweise Audio-Stutter")
                        if self._db:
                            aid = self._db.log_anomaly(
                                "gil_starvation", SEV_HINT, "audio",
                                desc, evidence={
                                    "peak_ms": round(peak_ms, 1),
                                    "avg_ms": round(avg_ms, 1),
                                },
                            )
                            self._active[key] = aid
                else:
                    if key in self._active:
                        aid = self._active.pop(key)
                        if self._db:
                            self._db.resolve_anomaly(aid)
                        # v0.0.21.203 (A-2): GIL-Erholung → Sentinel-
                        # Throttle löschen, damit Saga + Animation wieder
                        # auf voller Render-Last laufen können.
                        try:
                            from pydaw.services.motion_throttle_service import (
                                get_motion_throttle,
                            )
                            get_motion_throttle().set_sentinel_throttle(False)
                        except Exception as e:
                            log.debug("[SENTINEL] motion-throttle release failed: %s", e)

                # Reset peak after check (sliding window)
                self._gil_peak_ms = max(recent[-5:]) if len(recent) >= 5 else 0
                self._gil_history.clear()

            except Exception as e:
                log.debug("[SENTINEL] _check_gil error: %s", e)

        # ══════════════════════════════════════════════════════════
        # Query
        # ══════════════════════════════════════════════════════════

        def get_health_status(self) -> str:
            """Get overall health: 'healthy', 'warning', or 'critical'."""
            if not self._active:
                return "healthy"
            max_sev = max(
                (self._db.get_active_anomalies()[0].get("severity", 1)
                 if self._db and self._db.get_active_anomalies() else 1),
                max((0,), default=0),
            )
            # Simpler: check active dict
            for key in self._active:
                if "echo" in key:
                    return "critical"
            if len(self._active) > 2:
                return "warning"
            return "warning" if self._active else "healthy"

else:
    class SentinelAnomaly:
        _instance = None

        @classmethod
        def get(cls):
            if cls._instance is None:
                cls._instance = cls()
            return cls._instance

        def __init__(self):
            pass

        def start(self, recorder=None):
            pass

        def stop(self):
            pass

        def check_message_rate(self, op_type="", current_rate=0):
            return False

        def is_op_blocked(self, op_type=""):
            return False
