"""
pydaw.services.flux_vault_factory_living — V-2 Living-Patterns Factory-Presets

**v0.0.21.231 — Living-Patterns + Number-Probe Edition**
========================================================

Anno-Auftrag (2026-05-04, mit 6 Screenshots): „kuck auch mal in die
bilder der patch funktioniert so nicht vieleicht kannst du das gleich
mit machen" + „könntest du noch ein number modul bauen wo ich sehe das
da zahlen durch gehen also nubers mit ein und ausgängen ich will an
lfo sehen ob da was durch kommt".

Diese Factory liefert Vault-Presets die die v.230/v.231-Features
demonstrieren:

| Preset | Demo |
|---|---|
| Living-Patterns-Demo | Vör.RouteV mit pre-promoted 4.0/6.0 — Phase-W-Foundation |
| LFO-Probes-Random-Synth | Anno's Screenshot-Patch korrigiert (Plus(60), 3× NumberFlow probes, LFOSquare phase=0.25) |

Die LFO-Probes-Demo ist DIE Antwort auf „der patch funktioniert so
nicht": Random→Mtof produziert ohne Plus(60) sub-audio (8-10 Hz), das
ist im SineOsc auf 20 Hz hard-clamped → unhörbar. Mit Plus(60) wird
0..3 zu MIDI 60..63 = C4..D♯4 = ~261-311 Hz, perfekt hörbar.
NumberFlow zeigt am Patch live an dass die LFOs tatsächlich Werte
liefern (statt im Dunkeln raten).

NICHTS-KAPUTT: rein additiv, kein Eingriff in v.229/v.230-Vaults.
"""
from __future__ import annotations

import logging
from typing import Optional

logger = logging.getLogger(__name__)


LIVING_FACTORY_VERSION = "v1"
LIVING_FACTORY_AUTHOR = (
    f"FLUX Factory (Living {LIVING_FACTORY_VERSION})"
)


def _connect(patch, src_id: str, src_port: str,
             tgt_id: str, tgt_port: str) -> bool:
    from pydaw.flux.patch_model import Connection
    src = patch.get_module(src_id)
    tgt = patch.get_module(tgt_id)
    if src is None or tgt is None:
        return False
    patch.add_connection(Connection(
        source_module=src_id, source_port=src_port,
        target_module=tgt_id, target_port=tgt_port,
    ))
    return True


def _set(module, **params) -> None:
    if module is None:
        return
    for k, v in params.items():
        module.params[k] = v


def _build_patch_dict(name: str, builder) -> Optional[dict]:
    try:
        from pydaw.flux.patch_model import Patch
        p = Patch(name=name, author=LIVING_FACTORY_AUTHOR)
        ok = builder(p)
        if not ok:
            return None
        return p.to_dict()
    except Exception as e:
        logger.warning("[LivingPresets] build %s failed: %s", name, e)
        return None


# ─── Preset 1: Living Patterns Demo (RouteV pre-promoted) ─────────


def _build_living_patterns_demo(p) -> bool:
    """Vör.RouteV mit Pre-Promoted-Patterns 4.0 und 6.0 als Quickstart-Demo
    für die Living-Patterns-Architektur (v.230/v.231 Phase W).

    Stream: Norns.Metro → Ullr.Random(8) → Vör.RouteV → 2× Plus(60/72) → Mtof → SineOsc.

    Frozen Tags: rune_in=[4.0, 6.0]. RouteV emittiert auf pat_0 wenn
    Random=4 kommt, auf pat_1 wenn Random=6 kommt — so können
    verschiedene Random-Werte verschiedene Synth-Pfade triggern.
    """
    from pydaw.flux.module_library import make_module
    from pydaw.flux.living_patterns import promote_tag
    toggle = make_module('Frigg', 'Toggle'); toggle.position = (-200, 0)
    metro  = make_module('Norns', 'Metro');  metro.position  = ( -50, 0)
    rnd    = make_module('Ullr', 'Random');  rnd.position    = ( 130, 0)
    routev = make_module('Vör', 'RouteV');   routev.position = ( 320, 0)
    plus60 = make_module('Ullr', 'Plus');    plus60.position = ( 520, -80)
    plus72 = make_module('Ullr', 'Plus');    plus72.position = ( 520,  80)
    mtof_a = make_module('Ratatosk', 'Mtof'); mtof_a.position = (700, -80)
    mtof_b = make_module('Ratatosk', 'Mtof'); mtof_b.position = (700,  80)
    sine_a = make_module('Bragi', 'SineOsc'); sine_a.position = (880, -80)
    sine_b = make_module('Bragi', 'SineOsc'); sine_b.position = (880,  80)
    master = make_module('Heimdall', 'MasterOut'); master.position = (1080, 0)
    if any(m is None for m in (toggle, metro, rnd, routev, plus60, plus72,
                               mtof_a, mtof_b, sine_a, sine_b, master)):
        return False

    _set(toggle, value=1.0)
    _set(metro,  rate_hz=4.0)
    _set(rnd,    max_value=8.0)
    _set(plus60, b=60.0)
    _set(plus72, b=72.0)
    _set(sine_a, gain=0.3)
    _set(sine_b, gain=0.3)

    # RouteV: pre-promote 4.0 und 6.0
    promote_tag(routev, 4.0)
    promote_tag(routev, 6.0)

    for m in (toggle, metro, rnd, routev, plus60, plus72,
              mtof_a, mtof_b, sine_a, sine_b, master):
        p.add_module(m)

    _connect(p, toggle.id, 'out', metro.id, 'rate_hz')
    _connect(p, metro.id, 'rune_out', rnd.id, 'trigger')
    _connect(p, rnd.id, 'rune_out', routev.id, 'rune_in')
    _connect(p, routev.id, 'pat_0', plus60.id, 'rune_in')
    _connect(p, routev.id, 'pat_1', plus72.id, 'rune_in')
    _connect(p, plus60.id, 'rune_out', mtof_a.id, 'rune_in')
    _connect(p, plus72.id, 'rune_out', mtof_b.id, 'rune_in')
    _connect(p, mtof_a.id, 'rune_out', sine_a.id, 'freq')
    _connect(p, mtof_b.id, 'rune_out', sine_b.id, 'freq')
    _connect(p, sine_a.id, 'audio_out', master.id, 'audio_in_l')
    _connect(p, sine_b.id, 'audio_out', master.id, 'audio_in_r')
    return True


# ─── Preset 2: LFO-Probes-Random-Synth (Anno's Screenshot fixed) ──


def _build_v232_showcase(p) -> bool:
    """v0.0.21.232 Module-Showcase: Swarm + WavetableOsc → SubOsc-Bass +
    Vidar.Gain + PeakLimiter mit Sidechain auf Lowpass-Cutoff.

    Demonstriert ALLE neuen v.232-Module außer Sampler (der braucht
    eine externe File und ist daher kein „aus-der-Box-Preset"):

        Toggle → Metro(2Hz) → Random(8) → Plus(60) → Mtof
                                                     ├─→ SwarmOsc.freq
                                                     │     ↓
                                                     │   Vidar.Gain(0.4)
                                                     │     ↓
                                                     │   Forseti.Lowpass
                                                     │     ↑ cutoff
                                                     │  ┌──┘
                                                     │  Vidar.PeakLimiter.gr_out (sidechain duck)
                                                     │     ↑ audio_in
                                                     │  Vidar.Gain
                                                     │     ↓ audio_out → MasterOut
                                                     ↓
                                                  SubOsc.freq → SubOsc.audio_out → MasterOut
        LFO Sine (slow) → WavetableOsc.position    (morpht Wavetables im Takt)
    """
    from pydaw.flux.module_library import make_module
    toggle  = make_module('Frigg', 'Toggle');     toggle.position  = (-200, -50)
    metro   = make_module('Norns', 'Metro');      metro.position   = ( -50, -50)
    rnd     = make_module('Ullr', 'Random');      rnd.position     = ( 130, -50)
    plus60  = make_module('Ullr', 'Plus');        plus60.position  = ( 280, -50)
    mtof    = make_module('Ratatosk', 'Mtof');    mtof.position    = ( 430, -50)
    swarm   = make_module('Bragi', 'SwarmOsc');   swarm.position   = ( 600, -120)
    sub     = make_module('Bragi', 'SubOsc');     sub.position     = ( 600,   60)
    wt      = make_module('Bragi', 'WavetableOsc'); wt.position    = ( 600,  220)
    lfo     = make_module('Loki', 'LFOSine');     lfo.position     = ( 430,  220)
    nf      = make_module('Frigg', 'NumberFlow'); nf.position      = ( 800, -200)
    gain    = make_module('Vidar', 'Gain');       gain.position    = ( 800, -120)
    peak    = make_module('Vidar', 'PeakLimiter');peak.position    = ( 980, -120)
    lp      = make_module('Forseti', 'Lowpass');  lp.position      = (1160, -120)
    master  = make_module('Heimdall', 'MasterOut'); master.position = (1340, 0)

    mods = [toggle, metro, rnd, plus60, mtof, swarm, sub, wt, lfo,
            nf, gain, peak, lp, master]
    if any(m is None for m in mods):
        return False

    _set(toggle, value=1.0)
    _set(metro,  rate_hz=2.0)
    _set(rnd,    max_value=8.0)
    _set(plus60, b=48.0)
    _set(swarm,  detune=18.0, mix=0.6, gain=0.35)
    _set(sub,    octaves=1.0, gain=0.4)
    _set(wt,     position=0.0, gain=0.3)
    _set(lfo,    rate=0.3, depth=0.5)         # langsam, durchschwingend
    _set(gain,   gain=0.7)                    # globaler Pegel
    _set(peak,   threshold=-6.0, release_ms=80.0)
    _set(lp,     cutoff=1200.0, resonance=0.5)
    _set(nf,     decimals=1.0)

    for m in mods:
        p.add_module(m)

    # Pitch chain
    _connect(p, toggle.id, 'out', metro.id, 'rate_hz')
    _connect(p, metro.id, 'rune_out', rnd.id, 'trigger')
    _connect(p, rnd.id, 'rune_out', plus60.id, 'rune_in')
    _connect(p, plus60.id, 'rune_out', mtof.id, 'rune_in')
    _connect(p, mtof.id, 'rune_out', swarm.id, 'freq')
    _connect(p, mtof.id, 'rune_out', sub.id, 'freq')
    _connect(p, mtof.id, 'rune_out', wt.id, 'freq')
    _connect(p, mtof.id, 'rune_out', nf.id, 'cv_in')
    # LFO modulates wavetable morph
    _connect(p, lfo.id, 'cv_out', wt.id, 'position')
    # Audio mix: Swarm + Sub + WT → Gain → PeakLimiter → LP → MasterOut
    # (3 sources can't fan-into one input; route through MasterOut directly)
    _connect(p, swarm.id, 'audio_out', gain.id, 'audio_in')
    _connect(p, gain.id, 'audio_out', peak.id, 'audio_in')
    _connect(p, peak.id, 'audio_out', lp.id, 'audio_in')
    _connect(p, lp.id, 'audio_out', master.id, 'audio_in_l')
    # Sub + WT direkt zum Master rechts (parallele bus)
    _connect(p, sub.id, 'audio_out', master.id, 'audio_in_r')
    _connect(p, wt.id, 'audio_out',  master.id, 'audio_in_r')
    return True


def _build_lfo_probes(p) -> bool:
    """Anno's Screenshot-Patch korrigiert + ausgestattet mit NumberFlow-
    Probes (v.231). Demonstriert:

    * Plus(60) zwischen Random und Mtof → MIDI 60..63 (C4..D♯4)
      hörbar statt Random→Mtof direkt (das gibt 8-10 Hz sub-audio).
    * 3× Frigg.NumberFlow als Live-Probes — User sieht Random-Output,
      Mtof-Hz, LFOSine-Wert während Test Play.
    * LFOSquare phase=0.25 → 90° versetzt zur LFOSine — neues v.231
      Phase-Port-Feature.

    Topologie:
        Toggle → Metro(4Hz) → Random(0..3) → [probe_random]
                                       └──→ Plus(60) → Mtof → [probe_freq] → SineOsc.freq
        LFOSine(1.5Hz) → [probe_lfo] → SineOsc.gain  (Tremolo)
        LFOSquare(2Hz, phase=0.25) → Lowpass.cutoff   (Dub-Pulse)
        SineOsc → Lowpass → MasterOut
    """
    from pydaw.flux.module_library import make_module
    toggle  = make_module('Frigg', 'Toggle');     toggle.position  = (-200, -50)
    metro   = make_module('Norns', 'Metro');      metro.position   = ( -50, -50)
    rnd     = make_module('Ullr', 'Random');      rnd.position     = ( 130, -50)
    nf_rnd  = make_module('Frigg', 'NumberFlow'); nf_rnd.position  = ( 300,-130)
    plus60  = make_module('Ullr', 'Plus');        plus60.position  = ( 300,   0)
    mtof    = make_module('Ratatosk', 'Mtof');    mtof.position    = ( 470,   0)
    nf_freq = make_module('Frigg', 'NumberFlow'); nf_freq.position = ( 640, -90)
    sine    = make_module('Bragi', 'SineOsc');    sine.position    = ( 640,  60)
    lfo_s   = make_module('Loki', 'LFOSine');     lfo_s.position   = ( 470, 200)
    nf_lfo  = make_module('Frigg', 'NumberFlow'); nf_lfo.position  = ( 640, 200)
    lfo_sq  = make_module('Loki', 'LFOSquare');   lfo_sq.position  = ( 470, 320)
    lp      = make_module('Forseti', 'Lowpass');  lp.position      = ( 820,  60)
    master  = make_module('Heimdall', 'MasterOut'); master.position = (1000, 60)

    mods = [toggle, metro, rnd, nf_rnd, plus60, mtof, nf_freq,
            sine, lfo_s, nf_lfo, lfo_sq, lp, master]
    if any(m is None for m in mods):
        return False

    _set(toggle, value=1.0)
    _set(metro,  rate_hz=4.0)
    _set(rnd,    max_value=4.0)
    _set(plus60, b=60.0)
    _set(sine,   gain=0.4)
    _set(lfo_s,  rate=1.5, depth=0.3)
    _set(lfo_sq, rate=2.0, depth=0.5, phase=0.25)
    _set(lp,     cutoff=800.0, resonance=0.6)
    _set(nf_rnd,  decimals=0.0)
    _set(nf_freq, decimals=1.0)
    _set(nf_lfo,  decimals=3.0)

    for m in mods:
        p.add_module(m)

    # Toggle gates the metro
    _connect(p, toggle.id, 'out', metro.id, 'rate_hz')
    # Metro triggers random
    _connect(p, metro.id, 'rune_out', rnd.id, 'trigger')
    # Random branches: probe AND plus60 (parallel observation)
    _connect(p, rnd.id, 'rune_out', nf_rnd.id, 'cv_in')
    _connect(p, rnd.id, 'rune_out', plus60.id, 'rune_in')
    # plus60 → mtof → probe → SineOsc freq
    _connect(p, plus60.id, 'rune_out', mtof.id, 'rune_in')
    _connect(p, mtof.id, 'rune_out', nf_freq.id, 'cv_in')
    _connect(p, nf_freq.id, 'cv_out', sine.id, 'freq')
    # LFO Sine → probe → SineOsc gain (Tremolo)
    _connect(p, lfo_s.id, 'cv_out', nf_lfo.id, 'cv_in')
    _connect(p, nf_lfo.id, 'cv_out', sine.id, 'gain')
    # LFO Square (phase-shifted) → Lowpass cutoff
    _connect(p, lfo_sq.id, 'cv_out', lp.id, 'cutoff')
    # Audio chain
    _connect(p, sine.id, 'audio_out', lp.id, 'audio_in')
    _connect(p, lp.id, 'audio_out', master.id, 'audio_in_l')
    _connect(p, lp.id, 'audio_out', master.id, 'audio_in_r')
    return True


def _build_v239_voice_grain_bell(p) -> bool:
    """v0.0.21.239 Showcase: RingMod (Bell) + Grain (Texture) + Formant (Voice).

    Demonstriert die drei neuen v.239-Oszis als parallele Klangschichten.
    Ein gemeinsamer Pitch-Chain (Toggle → Metro → Random → Plus(36) → Mtof)
    füttert Carrier-Frequenz aller drei. Jeder durch eigenen Vidar.Gain
    damit User die drei einzeln durchklicken kann.

    Plus: ein langsamer LFO sweept den FormantOsc.vowel-Param → klassisches
    „Aaaa-Eeee-Iiii"-Vocal-Wow.

    Topologie:

        Toggle → Metro(1.5Hz) → Random(8) → Plus(36) → Mtof
                                                         │
                                              ┌──────────┼──────────┐
                                              │          │          │
                                            freq       freq       freq
                                              │          │          │
                                          RingModOsc  GrainOsc  FormantOsc
                                              │          │          │
                                              ↓          ↓          ↓
                                            Vidar.    Vidar.     Vidar.
                                            Gain      Gain       Gain
                                              │          │          │
                                              └──────────┼──────────┘
                                                         │
                                                  Vidar.PeakLimiter
                                                         │
                                                    MasterOut

        LFOSine (0.15Hz) → FormantOsc.vowel  (Aaaa→Eeee→Iiii sweep)

    Default-State: Nur FormantOsc on (gain=1.0), die anderen stumm. User
    dreht andere auf um Bell-Sound (RingMod) und Granular-Texture (Grain)
    zu hören.
    """
    from pydaw.flux.module_library import make_module
    toggle  = make_module('Frigg', 'Toggle');       toggle.position = (-200, -100)
    metro   = make_module('Norns', 'Metro');        metro.position  = (-50,  -100)
    rnd     = make_module('Ullr', 'Random');        rnd.position    = (130,  -100)
    plus36  = make_module('Ullr', 'Plus');          plus36.position = (300,  -100)
    mtof    = make_module('Ratatosk', 'Mtof');      mtof.position   = (470,  -100)
    rm      = make_module('Bragi', 'RingModOsc');   rm.position     = (650,  -200)
    grain   = make_module('Bragi', 'GrainOsc');     grain.position  = (650,   -50)
    fmt     = make_module('Bragi', 'FormantOsc');   fmt.position    = (650,  100)
    g_rm    = make_module('Vidar', 'Gain');         g_rm.position   = (830, -200)
    g_grain = make_module('Vidar', 'Gain');         g_grain.position = (830, -50)
    g_fmt   = make_module('Vidar', 'Gain');         g_fmt.position  = (830, 100)
    lfo     = make_module('Loki', 'LFOSine');       lfo.position    = (470,  220)
    peak    = make_module('Vidar', 'PeakLimiter');  peak.position   = (1010,  0)
    master  = make_module('Heimdall', 'MasterOut'); master.position = (1190,  0)

    mods = [toggle, metro, rnd, plus36, mtof, rm, grain, fmt,
            g_rm, g_grain, g_fmt, lfo, peak, master]
    if any(m is None for m in mods):
        return False

    _set(toggle, value=1.0)
    _set(metro,  rate_hz=1.5)
    _set(rnd,    max_value=8.0)
    _set(plus36, b=36.0)        # MIDI 36..43 → C2..G2 (Bass-Range)
    # Oszi-Defaults
    _set(rm,    gain=0.45, mod_freq=440.0, mix=1.0)  # bell-style ratio 1:2
    _set(grain, gain=0.45, grain_size=40.0, density=60.0, pitch_spread=0.3)
    _set(fmt,   gain=0.5, vowel=0.0, formant_shift=1.0, resonance=6.0)
    # Per-osc gains: nur Formant on
    _set(g_rm,    gain=0.0)   # off
    _set(g_grain, gain=0.0)   # off
    _set(g_fmt,   gain=1.0)   # on
    _set(lfo,     rate=0.15, depth=0.5)  # 0..1 → vowel range
    _set(peak,    threshold=-3.0, release_ms=120.0)

    for m in mods:
        p.add_module(m)

    # Pitch-Chain
    _connect(p, toggle.id, 'out', metro.id, 'rate_hz')
    _connect(p, metro.id, 'rune_out', rnd.id, 'trigger')
    _connect(p, rnd.id, 'rune_out', plus36.id, 'rune_in')
    _connect(p, plus36.id, 'rune_out', mtof.id, 'rune_in')
    # Mtof feeds all 3
    _connect(p, mtof.id, 'rune_out', rm.id, 'freq')
    _connect(p, mtof.id, 'rune_out', grain.id, 'freq')
    _connect(p, mtof.id, 'rune_out', fmt.id, 'freq')
    # LFO sweept Formant.vowel
    _connect(p, lfo.id, 'cv_out', fmt.id, 'vowel')
    # Audio durch per-osc gains
    _connect(p, rm.id, 'audio_out', g_rm.id, 'audio_in')
    _connect(p, grain.id, 'audio_out', g_grain.id, 'audio_in')
    _connect(p, fmt.id, 'audio_out', g_fmt.id, 'audio_in')
    # Sum into PeakLimiter
    _connect(p, g_rm.id,    'audio_out', peak.id, 'audio_in')
    _connect(p, g_grain.id, 'audio_out', peak.id, 'audio_in')
    _connect(p, g_fmt.id,   'audio_out', peak.id, 'audio_in')
    # PeakLimiter → MasterOut (stereo)
    _connect(p, peak.id, 'audio_out', master.id, 'audio_in_l')
    _connect(p, peak.id, 'audio_out', master.id, 'audio_in_r')
    return True


def _build_v240_robot_voice_vocoder(p) -> bool:
    """v0.0.21.240 Showcase: Hel.Vocoder als Robot-Voice-Effekt.

    Klassischer Vocoder-Patch:
      * Carrier: Bragi.SwarmOsc (7-Voice-Supersaw, harmonienreich)
      * Modulator: Bragi.PulseOsc + Freyr.ADSR (rhythmisch gepulst)
      * Trigger via Tyr.PulseGate (4 Hz tempo-pulse)

    Anno's Use-Case: ohne externe Sprach-Datei (Sampler braucht file_path)
    nutzen wir einen rhythmisch modulierten PulseOsc als Modulator-Quelle.
    Das treibt den Vocoder-Envelope in regelmäßigen Abständen → klassischer
    Robot-Voice-/Daft-Punk-Pad-Sound.

    Topologie:

        Toggle → Tyr.PulseGate(4Hz) → Freyr.ADSR.gate
                                      ↓
                         Bragi.PulseOsc.gain (rhythmisch on/off)
                                      ↓
                                 → Hel.Vocoder.mod_in
                                      ↑
        Toggle → Norns.Metro(2Hz) → Random → Plus(48) → Mtof
                                                          ↓
                                                  Bragi.SwarmOsc
                                                          ↓
                                                  Hel.Vocoder.audio_in
                                                          ↓
                                                  Vidar.PeakLimiter
                                                          ↓
                                                       MasterOut

        LFOSine(0.1Hz, depth=0.3) → Vocoder.formant_shift   (subtile cartoon-modulation)

    Default: dry_wet=1.0 (full vocoder), formant_shift=1.0 (neutral).
    User kann formant_shift=1.5 zum Höher-stimmen oder 0.7 zum Tiefer-
    stimmen drehen.
    """
    from pydaw.flux.module_library import make_module
    toggle  = make_module('Frigg', 'Toggle');       toggle.position = (-200, -100)
    metro   = make_module('Norns', 'Metro');        metro.position  = (-50,  -100)
    rnd     = make_module('Ullr', 'Random');        rnd.position    = (130,  -100)
    plus48  = make_module('Ullr', 'Plus');          plus48.position = (300,  -100)
    mtof    = make_module('Ratatosk', 'Mtof');      mtof.position   = (470,  -100)
    swarm   = make_module('Bragi', 'SwarmOsc');     swarm.position  = (650,  -100)
    pulse_g = make_module('Tyr', 'PulseGate');      pulse_g.position = (-50,   100)
    pulse   = make_module('Bragi', 'PulseOsc');     pulse.position  = (130,   100)
    adsr    = make_module('Freyr', 'ADSR');         adsr.position   = (310,   100)
    gain_m  = make_module('Vidar', 'Gain');         gain_m.position = (470,   100)
    voc     = make_module('Hel', 'Vocoder');        voc.position    = (830,   0)
    lfo     = make_module('Loki', 'LFOSine');       lfo.position    = (650,   220)
    peak    = make_module('Vidar', 'PeakLimiter');  peak.position   = (1010,  0)
    master  = make_module('Heimdall', 'MasterOut'); master.position = (1190,  0)

    mods = [toggle, metro, rnd, plus48, mtof, swarm,
            pulse_g, pulse, adsr, gain_m, voc, lfo, peak, master]
    if any(m is None for m in mods):
        return False

    _set(toggle, value=1.0)
    _set(metro,  rate_hz=2.0)
    _set(rnd,    max_value=8.0)
    _set(plus48, b=48.0)              # MIDI 48..55 → C3..G3
    _set(swarm,  detune=18.0, mix=0.6, gain=0.4)
    _set(pulse_g, rate=4.0, pulse_width=0.3)  # 4 Hz pulses
    _set(pulse,  freq=120.0, gain=0.5, pulse_width=0.3)
    _set(adsr,   attack=0.005, decay=0.05, sustain=0.6, release=0.1)
    _set(gain_m, gain=0.8)
    _set(voc,    formant_shift=1.0, dry_wet=1.0,
                 attack_ms=5.0, release_ms=80.0)
    _set(lfo,    rate=0.1, depth=0.3)  # ±0.3 → modulates formant_shift around 1.0
    _set(peak,   threshold=-3.0, release_ms=120.0)

    for m in mods:
        p.add_module(m)

    # Pitch-Chain für Carrier
    _connect(p, toggle.id, 'out', metro.id, 'rate_hz')
    _connect(p, metro.id, 'rune_out', rnd.id, 'trigger')
    _connect(p, rnd.id, 'rune_out', plus48.id, 'rune_in')
    _connect(p, plus48.id, 'rune_out', mtof.id, 'rune_in')
    _connect(p, mtof.id, 'rune_out', swarm.id, 'freq')

    # Modulator-Chain: PulseGate → ADSR → Gain (modulates PulseOsc-Output)
    _connect(p, pulse_g.id, 'gate_out', adsr.id, 'gate')
    _connect(p, pulse.id, 'audio_out', gain_m.id, 'audio_in')
    _connect(p, adsr.id, 'cv_out',  gain_m.id, 'gain')

    # Vocoder I/O
    _connect(p, swarm.id, 'audio_out', voc.id, 'audio_in')
    _connect(p, gain_m.id, 'audio_out', voc.id, 'mod_in')
    _connect(p, lfo.id,   'cv_out',     voc.id, 'formant_shift')

    # Output
    _connect(p, voc.id,  'audio_out', peak.id, 'audio_in')
    _connect(p, peak.id, 'audio_out', master.id, 'audio_in_l')
    _connect(p, peak.id, 'audio_out', master.id, 'audio_in_r')
    return True


# ─── Build All ────────────────────────────────────────────────────


def _build_v238_bitwig_trio(p) -> bool:
    """v0.0.21.238 Bitwig-Trio-Showcase: HardSync + FM + Drift parallel.

    Demo der drei neuen Bitwig-Style Oszillatoren (v.238) im direkten
    A/B/C-Vergleich. Ein gemeinsamer Pitch-Chain (Toggle → Metro →
    Random → Plus(48) → Mtof) füttert alle drei Oszis. Jeder geht
    durch ein eigenes Vidar.Gain damit man sie mischen oder einzeln
    austesten kann (alle stumm außer einer).

    Plus: ein langsamer LFO moduliert HardSync.slave_ratio für den
    klassischen „Sync-Sweep"-Lead-Sound.

    Topologie:

        Toggle → Metro(2Hz) → Random(8) → Plus(48) → Mtof
                                                       │
                                            ┌──────────┼──────────┐
                                            │          │          │
                                          freq       freq       freq
                                            │          │          │
                                       HardSyncOsc  FMOsc     DriftOsc
                                            │          │          │
                                          gain       gain       gain
                                            │          │          │
                                          Vidar.    Vidar.     Vidar.
                                          Gain      Gain       Gain
                                            │          │          │
                                            └──────────┼──────────┘
                                                       │
                                                Vidar.PeakLimiter
                                                       │
                                                  MasterOut.in_l

        LFO Sine (slow 0.2Hz) → HardSyncOsc.slave_ratio (sweep!)

    Anno-Direktive: Living Patterns Histogramm (v.238) zeigt sich
    automatisch wenn ein RouteV-Modul in der Patch ist — hier nicht
    nötig, weil der Showcase die Oszis selbst zeigen will.
    """
    from pydaw.flux.module_library import make_module
    toggle  = make_module('Frigg', 'Toggle');       toggle.position = (-200, -100)
    metro   = make_module('Norns', 'Metro');        metro.position  = (-50,  -100)
    rnd     = make_module('Ullr', 'Random');        rnd.position    = (130,  -100)
    plus48  = make_module('Ullr', 'Plus');          plus48.position = (300,  -100)
    mtof    = make_module('Ratatosk', 'Mtof');      mtof.position   = (470,  -100)
    # 3 parallel oscillators
    hs      = make_module('Bragi', 'HardSyncOsc');  hs.position     = (650,  -200)
    fm      = make_module('Bragi', 'FMOsc');        fm.position     = (650,   -50)
    drift   = make_module('Bragi', 'DriftOsc');     drift.position  = (650,  100)
    # Per-oscillator gain (so user can mute/balance each)
    g_hs    = make_module('Vidar', 'Gain');         g_hs.position    = (830, -200)
    g_fm    = make_module('Vidar', 'Gain');         g_fm.position    = (830,  -50)
    g_drift = make_module('Vidar', 'Gain');         g_drift.position = (830, 100)
    # Sync-sweep modulator
    lfo     = make_module('Loki', 'LFOSine');       lfo.position    = (470,  -250)
    # Output chain: PeakLimiter → MasterOut
    peak    = make_module('Vidar', 'PeakLimiter');  peak.position   = (1010,  0)
    master  = make_module('Heimdall', 'MasterOut'); master.position = (1190,  0)

    mods = [toggle, metro, rnd, plus48, mtof, hs, fm, drift,
            g_hs, g_fm, g_drift, lfo, peak, master]
    if any(m is None for m in mods):
        return False

    _set(toggle, value=1.0)
    _set(metro,  rate_hz=2.0)
    _set(rnd,    max_value=8.0)
    _set(plus48, b=48.0)
    # Oszi-Defaults so dass alle drei mit gain ~0.4 gleich laut sind
    _set(hs,     gain=0.45, slave_ratio=2.5, slave_drift=0.0)
    _set(fm,     gain=0.45, mod_ratio=1.0, mod_index=2.5, feedback=0.2)
    _set(drift,  gain=0.45, drift_amount=0.2, drift_rate=0.5, warmth=0.4)
    # Per-oscillator gains: nur Drift hörbar by default (User kann andere aufdrehen)
    _set(g_hs,    gain=0.0)   # off
    _set(g_fm,    gain=0.0)   # off
    _set(g_drift, gain=1.0)   # on
    _set(lfo,     rate=0.2, depth=2.0)  # ±2 → moduliert ratio um 1.0..5.0
    _set(peak,    threshold=-3.0, release_ms=120.0)

    for m in mods:
        p.add_module(m)

    # Pitch-Chain
    _connect(p, toggle.id, 'out', metro.id, 'rate_hz')
    _connect(p, metro.id, 'rune_out', rnd.id, 'trigger')
    _connect(p, rnd.id, 'rune_out', plus48.id, 'rune_in')
    _connect(p, plus48.id, 'rune_out', mtof.id, 'rune_in')
    # Mtof feeds all three oscillators
    _connect(p, mtof.id, 'rune_out', hs.id, 'freq')
    _connect(p, mtof.id, 'rune_out', fm.id, 'freq')
    _connect(p, mtof.id, 'rune_out', drift.id, 'freq')
    # LFO sweep on HardSync slave_ratio (wenn User g_hs auf 1 setzt: hörbar)
    # LFO output ±depth → Center 3.0, ±2.0 = 1.0..5.0 (slave_ratio range)
    # Wir routen LFO auf slave_ratio direkt — bei aktuellen LFO-Defaults
    # bekommt slave_ratio Werte um 0; Knob in HardSyncOsc default ist 2.5,
    # das wird zur Mod hinzugefügt. Da wir aber via CV-Connect arbeiten,
    # OVERRIDE-t LFO den Knob → slave_ratio = LFO-Wert. Mit LFO depth=2
    # ergibt das ±2 → wir clampen auf [1, 8] in der DSP, sodass
    # negative Werte als 1 gerendert werden. Das ist akzeptable.
    _connect(p, lfo.id, 'cv_out', hs.id, 'slave_ratio')
    # Audio durch per-osc gains
    _connect(p, hs.id, 'audio_out', g_hs.id, 'audio_in')
    _connect(p, fm.id, 'audio_out', g_fm.id, 'audio_in')
    _connect(p, drift.id, 'audio_out', g_drift.id, 'audio_in')
    # Sum into PeakLimiter (alle 3 Gain-Outputs gehen parallel rein)
    _connect(p, g_hs.id,    'audio_out', peak.id, 'audio_in')
    _connect(p, g_fm.id,    'audio_out', peak.id, 'audio_in')
    _connect(p, g_drift.id, 'audio_out', peak.id, 'audio_in')
    # PeakLimiter → MasterOut (stereo bus)
    _connect(p, peak.id, 'audio_out', master.id, 'audio_in_l')
    _connect(p, peak.id, 'audio_out', master.id, 'audio_in_r')
    return True


def _build_all() -> list[dict]:
    builders = [
        ("Living-Patterns-Demo",
         "Vör.RouteV mit pre-promoted 4.0 und 6.0 — Random-Wert routet "
         "auf 2 SineOsc-Pfade (C4 oder C5 transponiert).",
         ["living-patterns", "routev", "random", "demo"], "C4",
         _build_living_patterns_demo),
        ("LFO-Probes-Random-Synth",
         "Anno's Screenshot-Patch korrigiert: Plus(60) macht Random→"
         "Mtof hörbar; 3× NumberFlow zeigen Live-Werte; LFOSquare "
         "phase=0.25 versetzt → Demo des v.231 Phase-Port-Features.",
         ["v231", "numberflow", "lfo", "probe", "tremolo", "dub"], "C4",
         _build_lfo_probes),
        ("v232-Showcase-Swarm-Sub-Wavetable",
         "Demo aller v.232 Module: Bragi.SwarmOsc + SubOsc + WavetableOsc"
         " (LFO-morphing) durch Vidar.Gain → Vidar.PeakLimiter →"
         " Forseti.Lowpass. Random-Sequence steuert die Pitches.",
         ["v232", "swarm", "sub", "wavetable", "gain", "peaklimiter",
          "showcase"], "C3",
         _build_v232_showcase),
        ("v238-Bitwig-Trio-HardSync-FM-Drift",
         "Demo aller v.238 Bitwig-Style-Oszis: HardSyncOsc (Sync-Sweep "
         "via LFO auf slave_ratio), FMOsc (2-Op + Feedback), DriftOsc "
         "(Vintage-Analog-Wobble). Per-Oszi-Gain — nur Drift on by "
         "default; User dreht HS und FM auf um sie zu hören. Random-"
         "Sequence steuert alle drei Pitches gleichzeitig.",
         ["v238", "hardsync", "fm", "drift", "bitwig", "showcase"], "C3",
         _build_v238_bitwig_trio),
        ("v239-Voice-Grain-Bell",
         "Demo aller v.239 Bitwig-Style-Oszis: RingModOsc (bell-style "
         "ratio 1:2), GrainOsc (granulare Texture mit pitch_spread), "
         "FormantOsc (Vocal-Synth mit LFO-vowel-sweep Aaaa→Eeee→Iiii). "
         "Per-Oszi-Gain — nur Formant on by default; User dreht andere "
         "auf um Bell + Grain zu hören.",
         ["v239", "ringmod", "grain", "formant", "vocal", "bitwig",
          "showcase"], "C2",
         _build_v239_voice_grain_bell),
        ("v240-Robot-Voice-Vocoder",
         "Demo Hel.Vocoder als klassischer Robot-Voice-Effekt. Bragi."
         "SwarmOsc (7-Voice-Supersaw) als Carrier; rhythmisch gepulster "
         "Bragi.PulseOsc + Freyr.ADSR (4Hz via Tyr.PulseGate) als "
         "Modulator. LFOSine moduliert Vocoder.formant_shift für subtile "
         "cartoon-Stimm-Modulation. Drehe formant_shift auf 1.5 für "
         "Mickey-Mouse, 0.7 für Tief-Stimme.",
         ["v240", "vocoder", "robot", "voice", "hel", "showcase"], "C3",
         _build_v240_robot_voice_vocoder),
    ]
    presets = []
    for name, desc, tags, key, builder in builders:
        patch_dict = _build_patch_dict(name, builder)
        if patch_dict is None:
            logger.warning("[LivingPresets-v1] %s skipped (build failed)", name)
            continue
        presets.append({
            "name": name,
            "description": desc,
            "tags": tags,
            "musical_key": key,
            "bpm": None,
            "author": LIVING_FACTORY_AUTHOR,
            "icon_svg": "",
            "patch": patch_dict,
        })
    return presets


class _LazyPresetList:
    def __init__(self):
        self._cache: Optional[list[dict]] = None

    def _ensure(self) -> list[dict]:
        if self._cache is None:
            self._cache = _build_all()
            logger.info(
                "[LivingPresets-v1] built %d Living presets (%s) lazily",
                len(self._cache), LIVING_FACTORY_VERSION,
            )
        return self._cache

    def __iter__(self):
        return iter(self._ensure())

    def __len__(self):
        return len(self._ensure())

    def __getitem__(self, i):
        return self._ensure()[i]


LIVING_PRESETS = _LazyPresetList()


__all__ = [
    "LIVING_PRESETS",
    "LIVING_FACTORY_VERSION",
    "LIVING_FACTORY_AUTHOR",
]
