"""First-Run-Experience Dialog — P0D

Erscheint einmalig beim allerersten Start von Py_DAW.
Ziel: Neuer Nutzer → Instrument → Note → Ton in unter 30 Sekunden.

v0.0.20.747 — Anno / Claude Sonnet 4.6
"""
from __future__ import annotations

from typing import Optional

from PyQt6.QtCore import Qt, QSettings
from PyQt6.QtGui import QFont, QPixmap, QColor, QPainter
from PyQt6.QtWidgets import (
    QDialog,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QWidget,
    QWizard,
    QWizardPage,
    QSizePolicy,
    QCheckBox,
    QGroupBox,
    QRadioButton,
    QScrollArea,
    QFrame,
)

_SETTINGS_KEY = "first_run_done"
_SETTINGS_ORG = "Py_DAW"
_SETTINGS_APP = "ChronoScaleStudio"


def should_show_first_run() -> bool:
    """True wenn Py_DAW noch nie gestartet wurde."""
    s = QSettings(_SETTINGS_ORG, _SETTINGS_APP)
    return not s.value(_SETTINGS_KEY, False, type=bool)


def mark_first_run_done() -> None:
    s = QSettings(_SETTINGS_ORG, _SETTINGS_APP)
    s.setValue(_SETTINGS_KEY, True)


# ─── Seiten ──────────────────────────────────────────────────────────────────

class _WelcomePage(QWizardPage):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle("Willkommen bei Py_DAW")
        self.setSubTitle("Die Open-Source-DAW — Python-nativ, Rust-schnell, KI-unterstützt.")

        lay = QVBoxLayout(self)
        lay.setSpacing(12)

        # Logo-Placeholder + Titel
        header = QHBoxLayout()
        icon_lbl = QLabel()
        icon_lbl.setFixedSize(64, 64)
        icon_lbl.setStyleSheet(
            "background: qlineargradient(x1:0,y1:0,x2:1,y2:1,"
            "stop:0 #1a237e, stop:1 #4fc3f7);"
            "border-radius: 12px; color: white; font-size: 28px;"
        )
        icon_lbl.setText("🎵")
        icon_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        header.addWidget(icon_lbl)

        title_col = QVBoxLayout()
        t1 = QLabel("Py_DAW — ChronoScaleStudio")
        t1.setFont(QFont("Sans", 16, QFont.Weight.Bold))
        t2 = QLabel("Digital Audio Workstation · Open Source · Linux-first")
        t2.setStyleSheet("color: #aaa;")
        title_col.addWidget(t1)
        title_col.addWidget(t2)
        title_col.addStretch()
        header.addLayout(title_col, 1)
        lay.addLayout(header)

        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        sep.setStyleSheet("color: #444;")
        lay.addWidget(sep)

        # Feature-Highlights
        features = QGroupBox("Was dich erwartet")
        f_lay = QVBoxLayout(features)
        for feat in [
            "🎹  Piano Roll · Notation Editor · Arranger",
            "🥁  Drum Machine · Advanced Sampler · AETERNA Synth",
            "🎚️  Built-in FX: EQ, Compressor, Reverb, Delay …",
            "🔌  VST3 · CLAP · LV2 Plugin-Hosting",
            "🦀  Rust Audio-Engine für maximale Performance",
            "🤖  KI-Kompositions-Assistent (Claude API)",
        ]:
            lbl = QLabel(feat)
            lbl.setStyleSheet("padding: 2px 0;")
            f_lay.addWidget(lbl)
        lay.addWidget(features)

        lay.addStretch()
        info = QLabel("Klicke <b>Weiter</b> für die 30-Sekunden-Schnellstart-Tour →")
        info.setAlignment(Qt.AlignmentFlag.AlignCenter)
        info.setStyleSheet("color: #4fc3f7;")
        lay.addWidget(info)


class _QuickstartPage(QWizardPage):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle("Schnellstart: Erster Ton in 30 Sekunden")
        self.setSubTitle("Folge diesen 4 Schritten:")

        lay = QVBoxLayout(self)
        lay.setSpacing(8)

        steps = [
            ("1️⃣", "Projekt anlegen",
             "Datei → Neues Projekt  oder  Ctrl+N"),
            ("2️⃣", "Instrument-Track erstellen",
             "Rechtsklick in der Track-Liste → 'Instrument-Track hinzufügen'"),
            ("3️⃣", "Instrument laden",
             "Im Browser rechts: Reiter 'Instrumente' → AETERNA doppelklicken"),
            ("4️⃣", "Note spielen",
             "Piano Roll (Ctrl+P) öffnen → mit Maus eine Note zeichnen → Play ▶"),
        ]

        for icon, title, desc in steps:
            row = QHBoxLayout()
            ico = QLabel(icon)
            ico.setFont(QFont("Sans", 20))
            ico.setFixedWidth(40)
            row.addWidget(ico)
            col = QVBoxLayout()
            t = QLabel(f"<b>{title}</b>")
            d = QLabel(desc)
            d.setStyleSheet("color: #aaa; font-size: 11px;")
            col.addWidget(t)
            col.addWidget(d)
            row.addLayout(col, 1)

            box = QWidget()
            box.setLayout(row)
            box.setStyleSheet(
                "QWidget { background: #1e1e2e; border-radius: 6px; padding: 6px; }"
            )
            lay.addWidget(box)

        lay.addStretch()

        tip = QLabel(
            "💡 <b>Tipp:</b> Die Leertaste startet/stoppt die Wiedergabe überall in der DAW."
        )
        tip.setWordWrap(True)
        tip.setStyleSheet(
            "background: #1a3a1a; border-radius: 4px; padding: 6px; color: #8bc34a;"
        )
        lay.addWidget(tip)


class _AudioSetupPage(QWizardPage):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle("Audio-Setup")
        self.setSubTitle("Py_DAW verwendet PipeWire / JACK für Low-Latency Audio.")

        lay = QVBoxLayout(self)
        lay.setSpacing(10)

        status_box = QGroupBox("System-Status")
        s_lay = QVBoxLayout(status_box)

        checks = [
            ("PipeWire", "pipewire --version 2>/dev/null | head -1"),
            ("JACK Bridge", "which pw-jack 2>/dev/null"),
            ("ALSA", "aplay -l 2>/dev/null | head -2"),
        ]

        import subprocess
        for name, cmd in checks:
            try:
                r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=2)
                ok = bool(r.stdout.strip())
            except Exception:
                ok = False
            row = QHBoxLayout()
            icon = QLabel("✅" if ok else "⚠️")
            icon.setFixedWidth(24)
            row.addWidget(icon)
            lbl = QLabel(f"{name}: {'gefunden' if ok else 'nicht gefunden'}")
            if not ok:
                lbl.setStyleSheet("color: #ff9800;")
            row.addWidget(lbl, 1)
            s_lay.addLayout(row)

        lay.addWidget(status_box)

        hint = QLabel(
            "Py_DAW startet automatisch mit dem verfügbaren Audio-Backend.\n"
            "Einstellungen: Audio → Audio-Einstellungen (Buffer-Größe, Sample-Rate)"
        )
        hint.setWordWrap(True)
        hint.setStyleSheet("color: #aaa; font-size: 11px;")
        lay.addWidget(hint)

        rust_box = QGroupBox("Rust Audio-Engine")
        r_lay = QVBoxLayout(rust_box)

        import os
        import pathlib
        # v0.0.21.167: Workspace-Layout zuerst (seit v.165), dann Per-Crate-Fallback
        _root = pathlib.Path(__file__).parent.parent.parent
        engine_path = None
        for _candidate in (
            _root / "target" / "release" / "pydaw_engine",
            _root / "pydaw_engine" / "target" / "release" / "pydaw_engine",
        ):
            if _candidate.exists():
                engine_path = _candidate
                break
        engine_ok = engine_path is not None
        r_lay.addWidget(QLabel(
            f"{'✅ Rust-Engine kompiliert' if engine_ok else '⚠️ Rust-Engine nicht gefunden (cargo build --release ausführen)'}"
        ))
        r_lay.addWidget(QLabel(
            "Starte mit: USE_RUST_ENGINE=1 python3 main.py"
        ))
        lay.addWidget(rust_box)
        lay.addStretch()


class _KiSetupPage(QWizardPage):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle("KI-Assistent (optional)")
        self.setSubTitle("Claude API für KI-gestützte Komposition — optional, kostenlos testbar.")

        lay = QVBoxLayout(self)
        lay.setSpacing(10)

        desc = QLabel(
            "Der KI-Kompositions-Assistent kann MIDI-Pattern aus natürlicher Sprache generieren.\n\n"
            "<b>Beispiele:</b>"
        )
        desc.setWordWrap(True)
        lay.addWidget(desc)

        examples_box = QGroupBox()
        e_lay = QVBoxLayout(examples_box)
        for ex in [
            "\"Schreibe einen 8-Takt-Drum-Groove im 80er Synthpop-Stil\"",
            "\"Erstelle eine Akkordfolge wie in Radiohead-Songs\"",
            "\"Erkläre das aktuelle MIDI-Pattern\"",
        ]:
            l = QLabel(f"  → {ex}")
            l.setStyleSheet("color: #4fc3f7; font-size: 11px;")
            e_lay.addWidget(l)
        lay.addWidget(examples_box)

        key_box = QGroupBox("API-Key (optional)")
        k_lay = QVBoxLayout(key_box)
        k_lay.addWidget(QLabel(
            "1. Kostenlos registrieren: <a href='https://console.anthropic.com'>console.anthropic.com</a>"
        ))
        k_lay.addWidget(QLabel(
            "2. API-Key erstellen"
        ))
        k_lay.addWidget(QLabel(
            "3. In Py_DAW: Projekt → 🤖 KI-Assistent → Key eingeben"
        ))
        lay.addWidget(key_box)

        self._skip_ki = QCheckBox("KI-Assistent überspringen (jederzeit später aktivierbar)")
        self._skip_ki.setChecked(False)
        lay.addWidget(self._skip_ki)
        lay.addStretch()


class _DonePage(QWizardPage):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle("Bereit!")
        self.setSubTitle("Py_DAW ist einsatzbereit. Viel Spaß beim Musik-Machen!")

        lay = QVBoxLayout(self)
        lay.setSpacing(14)

        big = QLabel("🎉")
        big.setFont(QFont("Sans", 48))
        big.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(big)

        msg = QLabel(
            "<h3>Willkommen an Bord!</h3>"
            "<p>Py_DAW ist jetzt konfiguriert und einsatzbereit.</p>"
            "<p><b>Nächste Schritte:</b></p>"
            "<ul>"
            "<li>Ctrl+N → Neues Projekt anlegen</li>"
            "<li>Ctrl+P → Piano Roll öffnen</li>"
            "<li>B → Browser öffnen (Instrumente, Samples …)</li>"
            "<li>Ctrl+Alt+K → KI-Assistent öffnen</li>"
            "</ul>"
        )
        msg.setWordWrap(True)
        msg.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(msg)

        lay.addStretch()

        self._no_show = QCheckBox("Diesen Dialog beim nächsten Start nicht mehr zeigen")
        self._no_show.setChecked(True)
        lay.addWidget(self._no_show)

    def no_show_checked(self) -> bool:
        return self._no_show.isChecked()


# ─── Wizard ──────────────────────────────────────────────────────────────────

class FirstRunWizard(QWizard):
    """Einmaliger Willkommens-Wizard für Py_DAW."""

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setWindowTitle("Willkommen bei Py_DAW")
        self.setWizardStyle(QWizard.WizardStyle.ModernStyle)
        self.resize(600, 480)
        self.setMinimumSize(520, 420)

        # Dunkles Stylesheet passend zur DAW
        self.setStyleSheet("""
            QWizard { background: #1a1a2e; }
            QWizardPage { background: #1a1a2e; color: #e0e0e0; }
            QLabel { color: #e0e0e0; }
            QGroupBox { color: #aaa; border: 1px solid #444; border-radius: 6px; margin-top: 8px; padding-top: 8px; }
            QGroupBox::title { subcontrol-origin: margin; left: 8px; }
            QPushButton { background: #2a5298; color: white; border-radius: 4px; padding: 6px 14px; }
            QPushButton:hover { background: #3a63b0; }
            QCheckBox { color: #e0e0e0; }
        """)

        self._page_welcome = _WelcomePage(self)
        self._page_quickstart = _QuickstartPage(self)
        self._page_audio = _AudioSetupPage(self)
        self._page_ki = _KiSetupPage(self)
        self._page_done = _DonePage(self)

        for page in (
            self._page_welcome,
            self._page_quickstart,
            self._page_audio,
            self._page_ki,
            self._page_done,
        ):
            self.addPage(page)

    def accept(self) -> None:
        if self._page_done.no_show_checked():
            mark_first_run_done()
        super().accept()

    def reject(self) -> None:
        # "Abbrechen" = auch als erledigt markieren (kein ewiger Loop)
        mark_first_run_done()
        super().reject()


def maybe_show_first_run(parent: Optional[QWidget] = None) -> None:
    """Zeigt den First-Run-Wizard wenn nötig. Aufruf in main_window nach __init__."""
    if should_show_first_run():
        wiz = FirstRunWizard(parent)
        wiz.exec()
