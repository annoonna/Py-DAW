"""
pydaw.flux.ui_widgets.comment — Frigg.Comment Text-Label (Phase U-2)
====================================================================

PureData-Style Comment: nicht-funktionales Text-Label im Canvas.
Doppelklick → Eingabe-Dialog für neuen Text.

Eingebaut in v0.0.21.195.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


try:
    from PyQt6.QtCore import Qt, QRectF, QSize, pyqtSignal
    from PyQt6.QtGui import QColor, QPainter, QPen, QBrush, QFont, QFontMetrics
    from PyQt6.QtWidgets import QWidget, QSizePolicy, QInputDialog
    _QT_AVAILABLE = True
except ImportError:
    _QT_AVAILABLE = False


if _QT_AVAILABLE:

    class CommentWidget(QWidget):  # type: ignore[misc]
        """Text-Label im Canvas. Klick = Eingabe.

        Signale
        -------
        ``text_changed(str)`` — feuert bei Edit.
        """

        DEFAULT_HEIGHT = 24
        COL_TEXT = "#8b949e"

        text_changed = pyqtSignal(str)

        def __init__(self, text: str = "Comment …", parent=None):
            super().__init__(parent)
            self._text = str(text) if text else "Comment …"
            self._update_size()
            self.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)

        @property
        def text(self) -> str:
            return self._text

        def set_text(self, text: str, *, emit_signal: bool = True) -> None:
            t = str(text) if text else "…"
            if t == self._text:
                return
            self._text = t
            if emit_signal:
                self.text_changed.emit(self._text)
            self._update_size()
            self.update()

        def _update_size(self) -> None:
            font = QFont("monospace", 10)
            metrics = QFontMetrics(font)
            w = metrics.horizontalAdvance(self._text) + 12
            self.setMinimumSize(max(40, w), self.DEFAULT_HEIGHT)
            self.setMaximumSize(max(40, w) + 4, self.DEFAULT_HEIGHT + 2)

        def mouseDoubleClickEvent(self, event):  # type: ignore[override]
            if event.button() == Qt.MouseButton.LeftButton:
                t, ok = QInputDialog.getText(
                    self, "Comment", "Text:", text=self._text,
                )
                if ok:
                    self.set_text(t, emit_signal=True)
                event.accept()
            else:
                super().mouseDoubleClickEvent(event)

        def paintEvent(self, event):  # type: ignore[override]
            painter = QPainter(self)
            painter.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)

            painter.setPen(QPen(QColor(self.COL_TEXT)))
            painter.setFont(QFont("monospace", 10, QFont.Weight.Normal))
            painter.drawText(
                QRectF(6, 0, self.width() - 12, self.height()),
                int(Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft),
                self._text,
            )

            painter.end()

else:
    CommentWidget = None  # type: ignore[assignment,misc]


__all__ = ["CommentWidget"]
