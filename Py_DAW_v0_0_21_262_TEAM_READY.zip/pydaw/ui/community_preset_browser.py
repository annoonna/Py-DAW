"""Community Preset Browser (P6C) — Search & install presets from within the DAW.

Provides a UI widget and service for browsing community presets.
Supports local preset directories + optional HTTP preset repositories.

Features:
- Scan local preset directories (.pydaw-preset files)
- Search by name, category, instrument, tags
- Preview preset parameters before loading
- Install from preset repository (HTTP/JSON API)
- Rate / favorite presets
- User preset sharing (export to .pydaw-preset)

v0.0.20.812 — Phase P6C
"""

from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Dict, Any, Callable

from PyQt6.QtCore import QObject, pyqtSignal, Qt, QThread
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLineEdit, QListWidget,
    QListWidgetItem, QPushButton, QLabel, QComboBox, QFrame,
    QSizePolicy, QTextEdit, QMessageBox,
)

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class CommunityPreset:
    """A preset from the community repository."""
    id: str = ""
    name: str = ""
    author: str = ""
    instrument: str = ""      # "aeterna"|"fusion"|"drum_machine"|"sampler"
    category: str = ""        # "Bass"|"Lead"|"Pad"|"Keys"|"FX"|"Drums"
    tags: List[str] = field(default_factory=list)
    description: str = ""
    params: Dict[str, Any] = field(default_factory=dict)
    rating: float = 0.0       # 0..5
    downloads: int = 0
    source: str = "local"     # "local"|"repository"|"user"
    file_path: str = ""
    is_favorite: bool = False

    def to_dict(self) -> dict:
        return {
            "id": self.id, "name": self.name, "author": self.author,
            "instrument": self.instrument, "category": self.category,
            "tags": self.tags, "description": self.description,
            "params": self.params, "rating": self.rating,
            "downloads": self.downloads, "source": self.source,
        }


# ---------------------------------------------------------------------------
# Categories
# ---------------------------------------------------------------------------

CATEGORIES = [
    "All", "Bass", "Lead", "Pad", "Keys", "Pluck", "Strings",
    "Brass", "FX", "Drums", "Ambient", "Arp", "Sequence", "Other",
]

INSTRUMENTS = [
    "All", "AETERNA", "Fusion", "Drum Machine", "Sampler", "BachOrgel",
]


# ---------------------------------------------------------------------------
# Preset Repository Service
# ---------------------------------------------------------------------------

class PresetRepositoryService(QObject):
    """Manages local and remote preset collections."""

    presets_loaded = pyqtSignal(list)    # List[CommunityPreset]
    preset_installed = pyqtSignal(str)   # preset name
    error = pyqtSignal(str)

    def __init__(self, preset_dirs: Optional[List[str]] = None, parent=None):
        super().__init__(parent)
        self._preset_dirs = preset_dirs or []
        self._presets: List[CommunityPreset] = []
        self._favorites: set = set()

        # Default directories
        home = str(Path.home())
        default_dirs = [
            os.path.join(home, ".pydaw", "presets"),
            os.path.join(home, ".pydaw", "community_presets"),
        ]
        for d in default_dirs:
            if d not in self._preset_dirs:
                self._preset_dirs.append(d)

    def scan_local(self) -> List[CommunityPreset]:
        """Scan local directories for .pydaw-preset files."""
        self._presets.clear()

        for preset_dir in self._preset_dirs:
            if not os.path.isdir(preset_dir):
                continue

            for root, dirs, files in os.walk(preset_dir):
                for fname in files:
                    if not fname.endswith((".pydaw-preset", ".json", ".yaml", ".yml")):
                        continue
                    fpath = os.path.join(root, fname)
                    preset = self._load_preset_file(fpath)
                    if preset:
                        self._presets.append(preset)

        log.info("Scanned %d presets from %d directories",
                 len(self._presets), len(self._preset_dirs))

        try:
            self.presets_loaded.emit(list(self._presets))
        except Exception:
            pass
        return list(self._presets)

    def _load_preset_file(self, path: str) -> Optional[CommunityPreset]:
        """Load a single preset file."""
        try:
            text = Path(path).read_text(encoding="utf-8", errors="ignore")

            # Try JSON first
            try:
                data = json.loads(text)
            except json.JSONDecodeError:
                # Try YAML
                try:
                    import yaml  # type: ignore
                    data = yaml.safe_load(text)
                except Exception:
                    return None

            if not isinstance(data, dict):
                return None

            preset = CommunityPreset(
                id=data.get("id", os.path.basename(path)),
                name=data.get("name", Path(path).stem),
                author=data.get("author", "Unknown"),
                instrument=data.get("instrument", ""),
                category=data.get("category", "Other"),
                tags=data.get("tags", []),
                description=data.get("description", ""),
                params=data.get("params", {}),
                rating=float(data.get("rating", 0)),
                downloads=int(data.get("downloads", 0)),
                source="local",
                file_path=path,
                is_favorite=data.get("id", "") in self._favorites,
            )
            return preset

        except Exception as exc:
            log.debug("Failed to load preset %s: %s", path, exc)
            return None

    def search(
        self,
        query: str = "",
        category: str = "All",
        instrument: str = "All",
        favorites_only: bool = False,
    ) -> List[CommunityPreset]:
        """Search presets by name, category, instrument."""
        results = list(self._presets)

        if favorites_only:
            results = [p for p in results if p.is_favorite]

        if category != "All":
            results = [p for p in results if p.category.lower() == category.lower()]

        if instrument != "All":
            results = [p for p in results
                       if instrument.lower() in p.instrument.lower()]

        if query:
            q = query.lower()
            results = [p for p in results
                       if q in p.name.lower()
                       or q in p.author.lower()
                       or q in p.description.lower()
                       or any(q in t.lower() for t in p.tags)]

        # Sort by rating, then downloads
        results.sort(key=lambda p: (p.rating, p.downloads), reverse=True)
        return results

    def toggle_favorite(self, preset_id: str) -> bool:
        """Toggle favorite status for a preset."""
        if preset_id in self._favorites:
            self._favorites.discard(preset_id)
            is_fav = False
        else:
            self._favorites.add(preset_id)
            is_fav = True

        for p in self._presets:
            if p.id == preset_id:
                p.is_favorite = is_fav
                break
        return is_fav

    def install_preset(self, preset: CommunityPreset, target_dir: str = "") -> bool:
        """Install a preset to the local preset directory."""
        if not target_dir:
            target_dir = self._preset_dirs[0] if self._preset_dirs else ""
        if not target_dir:
            return False

        try:
            Path(target_dir).mkdir(parents=True, exist_ok=True)
            fname = f"{preset.name.replace(' ', '_')}.pydaw-preset"
            fpath = os.path.join(target_dir, fname)

            data = preset.to_dict()
            Path(fpath).write_text(
                json.dumps(data, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )

            preset.file_path = fpath
            preset.source = "local"
            if preset not in self._presets:
                self._presets.append(preset)

            try:
                self.preset_installed.emit(preset.name)
            except Exception:
                pass
            return True

        except Exception as exc:
            log.error("Failed to install preset: %s", exc)
            try:
                self.error.emit(f"Preset-Installation fehlgeschlagen: {exc}")
            except Exception:
                pass
            return False

    def get_all(self) -> List[CommunityPreset]:
        return list(self._presets)

    def add_preset_dir(self, path: str) -> None:
        if path not in self._preset_dirs:
            self._preset_dirs.append(path)

    def get_preset_dirs(self) -> List[str]:
        return list(self._preset_dirs)


# ---------------------------------------------------------------------------
# UI Widget: Community Preset Browser
# ---------------------------------------------------------------------------

class CommunityPresetBrowser(QWidget):
    """Dock-widget for browsing and loading community presets."""

    preset_selected = pyqtSignal(object)   # CommunityPreset
    preset_load = pyqtSignal(object)       # CommunityPreset → load into synth
    status_message = pyqtSignal(str)

    def __init__(
        self,
        repository: Optional[PresetRepositoryService] = None,
        parent: Optional[QWidget] = None,
    ):
        super().__init__(parent)
        self._repo = repository or PresetRepositoryService()
        self._current_results: List[CommunityPreset] = []

        self._setup_ui()
        self._connect_signals()

    def _setup_ui(self) -> None:
        lay = QVBoxLayout(self)
        lay.setContentsMargins(4, 4, 4, 4)
        lay.setSpacing(4)

        # Header
        header = QLabel("🎛 Community Presets")
        header.setStyleSheet("font-size: 14px; font-weight: bold; color: #a5d6a7;")
        lay.addWidget(header)

        # Search bar
        search_row = QHBoxLayout()
        self._search_edit = QLineEdit()
        self._search_edit.setPlaceholderText("🔍 Suche nach Name, Autor, Tags...")
        self._search_edit.setStyleSheet(
            "QLineEdit { background: #2a2a2a; border: 1px solid #555; "
            "border-radius: 4px; padding: 4px 8px; color: #eee; }"
        )
        search_row.addWidget(self._search_edit)

        self._scan_btn = QPushButton("🔄")
        self._scan_btn.setMaximumWidth(35)
        self._scan_btn.setToolTip("Preset-Verzeichnisse neu scannen")
        search_row.addWidget(self._scan_btn)
        lay.addLayout(search_row)

        # Filters
        filter_row = QHBoxLayout()

        self._cat_combo = QComboBox()
        self._cat_combo.addItems(CATEGORIES)
        self._cat_combo.setMaximumWidth(120)
        filter_row.addWidget(QLabel("Kat:"))
        filter_row.addWidget(self._cat_combo)

        self._inst_combo = QComboBox()
        self._inst_combo.addItems(INSTRUMENTS)
        self._inst_combo.setMaximumWidth(120)
        filter_row.addWidget(QLabel("Synth:"))
        filter_row.addWidget(self._inst_combo)

        self._fav_btn = QPushButton("⭐")
        self._fav_btn.setCheckable(True)
        self._fav_btn.setMaximumWidth(35)
        self._fav_btn.setToolTip("Nur Favoriten")
        filter_row.addWidget(self._fav_btn)
        filter_row.addStretch()
        lay.addLayout(filter_row)

        # Results list
        self._list = QListWidget()
        self._list.setStyleSheet(
            "QListWidget { background: #1e1e1e; border: 1px solid #444; }"
            "QListWidget::item { padding: 6px; border-bottom: 1px solid #333; }"
            "QListWidget::item:selected { background: #37474f; }"
        )
        lay.addWidget(self._list, stretch=1)

        # Detail panel
        self._detail = QTextEdit()
        self._detail.setReadOnly(True)
        self._detail.setMaximumHeight(100)
        self._detail.setStyleSheet(
            "QTextEdit { background: #252525; border: 1px solid #444; "
            "color: #ccc; font-size: 11px; }"
        )
        lay.addWidget(self._detail)

        # Action buttons
        btn_row = QHBoxLayout()
        self._load_btn = QPushButton("📥 Laden")
        self._load_btn.setEnabled(False)
        btn_row.addWidget(self._load_btn)

        self._fav_toggle_btn = QPushButton("⭐ Favorit")
        self._fav_toggle_btn.setEnabled(False)
        btn_row.addWidget(self._fav_toggle_btn)

        self._count_label = QLabel("0 Presets")
        self._count_label.setStyleSheet("color: #888; font-size: 11px;")
        btn_row.addStretch()
        btn_row.addWidget(self._count_label)
        lay.addLayout(btn_row)

    def _connect_signals(self) -> None:
        self._search_edit.textChanged.connect(self._on_search)
        self._cat_combo.currentTextChanged.connect(self._on_search)
        self._inst_combo.currentTextChanged.connect(self._on_search)
        self._fav_btn.toggled.connect(self._on_search)
        self._scan_btn.clicked.connect(self._on_scan)
        self._list.currentRowChanged.connect(self._on_select)
        self._load_btn.clicked.connect(self._on_load)
        self._fav_toggle_btn.clicked.connect(self._on_fav_toggle)

    def _on_scan(self) -> None:
        self._repo.scan_local()
        self._on_search()
        try:
            self.status_message.emit(
                f"🔄 {len(self._repo.get_all())} Presets gescannt"
            )
        except Exception:
            pass

    def _on_search(self) -> None:
        query = self._search_edit.text().strip()
        cat = self._cat_combo.currentText()
        inst = self._inst_combo.currentText()
        fav = self._fav_btn.isChecked()

        self._current_results = self._repo.search(
            query=query, category=cat, instrument=inst, favorites_only=fav,
        )

        self._list.clear()
        for preset in self._current_results:
            fav_icon = "⭐" if preset.is_favorite else ""
            rating = "★" * int(preset.rating) if preset.rating > 0 else ""
            text = f"{fav_icon} {preset.name} — {preset.author} [{preset.category}] {rating}"
            self._list.addItem(text.strip())

        self._count_label.setText(f"{len(self._current_results)} Presets")

    def _on_select(self, row: int) -> None:
        if 0 <= row < len(self._current_results):
            preset = self._current_results[row]
            self._load_btn.setEnabled(True)
            self._fav_toggle_btn.setEnabled(True)

            # Show detail
            lines = [
                f"<b>{preset.name}</b> von {preset.author}",
                f"Instrument: {preset.instrument} | Kategorie: {preset.category}",
            ]
            if preset.tags:
                lines.append(f"Tags: {', '.join(preset.tags)}")
            if preset.description:
                lines.append(f"<br>{preset.description}")
            if preset.params:
                lines.append(f"<br>{len(preset.params)} Parameter")
            self._detail.setHtml("<br>".join(lines))

            try:
                self.preset_selected.emit(preset)
            except Exception:
                pass
        else:
            self._load_btn.setEnabled(False)
            self._fav_toggle_btn.setEnabled(False)
            self._detail.clear()

    def _on_load(self) -> None:
        row = self._list.currentRow()
        if 0 <= row < len(self._current_results):
            preset = self._current_results[row]
            try:
                self.preset_load.emit(preset)
                self.status_message.emit(f"📥 Preset '{preset.name}' geladen")
            except Exception:
                pass

    def _on_fav_toggle(self) -> None:
        row = self._list.currentRow()
        if 0 <= row < len(self._current_results):
            preset = self._current_results[row]
            is_fav = self._repo.toggle_favorite(preset.id)
            self._on_search()  # refresh list
            try:
                self.status_message.emit(
                    f"{'⭐ Favorit' if is_fav else '☆ Kein Favorit'}: {preset.name}"
                )
            except Exception:
                pass

    def refresh(self) -> None:
        """Refresh the preset list."""
        self._on_scan()
