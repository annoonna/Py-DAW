"""
pydaw.flux.module_library
=========================

Factory für die ersten Demo-Module.  Jedes Modul wird über eine
Factory-Funktion erzeugt, die Port-Schema und Default-Params setzt.
Die DSP-Implementation lebt in der Rust-Engine
(`pydaw_engine/src/flux/`); diese Datei beschreibt nur die
**Schnittstelle** — was sieht der User auf dem Canvas.

Drei Module reichen für F-0:

1. **Bragi.SineOsc** — einfacher Sinus-Oszillator
2. **Forseti.Lowpass** — Biquad-Tiefpass (nutzt bestehende biquad.rs)
3. **Heimdall.MasterOut** — Stereo-Audio-Ausgang zum DAW-Bus

Diese drei reichen für eine sinnvolle Demo-Patch:
"Bragi.SineOsc → Forseti.Lowpass → Heimdall.MasterOut"

Folge-Sessions erweitern: Bragi.SquareOsc, Bragi.SawOsc,
Bragi.WavetableOsc, Forseti.Highpass, Forseti.Bandpass, Loki.LFO,
Freyr.ADSR, Iduna.Reverb, …
"""

from __future__ import annotations

from typing import Callable

from pydaw.flux.patch_model import Module, Port, PortKind, PortDirection
from pydaw.flux.yggdrasil import GODS

# v0.0.21.202 — S-0: Saga (Sigil-Sight)
from pydaw.flux.saga.saga_magic_module import make_saga_magic


# ─── Factory-Helper ───────────────────────────────────────────────

def _audio_in(name: str = "audio_in", label: str = "Audio In") -> Port:
    return Port(name=name, kind=PortKind.AUDIO,
                direction=PortDirection.INPUT, label=label)


def _audio_out(name: str = "audio_out", label: str = "Audio Out") -> Port:
    return Port(name=name, kind=PortKind.AUDIO,
                direction=PortDirection.OUTPUT, label=label)


def _cv_in(name: str, label: str, default: float = 0.0,
           lo: float = 0.0, hi: float = 1.0, unit: str = "") -> Port:
    return Port(name=name, kind=PortKind.CV,
                direction=PortDirection.INPUT, label=label,
                default=default, minimum=lo, maximum=hi, unit=unit)


# v0.0.21.215 — Rune-Realm helpers (Phase 1 Foundation).
# Rune-Ports tragen diskrete Message-Events (list[dict] pro Block).
# Sie koppeln nicht an numerische Skalierung — _gather_inputs in
# audio_preview.py erkennt PortKind.RUNE und überspringt den
# `val * scale + offset` Pfad. Pro Block fließt entweder eine leere
# Liste (kein Event) oder eine Liste von Events mit mind. "kind"
# (z.B. "bang") und optional "ts" (sample-offset im Block) sowie
# "value" (für float/int/symbol-Messages, ab v.216+).
def _rune_in(name: str = "rune_in", label: str = "Rune In") -> Port:
    return Port(name=name, kind=PortKind.RUNE,
                direction=PortDirection.INPUT, label=label)


def _rune_out(name: str = "rune_out", label: str = "Rune Out") -> Port:
    return Port(name=name, kind=PortKind.RUNE,
                direction=PortDirection.OUTPUT, label=label)


# ─── Demo-Module ───────────────────────────────────────────────────


def make_bragi_sine_osc() -> Module:
    """Bragi.SineOsc — einfacher Sinus-Oszillator.

    Inputs:
        freq    (CV)  — Frequenz in Hz  [20 .. 20000]
        gain    (CV)  — Amplitude        [0 .. 1]
    Outputs:
        audio_out (AUDIO) — der erzeugte Sinus

    Default-Params: freq=440 Hz (Konzert-A), gain=0.5
    """
    return Module(
        god="Bragi",
        kind="SineOsc",
        params={"freq": 440.0, "gain": 0.5, "phase": 0.0},
        inputs=[
            _cv_in("freq", "Frequency", default=440.0, lo=20.0, hi=20000.0, unit="Hz"),
            _cv_in("gain", "Gain",      default=0.5,   lo=0.0,  hi=1.0),
        ],
        outputs=[_audio_out()],
    )


def make_bragi_saw_osc() -> Module:
    """Bragi.SawOsc — Sägezahn-Oszillator (naive, kein Anti-Aliasing).

    Klassischer raw-Synthklang — viele Obertöne, gut für Bässe und Leads.

    Inputs:
        freq    (CV)  — Frequenz in Hz   [20 .. 20000]
        gain    (CV)  — Amplitude         [0 .. 1]
    Outputs:
        audio_out (AUDIO) — Sägezahnwelle (-1 .. +1)

    F-3-Hinweis: Naive Implementation aliast bei sehr hohen Frequenzen.
    Polished BLEP-Variante kommt in einer späteren Phase.
    """
    return Module(
        god="Bragi",
        kind="SawOsc",
        params={"freq": 220.0, "gain": 0.5, "phase": 0.0},
        inputs=[
            _cv_in("freq", "Frequency", default=220.0, lo=20.0, hi=20000.0, unit="Hz"),
            _cv_in("gain", "Gain",      default=0.5,   lo=0.0,  hi=1.0),
        ],
        outputs=[_audio_out()],
    )


def make_bragi_square_osc() -> Module:
    """Bragi.SquareOsc — Rechteck-/Pulsoszillator mit Pulsweite.

    Mit pulse_width=0.5 ist es ein klassisches Rechteck (hohle Quintenklang),
    bei Werten ≠ 0.5 wird es ein Puls (PWM-tauglich).

    Inputs:
        freq         (CV)  — Frequenz in Hz       [20 .. 20000]
        gain         (CV)  — Amplitude             [0 .. 1]
        pulse_width  (CV)  — Pulsweite (Duty)      [0.05 .. 0.95]
    Outputs:
        audio_out (AUDIO) — Rechteckwelle (-1 .. +1)

    F-3-Hinweis: Naive Implementation, kein Anti-Aliasing.
    """
    return Module(
        god="Bragi",
        kind="SquareOsc",
        params={"freq": 220.0, "gain": 0.5, "pulse_width": 0.5, "phase": 0.0},
        inputs=[
            _cv_in("freq",        "Frequency",   default=220.0, lo=20.0,  hi=20000.0, unit="Hz"),
            _cv_in("gain",        "Gain",        default=0.5,   lo=0.0,   hi=1.0),
            _cv_in("pulse_width", "Pulse Width", default=0.5,   lo=0.05,  hi=0.95),
        ],
        outputs=[_audio_out()],
    )


def make_bragi_triangle_osc() -> Module:
    """Bragi.TriangleOsc — Dreieck-Oszillator.

    Wenig Obertöne, weicher Klang — für sanfte Bässe oder als
    Modulator-Quelle nützlich.

    Inputs:
        freq    (CV)  — Frequenz in Hz   [20 .. 20000]
        gain    (CV)  — Amplitude         [0 .. 1]
    Outputs:
        audio_out (AUDIO) — Dreieckwelle (-1 .. +1)
    """
    return Module(
        god="Bragi",
        kind="TriangleOsc",
        params={"freq": 220.0, "gain": 0.5, "phase": 0.0},
        inputs=[
            _cv_in("freq", "Frequency", default=220.0, lo=20.0, hi=20000.0, unit="Hz"),
            _cv_in("gain", "Gain",      default=0.5,   lo=0.0,  hi=1.0),
        ],
        outputs=[_audio_out()],
    )


def make_bragi_noise_osc() -> Module:
    """Bragi.NoiseOsc — White-Noise-Generator.

    Pseudo-zufälliges Rauschen mit gleichmäßigem Spektrum. Kombiniert
    mit Forseti.Lowpass entstehen Wind-, Wasser- und Hi-Hat-Sounds.

    Inputs:
        gain     (CV)  — Amplitude  [0 .. 1]
    Outputs:
        audio_out (AUDIO) — Weißes Rauschen (-1 .. +1)

    Hinweis: Verwendet einen deterministischen LCG-Pseudo-RNG damit
    der Klang reproduzierbar bleibt (gleicher Seed = gleiche Klangfolge).
    """
    return Module(
        god="Bragi",
        kind="NoiseOsc",
        params={"gain": 0.5, "seed": 12345.0},
        inputs=[
            _cv_in("gain", "Gain", default=0.5, lo=0.0, hi=1.0),
        ],
        outputs=[_audio_out()],
    )


def make_loki_lfo_sine() -> Module:
    """Loki.LFOSine — Sinus-LFO (Low Frequency Oscillator).

    Klassischer Modulator. ``phase`` ist die Anfangsphasen-Verschiebung
    in Cycles (0=Sinus startet bei 0, 0.25=startet im Maximum,
    0.5=startet bei 0 fallend). Nützlich um zwei LFOs gegeneinander zu
    phasen-versetzen ohne sie sample-genau syncen zu müssen.

    Inputs:
        rate   (CV)  — Frequenz in Hz       [0.01 .. 50]
        depth  (CV)  — Output-Skalierung    [0 .. 1]
        phase  (CV)  — Initial-Phase-Offset [0 .. 1]
    Outputs:
        cv_out (CV)  — Bipolarer Sinus     [-depth .. +depth]

    v0.0.21.231: ``phase`` ist jetzt ein echter CV-Port mit Range
    [0..1] (vorher: dead-code-Param mit ±1e6 spinbox-range, das
    löste die UI-Anomalie „phase = 370000" aus).
    """
    return Module(
        god="Loki",
        kind="LFOSine",
        params={"rate": 2.0, "depth": 1.0, "phase": 0.0},
        inputs=[
            _cv_in("rate",  "Rate",  default=2.0, lo=0.01, hi=50.0, unit="Hz"),
            _cv_in("depth", "Depth", default=1.0, lo=0.0,  hi=1.0),
            _cv_in("phase", "Phase", default=0.0, lo=0.0,  hi=1.0),
        ],
        outputs=[
            Port("cv_out", PortKind.CV, PortDirection.OUTPUT, "CV Out"),
        ],
    )


def make_loki_lfo_triangle() -> Module:
    """Loki.LFOTriangle — Dreieck-LFO.

    Wie LFOSine aber mit linearem Ramp statt Sinus. Inputs analog
    inkl. ``phase`` als Initial-Offset (siehe LFOSine-Doku).

    v0.0.21.231: phase ist jetzt CV-Port [0..1].
    """
    return Module(
        god="Loki",
        kind="LFOTriangle",
        params={"rate": 2.0, "depth": 1.0, "phase": 0.0},
        inputs=[
            _cv_in("rate",  "Rate",  default=2.0, lo=0.01, hi=50.0, unit="Hz"),
            _cv_in("depth", "Depth", default=1.0, lo=0.0,  hi=1.0),
            _cv_in("phase", "Phase", default=0.0, lo=0.0,  hi=1.0),
        ],
        outputs=[
            Port("cv_out", PortKind.CV, PortDirection.OUTPUT, "CV Out"),
        ],
    )


def make_loki_lfo_square() -> Module:
    """Loki.LFOSquare — Rechteck-LFO mit Pulsweite.

    Hartes On/Off-Schalten — gut für rhythmische Effekte oder
    Dub-Style-Stutter. Pulse-Width steuert das Verhältnis On:Off.

    Inputs:
        rate         (CV)  — Frequenz in Hz       [0.01 .. 50]
        depth        (CV)  — Output-Skalierung    [0 .. 1]
        pulse_width  (CV)  — Pulsweite (Duty)     [0.05 .. 0.95]
        phase        (CV)  — Initial-Phase-Offset [0 .. 1]
    Outputs:
        cv_out       (CV)  — Bipolares Rechteck   {-depth, +depth}

    v0.0.21.231: phase ist jetzt CV-Port [0..1] (siehe LFOSine).
    """
    return Module(
        god="Loki",
        kind="LFOSquare",
        params={"rate": 2.0, "depth": 1.0, "pulse_width": 0.5, "phase": 0.0},
        inputs=[
            _cv_in("rate",        "Rate",        default=2.0, lo=0.01, hi=50.0, unit="Hz"),
            _cv_in("depth",       "Depth",       default=1.0, lo=0.0,  hi=1.0),
            _cv_in("pulse_width", "Pulse Width", default=0.5, lo=0.05, hi=0.95),
            _cv_in("phase",       "Phase",       default=0.0, lo=0.0,  hi=1.0),
        ],
        outputs=[
            Port("cv_out", PortKind.CV, PortDirection.OUTPUT, "CV Out"),
        ],
    )


def make_loki_lfo_sample_hold() -> Module:
    """Loki.LFOSampleHold — Sample & Hold (Random-Steps).

    Bei jedem Rate-Tick wird ein neuer Zufallswert gewählt und bis
    zum nächsten Tick gehalten. Erzeugt „Treppen"-Modulationen, wie
    in alten analogen Synths (Klassiker: random pitch im Berlin-School-
    Sequenzer-Sound).

    Inputs:
        rate    (CV)  — Tick-Frequenz in Hz   [0.01 .. 50]
        depth   (CV)  — Output-Skalierung     [0 .. 1]
    Outputs:
        cv_out  (CV)  — Random-Steps          [-depth .. +depth]

    Reproduzierbar via Modul-Param `seed` (identisch zu Bragi.NoiseOsc):
    gleicher Seed → gleiche Klangfolge.
    """
    return Module(
        god="Loki",
        kind="LFOSampleHold",
        params={"rate": 4.0, "depth": 1.0, "seed": 12345.0},
        inputs=[
            _cv_in("rate",  "Rate",  default=4.0, lo=0.01, hi=50.0, unit="Hz"),
            _cv_in("depth", "Depth", default=1.0, lo=0.0,  hi=1.0),
        ],
        outputs=[
            Port("cv_out", PortKind.CV, PortDirection.OUTPUT, "CV Out"),
        ],
    )


def make_freyr_adsr() -> Module:
    """Freyr.ADSR — klassische 4-stufige Hüllkurve (Attack-Decay-Sustain-Release).

    Wenn `gate` von 0 auf >=0.5 steigt, läuft die Attack-Phase: Output
    steigt linear in `attack` Sekunden auf 1.0. Danach Decay-Phase: linear
    fallend auf `sustain` (in `decay` Sekunden). Solange gate hoch bleibt:
    halten auf sustain. Wenn gate auf <0.5 fällt: Release-Phase, linear
    fallend auf 0 in `release` Sekunden.

    Inputs:
        gate    (CV)  — Trigger-Signal (≥0.5 = on, <0.5 = off)
        attack  (CV)  — Attack-Zeit in Sekunden    [0.001 .. 5]
        decay   (CV)  — Decay-Zeit in Sekunden     [0.001 .. 5]
        sustain (CV)  — Sustain-Level              [0 .. 1]
        release (CV)  — Release-Zeit in Sekunden   [0.001 .. 10]
    Outputs:
        cv_out  (CV)  — Hüllkurve-Wert             [0 .. 1]

    Verwendung: `cv_out` an `Bragi.<Osc>.gain` für Volume-Envelope, oder
    an `Forseti.Lowpass.cutoff` mit scale für Filter-Envelope.
    """
    return Module(
        god="Freyr",
        kind="ADSR",
        params={
            "gate":    0.0,    # statisch off; wird normal via Connection getrieben
            "attack":  0.05,
            "decay":   0.15,
            "sustain": 0.7,
            "release": 0.4,
        },
        inputs=[
            _cv_in("gate",    "Gate",    default=0.0,  lo=0.0,   hi=1.0),
            _cv_in("attack",  "Attack",  default=0.05, lo=0.001, hi=5.0,  unit="s"),
            _cv_in("decay",   "Decay",   default=0.15, lo=0.001, hi=5.0,  unit="s"),
            _cv_in("sustain", "Sustain", default=0.7,  lo=0.0,   hi=1.0),
            _cv_in("release", "Release", default=0.4,  lo=0.001, hi=10.0, unit="s"),
        ],
        outputs=[
            Port("cv_out", PortKind.CV, PortDirection.OUTPUT, "CV Out"),
        ],
    )


def make_tyr_pulse_gate() -> Module:
    """Tyr.PulseGate — periodischer Gate-Generator (Test-Trigger).

    Erzeugt rhythmische On/Off-Pulse zum Triggern von Freyr.ADSR und
    anderen Trigger-Modulen. Praktisch für Test-Play ohne MIDI-Input.
    Wenn F-16 (Pianoroll → FLUX) implementiert ist, wird Tyr.PulseGate
    durch echte MIDI-Note-On/Off ersetzt.

    Inputs:
        rate         (CV)  — Pulse-Frequenz in Hz   [0.1 .. 50]
        pulse_width  (CV)  — Pulsweite (Duty)       [0.05 .. 0.95]
    Outputs:
        gate_out     (CV)  — Gate-Signal {0, 1}
    """
    return Module(
        god="Tyr",
        kind="PulseGate",
        params={"rate": 2.0, "pulse_width": 0.5, "phase": 0.0},
        inputs=[
            _cv_in("rate",        "Rate",        default=2.0, lo=0.1,  hi=50.0, unit="Hz"),
            _cv_in("pulse_width", "Pulse Width", default=0.5, lo=0.05, hi=0.95),
        ],
        outputs=[
            Port("gate_out", PortKind.CV, PortDirection.OUTPUT, "Gate Out"),
        ],
    )


def make_forseti_lowpass() -> Module:
    """Forseti.Lowpass — Biquad-Tiefpassfilter.

    Inputs:
        audio_in    (AUDIO)
        cutoff      (CV) — Eckfrequenz in Hz  [20 .. 20000]
        resonance   (CV) — Q-Faktor           [0.1 .. 10]
    Outputs:
        audio_out   (AUDIO)
    """
    return Module(
        god="Forseti",
        kind="Lowpass",
        params={"cutoff": 1000.0, "resonance": 0.707},
        inputs=[
            _audio_in(),
            _cv_in("cutoff",    "Cutoff",    default=1000.0, lo=20.0, hi=20000.0, unit="Hz"),
            _cv_in("resonance", "Resonance", default=0.707,  lo=0.1,  hi=10.0,    unit="Q"),
        ],
        outputs=[_audio_out()],
    )


def make_forseti_highpass() -> Module:
    """Forseti.Highpass — 1-Pol Hochpass (komplementär zu Lowpass).

    Lässt Frequenzen oberhalb `cutoff` durch und dämpft tiefe Frequenzen.
    Realisierung: y[n] = (input - lowpass(input)) — ein simpler
    1-Pol-HP, gleichwertig zu Lowpass in Komplexität.

    Inputs:
        audio_in  (AUDIO) — Audio-Eingang
        cutoff    (CV)    — Cutoff-Frequenz in Hz   [20 .. 20000]
    Outputs:
        audio_out (AUDIO) — gefilterter Audio-Output

    Anwendung: Hi-Hats von Bass-Frequenzen befreien, „Air" auf Vocals
    legen, DC-Offset entfernen.
    """
    return Module(
        god="Forseti",
        kind="Highpass",
        params={"cutoff": 200.0},
        inputs=[
            _audio_in(),
            _cv_in("cutoff", "Cutoff", default=200.0, lo=20.0, hi=20000.0, unit="Hz"),
        ],
        outputs=[_audio_out()],
    )


def make_forseti_bandpass() -> Module:
    """Forseti.Bandpass — Biquad-Bandpass (RBJ-Cookbook).

    Lässt einen schmalen Frequenzbereich um `cutoff` durch. Mit hoher
    Resonance (Q) wird der Bandpass „wütender" — gut für Wah-/Vocal-
    Effekte und Talk-Box-Sounds.

    Inputs:
        audio_in   (AUDIO) — Audio-Eingang
        cutoff     (CV)    — Center-Frequenz in Hz  [20 .. 20000]
        resonance  (CV)    — Q-Faktor               [0.5 .. 20]
    Outputs:
        audio_out  (AUDIO) — gefilterter Output

    Tipp: Mit Loki.LFOSine an cutoff entstehen Wah-/Auto-Wah-Effekte.
    """
    return Module(
        god="Forseti",
        kind="Bandpass",
        params={"cutoff": 800.0, "resonance": 2.0},
        inputs=[
            _audio_in(),
            _cv_in("cutoff",    "Cutoff",    default=800.0, lo=20.0, hi=20000.0, unit="Hz"),
            _cv_in("resonance", "Resonance", default=2.0,   lo=0.5,  hi=20.0),
        ],
        outputs=[_audio_out()],
    )


def make_forseti_notch() -> Module:
    """Forseti.Notch — Biquad-Notch (Band-Reject, RBJ-Cookbook).

    Komplement zu Bandpass: dämpft einen schmalen Frequenzbereich um
    `cutoff` weg, lässt alles andere durch. Klassisch für Brummen-
    Entfernung (50/60 Hz) oder für Phaser-/Comb-ähnliche Effekte.

    Inputs:
        audio_in   (AUDIO) — Audio-Eingang
        cutoff     (CV)    — Center-Frequenz in Hz  [20 .. 20000]
        resonance  (CV)    — Q-Faktor               [0.5 .. 20]
    Outputs:
        audio_out  (AUDIO) — gefilterter Output

    Tipp: Mit mehreren Notches in Serie + LFO an cutoff entsteht ein
    Phaser-ähnlicher Effekt.
    """
    return Module(
        god="Forseti",
        kind="Notch",
        params={"cutoff": 1000.0, "resonance": 2.0},
        inputs=[
            _audio_in(),
            _cv_in("cutoff",    "Cutoff",    default=1000.0, lo=20.0, hi=20000.0, unit="Hz"),
            _cv_in("resonance", "Resonance", default=2.0,    lo=0.5,  hi=20.0),
        ],
        outputs=[_audio_out()],
    )


def make_forseti_tilt() -> Module:
    """Forseti.Tilt — Tilt-EQ (1-Knob Bass↕Treble).

    Ein einziger Tilt-Wert kippt das Spektrum: positiv hebt Höhen + senkt
    Tiefen, negativ umgekehrt. Realisierung über Lowpass + Highpass mit
    komplementärer Gain-Struktur.

    Inputs:
        audio_in   (AUDIO) — Audio-Eingang
        tilt       (CV)    — Tilt-Wert ∈ [-1, +1] (-1 = bassig, +1 = brillant)
    Outputs:
        audio_out  (AUDIO) — gefärbter Output

    Pivotfrequenz fest auf 1000 Hz — Frequenzen darunter/darüber werden
    komplementär verstärkt/abgesenkt um max. ±6 dB bei tilt=±1.
    """
    return Module(
        god="Forseti",
        kind="Tilt",
        params={"tilt": 0.0},
        inputs=[
            _audio_in(),
            _cv_in("tilt", "Tilt", default=0.0, lo=-1.0, hi=1.0),
        ],
        outputs=[_audio_out()],
    )


def make_forseti_eq4() -> Module:
    """Forseti.EQ4 — 4-Band-EQ (Low-Shelf + 2× Peak + High-Shelf).

    Vier Bänder mit jeweils Gain-Steuerung in dB:
    - Low-Shelf @ 200 Hz
    - Low-Mid Peak @ 800 Hz
    - High-Mid Peak @ 3000 Hz
    - High-Shelf @ 8000 Hz

    Inputs:
        audio_in   (AUDIO) — Audio-Eingang
        low_gain   (CV)    — Low-Shelf-Gain in dB    [-12 .. +12]
        lo_mid_gain (CV)   — Low-Mid-Peak-Gain in dB [-12 .. +12]
        hi_mid_gain (CV)   — High-Mid-Peak-Gain in dB[-12 .. +12]
        high_gain  (CV)    — High-Shelf-Gain in dB   [-12 .. +12]
    Outputs:
        audio_out  (AUDIO) — gefilterter Output

    Hinweis: Frequenzen sind für v0.0.21.178 fest. Variable Frequenzen
    pro Band wären eine Folge-Erweiterung.
    """
    return Module(
        god="Forseti",
        kind="EQ4",
        params={
            "low_gain":    0.0,
            "lo_mid_gain": 0.0,
            "hi_mid_gain": 0.0,
            "high_gain":   0.0,
        },
        inputs=[
            _audio_in(),
            _cv_in("low_gain",    "Low Gain",     default=0.0, lo=-12.0, hi=12.0, unit="dB"),
            _cv_in("lo_mid_gain", "Lo-Mid Gain",  default=0.0, lo=-12.0, hi=12.0, unit="dB"),
            _cv_in("hi_mid_gain", "Hi-Mid Gain",  default=0.0, lo=-12.0, hi=12.0, unit="dB"),
            _cv_in("high_gain",   "High Gain",    default=0.0, lo=-12.0, hi=12.0, unit="dB"),
        ],
        outputs=[_audio_out()],
    )


def make_iduna_delay() -> Module:
    """Iduna.Delay — Tape-Delay mit Feedback, Mix und Tone-Control.

    Klassisches Mono-In/Stereo-Out-Delay. Time wird in Sekunden
    angegeben; das gespeicherte Echo bekommt einen einfachen 1-Pol-
    Lowpass im Feedback-Pfad (Tone-Control), was den klassischen
    „dunklen Tape-Delay"-Charakter erzeugt.

    Inputs:
        audio_in   (AUDIO) — Mono-Input
        time       (CV)    — Delay-Zeit in Sekunden    [0.001 .. 2.0]
        feedback   (CV)    — Feedback-Anteil           [0 .. 0.95]
        mix        (CV)    — Dry/Wet-Mischung          [0 .. 1] (0=dry, 1=wet)
        tone       (CV)    — Tone-Control (LP-Cutoff)  [200 .. 20000] Hz
    Outputs:
        audio_out  (AUDIO) — gemischter Output

    Tipp: Mit Loki.LFOSine an `time` (kleine depth!) entstehen Chorus/
    Flanger-ähnliche Modulationen. Hohe Feedback-Werte (>0.85) erzeugen
    selbsterhaltende Echo-Kaskaden — vorsicht mit Master-Lautstärke!
    """
    return Module(
        god="Iduna",
        kind="Delay",
        params={
            "time":     0.375,   # 3/8 Note bei 120 BPM
            "feedback": 0.4,
            "mix":      0.3,
            "tone":     5000.0,
        },
        inputs=[
            _audio_in(),
            _cv_in("time",     "Time",     default=0.375,  lo=0.001, hi=2.0,    unit="s"),
            _cv_in("feedback", "Feedback", default=0.4,    lo=0.0,   hi=0.95),
            _cv_in("mix",      "Mix",      default=0.3,    lo=0.0,   hi=1.0),
            _cv_in("tone",     "Tone",     default=5000.0, lo=200.0, hi=20000.0, unit="Hz"),
        ],
        outputs=[_audio_out()],
    )


def make_iduna_reverb() -> Module:
    """Iduna.Reverb — Schroeder-Reverb (Plate-artiger Klang).

    Klassische Schroeder-Architektur:
    - 4 parallele Comb-Filter mit primzahl-basierten Verzögerungs-
      Längen (vermeidet Stehwellen / Resonanzen)
    - 2 Allpass-Filter in Serie (diffundieren das Signal)
    - Damping über LP im Comb-Feedback-Pfad

    Inputs:
        audio_in   (AUDIO) — Mono-Input
        room_size  (CV)    — Raum-Größe (skaliert Comb-Längen) [0.1 .. 1.0]
        damping    (CV)    — Höhen-Dämpfung                    [0 .. 1]
        mix        (CV)    — Dry/Wet-Mischung                  [0 .. 1]
    Outputs:
        audio_out  (AUDIO) — gemischter Stereo-Output

    Anwendung: Vocals, Snares, Pads. Bei `room_size > 0.7` entsteht
    ein Hall-artiger Raum, bei `< 0.3` ein kleiner Plate-Klang.
    """
    return Module(
        god="Iduna",
        kind="Reverb",
        params={
            "room_size": 0.5,
            "damping":   0.4,
            "mix":       0.3,
        },
        inputs=[
            _audio_in(),
            _cv_in("room_size", "Room Size", default=0.5, lo=0.1, hi=1.0),
            _cv_in("damping",   "Damping",   default=0.4, lo=0.0, hi=1.0),
            _cv_in("mix",       "Mix",       default=0.3, lo=0.0, hi=1.0),
        ],
        outputs=[_audio_out()],
    )


def make_hel_gater() -> Module:
    """Hel.Gater — rhythmisches Audio-Gate (Trance-Gate / Tremolo).

    Schaltet Audio rhythmisch on/off — bei `rate` Hz mit Pulse-Width-
    Anteil. Mit `smooth` lässt sich die Flankensteilheit einstellen
    (0=hart wie ein Gate, 1=weich wie ein Sinus-Tremolo).

    Inputs:
        audio_in   (AUDIO) — Audio-Eingang
        rate       (CV)    — Gate-Frequenz in Hz       [0.1 .. 50]
        pulse_width(CV)    — On-Anteil pro Zyklus      [0.05 .. 0.95]
        smooth     (CV)    — Flanken-Glättung          [0 .. 1]
        mix        (CV)    — Dry/Wet                   [0 .. 1]
    Outputs:
        audio_out  (AUDIO) — gegateter Output

    Tipp: Mit Loki.LFOSine an `rate` entstehen tempo-modulierte Gater-
    Effekte. Bei `smooth=0.0` und `rate` synchron zum Beat ergibt das
    den klassischen Trance-Gate-Sound.
    """
    return Module(
        god="Hel",
        kind="Gater",
        params={
            "rate":        4.0,
            "pulse_width": 0.5,
            "smooth":      0.05,
            "mix":         1.0,
            "phase":       0.0,  # interner Phase-Counter
        },
        inputs=[
            _audio_in(),
            _cv_in("rate",        "Rate",        default=4.0,  lo=0.1,  hi=50.0, unit="Hz"),
            _cv_in("pulse_width", "Pulse Width", default=0.5,  lo=0.05, hi=0.95),
            _cv_in("smooth",      "Smooth",      default=0.05, lo=0.0,  hi=1.0),
            _cv_in("mix",         "Mix",         default=1.0,  lo=0.0,  hi=1.0),
        ],
        outputs=[_audio_out()],
    )


def make_hel_tape_stop() -> Module:
    """Hel.TapeStop — DJ-Tape-Stop-Effekt (Pitch + Volume runter).

    Wenn `trigger` rising-edge bekommt: über `duration` Sekunden hinweg
    wird der Audio-Pitch + Volume gleichzeitig auf 0 gefahren. Das simuliert
    eine Tape-/Plattenaufnahme die langsam zum Stehen kommt.

    Wenn `trigger` falling-edge bekommt: zurück auf normale Geschwindigkeit
    (instant). Für sanfteres Re-Start `trigger` als kurzes Pulse triggern
    und auf reset warten.

    Inputs:
        audio_in   (AUDIO) — Audio-Eingang
        trigger    (CV)    — Stop-Trigger (≥0.5 = Stop läuft)
        duration   (CV)    — Stop-Zeit in Sekunden     [0.05 .. 5.0]
    Outputs:
        audio_out  (AUDIO) — Tape-Stop-gefiltertes Audio

    Tipp: Mit Tyr.PulseGate (rate=0.25, pw=0.1) ergibt das alle 4
    Sekunden einen kurzen Stop-Effekt. Klassischer DJ-Drop.
    """
    return Module(
        god="Hel",
        kind="TapeStop",
        params={"duration": 0.5, "trigger": 0.0},
        inputs=[
            _audio_in(),
            _cv_in("trigger",  "Trigger",  default=0.0, lo=0.0,  hi=1.0),
            _cv_in("duration", "Duration", default=0.5, lo=0.05, hi=5.0, unit="s"),
        ],
        outputs=[_audio_out()],
    )


# ─── v0.0.21.240 — Hel.Vocoder ─────────────────────────────────────
# Anno (v.239 → v.240): klassischer Vocoder als nächste Bitwig-Familie-
# Erweiterung. Wiederverwendung der FormantOsc-DSP-Logik (3-BP-Filterbank
# pro Voice, v.239) auf 16 Bänder skaliert + zwei Audio-Eingänge.


def make_hel_vocoder() -> Module:
    """Hel.Vocoder — Klassischer Channel-Vocoder (Bitwig/Polymer-Style).

    Modulator-Audio (typisch Stimme/Sprache) steuert das Spektrum eines
    Carrier-Audio (typisch Synth-Pad/Saw). Implementation:

        Modulator → 16 Bandpass-Filter → 16 Envelope-Follower
                                              ↓ (steuern)
        Carrier   → 16 Bandpass-Filter → ×Envelope[i] → Sum → Output

    Die 16 Bänder sind logarithmisch von 100 Hz bis 8000 Hz verteilt
    (das menschliche Sprachformat-Band). `formant_shift` schiebt nur
    die Carrier-Bänder relativ zu den Modulator-Bändern → cartoon-haftes
    Pitch-Shifting der „Stimme" ohne den eigentlichen Carrier-Pitch zu
    ändern. `dry_wet` mischt zwischen unbearbeitetem Carrier und
    Vocoder-Output.

    Anno-Use-Case: Im Vault-Preset wird `Bragi.SwarmOsc` als Carrier
    verbunden mit `Bragi.PulseOsc` (modulier durch Freyr.ADSR)
    als Modulator → klassischer Robot-Voice-Effekt mit rhythmischer
    Pulsation.

    Inputs:
        audio_in       (AUDIO) — Carrier (typisch Synth, harmonienreich)
        mod_in         (AUDIO) — Modulator (typisch Vocal/Speech)
        formant_shift  (CV)    — Carrier-Band-Shift [0.5..2]: <1=tiefer,
                                >1=Mickey-Mouse
        dry_wet        (CV)    — Dry/Wet [0..1]: 0=nur Carrier,
                                1=nur Vocoder-Output
        attack_ms      (CV)    — Envelope-Follow-Attack [0.5..50 ms]
        release_ms     (CV)    — Envelope-Follow-Release [10..500 ms]
    Outputs:
        audio_out (AUDIO)

    Tipp: Für klassischen Robot-Voice-Sound: SwarmOsc als Carrier (viele
    Harmonics), Sprache als Modulator (`mod_in` via Zerberus.Sampler
    geladen). Ohne Sprache ist auch ein Bragi.PulseOsc + Freyr.ADSR
    rhythmisch via Tyr.PulseGate sehr wirksam — pumpenden Robot-Pad.

    NICHTS-KAPUTT: 16 Bänder × 2 Filterbänke (Mod + Carrier) = 32
    Biquads pro Block. Die Python-Loop ist langsamer als numpy-vec aber
    für FLUX-Live-Preview ausreichend (block_size 256 → 32×256 = 8192
    Multiplikationen pro 5.8ms = realtime-ok auf Anno's Hardware).
    """
    return Module(
        god="Hel",
        kind="Vocoder",
        params={"formant_shift": 1.0, "dry_wet": 1.0,
                "attack_ms": 5.0, "release_ms": 80.0},
        inputs=[
            _audio_in("audio_in", "Carrier"),
            _audio_in("mod_in",   "Modulator"),
            _cv_in("formant_shift", "Formant Shift", default=1.0,
                   lo=0.5, hi=2.0),
            _cv_in("dry_wet",       "Dry/Wet",       default=1.0,
                   lo=0.0, hi=1.0),
            _cv_in("attack_ms",     "Attack",        default=5.0,
                   lo=0.5, hi=50.0, unit="ms"),
            _cv_in("release_ms",    "Release",       default=80.0,
                   lo=10.0, hi=500.0, unit="ms"),
        ],
        outputs=[_audio_out()],
    )


def make_mimir_stutter() -> Module:
    """Mimir.Stutter — Buffer-Frost + Re-Trigger (Beat-Repeat).

    Wenn `freeze` ≥ 0.5: Audio-Eingang wird IGNORIERT und stattdessen
    ein kleiner Audio-Buffer (Größe `slice_ms`) wird kontinuierlich
    wiederholt — klassischer „Stutter"-Effekt.

    Wenn `freeze` < 0.5: Audio läuft normal durch + der interne Buffer
    wird kontinuierlich aktualisiert (frische Samples). So bekommt der
    nächste Stutter immer das jüngste Audio-Material.

    Inputs:
        audio_in   (AUDIO) — Audio-Eingang
        freeze     (CV)    — Stutter-Trigger (≥0.5 = stutter läuft)
        slice_ms   (CV)    — Slice-Länge in ms         [10 .. 500]
    Outputs:
        audio_out  (AUDIO) — original oder stutter-Output

    Tipp: Mit Tyr.PulseGate (rate=2.0, pw=0.5) ergibt das einen 2Hz-
    Stutter-Rhythmus. Mit Loki.LFOSine an `slice_ms` (depth=100)
    entsteht ein „atmender" Glitch.
    """
    return Module(
        god="Mimir",
        kind="Stutter",
        params={"freeze": 0.0, "slice_ms": 100.0},
        inputs=[
            _audio_in(),
            _cv_in("freeze",   "Freeze",   default=0.0,   lo=0.0,  hi=1.0),
            _cv_in("slice_ms", "Slice ms", default=100.0, lo=10.0, hi=500.0, unit="ms"),
        ],
        outputs=[_audio_out()],
    )


def make_fenrir_bit_crush() -> Module:
    """Fenrir.BitCrush — Bit-Tiefe-Reduktion (LoFi-Atari-Sound).

    Quantisiert das Audio-Signal auf `bits` Bit-Tiefe. Bei 16 bit
    klingt es nahezu unverändert; bei 8 bit beginnt hörbares Rauschen;
    bei 4 bit klingt es nach Atari/NES; bei 2 bit nach Hardcore-Glitch.

    Inputs:
        audio_in   (AUDIO) — Audio-Eingang
        bits       (CV)    — Bit-Tiefe                 [1 .. 16]
        mix        (CV)    — Dry/Wet                   [0 .. 1]
    Outputs:
        audio_out  (AUDIO) — bitcrushed Output

    Tipp: Vor BitCrush kann ein Bandpass den Sound „fokussieren".
    Nach BitCrush ein Lowpass macht ihn etwas weicher (klassisch
    LoFi-Hip-Hop).
    """
    return Module(
        god="Fenrir",
        kind="BitCrush",
        params={"bits": 8.0, "mix": 1.0},
        inputs=[
            _audio_in(),
            _cv_in("bits", "Bits", default=8.0, lo=1.0, hi=16.0),
            _cv_in("mix",  "Mix",  default=1.0, lo=0.0, hi=1.0),
        ],
        outputs=[_audio_out()],
    )


def make_fenrir_decimator() -> Module:
    """Fenrir.Decimator — Sample-Rate-Reduktion (Aliasing-Sound).

    Hold-and-Sample: nimmt nur jeden N-ten Sample und hält ihn für
    den Rest des Intervalls. Bei `target_sr=48000` unverändert; bei
    `target_sr=8000` Game-Boy-Sound; bei `target_sr=2000` extreme
    Aliasing-Verzerrung.

    Inputs:
        audio_in   (AUDIO) — Audio-Eingang
        target_sr  (CV)    — Ziel-Sample-Rate in Hz    [200 .. 48000]
        mix        (CV)    — Dry/Wet                   [0 .. 1]
    Outputs:
        audio_out  (AUDIO) — decimated Output

    Tipp: Decimator + BitCrush in Serie ergibt klassischen 8-bit-
    Console-Sound. Mit LFOSine an `target_sr` entsteht ein „kaputter
    Empfänger"-Effekt.
    """
    return Module(
        god="Fenrir",
        kind="Decimator",
        params={"target_sr": 8000.0, "mix": 1.0, "phase_acc": 0.0},
        inputs=[
            _audio_in(),
            _cv_in("target_sr", "Target SR", default=8000.0, lo=200.0, hi=48000.0, unit="Hz"),
            _cv_in("mix",       "Mix",       default=1.0,    lo=0.0,   hi=1.0),
        ],
        outputs=[_audio_out()],
    )


# ═══════════════════════════════════════════════════════════════════
# Phase-2-Final v0.0.21.182:  Thor (Distortion) + Vidar (Dynamics)
#                              + Skadi (Modulations-FX)
# ═══════════════════════════════════════════════════════════════════

# ─── F-10 Thor ──────────────────────────────────────────────────────
# „Donner" — Distortion-Familie. Zustandslose Wave-Shaping-Funktionen.

def make_thor_tube_drive() -> Module:
    """Thor.TubeDrive — Soft-Saturation via tanh (Röhren-Charakter).

    Klassischer „warmer" Sound — sanfte Sättigung der Spitzen mit
    musikalisch-harmonischen Obertönen.

    Inputs:
        audio_in   (AUDIO)
        drive      (CV)    — Vorverstärkung in dB     [0 .. 36]
        tone       (CV)    — Tone-Shaping (1-Pol-LP)  [0 .. 1]
        mix        (CV)    — Dry/Wet                  [0 .. 1]
    Outputs:
        audio_out  (AUDIO)

    Tipp: Bei drive=24 dB und tone=0.5 klingt es wie ein klassischer
    Röhren-Vorverstärker. Mit drive=36 wird's hardrock-charakter.
    """
    return Module(
        god="Thor",
        kind="TubeDrive",
        params={"drive": 12.0, "tone": 0.5, "mix": 1.0},
        inputs=[
            _audio_in(),
            _cv_in("drive", "Drive", default=12.0, lo=0.0, hi=36.0, unit="dB"),
            _cv_in("tone",  "Tone",  default=0.5,  lo=0.0, hi=1.0),
            _cv_in("mix",   "Mix",   default=1.0,  lo=0.0, hi=1.0),
        ],
        outputs=[_audio_out()],
    )


def make_thor_fuzz() -> Module:
    """Thor.Fuzz — Hard-Clip mit Bias (aggressiv-asymmetrisch).

    Klassischer Fuzz-Pedal-Sound — harter Clip am Threshold mit
    optional asymmetrischem Bias für gerade Harmonische.

    Inputs:
        audio_in   (AUDIO)
        gain       (CV)    — Vorverstärkung           [0 .. 60 dB]
        bias       (CV)    — Asymmetrie-Offset        [-1 .. +1]
        mix        (CV)    — Dry/Wet                  [0 .. 1]
    Outputs:
        audio_out  (AUDIO)
    """
    return Module(
        god="Thor",
        kind="Fuzz",
        params={"gain": 30.0, "bias": 0.0, "mix": 1.0},
        inputs=[
            _audio_in(),
            _cv_in("gain", "Gain", default=30.0, lo=0.0,  hi=60.0, unit="dB"),
            _cv_in("bias", "Bias", default=0.0,  lo=-1.0, hi=1.0),
            _cv_in("mix",  "Mix",  default=1.0,  lo=0.0,  hi=1.0),
        ],
        outputs=[_audio_out()],
    )


def make_thor_saturation() -> Module:
    """Thor.Saturation — Asymmetrisch warm via tanh+x³ (Tape-Charakter).

    Mischung aus weicher tanh und kubischem Term — emuliert leichten
    Tape-Saturation-Effekt mit musikalischen 2. + 3. Harmonischen.

    Inputs:
        audio_in   (AUDIO)
        amount     (CV)    — Saturation-Stärke        [0 .. 1]
        mix        (CV)    — Dry/Wet                  [0 .. 1]
    Outputs:
        audio_out  (AUDIO)
    """
    return Module(
        god="Thor",
        kind="Saturation",
        params={"amount": 0.5, "mix": 1.0},
        inputs=[
            _audio_in(),
            _cv_in("amount", "Amount", default=0.5, lo=0.0, hi=1.0),
            _cv_in("mix",    "Mix",    default=1.0, lo=0.0, hi=1.0),
        ],
        outputs=[_audio_out()],
    )


def make_thor_wave_shaper() -> Module:
    """Thor.WaveShaper — Wählbare Shaping-Funktion.

    Schaltet zwischen 3 Shape-Funktionen (per `shape`-Parameter):
      0 = Sin-Shape   (sin(x · π/2)) — sehr weich
      1 = Cubic-Shape (1.5x - 0.5x³) — klassisch musikalisch
      2 = Quintic-Shape (1.875x - 1.25x³ + 0.375x⁵) — cleaner Headroom

    Inputs:
        audio_in   (AUDIO)
        drive      (CV)    — Eingangs-Pegel           [0 .. 24 dB]
        shape      (CV)    — Shape-Selector           [0..2]
        mix        (CV)    — Dry/Wet                  [0..1]
    Outputs:
        audio_out  (AUDIO)
    """
    return Module(
        god="Thor",
        kind="WaveShaper",
        params={"drive": 6.0, "shape": 1.0, "mix": 1.0},
        inputs=[
            _audio_in(),
            _cv_in("drive", "Drive", default=6.0, lo=0.0, hi=24.0, unit="dB"),
            _cv_in("shape", "Shape", default=1.0, lo=0.0, hi=2.0),
            _cv_in("mix",   "Mix",   default=1.0, lo=0.0, hi=1.0),
        ],
        outputs=[_audio_out()],
    )


# ─── F-9 Vidar ──────────────────────────────────────────────────────
# „Stille Vergeltung" — Dynamics-Familie.

def make_vidar_compressor() -> Module:
    """Vidar.Compressor — Klassischer Kompressor mit Envelope-Follower.

    Reduziert das Signal um ein Verhältnis (`ratio`) sobald es einen
    Schwellwert (`threshold`) überschreitet. Attack/Release in ms.

    Inputs:
        audio_in   (AUDIO)
        threshold  (CV)    — Schwelle in dB           [-60 .. 0]
        ratio      (CV)    — Kompressions-Ratio       [1 .. 20]
        attack_ms  (CV)    — Attack-Zeit              [0.1 .. 100 ms]
        release_ms (CV)    — Release-Zeit             [10 .. 1000 ms]
        makeup     (CV)    — Make-up-Gain in dB       [0 .. 24]
    Outputs:
        audio_out  (AUDIO)

    Tipp: Klassische Drum-Kompression: threshold=-12, ratio=4,
    attack=5ms, release=50ms, makeup=6.
    """
    return Module(
        god="Vidar",
        kind="Compressor",
        params={
            "threshold":  -12.0,
            "ratio":      4.0,
            "attack_ms":  5.0,
            "release_ms": 50.0,
            "makeup":     0.0,
            "env":        0.0,  # Envelope-Follower-State
        },
        inputs=[
            _audio_in(),
            _cv_in("threshold",  "Threshold",  default=-12.0, lo=-60.0, hi=0.0, unit="dB"),
            _cv_in("ratio",      "Ratio",      default=4.0,   lo=1.0,   hi=20.0),
            _cv_in("attack_ms",  "Attack",     default=5.0,   lo=0.1,   hi=100.0, unit="ms"),
            _cv_in("release_ms", "Release",    default=50.0,  lo=10.0,  hi=1000.0, unit="ms"),
            _cv_in("makeup",     "Makeup",     default=0.0,   lo=0.0,   hi=24.0, unit="dB"),
        ],
        outputs=[_audio_out()],
    )


def make_vidar_limiter() -> Module:
    """Vidar.Limiter — Brick-Wall Hard-Limiter.

    Verhindert dass das Signal `ceiling` (in dB) überschreitet.
    Sehr schnelle Attack (<1ms) für transparente Pegel-Begrenzung.

    Inputs:
        audio_in   (AUDIO)
        ceiling    (CV)    — Brickwall-Pegel          [-12 .. 0 dB]
        release_ms (CV)    — Release-Zeit             [1 .. 500 ms]
    Outputs:
        audio_out  (AUDIO)

    Tipp: Für Master-Bus: ceiling=-0.3 dB (verhindert
    Inter-Sample-Peaks), release=50ms.
    """
    return Module(
        god="Vidar",
        kind="Limiter",
        params={"ceiling": -0.3, "release_ms": 50.0, "env": 0.0},
        inputs=[
            _audio_in(),
            _cv_in("ceiling",    "Ceiling", default=-0.3, lo=-12.0, hi=0.0, unit="dB"),
            _cv_in("release_ms", "Release", default=50.0, lo=1.0,   hi=500.0, unit="ms"),
        ],
        outputs=[_audio_out()],
    )


def make_vidar_gate() -> Module:
    """Vidar.Gate — Threshold-basierter Noise-Gate.

    Schaltet das Signal stumm sobald es unter `threshold` (dB) sinkt.
    Anders als Hel.Gater (rhythmisch): Vidar.Gate ist signalpegel-
    abhängig, perfekt für Drum-Bleed-Reduktion.

    Inputs:
        audio_in   (AUDIO)
        threshold  (CV)    — Open-Schwelle in dB      [-80 .. 0]
        attack_ms  (CV)    — Open-Speed                [0.1 .. 50 ms]
        release_ms (CV)    — Close-Speed               [10 .. 1000 ms]
    Outputs:
        audio_out  (AUDIO)
    """
    return Module(
        god="Vidar",
        kind="Gate",
        params={
            "threshold":  -40.0,
            "attack_ms":  1.0,
            "release_ms": 100.0,
            "env":        0.0,
            "gain":       0.0,
        },
        inputs=[
            _audio_in(),
            _cv_in("threshold",  "Threshold", default=-40.0, lo=-80.0, hi=0.0, unit="dB"),
            _cv_in("attack_ms",  "Attack",    default=1.0,   lo=0.1,   hi=50.0, unit="ms"),
            _cv_in("release_ms", "Release",   default=100.0, lo=10.0,  hi=1000.0, unit="ms"),
        ],
        outputs=[_audio_out()],
    )


# ─── F-8 Skadi ──────────────────────────────────────────────────────
# „Skigöttin, kalt und weit" — Modulations-FX-Familie.

def make_skadi_chorus() -> Module:
    """Skadi.Chorus — Stereo-Chorus mit eingebautem LFO.

    Delay-Modulation 5-30ms mit Sinus-LFO. Stereo: linker und rechter
    LFO 90° phasenverschoben für breiten Stereo-Effekt.

    Inputs:
        audio_in   (AUDIO)
        rate       (CV)    — LFO-Geschwindigkeit      [0.05 .. 8 Hz]
        depth      (CV)    — Modulations-Tiefe        [0 .. 1]
        mix        (CV)    — Dry/Wet                  [0 .. 1]
    Outputs:
        audio_out  (AUDIO)

    Tipp: Klassische Werte: rate=0.5 Hz, depth=0.6, mix=0.5.
    """
    return Module(
        god="Skadi",
        kind="Chorus",
        params={"rate": 0.5, "depth": 0.6, "mix": 0.5},
        inputs=[
            _audio_in(),
            _cv_in("rate",  "Rate",  default=0.5, lo=0.05, hi=8.0, unit="Hz"),
            _cv_in("depth", "Depth", default=0.6, lo=0.0,  hi=1.0),
            _cv_in("mix",   "Mix",   default=0.5, lo=0.0,  hi=1.0),
        ],
        outputs=[_audio_out()],
    )


def make_skadi_flanger() -> Module:
    """Skadi.Flanger — Klassischer Flanger mit Feedback.

    Sehr kurze Delay-Modulation (0-10ms) mit LFO + Feedback-Schleife
    erzeugt den charakteristischen „Jet-Sound".

    Inputs:
        audio_in   (AUDIO)
        rate       (CV)    — LFO-Geschwindigkeit      [0.05 .. 5 Hz]
        depth      (CV)    — Modulations-Tiefe        [0 .. 1]
        feedback   (CV)    — Feedback-Anteil          [-0.95 .. +0.95]
        mix        (CV)    — Dry/Wet                  [0 .. 1]
    Outputs:
        audio_out  (AUDIO)
    """
    return Module(
        god="Skadi",
        kind="Flanger",
        params={"rate": 0.3, "depth": 0.7, "feedback": 0.5, "mix": 0.5},
        inputs=[
            _audio_in(),
            _cv_in("rate",     "Rate",     default=0.3, lo=0.05, hi=5.0, unit="Hz"),
            _cv_in("depth",    "Depth",    default=0.7, lo=0.0,  hi=1.0),
            _cv_in("feedback", "Feedback", default=0.5, lo=-0.95, hi=0.95),
            _cv_in("mix",      "Mix",      default=0.5, lo=0.0,  hi=1.0),
        ],
        outputs=[_audio_out()],
    )


def make_skadi_phaser() -> Module:
    """Skadi.Phaser — 4-Stage-Allpass-Phaser mit LFO.

    4 Allpass-Filter in Serie deren Cutoff-Frequenzen mit Sinus-LFO
    moduliert werden. Klassischer „Schwoosh"-Effekt von Funk/Disco.

    Inputs:
        audio_in   (AUDIO)
        rate       (CV)    — LFO-Geschwindigkeit      [0.05 .. 8 Hz]
        depth      (CV)    — Modulations-Tiefe        [0 .. 1]
        feedback   (CV)    — Feedback-Anteil          [0 .. 0.95]
        mix        (CV)    — Dry/Wet                  [0 .. 1]
    Outputs:
        audio_out  (AUDIO)
    """
    return Module(
        god="Skadi",
        kind="Phaser",
        params={"rate": 0.5, "depth": 0.7, "feedback": 0.4, "mix": 0.5},
        inputs=[
            _audio_in(),
            _cv_in("rate",     "Rate",     default=0.5, lo=0.05, hi=8.0, unit="Hz"),
            _cv_in("depth",    "Depth",    default=0.7, lo=0.0,  hi=1.0),
            _cv_in("feedback", "Feedback", default=0.4, lo=0.0,  hi=0.95),
            _cv_in("mix",      "Mix",      default=0.5, lo=0.0,  hi=1.0),
        ],
        outputs=[_audio_out()],
    )


def make_skadi_stereo_imager() -> Module:
    """Skadi.StereoImager — Mid/Side Width-Control.

    Erweitert oder verengt die Stereo-Breite via Mid/Side-Decoding.
    width=0 = Mono, width=1 = unverändert, width=2 = ultra-breit.

    Inputs:
        audio_in   (AUDIO)
        width      (CV)    — Stereo-Breite            [0 .. 2]
        mix        (CV)    — Dry/Wet                  [0 .. 1]
    Outputs:
        audio_out  (AUDIO)

    Hinweis: In der Mono-Test-Play-Pipeline klingt das nur dezent —
    der echte Effekt zeigt sich erst nach F-1 Audio-Routing in der
    Stereo-DAW-Track.
    """
    return Module(
        god="Skadi",
        kind="StereoImager",
        params={"width": 1.5, "mix": 1.0},
        inputs=[
            _audio_in(),
            _cv_in("width", "Width", default=1.5, lo=0.0, hi=2.0),
            _cv_in("mix",   "Mix",   default=1.0, lo=0.0, hi=1.0),
        ],
        outputs=[_audio_out()],
    )


def make_heimdall_master_out() -> Module:
    """Heimdall.MasterOut — Stereo-Ausgang zum DAW-Track-Buffer.

    Das ist die "Senke" eines Patches.  Pro Patch sollte normalerweise
    genau ein Heimdall.MasterOut existieren — er routet das Audio zum
    Track-Output.

    Inputs:
        audio_in_l  (AUDIO) — Linker Kanal
        audio_in_r  (AUDIO) — Rechter Kanal
        gain        (CV)    — Master-Gain   [0 .. 2]
    Outputs:
        keine — Heimdall ist eine Audio-Senke
    """
    return Module(
        god="Heimdall",
        kind="MasterOut",
        params={"gain": 1.0},
        inputs=[
            Port("audio_in_l", PortKind.AUDIO, PortDirection.INPUT, "L In"),
            Port("audio_in_r", PortKind.AUDIO, PortDirection.INPUT, "R In"),
            _cv_in("gain", "Master Gain", default=1.0, lo=0.0, hi=2.0),
        ],
        outputs=[],
    )


# ─── v0.0.21.195 — Frigg-Familie: UI-Control-Widgets ────────────────
#
# Pure-Data-/Max-/Bitwig-Style Module die DIREKT IM CANVAS leben und
# DSP-Module-Params kontrollieren. Sie haben kein Rust-DSP — die
# `UiModuleBridge` (services/ui_module_bridge.py) iteriert ihre
# Output-Connections und übersetzt Wert-Änderungen in `set_module_param`-
# Calls am Ziel-Modul (D-1-Pfad seit v.184).
#
# Konvention: jedes Frigg-Modul hat genau einen CV-Output `out`. Sein
# `params["value"]` ist der aktuelle Wert; `params["minimum"]`,
# `params["maximum"]`, `params["default"]` definieren die Range. Der
# Output-Port führt den `value` an die Zieladresse weiter.

def make_frigg_knob() -> Module:
    """Frigg.Knob — rundes Knob-Widget (PD-/Max-/Bitwig-Style).

    Im Canvas erscheint ein rundes, animiertes Knob-Widget mit Lerp-
    Animation. Vertikal-Drag ändert den Wert; Shift+Drag = Fine-Tune;
    Doppelklick = Reset auf Default. Der Wert wird über den
    `out` CV-Output an verbundene DSP-Module weitergereicht.

    Default-Bereich 0..1 (gain-style); per Patch-Edit kann der User
    Min/Max/Default auf jeden Wertebereich setzen (z.B. 20..20000 für
    Frequenz, -60..+12 für dB).

    Inputs:
        keine
    Outputs:
        out (CV) — der aktuelle Knob-Wert
    """
    return Module(
        god="Frigg",
        kind="Knob",
        params={"value": 0.5, "minimum": 0.0, "maximum": 1.0, "default": 0.5},
        inputs=[],
        outputs=[
            Port("out", PortKind.CV, PortDirection.OUTPUT, "Out",
                 default=0.5, minimum=0.0, maximum=1.0),
        ],
    )


def make_frigg_slider_v() -> Module:
    """Frigg.SliderV — vertikaler Slider (kontinuierlich).

    Wie Knob aber als vertikaler Schieberegler. Ideal für Volume-
    Fader oder Modulations-Tiefe.

    Inputs:
        keine
    Outputs:
        out (CV) — der aktuelle Slider-Wert
    """
    return Module(
        god="Frigg",
        kind="SliderV",
        params={"value": 0.5, "minimum": 0.0, "maximum": 1.0, "default": 0.5},
        inputs=[],
        outputs=[
            Port("out", PortKind.CV, PortDirection.OUTPUT, "Out",
                 default=0.5, minimum=0.0, maximum=1.0),
        ],
    )


def make_frigg_slider_h() -> Module:
    """Frigg.SliderH — horizontaler Slider (kontinuierlich).

    Wie SliderV aber horizontal. Ideal für Pan, Crossfade, Mix-Regler.
    """
    return Module(
        god="Frigg",
        kind="SliderH",
        params={"value": 0.5, "minimum": 0.0, "maximum": 1.0, "default": 0.5},
        inputs=[],
        outputs=[
            Port("out", PortKind.CV, PortDirection.OUTPUT, "Out",
                 default=0.5, minimum=0.0, maximum=1.0),
        ],
    )


def make_frigg_toggle() -> Module:
    """Frigg.Toggle — Bool-Schalter (on/off).

    Klick wechselt zwischen 0.0 (off) und 1.0 (on). Der Wert wird über
    den CV-Output gesendet. Klassische Verwendung: einen Modulator
    aktivieren/deaktivieren, einen Effekt ein-/ausschalten.

    Inputs:
        keine
    Outputs:
        out (CV) — 0.0 oder 1.0
    """
    return Module(
        god="Frigg",
        kind="Toggle",
        params={"value": 0.0, "minimum": 0.0, "maximum": 1.0, "default": 0.0},
        inputs=[],
        outputs=[
            Port("out", PortKind.CV, PortDirection.OUTPUT, "Out",
                 default=0.0, minimum=0.0, maximum=1.0),
        ],
    )


def make_frigg_bang() -> Module:
    """Frigg.Bang — Trigger-Button (Puls-Event).

    Bei Klick wird ein einzelner Puls (1.0 → 0.0 nach kurzer Zeit) am
    Output gesendet. Für Trigger-Inputs an Envelopes (Freyr.ADSR) oder
    Reset-Pins.

    Inputs:
        keine
    Outputs:
        out (GATE) — Puls (1.0 für ~50ms, sonst 0.0)
    """
    return Module(
        god="Frigg",
        kind="Bang",
        params={"value": 0.0, "minimum": 0.0, "maximum": 1.0, "default": 0.0},
        inputs=[],
        outputs=[
            Port("out", PortKind.GATE, PortDirection.OUTPUT, "Out",
                 default=0.0, minimum=0.0, maximum=1.0),
        ],
    )


def make_frigg_number_box() -> Module:
    """Frigg.NumberBox — numerische Wert-Eingabe (Drag-Editing).

    Wie Knob aber als Number-Box-Display. Direkter Klick → Tastatur-
    Eingabe; Drag → Wert ändern wie SpinBox. Praktisch wenn man einen
    exakten Wert tippen will (z.B. BPM).
    """
    return Module(
        god="Frigg",
        kind="NumberBox",
        params={"value": 0.0, "minimum": -1e6, "maximum": 1e6, "default": 0.0},
        inputs=[],
        outputs=[
            Port("out", PortKind.CV, PortDirection.OUTPUT, "Out",
                 default=0.0, minimum=-1e6, maximum=1e6),
        ],
    )


def make_frigg_comment() -> Module:
    """Frigg.Comment — nicht-funktionales Text-Label im Canvas.

    Text-Label zur Dokumentation des Patches. Hat KEINEN Output —
    rein dekorativ. Der Text liegt in `extra["text"]`.

    Inputs:
        keine
    Outputs:
        keine
    """
    m = Module(
        god="Frigg",
        kind="Comment",
        params={},
        inputs=[],
        outputs=[],
    )
    m.extra["text"] = "Comment …"
    return m


# ─── v0.0.21.197 — FLUX Sigil-Widgets (W-1, Norse-Designs) ──────────
#
# Norse-Sigil-Designs als zusätzliche Modul-Kinds. Alte Frigg.Knob etc.
# bleiben unverändert funktional (Backward-Compat-Pakt aus
# FLUX_GROVE_MANIFEST.md). Signal-Verträge identisch — die UiModuleBridge
# (services/ui_module_bridge.py) und der v.196 Auto-Range-Adapter
# funktionieren ohne Änderung.

def make_frigg_pulse_ring() -> Module:
    """Frigg.PulseRing — Norse-Sigil-Knob (W-1).

    Hohler Ring mit pulsierendem Kern. Wert = Größe des inneren Kerns.
    Beim Drehen läuft eine sich nach außen ausbreitende Welle (Pulse-Wave-
    Animation). Wert-Display unter dem Ring mit Shimmer-Animation beim
    Wechsel. Bei Verbindung leuchtet der Ring in der Connection-Farbe.

    Identische API zum klassischen Frigg.Knob — kann überall eingesetzt
    werden wo ein Knob gebraucht wird.

    Inputs:
        keine
    Outputs:
        out (CV) — der aktuelle Wert
    """
    return Module(
        god="Frigg",
        kind="PulseRing",
        params={"value": 0.5, "minimum": 0.0, "maximum": 1.0, "default": 0.5},
        inputs=[],
        outputs=[
            Port("out", PortKind.CV, PortDirection.OUTPUT, "Out",
                 default=0.5, minimum=0.0, maximum=1.0),
        ],
    )


def make_frigg_aurora_slider_v() -> Module:
    """Frigg.AuroraSliderV — Norse-Sigil-Slider vertikal (W-1).

    Polarlicht-Streifen-Hintergrund der langsam fließt (Aurora-Drift-
    Idle-Loop). Wert-Position = wo der Streifen am hellsten ist. Beim
    Drag bewegt sich das Aurora-Maximum mit.

    Inputs:
        keine
    Outputs:
        out (CV) — der aktuelle Slider-Wert
    """
    return Module(
        god="Frigg",
        kind="AuroraSliderV",
        params={"value": 0.5, "minimum": 0.0, "maximum": 1.0, "default": 0.5},
        inputs=[],
        outputs=[
            Port("out", PortKind.CV, PortDirection.OUTPUT, "Out",
                 default=0.5, minimum=0.0, maximum=1.0),
        ],
    )


def make_frigg_aurora_slider_h() -> Module:
    """Frigg.AuroraSliderH — Norse-Sigil-Slider horizontal (W-1).

    Wie AuroraSliderV aber horizontal — ideal für Pan, Crossfade,
    Mix-Regler.
    """
    return Module(
        god="Frigg",
        kind="AuroraSliderH",
        params={"value": 0.5, "minimum": 0.0, "maximum": 1.0, "default": 0.5},
        inputs=[],
        outputs=[
            Port("out", PortKind.CV, PortDirection.OUTPUT, "Out",
                 default=0.5, minimum=0.0, maximum=1.0),
        ],
    )


def make_frigg_rune_toggle() -> Module:
    """Frigg.RuneToggle — Norse-Sigil-Toggle (W-1).

    Eine Rune (Default ᚠ Fehu — Frigg-Symbol) im OFF-Zustand matt
    graviert; im ON-Zustand glüht sie cyan mit sanfter Pulsation
    (Rune-Glow-Idle-Loop). Beim Klick: kurzer Spark-Burst an den Ecken.

    Identische API zum klassischen Frigg.Toggle.

    Inputs:
        keine
    Outputs:
        out (CV) — 0.0 oder 1.0
    """
    m = Module(
        god="Frigg",
        kind="RuneToggle",
        params={"value": 0.0, "minimum": 0.0, "maximum": 1.0, "default": 0.0},
        inputs=[],
        outputs=[
            Port("out", PortKind.CV, PortDirection.OUTPUT, "Out",
                 default=0.0, minimum=0.0, maximum=1.0),
        ],
    )
    # Welche Rune zeigen — User kann das per extra["rune"] anpassen.
    # Default Fehu (ᚠ).
    m.extra["rune"] = "ᚠ"
    return m


def make_frigg_spark_bang() -> Module:
    """Frigg.SparkBang — Norse-Sigil-Bang (W-1).

    8-zackiger Funken-Stern (Mjölnir-Funken). Bei Klick: Explosion
    von 12 Funken radial auswärts (Spark-Burst-Animation). Identisches
    Puls-Verhalten zum klassischen Frigg.Bang (1.0 für ~80ms, dann 0.0).

    Inputs:
        keine
    Outputs:
        out (GATE) — Puls (1.0 für ~80ms, sonst 0.0)
    """
    return Module(
        god="Frigg",
        kind="SparkBang",
        params={"value": 0.0, "minimum": 0.0, "maximum": 1.0, "default": 0.0},
        inputs=[],
        outputs=[
            Port("out", PortKind.GATE, PortDirection.OUTPUT, "Out",
                 default=0.0, minimum=0.0, maximum=1.0),
        ],
    )


# ─── Phase W-2 (v0.0.21.200): FLUX Display-Sigil-Widgets ─────────────


def make_frigg_volva_number() -> Module:
    """Frigg.VolvaNumber — prophetisches Zahlen-Display (W-2).

    Großes monospaced Zahlen-Display mit Pulse-Wave bei Wert-Änderung
    und subtilem Idle-Shimmer. Editierbar via Klick + Drag-Vertikal,
    Mausrad, Doppelklick→Default.

    Verwendung: Frequenz-Anzeige, BPM-Display, Cents-Wert,
    arbiträre Numerische Werte mit konfigurierbaren Decimals.

    Inputs:
        keine
    Outputs:
        out (CV) — der aktuelle Wert
    """
    return Module(
        god="Frigg",
        kind="VolvaNumber",
        params={"value": 0.0, "minimum": -1e6, "maximum": 1e6,
                "default": 0.0, "decimals": 3.0},
        inputs=[],
        outputs=[
            Port("out", PortKind.CV, PortDirection.OUTPUT, "Out",
                 default=0.0, minimum=-1e6, maximum=1e6),
        ],
    )


def make_frigg_bauta_stone() -> Module:
    """Frigg.BautaStone — runischer Stein-Switch (W-2).

    Stein-grauer Sigil-Stein mit eingravierter Rune. Klick → Cycle
    durch 4 States (Default-Runen ᚠ ᚢ ᚦ ᚨ). Right-Click rückwärts.
    Mausrad → Schritt vor/zurück. Doppelklick → Reset.

    Verwendung: diskrete Multi-State-Wahl wo Toggle nicht reicht.
    Wave-Form-Switch, Filter-Mode-Switch, Modus-Wahl.

    Inputs:
        keine
    Outputs:
        out (CV) — der State als 0..1 (gleichmäßig verteilt)
    """
    m = Module(
        god="Frigg",
        kind="BautaStone",
        params={"value": 0.0, "minimum": 0.0, "maximum": 1.0,
                "default": 0.0},
        inputs=[],
        outputs=[
            Port("out", PortKind.CV, PortDirection.OUTPUT, "Out",
                 default=0.0, minimum=0.0, maximum=1.0),
        ],
    )
    # User kann via extra["runes"] eigene Rune-Liste setzen
    m.extra["runes"] = ["ᚠ", "ᚢ", "ᚦ", "ᚨ"]
    return m


def make_frigg_mani_meter() -> Module:
    """Frigg.ManiMeter — Mond-Phasen-Anzeige (W-2).

    Mondförmige Wert-Visualisierung: 0 = Neumond, 0.5 = Halbmond,
    1.0 = Vollmond. Idle-Lunar-Phase-Cycle als Sternchen-Animation am
    Rand, Echo-Ring beim Wert-Wechsel.

    Verwendung: organische Mix-Regler, Gain-Visualisierung,
    Modulation-Tiefe-Anzeige.

    Inputs:
        keine
    Outputs:
        out (CV) — der aktuelle Wert
    """
    return Module(
        god="Frigg",
        kind="ManiMeter",
        params={"value": 0.5, "minimum": 0.0, "maximum": 1.0,
                "default": 0.5},
        inputs=[],
        outputs=[
            Port("out", PortKind.CV, PortDirection.OUTPUT, "Out",
                 default=0.5, minimum=0.0, maximum=1.0),
        ],
    )


def make_frigg_number_flow() -> Module:
    """Frigg.NumberFlow — Live-Probe für CV/RUNE-Werte (v.231).

    Anno-Direktive (mit zwei Screenshots): „könntest du noch ein number
    modul bauen wo ich sehe das da zahlen durch gehen also nubers mit
    ein und ausgängen ich will an lfo sehen ob da was durch kommt".

    NumberFlow ist eine Sonderform unter Frigg — anders als die anderen
    Frigg-Widgets (NumberBox, VolvaNumber, ManiMeter, Knob...) hat
    NumberFlow einen **Eingang** und reicht den Wert UNVERÄNDERT an
    seinen Ausgang weiter. Es ist ein Multimeter im Patch:

        Loki.LFOSine.cv_out ─→ Frigg.NumberFlow.cv_in ─→ Bragi.SineOsc.frequency
                                       │
                                       └─ Display zeigt: 226.4 (live)

    Im Audio-Preview-Renderer hat NumberFlow eine eigene Branch
    (vor dem Standard-UI-Widget-Stub): liest cv_in als Skalar,
    publisht den Wert in ``audio_preview._module_values[mod_id]``,
    schreibt das Skalar in cv_out (Konstante über den ganzen Block).

    Das eingebettete ``NumberFlowWidget`` zeigt:
        * großes Cyan-Number-Display (decimals konfigurierbar via Param)
        * 64-Sample Sparkline-Historie unter der Zahl (autoscale)
        * Pulse-Glow am Rahmen wenn der Wert sich gerade ändert

    Inputs:
        cv_in (CV) — Eingehender Wert (akzeptiert auch RUNE über die
            v.219 Permissive-Connections-Bridge)
    Outputs:
        cv_out (CV) — Pass-through des Eingangs

    Params:
        decimals (CV, 0..6, default 3) — Display-Präzision

    NICHTS-KAPUTT: rein additiv. Existierende Frigg-Module (alle ohne
    Inputs) sind unangefastet.
    """
    return Module(
        god="Frigg",
        kind="NumberFlow",
        params={"decimals": 3.0},
        inputs=[
            Port("cv_in", PortKind.CV, PortDirection.INPUT, "CV In",
                 default=0.0, minimum=-1e9, maximum=1e9),
        ],
        outputs=[
            Port("cv_out", PortKind.CV, PortDirection.OUTPUT, "CV Out",
                 default=0.0, minimum=-1e9, maximum=1e9),
        ],
    )


# ─── v0.0.21.215 — Rune-Realm Phase 1 (Vör-Familie) ───────────────


def make_voer_bang() -> Module:
    """Vör.Bang — periodischer Rune-Bang-Producer (Phase 1 Foundation).

    Sendet einen Bang-Message-Event nach jeweils ``period_blocks`` Audio-
    Blöcken. Das ist die simpelste Form eines Rune-Producers — analog zu
    PD's ``metro`` aber blockzählend statt millisekunden-basiert (Phase 1
    Vereinfachung; sample-genaues Timing kommt mit Norns.Metro in v.219).

    Inputs:
        keine (autonomer Producer)
    Outputs:
        rune_out (RUNE) — Liste aus Bang-Messages pro Block
                          (entweder ``[]`` oder ``[{"kind": "bang", "ts": 0}]``)

    Default ``period_blocks=8``: bei 256-Sample-Block + 44100 Hz = 1 Bang
    alle ~46 ms ≈ 21.5 Hz.

    Verwendung: an ``Vör.RuneTap`` zum Test der Rune-Pipeline. Spätere
    Konsumenten: Vör.Route (split by-symbol), Norns.Pipe (delay messages),
    Ratatosk.RuneToStream (RUNE → CV bridge).
    """
    return Module(
        god="Vör",
        kind="Bang",
        params={"period_blocks": 8.0},
        inputs=[],
        outputs=[_rune_out("rune_out", "Rune Out")],
    )


def make_voer_rune_tap() -> Module:
    """Vör.RuneTap — Rune-Message-Counter (Phase 1 Debug/Sink).

    Konsumiert eingehende Rune-Messages und zählt sie in seinem internen
    State. Der Count ist über das Properties-Panel im Patch-Editor sichtbar
    (read-only, Live-Inspection). Nützlich um zu prüfen ob Rune-Pipeline
    funktioniert ohne ein UI-Widget zu brauchen.

    Inputs:
        rune_in  (RUNE) — eingehende Messages werden gezählt
    Outputs:
        keine (Sink-Modul)

    Param ``count`` wird per Block aktualisiert vom audio_preview-Renderer.
    Reset-Pattern: Modul löschen + neu einfügen (oder count manuell auf 0
    setzen). Echte Reset-Trigger kommen mit Vör.Trigger in v.218.
    """
    return Module(
        god="Vör",
        kind="RuneTap",
        params={"count": 0.0},
        inputs=[_rune_in("rune_in", "Rune In")],
        outputs=[],
    )


# ─── v0.0.21.216 — Rune-Realm Phase 2.1 (Vör.Route + Vör.Select) ──


def make_voer_route() -> Module:
    """Vör.Route — splittet Rune-Messages by ``kind`` an typisierte Outputs.

    Phase-2-Foundation der Vör-Familie. Analog zu PD's ``route`` aber
    auf das ``kind``-Feld der Rune-Messages. Eine eingehende Liste an
    Messages wird pro Block in 4 disjunkte Listen aufgeteilt:

    Inputs:
        rune_in (RUNE) — eingehende Messages (oft gemischt)
    Outputs:
        rune_bang   (RUNE) — alle msg mit kind=="bang"
        rune_float  (RUNE) — alle msg mit kind=="float" oder "int"
        rune_symbol (RUNE) — alle msg mit kind=="symbol" oder "list"
        rune_else   (RUNE) — alles übrige (Forward-Compatibility)

    Beispiel-Pipeline (ab v.225 mit Ratatosk):

        Vör.Bang.rune_out  ──>  Vör.Route.rune_in
        Vör.Route.rune_bang ──>  Vör.RuneTap.rune_in
        Vör.Route.rune_float ──> Ratatosk.RuneToStream.rune_in

    Phase-1-Vereinfachung: kein User-konfigurierbares Pattern-Matching
    (PD's ``route 1 2 foo``). Die 4 typ-basierten Outputs decken die
    häufigste Verwendung ab und passen zum aktuellen Daten-Format. User-
    Patterns kommen mit Ullr.Expr in v.222+.

    NICHTS-KAPUTT: Modul ist strikt additiv, keine Mutation der ein-
    gehenden Messages — pro Output eine neue Liste.

    v0.0.21.229: ``dynamic_outputs=True`` — der Renderer trackt
    eingehende Werte in ``observed_tags["rune_in"]``. Nach Patch-Run
    sieht der User (UI v.230+) welche Werte tatsächlich auftauchen
    und kann sie zu Pattern-Outputs promoten.
    """
    return Module(
        god="Vör",
        kind="Route",
        params={},
        inputs=[_rune_in("rune_in", "Rune In")],
        outputs=[
            _rune_out("rune_bang",   "Bang"),
            _rune_out("rune_float",  "Float/Int"),
            _rune_out("rune_symbol", "Symbol/List"),
            _rune_out("rune_else",   "Else"),
        ],
        dynamic_outputs=True,
    )


def make_voer_select() -> Module:
    """Vör.Select — Boolean-Test einer Message auf ``kind`` (+optional ``value``).

    Analog zu PD's ``select`` / ``sel``: emittiert einen Bang an
    ``match_out`` wenn die eingehende Message dem Match-Kriterium
    entspricht, sonst an ``miss_out``. Pro Block wird **jede einzelne**
    Message geprüft — eine Liste mit 3 Messages kann also 3 Bangs am
    selben Output erzeugen.

    Inputs:
        rune_in (RUNE) — eingehende Messages
    Outputs:
        match_out (RUNE) — Bang pro Match
        miss_out  (RUNE) — Bang pro Miss

    Params:
        match_kind   — "bang" | "float" | "int" | "symbol" | "list"
                       (Default 1.0 ≙ "bang"; via NumberBox-Mapping)
        match_value  — bei kind=float/int: numerischer Vergleichswert
                       (Default 0.0; nur ausgewertet wenn kind!=bang)
        use_value    — 0/1 — ob match_value berücksichtigt wird
                       (Default 0.0 = nur kind matchen)

    Daten-Format-Detail: ``match_kind`` ist intern Float (Properties-
    Panel), wird über kleines Mapping in String aufgelöst (siehe
    ``audio_preview._VOER_SELECT_KIND_MAP``). Konvention:
       1=bang, 2=float, 3=int, 4=symbol, 5=list, sonst=else.

    Sample-Offset: emittierte Bangs übernehmen den ``ts`` der Original-
    Message (sample-genaues Timing bleibt erhalten — wichtig für die
    spätere Norns.Metro-Integration in v.219).
    """
    return Module(
        god="Vör",
        kind="Select",
        params={
            "match_kind": 1.0,   # 1 = "bang" (Default)
            "match_value": 0.0,
            "use_value": 0.0,
        },
        inputs=[_rune_in("rune_in", "Rune In")],
        outputs=[
            _rune_out("match_out", "Match"),
            _rune_out("miss_out",  "Miss"),
        ],
        dynamic_outputs=True,  # v.229 — Living Patterns Foundation
    )


# ─── v0.0.21.217 — Rune-Realm Phase 2.2 (Vör.Spigot + Vör.Trigger) ──


def make_voer_spigot() -> Module:
    """Vör.Spigot — gated Pass-Through für Rune-Messages.

    Phase-2.2 der Vör-Familie. Analog zu PD's ``spigot``: leitet
    eingehende Messages nur dann weiter, wenn ``gate`` (CV) > 0.5
    ist — sonst werden sie verworfen. Erste Bridge zwischen Stream-
    Realm (CV) und Rune-Realm: ein Frigg.Toggle/SparkBang kann Rune-
    Pipelines an/aus schalten ohne Ratatosk-Bridge.

    Inputs:
        rune_in (RUNE) — Eingangs-Messages
        gate    (CV)   — 0..1, > 0.5 = open, ≤ 0.5 = closed
                         (default 1.0 = always open)

    Outputs:
        rune_out (RUNE) — gefilterte Messages

    NICHTS-KAPUTT: kein Memory zwischen Blöcken — pure Funktion.
    Gate wird per ``_scalarize`` aus dem Block-Average bestimmt; das
    ist für die typische Toggle-Anwendung (Frigg.Toggle: konstantes
    0/1) völlig ausreichend. Sample-genaues Gating würde ein extra
    Modul brauchen (Norns-Gate kommt später).

    Use-Case: ``Frigg.Toggle.cv_out → Spigot.gate`` macht jeden Rune-
    Pfad mute-bar mit einem Klick. Sehr typische Live-Performance-
    Pattern aus Reaktor.
    """
    return Module(
        god="Vör",
        kind="Spigot",
        params={"gate": 1.0},   # default open
        inputs=[
            _rune_in("rune_in", "Rune In"),
            _cv_in("gate", "Gate", default=1.0, lo=0.0, hi=1.0),
        ],
        outputs=[_rune_out("rune_out", "Rune Out")],
    )


def make_voer_trigger() -> Module:
    """Vör.Trigger — Sequence-Output (PD: ``trigger`` / ``t b b b``).

    Phase-2.2 der Vör-Familie. Bei jeder eingehenden Message werden
    Bangs an N Outputs in fester Reihenfolge emittiert. PD-Konvention
    ist right-to-left (höchste Output-Nummer zuerst); FLUX implementiert
    same-block-fanout, weil Reihenfolge innerhalb eines Block keine
    semantische Bedeutung in numpy-Pipelines hat.

    Inputs:
        rune_in (RUNE) — Trigger-Source
    Outputs:
        rune_out_1 (RUNE) — gleiche Bang-Liste
        rune_out_2 (RUNE) — gleiche Bang-Liste
        rune_out_3 (RUNE) — gleiche Bang-Liste

    Phase-2.2 fixiert N=3 — das deckt 90% der PD-Patches ab und vermeidet
    dynamisches Port-Schema (das in v.228+ mit Hoenir.Stave kommt). User
    die mehr brauchen ketten zwei Triggers (rune_out_3 → next.rune_in).

    Use-Case: ``Trigger`` macht aus einem einzelnen Bang gleichzeitig
    drei Aktionen — z.B. Voice-Trigger + Counter-Reset + UI-Pulse. Die
    Order-of-Operations ist im selben Block deterministisch (gleiche
    Liste, alle drei Outputs).

    NICHTS-KAPUTT: emittiert dieselbe Liste-Referenz an alle Outputs
    NICHT — pro Output eine flache Kopie. Damit kann ein Konsument die
    Liste mutieren ohne Side-Effects.
    """
    return Module(
        god="Vör",
        kind="Trigger",
        params={},
        inputs=[_rune_in("rune_in", "Rune In")],
        outputs=[
            _rune_out("rune_out_1", "Out 1"),
            _rune_out("rune_out_2", "Out 2"),
            _rune_out("rune_out_3", "Out 3"),
        ],
    )


# ─── v0.0.21.220 — Rune-Realm Phase 2.4 (Vör.Float + Vör.Int Producer) ──


def make_voer_float() -> Module:
    """Vör.Float — Float-Message-Producer (trigger-getriggert).

    Pro eingehender Message am Trigger-Port wird ein Float-Event mit
    dem konfigurierten ``value`` an den Output emittiert. Der Sample-
    Offset (``ts``) wird von der Trigger-Message übernommen — damit
    bleibt sample-genaues Timing erhalten (wichtig für die spätere
    Norns-Familie in v.220-222).

    Inputs:
        trigger (RUNE) — Trigger-Source (Bang oder beliebige Message)
        value   (CV)   — Float-Wert (kann von Knob/LFO moduliert werden)

    Outputs:
        rune_out (RUNE) — Float-Messages mit ``{"kind": "float",
                          "value": value, "ts": ts}``

    Anwendung: ``Vör.Bang(period=4) → Vör.Float(value=440) → ?`` —
    sendet alle 4 Blöcke einen Float-Event mit Wert 440. Konsumiert
    von ``Vör.Route.rune_float`` oder zukünftigen Modulen die Float-
    Messages verstehen (Ullr.Plus, Ratatosk.RuneToStream, ...).

    NICHTS-KAPUTT: rein additiv. Wenn der Trigger-Input keine RUNE-
    Liste liefert (z.B. CV→RUNE-Bridge), wird die Reverse-Pulse-
    Bridge (rising edge) automatisch von ``_gather_inputs``
    angewendet — Float-Events kommen dann genau bei Edge-Übergängen.
    """
    return Module(
        god="Vör",
        kind="Float",
        params={"value": 0.0},
        inputs=[
            _rune_in("trigger", "Trigger"),
            _cv_in("value", "Value", default=0.0, lo=-1000.0, hi=1000.0),
        ],
        outputs=[_rune_out("rune_out", "Float Out")],
    )


def make_voer_int() -> Module:
    """Vör.Int — Int-Message-Producer (trigger-getriggert).

    Wie Vör.Float, aber emittiert Int-Messages (``round()`` auf den
    Float-Wert). Nützlich für MIDI-Note-Numbers, Index-Selektion in
    späteren List-Modulen, Counter-Werte (siehe Ullr.Counter v.223+).

    Inputs:
        trigger (RUNE) — Trigger-Source
        value   (CV)   — wird auf int gerundet

    Outputs:
        rune_out (RUNE) — Int-Messages mit ``{"kind": "int",
                          "value": int(round(value)), "ts": ts}``

    Vör.Route routet Int-Messages auf den ``rune_float``-Output
    (gleicher Realm: numerisch); Konsumenten unterscheiden über
    ``msg["kind"]`` zwischen float und int.
    """
    return Module(
        god="Vör",
        kind="Int",
        params={"value": 0.0},
        inputs=[
            _rune_in("trigger", "Trigger"),
            _cv_in("value", "Value", default=0.0, lo=-1000.0, hi=1000.0),
        ],
        outputs=[_rune_out("rune_out", "Int Out")],
    )


# ─── v0.0.21.221 — Rune-Realm Phase 2.5 (Vör.Knob — Continuous Float-Source) ──


def make_voer_knob() -> Module:
    """Vör.Knob — autonomer Float-Producer (continuous knob).

    Phase-2.5 der Vör-Familie. Anno-Direktive: „ich brauch auch vör-knob".
    Komplementär zu Vör.Float (das ist trigger-getriggert) — Vör.Knob
    läuft autonom und emittiert einen Float-Event NUR wenn der Wert
    sich seit dem letzten Block geändert hat. Damit hat man:

      * Vör.Bang   → autonomer Bang-Producer (period-basiert)
      * Vör.Float  → trigger-getriggerter Float-Producer
      * Vör.Knob   → autonomer Float-Producer (auf Wert-Änderung)
      * Vör.Int    → trigger-getriggerter Int-Producer

    Zwei Modi gleichzeitig:
      * **Properties-Knob:** User dreht ``value`` direkt im
        Properties-Panel → Float fließt
      * **CV-Modulation:** ``Frigg.Knob.out → Vör.Knob.value`` (CV) →
        Vör.Knob detect change → Float fließt. Macht aus jedem CV-
        Stream einen sparsamen Float-Stream (nur bei Änderung).

    Inputs:
        value (CV) — der zu sendende Wert (default 0.0; falls
                     unverbunden wird ``module.params["value"]``
                     genutzt)
    Outputs:
        rune_out (RUNE) — Float-Messages mit ``{"kind": "float",
                          "value": value, "ts": 0}``

    Verhalten: emit erstes Float beim ersten Block (init), dann nur
    bei Wert-Änderung. Damit kein Spam, aber Live-Feedback bei
    User-Bewegung.

    NICHTS-KAPUTT: rein additiv. Anwendungen:
      * Frigg.Knob → Vör.Knob (CV-Stream zu Float-Stream)
      * Direkter Properties-Knob als User-Wert-Quelle
      * Mit Vör.Int kombinieren für Counter/Indices
    """
    return Module(
        god="Vör",
        kind="Knob",
        params={"value": 0.0},
        inputs=[
            _cv_in("value", "Value", default=0.0, lo=-1000.0, hi=1000.0),
        ],
        outputs=[_rune_out("rune_out", "Float Out")],
    )


# ─── v0.0.21.221 — Rune-Realm Phase 3 (Norns-Familie: Time & Sequencing) ──


def make_norns_metro() -> Module:
    """Norns.Metro — Sample-genauer Bang-Generator (Hz-konfigurierbar).

    Phase 3.1 der Norns-Familie (die drei Schicksals-Göttinnen
    Urð/Verðandi/Skuld). Löst Vör.Bang's block-rate-Vereinfachung ab:
    während Vör.Bang nur am Block-Anfang feuert (period_blocks zählt
    Audio-Blöcke), berechnet Norns.Metro die Bang-Positionen
    sample-präzise innerhalb jedes Blocks.

    Inputs:
        rate_hz (CV) — Frequenz in Hz (1.0 = 1 Bang/Sekunde)
    Outputs:
        rune_out (RUNE) — Bang-Messages mit korrektem ``ts`` innerhalb
                          des Blocks

    Beispiele bei sr=48000, block_size=256:
      * rate_hz=4.0:    period=12000 samples = 1 Bang alle 47 Blöcke,
                        ts variabel innerhalb des Blocks
      * rate_hz=187.5:  period=256 samples = 1 Bang/Block (am ts=0)
      * rate_hz=1000.0: period=48 samples = ~5 Bangs/Block, sample-genau

    Edge-Cases:
      * rate_hz <= 0: clamped auf 0.001 Hz (1 Bang alle 1000 Sek)
      * rate_hz > sr/2: clamped auf sr/2 (Nyquist-analog)

    Algorithmik: O(triggers_per_block) statt O(block_size) — direkt
    erste-Trigger-Position berechnen via ``(-sc) % period_samples``,
    dann mit period_samples-Schritten weitergehen bis block_end.

    Verwendung mit Norns.Pipe (Phase 3.3): Metro→Pipe für sample-
    genaue Delay-Sequenzen. Mit Vör.Float (Phase 2.4): Metro→Float
    für rhythmische Float-Ströme.
    """
    return Module(
        god="Norns",
        kind="Metro",
        params={"rate_hz": 4.0},
        inputs=[
            _cv_in("rate_hz", "Rate Hz", default=4.0, lo=0.001, hi=20000.0,
                   unit="Hz"),
        ],
        outputs=[_rune_out("rune_out", "Bang Out")],
    )


def make_norns_line() -> Module:
    """Norns.Line — Lineare Float-Ramp über Zeit (PD: ``line``).

    Phase 3.2 der Norns-Familie. Bei eingehender Trigger-Message
    startet eine lineare Interpolation von ``start`` zu ``end`` über
    ``duration_ms`` Sekunden. Pro Audio-Block wird der aktuelle
    interpolierte Wert als Float-Message emittiert. Wenn die Ramp
    fertig ist, emit final-value (=end) und go to idle.

    Inputs:
        trigger     (RUNE) — startet die Ramp neu
        start       (CV)   — Startwert (default 0.0)
        end         (CV)   — Zielwert (default 1.0)
        duration_ms (CV)   — Ramp-Dauer in ms (default 1000.0)

    Outputs:
        rune_out (RUNE) — Float-Messages, 1 pro Block während Ramp aktiv

    Verhalten:
      * Bei trigger-Bang: aktiviere Ramp, snapshot start/end/duration,
        progress=0
      * Pro Block: emit 1 Float mit interpoliertem Wert,
        progress += block_size
      * Wenn progress >= duration_samples: emit end-Wert,
        deaktiviere
      * Mehrere Trigger neu hintereinander: jede neue Trigger
        überschreibt Ramp (last-wins, PD-konform)

    1 Float-Message pro Block ist ausreichend für CV-Modulation
    (Audio-Rate ist ``Bragi.SineOsc.audio_out`` etc., nicht der
    Rune-Realm). Sample-genauere Ramps wären spammig — wer das
    braucht nutzt eine Audio-Rate-LFO direkt.

    Use-Case: ``Frigg.Bang → Norns.Line(0→1, 500ms) → Vör.Float`` …
    nö Quatsch — Line emittiert SCHON Float-Messages, nicht Bangs.
    Korrekt: Line.rune_out → Bragi.SineOsc.gain (RUNE→CV via Forward-
    Pulse-Bridge → 1.0 wenn Float kommt, sonst 0.0). Oder:
    Line.rune_out → Vör.RuneTap (Float-Counter sichtbar machen).
    Ratatosk.RuneToStream (Phase 5) wird eine echte Float-zu-CV-
    Konversion mit Smoothing bringen.
    """
    return Module(
        god="Norns",
        kind="Line",
        params={"start": 0.0, "end": 1.0, "duration_ms": 1000.0},
        inputs=[
            _rune_in("trigger", "Trigger"),
            _cv_in("start", "Start", default=0.0, lo=-1000.0, hi=1000.0),
            _cv_in("end", "End", default=1.0, lo=-1000.0, hi=1000.0),
            _cv_in("duration_ms", "Duration ms", default=1000.0,
                   lo=1.0, hi=60000.0, unit="ms"),
        ],
        outputs=[_rune_out("rune_out", "Float Out")],
    )


def make_norns_pipe() -> Module:
    """Norns.Pipe — Message-Delay-Line (PD: ``pipe``).

    Phase 3.3 der Norns-Familie. Speichert eingehende Messages in
    einer Queue und gibt sie nach ``delay_ms`` Millisekunden weiter.
    Sample-genau: jede Message merkt sich ihren absoluten Release-
    Sample (basierend auf eingehendem ts), wird emittiert wenn das
    aktuelle Block-Fenster ihn enthält.

    Inputs:
        rune_in  (RUNE) — eingehende Messages (alle werden delayed)
        delay_ms (CV)   — Delay-Zeit in ms (default 100.0)

    Outputs:
        rune_out (RUNE) — verzögerte Messages mit ts korrigiert auf
                          die Position innerhalb des Output-Blocks

    Verhalten: Queue-basiert (FIFO), unbegrenzt (in Praxis kommen
    selten viele simultane Messages — typische Rune-Streams sind
    sparse). Jede Message bekommt einen absoluten Release-Sample
    zugeordnet:

        release_sample = current_sample_counter + msg["ts"] + delay_samples

    Pro Block werden alle Messages emittiert deren Release-Sample im
    aktuellen Block-Fenster liegt. ts wird auf relative Position
    innerhalb des Output-Blocks korrigiert.

    Use-Case: Echo-Sequenzen — ``Vör.Bang → Norns.Pipe(200ms) →
    Vör.RuneTap``: jeder Bang erscheint 200ms später am Tap. Mit
    mehreren Pipes hintereinander (oder einer Loop über Mimir-Buffer):
    Echo-Trains.

    Vergleich Norns.Pipe vs Norns.Delay:
      * Pipe: Queue, ALLE Messages werden delayed (FIFO)
      * Delay: Single-Slot, neue Message überschreibt pending
        (last-wins, PD-Style ``delay``)
    """
    return Module(
        god="Norns",
        kind="Pipe",
        params={"delay_ms": 100.0},
        inputs=[
            _rune_in("rune_in", "Rune In"),
            _cv_in("delay_ms", "Delay ms", default=100.0,
                   lo=0.0, hi=10000.0, unit="ms"),
        ],
        outputs=[_rune_out("rune_out", "Rune Out")],
    )


def make_norns_delay() -> Module:
    """Norns.Delay — Single-Shot-Message-Delay (PD: ``delay``).

    Phase 3.4 der Norns-Familie. Single-Slot-Variante von Pipe: nur
    EINE Message kann gleichzeitig pending sein. Neue eingehende
    Messages überschreiben die pending (last-wins). PD-konform —
    PD's ``delay`` macht es genauso.

    Inputs:
        rune_in  (RUNE) — eingehende Messages (last-wins)
        delay_ms (CV)   — Delay-Zeit in ms (default 100.0)

    Outputs:
        rune_out (RUNE) — die letzte pending Message, emittiert nach
                          delay_ms

    Use-Case: One-Shot-Trigger — ``Frigg.Bang → Norns.Delay(500ms) →
    Bragi.SineOsc.gain``: 500ms nach dem Klick wird der Sine-Volume
    auf 1.0 gepulsed. Mehrfach klicken vor Ablauf der 500ms: nur
    der letzte Klick zählt (typisches Single-Shot-Verhalten gegen
    Doppel-Klicks).

    NICHTS-KAPUTT: state["pending_release"] = None bei start (kein
    Init-Delay-Bang). Wenn keine Messages eingegangen sind, bleibt
    der Output leer.
    """
    return Module(
        god="Norns",
        kind="Delay",
        params={"delay_ms": 100.0},
        inputs=[
            _rune_in("rune_in", "Rune In"),
            _cv_in("delay_ms", "Delay ms", default=100.0,
                   lo=0.0, hi=10000.0, unit="ms"),
        ],
        outputs=[_rune_out("rune_out", "Rune Out")],
    )


# ─── v0.0.21.224 — Rune-Realm Phase 2.6 (Vör.RouteV + Vör.SelectV PD-Style) ──


def make_voer_route_v() -> Module:
    """Vör.RouteV — PD-style Route by Value (multi-match value-router).

    Anno-Direktive (2026-05-04, mit PD-Screenshot-Vergleich):
    „bei uns bekommt route und select keine inputs oder outputs wir
    brauchen was wo wir das eintragen können". PD's ``route 0 1 2 3``
    hat 4 Match-Args + 4 numerische Outlets + 1 unmatched. Vör.RouteV
    bildet das nach mit 4 Float-Params + 4 Outputs + 1 else_out.

    Inputs:
        rune_in (RUNE) — eingehende Messages (bevorzugt Float/Int)

    Outputs:
        out_0, out_1, out_2, out_3 (RUNE) — Match-Outputs für die
            vier Match-Float-Slots
        else_out (RUNE) — unmatched Messages (kein Match oder
            kein Float/Int)

    Params:
        match_0..match_3 (Float, default 0.0/1.0/2.0/3.0) —
        die Werte gegen die gematcht wird, mit ε=1e-6 Toleranz für
        Float-Vergleich.

    Verhalten:
      * Float oder Int Message kommt rein → Wert wird gegen alle
        4 Match-Slots verglichen (in Reihenfolge match_0, match_1,
        match_2, match_3). Erster Treffer gewinnt — Message wird
        an entsprechenden out_N emittiert (mit ts preserved).
      * Kein Treffer (oder kind=bang/symbol/list) → else_out.
      * Mehrere eingehende Messages pro Block: jede wird einzeln
        geroutet, Reihenfolge erhalten.

    Unterschied zu Vör.Route (existing):
      * Vör.Route splittet **by kind** (bang/float-int/symbol-list/else)
      * Vör.RouteV splittet **by value** (PD-style, numerisch)
      * Beide existieren parallel — User wählt was passt.

    Properties-Panel-Eingabe v.224: 4 Float-Knobs match_0..match_3.
    Spätere bahnbrechende UI: „Living Patterns" — Modul lernt aus
    Daten + Click-to-add (siehe PROJECT_DOCS/architecture/
    LIVING_PATTERNS_SPEC.md, geplant v.227+).

    NICHTS-KAPUTT: rein additiv. Vör.Route bleibt unverändert.

    v0.0.21.229: ``dynamic_outputs=True`` — Renderer trackt eingehende
    Werte in ``observed_tags["rune_in"]``. Living Patterns UI (v.230+)
    nutzt das für die Click-to-promote-Funktion.
    """
    return Module(
        god="Vör",
        kind="RouteV",
        params={
            "match_0": 0.0,
            "match_1": 1.0,
            "match_2": 2.0,
            "match_3": 3.0,
        },
        inputs=[_rune_in("rune_in", "Rune In")],
        outputs=[
            _rune_out("out_0", "Out 0"),
            _rune_out("out_1", "Out 1"),
            _rune_out("out_2", "Out 2"),
            _rune_out("out_3", "Out 3"),
            _rune_out("else_out", "Else"),
        ],
        dynamic_outputs=True,
    )


def make_voer_select_v() -> Module:
    """Vör.SelectV — PD-style Select by Value (multi-match logic gate).

    PD's ``select 0 1 2 3`` Pendant. Im Gegensatz zu RouteV emittiert
    SelectV einen reinen **Bang** am Match-Output (nicht die original
    Message) — typischer „if-this-value-then-trigger"-Use-Case.

    Inputs:
        rune_in (RUNE) — eingehende Messages

    Outputs:
        match_0..match_3 (RUNE) — Bang-Output bei Match
            (``{"kind": "bang", "ts": <preserved>}``)
        miss_out (RUNE) — Bang-Output bei kein Match

    Params: identisch zu RouteV (match_0..match_3 als Floats).

    Use-Case-Differenz:
      * Vör.RouteV: „leite Float-Wert 1.0 weiter zu Output X"
        → Message-Routing (durchreichen)
      * Vör.SelectV: „wenn Float-Wert == 1.0, feuere Bang an
        Output X" → Trigger-Generation (kein Wert-Pass)

    Beispiel-Pipeline:
        Vör.Bang → Vör.Float(value=2.0) → Vör.SelectV (match_2=2.0)
        → match_2-Output → Bragi.SineOsc.gain (via Forward-Pulse-
        Bridge): nur wenn ein Float mit Wert 2.0 reinkommt, wird
        Sine-Volume gepulsed.

    NICHTS-KAPUTT: rein additiv. Vör.Select (single-match) bleibt
    unverändert.

    v0.0.21.229: ``dynamic_outputs=True`` analog zu RouteV.
    """
    return Module(
        god="Vör",
        kind="SelectV",
        params={
            "match_0": 0.0,
            "match_1": 1.0,
            "match_2": 2.0,
            "match_3": 3.0,
        },
        inputs=[_rune_in("rune_in", "Rune In")],
        outputs=[
            _rune_out("match_0", "Match 0"),
            _rune_out("match_1", "Match 1"),
            _rune_out("match_2", "Match 2"),
            _rune_out("match_3", "Match 3"),
            _rune_out("miss_out", "Miss"),
        ],
        dynamic_outputs=True,
    )


# ─── v0.0.21.225-227 — Rune-Realm Phase 4 (Ullr-Familie: Math/Expr) ──


def _ullr_binary(kind: str, b_default: float = 0.0) -> Module:
    """Helper für die binären Ullr-Module (Plus, Minus, Times, Divide).

    Pattern: rune_in (RUNE) trigger + value, a/b CV-Inputs für die
    Operanden. Pro eingehender Float/Int-Message am rune_in:
    - msg.value ist ``a`` (oder a-CV-Input falls msg.value=None)
    - b kommt aus b-CV-Input oder b-Param
    - emit {"kind": "float", "value": a OP b, "ts": preserved}

    PD-konform: PD's ``+ 60`` triggers on float-input, b kommt vom
    right-inlet oder Args.

    v0.0.21.247: Additive Erweiterung um audio_in_a/audio_in_b/audio_out
    für Audio/CV-Sample-für-Sample-Math in der Rust-Engine. User können
    jetzt entweder den klassischen rune-Pfad nutzen (Live-Preview, Python-
    eval) ODER die neuen audio-Ports anschließen (Track-Bounce, Rust-DSP).
    Die rune-Pfade bleiben unverändert (NICHTS-KAPUTT).
    """
    return Module(
        god="Ullr",
        kind=kind,
        params={"a": 0.0, "b": b_default},
        inputs=[
            _rune_in("rune_in", "Rune In"),
            _cv_in("a", "A", default=0.0, lo=-100000.0, hi=100000.0),
            _cv_in("b", "B", default=b_default, lo=-100000.0, hi=100000.0),
            # v.247: Audio-Ports für Rust-DSP-Pfad
            _audio_in("audio_in_a", "Audio A"),
            _audio_in("audio_in_b", "Audio B"),
        ],
        outputs=[
            _rune_out("rune_out", "Rune Out"),
            # v.247: Audio-Out für Rust-DSP-Pfad
            _audio_out("audio_out", "Audio Out"),
        ],
    )


def make_ullr_plus() -> Module:
    """Ullr.Plus — a + b. PD's ``+ 60``."""
    return _ullr_binary("Plus", b_default=0.0)


def make_ullr_minus() -> Module:
    """Ullr.Minus — a - b. PD's ``- 1``."""
    return _ullr_binary("Minus", b_default=0.0)


def make_ullr_times() -> Module:
    """Ullr.Times — a * b. PD's ``* 2``."""
    return _ullr_binary("Times", b_default=1.0)


def make_ullr_divide() -> Module:
    """Ullr.Divide — a / b. PD's ``/ 100``. Division durch 0 → 0."""
    return _ullr_binary("Divide", b_default=1.0)


def make_ullr_clip() -> Module:
    """Ullr.Clip — clamp value to [lo, hi]. PD's ``clip``.

    Inputs: rune_in (RUNE), lo/hi (CV)
    Output: rune_out (Float, geclampt)
    """
    return Module(
        god="Ullr",
        kind="Clip",
        params={"lo": 0.0, "hi": 1.0},
        inputs=[
            _rune_in("rune_in", "Rune In"),
            _cv_in("lo", "Low", default=0.0, lo=-100000.0, hi=100000.0),
            _cv_in("hi", "High", default=1.0, lo=-100000.0, hi=100000.0),
        ],
        outputs=[_rune_out("rune_out", "Rune Out")],
    )


def make_ullr_abs() -> Module:
    """Ullr.Abs — |x|. Reines Unary.

    v0.0.21.247: Additive Erweiterung um audio_in/audio_out für
    Audio-DSP-Pfad (Vollwellen-Gleichrichter in Rust). Rune-Pfad
    bleibt für Live-Preview erhalten.
    """
    return Module(
        god="Ullr",
        kind="Abs",
        params={},
        inputs=[
            _rune_in("rune_in", "Rune In"),
            # v.247: Audio-In für Rust-DSP-Pfad
            _audio_in("audio_in", "Audio In"),
        ],
        outputs=[
            _rune_out("rune_out", "Rune Out"),
            # v.247: Audio-Out für Rust-DSP-Pfad
            _audio_out("audio_out", "Audio Out"),
        ],
    )


def make_ullr_min() -> Module:
    """Ullr.Min — min(a, b). PD's ``min``."""
    return _ullr_binary("Min", b_default=0.0)


def make_ullr_max() -> Module:
    """Ullr.Max — max(a, b). PD's ``max``."""
    return _ullr_binary("Max", b_default=1.0)


def make_ullr_random() -> Module:
    """Ullr.Random — random integer 0..max-1. PD's ``random 4``.

    Inputs: trigger (RUNE), max_value (CV, default 4)
    Output: rune_out (RUNE) — Int-Messages

    Pro Trigger wird ein neuer pseudozufälliger Int 0..max-1
    emittiert (mit ts preserved).
    """
    return Module(
        god="Ullr",
        kind="Random",
        params={"max_value": 4.0},
        inputs=[
            _rune_in("trigger", "Trigger"),
            _cv_in("max_value", "Max", default=4.0, lo=2.0, hi=100000.0),
        ],
        outputs=[_rune_out("rune_out", "Random Int")],
    )


def make_ullr_expr() -> Module:
    """Ullr.Expr — Expression-Evaluator. PD's ``expr``.

    Im Properties-Panel kann der User einen Ausdruck eingeben
    (default: ``a + b``). Variablen: a, b, c (CV-Inputs), x (vom
    rune_in.value). Verfügbare Funktionen: abs, min, max, round,
    pow, math.* (sin, cos, log, exp, sqrt, ...).

    Inputs:
        rune_in (RUNE) — trigger; msg.value ist ``x``
        a, b, c (CV) — Variablen
    Outputs:
        rune_out (RUNE) — Float-Result

    Sicherheit: eval mit ``__builtins__: {}`` und kuratiertem
    namespace. Keine Imports, keine Filesystem-Zugriffe möglich.
    Auf Parser-Error wird die Message stillschweigend übersprungen.

    Limitation v.227: ``expr`` ist ein String-Param und wird nicht
    in Properties-Panel-Knobs gerendert. User muss patch-JSON
    direkt bearbeiten ODER eine UI-Erweiterung warten. Workaround:
    Kombination aus Plus/Times/etc. erlaubt jeden Ausdruck.
    """
    return Module(
        god="Ullr",
        kind="Expr",
        params={"expr": "a + b", "a": 0.0, "b": 0.0, "c": 0.0},
        inputs=[
            _rune_in("rune_in", "Rune In"),
            _cv_in("a", "A", default=0.0, lo=-100000.0, hi=100000.0),
            _cv_in("b", "B", default=0.0, lo=-100000.0, hi=100000.0),
            _cv_in("c", "C", default=0.0, lo=-100000.0, hi=100000.0),
        ],
        outputs=[_rune_out("rune_out", "Rune Out")],
    )


# ─── v0.0.21.247 — Rune-Realm Audio-Math-Erweiterung (Anno's v.247-Liste) ──
#
# 5 NEUE Audio-only-Math-Module die in Rust voll implementiert sind.
# Im Gegensatz zu den älteren rune-event-driven Plus/Minus/Times/Divide/
# Abs (die in v.247 zusätzlich audio-Ports bekommen haben) sind
# Sqrt/Pow/Log/Exp/Negate von vornherein als Audio/CV-Sample-für-Sample
# konzipiert. Anwendung: Curve-Shaping, Envelope-Compression, Phase-
# Invertierung im Rust-DSP-Pfad.


def make_ullr_sqrt() -> Module:
    """Ullr.Sqrt — sign(x) * sqrt(|x|). Symmetrische Wurzel.

    Anwendung: Audio-Curve-Shaping mit sanfter Sublinear-Kompression.
    Bei x > 0 ist Output schwächer als Input (1.0 → 1.0, 0.5 → 0.707,
    0.25 → 0.5). Symmetrisch für negative Inputs. Kein NaN durch
    sign-handling.
    """
    return Module(
        god="Ullr",
        kind="Sqrt",
        params={},
        inputs=[_audio_in("audio_in", "Audio In")],
        outputs=[_audio_out("audio_out", "Audio Out")],
    )


def make_ullr_pow() -> Module:
    """Ullr.Pow — sign(a) * |a|.powf(b). Exponentielle Curve-Shaping.

    Inputs:
        audio_in_a (Audio) — Basis
        audio_in_b (CV/Audio) — Exponent (oder b-Param als Fallback)
    Output:
        audio_out (Audio) — Result

    Anwendung: b=2.0 → quadratische Compression-Curve, b=0.5 → sqrt.
    b=1.0 → identity (Default). Negative b gehen auch (1/x-Verhalten).
    """
    return Module(
        god="Ullr",
        kind="Pow",
        params={"b": 1.0},
        inputs=[
            _audio_in("audio_in_a", "Audio A (Basis)"),
            _audio_in("audio_in_b", "Audio B (Exponent)"),
            _cv_in("b", "B (Exp)", default=1.0, lo=-10.0, hi=10.0),
        ],
        outputs=[_audio_out("audio_out", "Audio Out")],
    )


def make_ullr_log() -> Module:
    """Ullr.Log — sign(x) * ln(1 + |x|). Soft Log-Compression.

    Anwendung: Soft-Knee-Compression-Curve. Inverse zu Ullr.Exp.
    Symmetrisch, kein -∞ bei x=0, da log(1)=0.
    Beispiel: x=1.0 → ~0.693, x=2.0 → ~1.099, x=10 → ~2.398.
    """
    return Module(
        god="Ullr",
        kind="Log",
        params={},
        inputs=[_audio_in("audio_in", "Audio In")],
        outputs=[_audio_out("audio_out", "Audio Out")],
    )


def make_ullr_exp() -> Module:
    """Ullr.Exp — sign(x) * (exp(|x|) - 1). Soft Exp-Expansion.

    Anwendung: Inverse zu Ullr.Log. Audio-Expansion mit Anti-Overflow-
    Clamp bei |x|>20. Geeignet für Modulator-Verstärkung mit kontrol-
    liertem Maximum.
    """
    return Module(
        god="Ullr",
        kind="Exp",
        params={},
        inputs=[_audio_in("audio_in", "Audio In")],
        outputs=[_audio_out("audio_out", "Audio Out")],
    )


def make_ullr_negate() -> Module:
    """Ullr.Negate — -x. Phasen-Invertierung.

    Anwendung: Polaritätsumkehr des Signals. Häufig bei Mid/Side-
    Modulation oder Differenz-Mischung. Eingang Mono/Stereo wird
    sample-für-sample negiert.
    """
    return Module(
        god="Ullr",
        kind="Negate",
        params={},
        inputs=[_audio_in("audio_in", "Audio In")],
        outputs=[_audio_out("audio_out", "Audio Out")],
    )


# ─── v0.0.21.227 — Rune-Realm Phase 5 Foundation (Ratatosk: Mtof + Ftom) ──


def make_ratatosk_mtof() -> Module:
    """Ratatosk.Mtof — MIDI-Note-Number → Frequenz Hz. PD's ``mtof``.

    Formel: ``freq = 440.0 * 2.0 ** ((note - 69) / 12)``
    Note 69 (A4) = 440 Hz, Note 60 (C4) = ~261.63 Hz.

    Inputs:
        rune_in (RUNE) — Float/Int-Message mit MIDI-Note (0..127 typ.)
    Outputs:
        rune_out (RUNE) — Float-Message mit Frequenz in Hz

    Anwendung: Vör.Int(60) → Mtof → Bragi.SineOsc.frequency
    (über die Forward-Pulse-Bridge wird's auf 1.0 reduziert — für
    echte Frequenz-Modulation braucht's Ratatosk.RuneToStream in
    Phase 5 v.228+; mtof ist hier zur PD-Patch-Kompatibilität).
    """
    return Module(
        god="Ratatosk",
        kind="Mtof",
        params={},
        inputs=[_rune_in("rune_in", "Rune In")],
        outputs=[_rune_out("rune_out", "Freq Hz")],
    )


def make_ratatosk_ftom() -> Module:
    """Ratatosk.Ftom — Frequenz Hz → MIDI-Note-Number. PD's ``ftom``.

    Formel: ``note = 69 + 12 * log2(freq / 440.0)``
    440 Hz = Note 69, 261.63 Hz = ~Note 60.
    Resultat ist Float (kann fractional sein für Mikrotöne).

    Edge-Case: freq <= 0 → Note 0 (statt -inf log2).
    """
    return Module(
        god="Ratatosk",
        kind="Ftom",
        params={},
        inputs=[_rune_in("rune_in", "Rune In")],
        outputs=[_rune_out("rune_out", "MIDI Note")],
    )


# ─── v0.0.21.228 — Phase 6 Rune-Realm: Hermod-Familie (Network/OSC) ──


def make_hermod_osc_receive() -> Module:
    """Hermod.OscReceive — UDP/OSC-Listener auf konfigurierbarem Port.

    PD-Pendant: ``netreceive -u -b`` + ``oscparse``. Lauscht auf einem
    UDP-Port (default 9000), parsiert eingehende Pakete als OSC 1.0
    Messages, emittiert sie als RUNE-list-Messages am rune_out.

    Inputs:
        port (CV) — UDP-Port (default 9000, range 1024-65535)

    Outputs:
        rune_out (RUNE) — eine list-Message pro empfangenem OSC-Paket
            mit Format ``{"kind": "list", "value": [path, *args],
            "ts": 0}``

    Verhalten:
      * Port wird beim ersten _process_module geöffnet (non-blocking
        UDP-Socket auf 0.0.0.0).
      * Pro Audio-Block: socket.recv-Loop (non-blocking), alle
        Messages parsen, in outputs sammeln.
      * Auf Bind-Error (Port belegt) wird das Modul silent — sonst
        würde das ganze audio_preview crashen.

    Limitation v.228:
      * Port-Wechsel wird nicht live übernommen. User muss patch
        neu laden.
      * Kein OSC-Bundle-Support (#bundle) — kommt in Phase 6.5.
      * Sockets werden nicht aktiv geschlossen — bei Patch-Stop ist
        das ein leak. Mini-Refactor-Ticket.

    Beispiel: Externes Tool sendet `/synth/freq 440.0` an UDP-Port
    9000 → Modul emittiert ``{"kind":"list","value":["/synth/freq",
    440.0],"ts":0}``. Konsument: ``Hermod.OscPath`` zum Filtern.
    """
    return Module(
        god="Hermod",
        kind="OscReceive",
        params={"port": 9000.0},
        inputs=[
            _cv_in("port", "Port", default=9000.0, lo=1024.0, hi=65535.0),
        ],
        outputs=[_rune_out("rune_out", "OSC Out")],
    )


def make_hermod_osc_send() -> Module:
    """Hermod.OscSend — sendet RUNE-list-Messages als OSC über UDP.

    Eingehende list-Messages werden als OSC-1.0-Packets encodiert und
    an host:port geschickt. Erste Listen-Element ist der Path, Rest
    die Args.

    Inputs:
        rune_in (RUNE) — list-Messages (oder einzelne float/int — die
            werden mit Default-Path versehen)
        port (CV) — Ziel-UDP-Port (default 8000)

    Outputs:
        sent_count (RUNE) — bang pro erfolgreich gesendeter Message
            (für UI-Counter / Debug)

    Params:
        host (string, default "127.0.0.1")
        default_path (string, default "/flux") — wenn rune_in keine
            list-Message ist, wird dieser Path benutzt

    Limitation v.228:
        host-String und default_path-String sind via params editierbar
        (Properties-Panel hat aber nur Float-Spinboxes). Workaround:
        JSON editieren oder Default-Werte verwenden.
    """
    return Module(
        god="Hermod",
        kind="OscSend",
        params={
            "port": 8000.0,
            "host": "127.0.0.1",
            "default_path": "/flux",
        },
        inputs=[
            _rune_in("rune_in", "OSC In"),
            _cv_in("port", "Port", default=8000.0, lo=1024.0, hi=65535.0),
        ],
        outputs=[_rune_out("sent_count", "Sent Bang")],
    )


def make_hermod_osc_path() -> Module:
    """Hermod.OscPath — filtert OSC-list-Messages nach Path.

    Pendant zu PD's `routeOSC`. Eingehende list-Messages werden auf
    den Path geprüft (erstes Listen-Element). Bei Match wird die
    Message am match_out emittiert (ohne den Path — nur die args
    bleiben als Float/Int/String). Bei kein Match → miss_out (mit
    full Original-list).

    Params:
        path_pattern (string, default "/flux/*") — Glob-Pattern
            (* = wildcard, /a/* matched /a/b und /a/x)

    Limitation v.228: path_pattern als String-Param ist nicht im
    Properties-Panel editierbar. JSON-Edit.

    Inputs:
        rune_in (RUNE)

    Outputs:
        match_out (RUNE) — Args ohne Path bei Match
        miss_out (RUNE) — Original-list bei kein Match
    """
    return Module(
        god="Hermod",
        kind="OscPath",
        params={"path_pattern": "/flux/*"},
        inputs=[_rune_in("rune_in", "OSC In")],
        outputs=[
            _rune_out("match_out", "Match"),
            _rune_out("miss_out", "Miss"),
        ],
    )


def make_hermod_osc_print() -> Module:
    """Hermod.OscPrint — Debug-Print eingehender RUNE-Messages.

    Pendant zu PD's ``print``. Loggt alle eingehenden Messages an
    Python-Logger (level=INFO). Reicht alle Messages durch zum
    rune_out (für In-Line-Debugging in Pipelines).

    Inputs:
        rune_in (RUNE)
    Outputs:
        rune_out (RUNE) — durchgereicht (passthrough)

    Verwendung: zwischen zwei Modulen einfügen um zu sehen was
    fließt. ``Hermod.OscReceive → Hermod.OscPrint → Vör.RuneTap``
    zeigt im Log was reinkommt.
    """
    return Module(
        god="Hermod",
        kind="OscPrint",
        params={"prefix": "[OSC]"},
        inputs=[_rune_in("rune_in", "Rune In")],
        outputs=[_rune_out("rune_out", "Rune Out")],
    )


# ─── Registry ─────────────────────────────────────────────────────

# Mapping (god, kind) → Factory-Funktion.  Wer ein neues Modul
# anlegt, registriert es hier.  Die GUI-Palette nutzt diese
# Registry zur Anzeige der verfügbaren Module.

ModuleFactory = Callable[[], Module]

# ─── v0.0.21.232 — Anno-Auftrag „gain knob, peak limiter, sampler, ───
# pulse/sub/swarm/wavetable oscillators" ─────────────────────────────


def make_vidar_gain() -> Module:
    """Vidar.Gain — Universal-Gain-Modul (Lautstärke-Regler).

    Anno-Direktive (v.232): „ich brauch ein gain knob modul der
    lautstärke kann". Ein simpler aber unverzichtbarer Audio-
    Multiplizierer. Audio fließt rein, wird mit ``gain`` skaliert,
    fließt raus.

    Inputs:
        audio_in (AUDIO)
        gain     (CV) — Multiplikator [0..2], 1.0 = Unity, 2.0 = +6dB
    Outputs:
        audio_out (AUDIO)

    Tipp gegen „Sound formt sich nicht": Vidar.Gain als Bridge zwischen
    LFO-Output und Audio-Input nutzen. LFO ±1 → Vidar.Gain.gain → audio
    sweep zwischen stumm und doppelt-laut.
    """
    return Module(
        god="Vidar",
        kind="Gain",
        params={"gain": 1.0},
        inputs=[
            _audio_in(),
            _cv_in("gain", "Gain", default=1.0, lo=0.0, hi=2.0),
        ],
        outputs=[_audio_out()],
    )


def make_vidar_peak_limiter() -> Module:
    """Vidar.PeakLimiter — Peak-Limiter mit Sidechain-CV-Outputs.

    Unterschied zu Vidar.Limiter: PeakLimiter exponiert die interne
    Hüllkurve und Gain-Reduction als CV-Outputs — damit lassen sich
    andere Module (z.B. Filter-Cutoff, andere Gain-Stages) ducken
    oder zu rhythmus-synchronisieren.

    Inputs:
        audio_in   (AUDIO)
        threshold  (CV)   — Peak-Threshold [-30..0 dB], default -3
        release_ms (CV)   — Release-Zeit   [1..1000 ms], default 100
        sidechain  (CV)   — externe Hüllkurve (optional; wenn nicht
                           verbunden wird audio_in selbst genutzt)
    Outputs:
        audio_out (AUDIO) — limited Signal
        gr_out    (CV)    — Gain-Reduction in linearem [0..1] (1=keine
                           Reduktion, 0=stumm). Nützlich als Sidechain-
                           Quelle: invert mit Ullr.Minus(1, gr_out) für
                           Pumpe-Effekt auf einen anderen Bus.
        env_out   (CV)    — Envelope-Follower-Output [0..1] des Eingangs

    Anno-Use-Case (v.232): „mit der möglichkeit zu allen modulen zu
    steuern" — gr_out via Connection.scale auf Filter-Cutoff legen
    macht ducking-filter; env_out kann andere LFOs synchronisieren.
    """
    return Module(
        god="Vidar",
        kind="PeakLimiter",
        params={"threshold": -3.0, "release_ms": 100.0,
                "env": 0.0, "gr": 1.0},
        inputs=[
            _audio_in(),
            _cv_in("threshold",  "Threshold", default=-3.0,  lo=-30.0, hi=0.0,    unit="dB"),
            _cv_in("release_ms", "Release",   default=100.0, lo=1.0,   hi=1000.0, unit="ms"),
            _cv_in("sidechain",  "Sidechain", default=0.0,   lo=0.0,   hi=2.0),
        ],
        outputs=[
            _audio_out(),
            Port("gr_out",  PortKind.CV, PortDirection.OUTPUT, "GR Out",
                 default=1.0, minimum=0.0, maximum=1.0),
            Port("env_out", PortKind.CV, PortDirection.OUTPUT, "Env Out",
                 default=0.0, minimum=0.0, maximum=2.0),
        ],
    )


def make_bragi_pulse_osc() -> Module:
    """Bragi.PulseOsc — Pulse-Oscillator mit variabler Pulsweite (PWM).

    Anders als Bragi.SquareOsc (50% fix): hier ist die Pulsweite
    parametrisch und CV-modulierbar. Setze ``pulse_width=0.5`` und
    moduliere mit einem LFO für klassische PWM-Strings.

    Inputs:
        freq        (CV) — Frequenz [20..20000 Hz]
        gain        (CV) — Lautstärke [0..1]
        pulse_width (CV) — Duty-Cycle [0.05..0.95], 0.5 = Square
    Outputs:
        audio_out (AUDIO)
    """
    return Module(
        god="Bragi",
        kind="PulseOsc",
        params={"freq": 220.0, "gain": 0.5, "pulse_width": 0.5},
        inputs=[
            _cv_in("freq",        "Frequency",   default=220.0, lo=20.0, hi=20000.0, unit="Hz"),
            _cv_in("gain",        "Gain",        default=0.5,   lo=0.0,  hi=1.0),
            _cv_in("pulse_width", "Pulse Width", default=0.5,   lo=0.05, hi=0.95),
        ],
        outputs=[_audio_out()],
    )


def make_bragi_sub_osc() -> Module:
    """Bragi.SubOsc — Sub-Oktave-Oszillator (Sinus, eine Oktave runter).

    Folgt einer Eingangs-Frequenz aber halbiert sie. Klassischer
    Bass-Boost: parallel zu einem normalen SineOsc legen für tiefes
    Fundament. Bei freq=440 produziert SubOsc 220 Hz.

    Inputs:
        freq      (CV) — Eingangs-Frequenz [20..20000 Hz] (wird intern halbiert)
        gain      (CV) — Lautstärke [0..1]
        octaves   (CV) — Oktaven runter [1..3], default 1 (d.h. /2)
    Outputs:
        audio_out (AUDIO)

    Tipp: Mit Bragi.SineOsc.freq an SubOsc.freq verbinden — beide
    bekommen dieselbe Note, SubOsc spielt Oktave drunter.
    """
    return Module(
        god="Bragi",
        kind="SubOsc",
        params={"freq": 220.0, "gain": 0.5, "octaves": 1.0},
        inputs=[
            _cv_in("freq",    "Frequency", default=220.0, lo=20.0, hi=20000.0, unit="Hz"),
            _cv_in("gain",    "Gain",      default=0.5,   lo=0.0,  hi=1.0),
            _cv_in("octaves", "Octaves",   default=1.0,   lo=1.0,  hi=3.0),
        ],
        outputs=[_audio_out()],
    )


def make_bragi_swarm_osc() -> Module:
    """Bragi.SwarmOsc — 7-Voice-Supersaw mit Detune und Stereo-Spread.

    Klassischer JP-8000-Style Supersaw — 7 detunete Sägezahn-Voices
    addiert ergibt den fetten Trance-/Hyperpop-Sound. ``detune`` (in
    Cents) spreizt die Voices um die Mittenfrequenz; ``mix`` regelt
    das Verhältnis Center-Voice zu den 6 Side-Voices.

    Inputs:
        freq    (CV) — Mitten-Frequenz [20..20000 Hz]
        gain    (CV) — Lautstärke [0..1]
        detune  (CV) — Spread in Cents [0..50], 0=alle gleich
        mix     (CV) — Side-Voices-Mix [0..1], 0.5 = balanciert
    Outputs:
        audio_out (AUDIO)

    NICHTS-KAPUTT: Mono-Output (kein Stereo-Spread für jetzt — V2
    könnte L/R-Voice-Splitting machen).
    """
    return Module(
        god="Bragi",
        kind="SwarmOsc",
        params={"freq": 220.0, "gain": 0.5, "detune": 15.0, "mix": 0.5},
        inputs=[
            _cv_in("freq",   "Frequency", default=220.0, lo=20.0, hi=20000.0, unit="Hz"),
            _cv_in("gain",   "Gain",      default=0.5,   lo=0.0,  hi=1.0),
            _cv_in("detune", "Detune",    default=15.0,  lo=0.0,  hi=50.0,    unit="ct"),
            _cv_in("mix",    "Mix",       default=0.5,   lo=0.0,  hi=1.0),
        ],
        outputs=[_audio_out()],
    )


def make_bragi_union_osc() -> Module:
    """Bragi.UnionOsc — Phase-locked Harmonic-Stack (Bitwig Polymer-Style).

    Anno (v.233): „union, bite, phase-1, scrawl — das ist bitwig style".

    Bitwig Polymer's Union Oszillator stackt mehrere Sägezähne phase-locked
    auf ganzzahligen Vielfachen der Grundfrequenz. Das ergibt eine harmoni-
    sche Reihe (organähnlich/brassy) — anders als SwarmOsc (detunet) sind
    die Voices hier sauber im Verhältnis 1:2:3:4:5.

    Inputs:
        freq    (CV) — Grund-Frequenz [20..20000 Hz]
        gain    (CV) — Lautstärke [0..1]
        voices  (CV) — Anzahl Harmonics [1..8], default 4
        rolloff (CV) — Amplituden-Rolloff der höheren Voices [0..1]:
                      0=alle gleich, 1=jede Stufe halbiert
    Outputs:
        audio_out (AUDIO)
    """
    return Module(
        god="Bragi",
        kind="UnionOsc",
        params={"freq": 220.0, "gain": 0.5, "voices": 4.0, "rolloff": 0.5},
        inputs=[
            _cv_in("freq",    "Frequency", default=220.0, lo=20.0, hi=20000.0, unit="Hz"),
            _cv_in("gain",    "Gain",      default=0.5,   lo=0.0,  hi=1.0),
            _cv_in("voices",  "Voices",    default=4.0,   lo=1.0,  hi=8.0),
            _cv_in("rolloff", "Rolloff",   default=0.5,   lo=0.0,  hi=1.0),
        ],
        outputs=[_audio_out()],
    )


def make_bragi_bite_osc() -> Module:
    """Bragi.BiteOsc — Asymmetric-Distortion-Oszillator (Bitwig Polymer-Style).

    Bitwig's „Bite" Oszillator hat einen aggressiven, beißenden Charakter
    durch asymmetrische Verzerrung einer Grundwellenform. Wir implementieren
    das als: Saw → Bias-Offset → tanh-Waveshaping mit variabler Härte.
    Bei bite=0 fast cleaner Saw, bei bite=1 hartes Distorted-Sound mit
    DC-asymmetrie für „biting" character.

    Inputs:
        freq    (CV) — Frequenz [20..20000 Hz]
        gain    (CV) — Lautstärke [0..1]
        bite    (CV) — Distortion-Intensität [0..1]
        bias    (CV) — DC-Asymmetrie [-0.5..0.5]: schiebt das Signal vor
                      der tanh-Wellenformung (mehr „bite" auf einer Seite)
    Outputs:
        audio_out (AUDIO)
    """
    return Module(
        god="Bragi",
        kind="BiteOsc",
        params={"freq": 220.0, "gain": 0.5, "bite": 0.6, "bias": 0.0},
        inputs=[
            _cv_in("freq", "Frequency", default=220.0, lo=20.0, hi=20000.0, unit="Hz"),
            _cv_in("gain", "Gain",      default=0.5,   lo=0.0,  hi=1.0),
            _cv_in("bite", "Bite",      default=0.6,   lo=0.0,  hi=1.0),
            _cv_in("bias", "Bias",      default=0.0,   lo=-0.5, hi=0.5),
        ],
        outputs=[_audio_out()],
    )


def make_bragi_phase1_osc() -> Module:
    """Bragi.Phase1Osc — Phase-Distortion-Oszillator (Bitwig + Casio CZ-101 Style).

    Bitwig Polymer's „Phase-1" ist von Casios CZ-101 Phase-Distortion-
    Synthese inspiriert. Statt der Phase linear zu inkrementieren wird
    sie verzerrt: in der ersten Hälfte des Cycles beschleunigt, in der
    zweiten Hälfte verlangsamt. Das erzeugt harmonisch-resonante Klänge
    die nach analogen Filter-Sweeps klingen — ohne tatsächliches Filter.

    Inputs:
        freq    (CV) — Frequenz [20..20000 Hz]
        gain    (CV) — Lautstärke [0..1]
        shape   (CV) — Phase-Distortion-Stärke [0..1]:
                      0=lineare Phase (cleaner Sinus),
                      0.5=mäßig resonant,
                      1=extrem resonant (beat sound)
    Outputs:
        audio_out (AUDIO)

    Tipp: shape via langsamen LFO modulieren für klassisches CZ-Filter-
    Sweeping ohne Filter-Modul. shape=0.7..0.95 = sweetspot.
    """
    return Module(
        god="Bragi",
        kind="Phase1Osc",
        params={"freq": 220.0, "gain": 0.5, "shape": 0.5},
        inputs=[
            _cv_in("freq",  "Frequency", default=220.0, lo=20.0, hi=20000.0, unit="Hz"),
            _cv_in("gain",  "Gain",      default=0.5,   lo=0.0,  hi=1.0),
            _cv_in("shape", "Shape",     default=0.5,   lo=0.0,  hi=1.0),
        ],
        outputs=[_audio_out()],
    )


def make_bragi_scrawl_osc() -> Module:
    """Bragi.ScrawlOsc — Glitchy/randomized Oszillator (Bitwig-Style).

    Bitwig's „Scrawl" Oszillator hat einen kritzelnd-zufälligen Charakter
    — wie ein Square der von einem zittrigen Stift gezeichnet wurde.
    Implementation: Square mit per-Cycle randomisierter Pulsweite (S&H),
    plus optional Sample-Rate-Reduction via Stair-Step-Quantisierung.
    Das gibt diese „crusher chaos"-Anmutung von chip-tune-Glitch.

    Inputs:
        freq    (CV) — Frequenz [20..20000 Hz]
        gain    (CV) — Lautstärke [0..1]
        chaos   (CV) — Randomisierungs-Intensität [0..1]:
                      0=cleaner Square, 1=stark zerflattert
        crush   (CV) — Bit-Crush-Stärke [0..1]: 0=clean, 1=8-bit-stair
    Outputs:
        audio_out (AUDIO)
    """
    return Module(
        god="Bragi",
        kind="ScrawlOsc",
        params={"freq": 220.0, "gain": 0.5, "chaos": 0.5, "crush": 0.0,
                "seed": 12345.0},
        inputs=[
            _cv_in("freq",  "Frequency", default=220.0, lo=20.0, hi=20000.0, unit="Hz"),
            _cv_in("gain",  "Gain",      default=0.5,   lo=0.0,  hi=1.0),
            _cv_in("chaos", "Chaos",     default=0.5,   lo=0.0,  hi=1.0),
            _cv_in("crush", "Crush",     default=0.0,   lo=0.0,  hi=1.0),
        ],
        outputs=[_audio_out()],
    )


def make_bragi_wavetable_osc() -> Module:
    """Bragi.WavetableOsc — Wavetable-Oszillator mit 8 morphbaren Tables.

    8 fest gespeicherte Single-Cycle-Wellenformen werden zwischen-
    einander interpoliert basierend auf ``position`` [0..1]:
        0/8: Sine, 1/8: Triangle, 2/8: Saw, 3/8: Square,
        4/8: Soft-Saw (gerundet), 5/8: PWM-Stack, 6/8: harm. Mix,
        7/8: Noise-Pulse.

    Position kann via LFO/Envelope moduliert werden für klassische
    Wavetable-Sweeps. Im Gegensatz zu echten Wavetable-Synths (mit
    user-loadable .wav Tables) sind hier die Tables fix — zukünftige
    Versionen könnten file_path-Loading bekommen.

    Inputs:
        freq     (CV) — Frequenz [20..20000 Hz]
        gain     (CV) — Lautstärke [0..1]
        position (CV) — Wavetable-Position [0..1]
    Outputs:
        audio_out (AUDIO)
    """
    return Module(
        god="Bragi",
        kind="WavetableOsc",
        params={"freq": 220.0, "gain": 0.5, "position": 0.0},
        inputs=[
            _cv_in("freq",     "Frequency", default=220.0, lo=20.0, hi=20000.0, unit="Hz"),
            _cv_in("gain",     "Gain",      default=0.5,   lo=0.0,  hi=1.0),
            _cv_in("position", "Position",  default=0.0,   lo=0.0,  hi=1.0),
        ],
        outputs=[_audio_out()],
    )


def make_zerberus_sampler() -> Module:
    """Zerberus.Sampler — Multi-Format-Sampler mit Gate + Pitch-CV.

    Anno-Direktive (v.232/v.233): „es fehlt noch immer ein sampler wo ich
    alle formate laden kann [...] muss mp3 mp4 usw können".

    Lädt **beliebige** Audio-tragende Formate via 2-stufigem Loader:

    * **soundfile (libsndfile)** für die nativen Formate (schnell, kein
      Subprocess): WAV, FLAC, OGG, AIFF, AU, W64
    * **ffmpeg-Subprocess** als Fallback für MP3, MP4, M4A, AAC, OPUS,
      WMA, MOV, MKV, WebM und alles andere was ffmpeg dekodieren kann

    Bei jedem Gate-Trigger startet die Wiedergabe von Anfang. ``pitch_cv``
    transponiert in Halbtonschritten relativ zu ``base_note`` (default 60 = C4).

    Inputs:
        gate     (RUNE) — Trigger-Bang startet Sample-Wiedergabe von
                          Anfang
        pitch_cv (CV)   — Transposition in Halbtönen [-24..+24]
        gain     (CV)   — Volumen-Multiplikator [0..2]
    Outputs:
        audio_out (AUDIO) — Mono-Ausgabe (Stereo-Files werden gemischt)
        pitch_out (CV)    — Effektive Halbton-Transposition (für
                           Chaining: ein Sampler kann den Pitch des
                           nächsten steuern)
        gate_out  (RUNE)  — Pass-through des Triggers

    Params:
        file_path  (string) — Pfad zur Audio-Datei
        base_note  (CV)     — MIDI-Note der Original-Aufnahme [0..127]
        loop       (CV)     — 0=One-Shot, 1=Loop
        start_offset (CV)   — Wiedergabe-Startposition [0..1]

    System-Requirement: ``ffmpeg`` muss installiert sein für MP3/MP4/etc.
    Auf Debian/Ubuntu/Kali: ``sudo apt install ffmpeg``. Ohne ffmpeg
    funktionieren nur die soundfile-nativen Formate (WAV/FLAC/OGG/AIFF).

    Pitch-Shift: Sample-Rate-Stretching (kein Formant-Korrektur). Für
    große Pitch-Änderungen entstehen Mickey-Mouse-Effekte — das ist
    musikalisch oft genau das Gewollte.

    NICHTS-KAPUTT: existing ProSampler bleibt unverändert; das hier
    ist die simple/universelle Variante für Anno's „alle formate"-
    Anforderung.
    """
    return Module(
        god="Zerberus",
        kind="Sampler",
        params={
            "file_path":    "",
            "base_note":    60.0,
            "loop":         0.0,
            "start_offset": 0.0,
        },
        inputs=[
            _rune_in("gate", "Gate"),
            _cv_in("pitch_cv", "Pitch", default=0.0, lo=-24.0, hi=24.0, unit="st"),
            _cv_in("gain",     "Gain",  default=1.0, lo=0.0,   hi=2.0),
        ],
        outputs=[
            _audio_out(),
            Port("pitch_out", PortKind.CV, PortDirection.OUTPUT, "Pitch Out",
                 default=0.0, minimum=-24.0, maximum=24.0),
            _rune_out("gate_out", "Gate Out"),
        ],
    )


# ─── v0.0.21.238 — 3 neue Bitwig-Polymer-Style Oszillatoren ──────────
#
# Anno (v.237): „Living Patterns weiterbauen, neuen Bitwig-Oszi
#    lass uns weiter machen die".
#
# v.232/233 hatten union/bite/phase-1/scrawl geliefert. v.238 erweitert
# die Bitwig-Palette um drei weitere klassische Klang-Charaktere die
# in Bitwig's Polymer/The-Grid existieren:
#
#   * HardSyncOsc — Master/Slave-Sync für brassy/leady Sounds
#   * FMOsc       — 2-Operator FM mit Feedback (Yamaha DX-Style)
#   * DriftOsc    — Analog-Drift mit Pitch-Wobble (vintage feel)


def make_bragi_hardsync_osc() -> Module:
    """Bragi.HardSyncOsc — Master/Slave Hard-Sync (Bitwig-Style).

    Klassische Hard-Sync-Synthese: Ein „Slave"-Oszillator (variable
    Frequenz) wird bei jedem Cycle des „Master"-Oszillators (fixe
    Grundfrequenz) auf Null zurückgesetzt. Wenn slave_ratio > 1.0 ist,
    entstehen scharfe diskontinuierliche Wellenformen mit charakteristisch
    metallischem/brassy Sound — perfekt für Lead-Synth-Sounds.

    Anno (v.238): „neuen Bitwig-Oszi". Hard-Sync ist in Bitwig's Polymer
    als Sync-Mode in mehreren Oszillatoren vorhanden — wir machen daraus
    ein eigenes Modul für klare Patches.

    Inputs:
        freq        (CV) — Master-Frequenz [20..20000 Hz]
        gain        (CV) — Lautstärke [0..1]
        slave_ratio (CV) — Slave-Frequenz als Vielfaches von freq [1..8]:
                          1.0 = unisono (klingt wie Saw), 2.0 = Oktave
                          drüber, fraktional (z.B. 1.7) für scharfen Sync
        slave_drift (CV) — Slave-Frequenz-Modulation [0..1]: erzeugt das
                          klassische sweepende Sync-Sound wenn an LFO
                          gehängt
    Outputs:
        audio_out (AUDIO)

    Tipp: slave_ratio via langsamen LFO 1.0..3.5 modulieren für den
    klassischen Sync-Sweep-Sound. Bei slave_drift=0 ist die Slave-Frequenz
    konstant (klingt wie ein „eingefrorener" Sync-Sound).
    """
    return Module(
        god="Bragi",
        kind="HardSyncOsc",
        params={"freq": 220.0, "gain": 0.5, "slave_ratio": 1.5,
                "slave_drift": 0.0},
        inputs=[
            _cv_in("freq",        "Frequency", default=220.0,
                   lo=20.0, hi=20000.0, unit="Hz"),
            _cv_in("gain",        "Gain",      default=0.5,
                   lo=0.0,  hi=1.0),
            _cv_in("slave_ratio", "Slave Ratio", default=1.5,
                   lo=1.0,  hi=8.0),
            _cv_in("slave_drift", "Slave Drift", default=0.0,
                   lo=0.0,  hi=1.0),
        ],
        outputs=[_audio_out()],
    )


def make_bragi_fm_osc() -> Module:
    """Bragi.FMOsc — 2-Operator FM mit Feedback (Yamaha DX-Style).

    Frequency-Modulation-Synthese mit zwei Operatoren: Modulator (Sinus)
    moduliert die Phase des Carriers (Sinus). Plus Feedback-Pfad: Carrier
    moduliert sich selbst — ergibt sägezahn-ähnliche Spektren bei hohem
    Feedback. Das ist die Basis von Yamaha DX7's berühmten Sounds.

    Anno (v.238): Bitwig hat im Polymer einen FM-Mode und in The Grid
    einen FM-Operator. Hier als eigenständiges Modul mit klassischen
    DX-Parametern.

    Inputs:
        freq      (CV) — Carrier-Frequenz [20..20000 Hz]
        gain      (CV) — Lautstärke [0..1]
        mod_ratio (CV) — Modulator-Frequenz als Vielfaches von freq
                         [0.25..16]: ganzzahlig (1, 2, 3) = harmonisch,
                         fraktional (1.41, 2.7) = inharmonisch/glockig
        mod_index (CV) — FM-Modulationstiefe [0..10]: 0 = pure Sine,
                         höher = mehr Sidebands; ab ~5 wird's metallisch
        feedback  (CV) — Carrier-Self-FM [0..1]: 0=clean, ~0.7=Saw-ähnlich,
                         1=raues Noise (Bauteil-typisch für DX-Brass)
    Outputs:
        audio_out (AUDIO)

    Tipp: mod_index per Envelope (Freyr.ADSR) modulieren für klassische
    FM-Plucks/Bells. mod_ratio=1.0 → harmonisch (Brass), 3.5 → Glocke.
    feedback=0.5 mit mod_index=2 = klassischer DX-Bass.
    """
    return Module(
        god="Bragi",
        kind="FMOsc",
        params={"freq": 220.0, "gain": 0.5, "mod_ratio": 1.0,
                "mod_index": 2.0, "feedback": 0.0},
        inputs=[
            _cv_in("freq",      "Frequency", default=220.0,
                   lo=20.0, hi=20000.0, unit="Hz"),
            _cv_in("gain",      "Gain",      default=0.5,
                   lo=0.0,  hi=1.0),
            _cv_in("mod_ratio", "Mod Ratio", default=1.0,
                   lo=0.25, hi=16.0),
            _cv_in("mod_index", "Mod Index", default=2.0,
                   lo=0.0,  hi=10.0),
            _cv_in("feedback",  "Feedback",  default=0.0,
                   lo=0.0,  hi=1.0),
        ],
        outputs=[_audio_out()],
    )


def make_bragi_drift_osc() -> Module:
    """Bragi.DriftOsc — Analog-Drift mit Pitch-Wobble (Vintage-Style).

    Saw-Oszillator mit subtiler Pitch-Drift (Random-Walk) der den
    Charakter alter Analog-Synths nachbildet: VCOs hatten temperatur-
    abhängige Schwankungen die heutigen DCOs/Digital-Oszis fehlt. Drift
    bringt das zurück — und damit Lebendigkeit in Bass- und Pad-Sounds.

    Anno (v.238): Bitwig's „Drift" Oszillator (auch bei u-he Diva, etc.)
    macht Sounds analog-feel; ohne Drift klingt jeder Digital-Synth
    sterilisiert-perfekt.

    Inputs:
        freq        (CV) — Grund-Frequenz [20..20000 Hz]
        gain        (CV) — Lautstärke [0..1]
        drift_amount(CV) — Wobble-Tiefe [0..1]: 0=keine Drift (steril),
                          ~0.1=subtile Lebendigkeit, 1=stark seekrank
        drift_rate  (CV) — Wobble-Geschwindigkeit [0.05..20 Hz]: niedrig =
                          langsame Atmung, hoch = vibrato-ähnlich
        warmth      (CV) — Subtile Even-Harmonics [0..1]: 0=clean Saw,
                          1=tube-warm via leichte tanh-Saturation
    Outputs:
        audio_out (AUDIO)

    Tipp: Zwei DriftOscs leicht detunet (z.B. ±5 Cent) ergeben das
    klassische „fat Analog Saw" Pad. drift_rate=0.3 + drift_amount=0.15 =
    sweetspot für Lebendigkeit ohne nervöses Wobble.
    """
    return Module(
        god="Bragi",
        kind="DriftOsc",
        params={"freq": 220.0, "gain": 0.5, "drift_amount": 0.15,
                "drift_rate": 0.3, "warmth": 0.3, "seed": 24601.0},
        inputs=[
            _cv_in("freq",         "Frequency", default=220.0,
                   lo=20.0,  hi=20000.0, unit="Hz"),
            _cv_in("gain",         "Gain",      default=0.5,
                   lo=0.0,   hi=1.0),
            _cv_in("drift_amount", "Drift Amount", default=0.15,
                   lo=0.0,   hi=1.0),
            _cv_in("drift_rate",   "Drift Rate", default=0.3,
                   lo=0.05,  hi=20.0, unit="Hz"),
            _cv_in("warmth",       "Warmth",    default=0.3,
                   lo=0.0,   hi=1.0),
        ],
        outputs=[_audio_out()],
    )


# ─── v0.0.21.239 — 3 weitere Bitwig-Polymer-Style Oszillatoren ────────
#
# Anno (v.238 → v.239): „Weiter" — wir bauen die Bitwig-Familie weiter aus.
#
# v.232 hatte 4 Oszis (Pulse/Sub/Swarm/Wavetable). v.233 hatte 4 weitere
# (Union/Bite/Phase1/Scrawl). v.238 hatte 3 weitere (HardSync/FM/Drift).
# v.239 ergänzt drei weitere klassische Klang-Charaktere die in Bitwig's
# Polymer/The-Grid-Bibliothek dokumentiert sind:
#
#   * RingModOsc — Ring-Modulation (zwei Sinus multipliziert, glockig/metallisch)
#   * GrainOsc   — Granular-Synthese (kurze Grains mit Overlap, Texturen/Drones)
#   * FormantOsc — Vocal-Formant (Saw → 3 BP-Filter, Vowel-Morphing A→E→I→O→U)


def make_bragi_ring_mod_osc() -> Module:
    """Bragi.RingModOsc — Ring-Modulator (Bitwig-Style).

    Ring-Modulation: Zwei Sinus-Oszillatoren werden multipliziert. Das
    Ergebnis enthält die Summen- UND Differenz-Frequenzen (`f1±f2`) der
    beiden Inputs — KEINE Original-Frequenzen. Bei harmonischen Verhält-
    nissen (mod_freq = freq * 2.0) klingt das glockig/metallisch; bei
    unharmonischen Verhältnissen (mod_freq = freq * 1.41) entstehen die
    klassischen Sci-Fi-/Dalek-Sounds.

    Anno (v.239): Bitwig hat im Polymer einen Ring-Modulator-Modus und
    in The Grid einen eigenen Ring-Mod-Operator. Hier als eigenständiges
    Modul mit klarem Carrier/Modulator-Setup plus dry/wet-Mix damit man
    den Effekt dosieren kann.

    Inputs:
        freq      (CV) — Carrier-Frequenz [20..20000 Hz]
        gain      (CV) — Lautstärke [0..1]
        mod_freq  (CV) — Modulator-Frequenz absolute [20..20000 Hz]:
                         harmonische Vielfache (220/440/660) klingen
                         glockig, fraktional (220/311) = Sci-Fi
        mix       (CV) — Dry/Wet [0..1]: 0=nur Carrier (Sinus),
                         1=nur Ring-Mod-Produkt
    Outputs:
        audio_out (AUDIO)

    Tipp: mod_freq via langsamen LFO 100..800 Hz sweepen für klassische
    Daleck-Sweep-Sounds. Bei mix=0.5 kombiniert man harmonisch klingen-
    den Carrier mit metallischem Ring-Mod-Anteil — gut für Bell-Pads.
    """
    return Module(
        god="Bragi",
        kind="RingModOsc",
        params={"freq": 220.0, "gain": 0.5, "mod_freq": 440.0, "mix": 1.0},
        inputs=[
            _cv_in("freq",     "Frequency", default=220.0,
                   lo=20.0, hi=20000.0, unit="Hz"),
            _cv_in("gain",     "Gain",      default=0.5,
                   lo=0.0,  hi=1.0),
            _cv_in("mod_freq", "Mod Freq",  default=440.0,
                   lo=20.0, hi=20000.0, unit="Hz"),
            _cv_in("mix",      "Mix",       default=1.0,
                   lo=0.0,  hi=1.0),
        ],
        outputs=[_audio_out()],
    )


def make_bragi_grain_osc() -> Module:
    """Bragi.GrainOsc — Granular-Oszillator (Bitwig-Style).

    Granulare Synthese aus dem Oszi heraus: Statt eines kontinuierlichen
    Sinus-/Saw-Streams werden viele kurze (5..100ms) Hanning-gefensterte
    Sinus-„Grains" mit konfigurierbarer Density (Grains pro Sekunde) und
    Pitch+Time-Spread random ausgelöst. Das ergibt körnige Texturen,
    Drone-Pads, sci-fi-Hintergründe — sehr lebendig, anders als smoothe
    Wavetable-Sounds.

    Anno (v.239): Bitwig hat Grain in The Grid (auch Phase-DG / Granny
    bei diversen Synths). Wir machen eine simple aber effektive Variante.

    Inputs:
        freq        (CV) — Center-Pitch der Grains [20..20000 Hz]
        gain        (CV) — Lautstärke [0..1]
        grain_size  (CV) — Grain-Länge in ms [5..100]: kurz=körnig,
                          lang=smooth überlappend
        density     (CV) — Grains pro Sekunde [5..200]: niedrig=
                          tröpfelnd, hoch=dichter Klangteppich
        pitch_spread(CV) — Random-Pitch-Variation pro Grain [0..1]:
                          0=alle Grains gleiche Pitch, 1=±1 Oktave
                          random
    Outputs:
        audio_out (AUDIO)

    Tipp: density=80 + grain_size=50ms ergibt smoothe Pad-Texturen.
    density=15 + grain_size=10ms = klassischer „grain shower"-Effekt.
    pitch_spread via LFO langsam moduliert für lebendige Pads.
    """
    return Module(
        god="Bragi",
        kind="GrainOsc",
        params={"freq": 220.0, "gain": 0.5, "grain_size": 30.0,
                "density": 50.0, "pitch_spread": 0.0, "seed": 42.0},
        inputs=[
            _cv_in("freq",         "Frequency",   default=220.0,
                   lo=20.0, hi=20000.0, unit="Hz"),
            _cv_in("gain",         "Gain",        default=0.5,
                   lo=0.0,  hi=1.0),
            _cv_in("grain_size",   "Grain Size",  default=30.0,
                   lo=5.0,  hi=100.0, unit="ms"),
            _cv_in("density",      "Density",     default=50.0,
                   lo=5.0,  hi=200.0, unit="g/s"),
            _cv_in("pitch_spread", "Pitch Spread", default=0.0,
                   lo=0.0,  hi=1.0),
        ],
        outputs=[_audio_out()],
    )


def make_bragi_formant_osc() -> Module:
    """Bragi.FormantOsc — Vocal-Formant-Synthese (Bitwig-Style).

    Saw-Source durch 3 parallele Bandpass-Filter mit Formant-Resonanzen.
    Jede Vowel (A, E, I, O, U) hat eine charakteristische Trio von
    Formant-Frequenzen die durch das Vocal-Tract entstehen. Wir morphen
    zwischen den Vowels via ``vowel`` Param: 0=A, 0.25=E, 0.5=I, 0.75=O,
    1.0=U. Ergibt sing-/sprechende Sounds — von Choir-Pads bis zu
    Roboter-Stimmen wenn man's per LFO durchwiegt.

    Formant-Frequenzen (aus klassischer Vocal-Tract-Modellierung,
    Reference: Klatt 1980 + Peterson/Barney 1952 normalisierte Werte):

        Vowel  F1     F2      F3
        A      730    1090    2440
        E      530    1840    2480
        I      270    2290    3010
        O      570    840     2410
        U      300    870     2240

    Anno (v.239): Bitwig hat keinen direkten Formant-Oszi aber die
    Voice-Synthese ist Standard in Polymer-Style-Synths (u-he Hive,
    u-he Diva, Ableton Operator). Wir bringen sie zu FLUX.

    Inputs:
        freq          (CV) — Source-Frequenz (Saw-Pitch) [20..2000 Hz]
        gain          (CV) — Lautstärke [0..1]
        vowel         (CV) — Vowel-Morph [0..1]: A→E→I→O→U
        formant_shift (CV) — Formant-Frequenz-Multiplier [0.5..2]:
                            <1 = größerer Vocal-Tract (tiefere
                            Stimme), >1 = kleinere/höhere
        resonance     (CV) — Q der Formant-BP-Filter [0.5..15]:
                            niedrig=verschwommen, hoch=schreiend-resonant
    Outputs:
        audio_out (AUDIO)

    Tipp: vowel via Loki.LFOSine sweepen für klassische „Mama-Mama-
    Wah"-Sounds. formant_shift unabhängig von freq mit LFO modulieren
    erzeugt cartoon-haftige Pitch-Stimme-Effekte.
    """
    return Module(
        god="Bragi",
        kind="FormantOsc",
        params={"freq": 110.0, "gain": 0.5, "vowel": 0.0,
                "formant_shift": 1.0, "resonance": 6.0},
        inputs=[
            _cv_in("freq",          "Frequency", default=110.0,
                   lo=20.0, hi=2000.0, unit="Hz"),
            _cv_in("gain",          "Gain",      default=0.5,
                   lo=0.0,  hi=1.0),
            _cv_in("vowel",         "Vowel",     default=0.0,
                   lo=0.0,  hi=1.0),
            _cv_in("formant_shift", "Formant Shift", default=1.0,
                   lo=0.5,  hi=2.0),
            _cv_in("resonance",     "Resonance", default=6.0,
                   lo=0.5,  hi=15.0),
        ],
        outputs=[_audio_out()],
    )


MODULE_REGISTRY: dict[tuple[str, str], ModuleFactory] = {

    ("Bragi",    "SineOsc"):       make_bragi_sine_osc,
    ("Bragi",    "SawOsc"):        make_bragi_saw_osc,
    ("Bragi",    "SquareOsc"):     make_bragi_square_osc,
    ("Bragi",    "TriangleOsc"):   make_bragi_triangle_osc,
    ("Bragi",    "NoiseOsc"):      make_bragi_noise_osc,
    ("Loki",     "LFOSine"):       make_loki_lfo_sine,
    ("Loki",     "LFOTriangle"):   make_loki_lfo_triangle,
    ("Loki",     "LFOSquare"):     make_loki_lfo_square,
    ("Loki",     "LFOSampleHold"): make_loki_lfo_sample_hold,
    ("Freyr",    "ADSR"):          make_freyr_adsr,
    ("Tyr",      "PulseGate"):     make_tyr_pulse_gate,
    ("Forseti",  "Lowpass"):       make_forseti_lowpass,
    ("Forseti",  "Highpass"):      make_forseti_highpass,
    ("Forseti",  "Bandpass"):      make_forseti_bandpass,
    ("Forseti",  "Notch"):         make_forseti_notch,
    ("Forseti",  "Tilt"):          make_forseti_tilt,
    ("Forseti",  "EQ4"):           make_forseti_eq4,
    ("Iduna",    "Delay"):         make_iduna_delay,
    ("Iduna",    "Reverb"):        make_iduna_reverb,
    ("Hel",      "Gater"):         make_hel_gater,
    ("Hel",      "TapeStop"):      make_hel_tape_stop,
    ("Mimir",    "Stutter"):       make_mimir_stutter,
    ("Fenrir",   "BitCrush"):      make_fenrir_bit_crush,
    ("Fenrir",   "Decimator"):     make_fenrir_decimator,
    ("Thor",     "TubeDrive"):     make_thor_tube_drive,
    ("Thor",     "Fuzz"):          make_thor_fuzz,
    ("Thor",     "Saturation"):    make_thor_saturation,
    ("Thor",     "WaveShaper"):    make_thor_wave_shaper,
    ("Vidar",    "Compressor"):    make_vidar_compressor,
    ("Vidar",    "Limiter"):       make_vidar_limiter,
    ("Vidar",    "Gate"):          make_vidar_gate,
    ("Skadi",    "Chorus"):        make_skadi_chorus,
    ("Skadi",    "Flanger"):       make_skadi_flanger,
    ("Skadi",    "Phaser"):        make_skadi_phaser,
    ("Skadi",    "StereoImager"):  make_skadi_stereo_imager,
    ("Heimdall", "MasterOut"):     make_heimdall_master_out,
    # v0.0.21.195 — Frigg-Familie (UI-Control-Widgets)
    ("Frigg",    "Knob"):          make_frigg_knob,
    ("Frigg",    "SliderV"):       make_frigg_slider_v,
    ("Frigg",    "SliderH"):       make_frigg_slider_h,
    ("Frigg",    "Toggle"):        make_frigg_toggle,
    ("Frigg",    "Bang"):          make_frigg_bang,
    ("Frigg",    "NumberBox"):     make_frigg_number_box,
    ("Frigg",    "Comment"):       make_frigg_comment,
    # v0.0.21.197 — FLUX Sigil-Widgets (W-1, Norse-Designs)
    ("Frigg",    "PulseRing"):     make_frigg_pulse_ring,
    ("Frigg",    "AuroraSliderV"): make_frigg_aurora_slider_v,
    ("Frigg",    "AuroraSliderH"): make_frigg_aurora_slider_h,
    ("Frigg",    "RuneToggle"):    make_frigg_rune_toggle,
    ("Frigg",    "SparkBang"):     make_frigg_spark_bang,
    # v0.0.21.200 — FLUX Display-Sigil-Widgets (W-2)
    ("Frigg",    "VolvaNumber"):   make_frigg_volva_number,
    ("Frigg",    "BautaStone"):    make_frigg_bauta_stone,
    ("Frigg",    "ManiMeter"):     make_frigg_mani_meter,
    # v0.0.21.231 — Live-Probe (Anno's „number modul mit ein und ausgängen")
    ("Frigg",    "NumberFlow"):    make_frigg_number_flow,
    # v0.0.21.202 — S-0: Saga (Sigil-Sight) — Stippling-Visualizer
    ("Saga",     "Magic"):         make_saga_magic,
    # v0.0.21.215 — Phase 1 Rune-Realm: Vör (Routing & Logic) Foundation
    ("Vör",      "Bang"):          make_voer_bang,
    ("Vör",      "RuneTap"):       make_voer_rune_tap,
    # v0.0.21.216 — Phase 2.1 Rune-Realm: Vör.Route + Vör.Select
    ("Vör",      "Route"):         make_voer_route,
    ("Vör",      "Select"):        make_voer_select,
    # v0.0.21.217 — Phase 2.2 Rune-Realm: Vör.Spigot + Vör.Trigger
    ("Vör",      "Spigot"):        make_voer_spigot,
    ("Vör",      "Trigger"):       make_voer_trigger,
    # v0.0.21.220 — Phase 2.4 Rune-Realm: Vör.Float + Vör.Int Producer
    ("Vör",      "Float"):         make_voer_float,
    ("Vör",      "Int"):           make_voer_int,
    # v0.0.21.221 — Phase 2.5 Rune-Realm: Vör.Knob (continuous Float)
    ("Vör",      "Knob"):          make_voer_knob,
    # v0.0.21.221-223 — Phase 3 Rune-Realm: Norns-Familie (Time)
    ("Norns",    "Metro"):         make_norns_metro,
    ("Norns",    "Line"):          make_norns_line,
    ("Norns",    "Pipe"):          make_norns_pipe,
    ("Norns",    "Delay"):         make_norns_delay,
    # v0.0.21.224 — Phase 2.6 Rune-Realm: Vör.RouteV + Vör.SelectV
    # (PD-style Multi-Match by Value, Anno-Direktive nach PD-Vergleich)
    ("Vör",      "RouteV"):        make_voer_route_v,
    ("Vör",      "SelectV"):       make_voer_select_v,
    # v0.0.21.225-227 — Phase 4 Rune-Realm: Ullr-Familie (Math/Expr)
    ("Ullr",     "Plus"):          make_ullr_plus,
    ("Ullr",     "Minus"):         make_ullr_minus,
    ("Ullr",     "Times"):         make_ullr_times,
    ("Ullr",     "Divide"):        make_ullr_divide,
    ("Ullr",     "Clip"):          make_ullr_clip,
    ("Ullr",     "Abs"):           make_ullr_abs,
    ("Ullr",     "Min"):           make_ullr_min,
    ("Ullr",     "Max"):           make_ullr_max,
    ("Ullr",     "Random"):        make_ullr_random,
    ("Ullr",     "Expr"):          make_ullr_expr,
    # v0.0.21.247 — Anno's Math-Erweiterung: 5 neue Audio-only-Operatoren
    ("Ullr",     "Sqrt"):          make_ullr_sqrt,
    ("Ullr",     "Pow"):           make_ullr_pow,
    ("Ullr",     "Log"):           make_ullr_log,
    ("Ullr",     "Exp"):           make_ullr_exp,
    ("Ullr",     "Negate"):        make_ullr_negate,
    # v0.0.21.227 — Phase 5 Foundation Rune-Realm: Ratatosk (Mtof+Ftom)
    ("Ratatosk", "Mtof"):          make_ratatosk_mtof,
    ("Ratatosk", "Ftom"):          make_ratatosk_ftom,
    # v0.0.21.228 — Phase 6 Rune-Realm: Hermod-Familie (Network/OSC)
    ("Hermod",   "OscReceive"):    make_hermod_osc_receive,
    ("Hermod",   "OscSend"):       make_hermod_osc_send,
    ("Hermod",   "OscPath"):       make_hermod_osc_path,
    ("Hermod",   "OscPrint"):      make_hermod_osc_print,
    # v0.0.21.232 — Anno-Auftrag: Gain, PeakLimiter, Sampler, neue Oszillatoren
    ("Vidar",    "Gain"):          make_vidar_gain,
    ("Vidar",    "PeakLimiter"):   make_vidar_peak_limiter,
    ("Bragi",    "PulseOsc"):      make_bragi_pulse_osc,
    ("Bragi",    "SubOsc"):        make_bragi_sub_osc,
    ("Bragi",    "SwarmOsc"):      make_bragi_swarm_osc,
    ("Bragi",    "WavetableOsc"): make_bragi_wavetable_osc,
    ("Zerberus", "Sampler"):       make_zerberus_sampler,
    # v0.0.21.233 — Bitwig-Polymer-Style Oszillatoren
    ("Bragi",    "UnionOsc"):      make_bragi_union_osc,
    ("Bragi",    "BiteOsc"):       make_bragi_bite_osc,
    ("Bragi",    "Phase1Osc"):     make_bragi_phase1_osc,
    ("Bragi",    "ScrawlOsc"):     make_bragi_scrawl_osc,
    # v0.0.21.238 — 3 weitere Bitwig-Style-Oszillatoren
    ("Bragi",    "HardSyncOsc"):   make_bragi_hardsync_osc,
    ("Bragi",    "FMOsc"):         make_bragi_fm_osc,
    ("Bragi",    "DriftOsc"):      make_bragi_drift_osc,
    # v0.0.21.239 — 3 weitere Bitwig-Style-Oszillatoren
    ("Bragi",    "RingModOsc"):    make_bragi_ring_mod_osc,
    ("Bragi",    "GrainOsc"):      make_bragi_grain_osc,
    ("Bragi",    "FormantOsc"):    make_bragi_formant_osc,
    # v0.0.21.240 — Hel.Vocoder (klassischer Channel-Vocoder)
    ("Hel",      "Vocoder"):       make_hel_vocoder,
}


def list_available_modules() -> list[tuple[str, str, str]]:
    """Für die UI-Palette: alle registrierten Module mit Beschreibung.

    Returns: List of (god, kind, description).
    """
    out = []
    for (god, kind), factory in MODULE_REGISTRY.items():
        # Description aus dem Factory-Docstring extrahieren (1. Zeile)
        doc = (factory.__doc__ or "").strip().split("\n")[0]
        out.append((god, kind, doc))
    return out


def make_module(god: str, kind: str) -> Module | None:
    """Erzeugt ein neues Modul über die Registry.

    Returns: Neues Module-Objekt mit frischer ID, oder None wenn
    (god, kind) nicht registriert ist.
    """
    factory = MODULE_REGISTRY.get((god, kind))
    if factory is None:
        return None
    return factory()


def make_demo_patch() -> "Patch":
    """Baut einen Demo-Patch: Bragi.SineOsc → Forseti.Lowpass → Heimdall.MasterOut.

    Praktisch fürs erste Öffnen — leerer Canvas wirkt einschüchternd.
    """
    from pydaw.flux.patch_model import Patch, Connection
    p = Patch(name="FLUX Demo — Sine through Filter")
    osc = make_bragi_sine_osc(); osc.position = (100, 200)
    flt = make_forseti_lowpass(); flt.position = (400, 200)
    out = make_heimdall_master_out(); out.position = (700, 200)
    p.add_module(osc); p.add_module(flt); p.add_module(out)
    p.add_connection(Connection(
        source_module=osc.id, source_port="audio_out",
        target_module=flt.id, target_port="audio_in",
    ))
    p.add_connection(Connection(
        source_module=flt.id, source_port="audio_out",
        target_module=out.id, target_port="audio_in_l",
    ))
    p.add_connection(Connection(
        source_module=flt.id, source_port="audio_out",
        target_module=out.id, target_port="audio_in_r",
    ))
    return p


__all__ = [
    "MODULE_REGISTRY", "ModuleFactory",
    "make_bragi_sine_osc", "make_bragi_saw_osc", "make_bragi_square_osc",
    "make_bragi_triangle_osc", "make_bragi_noise_osc",
    "make_loki_lfo_sine", "make_loki_lfo_triangle",
    "make_loki_lfo_square", "make_loki_lfo_sample_hold",
    "make_freyr_adsr", "make_tyr_pulse_gate",
    "make_forseti_lowpass", "make_forseti_highpass", "make_forseti_bandpass",
    "make_forseti_notch", "make_forseti_tilt", "make_forseti_eq4",
    "make_iduna_delay", "make_iduna_reverb",
    "make_hel_gater", "make_hel_tape_stop",
    "make_mimir_stutter",
    "make_fenrir_bit_crush", "make_fenrir_decimator",
    "make_thor_tube_drive", "make_thor_fuzz",
    "make_thor_saturation", "make_thor_wave_shaper",
    "make_vidar_compressor", "make_vidar_limiter", "make_vidar_gate",
    "make_skadi_chorus", "make_skadi_flanger",
    "make_skadi_phaser", "make_skadi_stereo_imager",
    "make_heimdall_master_out",
    # v.197 W-1 — Sigil-Widgets
    "make_frigg_pulse_ring",
    "make_frigg_aurora_slider_v", "make_frigg_aurora_slider_h",
    "make_frigg_rune_toggle", "make_frigg_spark_bang",
    "list_available_modules", "make_module", "make_demo_patch",
]
