"""Cloud Storage Service (P5B) — Self-hostable project, sample, and preset cloud.

Provides local-first cloud storage with optional HTTP sync.
All data stays on the user's machine by default. HTTP sync is opt-in.

Features:
- Project cloud: backup/restore projects to local or remote storage
- Sample cloud: catalog and sync samples across machines
- Preset cloud: share and discover presets
- Collections browser: organized preset/sample collections
- Manifest-based sync (SHA-256 content-addressed storage)

v0.0.20.817 — Phase P5B
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import shutil
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Dict, Any, Tuple

from PyQt6.QtCore import QObject, pyqtSignal

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class CloudItem:
    """An item in the cloud storage (project, sample, or preset)."""
    item_id: str = ""
    name: str = ""
    item_type: str = ""        # "project"|"sample"|"preset"
    author: str = ""
    description: str = ""
    tags: List[str] = field(default_factory=list)
    category: str = ""
    file_path: str = ""
    file_size: int = 0
    sha256: str = ""
    created_at: float = 0.0
    updated_at: float = 0.0
    download_count: int = 0
    rating: float = 0.0
    is_local: bool = True
    is_synced: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "item_id": self.item_id, "name": self.name,
            "item_type": self.item_type, "author": self.author,
            "description": self.description, "tags": self.tags,
            "category": self.category, "file_size": self.file_size,
            "sha256": self.sha256, "created_at": self.created_at,
            "updated_at": self.updated_at, "download_count": self.download_count,
            "rating": self.rating, "metadata": self.metadata,
        }

    @staticmethod
    def from_dict(data: dict) -> CloudItem:
        item = CloudItem()
        for key in ("item_id", "name", "item_type", "author", "description",
                     "category", "sha256", "file_path"):
            if key in data:
                setattr(item, key, data[key])
        for key in ("file_size", "download_count"):
            if key in data:
                setattr(item, key, int(data[key]))
        for key in ("created_at", "updated_at", "rating"):
            if key in data:
                setattr(item, key, float(data[key]))
        if "tags" in data:
            item.tags = list(data["tags"])
        if "metadata" in data:
            item.metadata = dict(data["metadata"])
        return item


@dataclass
class CloudCollection:
    """A curated collection of cloud items."""
    name: str = ""
    description: str = ""
    author: str = ""
    items: List[str] = field(default_factory=list)  # item_ids
    tags: List[str] = field(default_factory=list)
    category: str = ""
    created_at: float = 0.0

    def to_dict(self) -> dict:
        return {
            "name": self.name, "description": self.description,
            "author": self.author, "items": self.items,
            "tags": self.tags, "category": self.category,
        }


# ---------------------------------------------------------------------------
# Cloud Storage Manager
# ---------------------------------------------------------------------------

class CloudStorageService(QObject):
    """Manages local cloud storage for projects, samples, and presets.

    Storage layout:
        ~/.pydaw/cloud/
        ├── projects/     ← project backups
        ├── samples/      ← sample library
        ├── presets/       ← preset library
        ├── collections/  ← curated collections
        └── manifest.json ← content manifest
    """

    item_added = pyqtSignal(object)       # CloudItem
    item_removed = pyqtSignal(str)         # item_id
    sync_progress = pyqtSignal(int, int)   # current, total
    status = pyqtSignal(str)
    error = pyqtSignal(str)

    def __init__(
        self,
        cloud_dir: str = "",
        parent=None,
    ):
        super().__init__(parent)
        self._cloud_dir = cloud_dir or str(Path.home() / ".pydaw" / "cloud")
        self._manifest: Dict[str, CloudItem] = {}
        self._collections: Dict[str, CloudCollection] = {}

        # Ensure directories
        for subdir in ("projects", "samples", "presets", "collections"):
            Path(self._cloud_dir, subdir).mkdir(parents=True, exist_ok=True)

        self._load_manifest()

    # ── Manifest ──────────────────────────────────────────────────────

    def _manifest_path(self) -> str:
        return os.path.join(self._cloud_dir, "manifest.json")

    def _load_manifest(self) -> None:
        """Load the content manifest from disk."""
        mp = self._manifest_path()
        if not os.path.exists(mp):
            return
        try:
            data = json.loads(Path(mp).read_text(encoding="utf-8"))
            for item_data in data.get("items", []):
                item = CloudItem.from_dict(item_data)
                if item.item_id:
                    self._manifest[item.item_id] = item
            for coll_data in data.get("collections", []):
                coll = CloudCollection(**{k: v for k, v in coll_data.items()
                                          if k in CloudCollection.__dataclass_fields__})
                if coll.name:
                    self._collections[coll.name] = coll
            log.info("Cloud manifest loaded: %d items, %d collections",
                     len(self._manifest), len(self._collections))
        except Exception as exc:
            log.error("Manifest load failed: %s", exc)

    def _save_manifest(self) -> None:
        """Save the content manifest to disk."""
        data = {
            "version": 1,
            "updated_at": time.time(),
            "items": [item.to_dict() for item in self._manifest.values()],
            "collections": [coll.to_dict() for coll in self._collections.values()],
        }
        try:
            Path(self._manifest_path()).write_text(
                json.dumps(data, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
        except Exception as exc:
            log.error("Manifest save failed: %s", exc)

    # ── Content operations ────────────────────────────────────────────

    def add_item(
        self,
        file_path: str,
        item_type: str,
        name: str = "",
        description: str = "",
        tags: Optional[List[str]] = None,
        category: str = "",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Optional[CloudItem]:
        """Add a file to the cloud storage.

        Args:
            file_path: path to the file to add
            item_type: "project"|"sample"|"preset"
            name: display name (defaults to filename)
            description: item description
            tags: search tags
            category: category name
            metadata: additional metadata dict

        Returns:
            CloudItem on success, None on failure.
        """
        if not os.path.exists(file_path):
            try:
                self.error.emit(f"Datei nicht gefunden: {file_path}")
            except Exception:
                pass
            return None

        try:
            # Hash content for dedup
            sha = hashlib.sha256()
            with open(file_path, "rb") as f:
                for chunk in iter(lambda: f.read(8192), b""):
                    sha.update(chunk)
            content_hash = sha.hexdigest()

            # Check for duplicate
            for existing in self._manifest.values():
                if existing.sha256 == content_hash:
                    log.info("Duplicate detected: %s already in cloud as %s",
                             file_path, existing.name)
                    return existing

            # Generate ID
            item_id = content_hash[:16]

            # Copy to cloud storage
            subdir = {"project": "projects", "sample": "samples",
                      "preset": "presets"}.get(item_type, "projects")
            ext = Path(file_path).suffix
            dest = os.path.join(self._cloud_dir, subdir, f"{item_id}{ext}")
            shutil.copy2(file_path, dest)

            item = CloudItem(
                item_id=item_id,
                name=name or Path(file_path).stem,
                item_type=item_type,
                author=os.environ.get("USER", "Anonymous"),
                description=description,
                tags=tags or [],
                category=category,
                file_path=dest,
                file_size=os.path.getsize(dest),
                sha256=content_hash,
                created_at=time.time(),
                updated_at=time.time(),
                is_local=True,
                metadata=metadata or {},
            )

            self._manifest[item_id] = item
            self._save_manifest()

            try:
                self.item_added.emit(item)
                self.status.emit(f"☁️ {item.name} zur Cloud hinzugefügt")
            except Exception:
                pass

            return item

        except Exception as exc:
            log.error("Cloud add failed: %s", exc)
            try:
                self.error.emit(f"Cloud-Fehler: {exc}")
            except Exception:
                pass
            return None

    def remove_item(self, item_id: str) -> bool:
        """Remove an item from cloud storage."""
        item = self._manifest.get(item_id)
        if item is None:
            return False

        try:
            if item.file_path and os.path.exists(item.file_path):
                os.remove(item.file_path)
            del self._manifest[item_id]
            self._save_manifest()

            try:
                self.item_removed.emit(item_id)
                self.status.emit(f"☁️ {item.name} aus Cloud entfernt")
            except Exception:
                pass
            return True
        except Exception as exc:
            log.error("Cloud remove failed: %s", exc)
            return False

    def get_item(self, item_id: str) -> Optional[CloudItem]:
        return self._manifest.get(item_id)

    def search(
        self,
        query: str = "",
        item_type: str = "",
        category: str = "",
        tags: Optional[List[str]] = None,
    ) -> List[CloudItem]:
        """Search cloud items."""
        results = list(self._manifest.values())

        if item_type:
            results = [i for i in results if i.item_type == item_type]

        if category:
            results = [i for i in results
                       if i.category.lower() == category.lower()]

        if tags:
            tag_set = set(t.lower() for t in tags)
            results = [i for i in results
                       if tag_set & set(t.lower() for t in i.tags)]

        if query:
            q = query.lower()
            results = [i for i in results
                       if q in i.name.lower()
                       or q in i.description.lower()
                       or q in i.author.lower()
                       or any(q in t.lower() for t in i.tags)]

        results.sort(key=lambda i: i.updated_at, reverse=True)
        return results

    # ── Collections ───────────────────────────────────────────────────

    def create_collection(
        self,
        name: str,
        description: str = "",
        item_ids: Optional[List[str]] = None,
        tags: Optional[List[str]] = None,
        category: str = "",
    ) -> CloudCollection:
        """Create a curated collection of items."""
        coll = CloudCollection(
            name=name,
            description=description,
            author=os.environ.get("USER", "Anonymous"),
            items=item_ids or [],
            tags=tags or [],
            category=category,
            created_at=time.time(),
        )
        self._collections[name] = coll
        self._save_manifest()
        return coll

    def get_collection(self, name: str) -> Optional[CloudCollection]:
        return self._collections.get(name)

    def list_collections(self, category: str = "") -> List[CloudCollection]:
        """List all collections, optionally filtered by category."""
        result = list(self._collections.values())
        if category:
            result = [c for c in result if c.category.lower() == category.lower()]
        return result

    def add_to_collection(self, collection_name: str, item_id: str) -> bool:
        """Add an item to a collection."""
        coll = self._collections.get(collection_name)
        if coll and item_id not in coll.items:
            coll.items.append(item_id)
            self._save_manifest()
            return True
        return False

    # ── Convenience methods ───────────────────────────────────────────

    def add_sample(self, file_path: str, **kwargs) -> Optional[CloudItem]:
        """Add a sample to the cloud."""
        return self.add_item(file_path, "sample", **kwargs)

    def add_preset(self, file_path: str, **kwargs) -> Optional[CloudItem]:
        """Add a preset to the cloud."""
        return self.add_item(file_path, "preset", **kwargs)

    def add_project(self, file_path: str, **kwargs) -> Optional[CloudItem]:
        """Add a project backup to the cloud."""
        return self.add_item(file_path, "project", **kwargs)

    def list_samples(self, query: str = "", category: str = "") -> List[CloudItem]:
        return self.search(query=query, item_type="sample", category=category)

    def list_presets(self, query: str = "", category: str = "") -> List[CloudItem]:
        return self.search(query=query, item_type="preset", category=category)

    def list_projects(self, query: str = "") -> List[CloudItem]:
        return self.search(query=query, item_type="project")

    def get_stats(self) -> Dict[str, Any]:
        """Get cloud storage statistics."""
        total_size = sum(i.file_size for i in self._manifest.values())
        return {
            "total_items": len(self._manifest),
            "projects": len([i for i in self._manifest.values() if i.item_type == "project"]),
            "samples": len([i for i in self._manifest.values() if i.item_type == "sample"]),
            "presets": len([i for i in self._manifest.values() if i.item_type == "preset"]),
            "collections": len(self._collections),
            "total_size_mb": round(total_size / (1024 * 1024), 1),
            "cloud_dir": self._cloud_dir,
        }

    def shutdown(self) -> None:
        self._save_manifest()
