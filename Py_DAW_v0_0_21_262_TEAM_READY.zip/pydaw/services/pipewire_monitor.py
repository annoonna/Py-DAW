"""pipewire_monitor.py — PipeWire Quantum & Rate Monitor (v0.0.20.983)

NS5.4: Buffer-Size Synchronisation — PipeWire Quantum

Features:
  - Query actual PipeWire quantum (buffer size) and sample rate
  - Detect mismatch between requested and actual buffer
  - Set PipeWire quantum to match DAW settings
  - Background polling (optional)

Usage:
    from pydaw.services.pipewire_monitor import PipeWireMonitor

    pw = PipeWireMonitor()
    info = pw.query()
    # info = {'quantum': 1024, 'rate': 48000, 'available': True}

    pw.set_quantum(256)  # change PipeWire buffer size
"""

import logging
import subprocess
import threading
from typing import Optional

log = logging.getLogger(__name__)


class PipeWireInfo:
    """Immutable snapshot of PipeWire state."""
    __slots__ = ("available", "quantum", "rate", "min_quantum", "max_quantum",
                 "allowed_rates", "driver")

    def __init__(self, available: bool = False, quantum: int = 0, rate: int = 0,
                 min_quantum: int = 0, max_quantum: int = 0,
                 allowed_rates: str = "", driver: str = ""):
        self.available = available
        self.quantum = quantum
        self.rate = rate
        self.min_quantum = min_quantum
        self.max_quantum = max_quantum
        self.allowed_rates = allowed_rates
        self.driver = driver

    def buffer_mismatch(self, requested_buffer: int) -> bool:
        """Check if there's a significant mismatch between requested and actual."""
        if not self.available or self.quantum == 0:
            return False
        return self.quantum != requested_buffer

    def mismatch_ratio(self, requested_buffer: int) -> float:
        """Ratio of actual/requested. >4x or <0.25x is a warning."""
        if not self.available or self.quantum == 0 or requested_buffer == 0:
            return 1.0
        return self.quantum / requested_buffer

    def __repr__(self):
        if not self.available:
            return "PipeWireInfo(not available)"
        return (f"PipeWireInfo(quantum={self.quantum}, rate={self.rate}, "
                f"driver={self.driver!r})")


class PipeWireMonitor:
    """Query and control PipeWire audio server settings.

    All subprocess calls use timeout=2 to prevent blocking.
    """

    _instance: Optional["PipeWireMonitor"] = None

    @classmethod
    def instance(cls) -> "PipeWireMonitor":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._last_info: Optional[PipeWireInfo] = None
        self._lock = threading.Lock()

    @property
    def last_info(self) -> Optional[PipeWireInfo]:
        return self._last_info

    def is_pipewire_running(self) -> bool:
        """Check if PipeWire is the active audio server."""
        try:
            result = subprocess.run(
                ["pw-cli", "info", "0"],
                capture_output=True, text=True, timeout=2,
            )
            return result.returncode == 0
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False

    def query(self) -> PipeWireInfo:
        """Query current PipeWire quantum and sample rate.

        Uses pw-metadata to get the global settings.
        Returns PipeWireInfo with available=False if PipeWire is not running.
        """
        info = PipeWireInfo()
        try:
            result = subprocess.run(
                ["pw-metadata", "-n", "settings", "0"],
                capture_output=True, text=True, timeout=2,
            )
            if result.returncode != 0:
                self._last_info = info
                return info

            quantum = 0
            rate = 0
            min_q = 0
            max_q = 0
            allowed = ""

            for line in result.stdout.splitlines():
                try:
                    if "clock.quantum'" in line and "quantum-limit" not in line and "quantum-current" not in line:
                        quantum = self._extract_value_int(line)
                    elif "clock.rate'" in line and "allowed" not in line:
                        rate = self._extract_value_int(line)
                    elif "clock.quantum-min" in line:
                        min_q = self._extract_value_int(line)
                    elif "clock.quantum-max" in line:
                        max_q = self._extract_value_int(line)
                    elif "clock.allowed-rates" in line:
                        allowed = self._extract_value_str(line)
                except (ValueError, IndexError):
                    continue

            # Also try to get the driver name
            driver = self._query_driver()

            info = PipeWireInfo(
                available=True,
                quantum=quantum,
                rate=rate,
                min_quantum=min_q,
                max_quantum=max_q,
                allowed_rates=allowed,
                driver=driver,
            )

        except FileNotFoundError:
            log.debug("pw-metadata not found — PipeWire not installed")
        except subprocess.TimeoutExpired:
            log.warning("pw-metadata timed out")
        except Exception as e:
            log.debug("PipeWire query failed: %s", e)

        self._last_info = info
        return info

    def query_async(self, callback=None):
        """Query PipeWire in background thread.

        Args:
            callback: Optional callable(PipeWireInfo) called on completion.
        """
        def _run():
            info = self.query()
            if callback is not None:
                try:
                    callback(info)
                except Exception as e:
                    log.debug("PipeWire callback error: %s", e)

        t = threading.Thread(target=_run, daemon=True, name="pw-query")
        t.start()

    def set_quantum(self, quantum: int) -> bool:
        """Set PipeWire quantum (buffer size).

        Uses pw-metadata to change the global quantum.
        Returns True on success.
        """
        if quantum < 16 or quantum > 65536:
            log.warning("Invalid quantum: %d (must be 16–65536)", quantum)
            return False
        try:
            result = subprocess.run(
                ["pw-metadata", "-n", "settings", "0",
                 "clock.force-quantum", str(quantum)],
                capture_output=True, text=True, timeout=2,
            )
            if result.returncode == 0:
                log.info("PipeWire quantum set to %d", quantum)
                return True
            else:
                log.warning("pw-metadata set quantum failed: %s", result.stderr)
                return False
        except FileNotFoundError:
            log.warning("pw-metadata not found")
            return False
        except Exception as e:
            log.warning("Failed to set PipeWire quantum: %s", e)
            return False

    def set_rate(self, rate: int) -> bool:
        """Set PipeWire sample rate.

        Uses pw-metadata to change the global rate.
        Returns True on success.
        """
        if rate not in (22050, 44100, 48000, 88200, 96000, 176400, 192000):
            log.warning("Unusual sample rate: %d", rate)
        try:
            result = subprocess.run(
                ["pw-metadata", "-n", "settings", "0",
                 "clock.force-rate", str(rate)],
                capture_output=True, text=True, timeout=2,
            )
            if result.returncode == 0:
                log.info("PipeWire rate set to %d", rate)
                return True
            else:
                log.warning("pw-metadata set rate failed: %s", result.stderr)
                return False
        except FileNotFoundError:
            return False
        except Exception as e:
            log.warning("Failed to set PipeWire rate: %s", e)
            return False

    def sync_to_daw(self, sample_rate: int, buffer_size: int) -> bool:
        """Sync PipeWire quantum and rate to match DAW settings.

        Returns True if both succeeded.
        """
        ok_rate = self.set_rate(sample_rate)
        ok_quantum = self.set_quantum(buffer_size)
        return ok_rate and ok_quantum

    # === Internal helpers ===

    @staticmethod
    def _extract_value_int(line: str) -> int:
        """Extract integer value from pw-metadata output line.

        Format: key:'clock.quantum' value:'1024' type:''
        """
        parts = line.split("value:'")
        if len(parts) >= 2:
            return int(parts[1].split("'")[0])
        return 0

    @staticmethod
    def _extract_value_str(line: str) -> str:
        parts = line.split("value:'")
        if len(parts) >= 2:
            return parts[1].split("'")[0]
        return ""

    @staticmethod
    def _query_driver() -> str:
        """Get PipeWire audio driver name (e.g., 'pipewire-pulse', 'alsa')."""
        try:
            result = subprocess.run(
                ["pw-cli", "info", "0"],
                capture_output=True, text=True, timeout=2,
            )
            if result.returncode == 0:
                for line in result.stdout.splitlines():
                    if "media.class" in line or "node.name" in line:
                        parts = line.split("=")
                        if len(parts) >= 2:
                            return parts[1].strip().strip('"')
        except Exception:
            pass
        return ""
