"""BRRR Plugin — ChronoScaleStudio Flutter-Synthesizer.

Plugin-ID: chrono.brrr
"""
from .brrr_engine import BrrrEngine
from .brrr_widget import BrrrWidget

__all__ = ["BrrrEngine", "BrrrWidget"]
