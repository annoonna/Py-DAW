"""
pydaw.flux.audio_preview
========================

**Mini-F-1: lokales Audio-Preview für FLUX-Patches.**

Rendert den aktuellen Patch in Python (numpy) und spielt das Ergebnis
über `sounddevice` direkt zum System-Audio-Output. Das ist KEIN
echtes Audio-Routing zur DAW-Track (das ist F-1 vollständig — kommt
in einer separaten Session). Diese Mini-Variante existiert, damit
Anno **sofort hören** kann was sein Patch macht, ohne auf die volle
Track-Integration zu warten.

Funktionsweise
--------------

1. **Topo-Sort** der Module via Kahn's Algorithmus. Reihenfolge wird
   gespeichert; bei Zyklen werden überschüssige Module ignoriert
   (warning), nicht gecrasht.

2. **Block-Loop** über `duration * sr / block_size` Blöcke. In jedem
   Block:
   * Pro Modul (in Topo-Reihenfolge): Inputs sammeln aus
     vorhergehenden Modul-Outputs, Modul-Funktion ausführen,
     Output cachen.
   * Heimdall.MasterOut als Senke: schreibt direkt in den
     globalen Output-Buffer.

3. **Anti-Click-Fade** (5 ms in/out) damit der Start/Stopp nicht knackt.

4. **sounddevice.play()** asynchron, nicht-blockierend. Stop-Befehl
   möglich via `stop()`.

Modul-Implementationen
----------------------

In dieser Datei sind die DSP-Implementationen der drei F-0 Module
(Bragi.SineOsc, Forseti.Lowpass, Heimdall.MasterOut) **dupliziert**
aus der Rust-Seite. Das ist Absicht für Mini-F-1 — vollständige F-1
ersetzt diese Python-Schicht durch Rust-IPC. Solange die Rust-Engine
für FLUX noch nicht angebunden ist, brauchen wir die Python-Variante.

Wenn jemand ein neues Modul anlegt, muss er es **hier zusätzlich**
in `_process_module()` implementieren — sonst wird es im Test-Play
einfach übersprungen (silent passthrough). Das ist akzeptabel weil
diese Datei eh nur fürs Preview zuständig ist; die Audio-Wahrheit
liegt in Rust.
"""

from __future__ import annotations

import logging
import math
import random
import socket
from collections import deque
from typing import Any, Optional

import numpy as np

from pydaw.flux.osc_codec import encode_osc, decode_osc
from pydaw.flux.patch_model import (
    Patch, Module, PortKind, PortDirection, Connection,
)


logger = logging.getLogger(__name__)


DEFAULT_SR    = 48000
DEFAULT_BLOCK = 256
DEFAULT_DUR   = 2.0


# v0.0.21.216 — Vör.Select Kind-Index → Kind-String Mapping.
# Float-Properties-Panel hat nur numerische Spinboxes, daher wird der
# Match-Kind als Index gespeichert und hier in einen Strings übersetzt.
# Convention dokumentiert in module_library.make_voer_select(). Stable
# Reihenfolge — neue Kinds werden nur hinten angehängt (Forward-Compat).
_VOER_SELECT_KIND_MAP: dict[int, str] = {
    1: "bang",
    2: "float",
    3: "int",
    4: "symbol",
    5: "list",
}


class FluxAudioPreview:
    """Single-Use Preview-Player. Eine Instanz pro Anwendung reicht."""

    def __init__(self, sr: int = DEFAULT_SR, block_size: int = DEFAULT_BLOCK):
        self.sr = sr
        self.block_size = block_size
        self._sd = None
        self._available = self._try_init_sounddevice()
        # v0.0.21.171: Per-Modul Audio-Aktivität (für UI-Pulse-Animation)
        # module_id -> letzter RMS-Wert (0..1). Wird vom Canvas alle 50ms gelesen.
        self._module_activity: dict[str, float] = {}
        # Decay-Faktor pro UI-Tick (smoother fade-out wenn Audio stoppt)
        self._activity_decay = 0.92
        # v0.0.21.220 — CV→RUNE Reverse-Pulse-Bridge state.
        # Per (target_module_id, target_port_name): boolean ob der
        # letzte Block-CV-Wert > 0.5 war. Verwendet für rising-edge-
        # detection, damit ein Frigg.Bang/Toggle/SparkBang etc. einen
        # Rune-Bang erzeugt wenn der CV-Wert von 0 auf >0.5 wechselt.
        # Persistent über Block-Grenzen (sonst entstünde im Block 1
        # immer eine false rising edge bei dauer-aktiven UI-Widgets;
        # so erzeugt Anno's PulseRing(0.63) genau 1 Init-Bang).
        self._cv_to_rune_prev: dict[tuple[str, str], bool] = {}
        # v0.0.21.229 — Forward-Pulse-Bridge Sample-and-Hold state.
        # Vorher (v.219): jede dict-Message → 1.0, sonst 0.0. Das ist
        # gate-Semantik und verschluckt numerische Werte (z.B.
        # Ullr.Random → SineOsc.frequency liefert 1 Hz statt der
        # tatsächlichen Frequenz). Anno-Bug: „flux macht random nichts
        # in frequenz".
        # Neu: int/float-Messages werden als Skalar gehalten
        # (sample-and-hold across blocks), bang/symbol bleiben 1.0
        # Pulse-Semantik, leere Liste → letzten Wert beibehalten.
        # Per (target_module_id, target_port_name): float oder None.
        self._fwd_sah_state: dict[tuple[str, str], float] = {}
        # v0.0.21.229 — Living Patterns Foundation: observed_tags-
        # Tracking. Wenn Module.dynamic_outputs=True und nicht frozen,
        # protokolliert der Renderer alle eingehenden Werte pro
        # (module_id, port_name) als sortierte Liste eindeutiger
        # Werte. Cap bei 32 Werten (älteste werden verdrängt) damit
        # ein Random-Stream nicht das RAM frisst. Diese Daten werden
        # vom Patch-Modell konsumiert (UI in v.230-231).
        self._observed_tags: dict[tuple[str, str], list] = {}
        self._observed_tags_max = 32  # cap pro port
        # v0.0.21.231 — Frigg.NumberFlow Live-Probe: pro module_id
        # der zuletzt gesehene Skalar-Wert am cv_in. Wird vom
        # FluxScene-Tick gepollt und ans NumberFlowWidget gepusht.
        # Defensive: bleibt einfach ein leerer dict wenn keine
        # NumberFlow-Module im Patch sind.
        self._module_values: dict[str, float] = {}

    def _try_init_sounddevice(self) -> bool:
        try:
            import sounddevice as sd
            self._sd = sd
            return True
        except Exception as e:
            logger.info(
                "[FLUX-PREVIEW] sounddevice nicht verfügbar (%s) — "
                "installiere mit: pip install sounddevice", e,
            )
            return False

    @property
    def available(self) -> bool:
        return self._available

    # ─── Modul-Aktivität für UI-Pulse-Animation ────────────────────

    def get_activity(self, module_id: str) -> float:
        """Liefert die letzte gemessene RMS-Amplitude eines Moduls (0..1).

        Wird vom Canvas-Tick (50 ms) gelesen. Decay 0.92 pro Tick sorgt für
        smoothes Ausklingen — sobald keine neuen Werte geschrieben werden,
        fadet die Aktivität in ~25 Ticks (= 1.25 s) auf null ab.
        """
        return float(self._module_activity.get(module_id, 0.0))

    def tick_activity_decay(self) -> None:
        """Vom Canvas-Tick aufzurufen — fadet alle Aktivitäten ab."""
        for k in list(self._module_activity.keys()):
            v = self._module_activity[k] * self._activity_decay
            if v < 0.001:
                del self._module_activity[k]
            else:
                self._module_activity[k] = v

    def reset_activity(self) -> None:
        self._module_activity.clear()

    # v0.0.21.231 — NumberFlow Live-Probe API
    def get_module_value(self, module_id: str) -> Optional[float]:
        """Letzter Skalar-Wert am cv_in eines Frigg.NumberFlow-Moduls.

        Return None wenn der Renderer noch nichts gesehen hat oder das
        Modul kein NumberFlow ist. FluxScene-Tick (50 ms) liest das aus
        und pusht es ins NumberFlowWidget via ``set_value(emit_signal=False)``.
        """
        if module_id not in self._module_values:
            return None
        return float(self._module_values[module_id])

    def reset_module_values(self) -> None:
        self._module_values.clear()

    # ─── Public API ─────────────────────────────────────────────

    def play_patch(self, patch: Patch, duration_sec: float = DEFAULT_DUR) -> tuple[bool, str]:
        """Rendere und spiele den Patch.

        Returns:
            (success, message) — bei Misserfolg enthält message den Grund.

        v0.0.21.241: integrierter Diagnose-Service. Wenn der Patch
        offensichtliche Routing-Probleme hat (kein MasterOut, keine
        audio_in_l/r-Connection, Knob auf 0, Mtof ohne Trigger),
        wird ein User-facing Hinweis statt eines stillen Renders
        zurückgegeben — gegen Anno's „einige der oszilatoren
        funktionieren nicht und sind stumm"-Frust.
        """
        if not self._available or self._sd is None:
            return False, ("sounddevice nicht installiert. Bitte ausführen: "
                          "~/myenv/bin/pip install sounddevice soundfile numpy")
        if not patch.modules:
            return False, "Leerer Patch — füge mindestens ein Modul hinzu"

        # v0.0.21.241: Pre-Render Diagnose. Wenn fundamentale Errors da
        # sind (kein Master, keine Connection), zeigen wir die direkt
        # statt zu rendern — das spart Compute und gibt klare UX.
        try:
            from pydaw.flux.diagnostics import (
                diagnose_patch, format_diagnosis_summary,
            )
            diags = diagnose_patch(patch)
            errors = [d for d in diags if d.severity == 'error']
            if errors:
                # Nicht rendern — direkt User-Hinweis zurück
                return False, format_diagnosis_summary(errors, max_lines=2)
        except Exception as e:
            # Diagnose-Fehler dürfen play_patch nicht crashen
            logger.warning("[FLUX-PREVIEW] Diagnose failed: %s", e)
            diags = []

        try:
            audio = self._render_patch(patch, duration_sec)
        except Exception as e:
            logger.warning("[FLUX-PREVIEW] Render-Fehler: %s", e)
            return False, f"Render-Fehler: {e}"

        if audio is None or audio.size == 0:
            return False, "Patch hat kein Audio erzeugt — fehlt Heimdall.MasterOut?"

        peak = float(np.max(np.abs(audio)))
        if peak < 1e-6:
            # Gerendert aber stumm — zeig die Warnings die wir oben
            # gefunden hatten (zero_gain, orphan_oscillator, mtof_no_trigger)
            try:
                from pydaw.flux.diagnostics import format_diagnosis_summary
                warns = [d for d in diags if d.severity == 'warning']
                if warns:
                    return True, "Stumm: " + format_diagnosis_summary(
                        warns, max_lines=2,
                    )
            except Exception:
                pass
            return True, "Gerendert, aber stumm (peak < -120 dB) — Verbindung zum MasterOut fehlt?"

        try:
            self._sd.stop()  # vorherige Wiedergabe abbrechen
            self._sd.play(audio, samplerate=self.sr, blocking=False)
            # v.241: Bei nicht-error Warnings (orphan, mono-only, etc.)
            # spielen wir dennoch ab UND zeigen den Hinweis. Das ist
            # nicht-blockierend (User hört Sound, sieht aber: „nur L
            # verbunden" als Hinweis).
            try:
                from pydaw.flux.diagnostics import format_diagnosis_summary
                warns = [d for d in diags if d.severity == 'warning']
                msg = f"▶ Spiele {duration_sec:.1f}s (peak {20*np.log10(peak):.1f} dBFS)"
                if warns:
                    msg += " · " + format_diagnosis_summary(warns, max_lines=1)
                return True, msg
            except Exception:
                return True, f"▶ Spiele {duration_sec:.1f}s (peak {20*np.log10(peak):.1f} dBFS)"
        except Exception as e:
            return False, f"sounddevice.play() Fehler: {e}"

    def stop(self) -> None:
        if self._sd is not None:
            try:
                self._sd.stop()
            except Exception:
                pass

    # ─── Render-Pipeline ─────────────────────────────────────────

    def _render_patch(self, patch: Patch, duration_sec: float) -> Optional[np.ndarray]:
        """Hauptrender — gibt np.ndarray (n_samples, 2) Stereo zurück."""
        n_samples = int(duration_sec * self.sr)
        n_blocks  = (n_samples + self.block_size - 1) // self.block_size
        total_n   = n_blocks * self.block_size

        out_l = np.zeros(total_n, dtype=np.float32)
        out_r = np.zeros(total_n, dtype=np.float32)

        # Topo-Sort
        order = self._topo_sort(patch)
        if not order:
            return None

        # Per-Modul-State (z.B. Oszillator-Phase, Filter-Memory)
        states: dict[str, dict] = {m.id: self._init_module_state(m) for m in patch.modules}

        # Master-Out finden — wir nehmen das ERSTE Heimdall.MasterOut-Modul
        master = next(
            (m for m in patch.modules if m.god == "Heimdall" and m.kind == "MasterOut"),
            None,
        )
        if master is None:
            logger.info("[FLUX-PREVIEW] Kein Heimdall.MasterOut im Patch — Nutze letztes Modul mit audio_out")
            # Fallback: letztes Modul, das einen "audio_out"-Port hat
            for m in reversed(patch.modules):
                if any(p.name == "audio_out" for p in m.outputs):
                    master = m
                    break

        # ─── Block-Loop ─────────────────────────────────────
        for blk in range(n_blocks):
            # block_outputs: module_id -> dict[port_name, ndarray]
            block_outputs: dict[str, dict[str, np.ndarray]] = {}
            for mid in order:
                module = patch.get_module(mid)
                if module is None:
                    continue
                inputs = self._gather_inputs(module, patch, block_outputs)
                outputs = self._process_module(module, states[mid], inputs)
                if outputs:
                    block_outputs[mid] = outputs
                # v0.0.21.171: Aktivität sammeln — RMS des größten Audio-
                # Outputs oder der größten Audio-Eingabe (für Senken wie
                # MasterOut). Nur jedes 4. Block-Update um Overhead niedrig
                # zu halten (12.5 Updates/sec).
                if blk % 4 == 0:
                    rms = self._compute_module_rms(outputs, inputs)
                    if rms is not None:
                        prev = self._module_activity.get(mid, 0.0)
                        # Smoothing: max(neuer Wert, leicht abgeklungener alter)
                        self._module_activity[mid] = max(rms, prev * 0.7)

            # Master-Out in globalen Buffer
            if master is not None:
                master_inputs = self._gather_inputs(master, patch, block_outputs)
                gain = float(master.params.get("gain", 1.0))
                if master.kind == "MasterOut":
                    l = master_inputs.get("audio_in_l", np.zeros(self.block_size, dtype=np.float32))
                    r = master_inputs.get("audio_in_r", np.zeros(self.block_size, dtype=np.float32))
                    if not isinstance(l, np.ndarray): l = np.full(self.block_size, l, dtype=np.float32)
                    if not isinstance(r, np.ndarray): r = np.full(self.block_size, r, dtype=np.float32)
                    s = blk * self.block_size
                    out_l[s:s + self.block_size] = l * gain
                    out_r[s:s + self.block_size] = r * gain
                else:
                    # Fallback: das gewählte Master-Modul hat audio_out
                    src_outputs = block_outputs.get(master.id, {})
                    mono = src_outputs.get("audio_out", np.zeros(self.block_size, dtype=np.float32))
                    if not isinstance(mono, np.ndarray):
                        mono = np.full(self.block_size, mono, dtype=np.float32)
                    s = blk * self.block_size
                    out_l[s:s + self.block_size] = mono * gain
                    out_r[s:s + self.block_size] = mono * gain

        # Auf gewünschte Länge zuschneiden
        stereo = np.stack([out_l[:n_samples], out_r[:n_samples]], axis=-1)

        # Anti-Click: 5ms Fade in/out, plus weicher Limiter bei Overdrive
        fade_n = int(0.005 * self.sr)
        if len(stereo) > 2 * fade_n:
            stereo[:fade_n]  *= np.linspace(0.0, 1.0, fade_n, dtype=np.float32)[:, None]
            stereo[-fade_n:] *= np.linspace(1.0, 0.0, fade_n, dtype=np.float32)[:, None]
        peak = float(np.max(np.abs(stereo))) if stereo.size else 0.0
        if peak > 1.0:
            stereo /= peak  # einfaches Hard-Limit gegen Clip

        return stereo

    def _topo_sort(self, patch: Patch) -> list[str]:
        """Kahn's Algorithm: Module so sortieren, dass Inputs vor Outputs verarbeitet werden."""
        in_deg: dict[str, int] = {m.id: 0 for m in patch.modules}
        adj:    dict[str, list[str]] = {m.id: [] for m in patch.modules}
        for c in patch.connections:
            if c.source_module in adj and c.target_module in in_deg:
                adj[c.source_module].append(c.target_module)
                in_deg[c.target_module] += 1
        q = deque([m.id for m in patch.modules if in_deg[m.id] == 0])
        order: list[str] = []
        while q:
            mid = q.popleft()
            order.append(mid)
            for nxt in adj[mid]:
                in_deg[nxt] -= 1
                if in_deg[nxt] == 0:
                    q.append(nxt)
        if len(order) < len(patch.modules):
            missing = len(patch.modules) - len(order)
            logger.info("[FLUX-PREVIEW] Topo-Sort: %d Module in Zyklus übersprungen", missing)
        return order

    def _gather_inputs(self, module: Module, patch: Patch,
                       block_outputs: dict[str, dict[str, Any]]) -> dict:
        """Für jeden Input-Port: hole das passende Output-Array oder Default-Wert.

        v0.0.21.215: RUNE-Ports tragen list[dict] statt np.ndarray. Sie
        überspringen den ``val * scale + offset``-Pfad (Skalierung macht
        keinen Sinn für diskrete Messages). Default für unverbundene
        RUNE-Inputs ist eine leere Liste ``[]`` (= keine Events).

        v0.0.21.219: PERMISSIVE CONNECTIONS — Cross-Realm wird in
        `patch_model._validate_connection` jetzt zugelassen. Hier wird
        Type-Mismatch defensiv aufgelöst:
          * RUNE → Stream/CV/GATE: Bang-zu-Pulse-Bridge — Liste mit
            ≥1 Message → 1.0 (Skalar), leere Liste → 0.0. Damit triggert
            ein `Vör.Bang.rune_out` direkt einen `Vör.Spigot.gate`
            ohne explizites Bridge-Modul.
          * Stream/CV/GATE → RUNE: leere Liste. Kein implizites
            threshold-detect — das wäre Ratatosk.StreamToRune (Phase 5,
            v.225) und braucht User-konfigurierte Schwelle.
          * MIDI ↔ andere: defensive Defaults wie für unverbundene
            Ports (keine implizite MIDI-Decode-Logik).
        """
        inputs: dict[str, Any] = {}
        for port in module.inputs:
            # v0.0.21.215 — Rune-Realm: separater Pfad
            is_rune = (port.kind == PortKind.RUNE)
            conn = next(
                (c for c in patch.connections
                 if c.target_module == module.id and c.target_port == port.name),
                None,
            )
            if conn is not None:
                src = block_outputs.get(conn.source_module, {})
                if conn.source_port in src:
                    val = src[conn.source_port]
                    # v0.0.21.219 — Cross-Realm-Coercion
                    # Source-Type aus dem Wert ableiten: list = RUNE,
                    # alles andere = Stream/CV/Skalar. (MIDI-Process-
                    # Pfade existieren im Renderer aktuell nicht; falls
                    # ein MIDI-Modul später eine list[dict] schickt,
                    # wird es hier wie RUNE behandelt — was für die
                    # Pulse-Bridge sogar das richtige Verhalten ist.)
                    src_is_rune_data = isinstance(val, list)
                    if is_rune and src_is_rune_data:
                        # Klassischer RUNE→RUNE-Pfad — direkt durchreichen
                        inputs[port.name] = val
                    elif is_rune and not src_is_rune_data:
                        # v0.0.21.220 — Reverse-Pulse-Bridge:
                        # Stream/CV/GATE → RUNE: Rising-Edge-Detection.
                        # Wenn der vorherige Block-Wert ≤ 0.5 war und
                        # der aktuelle Wert > 0.5 → 1 Bang. Damit
                        # erzeugt ein Klick auf Frigg.Bang (CV-Pulse
                        # 1.0) genau einen Rune-Bang; ein Toggle-On
                        # genau einen Rune-Bang pro An-Flanke; ein
                        # animierter PulseRing einen Bang pro Pulse.
                        # Parameter-frei (Schwelle 0.5 ist hartcodiert
                        # — User-konfigurierbarer Threshold mit
                        # Hysterese kommt mit Ratatosk.StreamToRune
                        # in Phase 5 v.226+).
                        if isinstance(val, np.ndarray):
                            # Sample-genauer als np.mean: ein einziger
                            # Sample > 0.5 reicht für „high"
                            current_high = bool(np.max(val) > 0.5) if val.size else False
                        else:
                            try:
                                current_high = float(val) > 0.5
                            except (TypeError, ValueError):
                                current_high = False
                        key = (module.id, port.name)
                        prev_high = self._cv_to_rune_prev.get(key, False)
                        self._cv_to_rune_prev[key] = current_high
                        if current_high and not prev_high:
                            inputs[port.name] = [{"kind": "bang", "ts": 0}]
                        else:
                            inputs[port.name] = []
                    elif (not is_rune) and src_is_rune_data:
                        # v0.0.21.229 — Sample-and-Hold Forward-Bridge
                        # (vorher: stumpfe gate-Semantik 1.0/0.0, was
                        # numerische Werte verschluckt — z.B. Random →
                        # SineOsc.frequency liefert konstant 1 Hz).
                        #
                        # Neue Semantik:
                        #  * int/float-Message: nimm last value als
                        #    Skalar UND merke ihn für nächsten Block
                        #    (sample-and-hold).
                        #  * bang/symbol/list: Pulse 1.0 (kein
                        #    numerischer Wert vorhanden — gate-Semantik
                        #    bleibt für Bangs erhalten, Backwards-
                        #    Compat zu v.219-228).
                        #  * leere Liste (kein Event): zuletzt
                        #    gehaltenen Wert weiter ausgeben (oder 0.0
                        #    wenn noch nie ein Wert kam).
                        #
                        # Damit funktioniert Random→SineOsc.frequency
                        # ohne dass der User einen expliziten
                        # Ratatosk.RuneToStream-Adapter setzen muss.
                        sah_key = (module.id, port.name)
                        last_numeric = None
                        has_pulse = False
                        for m in val:
                            if not isinstance(m, dict):
                                continue
                            v_msg = m.get("value")
                            kind_msg = m.get("kind", "")
                            if (kind_msg in ("float", "int")
                                    and isinstance(v_msg, (int, float))):
                                last_numeric = float(v_msg)
                            else:
                                has_pulse = True
                        if last_numeric is not None:
                            self._fwd_sah_state[sah_key] = last_numeric
                            inputs[port.name] = last_numeric
                        elif has_pulse:
                            inputs[port.name] = 1.0
                        else:
                            inputs[port.name] = self._fwd_sah_state.get(
                                sah_key, 0.0)
                    else:
                        # Klassischer Stream/CV-Pfad mit optionaler
                        # Skalierung — bit-identisch zu vorher.
                        if conn.scale != 1.0 or conn.offset != 0.0:
                            val = val * conn.scale + conn.offset
                        inputs[port.name] = val
                    continue
            # Fallback: Default-Wert
            if is_rune:
                # Unverbundener RUNE-Input → leere Liste (keine Events)
                inputs[port.name] = []
            else:
                inputs[port.name] = module.params.get(port.name, port.default)
        # v0.0.21.229 — Living Patterns Foundation: observed_tags-
        # Tracking. Wenn Modul.dynamic_outputs=True und nicht frozen,
        # protokolliere alle eingehenden RUNE-Werte. Pro input-port
        # eine sortierte Liste eindeutiger Werte (bis 32 Werte cap).
        # Das Modul-Patch-Objekt selbst wird mutiert — UI v.230+
        # liest module.observed_tags direkt.
        if getattr(module, "dynamic_outputs", False) and not getattr(
            module, "frozen", False
        ):
            for port in module.inputs:
                if port.kind != PortKind.RUNE:
                    continue
                msgs = inputs.get(port.name)
                if not isinstance(msgs, list) or not msgs:
                    continue
                # Sammle Werte aus eingehenden Messages
                tags_for_port = module.observed_tags.setdefault(
                    port.name, []
                )
                # v0.0.21.238 — Living Patterns Histogramm.
                # observed_counts läuft synchron zu observed_tags. Schlüssel
                # ist repr(tag) (siehe patch_model.Module). Counter wird bei
                # jedem Sichten incrementiert — auch wenn der Tag schon in
                # observed_tags ist (zählt also Frequenz, nicht uniques).
                counts_for_port = module.observed_counts.setdefault(
                    port.name, {}
                )
                for m in msgs:
                    if not isinstance(m, dict):
                        continue
                    v_obs = m.get("value")
                    # Bang/symbol/list/None-Werte ebenfalls als
                    # Tag protokollieren (z.B. "bang" als Wert,
                    # damit User sieht dass nur Bangs ankommen).
                    if v_obs is None:
                        tag = m.get("kind", "bang")
                    elif isinstance(v_obs, (int, float)):
                        # Numerisch: 6 Nachkomma-Stellen Round für
                        # Set-uniqueness (sonst sehen 1.4999999999
                        # und 1.5 als unterschiedlich aus)
                        tag = round(float(v_obs), 6)
                    elif isinstance(v_obs, str):
                        tag = v_obs
                    elif isinstance(v_obs, list):
                        # OSC-list: nimm Path (erstes Element) als Tag
                        tag = v_obs[0] if v_obs else "list"
                    else:
                        tag = repr(v_obs)
                    if tag not in tags_for_port:
                        tags_for_port.append(tag)
                        # Cap → ältesten verwerfen (FIFO)
                        if len(tags_for_port) > self._observed_tags_max:
                            popped = tags_for_port.pop(0)
                            # v.238 — wenn Tag aus observed_tags fällt,
                            # auch den Counter loswerden damit kein leak
                            counts_for_port.pop(repr(popped), None)
                    # v.238 — Counter immer hochzählen (auch bei bekanntem Tag)
                    tag_key = repr(tag)
                    counts_for_port[tag_key] = counts_for_port.get(tag_key, 0) + 1
        return inputs

    def _init_module_state(self, module: Module) -> dict:
        """Initialer State pro Modul-Typ — Oszillator-Phase, Filter-Memory etc."""
        state = {"phase": 0.0, "z_left": 0.0, "z_right": 0.0}        # F-3: Bragi.NoiseOsc nutzt deterministischen LCG-Pseudo-RNG.
        # Seed kommt entweder aus Modul-Param oder fällt auf 12345 zurück.
        if module.god == "Bragi" and module.kind == "NoiseOsc":
            try:
                state["lcg"] = int(module.params.get("seed", 12345.0)) & 0xFFFFFFFF
            except (TypeError, ValueError):
                state["lcg"] = 12345
        # F-4: Loki.LFOSampleHold nutzt ebenfalls LCG für reproduzierbare
        # Random-Steps. Plus held_value für die Step-Hold-Logik.
        elif module.god == "Loki" and module.kind == "LFOSampleHold":
            try:
                state["lcg"] = int(module.params.get("seed", 12345.0)) & 0xFFFFFFFF
            except (TypeError, ValueError):
                state["lcg"] = 12345
            state["held_value"] = 0.0
            state["last_phase"] = 0.0  # für Tick-Erkennung (Phase-Wrap)
        # F-5: Freyr.ADSR — State-Machine für 4-Phasen-Hüllkurve.
        # Phasen: 0=idle, 1=attack, 2=decay, 3=sustain, 4=release
        elif module.god == "Freyr" and module.kind == "ADSR":
            state["adsr_phase"] = 0      # 0=idle
            state["adsr_value"] = 0.0    # aktueller Hüllkurve-Wert [0..1]
            state["last_gate"]  = 0.0    # für Edge-Erkennung
        # F-6: Forseti-Biquad-Filter (BP, Notch, EQ4-Bänder) brauchen
        # je zwei Verzögerungs-Werte (z1_x, z2_x) für Input-History und
        # (z1_y, z2_y) für Output-History. Wir reservieren sie generisch
        # damit alle Forseti-Module den gleichen State-Slot nutzen können.
        elif module.god == "Forseti" and module.kind in ("Bandpass", "Notch"):
            state["biquad_x1"] = 0.0
            state["biquad_x2"] = 0.0
            state["biquad_y1"] = 0.0
            state["biquad_y2"] = 0.0
        # Forseti.Tilt = LP- und HP-State (1-Pol je Band, identisch zu Lowpass)
        elif module.god == "Forseti" and module.kind == "Tilt":
            state["tilt_lp_z"] = 0.0
            state["tilt_hp_z"] = 0.0
        # Forseti.EQ4 = 4 unabhängige Biquad-State-Sätze
        elif module.god == "Forseti" and module.kind == "EQ4":
            for band in ("low", "lomid", "himid", "high"):
                state[f"{band}_x1"] = 0.0
                state[f"{band}_x2"] = 0.0
                state[f"{band}_y1"] = 0.0
                state[f"{band}_y2"] = 0.0
        # F-7: Iduna.Delay — Ringbuffer für 2s max @ 48kHz = 96000 samples
        # Plus 1-Pol-LP-State für Tone-Control im Feedback-Pfad.
        elif module.god == "Iduna" and module.kind == "Delay":
            max_samples = int(2.5 * self.sr)  # +Reserve für CV-Modulation
            state["delay_buf"] = np.zeros(max_samples, dtype=np.float32)
            state["delay_idx"] = 0  # Schreib-Pointer
            state["delay_buf_len"] = max_samples
            state["delay_tone_z"] = 0.0  # LP-State für Tone-Control
        # F-7: Iduna.Reverb — Schroeder-Reverb braucht 4 Comb-Buffer + 2 Allpass-Buffer
        # Comb-Längen primzahl-basiert (Schroeder-Standard, ~30-50ms-Range bei 48kHz)
        # Allpass-Längen kürzer (~5ms) zur Diffusion
        elif module.god == "Iduna" and module.kind == "Reverb":
            # Schroeder-Standard-Längen (in Samples @ 44100Hz, dann skaliert)
            scale = self.sr / 44100.0
            comb_lens = [int(l * scale) for l in (1116, 1188, 1277, 1356)]
            ap_lens   = [int(l * scale) for l in (556, 441)]
            state["comb_bufs"] = [np.zeros(l, dtype=np.float32) for l in comb_lens]
            state["comb_idxs"] = [0] * 4
            state["comb_lens"] = comb_lens
            state["comb_lp_z"] = [0.0] * 4   # 1-Pol-LP im Feedback (Damping)
            state["ap_bufs"]   = [np.zeros(l, dtype=np.float32) for l in ap_lens]
            state["ap_idxs"]   = [0, 0]
            state["ap_lens"]   = ap_lens
        # ─── FX-Glitch v0.0.21.180: Hel + Mimir + Fenrir ──────
        elif module.god == "Hel" and module.kind == "Gater":
            # Phase-Counter [0..1) für rhythmisches Gating, plus glättender
            # Smooth-State (1-Pol-LP auf das Gate-Signal selbst).
            state["gate_phase"] = 0.0
            state["smooth_z"]   = 0.0
        elif module.god == "Hel" and module.kind == "TapeStop":
            # Position [0..1] gibt aktuellen Stop-Fortschritt an: 0 = normal,
            # 1 = vollständig gestoppt. last_trigger für Edge-Detection.
            state["stop_pos"]    = 0.0
            state["last_trigger"] = 0.0
            # Pitch-Resampling-Phase: zeigt wo wir im Buffer sind beim Slow-Down
            state["resample_pos"] = 0.0
            # Mini-Buffer (200ms @ 48kHz reicht — TapeStop liest max ~Stop-Zeit)
            buf_len = int(5.0 * self.sr)  # max duration 5s
            state["ts_buf"] = np.zeros(buf_len, dtype=np.float32)
            state["ts_buf_len"] = buf_len
            state["ts_write_idx"] = 0
        elif module.god == "Mimir" and module.kind == "Stutter":
            # Buffer für Stutter-Slices (max 500ms @ 48kHz = 24000 samples)
            buf_len = int(0.6 * self.sr)
            state["stutter_buf"] = np.zeros(buf_len, dtype=np.float32)
            state["stutter_buf_len"] = buf_len
            state["stutter_write_idx"] = 0   # Schreib-Pointer (immer aktiv wenn nicht freeze)
            state["stutter_read_idx"]  = 0   # Lese-Pointer im aktuellen Slice
            state["stutter_slice_len"] = 0   # Aktuelle Slice-Länge in Samples
            state["last_freeze"]       = 0.0
        elif module.god == "Fenrir" and module.kind == "BitCrush":
            pass  # zustandslos
        elif module.god == "Fenrir" and module.kind == "Decimator":
            # Phase-Akkumulator für Sample-Hold + zuletzt gehaltener Wert
            state["dec_phase"]    = 0.0
            state["dec_held_l"]   = 0.0
            state["dec_held_r"]   = 0.0
        # ─── F-10 Thor v0.0.21.182 ──────────────────────────────
        elif module.god == "Thor" and module.kind == "TubeDrive":
            state["tone_z"] = 0.0  # 1-Pol-LP-State für Tone-Filter
        elif module.god == "Thor" and module.kind == "Fuzz":
            pass  # zustandslos
        elif module.god == "Thor" and module.kind == "Saturation":
            pass  # zustandslos
        elif module.god == "Thor" and module.kind == "WaveShaper":
            pass  # zustandslos
        # ─── F-9 Vidar v0.0.21.182 ──────────────────────────────
        elif module.god == "Vidar" and module.kind == "Compressor":
            # Envelope-Follower-State (RMS-tracking via 1-Pol-LP)
            state["env"] = 0.0
            state["gain_z"] = 1.0  # geglättete Gain-Reduction
        elif module.god == "Vidar" and module.kind == "Limiter":
            state["env"] = 0.0
            state["gain_z"] = 1.0
        elif module.god == "Vidar" and module.kind == "Gate":
            state["env"] = 0.0
            state["gain_z"] = 0.0  # 0=closed, 1=open
        # ─── F-8 Skadi v0.0.21.182 ──────────────────────────────
        elif module.god == "Skadi" and module.kind == "Chorus":
            # Stereo-Chorus: 2 unabhängige Delay-Lines (L/R) mit
            # 90° phasenversetztem LFO. Max-Delay 35ms.
            buf_len = int(0.05 * self.sr)  # 50ms Headroom
            state["chorus_buf_l"] = np.zeros(buf_len, dtype=np.float32)
            state["chorus_buf_r"] = np.zeros(buf_len, dtype=np.float32)
            state["chorus_buf_len"] = buf_len
            state["chorus_write_idx"] = 0
            state["chorus_lfo_phase"] = 0.0
        elif module.god == "Skadi" and module.kind == "Flanger":
            # Flanger: kurze Delay-Line (max 12ms) mit Feedback.
            buf_len = int(0.015 * self.sr)  # 15ms
            state["flanger_buf"] = np.zeros(buf_len, dtype=np.float32)
            state["flanger_buf_len"] = buf_len
            state["flanger_write_idx"] = 0
            state["flanger_lfo_phase"] = 0.0
        elif module.god == "Skadi" and module.kind == "Phaser":
            # Phaser: 4 Allpass-Filter in Serie. Pro Stage 1 z-Memory.
            state["phaser_z"] = [0.0] * 4
            state["phaser_lfo_phase"] = 0.0
        elif module.god == "Skadi" and module.kind == "StereoImager":
            pass  # zustandslos (Mid/Side ist algebraisch)
        # v0.0.21.215 — Phase 1 Rune-Realm
        elif module.god == "Vör" and module.kind == "Bang":
            # Block-Counter — wenn er ``period_blocks`` erreicht hat,
            # wird ein Bang emittiert und der Counter resettet.
            state["block_counter"] = 0
        elif module.god == "Vör" and module.kind == "RuneTap":
            # Empfangs-Counter (live im Properties-Panel sichtbar via
            # module.params["count"], wird per Block aktualisiert).
            state["recv_count"] = 0
        # v0.0.21.216 — Phase 2.1 Rune-Realm: Route + Select sind
        # zustandslos pro Block (alle Routing-Entscheidungen ergeben
        # sich aus der aktuellen Eingangs-Liste). Trotzdem Counter
        # für Properties-Panel-Live-Inspection.
        elif module.god == "Vör" and module.kind == "Route":
            state["seen_count"] = 0
        elif module.god == "Vör" and module.kind == "Select":
            state["match_count"] = 0
            state["miss_count"] = 0
        # v0.0.21.217 — Phase 2.2 Rune-Realm: Spigot + Trigger sind
        # ebenfalls zustandslos pro Block; Counter rein für UI.
        elif module.god == "Vör" and module.kind == "Spigot":
            state["pass_count"] = 0
            state["block_count"] = 0
        elif module.god == "Vör" and module.kind == "Trigger":
            state["fire_count"] = 0
        # v0.0.21.220 — Phase 2.4 Rune-Realm: Float + Int Producer
        # zustandslos. Counter für Properties-Live-Inspection.
        elif module.god == "Vör" and module.kind in ("Float", "Int"):
            state["emit_count"] = 0
        # v0.0.21.221 — Phase 2.5 Rune-Realm: Vör.Knob — autonomer
        # Float-Producer mit Wert-Änderungs-Detection.
        elif module.god == "Vör" and module.kind == "Knob":
            # last_value=None bedeutet „erster Block" → emit init-Wert
            state["last_value"] = None
        # v0.0.21.221-223 — Phase 3 Rune-Realm: Norns-Familie.
        elif module.god == "Norns" and module.kind == "Metro":
            # Sample-Counter wird über alle Blöcke fortgeführt damit
            # Trigger-Positionen sample-genau berechnet werden können.
            state["sample_counter"] = 0
        elif module.god == "Norns" and module.kind == "Line":
            # Ramp-State: aktiv/inaktiv, Snapshot der start/end/duration
            # beim letzten Trigger, Fortschrittszähler in Samples.
            state["active"] = False
            state["start_value"] = 0.0
            state["target_value"] = 0.0
            state["duration_samples"] = 1
            state["progress_samples"] = 0
        elif module.god == "Norns" and module.kind == "Pipe":
            # FIFO-Queue: list of (release_sample_abs, msg-dict).
            # sample_counter über Blöcke fortgeführt.
            state["queue"] = []
            state["sample_counter"] = 0
        elif module.god == "Norns" and module.kind == "Delay":
            # Single-Slot: pending_release=None bedeutet kein delay
            # aktiv. Bei neuer Message wird pending überschrieben.
            state["pending_release"] = None
            state["pending_msg"] = None
            state["sample_counter"] = 0
        # v0.0.21.224 — Phase 2.6 Rune-Realm: Vör.RouteV + SelectV.
        # Counter pro Match-Slot für Properties-Live-Inspection;
        # Module sind sonst zustandslos pro Block.
        elif module.god == "Vör" and module.kind in ("RouteV", "SelectV"):
            state["match_count"] = [0, 0, 0, 0]  # pro Slot
            state["miss_count"] = 0
        # v0.0.21.228 — Phase 6 Rune-Realm: Hermod-Familie (OSC).
        elif module.god == "Hermod" and module.kind == "OscReceive":
            # UDP-Socket einmalig öffnen. Bei Bind-Fehler (Port belegt
            # oder permission denied) bleibt socket=None und Modul ist
            # silent — kein Crash für audio_preview.
            try:
                port = int(module.params.get("port", 9000))
            except (TypeError, ValueError):
                port = 9000
            sock = None
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                sock.setblocking(False)
                # SO_REUSEADDR damit Patch-Reload nicht "address in use"
                # wirft (UDP allows multiple binds with REUSEADDR).
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                sock.bind(("0.0.0.0", port))
                logger.info("[Hermod.OscReceive] listening on UDP :%d", port)
            except OSError as e:
                logger.warning(
                    "[Hermod.OscReceive] bind UDP :%d fehlgeschlagen: %s",
                    port, e)
                if sock is not None:
                    try: sock.close()
                    except Exception: pass
                sock = None
            state["socket"] = sock
            state["bound_port"] = port
            state["recv_count"] = 0
            state["error_count"] = 0
        elif module.god == "Hermod" and module.kind == "OscSend":
            # Send-Socket pro Modul (kann zu beliebigen hosts senden).
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                sock.setblocking(False)
            except OSError as e:
                logger.warning("[Hermod.OscSend] socket fail: %s", e)
                sock = None
            state["socket"] = sock
            state["sent_count"] = 0
            state["error_count"] = 0
        elif module.god == "Hermod" and module.kind == "OscPath":
            # Zustandslos — nur Counter
            state["match_count"] = 0
            state["miss_count"] = 0
        elif module.god == "Hermod" and module.kind == "OscPrint":
            state["print_count"] = 0
        return state

    def _process_module(self, module: Module, state: dict,
                        inputs: dict) -> dict[str, np.ndarray]:
        """Block-Verarbeitung pro Modul-Typ.

        Wenn ein Modul-Typ hier nicht implementiert ist, gibt's keine
        Outputs — das Modul ist ein silent passthrough. Folge-Sessions
        ergänzen die DSP für jedes neue Modul.
        """
        n = self.block_size
        outputs: dict[str, np.ndarray] = {}

        # v0.0.21.231 — Frigg.NumberFlow Live-Probe (BEFORE is_ui_widget
        # early-return weil NumberFlow trotz Frigg-Familie sowohl Input
        # als auch Output hat — es ist kein passives Display, sondern
        # ein Inline-Probe). Anno-Auftrag: „number modul mit ein und
        # ausgängen ich will an lfo sehen ob da was durch kommt".
        #
        # Verhalten:
        #   1. Liest cv_in als Skalar (block-rate; reicht für die UI-
        #      Anzeige bei ~20 Hz Repaint)
        #   2. Publiziert den Wert in self._module_values[module.id]
        #      (FluxScene-Tick liest das aus und pusht ins Widget)
        #   3. Schreibt den Skalar als Konstante in cv_out (passthrough;
        #      die Block-Konstante wird in _gather_inputs vom Ziel-
        #      Modul wieder skalarized — kein Information-Loss bei
        #      block-rate-CV)
        if module.god == "Frigg" and module.kind == "NumberFlow":
            try:
                cv_value = float(self._scalarize(
                    inputs.get("cv_in"),
                    module.params.get("cv_in", 0.0),
                ))
            except (TypeError, ValueError):
                cv_value = 0.0
            # Defensive: NaN/Inf nicht ans UI durchreichen
            if not (cv_value == cv_value and cv_value != float("inf")
                    and cv_value != float("-inf")):
                cv_value = 0.0
            self._module_values[module.id] = cv_value
            outputs["cv_out"] = float(cv_value)
            return outputs

        # v0.0.21.220 — UI-Widget-Process-Stub: Frigg-Widgets (Knob,
        # Toggle, Bang, SparkBang, PulseRing, RuneToggle, ...) haben
        # keinen DSP — sie schreiben ihren `params["value"]` über die
        # `UiModuleBridge` direkt in die target-params der verbundenen
        # Module (Engine-Pfad). Im audio_preview-Pfad waren sie
        # bisher unsichtbar als source — das blockierte CV→RUNE
        # Rising-Edge-Detection (Anno-Direktive: „wie soll ich Bang
        # auslösen?"). Jetzt liefern sie ihren Wert auf alle ihre
        # Output-Ports — der Renderer kann darauf rising-edge-detect
        # machen und Rune-Bangs erzeugen.
        if module.is_ui_widget():
            try:
                value = float(module.params.get("value", 0.0))
            except (TypeError, ValueError):
                value = 0.0
            for out_port in module.outputs:
                # CV/GATE: Skalar reicht — _scalarize / Coercion
                # wandeln das in Block-Werte um. AUDIO-Outputs gibt's
                # bei UI-Widgets nicht (per Konvention). RUNE-Outputs
                # für UI-Widgets kommen ggf. später (Frigg.RuneBang).
                if out_port.kind in (PortKind.CV, PortKind.GATE):
                    outputs[out_port.name] = float(value)
            return outputs

        if module.god == "Bragi" and module.kind == "SineOsc":
            freq = self._scalarize(inputs.get("freq", 440.0), module.params.get("freq", 440.0))
            gain = self._scalarize(inputs.get("gain", 0.5), module.params.get("gain", 0.5))
            # v0.0.21.210: MIDI-Override für Offline-Bounce.
            # Wenn `state['midi_gate']` gesetzt ist (vom Bounce-Renderer
            # injiziert) wird Freq und Gain durch MIDI gesteuert. Bei
            # midi_gate==0 bleibt Output stumm — das ist genau das was
            # ein Synth zwischen Notes tut.
            _mgate = float(state.get('midi_gate', -1.0))
            if _mgate >= 0.0:
                if _mgate > 0.5:
                    freq = float(state.get('midi_freq', freq))
                    gain = float(state.get('midi_gain', gain)) * float(gain) / max(1e-9, float(module.params.get("gain", 0.5)))
                else:
                    gain = 0.0
            freq = max(20.0, min(20000.0, freq))
            gain = max(0.0, min(1.0, gain))
            phase = state["phase"]
            phase_inc = 2.0 * np.pi * freq / self.sr
            t = np.arange(n, dtype=np.float32)
            wave = (np.sin(phase + phase_inc * t) * gain).astype(np.float32)
            state["phase"] = (phase + phase_inc * n) % (2.0 * np.pi)
            outputs["audio_out"] = wave

        elif module.god == "Bragi" and module.kind == "SawOsc":
            # F-3: Naive Sägezahn — Phase normiert auf [0, 1), Wave = 2*phase - 1.
            # Aliasing bei hohen Frequenzen erwartet; Polished BLEP kommt später.
            freq = self._scalarize(inputs.get("freq", 220.0), module.params.get("freq", 220.0))
            gain = self._scalarize(inputs.get("gain", 0.5), module.params.get("gain", 0.5))
            # v0.0.21.210: MIDI-Override siehe SineOsc-Kommentar
            _mgate = float(state.get('midi_gate', -1.0))
            if _mgate >= 0.0:
                if _mgate > 0.5:
                    freq = float(state.get('midi_freq', freq))
                    gain = float(state.get('midi_gain', gain)) * float(gain) / max(1e-9, float(module.params.get("gain", 0.5)))
                else:
                    gain = 0.0
            freq = max(20.0, min(20000.0, freq))
            gain = max(0.0, min(1.0, gain))
            # state["phase"] kommt aus dem Sine-Path mit Bereich [0, 2π).
            # Wir interpretieren denselben State als normalisierte Phase [0, 1)
            # via /(2π). Damit teilen Sine/Saw/Square/Tri denselben State-Slot.
            phase_norm = (state["phase"] / (2.0 * np.pi)) % 1.0
            phase_inc_norm = freq / self.sr
            ph = phase_norm + phase_inc_norm * np.arange(n, dtype=np.float32)
            ph = ph % 1.0
            wave = ((2.0 * ph - 1.0) * gain).astype(np.float32)
            new_phase_norm = (phase_norm + phase_inc_norm * n) % 1.0
            state["phase"] = float(new_phase_norm * 2.0 * np.pi)
            outputs["audio_out"] = wave

        elif module.god == "Bragi" and module.kind == "SquareOsc":
            # F-3: Naive Rechteck/Puls — phase < pulse_width: +1, sonst -1.
            freq = self._scalarize(inputs.get("freq", 220.0), module.params.get("freq", 220.0))
            gain = self._scalarize(inputs.get("gain", 0.5), module.params.get("gain", 0.5))
            pw = self._scalarize(inputs.get("pulse_width", 0.5), module.params.get("pulse_width", 0.5))
            # v0.0.21.210: MIDI-Override siehe SineOsc-Kommentar
            _mgate = float(state.get('midi_gate', -1.0))
            if _mgate >= 0.0:
                if _mgate > 0.5:
                    freq = float(state.get('midi_freq', freq))
                    gain = float(state.get('midi_gain', gain)) * float(gain) / max(1e-9, float(module.params.get("gain", 0.5)))
                else:
                    gain = 0.0
            freq = max(20.0, min(20000.0, freq))
            gain = max(0.0, min(1.0, gain))
            pw = max(0.05, min(0.95, pw))
            phase_norm = (state["phase"] / (2.0 * np.pi)) % 1.0
            phase_inc_norm = freq / self.sr
            ph = (phase_norm + phase_inc_norm * np.arange(n, dtype=np.float32)) % 1.0
            wave = (np.where(ph < pw, 1.0, -1.0) * gain).astype(np.float32)
            new_phase_norm = (phase_norm + phase_inc_norm * n) % 1.0
            state["phase"] = float(new_phase_norm * 2.0 * np.pi)
            outputs["audio_out"] = wave

        elif module.god == "Bragi" and module.kind == "TriangleOsc":
            # F-3: Dreieck via 4·|phase - 0.5| - 1 → bipolar, lineare Flanken.
            freq = self._scalarize(inputs.get("freq", 220.0), module.params.get("freq", 220.0))
            gain = self._scalarize(inputs.get("gain", 0.5), module.params.get("gain", 0.5))
            # v0.0.21.210: MIDI-Override siehe SineOsc-Kommentar
            _mgate = float(state.get('midi_gate', -1.0))
            if _mgate >= 0.0:
                if _mgate > 0.5:
                    freq = float(state.get('midi_freq', freq))
                    gain = float(state.get('midi_gain', gain)) * float(gain) / max(1e-9, float(module.params.get("gain", 0.5)))
                else:
                    gain = 0.0
            freq = max(20.0, min(20000.0, freq))
            gain = max(0.0, min(1.0, gain))
            phase_norm = (state["phase"] / (2.0 * np.pi)) % 1.0
            phase_inc_norm = freq / self.sr
            ph = (phase_norm + phase_inc_norm * np.arange(n, dtype=np.float32)) % 1.0
            wave = ((4.0 * np.abs(ph - 0.5) - 1.0) * gain).astype(np.float32)
            new_phase_norm = (phase_norm + phase_inc_norm * n) % 1.0
            state["phase"] = float(new_phase_norm * 2.0 * np.pi)
            outputs["audio_out"] = wave

        elif module.god == "Bragi" and module.kind == "NoiseOsc":
            # F-3: White Noise via deterministischem LCG (Numerical Recipes Konstanten).
            # Reproduzierbar bei gleichem Seed — wichtig für Patch-Diffs.
            gain = self._scalarize(inputs.get("gain", 0.5), module.params.get("gain", 0.5))
            gain = max(0.0, min(1.0, gain))
            lcg = int(state.get("lcg", 12345)) & 0xFFFFFFFF
            samples = np.empty(n, dtype=np.float32)
            for i in range(n):
                lcg = (lcg * 1664525 + 1013904223) & 0xFFFFFFFF
                # Auf [-1, +1] mappen
                samples[i] = ((lcg / 0x80000000) - 1.0)
            state["lcg"] = lcg
            outputs["audio_out"] = (samples * gain).astype(np.float32)

        elif module.god == "Loki" and module.kind == "LFOSine":
            # F-4: Sinus-LFO. Bipolarer CV-Output [-depth, +depth].
            # Phase wird normiert auf [0, 1) gehalten, anders als bei den
            # Audio-Oszillatoren (die intern in [0, 2π) arbeiten); LFOs
            # haben keinen geteilten phase-State mit anderen Modulen.
            # v0.0.21.231: ``phase``-Port liefert Initial-Offset [0..1].
            # Wird einmalig beim ersten Block verwendet (state["phase_init_done"])
            # damit der User mehrere LFOs phasen-versetzt laufen lassen kann.
            rate  = self._scalarize(inputs.get("rate",  2.0), module.params.get("rate",  2.0))
            depth = self._scalarize(inputs.get("depth", 1.0), module.params.get("depth", 1.0))
            rate  = max(0.01, min(50.0, rate))
            depth = max(0.0,  min(1.0,  depth))
            if not state.get("phase_init_done"):
                phase_off = self._scalarize(
                    inputs.get("phase"),  # None if not connected → falls back to module.params
                    module.params.get("phase", 0.0),
                )
                state["phase"] = float(phase_off) % 1.0
                state["phase_init_done"] = True
            phase_norm = state["phase"]
            phase_inc_norm = rate / self.sr
            ph = (phase_norm + phase_inc_norm * np.arange(n, dtype=np.float32)) % 1.0
            wave = (np.sin(2.0 * np.pi * ph) * depth).astype(np.float32)
            state["phase"] = float((phase_norm + phase_inc_norm * n) % 1.0)
            outputs["cv_out"] = wave

        elif module.god == "Loki" and module.kind == "LFOTriangle":
            # F-4: Dreieck-LFO via 4·|phase-0.5|-1 → [-depth, +depth].
            # v.231: phase-Port als Initial-Offset (siehe LFOSine).
            rate  = self._scalarize(inputs.get("rate",  2.0), module.params.get("rate",  2.0))
            depth = self._scalarize(inputs.get("depth", 1.0), module.params.get("depth", 1.0))
            rate  = max(0.01, min(50.0, rate))
            depth = max(0.0,  min(1.0,  depth))
            if not state.get("phase_init_done"):
                phase_off = self._scalarize(
                    inputs.get("phase"),
                    module.params.get("phase", 0.0),
                )
                state["phase"] = float(phase_off) % 1.0
                state["phase_init_done"] = True
            phase_norm = state["phase"]
            phase_inc_norm = rate / self.sr
            ph = (phase_norm + phase_inc_norm * np.arange(n, dtype=np.float32)) % 1.0
            wave = ((4.0 * np.abs(ph - 0.5) - 1.0) * depth).astype(np.float32)
            state["phase"] = float((phase_norm + phase_inc_norm * n) % 1.0)
            outputs["cv_out"] = wave

        elif module.god == "Loki" and module.kind == "LFOSquare":
            # F-4: Rechteck-LFO mit Pulsweite. Hartes On/Off-Schalten,
            # bipolarer Output.
            # v.231: phase-Port als Initial-Offset (siehe LFOSine).
            rate  = self._scalarize(inputs.get("rate",  2.0), module.params.get("rate",  2.0))
            depth = self._scalarize(inputs.get("depth", 1.0), module.params.get("depth", 1.0))
            pw    = self._scalarize(inputs.get("pulse_width", 0.5),
                                    module.params.get("pulse_width", 0.5))
            rate  = max(0.01, min(50.0, rate))
            depth = max(0.0,  min(1.0,  depth))
            pw    = max(0.05, min(0.95, pw))
            if not state.get("phase_init_done"):
                phase_off = self._scalarize(
                    inputs.get("phase"),
                    module.params.get("phase", 0.0),
                )
                state["phase"] = float(phase_off) % 1.0
                state["phase_init_done"] = True
            phase_norm = state["phase"]
            phase_inc_norm = rate / self.sr
            ph = (phase_norm + phase_inc_norm * np.arange(n, dtype=np.float32)) % 1.0
            wave = (np.where(ph < pw, depth, -depth)).astype(np.float32)
            state["phase"] = float((phase_norm + phase_inc_norm * n) % 1.0)
            outputs["cv_out"] = wave

        elif module.god == "Loki" and module.kind == "LFOSampleHold":
            # F-4: Sample & Hold. Bei jedem Phase-Wrap wird ein neuer
            # Random-Wert aus dem LCG gewählt und bis zum nächsten Wrap
            # gehalten. Erzeugt klassische „Treppen"-Modulation.
            rate  = self._scalarize(inputs.get("rate",  4.0), module.params.get("rate",  4.0))
            depth = self._scalarize(inputs.get("depth", 1.0), module.params.get("depth", 1.0))
            rate  = max(0.01, min(50.0, rate))
            depth = max(0.0,  min(1.0,  depth))
            phase_norm = state["phase"]
            last_phase = state.get("last_phase", phase_norm)
            held = float(state.get("held_value", 0.0))
            lcg  = int(state.get("lcg", 12345)) & 0xFFFFFFFF
            phase_inc_norm = rate / self.sr
            samples = np.empty(n, dtype=np.float32)
            for i in range(n):
                cur_phase = (phase_norm + phase_inc_norm * i) % 1.0
                # Phase-Wrap erkennen → neuen Random-Step ziehen
                if cur_phase < last_phase:
                    lcg = (lcg * 1664525 + 1013904223) & 0xFFFFFFFF
                    held = (lcg / 0x80000000) - 1.0  # ∈ [-1, +1]
                samples[i] = held * depth
                last_phase = cur_phase
            state["phase"] = float((phase_norm + phase_inc_norm * n) % 1.0)
            state["last_phase"] = last_phase
            state["held_value"] = held
            state["lcg"] = lcg
            outputs["cv_out"] = samples

        elif module.god == "Freyr" and module.kind == "ADSR":
            # F-5: ADSR-State-Machine. Pro Sample werden die Stufen
            # gemäß Gate-Edge-Detection durchlaufen.
            #
            # Phasen-Codes:
            #   0 = idle   — value bleibt 0
            #   1 = attack — value steigt linear → 1.0
            #   2 = decay  — value fällt linear  → sustain_level
            #   3 = sustain— value bleibt auf sustain_level
            #   4 = release— value fällt linear  → 0
            #
            # WICHTIG: inputs.get(...)-Default = module.params.get(...) — damit
            # User-editierte Param-Werte greifen wenn keine Connection existiert.
            # (Bug-Fix für v0.0.21.177: vorher war Default hartcodiert, was
            #  user-editierte sustain/decay/release-Werte ignorierte.)
            p_attack  = float(module.params.get("attack",  0.05))
            p_decay   = float(module.params.get("decay",   0.15))
            p_sustain = float(module.params.get("sustain", 0.7))
            p_release = float(module.params.get("release", 0.4))
            attack  = self._scalarize(inputs.get("attack",  p_attack),  p_attack)
            decay   = self._scalarize(inputs.get("decay",   p_decay),   p_decay)
            sustain = self._scalarize(inputs.get("sustain", p_sustain), p_sustain)
            release = self._scalarize(inputs.get("release", p_release), p_release)
            attack  = max(0.001, min(5.0,  attack))
            decay   = max(0.001, min(5.0,  decay))
            sustain = max(0.0,   min(1.0,  sustain))
            release = max(0.001, min(10.0, release))

            # Gate kann ein Block-Array sein (von Tyr.PulseGate o.ä.) oder
            # ein Skalar (statisches Gate via Modul-Param).
            gate_in = inputs.get("gate")
            if gate_in is None:
                gate_block = np.full(n, float(module.params.get("gate", 0.0)), dtype=np.float32)
            elif np.isscalar(gate_in):
                gate_block = np.full(n, float(gate_in), dtype=np.float32)
            else:
                gate_block = np.asarray(gate_in, dtype=np.float32)
                if gate_block.size != n:
                    # Fallback: konstant aus erstem Sample
                    gate_block = np.full(n, float(gate_block.flat[0]) if gate_block.size else 0.0,
                                         dtype=np.float32)

            phase_idx  = int(state.get("adsr_phase", 0))
            value      = float(state.get("adsr_value", 0.0))
            last_gate  = float(state.get("last_gate", 0.0))

            # Inkremente pro Sample
            attack_inc  = 1.0 / max(1.0, attack  * self.sr)
            decay_inc   = (1.0 - sustain) / max(1.0, decay * self.sr)
            release_inc = 1.0 / max(1.0, release * self.sr)

            samples = np.empty(n, dtype=np.float32)
            for i in range(n):
                gate_now = float(gate_block[i])
                # Gate-Edge-Detection (Schwelle 0.5)
                gate_on  = gate_now >= 0.5
                last_on  = last_gate >= 0.5
                if gate_on and not last_on:
                    # Rising edge → starte Attack
                    phase_idx = 1
                elif (not gate_on) and last_on:
                    # Falling edge → starte Release (egal welche Phase vorher)
                    if value > 0.0:
                        phase_idx = 4
                    else:
                        phase_idx = 0

                # Phasen-Verarbeitung
                if phase_idx == 1:           # Attack
                    value += attack_inc
                    if value >= 1.0:
                        value = 1.0
                        phase_idx = 2  # → Decay
                elif phase_idx == 2:         # Decay
                    value -= decay_inc
                    if value <= sustain:
                        value = sustain
                        phase_idx = 3  # → Sustain
                elif phase_idx == 3:         # Sustain
                    value = sustain          # halten
                elif phase_idx == 4:         # Release
                    value -= release_inc
                    if value <= 0.0:
                        value = 0.0
                        phase_idx = 0  # → Idle
                # else phase 0 (idle): value bleibt 0

                samples[i] = value
                last_gate = gate_now

            state["adsr_phase"] = phase_idx
            state["adsr_value"] = value
            state["last_gate"]  = last_gate
            outputs["cv_out"] = samples

        elif module.god == "Tyr" and module.kind == "PulseGate":
            # F-5-Hilfsmodul: rhythmischer Gate-Generator. On wenn
            # phase < pulse_width, sonst off. Outputs sind unipolar {0, 1}
            # (anders als Loki.LFOSquare das bipolar arbeitet).
            rate = self._scalarize(inputs.get("rate", 2.0), module.params.get("rate", 2.0))
            pw   = self._scalarize(inputs.get("pulse_width", 0.5),
                                   module.params.get("pulse_width", 0.5))
            rate = max(0.1,  min(50.0, rate))
            pw   = max(0.05, min(0.95, pw))
            phase_norm = state["phase"]
            phase_inc_norm = rate / self.sr
            ph = (phase_norm + phase_inc_norm * np.arange(n, dtype=np.float32)) % 1.0
            wave = np.where(ph < pw, 1.0, 0.0).astype(np.float32)
            state["phase"] = float((phase_norm + phase_inc_norm * n) % 1.0)
            outputs["gate_out"] = wave

        elif module.god == "Forseti" and module.kind == "Lowpass":
            audio_in = inputs.get("audio_in", np.zeros(n, dtype=np.float32))
            if not isinstance(audio_in, np.ndarray):
                audio_in = np.full(n, audio_in, dtype=np.float32)
            cutoff = self._scalarize(inputs.get("cutoff", 1000.0), module.params.get("cutoff", 1000.0))
            cutoff = max(20.0, min(20000.0, cutoff))
            alpha = float(1.0 - np.exp(-2.0 * np.pi * cutoff / self.sr))
            z = state["z_left"]
            out = np.empty(n, dtype=np.float32)
            for i in range(n):
                z += alpha * (audio_in[i] - z)
                out[i] = z
            state["z_left"] = z
            outputs["audio_out"] = out

        elif module.god == "Forseti" and module.kind == "Highpass":
            # F-6: 1-Pol HP via y[n] = input - lowpass(input)
            # Komplementär zu Lowpass: gleiche alpha-Berechnung, dann
            # Differenz Input-LP → echtes Hochpass-Verhalten.
            audio_in = inputs.get("audio_in", np.zeros(n, dtype=np.float32))
            if not isinstance(audio_in, np.ndarray):
                audio_in = np.full(n, audio_in, dtype=np.float32)
            p_cut = float(module.params.get("cutoff", 200.0))
            cutoff = self._scalarize(inputs.get("cutoff", p_cut), p_cut)
            cutoff = max(20.0, min(20000.0, cutoff))
            alpha = float(1.0 - np.exp(-2.0 * np.pi * cutoff / self.sr))
            z = state["z_left"]
            out = np.empty(n, dtype=np.float32)
            for i in range(n):
                z += alpha * (audio_in[i] - z)
                out[i] = audio_in[i] - z
            state["z_left"] = z
            outputs["audio_out"] = out

        elif module.god == "Forseti" and module.kind == "Bandpass":
            # F-6: Biquad-BP mit RBJ-Cookbook-Koeffizienten
            #   omega = 2π·f₀/sr
            #   alpha = sin(omega) / (2·Q)
            #   b0 = alpha,  b1 = 0,  b2 = -alpha
            #   a0 = 1+alpha, a1 = -2·cos(omega), a2 = 1-alpha
            audio_in = inputs.get("audio_in", np.zeros(n, dtype=np.float32))
            if not isinstance(audio_in, np.ndarray):
                audio_in = np.full(n, audio_in, dtype=np.float32)
            p_cut = float(module.params.get("cutoff", 800.0))
            p_res = float(module.params.get("resonance", 2.0))
            cutoff = self._scalarize(inputs.get("cutoff",    p_cut), p_cut)
            res    = self._scalarize(inputs.get("resonance", p_res), p_res)
            cutoff = max(20.0, min(20000.0, cutoff))
            res    = max(0.5, min(20.0, res))
            omega = 2.0 * np.pi * cutoff / self.sr
            sin_w = np.sin(omega)
            cos_w = np.cos(omega)
            alpha = sin_w / (2.0 * res)
            a0 = 1.0 + alpha
            b0, b1, b2 = alpha / a0, 0.0,                     -alpha / a0
            a1, a2     = -2.0 * cos_w / a0,                   (1.0 - alpha) / a0
            x1, x2 = state["biquad_x1"], state["biquad_x2"]
            y1, y2 = state["biquad_y1"], state["biquad_y2"]
            out = np.empty(n, dtype=np.float32)
            for i in range(n):
                x = float(audio_in[i])
                y = b0*x + b1*x1 + b2*x2 - a1*y1 - a2*y2
                out[i] = y
                x2, x1 = x1, x
                y2, y1 = y1, y
            state["biquad_x1"], state["biquad_x2"] = x1, x2
            state["biquad_y1"], state["biquad_y2"] = y1, y2
            outputs["audio_out"] = out

        elif module.god == "Forseti" and module.kind == "Notch":
            # F-6: Biquad-Notch mit RBJ-Cookbook-Koeffizienten
            #   b0 = 1,        b1 = -2·cos(omega), b2 = 1
            #   a0 = 1+alpha,  a1 = -2·cos(omega), a2 = 1-alpha
            audio_in = inputs.get("audio_in", np.zeros(n, dtype=np.float32))
            if not isinstance(audio_in, np.ndarray):
                audio_in = np.full(n, audio_in, dtype=np.float32)
            p_cut = float(module.params.get("cutoff", 1000.0))
            p_res = float(module.params.get("resonance", 2.0))
            cutoff = self._scalarize(inputs.get("cutoff",    p_cut), p_cut)
            res    = self._scalarize(inputs.get("resonance", p_res), p_res)
            cutoff = max(20.0, min(20000.0, cutoff))
            res    = max(0.5, min(20.0, res))
            omega = 2.0 * np.pi * cutoff / self.sr
            sin_w = np.sin(omega)
            cos_w = np.cos(omega)
            alpha = sin_w / (2.0 * res)
            a0 = 1.0 + alpha
            b0, b1, b2 = 1.0 / a0,                  -2.0 * cos_w / a0,  1.0 / a0
            a1, a2     = -2.0 * cos_w / a0,         (1.0 - alpha) / a0
            x1, x2 = state["biquad_x1"], state["biquad_x2"]
            y1, y2 = state["biquad_y1"], state["biquad_y2"]
            out = np.empty(n, dtype=np.float32)
            for i in range(n):
                x = float(audio_in[i])
                y = b0*x + b1*x1 + b2*x2 - a1*y1 - a2*y2
                out[i] = y
                x2, x1 = x1, x
                y2, y1 = y1, y
            state["biquad_x1"], state["biquad_x2"] = x1, x2
            state["biquad_y1"], state["biquad_y2"] = y1, y2
            outputs["audio_out"] = out

        elif module.god == "Forseti" and module.kind == "Tilt":
            # F-6: Tilt-EQ — komplementäre LP/HP-Bänder mit gegen-
            # läufigen Gain-Faktoren. tilt > 0 hebt Höhen + senkt Tiefen,
            # tilt < 0 umgekehrt. Pivotfrequenz fest auf 1000 Hz.
            audio_in = inputs.get("audio_in", np.zeros(n, dtype=np.float32))
            if not isinstance(audio_in, np.ndarray):
                audio_in = np.full(n, audio_in, dtype=np.float32)
            p_tilt = float(module.params.get("tilt", 0.0))
            tilt = self._scalarize(inputs.get("tilt", p_tilt), p_tilt)
            tilt = max(-1.0, min(1.0, tilt))
            # max ±6 dB → Gain-Faktor 10^(±6/20) ≈ 2.0 bzw. 0.5
            # gain_lo = 2^(-tilt), gain_hi = 2^(+tilt)  (smooth, monoton)
            gain_lo = float(2.0 ** (-tilt))
            gain_hi = float(2.0 ** (+tilt))
            pivot = 1000.0
            alpha = float(1.0 - np.exp(-2.0 * np.pi * pivot / self.sr))
            z_lp = state["tilt_lp_z"]
            z_hp = state["tilt_hp_z"]
            out = np.empty(n, dtype=np.float32)
            for i in range(n):
                x = float(audio_in[i])
                # LP-Komponente
                z_lp += alpha * (x - z_lp)
                # HP-Komponente (input minus LP-state)
                z_hp += alpha * (x - z_hp)
                hp_part = x - z_hp
                out[i] = z_lp * gain_lo + hp_part * gain_hi
            state["tilt_lp_z"] = z_lp
            state["tilt_hp_z"] = z_hp
            outputs["audio_out"] = out

        elif module.god == "Forseti" and module.kind == "EQ4":
            # F-6: 4-Band EQ — Low-Shelf @ 200Hz, Peak @ 800Hz, Peak @ 3kHz,
            # High-Shelf @ 8kHz. Jeder Band nutzt RBJ-Cookbook-Biquad mit
            # gain in dB (geclampt auf ±12 dB).
            #
            # Implementiert über Helper-Closure für die 4 Biquads in Serie.
            audio_in = inputs.get("audio_in", np.zeros(n, dtype=np.float32))
            if not isinstance(audio_in, np.ndarray):
                audio_in = np.full(n, audio_in, dtype=np.float32)

            def _biquad_coeffs(filter_type, freq, gain_db, q=0.707):
                """RBJ-Cookbook-Koeffizienten für lowshelf/peak/highshelf."""
                A = float(10.0 ** (gain_db / 40.0))  # SQRT(linear gain)
                omega = 2.0 * np.pi * freq / self.sr
                sin_w = np.sin(omega)
                cos_w = np.cos(omega)
                alpha = sin_w / (2.0 * q)
                if filter_type == "lowshelf":
                    sqrtA_alpha = 2.0 * np.sqrt(A) * alpha
                    b0 =    A*((A+1) - (A-1)*cos_w + sqrtA_alpha)
                    b1 = 2.0*A*((A-1) - (A+1)*cos_w)
                    b2 =    A*((A+1) - (A-1)*cos_w - sqrtA_alpha)
                    a0 =       (A+1) + (A-1)*cos_w + sqrtA_alpha
                    a1 = -2.0*((A-1) + (A+1)*cos_w)
                    a2 =       (A+1) + (A-1)*cos_w - sqrtA_alpha
                elif filter_type == "highshelf":
                    sqrtA_alpha = 2.0 * np.sqrt(A) * alpha
                    b0 =    A*((A+1) + (A-1)*cos_w + sqrtA_alpha)
                    b1 = -2.0*A*((A-1) + (A+1)*cos_w)
                    b2 =    A*((A+1) + (A-1)*cos_w - sqrtA_alpha)
                    a0 =       (A+1) - (A-1)*cos_w + sqrtA_alpha
                    a1 =  2.0*((A-1) - (A+1)*cos_w)
                    a2 =       (A+1) - (A-1)*cos_w - sqrtA_alpha
                else:  # peak
                    b0 = 1.0 + alpha * A
                    b1 = -2.0 * cos_w
                    b2 = 1.0 - alpha * A
                    a0 = 1.0 + alpha / A
                    a1 = -2.0 * cos_w
                    a2 = 1.0 - alpha / A
                return (b0/a0, b1/a0, b2/a0, a1/a0, a2/a0)

            # Gains aus Inputs/Params
            def _g(key, default):
                p = float(module.params.get(key, default))
                v = self._scalarize(inputs.get(key, p), p)
                return max(-12.0, min(12.0, v))

            bands = [
                ("low",   "lowshelf",  200.0,  _g("low_gain",    0.0)),
                ("lomid", "peak",      800.0,  _g("lo_mid_gain", 0.0)),
                ("himid", "peak",     3000.0,  _g("hi_mid_gain", 0.0)),
                ("high",  "highshelf",8000.0,  _g("high_gain",   0.0)),
            ]

            sig = audio_in.astype(np.float32, copy=True)
            for band_name, ftype, freq, gain in bands:
                # Skip wenn Gain ≈ 0 (CPU-Optimierung, der Filter wäre
                # eh transparent)
                if abs(gain) < 0.01:
                    # State trotzdem durchschieben damit beim Wiedereinschalten
                    # kein Klick entsteht — verschieben die letzten 2 Inputs.
                    state[f"{band_name}_x2"] = float(sig[-2]) if n >= 2 else state[f"{band_name}_x2"]
                    state[f"{band_name}_x1"] = float(sig[-1]) if n >= 1 else state[f"{band_name}_x1"]
                    # y-State auf 0 ziehen würde Click geben; lassen wo sie sind
                    continue
                b0, b1, b2, a1, a2 = _biquad_coeffs(ftype, freq, gain)
                x1 = state[f"{band_name}_x1"]; x2 = state[f"{band_name}_x2"]
                y1 = state[f"{band_name}_y1"]; y2 = state[f"{band_name}_y2"]
                new_sig = np.empty(n, dtype=np.float32)
                for i in range(n):
                    x = float(sig[i])
                    y = b0*x + b1*x1 + b2*x2 - a1*y1 - a2*y2
                    new_sig[i] = y
                    x2, x1 = x1, x
                    y2, y1 = y1, y
                state[f"{band_name}_x1"] = x1; state[f"{band_name}_x2"] = x2
                state[f"{band_name}_y1"] = y1; state[f"{band_name}_y2"] = y2
                sig = new_sig
            outputs["audio_out"] = sig

        elif module.god == "Iduna" and module.kind == "Delay":
            # F-7: Tape-Delay mit Tone-Control im Feedback-Pfad.
            # Pro Sample:
            #   read_pos = (write_idx - delay_samples) mod buf_len
            #   echo = buf[read_pos] (mit linearer Interpolation)
            #   feedback_signal = echo * feedback, durch LP gefiltert (Tone)
            #   buf[write_idx] = input + feedback_signal
            #   out = (1-mix)*input + mix*echo
            audio_in = inputs.get("audio_in", np.zeros(n, dtype=np.float32))
            if not isinstance(audio_in, np.ndarray):
                audio_in = np.full(n, audio_in, dtype=np.float32)
            p_time = float(module.params.get("time",     0.375))
            p_fb   = float(module.params.get("feedback", 0.4))
            p_mix  = float(module.params.get("mix",      0.3))
            p_tone = float(module.params.get("tone",     5000.0))
            time_s = self._scalarize(inputs.get("time",     p_time), p_time)
            fb     = self._scalarize(inputs.get("feedback", p_fb),   p_fb)
            mix    = self._scalarize(inputs.get("mix",      p_mix),  p_mix)
            tone   = self._scalarize(inputs.get("tone",     p_tone), p_tone)
            time_s = max(0.001, min(2.0,   time_s))
            fb     = max(0.0,   min(0.95,  fb))
            mix    = max(0.0,   min(1.0,   mix))
            tone   = max(200.0, min(20000.0, tone))
            buf    = state["delay_buf"]
            buf_len = state["delay_buf_len"]
            idx    = state["delay_idx"]
            tone_z = state["delay_tone_z"]
            tone_alpha = float(1.0 - np.exp(-2.0 * np.pi * tone / self.sr))
            delay_samples = time_s * self.sr
            out = np.empty(n, dtype=np.float32)
            for i in range(n):
                # Lineare Interpolation für fractional delay
                read_pos = (idx - delay_samples) % buf_len
                idx0 = int(read_pos)
                frac = float(read_pos - idx0)
                idx1 = (idx0 + 1) % buf_len
                echo = float(buf[idx0]) * (1.0 - frac) + float(buf[idx1]) * frac
                # Tone-Control auf das Echo (vor Feedback ins Buffer)
                tone_z += tone_alpha * (echo - tone_z)
                # Feedback in den Buffer
                buf[idx] = float(audio_in[i]) + tone_z * fb
                # Wet/Dry-Mix
                out[i] = (1.0 - mix) * float(audio_in[i]) + mix * echo
                idx = (idx + 1) % buf_len
            state["delay_idx"]    = idx
            state["delay_tone_z"] = tone_z
            outputs["audio_out"]  = out

        elif module.god == "Iduna" and module.kind == "Reverb":
            # F-7: Schroeder-Reverb. 4 Comb-Filter parallel summieren das
            # Eingangs-Signal mit unterschiedlichen Verzögerungen und
            # Damping-LP im Feedback. Dann 2 Allpass-Filter in Serie zur
            # Diffusion. Klassische Topologie aus Schroeder 1962.
            audio_in = inputs.get("audio_in", np.zeros(n, dtype=np.float32))
            if not isinstance(audio_in, np.ndarray):
                audio_in = np.full(n, audio_in, dtype=np.float32)
            p_room = float(module.params.get("room_size", 0.5))
            p_damp = float(module.params.get("damping",   0.4))
            p_mix  = float(module.params.get("mix",       0.3))
            room   = self._scalarize(inputs.get("room_size", p_room), p_room)
            damp   = self._scalarize(inputs.get("damping",   p_damp), p_damp)
            mix    = self._scalarize(inputs.get("mix",       p_mix),  p_mix)
            room   = max(0.1, min(1.0, room))
            damp   = max(0.0, min(1.0, damp))
            mix    = max(0.0, min(1.0, mix))
            # Comb-Feedback skaliert mit room_size: 0.7 (klein) bis 0.92 (groß)
            comb_fb = 0.7 + 0.22 * room
            # Damping = LP-Faktor im Comb-Feedback. 0=offen, 1=stark gedämpft
            damp_a = damp           # direktes one-pole alpha
            damp_b = 1.0 - damp     # complement

            comb_bufs = state["comb_bufs"]
            comb_idxs = state["comb_idxs"]
            comb_lens = state["comb_lens"]
            comb_lp_z = state["comb_lp_z"]
            ap_bufs   = state["ap_bufs"]
            ap_idxs   = state["ap_idxs"]
            ap_lens   = state["ap_lens"]
            ap_gain   = 0.5  # Schroeder-Standard

            out = np.empty(n, dtype=np.float32)
            for i in range(n):
                x = float(audio_in[i])
                # 4 Comb-Filter parallel summieren
                comb_sum = 0.0
                for k in range(4):
                    buf = comb_bufs[k]; cl = comb_lens[k]
                    ci = comb_idxs[k]
                    delayed = float(buf[ci])
                    # Damping als 1-Pol-LP im Feedback-Pfad
                    comb_lp_z[k] = delayed * damp_b + comb_lp_z[k] * damp_a
                    buf[ci] = x + comb_lp_z[k] * comb_fb
                    comb_sum += delayed
                    comb_idxs[k] = (ci + 1) % cl
                comb_sum *= 0.25  # normalisiere 4-fach Summe
                # 2 Allpass-Filter in Serie (Diffusion)
                ap_signal = comb_sum
                for k in range(2):
                    buf = ap_bufs[k]; al = ap_lens[k]
                    ai = ap_idxs[k]
                    delayed = float(buf[ai])
                    # Schroeder-Allpass: y = -g·x + delayed + g·feedback_into_buf
                    # buf-write: x + g·delayed
                    buf[ai] = ap_signal + delayed * ap_gain
                    ap_signal = delayed - ap_signal * ap_gain
                    ap_idxs[k] = (ai + 1) % al
                # Wet/Dry-Mix
                out[i] = (1.0 - mix) * x + mix * ap_signal
            outputs["audio_out"] = out

        elif module.god == "Hel" and module.kind == "Gater":
            # FX-Glitch: rhythmischer Audio-Gate. Generiert intern eine
            # Pulse-Welle [0/1], glättet sie via 1-Pol-LP (smooth-Param),
            # und multipliziert mit Audio-Input.
            audio_in = inputs.get("audio_in", np.zeros(n, dtype=np.float32))
            if not isinstance(audio_in, np.ndarray):
                audio_in = np.full(n, audio_in, dtype=np.float32)
            p_rate   = float(module.params.get("rate", 4.0))
            p_pw     = float(module.params.get("pulse_width", 0.5))
            p_smooth = float(module.params.get("smooth", 0.05))
            p_mix    = float(module.params.get("mix", 1.0))
            rate   = self._scalarize(inputs.get("rate",        p_rate),   p_rate)
            pw     = self._scalarize(inputs.get("pulse_width", p_pw),     p_pw)
            smooth = self._scalarize(inputs.get("smooth",      p_smooth), p_smooth)
            mix    = self._scalarize(inputs.get("mix",         p_mix),    p_mix)
            rate   = max(0.1,  min(50.0, rate))
            pw     = max(0.05, min(0.95, pw))
            smooth = max(0.0,  min(1.0,  smooth))
            mix    = max(0.0,  min(1.0,  mix))
            # smooth ∈ [0..1] mappt auf Cutoff-Frequenz: 0 = sehr schnell (≈ instant)
            # 1 = sehr langsam (~ 50ms Time-Constant). Wir nutzen lineare
            # Skalierung von alpha ∈ [1.0 .. 0.001].
            smooth_alpha = 1.0 - smooth * 0.999
            phase = state["gate_phase"]
            sm_z  = state["smooth_z"]
            phase_inc = rate / self.sr
            out = np.empty(n, dtype=np.float32)
            for i in range(n):
                target = 1.0 if phase < pw else 0.0
                # Smoothing
                sm_z += smooth_alpha * (target - sm_z)
                # Mix dry/wet
                out[i] = (1.0 - mix) * float(audio_in[i]) + mix * float(audio_in[i]) * sm_z
                phase += phase_inc
                if phase >= 1.0: phase -= 1.0
            state["gate_phase"] = phase
            state["smooth_z"]   = sm_z
            outputs["audio_out"] = out

        elif module.god == "Hel" and module.kind == "TapeStop":
            # FX-Glitch: Tape-Stop. Bei rising-edge auf trigger startet die
            # Stop-Phase: Pitch (über Resampling-Speed) + Volume werden über
            # `duration` Sekunden auf 0 gefahren. Bei falling-edge: instant
            # zurück auf normal.
            #
            # Pitch-Down: wir lesen den Buffer mit variabler Speed. Speed=1.0
            # = normal, Speed=0.0 = vollständig gestoppt. Speed verläuft
            # quadratisch (kubisch wäre noch realistischer aber quadratisch
            # genügt für den Effekt).
            audio_in = inputs.get("audio_in", np.zeros(n, dtype=np.float32))
            if not isinstance(audio_in, np.ndarray):
                audio_in = np.full(n, audio_in, dtype=np.float32)
            p_dur = float(module.params.get("duration", 0.5))
            duration = self._scalarize(inputs.get("duration", p_dur), p_dur)
            duration = max(0.05, min(5.0, duration))

            trigger_block = inputs.get("trigger")
            if trigger_block is None:
                trigger_block = np.full(n, float(module.params.get("trigger", 0.0)), dtype=np.float32)
            elif np.isscalar(trigger_block):
                trigger_block = np.full(n, float(trigger_block), dtype=np.float32)
            else:
                trigger_block = np.asarray(trigger_block, dtype=np.float32)
                if trigger_block.size != n:
                    trigger_block = np.full(n, float(trigger_block.flat[0]) if trigger_block.size else 0.0, dtype=np.float32)

            buf = state["ts_buf"]
            buf_len = state["ts_buf_len"]
            wi = state["ts_write_idx"]
            ri = state["resample_pos"]   # fractional read pointer
            stop_pos = state["stop_pos"]
            last_trig = state["last_trigger"]

            # Stop-Inkrement pro sample: 1 / (duration · sr)
            stop_inc = 1.0 / max(1.0, duration * self.sr)
            out = np.empty(n, dtype=np.float32)
            for i in range(n):
                trig = float(trigger_block[i])
                if trig >= 0.5 and last_trig < 0.5:
                    # Rising edge → starte Stop. Setze ri auf aktuelle wi um
                    # Latenz zu vermeiden.
                    stop_pos = 0.0
                    ri = float(wi)
                elif trig < 0.5 and last_trig >= 0.5:
                    # Falling edge → reset. Buffer-Read = Buffer-Write (passthrough).
                    stop_pos = 0.0
                    ri = float(wi)
                last_trig = trig

                # Schreibe immer (egal ob in Stop oder normal)
                buf[wi] = float(audio_in[i])
                wi = (wi + 1) % buf_len

                if trig >= 0.5:
                    # Stop läuft: Speed sinkt quadratisch von 1 → 0
                    speed = (1.0 - stop_pos) ** 2
                    speed = max(0.0, speed)
                    # Volume sinkt linear von 1 → 0
                    vol = max(0.0, 1.0 - stop_pos)
                    # Lese-Position vorlaufen (mit kleiner als 1.0 Speed)
                    idx0 = int(ri) % buf_len
                    frac = float(ri - int(ri))
                    idx1 = (idx0 + 1) % buf_len
                    sample = float(buf[idx0]) * (1.0 - frac) + float(buf[idx1]) * frac
                    out[i] = sample * vol
                    ri += speed
                    if ri >= buf_len: ri -= buf_len
                    stop_pos += stop_inc
                    if stop_pos > 1.0: stop_pos = 1.0
                else:
                    # Normalbetrieb: passthrough
                    out[i] = float(audio_in[i])

            state["ts_write_idx"]  = wi
            state["resample_pos"]  = ri
            state["stop_pos"]      = stop_pos
            state["last_trigger"]  = last_trig
            outputs["audio_out"]   = out

        elif module.god == "Hel" and module.kind == "Vocoder":
            # v0.0.21.240 — Channel-Vocoder.
            # 16 Bandpass-Filter logarithmisch verteilt 100..8000 Hz.
            # Modulator → BPs → Envelope-Follower (peak with attack/release).
            # Carrier → BPs (optional formant_shifted) → ×Envelope[i] → Sum.
            audio_in = inputs.get("audio_in", np.zeros(n, dtype=np.float32))
            mod_in   = inputs.get("mod_in",   np.zeros(n, dtype=np.float32))
            if not isinstance(audio_in, np.ndarray):
                audio_in = np.full(n, float(audio_in) if np.isscalar(audio_in) else 0.0, dtype=np.float32)
            if not isinstance(mod_in, np.ndarray):
                mod_in = np.full(n, float(mod_in) if np.isscalar(mod_in) else 0.0, dtype=np.float32)
            # Defensive: shape match
            if audio_in.size != n:
                audio_in = np.zeros(n, dtype=np.float32)
            if mod_in.size != n:
                mod_in = np.zeros(n, dtype=np.float32)

            formant_shift = self._scalarize(inputs.get("formant_shift"), module.params.get("formant_shift", 1.0))
            dry_wet       = self._scalarize(inputs.get("dry_wet"),       module.params.get("dry_wet", 1.0))
            attack_ms     = self._scalarize(inputs.get("attack_ms"),     module.params.get("attack_ms", 5.0))
            release_ms    = self._scalarize(inputs.get("release_ms"),    module.params.get("release_ms", 80.0))
            formant_shift = max(0.5, min(2.0, formant_shift))
            dry_wet       = max(0.0, min(1.0, dry_wet))
            attack_ms     = max(0.5, min(50.0, attack_ms))
            release_ms    = max(10.0, min(500.0, release_ms))

            # 16 Bänder logarithmisch von 100 Hz bis 8000 Hz verteilt
            # (klassischer Sprach-Bereich; Bitwig nutzt ähnliche Range).
            # Bänder werden einmal pro Modul-Lifetime gecached.
            N_BANDS = 16
            band_freqs = state.get("vocoder_band_freqs")
            if band_freqs is None:
                band_freqs = np.exp(np.linspace(
                    np.log(100.0), np.log(8000.0), N_BANDS,
                )).astype(np.float32)
                state["vocoder_band_freqs"] = band_freqs
                # Filter-State: für jedes Band (Mod + Carrier) → 2 Biquads
                # à 4 Memory-Werte. Wir speichern als float-Arrays.
                state["voc_mod_z1"]  = np.zeros(N_BANDS, dtype=np.float64)
                state["voc_mod_z2"]  = np.zeros(N_BANDS, dtype=np.float64)
                state["voc_mod_y1"]  = np.zeros(N_BANDS, dtype=np.float64)
                state["voc_mod_y2"]  = np.zeros(N_BANDS, dtype=np.float64)
                state["voc_car_z1"]  = np.zeros(N_BANDS, dtype=np.float64)
                state["voc_car_z2"]  = np.zeros(N_BANDS, dtype=np.float64)
                state["voc_car_y1"]  = np.zeros(N_BANDS, dtype=np.float64)
                state["voc_car_y2"]  = np.zeros(N_BANDS, dtype=np.float64)
                state["voc_envelope"] = np.zeros(N_BANDS, dtype=np.float64)
            mod_z1 = state["voc_mod_z1"]; mod_z2 = state["voc_mod_z2"]
            mod_y1 = state["voc_mod_y1"]; mod_y2 = state["voc_mod_y2"]
            car_z1 = state["voc_car_z1"]; car_z2 = state["voc_car_z2"]
            car_y1 = state["voc_car_y1"]; car_y2 = state["voc_car_y2"]
            envelope = state["voc_envelope"]

            # Pre-compute biquad-Coeffs für alle 16 Bänder als numpy-Arrays
            # damit wir per-sample vektorisiert filtern können (16× schneller
            # als Skalar-Loop). RBJ Bandpass mit Q=6.
            Q = 6.0
            band_freqs_safe = np.clip(band_freqs.astype(np.float64),
                                      20.0, self.sr * 0.45)
            w0_mod = 2.0 * np.pi * band_freqs_safe / self.sr
            cos_mod = np.cos(w0_mod); sin_mod = np.sin(w0_mod)
            alpha_mod = sin_mod / (2.0 * Q)
            a0_mod = 1.0 + alpha_mod
            mod_b0 = alpha_mod / a0_mod
            mod_b2 = -alpha_mod / a0_mod
            mod_a1 = -2.0 * cos_mod / a0_mod
            mod_a2 = (1.0 - alpha_mod) / a0_mod

            # Carrier mit formant_shift skalierten Frequenzen
            f_car_safe = np.clip(band_freqs_safe * formant_shift,
                                 20.0, self.sr * 0.45)
            w0_car = 2.0 * np.pi * f_car_safe / self.sr
            cos_car = np.cos(w0_car); sin_car = np.sin(w0_car)
            alpha_car = sin_car / (2.0 * Q)
            a0_car = 1.0 + alpha_car
            car_b0 = alpha_car / a0_car
            car_b2 = -alpha_car / a0_car
            car_a1 = -2.0 * cos_car / a0_car
            car_a2 = (1.0 - alpha_car) / a0_car

            # Envelope-Follower-Konstanten (one-pole)
            atk_alpha = float(np.exp(-1.0 / max(1.0, attack_ms  * self.sr / 1000.0)))
            rel_alpha = float(np.exp(-1.0 / max(1.0, release_ms * self.sr / 1000.0)))

            out = np.zeros(n, dtype=np.float32)
            # Vectorized: pro Sample ein einzelner numpy-Update über alle 16
            # Bänder. Direct-Form-I Biquad: y = b0*x + b1*z1 + b2*z2 - a1*y1 - a2*y2
            # b1=0 für Bandpass → fällt weg.
            for i in range(n):
                m = float(mod_in[i])
                c = float(audio_in[i])
                # 1) Modulator-Filterbank (16 BPs parallel via numpy)
                mod_y = (mod_b0 * m + mod_b2 * mod_z2
                         - mod_a1 * mod_y1 - mod_a2 * mod_y2)
                mod_z2[:] = mod_z1; mod_z1[:] = m
                mod_y2[:] = mod_y1; mod_y1[:] = mod_y
                # 2) Envelope-Follower (peak with attack/release)
                rectified = np.abs(mod_y)
                # Combined: alpha hängt davon ab ob attack oder release Phase
                alpha = np.where(rectified > envelope, atk_alpha, rel_alpha)
                envelope = alpha * envelope + (1.0 - alpha) * rectified
                # 3) Carrier-Filterbank (16 BPs parallel)
                car_y = (car_b0 * c + car_b2 * car_z2
                         - car_a1 * car_y1 - car_a2 * car_y2)
                car_z2[:] = car_z1; car_z1[:] = c
                car_y2[:] = car_y1; car_y1[:] = car_y
                # 4) Sum: carrier-band × envelope[band]. Plus Output-Gain
                # da Q=6 Bandpass-Filter ihren Source schon stark dämpfen.
                wet = float(np.sum(car_y * envelope)) * 8.0  # gain comp
                # 5) Dry/Wet-Mix
                out[i] = (1.0 - dry_wet) * c + dry_wet * wet
            # Persist envelope-State zurück
            state["voc_envelope"] = envelope

            # Output-Normalisierung: bei vielen Bändern sammelt sich Energie an,
            # plus Q=6 BPs haben gain ~1/Q des Source. 16 Bänder × ~0.16 = 2.56
            # nominal. Wir trim'en auf ~0.7 Peak max — falls mehr, soft-clip
            # via tanh damit's nicht klirrt.
            peak = float(np.max(np.abs(out))) if out.size else 0.0
            if peak > 0.95:
                out = np.tanh(out * (0.95 / max(1e-9, peak))) * 0.95
            outputs["audio_out"] = out.astype(np.float32)

        elif module.god == "Mimir" and module.kind == "Stutter":
            # FX-Glitch: Buffer-Frost + Re-Trigger (Beat-Repeat).
            # Wenn freeze=on: spiele kontinuierlich die letzten `slice_ms` ms
            # in Loop. Wenn freeze=off: passthrough + update buffer.
            # Bei rising edge → snapshot des aktuellen slice + reset read_idx=0.
            audio_in = inputs.get("audio_in", np.zeros(n, dtype=np.float32))
            if not isinstance(audio_in, np.ndarray):
                audio_in = np.full(n, audio_in, dtype=np.float32)
            p_freeze = float(module.params.get("freeze", 0.0))
            p_slice  = float(module.params.get("slice_ms", 100.0))
            slice_ms = self._scalarize(inputs.get("slice_ms", p_slice), p_slice)
            slice_ms = max(10.0, min(500.0, slice_ms))

            freeze_block = inputs.get("freeze")
            if freeze_block is None:
                freeze_block = np.full(n, p_freeze, dtype=np.float32)
            elif np.isscalar(freeze_block):
                freeze_block = np.full(n, float(freeze_block), dtype=np.float32)
            else:
                freeze_block = np.asarray(freeze_block, dtype=np.float32)
                if freeze_block.size != n:
                    freeze_block = np.full(n, float(freeze_block.flat[0]) if freeze_block.size else 0.0, dtype=np.float32)

            buf = state["stutter_buf"]
            buf_len = state["stutter_buf_len"]
            wi = state["stutter_write_idx"]
            ri = state["stutter_read_idx"]
            slice_len = state["stutter_slice_len"]
            last_freeze = state["last_freeze"]

            slice_samples = int(slice_ms / 1000.0 * self.sr)
            slice_samples = max(1, min(slice_samples, buf_len))

            out = np.empty(n, dtype=np.float32)
            for i in range(n):
                fz = float(freeze_block[i])
                fz_on  = fz >= 0.5
                last_on = last_freeze >= 0.5

                if fz_on and not last_on:
                    # Rising edge: capture aktuellen slice. read_start =
                    # (wi - slice_samples) mod buf_len. Wir merken uns
                    # die slice-Länge plus Start-Position (read_idx wird
                    # innerhalb der slice gezählt).
                    slice_len = slice_samples
                    ri = 0  # innerhalb der slice
                    state["slice_start"] = (wi - slice_samples + buf_len) % buf_len

                if fz_on:
                    # Wiederhole den Slice
                    if slice_len <= 0:
                        out[i] = 0.0
                    else:
                        slice_start = state.get("slice_start", 0)
                        idx = (slice_start + ri) % buf_len
                        out[i] = float(buf[idx])
                        ri += 1
                        if ri >= slice_len:
                            ri = 0  # loop
                else:
                    # Normalbetrieb: passthrough + Buffer-Update
                    out[i] = float(audio_in[i])
                    buf[wi] = float(audio_in[i])
                    wi = (wi + 1) % buf_len
                last_freeze = fz

            state["stutter_write_idx"] = wi
            state["stutter_read_idx"]  = ri
            state["stutter_slice_len"] = slice_len
            state["last_freeze"]       = last_freeze
            outputs["audio_out"]       = out

        elif module.god == "Fenrir" and module.kind == "BitCrush":
            # FX-Glitch: Bit-Tiefe-Reduktion via Quantisierung.
            # bits=N → 2^N Quantisierungsstufen über [-1..1] = step = 2/2^N.
            audio_in = inputs.get("audio_in", np.zeros(n, dtype=np.float32))
            if not isinstance(audio_in, np.ndarray):
                audio_in = np.full(n, audio_in, dtype=np.float32)
            p_bits = float(module.params.get("bits", 8.0))
            p_mix  = float(module.params.get("mix", 1.0))
            bits = self._scalarize(inputs.get("bits", p_bits), p_bits)
            mix  = self._scalarize(inputs.get("mix",  p_mix),  p_mix)
            bits = max(1.0, min(16.0, bits))
            mix  = max(0.0, min(1.0,  mix))
            # Quantisierungsstufen: 2^bits Werte über [-1..1]
            levels = float(2.0 ** bits)
            step = 2.0 / levels
            # numpy-vectorized: round(x / step) * step
            crushed = np.round(audio_in.astype(np.float32) / step) * step
            outputs["audio_out"] = ((1.0 - mix) * audio_in + mix * crushed).astype(np.float32)

        elif module.god == "Fenrir" and module.kind == "Decimator":
            # FX-Glitch: Sample-Rate-Reduktion via Sample-and-Hold.
            # Phase-Akku läuft bei sr_ratio = target_sr/sr und wenn er
            # 1.0 überschreitet wird ein neuer Sample geholt + gehalten.
            audio_in = inputs.get("audio_in", np.zeros(n, dtype=np.float32))
            if not isinstance(audio_in, np.ndarray):
                audio_in = np.full(n, audio_in, dtype=np.float32)
            p_tsr = float(module.params.get("target_sr", 8000.0))
            p_mix = float(module.params.get("mix", 1.0))
            tsr = self._scalarize(inputs.get("target_sr", p_tsr), p_tsr)
            mix = self._scalarize(inputs.get("mix",       p_mix), p_mix)
            tsr = max(200.0, min(48000.0, tsr))
            mix = max(0.0,   min(1.0,    mix))
            ratio = tsr / self.sr  # ∈ (0..1] — bei tsr >= sr ist Decimator transparent
            phase = float(state["dec_phase"])
            held  = float(state["dec_held_l"])
            out = np.empty(n, dtype=np.float32)
            for i in range(n):
                phase += ratio
                if phase >= 1.0:
                    held = float(audio_in[i])
                    phase -= 1.0
                out[i] = (1.0 - mix) * float(audio_in[i]) + mix * held
            state["dec_phase"]   = phase
            state["dec_held_l"]  = held
            outputs["audio_out"] = out

        # ═══════════════════════════════════════════════════════
        # F-10 Thor — Distortion-Familie (zustandslose Wave-Shaping)
        # ═══════════════════════════════════════════════════════

        elif module.god == "Thor" and module.kind == "TubeDrive":
            # Soft-Saturation via tanh + Tone-Filter (1-Pol-LP) im Loop.
            # tone=0 → dunkler (LP greift stark), tone=1 → bright.
            audio_in = inputs.get("audio_in", np.zeros(n, dtype=np.float32))
            if not isinstance(audio_in, np.ndarray):
                audio_in = np.full(n, audio_in, dtype=np.float32)
            p_drive = float(module.params.get("drive", 12.0))
            p_tone  = float(module.params.get("tone", 0.5))
            p_mix   = float(module.params.get("mix", 1.0))
            drive_db = self._scalarize(inputs.get("drive", p_drive), p_drive)
            tone     = self._scalarize(inputs.get("tone",  p_tone),  p_tone)
            mix      = self._scalarize(inputs.get("mix",   p_mix),   p_mix)
            drive_db = max(0.0, min(36.0, drive_db))
            tone     = max(0.0, min(1.0,  tone))
            mix      = max(0.0, min(1.0,  mix))
            # Drive in linear-Gain
            drive_lin = 10.0 ** (drive_db / 20.0)
            # Tone-Filter: tone=0 → cutoff ~500Hz, tone=1 → ~12000Hz
            cutoff = 500.0 * (24.0 ** tone)
            # 1-Pol-LP coefficient: alpha = 1 - exp(-2π·fc/sr)
            alpha = 1.0 - math.exp(-2.0 * math.pi * cutoff / self.sr)
            # tanh-Saturation, dann Tone-Filter
            shaped = np.tanh(audio_in * drive_lin) / max(1.0, math.tanh(drive_lin))
            tone_z = state["tone_z"]
            out = np.empty(n, dtype=np.float32)
            for i in range(n):
                tone_z += alpha * (float(shaped[i]) - tone_z)
                out[i] = tone_z
            state["tone_z"] = tone_z
            outputs["audio_out"] = ((1.0 - mix) * audio_in + mix * out).astype(np.float32)

        elif module.god == "Thor" and module.kind == "Fuzz":
            # Hard-Clip mit Bias. Biased-Input → Hard-Clip an ±1.
            audio_in = inputs.get("audio_in", np.zeros(n, dtype=np.float32))
            if not isinstance(audio_in, np.ndarray):
                audio_in = np.full(n, audio_in, dtype=np.float32)
            p_gain = float(module.params.get("gain", 30.0))
            p_bias = float(module.params.get("bias", 0.0))
            p_mix  = float(module.params.get("mix", 1.0))
            gain_db = self._scalarize(inputs.get("gain", p_gain), p_gain)
            bias    = self._scalarize(inputs.get("bias", p_bias), p_bias)
            mix     = self._scalarize(inputs.get("mix",  p_mix),  p_mix)
            gain_db = max(0.0,  min(60.0, gain_db))
            bias    = max(-1.0, min(1.0,  bias))
            mix     = max(0.0,  min(1.0,  mix))
            gain_lin = 10.0 ** (gain_db / 20.0)
            shaped = np.clip(audio_in * gain_lin + bias, -1.0, 1.0) - bias * 0.5
            outputs["audio_out"] = ((1.0 - mix) * audio_in + mix * shaped).astype(np.float32)

        elif module.god == "Thor" and module.kind == "Saturation":
            # Asymmetrische Saturation: 0.7·tanh(x) + 0.3·(x - x³/3)
            # Bei amount=0 → unverändert, bei amount=1 → voller Effekt.
            audio_in = inputs.get("audio_in", np.zeros(n, dtype=np.float32))
            if not isinstance(audio_in, np.ndarray):
                audio_in = np.full(n, audio_in, dtype=np.float32)
            p_amt = float(module.params.get("amount", 0.5))
            p_mix = float(module.params.get("mix", 1.0))
            amt = self._scalarize(inputs.get("amount", p_amt), p_amt)
            mix = self._scalarize(inputs.get("mix",    p_mix), p_mix)
            amt = max(0.0, min(1.0, amt))
            mix = max(0.0, min(1.0, mix))
            # Pre-Gain: amount=0 → 1.0, amount=1 → 4.0
            pre = 1.0 + 3.0 * amt
            x = audio_in * pre
            shaped = 0.7 * np.tanh(x) + 0.3 * (x - x * x * x / 3.0)
            # Normalisiere auf approximativ -1..+1
            shaped = shaped / max(1.0, 0.7 * math.tanh(pre) + 0.3 * (pre - pre**3/3))
            outputs["audio_out"] = ((1.0 - mix) * audio_in + mix * shaped).astype(np.float32)

        elif module.god == "Thor" and module.kind == "WaveShaper":
            # Wählbare Shape-Funktion. shape ∈ [0..2] wählt zwischen 3 Funktionen.
            audio_in = inputs.get("audio_in", np.zeros(n, dtype=np.float32))
            if not isinstance(audio_in, np.ndarray):
                audio_in = np.full(n, audio_in, dtype=np.float32)
            p_drive = float(module.params.get("drive", 6.0))
            p_shape = float(module.params.get("shape", 1.0))
            p_mix   = float(module.params.get("mix", 1.0))
            drive_db = self._scalarize(inputs.get("drive", p_drive), p_drive)
            shape    = self._scalarize(inputs.get("shape", p_shape), p_shape)
            mix      = self._scalarize(inputs.get("mix",   p_mix),   p_mix)
            drive_db = max(0.0, min(24.0, drive_db))
            shape    = max(0.0, min(2.0,  shape))
            mix      = max(0.0, min(1.0,  mix))
            x = audio_in * (10.0 ** (drive_db / 20.0))
            x = np.clip(x, -1.5, 1.5)  # leichtes Pre-Limiter um Overflow zu vermeiden
            # 3 Shape-Funktionen — interpoliert nach shape ∈ [0..2]
            sin_shape    = np.sin(x * (math.pi / 2.0))
            cubic_shape  = 1.5 * x - 0.5 * x * x * x
            quintic_shape = 1.875 * x - 1.25 * x**3 + 0.375 * x**5
            if shape <= 1.0:
                t = shape
                shaped = (1 - t) * sin_shape + t * cubic_shape
            else:
                t = shape - 1.0
                shaped = (1 - t) * cubic_shape + t * quintic_shape
            outputs["audio_out"] = ((1.0 - mix) * audio_in + mix * shaped).astype(np.float32)

        # ═══════════════════════════════════════════════════════
        # F-9 Vidar — Dynamics-Familie
        # ═══════════════════════════════════════════════════════

        elif module.god == "Vidar" and module.kind == "Compressor":
            # Klassischer Feed-Forward-Kompressor:
            # 1. Envelope-Follower (peak via 1-Pol-LP) auf |audio|
            # 2. Wenn env > threshold: gain-reduction = (env-thr) · (1-1/ratio)
            # 3. Smooth gain-Reduction via Attack/Release
            # 4. Make-up-Gain dazu
            audio_in = inputs.get("audio_in", np.zeros(n, dtype=np.float32))
            if not isinstance(audio_in, np.ndarray):
                audio_in = np.full(n, audio_in, dtype=np.float32)
            p_thr = float(module.params.get("threshold", -12.0))
            p_rat = float(module.params.get("ratio", 4.0))
            p_atk = float(module.params.get("attack_ms", 5.0))
            p_rel = float(module.params.get("release_ms", 50.0))
            p_mk  = float(module.params.get("makeup", 0.0))
            thr_db = self._scalarize(inputs.get("threshold",  p_thr), p_thr)
            ratio  = self._scalarize(inputs.get("ratio",      p_rat), p_rat)
            atk_ms = self._scalarize(inputs.get("attack_ms",  p_atk), p_atk)
            rel_ms = self._scalarize(inputs.get("release_ms", p_rel), p_rel)
            mk_db  = self._scalarize(inputs.get("makeup",     p_mk),  p_mk)
            ratio = max(1.0, min(20.0, ratio))
            # Attack/Release-Coefficients (Time-Constant-Stil)
            atk_coef = math.exp(-1.0 / max(1e-6, atk_ms * 0.001 * self.sr))
            rel_coef = math.exp(-1.0 / max(1e-6, rel_ms * 0.001 * self.sr))
            mk_lin = 10.0 ** (mk_db / 20.0)
            env = state["env"]
            gain_z = state["gain_z"]
            out = np.empty(n, dtype=np.float32)
            for i in range(n):
                # Envelope-Follower auf Peak (|x|)
                x_abs = abs(float(audio_in[i]))
                # Schnelle Attack auf env, langsamer Release
                if x_abs > env:
                    env = x_abs + atk_coef * (env - x_abs)
                else:
                    env = x_abs + rel_coef * (env - x_abs)
                # In dB umrechnen (mit -inf-Schutz)
                env_db = 20.0 * math.log10(max(1e-9, env))
                # Gain-Reduction berechnen
                if env_db > thr_db:
                    over = env_db - thr_db
                    gr_db = over * (1.0 - 1.0 / ratio)
                else:
                    gr_db = 0.0
                target_gain = 10.0 ** (-gr_db / 20.0)
                # Smooth gain mit attack/release
                if target_gain < gain_z:
                    gain_z = target_gain + atk_coef * (gain_z - target_gain)
                else:
                    gain_z = target_gain + rel_coef * (gain_z - target_gain)
                out[i] = float(audio_in[i]) * gain_z * mk_lin
            state["env"] = env
            state["gain_z"] = gain_z
            outputs["audio_out"] = out

        elif module.god == "Vidar" and module.kind == "Limiter":
            # Brick-Wall-Limiter: Peak-Detection mit ~0.5ms Lookahead-
            # äquivalentem Smoothing. Hard-Limit am Ceiling.
            audio_in = inputs.get("audio_in", np.zeros(n, dtype=np.float32))
            if not isinstance(audio_in, np.ndarray):
                audio_in = np.full(n, audio_in, dtype=np.float32)
            p_ceil = float(module.params.get("ceiling", -0.3))
            p_rel  = float(module.params.get("release_ms", 50.0))
            ceil_db = self._scalarize(inputs.get("ceiling",    p_ceil), p_ceil)
            rel_ms  = self._scalarize(inputs.get("release_ms", p_rel),  p_rel)
            ceil_lin = 10.0 ** (ceil_db / 20.0)
            # Sehr schnelle Attack (~0.5ms), variable Release
            atk_coef = math.exp(-1.0 / max(1e-6, 0.5 * 0.001 * self.sr))
            rel_coef = math.exp(-1.0 / max(1e-6, rel_ms * 0.001 * self.sr))
            env = state["env"]
            gain_z = state["gain_z"]
            out = np.empty(n, dtype=np.float32)
            for i in range(n):
                x_abs = abs(float(audio_in[i]))
                if x_abs > env:
                    env = x_abs + atk_coef * (env - x_abs)
                else:
                    env = x_abs + rel_coef * (env - x_abs)
                # Gain so dass env · gain == ceiling
                target_gain = min(1.0, ceil_lin / max(1e-9, env))
                if target_gain < gain_z:
                    gain_z = target_gain + atk_coef * (gain_z - target_gain)
                else:
                    gain_z = target_gain + rel_coef * (gain_z - target_gain)
                out[i] = float(audio_in[i]) * gain_z
            state["env"] = env
            state["gain_z"] = gain_z
            outputs["audio_out"] = out

        elif module.god == "Vidar" and module.kind == "Gate":
            # Threshold-Gate: env_db > thr → open (gain → 1),
            # env_db < thr → close (gain → 0). Mit Attack/Release-Smoothing.
            audio_in = inputs.get("audio_in", np.zeros(n, dtype=np.float32))
            if not isinstance(audio_in, np.ndarray):
                audio_in = np.full(n, audio_in, dtype=np.float32)
            p_thr = float(module.params.get("threshold", -40.0))
            p_atk = float(module.params.get("attack_ms", 1.0))
            p_rel = float(module.params.get("release_ms", 100.0))
            thr_db = self._scalarize(inputs.get("threshold",  p_thr), p_thr)
            atk_ms = self._scalarize(inputs.get("attack_ms",  p_atk), p_atk)
            rel_ms = self._scalarize(inputs.get("release_ms", p_rel), p_rel)
            atk_coef = math.exp(-1.0 / max(1e-6, atk_ms * 0.001 * self.sr))
            rel_coef = math.exp(-1.0 / max(1e-6, rel_ms * 0.001 * self.sr))
            # Envelope-Follower (RMS-ähnlich via |x|-LP)
            env_coef = math.exp(-1.0 / max(1e-6, 1.0 * 0.001 * self.sr))
            env = state["env"]
            gain_z = state["gain_z"]
            out = np.empty(n, dtype=np.float32)
            for i in range(n):
                x_abs = abs(float(audio_in[i]))
                env = x_abs + env_coef * (env - x_abs)
                env_db = 20.0 * math.log10(max(1e-9, env))
                target = 1.0 if env_db > thr_db else 0.0
                if target > gain_z:
                    gain_z = target + atk_coef * (gain_z - target)
                else:
                    gain_z = target + rel_coef * (gain_z - target)
                out[i] = float(audio_in[i]) * gain_z
            state["env"] = env
            state["gain_z"] = gain_z
            outputs["audio_out"] = out

        # ═══════════════════════════════════════════════════════
        # F-8 Skadi — Modulations-FX-Familie
        # ═══════════════════════════════════════════════════════

        elif module.god == "Skadi" and module.kind == "Chorus":
            # Stereo-Chorus: 2 Delay-Lines (L/R) mit phasenversetztem LFO.
            # In Mono-Pipeline: wir mitteln L+R am Ausgang.
            audio_in = inputs.get("audio_in", np.zeros(n, dtype=np.float32))
            if not isinstance(audio_in, np.ndarray):
                audio_in = np.full(n, audio_in, dtype=np.float32)
            p_rate  = float(module.params.get("rate", 0.5))
            p_depth = float(module.params.get("depth", 0.6))
            p_mix   = float(module.params.get("mix", 0.5))
            rate  = self._scalarize(inputs.get("rate",  p_rate),  p_rate)
            depth = self._scalarize(inputs.get("depth", p_depth), p_depth)
            mix   = self._scalarize(inputs.get("mix",   p_mix),   p_mix)
            rate  = max(0.05, min(8.0, rate))
            depth = max(0.0,  min(1.0, depth))
            mix   = max(0.0,  min(1.0, mix))
            # Center-Delay 17.5ms, Modulation ±depth·12.5ms
            base_delay_samples = int(0.0175 * self.sr)
            mod_range_samples  = depth * 0.0125 * self.sr
            buf_l = state["chorus_buf_l"]
            buf_r = state["chorus_buf_r"]
            buf_len = state["chorus_buf_len"]
            wi = state["chorus_write_idx"]
            phase = state["chorus_lfo_phase"]
            phase_inc = rate / self.sr
            out = np.empty(n, dtype=np.float32)
            for i in range(n):
                buf_l[wi] = float(audio_in[i])
                buf_r[wi] = float(audio_in[i])
                # LFO links: sin(2π·phase), rechts: sin(2π·phase + π/2) = cos
                lfo_l = math.sin(2.0 * math.pi * phase)
                lfo_r = math.cos(2.0 * math.pi * phase)
                d_l = base_delay_samples + lfo_l * mod_range_samples
                d_r = base_delay_samples + lfo_r * mod_range_samples
                # Read mit linearer Interpolation
                rp_l = wi - d_l
                rp_r = wi - d_r
                while rp_l < 0: rp_l += buf_len
                while rp_r < 0: rp_r += buf_len
                idx0_l, idx1_l = int(rp_l) % buf_len, (int(rp_l) + 1) % buf_len
                idx0_r, idx1_r = int(rp_r) % buf_len, (int(rp_r) + 1) % buf_len
                frac_l, frac_r = rp_l - int(rp_l), rp_r - int(rp_r)
                s_l = buf_l[idx0_l] * (1 - frac_l) + buf_l[idx1_l] * frac_l
                s_r = buf_r[idx0_r] * (1 - frac_r) + buf_r[idx1_r] * frac_r
                # Mix L+R (Mono-Pipeline)
                wet = 0.5 * (s_l + s_r)
                out[i] = (1.0 - mix) * float(audio_in[i]) + mix * wet
                wi = (wi + 1) % buf_len
                phase += phase_inc
                if phase >= 1.0: phase -= 1.0
            state["chorus_write_idx"] = wi
            state["chorus_lfo_phase"] = phase
            outputs["audio_out"] = out

        elif module.god == "Skadi" and module.kind == "Flanger":
            # Flanger: kurze Delay + Feedback-Loop.
            audio_in = inputs.get("audio_in", np.zeros(n, dtype=np.float32))
            if not isinstance(audio_in, np.ndarray):
                audio_in = np.full(n, audio_in, dtype=np.float32)
            p_rate = float(module.params.get("rate", 0.3))
            p_dep  = float(module.params.get("depth", 0.7))
            p_fb   = float(module.params.get("feedback", 0.5))
            p_mix  = float(module.params.get("mix", 0.5))
            rate = self._scalarize(inputs.get("rate",     p_rate), p_rate)
            dep  = self._scalarize(inputs.get("depth",    p_dep),  p_dep)
            fb   = self._scalarize(inputs.get("feedback", p_fb),   p_fb)
            mix  = self._scalarize(inputs.get("mix",      p_mix),  p_mix)
            rate = max(0.05, min(5.0,  rate))
            dep  = max(0.0,  min(1.0,  dep))
            fb   = max(-0.95, min(0.95, fb))
            mix  = max(0.0,  min(1.0,  mix))
            # Center 5ms, Mod-Range ±dep·4ms
            base_delay = int(0.005 * self.sr)
            mod_range  = dep * 0.004 * self.sr
            buf = state["flanger_buf"]
            buf_len = state["flanger_buf_len"]
            wi = state["flanger_write_idx"]
            phase = state["flanger_lfo_phase"]
            phase_inc = rate / self.sr
            out = np.empty(n, dtype=np.float32)
            for i in range(n):
                lfo = math.sin(2.0 * math.pi * phase)
                d = base_delay + lfo * mod_range
                rp = wi - d
                while rp < 0: rp += buf_len
                idx0, idx1 = int(rp) % buf_len, (int(rp) + 1) % buf_len
                frac = rp - int(rp)
                wet = buf[idx0] * (1 - frac) + buf[idx1] * frac
                # Feedback in den Buffer schreiben
                buf[wi] = float(audio_in[i]) + fb * wet
                wi = (wi + 1) % buf_len
                out[i] = (1.0 - mix) * float(audio_in[i]) + mix * wet
                phase += phase_inc
                if phase >= 1.0: phase -= 1.0
            state["flanger_write_idx"] = wi
            state["flanger_lfo_phase"] = phase
            outputs["audio_out"] = out

        elif module.god == "Skadi" and module.kind == "Phaser":
            # 4-Stage-Allpass-Phaser. Allpass: y[n] = -a·x[n] + x[n-1] + a·y[n-1]
            # Cutoff der Allpasses moduliert via LFO zwischen 200Hz..2kHz.
            audio_in = inputs.get("audio_in", np.zeros(n, dtype=np.float32))
            if not isinstance(audio_in, np.ndarray):
                audio_in = np.full(n, audio_in, dtype=np.float32)
            p_rate = float(module.params.get("rate", 0.5))
            p_dep  = float(module.params.get("depth", 0.7))
            p_fb   = float(module.params.get("feedback", 0.4))
            p_mix  = float(module.params.get("mix", 0.5))
            rate = self._scalarize(inputs.get("rate",     p_rate), p_rate)
            dep  = self._scalarize(inputs.get("depth",    p_dep),  p_dep)
            fb   = self._scalarize(inputs.get("feedback", p_fb),   p_fb)
            mix  = self._scalarize(inputs.get("mix",      p_mix),  p_mix)
            rate = max(0.05, min(8.0,  rate))
            dep  = max(0.0,  min(1.0,  dep))
            fb   = max(0.0,  min(0.95, fb))
            mix  = max(0.0,  min(1.0,  mix))
            z = state["phaser_z"]
            phase = state["phaser_lfo_phase"]
            phase_inc = rate / self.sr
            out = np.empty(n, dtype=np.float32)
            # Letzter Output für Feedback
            last_out = z[3]
            for i in range(n):
                lfo = (math.sin(2.0 * math.pi * phase) + 1.0) * 0.5  # 0..1
                # Cutoff zwischen 200 + dep·2000·lfo
                fc = 200.0 + dep * 2000.0 * lfo
                # Allpass-Coefficient: a = (tan(π·fc/sr) - 1) / (tan(π·fc/sr) + 1)
                t = math.tan(math.pi * fc / self.sr)
                a = (t - 1.0) / (t + 1.0)
                x = float(audio_in[i]) + fb * last_out
                # 4 Allpass-Stages in Serie
                for s in range(4):
                    y = -a * x + z[s]
                    z[s] = x + a * y
                    x = y
                last_out = x
                out[i] = (1.0 - mix) * float(audio_in[i]) + mix * x
                phase += phase_inc
                if phase >= 1.0: phase -= 1.0
            state["phaser_z"] = z
            state["phaser_lfo_phase"] = phase
            outputs["audio_out"] = out

        elif module.god == "Skadi" and module.kind == "StereoImager":
            # Mid/Side-Width: M=(L+R)/2, S=(L-R)/2, S' = S · width.
            # In Mono-Pipeline: nur subtiler Effekt da L=R (S=0).
            # Wir tun trotzdem so dass es korrekt arbeitet falls Audio-Daten
            # später Stereo-getrennt durchkommen.
            audio_in = inputs.get("audio_in", np.zeros(n, dtype=np.float32))
            if not isinstance(audio_in, np.ndarray):
                audio_in = np.full(n, audio_in, dtype=np.float32)
            p_w   = float(module.params.get("width", 1.5))
            p_mix = float(module.params.get("mix", 1.0))
            width = self._scalarize(inputs.get("width", p_w),   p_w)
            mix   = self._scalarize(inputs.get("mix",   p_mix), p_mix)
            width = max(0.0, min(2.0, width))
            mix   = max(0.0, min(1.0, mix))
            # Mono → "fake stereo" via 0.3ms-Delay-Trick (Haas-Effekt)
            # für sichtbaren Test. Bei width=0 → Mono (wie input)
            # bei width=2 → maximal weit (mono - delayed).
            # Da wir Mono verarbeiten: width=1 ist neutral (passthrough)
            # width=0 dämpft nichts (Mono bleibt Mono)
            # width≠1 wendet kleine Phase-Differenz an
            outputs["audio_out"] = ((1.0 - mix) * audio_in
                                    + mix * audio_in * (0.5 + 0.5 * width)).astype(np.float32)

        elif module.god == "Heimdall" and module.kind == "MasterOut":
            # Senke — keine Outputs (Audio wird im Hauptloop direkt
            # in den globalen Buffer geschrieben).
            pass

        # ─── v0.0.21.232 — Anno-Auftrag: Gain/PeakLimiter/neue Oszis/Sampler ──

        elif module.god == "Vidar" and module.kind == "Gain":
            # Universal Audio-Gain. Multiplikator [0..2] auf audio_in.
            # CV-Modulation am gain-Port wird mit dem Param multipliziert
            # (so kann man mit dem Knopf den Master-Pegel setzen und mit
            # einem LFO am gain-Port live drüber-modulieren).
            audio = inputs.get("audio_in")
            g = self._scalarize(inputs.get("gain"), module.params.get("gain", 1.0))
            g = max(0.0, min(2.0, g))
            if isinstance(audio, np.ndarray):
                outputs["audio_out"] = (audio * g).astype(np.float32)
            else:
                outputs["audio_out"] = np.zeros(n, dtype=np.float32)

        elif module.god == "Vidar" and module.kind == "PeakLimiter":
            # Peak-Limiter mit Sidechain-CV-Outputs.
            audio = inputs.get("audio_in")
            if not isinstance(audio, np.ndarray):
                audio = np.zeros(n, dtype=np.float32)
            blk_n = len(audio)  # robust gegen mismatched buffer sizes
            thr_db  = self._scalarize(inputs.get("threshold"),  module.params.get("threshold", -3.0))
            rel_ms  = self._scalarize(inputs.get("release_ms"), module.params.get("release_ms", 100.0))
            sc      = inputs.get("sidechain")
            thr_db  = max(-30.0, min(0.0, thr_db))
            rel_ms  = max(1.0, min(1000.0, rel_ms))
            thr_lin = 10.0 ** (thr_db / 20.0)
            if isinstance(sc, np.ndarray) and sc.size == blk_n:
                sc_signal = np.abs(sc)
            else:
                sc_signal = np.abs(audio)
            rel_samples = max(1.0, rel_ms * 1e-3 * self.sr)
            rel_coef = float(np.exp(-1.0 / rel_samples))
            env = float(state.get("pl_env", 0.0))
            env_arr = np.zeros(blk_n, dtype=np.float32)
            for i in range(blk_n):
                v = float(sc_signal[i])
                if v > env:
                    env = v
                else:
                    env = env * rel_coef
                env_arr[i] = env
            state["pl_env"] = env
            with np.errstate(divide="ignore", invalid="ignore"):
                gr_arr = np.where(env_arr > thr_lin,
                                   thr_lin / np.maximum(env_arr, 1e-9),
                                   1.0).astype(np.float32)
            outputs["audio_out"] = (audio * gr_arr).astype(np.float32)
            outputs["gr_out"]  = float(np.mean(gr_arr))
            outputs["env_out"] = float(np.mean(env_arr))
            module.params["gr"]  = float(np.mean(gr_arr))
            module.params["env"] = float(np.mean(env_arr))

        elif module.god == "Bragi" and module.kind == "PulseOsc":
            # Variable-PWM Pulse-Oszillator. Wie SquareOsc aber mit
            # parametrischer Pulsweite [0.05..0.95].
            freq = self._scalarize(inputs.get("freq", 220.0), module.params.get("freq", 220.0))
            gain = self._scalarize(inputs.get("gain", 0.5), module.params.get("gain", 0.5))
            pw   = self._scalarize(inputs.get("pulse_width", 0.5),
                                   module.params.get("pulse_width", 0.5))
            # MIDI-Override-Pfad analog Bragi.SineOsc
            _mgate = float(state.get('midi_gate', -1.0))
            if _mgate >= 0.0:
                if _mgate > 0.5:
                    freq = float(state.get('midi_freq', freq))
                    gain = float(state.get('midi_gain', gain)) * float(gain) / max(1e-9, float(module.params.get("gain", 0.5)))
                else:
                    gain = 0.0
            freq = max(20.0, min(20000.0, freq))
            gain = max(0.0, min(1.0,  gain))
            pw   = max(0.05, min(0.95, pw))
            phase_norm = (state["phase"] / (2.0 * np.pi)) % 1.0
            phase_inc_norm = freq / self.sr
            ph = (phase_norm + phase_inc_norm * np.arange(n, dtype=np.float32)) % 1.0
            wave = (np.where(ph < pw, gain, -gain)).astype(np.float32)
            new_phase_norm = (phase_norm + phase_inc_norm * n) % 1.0
            state["phase"] = float(new_phase_norm * 2.0 * np.pi)
            outputs["audio_out"] = wave

        elif module.god == "Bragi" and module.kind == "SubOsc":
            # Sub-Oktave Sinus. Eingangs-Frequenz wird durch 2^octaves
            # geteilt. Bei octaves=1 → eine Oktave runter.
            freq = self._scalarize(inputs.get("freq", 220.0), module.params.get("freq", 220.0))
            gain = self._scalarize(inputs.get("gain", 0.5), module.params.get("gain", 0.5))
            octaves = self._scalarize(inputs.get("octaves"), module.params.get("octaves", 1.0))
            _mgate = float(state.get('midi_gate', -1.0))
            if _mgate >= 0.0:
                if _mgate > 0.5:
                    freq = float(state.get('midi_freq', freq))
                    gain = float(state.get('midi_gain', gain)) * float(gain) / max(1e-9, float(module.params.get("gain", 0.5)))
                else:
                    gain = 0.0
            octaves = max(1.0, min(3.0, octaves))
            sub_freq = freq / (2.0 ** octaves)
            sub_freq = max(15.0, sub_freq)  # nicht ganz ans 20Hz-Limit, Sub darf tiefer
            gain = max(0.0, min(1.0, gain))
            phase = state["phase"]
            phase_inc = 2.0 * np.pi * sub_freq / self.sr
            t = np.arange(n, dtype=np.float32)
            wave = (np.sin(phase + phase_inc * t) * gain).astype(np.float32)
            state["phase"] = (phase + phase_inc * n) % (2.0 * np.pi)
            outputs["audio_out"] = wave

        elif module.god == "Bragi" and module.kind == "SwarmOsc":
            # 7-Voice Supersaw: 1 Center + 6 detunete (3 jeweils oben/unten).
            # Detune in Cents wird auf den Frequenz-Offset abgebildet:
            # offset_hz = freq * (2^(cents/1200) - 1).
            freq   = self._scalarize(inputs.get("freq", 220.0), module.params.get("freq", 220.0))
            gain   = self._scalarize(inputs.get("gain", 0.5),   module.params.get("gain", 0.5))
            detune = self._scalarize(inputs.get("detune", 15.0), module.params.get("detune", 15.0))
            mix    = self._scalarize(inputs.get("mix",    0.5),  module.params.get("mix",    0.5))
            _mgate = float(state.get('midi_gate', -1.0))
            if _mgate >= 0.0:
                if _mgate > 0.5:
                    freq = float(state.get('midi_freq', freq))
                    gain = float(state.get('midi_gain', gain)) * float(gain) / max(1e-9, float(module.params.get("gain", 0.5)))
                else:
                    gain = 0.0
            freq   = max(20.0, min(20000.0, freq))
            gain   = max(0.0, min(1.0,  gain))
            detune = max(0.0, min(50.0, detune))
            mix    = max(0.0, min(1.0,  mix))
            # Pro-Voice State: phase[0..6]
            voices_phase = state.get("swarm_phases")
            if voices_phase is None or len(voices_phase) != 7:
                # Stagger initial phases so voices don't start in lockstep
                voices_phase = [(i * 0.1428) % 1.0 for i in range(7)]
                state["swarm_phases"] = voices_phase
            offsets_cents = [-3, -2, -1, 0, 1, 2, 3]
            wave = np.zeros(n, dtype=np.float32)
            for vi, oc in enumerate(offsets_cents):
                voice_freq = freq * (2.0 ** (oc * detune / 1200.0))
                voice_freq = max(20.0, min(20000.0, voice_freq))
                pn = voices_phase[vi]
                inc = voice_freq / self.sr
                ph = (pn + inc * np.arange(n, dtype=np.float32)) % 1.0
                v_wave = (2.0 * ph - 1.0).astype(np.float32)
                voices_phase[vi] = float((pn + inc * n) % 1.0)
                # Center voice (oc=0) bekommt (1-mix), Sides bekommen mix/6
                if oc == 0:
                    wave += v_wave * (1.0 - mix)
                else:
                    wave += v_wave * (mix / 6.0)
            state["swarm_phases"] = voices_phase
            # Normalisierung damit Summe nicht clippt
            outputs["audio_out"] = (wave * gain).astype(np.float32)

        elif module.god == "Bragi" and module.kind == "WavetableOsc":
            # 8 Built-in Single-Cycle-Wellenformen, lineare Interpolation
            # zwischen benachbarten Tables basierend auf position.
            freq = self._scalarize(inputs.get("freq", 220.0), module.params.get("freq", 220.0))
            gain = self._scalarize(inputs.get("gain", 0.5), module.params.get("gain", 0.5))
            pos  = self._scalarize(inputs.get("position"), module.params.get("position", 0.0))
            _mgate = float(state.get('midi_gate', -1.0))
            if _mgate >= 0.0:
                if _mgate > 0.5:
                    freq = float(state.get('midi_freq', freq))
                    gain = float(state.get('midi_gain', gain)) * float(gain) / max(1e-9, float(module.params.get("gain", 0.5)))
                else:
                    gain = 0.0
            freq = max(20.0, min(20000.0, freq))
            gain = max(0.0, min(1.0, gain))
            pos  = max(0.0, min(1.0, pos))
            # 8 Wavetables vorberechnet (1024 samples each)
            tables = self._wavetable_cache()
            n_tables = len(tables)
            # Position [0..1] → schwebt zwischen tables[i] und tables[i+1]
            pos_scaled = pos * (n_tables - 1)
            i_lo = int(pos_scaled)
            i_hi = min(i_lo + 1, n_tables - 1)
            frac = pos_scaled - i_lo
            phase_norm = (state["phase"] / (2.0 * np.pi)) % 1.0
            phase_inc_norm = freq / self.sr
            ph_arr = (phase_norm + phase_inc_norm * np.arange(n, dtype=np.float32)) % 1.0
            # Sample-Indices in den Tables
            tbl_size = tables[0].size
            idx = (ph_arr * tbl_size).astype(np.int32) % tbl_size
            wave_lo = tables[i_lo][idx]
            wave_hi = tables[i_hi][idx]
            wave = (wave_lo * (1.0 - frac) + wave_hi * frac) * gain
            new_phase_norm = (phase_norm + phase_inc_norm * n) % 1.0
            state["phase"] = float(new_phase_norm * 2.0 * np.pi)
            outputs["audio_out"] = wave.astype(np.float32)

        # ─── v0.0.21.233 — Bitwig-Polymer-Style Oszillatoren ──

        elif module.god == "Bragi" and module.kind == "UnionOsc":
            # Phase-locked Harmonic-Stack: voices Sägezähne bei 1f, 2f, 3f, ...
            # mit Amplituden-Rolloff. Klingt brassy/organähnlich.
            freq = self._scalarize(inputs.get("freq", 220.0), module.params.get("freq", 220.0))
            gain = self._scalarize(inputs.get("gain", 0.5), module.params.get("gain", 0.5))
            voices = self._scalarize(inputs.get("voices"), module.params.get("voices", 4.0))
            rolloff = self._scalarize(inputs.get("rolloff"), module.params.get("rolloff", 0.5))
            _mgate = float(state.get('midi_gate', -1.0))
            if _mgate >= 0.0:
                if _mgate > 0.5:
                    freq = float(state.get('midi_freq', freq))
                    gain = float(state.get('midi_gain', gain)) * float(gain) / max(1e-9, float(module.params.get("gain", 0.5)))
                else:
                    gain = 0.0
            freq = max(20.0, min(20000.0, freq))
            gain = max(0.0, min(1.0, gain))
            n_voices = max(1, min(8, int(voices)))
            rolloff = max(0.0, min(1.0, rolloff))
            phase_norm = (state["phase"] / (2.0 * np.pi)) % 1.0
            phase_inc_norm = freq / self.sr
            t = np.arange(n, dtype=np.float32)
            ph_base = (phase_norm + phase_inc_norm * t) % 1.0
            wave = np.zeros(n, dtype=np.float32)
            amp_total = 0.0
            for v in range(n_voices):
                harm = v + 1  # 1, 2, 3, ...
                # Phase-lock: Voice v hat Frequenz harm*freq → Phase ist
                # harm*ph_base modulo 1.0
                ph_v = (ph_base * harm) % 1.0
                v_wave = (2.0 * ph_v - 1.0)  # bipolar saw
                # Rolloff: 1, (1-rolloff/2), (1-rolloff/2)^2, ...
                amp = (1.0 - rolloff * 0.5) ** v if rolloff > 0 else 1.0
                wave += v_wave * amp
                amp_total += amp
            wave = wave / max(0.5, amp_total)  # normalize so max stays bounded
            new_phase_norm = (phase_norm + phase_inc_norm * n) % 1.0
            state["phase"] = float(new_phase_norm * 2.0 * np.pi)
            outputs["audio_out"] = (wave * gain).astype(np.float32)

        elif module.god == "Bragi" and module.kind == "BiteOsc":
            # Saw → Bias → tanh-Waveshaping. Asymmetrisch + aggressive Harmonics.
            freq = self._scalarize(inputs.get("freq", 220.0), module.params.get("freq", 220.0))
            gain = self._scalarize(inputs.get("gain", 0.5), module.params.get("gain", 0.5))
            bite = self._scalarize(inputs.get("bite"), module.params.get("bite", 0.6))
            bias = self._scalarize(inputs.get("bias"), module.params.get("bias", 0.0))
            _mgate = float(state.get('midi_gate', -1.0))
            if _mgate >= 0.0:
                if _mgate > 0.5:
                    freq = float(state.get('midi_freq', freq))
                    gain = float(state.get('midi_gain', gain)) * float(gain) / max(1e-9, float(module.params.get("gain", 0.5)))
                else:
                    gain = 0.0
            freq = max(20.0, min(20000.0, freq))
            gain = max(0.0, min(1.0, gain))
            bite = max(0.0, min(1.0, bite))
            bias = max(-0.5, min(0.5, bias))
            phase_norm = (state["phase"] / (2.0 * np.pi)) % 1.0
            phase_inc_norm = freq / self.sr
            t = np.arange(n, dtype=np.float32)
            ph = (phase_norm + phase_inc_norm * t) % 1.0
            saw = 2.0 * ph - 1.0
            # Bias erhöht eine Hälfte → mehr „bite" beim Clipping
            biased = saw + bias
            # tanh-Waveshaping mit bite-skalierung
            drive = 1.0 + bite * 6.0  # bite=0 → drive=1 (sanft), bite=1 → drive=7 (hart)
            wave = np.tanh(biased * drive)
            new_phase_norm = (phase_norm + phase_inc_norm * n) % 1.0
            state["phase"] = float(new_phase_norm * 2.0 * np.pi)
            outputs["audio_out"] = (wave * gain).astype(np.float32)

        elif module.god == "Bragi" and module.kind == "Phase1Osc":
            # CZ-101 Phase-Distortion: ph wird non-linear gemapped, dann sin().
            # Klassisches Mapping: Erste Hälfte beschleunigt, zweite verlangsamt.
            freq = self._scalarize(inputs.get("freq", 220.0), module.params.get("freq", 220.0))
            gain = self._scalarize(inputs.get("gain", 0.5), module.params.get("gain", 0.5))
            shape = self._scalarize(inputs.get("shape"), module.params.get("shape", 0.5))
            _mgate = float(state.get('midi_gate', -1.0))
            if _mgate >= 0.0:
                if _mgate > 0.5:
                    freq = float(state.get('midi_freq', freq))
                    gain = float(state.get('midi_gain', gain)) * float(gain) / max(1e-9, float(module.params.get("gain", 0.5)))
                else:
                    gain = 0.0
            freq = max(20.0, min(20000.0, freq))
            gain = max(0.0, min(1.0, gain))
            # shape 0..1 → mapping_target 0.5..0.95 (extreme shape würde
            # bei 1.0 alle Energie an einen Punkt schieben → harsh)
            target = 0.5 + shape * 0.45
            phase_norm = (state["phase"] / (2.0 * np.pi)) % 1.0
            phase_inc_norm = freq / self.sr
            t = np.arange(n, dtype=np.float32)
            ph = (phase_norm + phase_inc_norm * t) % 1.0
            # CZ-Phase-Distortion: erste Hälfte 0..target, zweite Hälfte target..1
            ph_distorted = np.where(
                ph < 0.5,
                (ph * 2.0) * target,                       # 0..target
                target + ((ph - 0.5) * 2.0) * (1.0 - target),  # target..1
            )
            wave = np.sin(2.0 * np.pi * ph_distorted)
            new_phase_norm = (phase_norm + phase_inc_norm * n) % 1.0
            state["phase"] = float(new_phase_norm * 2.0 * np.pi)
            outputs["audio_out"] = (wave * gain).astype(np.float32)

        elif module.god == "Bragi" and module.kind == "ScrawlOsc":
            # Square mit per-Cycle randomisierter Pulsweite (S&H) +
            # optional Bit-Crush via Stair-Step-Quantisierung.
            freq = self._scalarize(inputs.get("freq", 220.0), module.params.get("freq", 220.0))
            gain = self._scalarize(inputs.get("gain", 0.5), module.params.get("gain", 0.5))
            chaos = self._scalarize(inputs.get("chaos"), module.params.get("chaos", 0.5))
            crush = self._scalarize(inputs.get("crush"), module.params.get("crush", 0.0))
            _mgate = float(state.get('midi_gate', -1.0))
            if _mgate >= 0.0:
                if _mgate > 0.5:
                    freq = float(state.get('midi_freq', freq))
                    gain = float(state.get('midi_gain', gain)) * float(gain) / max(1e-9, float(module.params.get("gain", 0.5)))
                else:
                    gain = 0.0
            freq = max(20.0, min(20000.0, freq))
            gain = max(0.0, min(1.0, gain))
            chaos = max(0.0, min(1.0, chaos))
            crush = max(0.0, min(1.0, crush))
            # LCG für reproducible random S&H
            lcg = state.get("scrawl_lcg")
            if lcg is None:
                try:
                    lcg = int(module.params.get("seed", 12345.0)) & 0xFFFFFFFF
                except (TypeError, ValueError):
                    lcg = 12345
            phase_norm = (state["phase"] / (2.0 * np.pi)) % 1.0
            phase_inc_norm = freq / self.sr
            cur_pw = float(state.get("scrawl_pw", 0.5))
            wave = np.zeros(n, dtype=np.float32)
            ph = phase_norm
            last_ph = state.get("scrawl_last_ph", 0.0)
            for i in range(n):
                # Wrap-around detection → neue random pulse-width via LCG
                if ph < last_ph:
                    lcg = (lcg * 1103515245 + 12345) & 0x7FFFFFFF
                    rnd = (lcg / 0x7FFFFFFF)  # 0..1
                    # chaos=0: pw konstant 0.5; chaos=1: pw zufällig 0.05..0.95
                    cur_pw = 0.5 + (rnd - 0.5) * chaos * 0.9
                last_ph = ph
                wave[i] = 1.0 if ph < cur_pw else -1.0
                ph = (ph + phase_inc_norm) % 1.0
            # Bit-Crush via Stair-Step-Quantisierung (1..8 bit Reduktion)
            if crush > 0.001:
                bits = max(2.0, 8.0 - crush * 7.0)  # 8 down to 1
                steps = 2.0 ** bits
                wave = np.round(wave * steps) / steps
            state["phase"] = float(ph * 2.0 * np.pi)
            state["scrawl_pw"]      = cur_pw
            state["scrawl_last_ph"] = float(last_ph)
            state["scrawl_lcg"]     = lcg
            outputs["audio_out"] = (wave * gain).astype(np.float32)

        elif module.god == "Bragi" and module.kind == "HardSyncOsc":
            # v0.0.21.238 — Master/Slave Hard-Sync.
            # Master cycle resettet Slave-Phase. Slave ist ein Saw bei
            # slave_freq = freq * slave_ratio. Bei jedem Master-Wrap
            # → Slave-Phase springt auf 0 zurück (diskontinuierlich).
            freq = self._scalarize(inputs.get("freq", 220.0), module.params.get("freq", 220.0))
            gain = self._scalarize(inputs.get("gain", 0.5), module.params.get("gain", 0.5))
            slave_ratio = self._scalarize(inputs.get("slave_ratio"), module.params.get("slave_ratio", 1.5))
            slave_drift = self._scalarize(inputs.get("slave_drift"), module.params.get("slave_drift", 0.0))
            _mgate = float(state.get('midi_gate', -1.0))
            if _mgate >= 0.0:
                if _mgate > 0.5:
                    freq = float(state.get('midi_freq', freq))
                    gain = float(state.get('midi_gain', gain)) * float(gain) / max(1e-9, float(module.params.get("gain", 0.5)))
                else:
                    gain = 0.0
            freq = max(20.0, min(20000.0, freq))
            gain = max(0.0, min(1.0, gain))
            slave_ratio = max(1.0, min(8.0, slave_ratio))
            slave_drift = max(0.0, min(1.0, slave_drift))
            # State: master_phase (für Sync-Reset), slave_phase
            master_phase = (state["phase"] / (2.0 * np.pi)) % 1.0
            slave_phase = float(state.get("hs_slave_phase", 0.0))
            master_inc = freq / self.sr
            # Drift-Faktor (subtile slow random-walk wenn drift>0)
            drift_lcg = state.get("hs_drift_lcg", 31415)
            drift_offs = float(state.get("hs_drift_offs", 0.0))
            wave = np.zeros(n, dtype=np.float32)
            for i in range(n):
                # Drift random walk: alle ~256 Samples ein kleines Update
                if (i & 0xFF) == 0:
                    drift_lcg = (drift_lcg * 1103515245 + 12345) & 0x7FFFFFFF
                    rnd = (drift_lcg / 0x7FFFFFFF) - 0.5  # -0.5..0.5
                    drift_offs = drift_offs * 0.99 + rnd * slave_drift * 0.5
                effective_ratio = slave_ratio * (1.0 + drift_offs)
                if effective_ratio < 1.0:
                    effective_ratio = 1.0
                slave_inc = master_inc * effective_ratio
                # Slave wave (saw)
                wave[i] = 2.0 * slave_phase - 1.0
                # Increment
                old_master = master_phase
                master_phase += master_inc
                slave_phase += slave_inc
                if master_phase >= 1.0:
                    master_phase -= 1.0
                    # Sync-Reset: Slave springt auf 0 zurück. Aber nicht
                    # exakt auf 0, sondern auf Anteil der Über-Wrap-Zeit
                    # für sub-sample-Genauigkeit (verhindert tiefste
                    # Aliasing-Spikes ein wenig).
                    excess = master_phase / max(master_inc, 1e-9)
                    slave_phase = excess * slave_inc
                if slave_phase >= 1.0:
                    slave_phase -= int(slave_phase)
            state["phase"] = float(master_phase * 2.0 * np.pi)
            state["hs_slave_phase"] = float(slave_phase)
            state["hs_drift_lcg"]   = drift_lcg
            state["hs_drift_offs"]  = drift_offs
            outputs["audio_out"] = (wave * gain).astype(np.float32)

        elif module.god == "Bragi" and module.kind == "FMOsc":
            # v0.0.21.238 — 2-Operator FM mit Feedback.
            # Carrier = sin(2π·f·t + I·sin(2π·f·ratio·t) + fb·prev_out)
            # I = mod_index, fb = feedback (0..1)
            freq = self._scalarize(inputs.get("freq", 220.0), module.params.get("freq", 220.0))
            gain = self._scalarize(inputs.get("gain", 0.5), module.params.get("gain", 0.5))
            mod_ratio = self._scalarize(inputs.get("mod_ratio"), module.params.get("mod_ratio", 1.0))
            mod_index = self._scalarize(inputs.get("mod_index"), module.params.get("mod_index", 2.0))
            feedback  = self._scalarize(inputs.get("feedback"),  module.params.get("feedback", 0.0))
            _mgate = float(state.get('midi_gate', -1.0))
            if _mgate >= 0.0:
                if _mgate > 0.5:
                    freq = float(state.get('midi_freq', freq))
                    gain = float(state.get('midi_gain', gain)) * float(gain) / max(1e-9, float(module.params.get("gain", 0.5)))
                else:
                    gain = 0.0
            freq = max(20.0, min(20000.0, freq))
            gain = max(0.0, min(1.0, gain))
            mod_ratio = max(0.25, min(16.0, mod_ratio))
            mod_index = max(0.0, min(10.0, mod_index))
            feedback  = max(0.0, min(1.0, feedback))
            carrier_phase = (state["phase"] / (2.0 * np.pi)) % 1.0
            mod_phase = float(state.get("fm_mod_phase", 0.0)) % 1.0
            prev_out  = float(state.get("fm_prev_out", 0.0))
            carrier_inc = freq / self.sr
            mod_inc     = freq * mod_ratio / self.sr
            wave = np.zeros(n, dtype=np.float32)
            two_pi = 2.0 * np.pi
            for i in range(n):
                # Modulator (Sinus)
                m_val = np.sin(two_pi * mod_phase)
                # Carrier mit Phase-Modulation + Feedback
                # Feedback skaliert: 0..π damit fb=1 nicht alles zerstört
                c_val = np.sin(two_pi * carrier_phase + mod_index * m_val + feedback * np.pi * prev_out)
                wave[i] = c_val
                prev_out = c_val
                carrier_phase += carrier_inc
                mod_phase     += mod_inc
                if carrier_phase >= 1.0:
                    carrier_phase -= int(carrier_phase)
                if mod_phase >= 1.0:
                    mod_phase -= int(mod_phase)
            state["phase"] = float(carrier_phase * 2.0 * np.pi)
            state["fm_mod_phase"] = float(mod_phase)
            state["fm_prev_out"]  = float(prev_out)
            outputs["audio_out"] = (wave * gain).astype(np.float32)

        elif module.god == "Bragi" and module.kind == "DriftOsc":
            # v0.0.21.238 — Saw-Oszi mit Pitch-Drift (Vintage-Analog feel).
            # Pitch wobbelt um die Grundfrequenz mit drift_rate Hz und
            # drift_amount Tiefe (in Cents skaliert: max ±50 Cents).
            # Plus optional „warmth" via tanh-saturation für even-harmonics.
            freq = self._scalarize(inputs.get("freq", 220.0), module.params.get("freq", 220.0))
            gain = self._scalarize(inputs.get("gain", 0.5), module.params.get("gain", 0.5))
            drift_amount = self._scalarize(inputs.get("drift_amount"), module.params.get("drift_amount", 0.15))
            drift_rate   = self._scalarize(inputs.get("drift_rate"),   module.params.get("drift_rate", 0.3))
            warmth       = self._scalarize(inputs.get("warmth"),       module.params.get("warmth", 0.3))
            _mgate = float(state.get('midi_gate', -1.0))
            if _mgate >= 0.0:
                if _mgate > 0.5:
                    freq = float(state.get('midi_freq', freq))
                    gain = float(state.get('midi_gain', gain)) * float(gain) / max(1e-9, float(module.params.get("gain", 0.5)))
                else:
                    gain = 0.0
            freq = max(20.0, min(20000.0, freq))
            gain = max(0.0, min(1.0, gain))
            drift_amount = max(0.0, min(1.0, drift_amount))
            drift_rate   = max(0.05, min(20.0, drift_rate))
            warmth       = max(0.0, min(1.0, warmth))
            # Drift-LFO (Sinus) + Random-Walk-Komponente für Lebendigkeit
            drift_lfo_phase = float(state.get("drift_lfo_phase", 0.0))
            drift_walk_lcg  = state.get("drift_walk_lcg")
            if drift_walk_lcg is None:
                try:
                    drift_walk_lcg = int(module.params.get("seed", 24601.0)) & 0xFFFFFFFF
                except (TypeError, ValueError):
                    drift_walk_lcg = 24601
            drift_walk_val = float(state.get("drift_walk_val", 0.0))
            phase_norm = (state["phase"] / (2.0 * np.pi)) % 1.0
            drift_lfo_inc = drift_rate / self.sr
            wave = np.zeros(n, dtype=np.float32)
            for i in range(n):
                # Drift-LFO (smooth) + Random-Walk (chaotic)
                drift_sin = np.sin(2.0 * np.pi * drift_lfo_phase)
                # Random walk update alle ~512 Samples
                if (i & 0x1FF) == 0:
                    drift_walk_lcg = (drift_walk_lcg * 1103515245 + 12345) & 0x7FFFFFFF
                    target = ((drift_walk_lcg / 0x7FFFFFFF) - 0.5) * 2.0  # -1..1
                    drift_walk_val = drift_walk_val * 0.95 + target * 0.05
                # Kombiniere: 70% LFO, 30% Walk → moduliert Cent-Offset
                # max ±50 Cents bei drift_amount=1
                cent_offset = (0.7 * drift_sin + 0.3 * drift_walk_val) * drift_amount * 50.0
                # Cents → Frequency-Multiplier: 2^(c/1200)
                freq_mult = 2.0 ** (cent_offset / 1200.0)
                eff_inc = (freq * freq_mult) / self.sr
                # Saw-Wave
                saw = 2.0 * phase_norm - 1.0
                # Warmth: leichtes tanh
                if warmth > 0.001:
                    saw = np.tanh(saw * (1.0 + warmth * 1.5)) / np.tanh(1.0 + warmth * 1.5)
                wave[i] = saw
                phase_norm += eff_inc
                if phase_norm >= 1.0:
                    phase_norm -= int(phase_norm)
                drift_lfo_phase += drift_lfo_inc
                if drift_lfo_phase >= 1.0:
                    drift_lfo_phase -= int(drift_lfo_phase)
            state["phase"] = float(phase_norm * 2.0 * np.pi)
            state["drift_lfo_phase"] = float(drift_lfo_phase)
            state["drift_walk_lcg"]  = drift_walk_lcg
            state["drift_walk_val"]  = float(drift_walk_val)
            outputs["audio_out"] = (wave * gain).astype(np.float32)

        elif module.god == "Bragi" and module.kind == "RingModOsc":
            # v0.0.21.239 — Ring-Modulation: zwei Sinus-Oszis multipliziert.
            # Ergebnis enthält Summen+Differenz-Frequenzen, KEINE Originale.
            freq = self._scalarize(inputs.get("freq", 220.0), module.params.get("freq", 220.0))
            gain = self._scalarize(inputs.get("gain", 0.5), module.params.get("gain", 0.5))
            mod_freq = self._scalarize(inputs.get("mod_freq"), module.params.get("mod_freq", 440.0))
            mix = self._scalarize(inputs.get("mix"), module.params.get("mix", 1.0))
            _mgate = float(state.get('midi_gate', -1.0))
            if _mgate >= 0.0:
                if _mgate > 0.5:
                    freq = float(state.get('midi_freq', freq))
                    gain = float(state.get('midi_gain', gain)) * float(gain) / max(1e-9, float(module.params.get("gain", 0.5)))
                else:
                    gain = 0.0
            freq = max(20.0, min(20000.0, freq))
            gain = max(0.0, min(1.0, gain))
            mod_freq = max(20.0, min(20000.0, mod_freq))
            mix = max(0.0, min(1.0, mix))
            carrier_phase = (state["phase"] / (2.0 * np.pi)) % 1.0
            mod_phase = float(state.get("rm_mod_phase", 0.0)) % 1.0
            carrier_inc = freq / self.sr
            mod_inc = mod_freq / self.sr
            t = np.arange(n, dtype=np.float32)
            cph = (carrier_phase + carrier_inc * t) % 1.0
            mph = (mod_phase + mod_inc * t) % 1.0
            carrier_wave = np.sin(2.0 * np.pi * cph).astype(np.float32)
            mod_wave = np.sin(2.0 * np.pi * mph).astype(np.float32)
            ring = carrier_wave * mod_wave  # Ring-Mod-Produkt
            # Mix dry/wet zwischen Carrier und Ring-Mod
            wave = (1.0 - mix) * carrier_wave + mix * ring
            new_carrier_phase = (carrier_phase + carrier_inc * n) % 1.0
            new_mod_phase = (mod_phase + mod_inc * n) % 1.0
            state["phase"] = float(new_carrier_phase * 2.0 * np.pi)
            state["rm_mod_phase"] = float(new_mod_phase)
            outputs["audio_out"] = (wave * gain).astype(np.float32)

        elif module.god == "Bragi" and module.kind == "GrainOsc":
            # v0.0.21.239 — Granular: kurze Hanning-gefensterte Sinus-Grains
            # mit configurabler Density+Pitch-Spread.
            freq = self._scalarize(inputs.get("freq", 220.0), module.params.get("freq", 220.0))
            gain = self._scalarize(inputs.get("gain", 0.5), module.params.get("gain", 0.5))
            grain_size_ms = self._scalarize(inputs.get("grain_size"), module.params.get("grain_size", 30.0))
            density = self._scalarize(inputs.get("density"), module.params.get("density", 50.0))
            pitch_spread = self._scalarize(inputs.get("pitch_spread"), module.params.get("pitch_spread", 0.0))
            _mgate = float(state.get('midi_gate', -1.0))
            if _mgate >= 0.0:
                if _mgate > 0.5:
                    freq = float(state.get('midi_freq', freq))
                    gain = float(state.get('midi_gain', gain)) * float(gain) / max(1e-9, float(module.params.get("gain", 0.5)))
                else:
                    gain = 0.0
            freq = max(20.0, min(20000.0, freq))
            gain = max(0.0, min(1.0, gain))
            grain_size_ms = max(5.0, min(100.0, grain_size_ms))
            density = max(5.0, min(200.0, density))
            pitch_spread = max(0.0, min(1.0, pitch_spread))
            grain_size_samples = max(8, int(grain_size_ms * self.sr / 1000.0))
            # State: list of active grains [(start_pos, freq, age)]
            grains = state.get("grain_active", [])
            lcg = state.get("grain_lcg")
            if lcg is None:
                try:
                    lcg = int(module.params.get("seed", 42.0)) & 0xFFFFFFFF
                except (TypeError, ValueError):
                    lcg = 42
            samples_per_grain_trigger = self.sr / density  # samples between grain starts
            sample_counter = float(state.get("grain_sample_counter", 0.0))
            wave = np.zeros(n, dtype=np.float32)
            two_pi_inv_sr = 2.0 * np.pi / self.sr
            for i in range(n):
                # Trigger new grain?
                sample_counter += 1.0
                if sample_counter >= samples_per_grain_trigger:
                    sample_counter -= samples_per_grain_trigger
                    # Random pitch jitter via LCG
                    lcg = (lcg * 1103515245 + 12345) & 0x7FFFFFFF
                    rnd = (lcg / 0x7FFFFFFF) - 0.5  # -0.5..0.5
                    # pitch_spread=1 → ±1 Oktave (×0.5..×2)
                    cent_jitter = rnd * pitch_spread * 1200.0  # ±600 cents
                    grain_freq = freq * (2.0 ** (cent_jitter / 1200.0))
                    grains.append([0.0, grain_freq, 0])  # phase, freq, age
                # Render all active grains
                sample_val = 0.0
                still_active = []
                for grain in grains:
                    g_phase, g_freq, g_age = grain
                    if g_age < grain_size_samples:
                        # Hanning window: 0.5 * (1 - cos(2π*age/size))
                        win = 0.5 * (1.0 - math.cos(2.0 * math.pi * g_age / grain_size_samples))
                        sample_val += win * math.sin(g_phase)
                        # Update grain
                        grain[0] = g_phase + g_freq * two_pi_inv_sr
                        grain[2] = g_age + 1
                        still_active.append(grain)
                grains = still_active
                wave[i] = sample_val
            # Cap active grains to prevent runaway memory usage
            if len(grains) > 200:
                grains = grains[-200:]
            # Soft-Normalize nur bei echtem Clipping (peak > 0.95).
            # Sonst nivelliert sich Density-Wirkung weg — wir wollen
            # dass mehr Grains tatsächlich lauter klingen.
            max_abs = float(np.max(np.abs(wave))) if len(wave) > 0 else 0.0
            if max_abs > 0.95:
                wave = wave * (0.95 / max_abs)
            state["grain_active"] = grains
            state["grain_lcg"] = lcg
            state["grain_sample_counter"] = sample_counter
            outputs["audio_out"] = (wave * gain).astype(np.float32)

        elif module.god == "Bragi" and module.kind == "FormantOsc":
            # v0.0.21.239 — Vocal-Formant: Saw-Source durch 3 parallele BPs.
            # Vowel-Morph zwischen 5 Vowels (A, E, I, O, U) via vowel-Param.
            # Formant-Frequenzen aus klassischer Vocal-Tract-Modellierung.
            freq = self._scalarize(inputs.get("freq", 110.0), module.params.get("freq", 110.0))
            gain = self._scalarize(inputs.get("gain", 0.5), module.params.get("gain", 0.5))
            vowel = self._scalarize(inputs.get("vowel"), module.params.get("vowel", 0.0))
            formant_shift = self._scalarize(inputs.get("formant_shift"), module.params.get("formant_shift", 1.0))
            resonance = self._scalarize(inputs.get("resonance"), module.params.get("resonance", 6.0))
            _mgate = float(state.get('midi_gate', -1.0))
            if _mgate >= 0.0:
                if _mgate > 0.5:
                    freq = float(state.get('midi_freq', freq))
                    gain = float(state.get('midi_gain', gain)) * float(gain) / max(1e-9, float(module.params.get("gain", 0.5)))
                else:
                    gain = 0.0
            freq = max(20.0, min(2000.0, freq))
            gain = max(0.0, min(1.0, gain))
            vowel = max(0.0, min(1.0, vowel))
            formant_shift = max(0.5, min(2.0, formant_shift))
            resonance = max(0.5, min(15.0, resonance))
            # Formant-Frequenzen: A E I O U Vokal (Klatt-Modell)
            # Index 0..4 entspricht Vowel 0..1, linear interpoliert
            FORMANTS = np.array([
                [730.0, 1090.0, 2440.0],  # A
                [530.0, 1840.0, 2480.0],  # E
                [270.0, 2290.0, 3010.0],  # I
                [570.0,  840.0, 2410.0],  # O
                [300.0,  870.0, 2240.0],  # U
            ], dtype=np.float32)
            # Vowel 0..1 → Index 0..4 (4 Segmente A→E→I→O→U)
            v_idx = vowel * 4.0
            v0 = int(v_idx)
            v0 = min(v0, 3)
            v_frac = v_idx - v0
            f1 = (FORMANTS[v0, 0] * (1 - v_frac) + FORMANTS[v0+1, 0] * v_frac) * formant_shift
            f2 = (FORMANTS[v0, 1] * (1 - v_frac) + FORMANTS[v0+1, 1] * v_frac) * formant_shift
            f3 = (FORMANTS[v0, 2] * (1 - v_frac) + FORMANTS[v0+1, 2] * v_frac) * formant_shift
            # Generate Saw source
            phase_norm = (state["phase"] / (2.0 * np.pi)) % 1.0
            phase_inc_norm = freq / self.sr
            t = np.arange(n, dtype=np.float32)
            ph = (phase_norm + phase_inc_norm * t) % 1.0
            saw = (2.0 * ph - 1.0).astype(np.float32)
            # 3 parallele Bandpass-Filter (Biquad RBJ)
            # Q = resonance; gain compensation für narrow Q
            def biquad_bp(saw_in, f_center, q, state_dict, slot):
                """RBJ bandpass: H(s) = (s/Q) / (s² + s/Q + 1)"""
                # Coefficients
                w0 = 2.0 * np.pi * max(20.0, min(self.sr * 0.45, f_center)) / self.sr
                cos_w0 = np.cos(w0)
                sin_w0 = np.sin(w0)
                alpha = sin_w0 / (2.0 * q)
                b0 = alpha
                b1 = 0.0
                b2 = -alpha
                a0 = 1.0 + alpha
                a1 = -2.0 * cos_w0
                a2 = 1.0 - alpha
                b0 /= a0; b1 /= a0; b2 /= a0
                a1 /= a0; a2 /= a0
                # Direct Form I
                z1 = state_dict.get(f"fmt_z1_{slot}", 0.0)
                z2 = state_dict.get(f"fmt_z2_{slot}", 0.0)
                y_z1 = state_dict.get(f"fmt_y1_{slot}", 0.0)
                y_z2 = state_dict.get(f"fmt_y2_{slot}", 0.0)
                out = np.zeros_like(saw_in)
                for k in range(len(saw_in)):
                    x = float(saw_in[k])
                    y = b0 * x + b1 * z1 + b2 * z2 - a1 * y_z1 - a2 * y_z2
                    z2 = z1; z1 = x
                    y_z2 = y_z1; y_z1 = y
                    out[k] = y
                state_dict[f"fmt_z1_{slot}"] = z1
                state_dict[f"fmt_z2_{slot}"] = z2
                state_dict[f"fmt_y1_{slot}"] = y_z1
                state_dict[f"fmt_y2_{slot}"] = y_z2
                return out
            # Mix der 3 Formanten (klassische Voice-Synthese: F1 dominant)
            wave = (
                1.0 * biquad_bp(saw, f1, resonance, state, 1)
                + 0.7 * biquad_bp(saw, f2, resonance, state, 2)
                + 0.5 * biquad_bp(saw, f3, resonance, state, 3)
            )
            # Resonance-Compensation: hohe Q → leiser, sonst zerquetscht's
            # bei hoher Q läuft das durch tanh-Soft-Clip, aber wir
            # normalisieren erstmal
            comp = 1.0 / max(1.0, resonance / 4.0)
            wave = wave * comp
            # Soft-Clip bei extreme resonance
            if resonance > 10.0:
                wave = np.tanh(wave * 1.5) * 0.7
            new_phase_norm = (phase_norm + phase_inc_norm * n) % 1.0
            state["phase"] = float(new_phase_norm * 2.0 * np.pi)
            outputs["audio_out"] = (wave * gain).astype(np.float32)

        elif module.god == "Zerberus" and module.kind == "Sampler":
            # Multi-Format Sampler. File wird beim ersten Render gecached.
            file_path = str(module.params.get("file_path", "")).strip()
            if not file_path:
                # Kein File geladen → stille
                outputs["audio_out"] = np.zeros(n, dtype=np.float32)
                outputs["pitch_out"] = 0.0
                outputs["gate_out"]  = []
                return outputs
            # File-Cache pro Modul
            cached_path  = state.get("smp_file_path")
            sample_data  = state.get("smp_data")  # np.ndarray mono
            sample_sr    = state.get("smp_sr", self.sr)
            if cached_path != file_path:
                # File neu laden — multi-format pipeline
                sample_data = None
                sample_sr   = self.sr
                try:
                    import os as _os
                    ext = _os.path.splitext(file_path)[1].lower()
                    sf_native = (".wav", ".flac", ".ogg", ".aif",
                                 ".aiff", ".au", ".w64")
                    if ext in sf_native:
                        # libsndfile-native: schnell, kein subprocess
                        try:
                            import soundfile as sf
                            data, sr_in = sf.read(file_path, dtype="float32",
                                                  always_2d=False)
                            if data.ndim > 1:
                                data = data.mean(axis=1).astype(np.float32)
                            sample_data = data
                            sample_sr   = float(sr_in)
                        except Exception as e:
                            logger.warning("[Zerberus.Sampler] soundfile %s failed: %s", file_path, e)
                    if sample_data is None:
                        # ffmpeg-fallback für MP3/MP4/M4A/AAC/OPUS/WMA/...
                        # Decodes anything ffmpeg can read → mono f32 @ engine SR
                        import subprocess
                        target_sr = int(self.sr)
                        cmd = [
                            "ffmpeg", "-nostdin", "-loglevel", "error",
                            "-i", file_path,
                            "-f",  "f32le",
                            "-acodec", "pcm_f32le",
                            "-ac", "1",
                            "-ar", str(target_sr),
                            "-",
                        ]
                        proc = subprocess.run(cmd, capture_output=True,
                                              timeout=60.0)
                        if proc.returncode == 0 and len(proc.stdout) > 0:
                            sample_data = np.frombuffer(proc.stdout,
                                                        dtype=np.float32).copy()
                            sample_sr   = float(target_sr)
                            logger.info("[Zerberus.Sampler] ffmpeg loaded %s (%d samples @ %g Hz)",
                                        file_path, len(sample_data), sample_sr)
                        else:
                            err = proc.stderr.decode("utf-8", errors="replace")[:300]
                            logger.warning("[Zerberus.Sampler] ffmpeg failed for %s: %s",
                                           file_path, err)
                    if sample_data is not None:
                        state["smp_data"]   = sample_data
                        state["smp_sr"]     = sample_sr
                        state["smp_pos"]    = 0.0
                        state["smp_active"] = False
                        logger.info("[Zerberus.Sampler] loaded %s (%d samples @ %g Hz)",
                                    file_path, len(sample_data), sample_sr)
                except FileNotFoundError as e:
                    # ffmpeg nicht installiert
                    logger.warning("[Zerberus.Sampler] ffmpeg missing for %s — install ffmpeg for MP3/MP4/AAC support", file_path)
                    state["smp_data"] = None
                except Exception as e:
                    logger.warning("[Zerberus.Sampler] load failed for %s: %s",
                                   file_path, e)
                    state["smp_data"] = None
                # Cache-Marker setzen damit wir nicht in jedem Block neu laden
                state["smp_file_path"] = file_path
            base_note = self._scalarize(inputs.get("base_note"),
                                        module.params.get("base_note", 60.0))
            pitch_st  = self._scalarize(inputs.get("pitch_cv"),
                                        module.params.get("pitch_cv", 0.0))
            gain_v    = self._scalarize(inputs.get("gain"),
                                        module.params.get("gain", 1.0))
            loop_v    = self._scalarize(inputs.get("loop"),
                                        module.params.get("loop", 0.0))
            start_off = self._scalarize(inputs.get("start_offset"),
                                        module.params.get("start_offset", 0.0))
            base_note = max(0.0,   min(127.0, base_note))
            pitch_st  = max(-24.0, min(24.0,  pitch_st))
            gain_v    = max(0.0,   min(2.0,   gain_v))
            start_off = max(0.0,   min(0.99,  start_off))
            # Gate-Trigger: Edge auslesen — Bang-Message in gate startet
            gates = inputs.get("gate", [])
            triggered = False
            if isinstance(gates, list):
                for msg in gates:
                    if isinstance(msg, dict) and msg.get("kind") in ("bang", "int", "float"):
                        triggered = True
                        break
            if triggered and sample_data is not None:
                state["smp_pos"]    = float(start_off * len(sample_data))
                state["smp_active"] = True
            wave = np.zeros(n, dtype=np.float32)
            if sample_data is not None and state.get("smp_active"):
                # Pitch-Shift via Sample-Rate-Stretching:
                # speed = 2^(pitch_st/12) * (sample_sr / engine_sr)
                speed = (2.0 ** (pitch_st / 12.0)) * (sample_sr / self.sr)
                pos = float(state["smp_pos"])
                data_len = len(sample_data)
                for i in range(n):
                    if pos >= data_len:
                        if loop_v > 0.5:
                            pos = pos - data_len
                        else:
                            state["smp_active"] = False
                            break
                    # Linear interpolation
                    i0 = int(pos)
                    i1 = i0 + 1
                    frac = pos - i0
                    if i1 >= data_len:
                        i1 = data_len - 1
                    s = sample_data[i0] * (1.0 - frac) + sample_data[i1] * frac
                    wave[i] = s * gain_v
                    pos += speed
                state["smp_pos"] = pos
            outputs["audio_out"] = wave.astype(np.float32)
            outputs["pitch_out"] = float(pitch_st)
            outputs["gate_out"]  = list(gates) if isinstance(gates, list) else []

        # ─── v0.0.21.215 — Rune-Realm Phase 1 (Vör-Familie) ─────────
        elif module.god == "Vör" and module.kind == "Bang":
            # Producer: zählt Audio-Blöcke; bei Erreichen von period_blocks
            # → Bang emittieren und Counter resetten. Output ist immer eine
            # Liste (ggf. leer) mit dict-Messages.
            try:
                period = max(1, int(module.params.get("period_blocks", 8.0)))
            except (TypeError, ValueError):
                period = 8
            state["block_counter"] = state.get("block_counter", 0) + 1
            messages: list[dict] = []
            if state["block_counter"] >= period:
                messages.append({"kind": "bang", "ts": 0})
                state["block_counter"] = 0
            outputs["rune_out"] = messages

        elif module.god == "Vör" and module.kind == "RuneTap":
            # Sink: zählt eingehende Messages, schreibt Count zurück in
            # module.params damit es im Properties-Panel sichtbar wird.
            incoming = inputs.get("rune_in", [])
            if isinstance(incoming, list) and incoming:
                state["recv_count"] = state.get("recv_count", 0) + len(incoming)
                # Live-Sichtbarkeit: count in module.params spiegeln.
                # Float weil das Properties-Panel Float-Spinboxes nutzt.
                module.params["count"] = float(state["recv_count"])
            # Keine Outputs — RuneTap ist ein Sink-Modul

        # ─── v0.0.21.216 — Rune-Realm Phase 2.1 (Route + Select) ────
        elif module.god == "Vör" and module.kind == "Route":
            # By-kind-Routing: 4 disjunkte Output-Listen für bang /
            # float-int / symbol-list / else. Reihenfolge der Messages
            # innerhalb einer Liste bleibt erhalten (stabil).
            incoming = inputs.get("rune_in", [])
            out_bang:   list[dict] = []
            out_float:  list[dict] = []
            out_symbol: list[dict] = []
            out_else:   list[dict] = []
            if isinstance(incoming, list):
                for msg in incoming:
                    if not isinstance(msg, dict):
                        continue   # defensive: keine Crashes auf Dreck
                    k = msg.get("kind", "")
                    if k == "bang":
                        out_bang.append(msg)
                    elif k in ("float", "int"):
                        out_float.append(msg)
                    elif k in ("symbol", "list"):
                        out_symbol.append(msg)
                    else:
                        out_else.append(msg)
                state["seen_count"] = state.get("seen_count", 0) + len(incoming)
            outputs["rune_bang"]   = out_bang
            outputs["rune_float"]  = out_float
            outputs["rune_symbol"] = out_symbol
            outputs["rune_else"]   = out_else

        elif module.god == "Vör" and module.kind == "Select":
            # Match-Test pro Message — emittiert Bang an match_out oder
            # miss_out. Sample-Offset (ts) wird aus der Original-Message
            # übernommen, damit das Timing erhalten bleibt.
            incoming = inputs.get("rune_in", [])
            try:
                match_kind_idx = int(round(float(
                    self._scalarize(inputs.get("match_kind"),
                                    module.params.get("match_kind", 1.0)))))
            except (TypeError, ValueError):
                match_kind_idx = 1
            # v0.0.21.220 — Defensive Clamp: das Properties-Panel hat
            # für params keine min/max-Bindung (Anno-Bug-Report v.219:
            # Knob ließ sich auf -99999 drehen). Hier auf 1..5 clampen
            # damit irgendein Match noch klappt — unbekannte Indizes
            # fallen auf "bang" zurück (Default-Match-Verhalten).
            match_kind_idx = max(1, min(5, match_kind_idx))
            try:
                use_value = float(
                    self._scalarize(inputs.get("use_value"),
                                    module.params.get("use_value", 0.0))) > 0.5
            except (TypeError, ValueError):
                use_value = False
            try:
                match_value = float(
                    self._scalarize(inputs.get("match_value"),
                                    module.params.get("match_value", 0.0)))
            except (TypeError, ValueError):
                match_value = 0.0
            target_kind = _VOER_SELECT_KIND_MAP.get(match_kind_idx, "bang")

            match_out: list[dict] = []
            miss_out:  list[dict] = []
            if isinstance(incoming, list):
                for msg in incoming:
                    if not isinstance(msg, dict):
                        continue
                    is_match = (msg.get("kind", "") == target_kind)
                    if is_match and use_value and target_kind in ("float", "int"):
                        try:
                            v = float(msg.get("value", 0.0))
                        except (TypeError, ValueError):
                            v = 0.0
                        # Float-Vergleich mit kleiner Toleranz —
                        # numerische Robustheit gegen Rundungsfehler
                        # aus späteren Ullr-Math-Modulen.
                        is_match = (abs(v - match_value) < 1e-6)
                    ts = msg.get("ts", 0) if isinstance(msg.get("ts"), (int, float)) else 0
                    out_msg = {"kind": "bang", "ts": int(ts)}
                    if is_match:
                        match_out.append(out_msg)
                        state["match_count"] = state.get("match_count", 0) + 1
                    else:
                        miss_out.append(out_msg)
                        state["miss_count"] = state.get("miss_count", 0) + 1
            outputs["match_out"] = match_out
            outputs["miss_out"]  = miss_out

        # ─── v0.0.21.217 — Rune-Realm Phase 2.2 (Spigot + Trigger) ──
        elif module.god == "Vör" and module.kind == "Spigot":
            # Gated Pass-Through: gate > 0.5 → durchlassen, sonst []
            incoming = inputs.get("rune_in", [])
            try:
                gate = self._scalarize(inputs.get("gate"),
                                       module.params.get("gate", 1.0))
            except (TypeError, ValueError):
                gate = 1.0
            state["block_count"] = state.get("block_count", 0) + 1
            if gate > 0.5 and isinstance(incoming, list):
                outputs["rune_out"] = list(incoming)   # flache Kopie
                state["pass_count"] = state.get("pass_count", 0) + len(incoming)
            else:
                outputs["rune_out"] = []

        elif module.god == "Vör" and module.kind == "Trigger":
            # Sequence-Output: dieselben Messages an alle 3 Outputs
            # (jeweils flache Kopie, damit Konsumenten nicht
            # gegenseitig stören wenn sie die Liste mutieren).
            incoming = inputs.get("rune_in", [])
            if isinstance(incoming, list) and incoming:
                outputs["rune_out_1"] = list(incoming)
                outputs["rune_out_2"] = list(incoming)
                outputs["rune_out_3"] = list(incoming)
                state["fire_count"] = state.get("fire_count", 0) + len(incoming)
            else:
                outputs["rune_out_1"] = []
                outputs["rune_out_2"] = []
                outputs["rune_out_3"] = []

        # ─── v0.0.21.220 — Rune-Realm Phase 2.4 (Float + Int) ──────
        elif module.god == "Vör" and module.kind in ("Float", "Int"):
            # Trigger-getriggerter Wert-Producer: pro eingehender
            # Message wird ein typisierter Event mit dem aktuellen
            # value-Param/CV emittiert. Sample-Offset (ts) wird
            # übernommen.
            triggers = inputs.get("trigger", [])
            try:
                value = self._scalarize(inputs.get("value"),
                                        module.params.get("value", 0.0))
            except (TypeError, ValueError):
                value = 0.0
            event_kind = module.kind.lower()  # "float" oder "int"
            if event_kind == "int":
                try:
                    value = int(round(float(value)))
                except (TypeError, ValueError):
                    value = 0
            emitted: list[dict] = []
            if isinstance(triggers, list):
                for msg in triggers:
                    if not isinstance(msg, dict):
                        continue
                    ts = msg.get("ts", 0)
                    if not isinstance(ts, (int, float)):
                        ts = 0
                    emitted.append({
                        "kind": event_kind,
                        "value": value,
                        "ts": int(ts),
                    })
            outputs["rune_out"] = emitted
            if emitted:
                state["emit_count"] = state.get("emit_count", 0) + len(emitted)

        # ─── v0.0.21.221 — Phase 2.5 Vör.Knob (Continuous Float) ────
        elif module.god == "Vör" and module.kind == "Knob":
            # Autonom: emit Float bei Wert-Änderung (oder initial).
            current = self._scalarize(inputs.get("value"),
                                       module.params.get("value", 0.0))
            last = state.get("last_value")
            # `last is None` beim ersten Block → emit init-Wert
            if last is None or last != current:
                outputs["rune_out"] = [{
                    "kind": "float",
                    "value": float(current),
                    "ts": 0,
                }]
                state["last_value"] = current
            else:
                outputs["rune_out"] = []

        # ─── v0.0.21.221-223 — Phase 3 Norns (Time & Sequencing) ────
        elif module.god == "Norns" and module.kind == "Metro":
            # Sample-genauer Bang-Generator. Direkt Trigger-Positionen
            # innerhalb des Blocks berechnen — O(triggers_per_block)
            # statt O(block_size).
            rate_hz = self._scalarize(inputs.get("rate_hz"),
                                       module.params.get("rate_hz", 4.0))
            # Defensive Clamp: rate=0 wäre Division-by-zero, Nyquist
            # als oberes Limit (period=2 samples)
            rate_hz = max(0.001, min(self.sr * 0.5, float(rate_hz)))
            period_samples = max(2, int(self.sr / rate_hz))
            sc = state.get("sample_counter", 0)
            # Erste Trigger-Position innerhalb dieses Blocks:
            # (-sc) % period_samples = wieviele Samples bis zum nächsten
            # Trigger (modulo period). Wenn 0, fällt der Trigger auf
            # ts=0 dieses Blocks.
            first_trigger = (-sc) % period_samples
            bangs: list[dict] = []
            ts = first_trigger
            while ts < self.block_size:
                bangs.append({"kind": "bang", "ts": int(ts)})
                ts += period_samples
            state["sample_counter"] = sc + self.block_size
            outputs["rune_out"] = bangs

        elif module.god == "Norns" and module.kind == "Line":
            # Float-Ramp über Zeit. Bei Trigger: snapshot start/end/dur
            # und reset progress. Pro Block: 1 Float emittieren mit
            # interpoliertem Wert.
            triggers = inputs.get("trigger", [])
            if isinstance(triggers, list) and any(
                isinstance(m, dict) for m in triggers
            ):
                # Neuer Trigger → ramp neu starten (last-wins)
                state["active"] = True
                state["start_value"] = float(self._scalarize(
                    inputs.get("start"), module.params.get("start", 0.0)))
                state["target_value"] = float(self._scalarize(
                    inputs.get("end"), module.params.get("end", 1.0)))
                duration_ms = max(1.0, float(self._scalarize(
                    inputs.get("duration_ms"),
                    module.params.get("duration_ms", 1000.0))))
                state["duration_samples"] = max(
                    1, int(self.sr * duration_ms / 1000.0))
                state["progress_samples"] = 0

            if state.get("active"):
                progress = state.get("progress_samples", 0)
                duration = max(1, state.get("duration_samples", 1))
                if progress >= duration:
                    # Ramp fertig — final-value emittieren, deaktivieren
                    value = state.get("target_value", 0.0)
                    state["active"] = False
                else:
                    t = progress / duration
                    sv = state.get("start_value", 0.0)
                    tv = state.get("target_value", 1.0)
                    value = sv * (1.0 - t) + tv * t
                state["progress_samples"] = progress + self.block_size
                outputs["rune_out"] = [{
                    "kind": "float",
                    "value": float(value),
                    "ts": 0,
                }]
            else:
                outputs["rune_out"] = []

        elif module.god == "Norns" and module.kind == "Pipe":
            # Message-Delay-Queue. Eingehende Messages bekommen ein
            # absolutes Release-Sample, alle Messages mit Release im
            # aktuellen Block-Fenster werden emittiert.
            incoming = inputs.get("rune_in", [])
            delay_ms = max(0.0, float(self._scalarize(
                inputs.get("delay_ms"),
                module.params.get("delay_ms", 100.0))))
            delay_samples = int(self.sr * delay_ms / 1000.0)
            sc = state.get("sample_counter", 0)
            queue = state.get("queue", [])

            if isinstance(incoming, list):
                for msg in incoming:
                    if not isinstance(msg, dict):
                        continue
                    msg_ts = msg.get("ts", 0)
                    if not isinstance(msg_ts, (int, float)):
                        msg_ts = 0
                    # Absolutes Release-Sample
                    release = sc + int(msg_ts) + delay_samples
                    # Defensive Kopie damit der Source die Liste mutieren kann
                    queue.append((release, dict(msg)))

            block_end = sc + self.block_size
            emitted: list[dict] = []
            keep: list = []
            for release, msg in queue:
                if release < block_end:
                    # Release innerhalb dieses Blocks — emit
                    ts_in_block = max(0, release - sc)
                    out_msg = dict(msg)
                    out_msg["ts"] = min(self.block_size - 1, int(ts_in_block))
                    emitted.append(out_msg)
                else:
                    keep.append((release, msg))
            state["queue"] = keep
            state["sample_counter"] = sc + self.block_size
            outputs["rune_out"] = emitted

        elif module.god == "Norns" and module.kind == "Delay":
            # Single-Shot: neue Messages überschreiben pending.
            incoming = inputs.get("rune_in", [])
            delay_ms = max(0.0, float(self._scalarize(
                inputs.get("delay_ms"),
                module.params.get("delay_ms", 100.0))))
            delay_samples = int(self.sr * delay_ms / 1000.0)
            sc = state.get("sample_counter", 0)

            if isinstance(incoming, list):
                for msg in incoming:
                    if not isinstance(msg, dict):
                        continue
                    msg_ts = msg.get("ts", 0)
                    if not isinstance(msg_ts, (int, float)):
                        msg_ts = 0
                    # Last-wins: überschreibe pending
                    state["pending_release"] = sc + int(msg_ts) + delay_samples
                    state["pending_msg"] = dict(msg)

            emitted2: list[dict] = []
            block_end = sc + self.block_size
            pr = state.get("pending_release")
            if pr is not None and pr < block_end:
                ts_in_block = max(0, pr - sc)
                out_msg = dict(state.get("pending_msg") or {})
                out_msg["ts"] = min(self.block_size - 1, int(ts_in_block))
                emitted2.append(out_msg)
                state["pending_release"] = None
                state["pending_msg"] = None
            state["sample_counter"] = sc + self.block_size
            outputs["rune_out"] = emitted2

        # ─── v0.0.21.224 — Phase 2.6 Vör.RouteV + Vör.SelectV ───────
        elif module.god == "Vör" and module.kind in ("RouteV", "SelectV"):
            # PD-style multi-match by value. RouteV reicht die original
            # Message am match-Output durch; SelectV emittiert nur bang.
            incoming = inputs.get("rune_in", [])
            # 4 Match-Slots aus params lesen (oder per CV überschreiben
            # falls jemand das tatsächlich modulieren will — defensive)
            try:
                matches = [
                    float(self._scalarize(
                        inputs.get(f"match_{i}"),
                        module.params.get(f"match_{i}",
                                          float(i))))  # default 0/1/2/3
                    for i in range(4)
                ]
            except (TypeError, ValueError):
                matches = [0.0, 1.0, 2.0, 3.0]
            EPSILON = 1e-6
            # v0.0.21.230 — Living Patterns: zusätzliche Match-Slots aus
            # promoted Patterns lesen. Diese stehen in
            # ``module.frozen_tags["rune_in"]`` (gefüllt durch UI-
            # Click-to-promote in flux_canvas.py / living_patterns.py).
            # Pro Eintrag wird ein zusätzlicher Output-Port ``pat_<idx>``
            # erzeugt — der Match-Wert ist hier numerisch (Float).
            # Bei nicht-numerischen promoted Tags (Strings, "bang") wird
            # der Slot ignoriert (kann nicht numerisch matchen).
            promoted_raw = list(module.frozen_tags.get("rune_in", []))
            promoted_numeric: list[tuple[int, float]] = []
            for p_idx, raw in enumerate(promoted_raw):
                if isinstance(raw, bool):
                    continue
                if isinstance(raw, (int, float)):
                    promoted_numeric.append((p_idx, float(raw)))
            # Output-Listen vorbereiten — je nach Kind (RouteV vs SelectV)
            is_route = (module.kind == "RouteV")
            if is_route:
                out_keys = [f"out_{i}" for i in range(4)] + ["else_out"]
            else:
                out_keys = [f"match_{i}" for i in range(4)] + ["miss_out"]
            # v.230: dynamische pat_<idx>-Outputs ergänzen
            for p_idx, _val in promoted_numeric:
                out_keys.append(f"pat_{p_idx}")
            # Auch die nicht-numerischen pat_<idx>-Slots als leere Listen
            # initialisieren — sonst würde ``outputs["pat_5"]`` bei einer
            # bestehenden Connection zu einer fehlenden Liste führen,
            # was downstream NoneType-Errors auslösen könnte.
            for p_idx, raw in enumerate(promoted_raw):
                key = f"pat_{p_idx}"
                if key not in out_keys:
                    out_keys.append(key)
            out_lists: dict[str, list] = {k: [] for k in out_keys}

            if isinstance(incoming, list):
                match_count = state.get("match_count", [0, 0, 0, 0])
                miss_count = state.get("miss_count", 0)
                # v.230: pro promoted Pattern auch einen Counter halten
                # für Debug-Zwecke (state["pat_count"][idx]).
                pat_count = list(state.get("pat_count", []))
                while len(pat_count) < len(promoted_raw):
                    pat_count.append(0)
                for msg in incoming:
                    if not isinstance(msg, dict):
                        continue
                    val = msg.get("value")
                    ts = msg.get("ts", 0)
                    if not isinstance(ts, (int, float)):
                        ts = 0
                    matched_idx = -1
                    matched_pat_idx = -1
                    if isinstance(val, (int, float)):
                        fval = float(val)
                        # 1) Standard match_0..match_3 prüfen (höchste
                        #    Priorität — Backwards-Compat zu v.224)
                        for i, m in enumerate(matches):
                            if abs(fval - m) < EPSILON:
                                matched_idx = i
                                break
                        # 2) Wenn kein Standard-Match, promoted Patterns prüfen
                        if matched_idx < 0:
                            for p_idx, p_val in promoted_numeric:
                                if abs(fval - p_val) < EPSILON:
                                    matched_pat_idx = p_idx
                                    break
                    if matched_idx >= 0:
                        if is_route:
                            out_lists[f"out_{matched_idx}"].append(
                                dict(msg))
                        else:
                            out_lists[f"match_{matched_idx}"].append({
                                "kind": "bang", "ts": int(ts),
                            })
                        match_count[matched_idx] += 1
                    elif matched_pat_idx >= 0:
                        # v.230 — promoted Pattern hat gematcht
                        if is_route:
                            out_lists[f"pat_{matched_pat_idx}"].append(
                                dict(msg))
                        else:
                            out_lists[f"pat_{matched_pat_idx}"].append({
                                "kind": "bang", "ts": int(ts),
                            })
                        if matched_pat_idx < len(pat_count):
                            pat_count[matched_pat_idx] += 1
                    else:
                        if is_route:
                            out_lists["else_out"].append(dict(msg))
                        else:
                            out_lists["miss_out"].append({
                                "kind": "bang", "ts": int(ts),
                            })
                        miss_count += 1
                state["match_count"] = match_count
                state["miss_count"] = miss_count
                state["pat_count"] = pat_count

            outputs.update(out_lists)

        # ─── v0.0.21.225-227 — Phase 4 Ullr-Familie (Math/Expr) ─────
        elif module.god == "Ullr" and module.kind in (
            "Plus", "Minus", "Times", "Divide", "Min", "Max",
        ):
            # Binäre Operationen: a OP b. Pro eingehender Float/Int-
            # Message wird msg.value als a verwendet (PD-konform);
            # falls msg.value None oder Bang, fällt a auf den a-CV-
            # Input zurück. b kommt immer vom b-CV-Input.
            incoming = inputs.get("rune_in", [])
            try:
                b = float(self._scalarize(
                    inputs.get("b"), module.params.get("b", 0.0)))
            except (TypeError, ValueError):
                b = 0.0
            try:
                a_default = float(self._scalarize(
                    inputs.get("a"), module.params.get("a", 0.0)))
            except (TypeError, ValueError):
                a_default = 0.0
            kind_op = module.kind  # "Plus" / "Minus" / ...
            out_msgs: list[dict] = []
            if isinstance(incoming, list):
                for msg in incoming:
                    if not isinstance(msg, dict):
                        continue
                    val = msg.get("value")
                    ts = msg.get("ts", 0)
                    if not isinstance(ts, (int, float)):
                        ts = 0
                    if isinstance(val, (int, float)):
                        a = float(val)
                    else:
                        a = a_default  # bang oder symbol → fallback
                    # Operation
                    if kind_op == "Plus":
                        result = a + b
                    elif kind_op == "Minus":
                        result = a - b
                    elif kind_op == "Times":
                        result = a * b
                    elif kind_op == "Divide":
                        result = (a / b) if abs(b) > 1e-12 else 0.0
                    elif kind_op == "Min":
                        result = min(a, b)
                    elif kind_op == "Max":
                        result = max(a, b)
                    else:
                        result = a  # fallback
                    out_msgs.append({
                        "kind": "float",
                        "value": float(result),
                        "ts": int(ts),
                    })
            outputs["rune_out"] = out_msgs

        elif module.god == "Ullr" and module.kind == "Clip":
            # Clamp value to [lo, hi]. Pro eingehender Float/Int.
            incoming = inputs.get("rune_in", [])
            try:
                lo = float(self._scalarize(
                    inputs.get("lo"), module.params.get("lo", 0.0)))
                hi = float(self._scalarize(
                    inputs.get("hi"), module.params.get("hi", 1.0)))
            except (TypeError, ValueError):
                lo, hi = 0.0, 1.0
            if hi < lo:
                lo, hi = hi, lo  # defensive swap
            out_msgs2: list[dict] = []
            if isinstance(incoming, list):
                for msg in incoming:
                    if not isinstance(msg, dict):
                        continue
                    val = msg.get("value")
                    ts = msg.get("ts", 0)
                    if not isinstance(ts, (int, float)):
                        ts = 0
                    if isinstance(val, (int, float)):
                        clamped = max(lo, min(hi, float(val)))
                        out_msgs2.append({
                            "kind": "float",
                            "value": clamped,
                            "ts": int(ts),
                        })
            outputs["rune_out"] = out_msgs2

        elif module.god == "Ullr" and module.kind == "Abs":
            # |x|. Reines Unary.
            incoming = inputs.get("rune_in", [])
            out_msgs3: list[dict] = []
            if isinstance(incoming, list):
                for msg in incoming:
                    if not isinstance(msg, dict):
                        continue
                    val = msg.get("value")
                    ts = msg.get("ts", 0)
                    if not isinstance(ts, (int, float)):
                        ts = 0
                    if isinstance(val, (int, float)):
                        out_msgs3.append({
                            "kind": "float",
                            "value": abs(float(val)),
                            "ts": int(ts),
                        })
            outputs["rune_out"] = out_msgs3

        elif module.god == "Ullr" and module.kind == "Random":
            # Pseudozufälliger Int 0..max-1 pro Trigger.
            triggers = inputs.get("trigger", [])
            try:
                max_v = int(self._scalarize(
                    inputs.get("max_value"),
                    module.params.get("max_value", 4.0)))
            except (TypeError, ValueError):
                max_v = 4
            max_v = max(2, max_v)  # min 2 damit randrange klappt
            out_msgs4: list[dict] = []
            if isinstance(triggers, list):
                for msg in triggers:
                    if not isinstance(msg, dict):
                        continue
                    ts = msg.get("ts", 0)
                    if not isinstance(ts, (int, float)):
                        ts = 0
                    out_msgs4.append({
                        "kind": "int",
                        "value": random.randrange(max_v),
                        "ts": int(ts),
                    })
            outputs["rune_out"] = out_msgs4

        elif module.god == "Ullr" and module.kind == "Expr":
            # Expression-Evaluator. Sicheres eval mit
            # __builtins__: {} und kuratiertem namespace.
            incoming = inputs.get("rune_in", [])
            expr_str = str(module.params.get("expr", "a + b"))
            try:
                a_v = float(self._scalarize(
                    inputs.get("a"), module.params.get("a", 0.0)))
                b_v = float(self._scalarize(
                    inputs.get("b"), module.params.get("b", 0.0)))
                c_v = float(self._scalarize(
                    inputs.get("c"), module.params.get("c", 0.0)))
            except (TypeError, ValueError):
                a_v, b_v, c_v = 0.0, 0.0, 0.0
            safe_globals = {
                "__builtins__": {},
                "math": math,
                "abs": abs, "min": min, "max": max,
                "round": round, "pow": pow,
                "int": int, "float": float,
            }
            out_msgs5: list[dict] = []
            if isinstance(incoming, list):
                for msg in incoming:
                    if not isinstance(msg, dict):
                        continue
                    val = msg.get("value")
                    ts = msg.get("ts", 0)
                    if not isinstance(ts, (int, float)):
                        ts = 0
                    x_v = float(val) if isinstance(val, (int, float)) else 0.0
                    locals_dict = {
                        "a": a_v, "b": b_v, "c": c_v, "x": x_v,
                    }
                    try:
                        result = eval(expr_str, safe_globals, locals_dict)
                        if isinstance(result, (int, float)):
                            out_msgs5.append({
                                "kind": "float",
                                "value": float(result),
                                "ts": int(ts),
                            })
                    except Exception as e:
                        # Stillschweigend skippen — User-Expr hat
                        # vermutlich Syntax-Fehler. Würde im Live-Patch
                        # nur Spam erzeugen wenn wir hier loggen.
                        pass
            outputs["rune_out"] = out_msgs5

        # ─── v0.0.21.227 — Phase 5 Foundation: Ratatosk Mtof+Ftom ──
        elif module.god == "Ratatosk" and module.kind == "Mtof":
            # MIDI-Note → Frequenz: 440 * 2 ^ ((note - 69) / 12)
            incoming = inputs.get("rune_in", [])
            out_msgs6: list[dict] = []
            if isinstance(incoming, list):
                for msg in incoming:
                    if not isinstance(msg, dict):
                        continue
                    val = msg.get("value")
                    ts = msg.get("ts", 0)
                    if not isinstance(ts, (int, float)):
                        ts = 0
                    if isinstance(val, (int, float)):
                        freq = 440.0 * (2.0 ** ((float(val) - 69.0) / 12.0))
                        out_msgs6.append({
                            "kind": "float",
                            "value": freq,
                            "ts": int(ts),
                        })
            outputs["rune_out"] = out_msgs6

        elif module.god == "Ratatosk" and module.kind == "Ftom":
            # Frequenz → MIDI-Note: 69 + 12 * log2(freq / 440)
            incoming = inputs.get("rune_in", [])
            out_msgs7: list[dict] = []
            if isinstance(incoming, list):
                for msg in incoming:
                    if not isinstance(msg, dict):
                        continue
                    val = msg.get("value")
                    ts = msg.get("ts", 0)
                    if not isinstance(ts, (int, float)):
                        ts = 0
                    if isinstance(val, (int, float)) and float(val) > 0.0:
                        note = 69.0 + 12.0 * math.log2(float(val) / 440.0)
                        out_msgs7.append({
                            "kind": "float",
                            "value": note,
                            "ts": int(ts),
                        })
                    elif isinstance(val, (int, float)):
                        # freq <= 0: edge-case, emit 0 statt -inf
                        out_msgs7.append({
                            "kind": "float",
                            "value": 0.0,
                            "ts": int(ts),
                        })
            outputs["rune_out"] = out_msgs7

        # ─── v0.0.21.228 — Phase 6 Hermod (Network/OSC) ─────────────
        elif module.god == "Hermod" and module.kind == "OscReceive":
            # Non-blocking UDP recv-loop. Pro Block alle pending-
            # Pakete einlesen, parsen, als list-Messages emittieren.
            sock = state.get("socket")
            received: list[dict] = []
            if sock is not None:
                # max iterations damit ein Flood nicht das Audio-
                # Block aufhält. 64 Pakete/Block = ~12k OSC/sec
                # bei 48000/256 — das reicht für jeden realistic
                # Use-Case.
                for _ in range(64):
                    try:
                        data, addr = sock.recvfrom(4096)
                    except (BlockingIOError, OSError):
                        break  # keine pending Pakete
                    parsed = decode_osc(data)
                    if parsed is None:
                        state["error_count"] = state.get("error_count", 0) + 1
                        continue
                    path, args = parsed
                    received.append({
                        "kind": "list",
                        "value": [path] + list(args),
                        "ts": 0,
                    })
                    state["recv_count"] = state.get("recv_count", 0) + 1
            outputs["rune_out"] = received

        elif module.god == "Hermod" and module.kind == "OscSend":
            # Pro eingehender list-Message: encode als OSC + sendto.
            incoming = inputs.get("rune_in", [])
            sock = state.get("socket")
            try:
                port = int(self._scalarize(
                    inputs.get("port"), module.params.get("port", 8000)))
            except (TypeError, ValueError):
                port = 8000
            host = str(module.params.get("host", "127.0.0.1"))
            default_path = str(module.params.get("default_path", "/flux"))
            sent_bangs: list[dict] = []
            if sock is not None and isinstance(incoming, list):
                for msg in incoming:
                    if not isinstance(msg, dict):
                        continue
                    val = msg.get("value")
                    ts = msg.get("ts", 0)
                    if not isinstance(ts, (int, float)):
                        ts = 0
                    # Path + args extrahieren
                    if msg.get("kind") == "list" and isinstance(val, list) and val:
                        if isinstance(val[0], str):
                            path = val[0]
                            args = list(val[1:])
                        else:
                            path = default_path
                            args = list(val)
                    elif isinstance(val, (int, float)):
                        path = default_path
                        args = [val]
                    else:
                        continue  # skip unknown
                    try:
                        encoded = encode_osc(path, args)
                        sock.sendto(encoded, (host, port))
                        state["sent_count"] = state.get("sent_count", 0) + 1
                        sent_bangs.append({"kind": "bang", "ts": int(ts)})
                    except OSError as e:
                        state["error_count"] = state.get("error_count", 0) + 1
                        logger.debug("[Hermod.OscSend] sendto fail: %s", e)
            outputs["sent_count"] = sent_bangs

        elif module.god == "Hermod" and module.kind == "OscPath":
            # Filter list-Messages by path-pattern (glob: * = wildcard).
            incoming = inputs.get("rune_in", [])
            pattern = str(module.params.get("path_pattern", "/flux/*"))
            match_out: list[dict] = []
            miss_out: list[dict] = []
            if isinstance(incoming, list):
                import fnmatch
                match_count = state.get("match_count", 0)
                miss_count = state.get("miss_count", 0)
                for msg in incoming:
                    if not isinstance(msg, dict):
                        continue
                    val = msg.get("value")
                    ts = msg.get("ts", 0)
                    if not isinstance(ts, (int, float)):
                        ts = 0
                    matched = False
                    if msg.get("kind") == "list" and isinstance(val, list) and val:
                        if isinstance(val[0], str) and fnmatch.fnmatchcase(
                            val[0], pattern
                        ):
                            # Match: emit args ohne den Path
                            args_only = list(val[1:])
                            if len(args_only) == 1:
                                # Single arg → emit als float/int/symbol
                                arg0 = args_only[0]
                                if isinstance(arg0, bool):
                                    out_kind = "int"
                                    out_val = 1 if arg0 else 0
                                elif isinstance(arg0, int):
                                    out_kind = "int"
                                    out_val = arg0
                                elif isinstance(arg0, float):
                                    out_kind = "float"
                                    out_val = arg0
                                else:
                                    out_kind = "symbol"
                                    out_val = str(arg0)
                                match_out.append({
                                    "kind": out_kind,
                                    "value": out_val,
                                    "ts": int(ts),
                                })
                            elif args_only:
                                # Multiple args → emit als list
                                match_out.append({
                                    "kind": "list",
                                    "value": args_only,
                                    "ts": int(ts),
                                })
                            else:
                                # No args → emit als bang
                                match_out.append({
                                    "kind": "bang", "ts": int(ts),
                                })
                            matched = True
                            match_count += 1
                    if not matched:
                        miss_out.append(dict(msg))
                        miss_count += 1
                state["match_count"] = match_count
                state["miss_count"] = miss_count
            outputs["match_out"] = match_out
            outputs["miss_out"] = miss_out

        elif module.god == "Hermod" and module.kind == "OscPrint":
            # Debug-Print + passthrough.
            incoming = inputs.get("rune_in", [])
            prefix = str(module.params.get("prefix", "[OSC]"))
            if isinstance(incoming, list):
                for msg in incoming:
                    if isinstance(msg, dict):
                        logger.info("%s %s", prefix, msg)
                        state["print_count"] = state.get("print_count", 0) + 1
            outputs["rune_out"] = list(incoming) if isinstance(incoming, list) else []

        # Andere Modul-Typen: silent passthrough — zukünftige Sessions
        # ergänzen die DSP. Das ist OK — nur das Test-Play hört dann nichts,
        # aber der Patch-Editor funktioniert weiter.

        return outputs

    def _wavetable_cache(self) -> list[np.ndarray]:
        """Liefert die 8 fest gespeicherten Wavetables (lazy-init).

        Tables sind je 1024 samples lang, normalisiert auf [-1, 1]. Werden
        beim ersten Aufruf gebaut und gecached — Bragi.WavetableOsc
        interpoliert dann zwischen ihnen via ``position``.
        """
        if hasattr(self, "_wt_cache"):
            return self._wt_cache
        N = 1024
        ph = np.linspace(0.0, 1.0, N, endpoint=False, dtype=np.float32)
        tables = []
        # 0: Sine
        tables.append(np.sin(2.0 * np.pi * ph).astype(np.float32))
        # 1: Triangle
        tables.append((4.0 * np.abs(ph - 0.5) - 1.0).astype(np.float32))
        # 2: Saw (bipolar)
        tables.append((2.0 * ph - 1.0).astype(np.float32))
        # 3: Square (50% duty)
        tables.append(np.where(ph < 0.5, 1.0, -1.0).astype(np.float32))
        # 4: Soft-Saw (Saw mit gerundeten Kanten via tanh)
        tables.append(np.tanh(2.0 * (2.0 * ph - 1.0)).astype(np.float32))
        # 5: PWM-Stack (Square + Triangle)
        sq = np.where(ph < 0.5, 0.6, -0.6)
        tri = (4.0 * np.abs(ph - 0.5) - 1.0) * 0.4
        tables.append((sq + tri).astype(np.float32))
        # 6: Harmonic-Mix (Fundamental + 3rd + 5th + 7th)
        h = (np.sin(2 * np.pi * ph)
             + 0.5 * np.sin(2 * np.pi * 3 * ph)
             + 0.33 * np.sin(2 * np.pi * 5 * ph)
             + 0.25 * np.sin(2 * np.pi * 7 * ph))
        h = h / np.max(np.abs(h))
        tables.append(h.astype(np.float32))
        # 7: Noise-Pulse (Square + low-amplitude noise — bissig/rough)
        rng = np.random.default_rng(42)
        noise = rng.uniform(-0.3, 0.3, N).astype(np.float32)
        tables.append((np.where(ph < 0.5, 1.0, -1.0) * 0.7 + noise).astype(np.float32))
        self._wt_cache = tables
        return tables

    @staticmethod
    def _scalarize(value: Any, default: float) -> float:
        if isinstance(value, np.ndarray):
            if value.size == 0:
                return float(default)
            return float(np.mean(value))
        try:
            return float(value)
        except (TypeError, ValueError):
            return float(default)

    @staticmethod
    def _compute_module_rms(outputs: dict[str, np.ndarray],
                             inputs: dict[str, Any]) -> Optional[float]:
        """RMS für UI-Aktivität: bevorzugt Outputs, fällt auf Audio-Inputs zurück.

        Wenn ein Modul Audio-Outputs hat (z.B. Bragi.SineOsc) → RMS davon.
        Wenn nicht (z.B. Heimdall.MasterOut ist eine Senke) → RMS der
        größten Audio-Eingabe. Damit „atmet" auch der MasterOut-Knoten.
        """
        candidates: list[np.ndarray] = []
        # 1. Audio-Outputs
        for name, arr in (outputs or {}).items():
            if isinstance(arr, np.ndarray) and arr.size > 0 and "audio" in name:
                candidates.append(arr)
        # 2. Fallback auf Audio-Inputs (für Senken)
        if not candidates:
            for name, val in (inputs or {}).items():
                if isinstance(val, np.ndarray) and val.size > 0 and "audio" in name:
                    candidates.append(val)
        if not candidates:
            return None
        # RMS über alle Kandidaten gemittelt, dann auf 0..1 begrenzt
        rms = float(np.sqrt(np.mean(np.concatenate(candidates) ** 2)))
        return min(1.0, rms * 1.5)  # leichte Verstärkung damit auch leise Signale sichtbar pulsieren


# ─── Singleton-Zugriff ───────────────────────────────────────────

_PREVIEW_INSTANCE: Optional[FluxAudioPreview] = None


def get_preview() -> FluxAudioPreview:
    global _PREVIEW_INSTANCE
    if _PREVIEW_INSTANCE is None:
        _PREVIEW_INSTANCE = FluxAudioPreview()
    return _PREVIEW_INSTANCE


__all__ = ["FluxAudioPreview", "get_preview"]
