"""
pydaw.flux.saga.renderer_proxy — Qt-Renderer für Saga-Punktwolken
==================================================================

**v0.0.21.202 — S-0**

Bridge zwischen ``SagaShapeSampler`` und einem ``QPainter``. Die
zentrale Klasse ``SagaRendererProxy`` verwaltet:

  - **Subscriptions**: pro ``module_id`` eine Sampler-Instance
  - **Animation-Tick**: integriert sich in die zentrale Animation-
    Engine (`Aurora-Drift`-Loop) für die Rotations-Phase
  - **Paint-API**: ``paint(painter, mod_id, body_rect)`` zeichnet die
    aktuelle Punktwolke des Moduls

In S-0 ist der Renderer **rein Python**. Die Punkte stammen vom
``SagaShapeSampler`` direkt aus der Python-Process-RAM. In S-0+
kommt ein optionaler IPC-Pfad (``/tmp/pydaw_saga.sock``) hinzu, der
Punkte aus der Rust-Engine bevorzugt; der Proxy fällt automatisch
auf den Python-Sampler zurück, wenn die Rust-Engine nicht antwortet.

Anti-Overlap-Garantie (Manifest §7)
-----------------------------------

Die Methode ``paint()`` zeichnet nur INNERHALB der übergebenen
``body_rect``. Die Rect wird vom Modul-Item berechnet als
``module_body_rect`` minus Port-Hotzonen — Overlaps mit Ports
sind also mathematisch ausgeschlossen.

Cleanup-Pakt (v.198)
--------------------

* ``unsubscribe(mod_id)`` ist idempotent
* ``unsubscribe_all()`` für Patch-Reset
* Alle Animation-Engine-Subscriptions tragen den Prefix
  ``saga::{mod_id}::`` und werden bei ``unsubscribe(mod_id)``
  entfernt
"""
from __future__ import annotations

import logging
import time
from typing import Optional

from pydaw.flux.saga.shape_sampler import (
    SagaPoint,
    SagaShapeSampler,
    SamplerConfig,
)
from pydaw.services.saga_factory_shapes import DEFAULT_SHAPE_ID


logger = logging.getLogger(__name__)


# ─── Optional Qt ─────────────────────────────────────────────────


try:
    from PyQt6.QtCore import QObject, QPointF, QRectF, Qt, pyqtSignal
    from PyQt6.QtGui import QColor, QPainter, QPen, QPixmap, QPolygonF
    _QT_AVAILABLE = True
except ImportError:
    _QT_AVAILABLE = False
    QObject = object  # type: ignore[assignment,misc]
    QPointF = None  # type: ignore[assignment]
    QRectF = None  # type: ignore[assignment]
    QColor = None  # type: ignore[assignment]
    QPainter = None  # type: ignore[assignment]
    QPen = None  # type: ignore[assignment]
    QPixmap = None  # type: ignore[assignment]
    QPolygonF = None  # type: ignore[assignment]
    Qt = None  # type: ignore[assignment]

    def pyqtSignal(*args, **kwargs):  # type: ignore[no-redef]
        class _Stub:
            def emit(self, *a, **kw): ...
            def connect(self, *a, **kw): ...
        return _Stub()


# ─── Optional Animation-Engine ──────────────────────────────────


try:
    from pydaw.flux.animation_engine import (
        ANIM_AURORA_DRIFT,
        get_animation_engine,
    )
    _ANIM_AVAILABLE = True
except Exception:
    _ANIM_AVAILABLE = False

    def get_animation_engine():  # type: ignore[no-redef]
        return None
    ANIM_AURORA_DRIFT = "Aurora-Drift"  # type: ignore[assignment]


# ─── Subscription-Eintrag ────────────────────────────────────────


class _SagaSub:
    """Pro-Modul-Subscription im Proxy.

    Hält den Sampler, die zuletzt gerenderten Punkte, eine Cache-
    Stempelzeit und den letzten Body-Rect-Größenstempel (für Cache-
    Invalidierung wenn der Body resized wird).
    """

    __slots__ = (
        "mod_id", "sampler", "last_points",
        "last_body_w", "last_body_h", "last_phase",
        "last_render_ms",
        # v0.0.21.204 — Pixmap-Cache
        "cached_pixmap", "cached_phase_bucket",
        "cached_body_w", "cached_body_h",
        # v0.0.21.209 — Audio-Bucket für Cache-Invalidation
        "_audio_bucket",
    )

    def __init__(self, mod_id: str, sampler: SagaShapeSampler) -> None:
        self.mod_id = mod_id
        self.sampler = sampler
        self.last_points: list[SagaPoint] = []
        self.last_body_w: int = -1
        self.last_body_h: int = -1
        self.last_phase: float = -1.0
        self.last_render_ms: float = 0.0
        # v0.0.21.204 — Pixmap-Cache (nur in Qt-Mode genutzt)
        # Phase-Bucket-Quantisierung: 100 Buckets über die volle
        # Drehung — visuell glatt aber spart 99% Re-Renders bei
        # paint()-Floods (Mausbewegung etc.).
        self.cached_pixmap = None        # Optional[QPixmap]
        self.cached_phase_bucket: int = -1
        self.cached_body_w: int = -1
        self.cached_body_h: int = -1
        # v0.0.21.209 — Audio-Bucket-Cache-Key (5%-Quantisierung).
        # -1 erzwingt initialen Re-Render beim ersten Audio-Update.
        self._audio_bucket: int = -1


# ─── Proxy ───────────────────────────────────────────────────────


if _QT_AVAILABLE:

    class SagaRendererProxy(QObject):  # type: ignore[misc]
        """Singleton-artiger Proxy zwischen Saga-Sampler und Qt-Render.

        Lebenszyklus
        ------------
        Wird beim ersten Zugriff via ``get_saga_renderer_proxy()``
        instanziiert. Ein Prozess hat genau einen Proxy.

        Pro Modul-Item registriert sich das Saga.Magic-Modul über
        ``subscribe(mod_id, shape_id=0, …)``; bei jedem Aurora-Drift-
        Tick aktualisiert der Proxy die Rotations-Phase aller
        registrierten Sampler.

        Beim Modul-Schließen muss das Item ``unsubscribe(mod_id)``
        aufrufen — sonst hängt die Sampler-Instance bis zum Prozess-
        Ende im Speicher (nicht-kritisch aber unsauber).
        """

        # Rate-Limit für Punkt-Re-Sampling (in ms): bei Re-Render mit
        # gleicher Phase und Body-Größe brauchen wir nicht neu zu sampeln.
        _RESAMPLE_MIN_MS = 1000.0 / 30.0  # max 30 fps

        # Signals
        sampler_count_changed = pyqtSignal(int)

        def __init__(self, parent: Optional[QObject] = None) -> None:
            super().__init__(parent)
            self._subs: dict[str, _SagaSub] = {}
            self._anim_sub_id: Optional[str] = None
            self._tick_phase: float = 0.0
            self._global_throttle: bool = False
            # Anim-Engine-Subscription wird lazy beim ersten subscribe()
            # angelegt — kein Tick wenn keine Saga.Magic-Module aktiv.

            # v0.0.21.203 (A-2): Beim zentralen MotionThrottleService
            # registrieren — User-Reduced-Motion + SENTINEL-GIL-Hook
            # schalten dann automatisch den Saga-Throttle (Density 25%).
            try:
                from pydaw.services.motion_throttle_service import (
                    get_motion_throttle,
                )
                get_motion_throttle().register_listener(
                    self._on_motion_throttle_changed,
                )
            except Exception as e:
                logger.debug(
                    "[SagaProxy] motion-throttle register failed: %s", e,
                )

        # ─── Motion-Throttle-Listener (A-2) ───────────────────────

        def _on_motion_throttle_changed(self, throttled: bool) -> None:
            """Wird vom MotionThrottleService gerufen wenn User oder
            SENTINEL den globalen Reduced-Motion-Modus wechseln.
            Setzt den Saga-Density-Throttle entsprechend (25%).
            """
            try:
                self.set_global_throttle(bool(throttled))
            except Exception as e:
                logger.debug(
                    "[SagaProxy] throttle apply failed: %s", e,
                )

        # ─── Subscribe / Unsubscribe ──────────────────────────────

        def subscribe(
            self,
            mod_id: str,
            shape_id: int = DEFAULT_SHAPE_ID,
            *,
            density: float = 0.7,
            rotation_speed: float = 0.0,
            audio_react: float = 0.6,
            palette: int = 0,
        ) -> None:
            """Saga.Magic-Modul registrieren. Bei existierender ID
            wird die Sampler-Konfiguration aktualisiert (kein Re-Init).
            """
            sub = self._subs.get(mod_id)
            if sub is None:
                cfg = SamplerConfig(
                    shape_id=shape_id,
                    density=density,
                    rotation_speed=rotation_speed,
                    audio_react=audio_react,
                    palette=palette,
                )
                sub = _SagaSub(mod_id, SagaShapeSampler(cfg))
                self._subs[mod_id] = sub
                logger.debug(
                    "[SagaProxy] subscribe mod_id=%s shape=%d (total=%d)",
                    mod_id, shape_id, len(self._subs),
                )
                self.sampler_count_changed.emit(len(self._subs))
                self._ensure_anim_subscribed()
            else:
                sub.sampler.set_shape_id(shape_id)
                sub.sampler.set_density(density)
                sub.sampler.set_rotation_speed(rotation_speed)
                sub.sampler.set_audio_react(audio_react)
                sub.sampler.config.palette = int(palette)

        def update_params(
            self,
            mod_id: str,
            *,
            shape_id: Optional[int] = None,
            density: Optional[float] = None,
            rotation_speed: Optional[float] = None,
            audio_react: Optional[float] = None,
            palette: Optional[int] = None,
        ) -> bool:
            """Nur die Felder updaten, die nicht None sind."""
            sub = self._subs.get(mod_id)
            if sub is None:
                return False
            # v0.0.21.204: bei jedem Param-Wechsel den Pixmap-Cache
            # invalidieren — Shape/Density/Palette-Änderungen ändern
            # die gerenderten Punkte, der Phase-Bucket allein reicht
            # nicht mehr als Cache-Key.
            cache_dirty = False
            if shape_id is not None:
                sub.sampler.set_shape_id(int(shape_id))
                cache_dirty = True
            if density is not None:
                sub.sampler.set_density(float(density))
                cache_dirty = True
            if rotation_speed is not None:
                sub.sampler.set_rotation_speed(float(rotation_speed))
                # rotation_speed beeinflusst Animation, nicht Statik
                # → Cache-Invalidate nicht zwingend (Phase-Bucket fängt's)
            if audio_react is not None:
                sub.sampler.set_audio_react(float(audio_react))
            if palette is not None:
                sub.sampler.config.palette = int(palette)
                cache_dirty = True
            if cache_dirty:
                sub.cached_phase_bucket = -1   # erzwingt Re-Render
            return True

        def unsubscribe(self, mod_id: str) -> bool:
            """Idempotent. Returns True wenn was entfernt wurde."""
            existed = self._subs.pop(mod_id, None) is not None
            if existed:
                logger.debug(
                    "[SagaProxy] unsubscribe mod_id=%s (remaining=%d)",
                    mod_id, len(self._subs),
                )
                self.sampler_count_changed.emit(len(self._subs))
                if not self._subs:
                    self._cancel_anim_subscription()
            return existed

        def unsubscribe_all(self) -> int:
            """Patch-Reset: alle Subscriptions weg. Returns count."""
            n = len(self._subs)
            self._subs.clear()
            if n > 0:
                self.sampler_count_changed.emit(0)
                self._cancel_anim_subscription()
                logger.debug("[SagaProxy] unsubscribe_all (cleared %d)", n)
            return n

        # ─── Throttle ─────────────────────────────────────────────

        def set_global_throttle(self, throttled: bool) -> None:
            """SENTINEL-Hook: bei `True` reduzieren ALLE Sampler die
            Density auf 25% (Manifest §6 Adaptive-Density)."""
            new_val = bool(throttled)
            if new_val == self._global_throttle:
                return    # idempotent — kein Cache-Bash bei Spam
            self._global_throttle = new_val
            for sub in self._subs.values():
                sub.sampler.set_throttled(self._global_throttle)
                # v0.0.21.204: Density-Wechsel erzwingt Re-Render
                sub.cached_phase_bucket = -1

        # ─── Audio-Features ───────────────────────────────────────

        def update_audio_features(
            self,
            mod_id: str,
            *,
            rms: float = 0.0,
            centroid: float = 0.0,
            flatness: float = 0.0,
            onset: float = 0.0,
        ) -> None:
            """Audio-Features-Feed.

            v0.0.21.202 (S-0): Stub — nie aufgerufen, da kein Audio-Tap.
            v0.0.21.209: Live-Pfad — wird vom ``flux_main_widget`` aus
            der ``rust_engine_bridge.track_meters_changed``-Pipeline
            gerufen. RMS und Onset machen den Heart-Beat sichtbar.

            Die Features werden in ``SamplerConfig`` gespeichert; das
            nächste ``sample_points()`` liest sie und expandiert die
            Form (radial_scale + 3D-Tilt + Brightness — siehe v.209).

            **Cache-Invalidate-Strategie:** Audio-Werte ändern sich bei
            30 fps Tick-Rate ständig leicht. Wir können den Pixmap-Cache
            nicht bei jedem Mini-Δ verwerfen (sonst geht der Smart-
            Repaint-Tick verloren und wir kriegen v.203-GIL-Probleme).
            Daher quantisieren wir die Audio-Features in „audio buckets"
            (5%-Schritte) und invalidieren nur bei Bucket-Wechsel.
            """
            sub = self._subs.get(mod_id)
            if sub is None:
                return
            # Quantisieren auf 20 Buckets (5% Auflösung) — das bedeutet
            # beim Lautstärke-Sprung kommt sofort ein Re-Render, aber
            # bei Mini-Schwankungen (±2%) bleibt der Cache stabil.
            new_audio_bucket = (
                int(rms * 20) * 1000000
                + int(centroid * 20) * 10000
                + int(flatness * 20) * 100
                + int(onset * 20)
            )
            old_audio_bucket = getattr(sub, "_audio_bucket", -1)
            sub.sampler.update_audio_features(
                rms=rms, centroid=centroid, flatness=flatness, onset=onset,
            )
            if new_audio_bucket != old_audio_bucket:
                # Audio hat sich messbar geändert → Pixmap muss neu.
                # `cached_phase_bucket = -1` ist der Standard-Invalidate-
                # Trigger im paint()-Pfad (siehe v.204-Cache-Logik).
                sub.cached_phase_bucket = -1
                try:
                    sub._audio_bucket = new_audio_bucket
                except Exception:
                    pass

        # ─── Animation-Engine-Tick ────────────────────────────────

        def _ensure_anim_subscribed(self) -> None:
            """Eine globale Aurora-Drift-Subscription für ALLE Sampler.

            Wir nutzen Aurora-Drift (4000 ms Loop, sine_loop-easing) als
            unseren Phase-Driver. Bei reduziertem Modus ist die Anim-
            Engine selbst stiller, was wir hier weiterreichen.
            """
            if not _ANIM_AVAILABLE or self._anim_sub_id is not None:
                return
            try:
                eng = get_animation_engine()
                if eng is None:
                    return
                self._anim_sub_id = "saga::renderer_proxy::tick"
                eng.subscribe(
                    sub_id=self._anim_sub_id,
                    anim_name=ANIM_AURORA_DRIFT,
                    on_frame=self._on_anim_tick,
                )
            except Exception as e:
                logger.debug("[SagaProxy] anim subscribe failed: %s", e)
                self._anim_sub_id = None

        def _cancel_anim_subscription(self) -> None:
            if not _ANIM_AVAILABLE or self._anim_sub_id is None:
                return
            try:
                eng = get_animation_engine()
                if eng is not None:
                    eng.unsubscribe(self._anim_sub_id)
            except Exception:
                pass
            self._anim_sub_id = None

        def _on_anim_tick(self, phase: float, frame: int) -> None:
            """Wird ~30 fps gerufen während mind. ein Saga-Modul aktiv."""
            self._tick_phase = float(phase)
            # Alle Sampler kriegen die globale Phase als Basis-Phase;
            # ihre individuelle ``rotation_speed`` moduliert davon weg.
            for sub in self._subs.values():
                # Pro-Modul-Phase = global × individueller speed-Faktor
                speed = sub.sampler.config.rotation_speed
                # Direkter Phase-Setter — entkoppelt von dt-Logik
                sub.sampler.set_phase(self._tick_phase * speed)

        # ─── Paint-API ────────────────────────────────────────────

        # v0.0.21.204 — Phase-Bucket-Auflösung. 100 Buckets über die
        # volle Rotation (0..1) ist visuell genug für glatte Animation
        # bei realistischen rotation_speed-Werten (max 2.0/s → 200 Buckets/s
        # = 5 ms/Bucket). Maus-getriebene paint()-Floods landen aber im
        # gleichen Bucket → Pixmap wird geblittet, nicht neu gerendert.
        _PHASE_BUCKET_RESOLUTION = 100
        # Bei aktivem Throttle (User-Reduced-Motion ODER SENTINEL-GIL-Spike)
        # gehen wir auf 25 Buckets — Animation noch wahrnehmbar aber
        # 4× weniger Re-Render-Cost.
        _PHASE_BUCKET_RESOLUTION_THROTTLED = 25

        def _phase_bucket_resolution(self) -> int:
            return (self._PHASE_BUCKET_RESOLUTION_THROTTLED
                    if self._global_throttle
                    else self._PHASE_BUCKET_RESOLUTION)

        def phase_bucket_for_phase(self, phase: float) -> int:
            """Quantisiert Phase 0..1 in einen Bucket-Index."""
            res = self._phase_bucket_resolution()
            return int((phase % 1.0) * res) % res

        def phase_bucket(self, mod_id: str) -> int:
            """Aktueller Phase-Bucket eines Moduls. -1 wenn unbekannt.

            Wird vom `FluxScene._tick_pulses()` genutzt, um zu entscheiden
            ob `item.update()` überhaupt nötig ist (nur bei Bucket-Wechsel).
            """
            sub = self._subs.get(mod_id)
            if sub is None:
                return -1
            return self.phase_bucket_for_phase(sub.sampler._phase)

        def paint(
            self,
            painter: QPainter,
            mod_id: str,
            body_rect: QRectF,
        ) -> None:
            """Zeichnet die Punktwolke des Moduls in `body_rect`.

            v0.0.21.204 — Pixmap-Cache:
            - Body-Größe + Phase-Bucket sind Cache-Key.
            - Cache-Hit → ein einziges drawPixmap (UI-Thread bleibt frei)
            - Cache-Miss → Pixmap neu rendern (drawPoints-Batches statt
              N drawPoint-Calls; AA aus für Stippling).

            Rationale: vor v.204 verbrannte jedes paint() ~300
            drawPoint-Calls (Stippling). Bei 60-fps-Mouse-Move-Floods
            war das die Quelle für GIL-Starvation und
            ProAudio/SF2/Drums-Knacksen.
            """
            sub = self._subs.get(mod_id)
            if sub is None:
                return
            body_w = max(1, int(body_rect.width()))
            body_h = max(1, int(body_rect.height()))
            cur_bucket = self.phase_bucket_for_phase(sub.sampler._phase)

            # Cache-Hit?
            cache_valid = (
                sub.cached_pixmap is not None
                and sub.cached_body_w == body_w
                and sub.cached_body_h == body_h
                and sub.cached_phase_bucket == cur_bucket
            )

            if not cache_valid:
                # Re-Render in Pixmap. sample_points() einmal pro
                # Bucket-Wechsel, keine Rate-Limit nötig (Bucket-
                # Quantisierung übernimmt das).
                points = sub.sampler.sample_points(
                    body_w=body_w, body_h=body_h,
                )
                pix = self._render_to_pixmap(body_w, body_h, points)
                sub.cached_pixmap = pix
                sub.cached_body_w = body_w
                sub.cached_body_h = body_h
                sub.cached_phase_bucket = cur_bucket
                # Legacy-Felder (v.203 Diagnose) auch füllen
                sub.last_points = points
                sub.last_body_w = body_w
                sub.last_body_h = body_h
                sub.last_phase = sub.sampler._phase
                sub.last_render_ms = time.monotonic() * 1000.0

            # Blit — der eigentliche paint()-Hot-Path.
            if sub.cached_pixmap is not None:
                painter.drawPixmap(int(body_rect.x()), int(body_rect.y()),
                                   sub.cached_pixmap)

        @staticmethod
        def _render_to_pixmap(
            body_w: int,
            body_h: int,
            points: list[SagaPoint],
        ):
            """Rendert die Punktwolke in eine transparente QPixmap.

            v0.0.21.204 — drawPoints (Plural!) statt N×drawPoint:
            * Hue-Bucket-Gruppierung (5°-Bins) → 1-2 Pen-Wechsel typisch
            * Innerhalb eines Hue-Buckets: alpha-32-Bins
            * Pro (hue,alpha)-Bucket: ein QPolygonF + ein drawPoints-Call
              (Qt malt alle Punkte mit dem gesetzten Pen in 1 Op)
            * Antialiasing AUS — bei 2-px-Stippling visuell irrelevant,
              aber spart ~40% Render-Zeit
            """
            pix = QPixmap(body_w, body_h)
            pix.fill(QColor(0, 0, 0, 0))   # transparent
            if not points:
                return pix
            painter = QPainter(pix)
            try:
                # Antialiasing AUS — 2-px-Punkte profitieren nicht davon.
                painter.setRenderHint(QPainter.RenderHint.Antialiasing, False)
                pen = QPen()
                pen.setCapStyle(Qt.PenCapStyle.RoundCap)
                pen.setWidthF(2.0)

                # Bucketing: (hue_bin, alpha_bin) → Liste von QPointF
                buckets: dict[tuple[int, int], list[QPointF]] = {}
                fx_w = float(body_w)
                fx_h = float(body_h)
                for p in points:
                    hue_b = (p.hue // 5) * 5
                    alpha_b = (p.alpha // 32) * 32 + 16
                    key = (hue_b, alpha_b)
                    buckets.setdefault(key, []).append(
                        QPointF(p.x * fx_w, p.y * fx_h),
                    )

                for (hue_b, alpha_b), pts_list in buckets.items():
                    color = QColor.fromHsv(int(hue_b), 200, 240, int(alpha_b))
                    pen.setColor(color)
                    painter.setPen(pen)
                    poly = QPolygonF(pts_list)
                    painter.drawPoints(poly)
            finally:
                painter.end()
            return pix

        @staticmethod
        def _draw_points(
            painter: QPainter,
            body_rect: QRectF,
            points: list[SagaPoint],
        ) -> None:
            """v.203 Legacy-Pfad. Wird in v.204 nur noch von Tests
            benutzt — der Produktiv-Pfad geht über `_render_to_pixmap`
            + `drawPixmap` (Pixmap-Cache).
            """
            if not points:
                return
            painter.save()
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, False)
            x0 = body_rect.x()
            y0 = body_rect.y()
            w = body_rect.width()
            h = body_rect.height()
            buckets: dict[tuple[int, int], list[QPointF]] = {}
            for p in points:
                hue_b = (p.hue // 5) * 5
                alpha_b = (p.alpha // 32) * 32 + 16
                buckets.setdefault((hue_b, alpha_b), []).append(
                    QPointF(x0 + p.x * w, y0 + p.y * h),
                )
            pen = QPen()
            pen.setCapStyle(Qt.PenCapStyle.RoundCap)
            pen.setWidthF(2.0)
            for (hue_b, alpha_b), pts_list in buckets.items():
                color = QColor.fromHsv(int(hue_b), 200, 240, int(alpha_b))
                pen.setColor(color)
                painter.setPen(pen)
                painter.drawPoints(QPolygonF(pts_list))
            painter.restore()

        # ─── Diagnose ─────────────────────────────────────────────

        def diagnose(self) -> dict:
            return {
                "subscribers": len(self._subs),
                "anim_subscribed": self._anim_sub_id is not None,
                "global_throttle": self._global_throttle,
                "tick_phase": round(self._tick_phase, 4),
                "qt_available": _QT_AVAILABLE,
                "anim_available": _ANIM_AVAILABLE,
            }


else:
    # Qt nicht verfügbar — No-Op-Variante
    class SagaRendererProxy:  # type: ignore[no-redef]
        def __init__(self, parent=None) -> None: ...
        def subscribe(self, *a, **kw) -> None: ...
        def update_params(self, *a, **kw) -> bool:
            return False
        def unsubscribe(self, *a, **kw) -> bool:
            return False
        def unsubscribe_all(self) -> int:
            return 0
        def set_global_throttle(self, *a, **kw) -> None: ...
        def update_audio_features(self, *a, **kw) -> None: ...
        def paint(self, *a, **kw) -> None: ...
        def diagnose(self) -> dict:
            return {"qt_available": False}


# ─── Singleton ───────────────────────────────────────────────────


_PROXY_INSTANCE: Optional["SagaRendererProxy"] = None


def get_saga_renderer_proxy() -> "SagaRendererProxy":
    """Liefert die Prozess-globale Saga-Renderer-Proxy-Instance.

    Lazy-Init beim ersten Zugriff. Threadsafe nicht garantiert —
    der Proxy lebt typischerweise im Main-Thread (UI).
    """
    global _PROXY_INSTANCE
    if _PROXY_INSTANCE is None:
        _PROXY_INSTANCE = SagaRendererProxy()
    return _PROXY_INSTANCE


__all__ = [
    "SagaRendererProxy",
    "get_saga_renderer_proxy",
]
