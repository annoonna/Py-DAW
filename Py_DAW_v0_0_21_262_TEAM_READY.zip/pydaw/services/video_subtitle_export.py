"""video_subtitle_export.py — SRT/VTT Subtitle Export for VE11 (v0.0.20.950).

Exports transcriptions as standard subtitle files:
  - SRT (SubRip) — universal format
  - VTT (WebVTT) — web standard with styling support
  - Plain text transcript

Supports:
  - Word-level or segment-level output
  - Deleted words are excluded from export
  - Custom max line length and max lines per subtitle
  - Speaker labels (if available)

Usage:
    from pydaw.services.video_subtitle_export import export_srt, export_vtt
    export_srt(transcript, "/path/output.srt")
    export_vtt(transcript, "/path/output.vtt")
"""

from __future__ import annotations

import logging
import os
from typing import List, Optional, Tuple

log = logging.getLogger(__name__)


def _format_srt_time(seconds: float) -> str:
    """Format seconds as SRT time: HH:MM:SS,mmm"""
    if seconds < 0:
        seconds = 0
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    ms = int((seconds % 1) * 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def _format_vtt_time(seconds: float) -> str:
    """Format seconds as VTT time: HH:MM:SS.mmm"""
    if seconds < 0:
        seconds = 0
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    ms = int((seconds % 1) * 1000)
    return f"{h:02d}:{m:02d}:{s:02d}.{ms:03d}"


def _build_subtitle_blocks(transcript,
                            max_chars: int = 42,
                            max_lines: int = 2,
                            word_level: bool = False
                            ) -> List[Tuple[float, float, str]]:
    """Build subtitle blocks from transcript.
    
    Returns list of (start, end, text) tuples.
    """
    if word_level:
        # Each word is a separate subtitle
        blocks = []
        for w in transcript.active_words:
            blocks.append((w.start, w.end, w.word))
        return blocks

    # Segment-level with line wrapping
    blocks = []
    for seg in transcript.segments:
        active = seg.active_words
        if not active:
            continue

        # Split into lines based on max_chars
        lines = []
        current_line = []
        current_len = 0
        line_start = active[0].start
        line_end = active[0].end

        for w in active:
            word_len = len(w.word) + (1 if current_line else 0)
            if current_len + word_len > max_chars and current_line:
                # Finish current line
                lines.append((line_start, line_end,
                               " ".join(cw.word for cw in current_line)))
                current_line = [w]
                current_len = len(w.word)
                line_start = w.start
                line_end = w.end
            else:
                current_line.append(w)
                current_len += word_len
                line_end = w.end

        if current_line:
            lines.append((line_start, line_end,
                           " ".join(cw.word for cw in current_line)))

        # Group lines into subtitle blocks (max_lines per block)
        for i in range(0, len(lines), max_lines):
            group = lines[i:i + max_lines]
            block_start = group[0][0]
            block_end = group[-1][1]
            block_text = "\n".join(g[2] for g in group)
            blocks.append((block_start, block_end, block_text))

    return blocks


def export_srt(transcript, output_path: str,
               max_chars: int = 42,
               max_lines: int = 2,
               word_level: bool = False) -> bool:
    """Export transcript as SRT subtitle file.
    
    Args:
        transcript: Transcript object
        output_path: Where to save the .srt file
        max_chars: Max characters per line
        max_lines: Max lines per subtitle block
        word_level: If True, each word gets its own subtitle
        
    Returns:
        True if export was successful
    """
    try:
        blocks = _build_subtitle_blocks(transcript, max_chars,
                                         max_lines, word_level)
        lines = []
        for idx, (start, end, text) in enumerate(blocks, 1):
            lines.append(str(idx))
            lines.append(f"{_format_srt_time(start)} --> {_format_srt_time(end)}")
            lines.append(text)
            lines.append("")  # empty line separator

        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

        log.info("SRT exported: %s (%d blocks)", output_path, len(blocks))
        return True
    except Exception as exc:
        log.error("SRT export failed: %s", exc)
        return False


def export_vtt(transcript, output_path: str,
               max_chars: int = 42,
               max_lines: int = 2,
               word_level: bool = False,
               title: str = "") -> bool:
    """Export transcript as WebVTT subtitle file.
    
    Args:
        transcript: Transcript object
        output_path: Where to save the .vtt file
        max_chars: Max characters per line
        max_lines: Max lines per subtitle block
        word_level: If True, each word gets its own subtitle
        title: Optional title for the VTT header
        
    Returns:
        True if export was successful
    """
    try:
        blocks = _build_subtitle_blocks(transcript, max_chars,
                                         max_lines, word_level)
        lines = ["WEBVTT"]
        if title:
            lines[0] = f"WEBVTT - {title}"
        lines.append("")  # empty line after header

        for idx, (start, end, text) in enumerate(blocks, 1):
            lines.append(str(idx))
            lines.append(f"{_format_vtt_time(start)} --> {_format_vtt_time(end)}")
            lines.append(text)
            lines.append("")

        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

        log.info("VTT exported: %s (%d blocks)", output_path, len(blocks))
        return True
    except Exception as exc:
        log.error("VTT export failed: %s", exc)
        return False


def export_plain_text(transcript, output_path: str,
                       include_timestamps: bool = False) -> bool:
    """Export transcript as plain text.
    
    Args:
        transcript: Transcript object
        output_path: Where to save the .txt file
        include_timestamps: If True, add timestamps before each segment
        
    Returns:
        True if export was successful
    """
    try:
        lines = []
        for seg in transcript.segments:
            text = seg.active_text
            if not text:
                continue
            if include_timestamps:
                ts = _format_srt_time(seg.start).replace(",", ".")
                lines.append(f"[{ts}] {text}")
            else:
                lines.append(text)

        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")

        log.info("Text exported: %s (%d lines)", output_path, len(lines))
        return True
    except Exception as exc:
        log.error("Text export failed: %s", exc)
        return False


def generate_ffmpeg_cut_filter(transcript,
                                output_path: str = "") -> str:
    """Generate ffmpeg filter_complex for text-based editing.
    
    Creates a filter that keeps only non-deleted segments,
    concatenating them together.
    
    Returns: ffmpeg command string
    """
    keep_regions = transcript.get_keep_regions()
    if not keep_regions:
        return ""

    # Build select/aselect filter
    parts = []
    for i, (start, end) in enumerate(keep_regions):
        parts.append(f"between(t\\,{start:.3f}\\,{end:.3f})")

    select_expr = "+".join(parts)

    cmd_parts = [
        f"-vf \"select='{select_expr}',setpts=N/FRAME_RATE/TB\"",
        f"-af \"aselect='{select_expr}',asetpts=N/SR/TB\"",
    ]
    if output_path:
        cmd_parts.append(f"\"{output_path}\"")

    return " ".join(cmd_parts)
