"""Audio-State-Reset Dialog — In-App Pendant zu den CLI-Tools.

v0.0.21.237 — Anno-Auftrag: „kannst du mir eine möglichkeit geben im
programm selber alles zu löschen falls damit probleme auf tretten".

Drei Modi:
  1. **Diagnose**: Read-only. Zeigt was hot ist, ohne Änderungen.
  2. **Soft-Reset**: Setzt nur Werte > 1.5 zurück, mit Backup. Projekte
     und Presets bleiben unverändert.
  3. **Wipe-All**: Backupt UND löscht das ganze Config-Verzeichnis +
     QSettings. Equivalent zu Anno's manuellem ``rm -rf`` aber mit
     Backup-Sicherheitsnetz. Erfordert App-Restart.

Service-Logik in ``pydaw.services.audio_state_diagnostics`` — gleicher
Code-Pfad wie die CLI-Tools.
"""
from __future__ import annotations

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTextEdit, QMessageBox, QGroupBox, QSizePolicy, QWidget,
)

from pydaw.services import audio_state_diagnostics as asd


class AudioStateResetDialog(QDialog):
    """In-App Audio-State-Reset.

    Public API: just construct and ``exec()`` — no setup needed.
    """

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Audio-Settings — Diagnose & Reset")
        self.setMinimumSize(720, 540)
        self._build_ui()
        # Run an initial diagnose so the user sees state immediately.
        self._action_diagnose()

    # ── UI ────────────────────────────────────────────────────────────

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)

        # Header explanation
        explanation = QLabel(
            "<b>Was ist das?</b><br>"
            "Py_DAW speichert Master-Volume, Track-Volumes und FX-Settings "
            "persistent in <code>~/.config/ChronoScaleStudio/</code> (SQLite-DBs) "
            "und in QSettings. Wenn dort über die Zeit Werte > 1.0 angesammelt "
            "haben (durch MIDI-CCs, OSC, Doppelklick auf Fader), klingen alle "
            "Sources verzerrt — egal welcher Code-Stand das Audio rendert."
        )
        explanation.setWordWrap(True)
        explanation.setStyleSheet("padding: 6px;")
        layout.addWidget(explanation)

        # Three action buttons row
        actions_row = QHBoxLayout()

        self._btn_diagnose = QPushButton("🔍  Diagnose (nur lesen)")
        self._btn_diagnose.setToolTip("Liest alle Settings, ändert nichts. "
                                      "Zeigt 'hot' Werte > 1.5.")
        self._btn_diagnose.clicked.connect(self._action_diagnose)
        actions_row.addWidget(self._btn_diagnose)

        self._btn_soft = QPushButton("🛠  Soft-Reset (nur hot Werte)")
        self._btn_soft.setToolTip("Setzt Werte > 1.5 auf 0.8 zurück. "
                                  "Projekte/Presets bleiben unverändert. "
                                  "Backup wird automatisch erstellt.")
        self._btn_soft.clicked.connect(self._action_soft_reset)
        actions_row.addWidget(self._btn_soft)

        self._btn_wipe = QPushButton("💥  Wipe-All (alles löschen)")
        self._btn_wipe.setToolTip("Backupt und löscht das gesamte Config-"
                                  "Verzeichnis + QSettings. App-Restart nötig.")
        self._btn_wipe.setStyleSheet("color: #c00;")
        self._btn_wipe.clicked.connect(self._action_wipe)
        actions_row.addWidget(self._btn_wipe)

        layout.addLayout(actions_row)

        # Output area
        out_group = QGroupBox("Ergebnis")
        out_layout = QVBoxLayout(out_group)
        self._output = QTextEdit()
        self._output.setReadOnly(True)
        mono = QFont("Monospace")
        mono.setStyleHint(QFont.StyleHint.TypeWriter)
        self._output.setFont(mono)
        self._output.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        out_layout.addWidget(self._output)
        layout.addWidget(out_group, 1)

        # Bottom: close
        bottom_row = QHBoxLayout()
        bottom_row.addStretch(1)
        self._btn_close = QPushButton("Schließen")
        self._btn_close.clicked.connect(self.accept)
        bottom_row.addWidget(self._btn_close)
        layout.addLayout(bottom_row)

    # ── Actions ───────────────────────────────────────────────────────

    def _set_text(self, text: str) -> None:
        self._output.setPlainText(text)

    def _append(self, text: str) -> None:
        self._output.append(text)

    def _action_diagnose(self) -> None:
        try:
            res = asd.diagnose()
        except Exception as e:
            self._set_text(f"❌ Diagnose fehlgeschlagen: {e}")
            return

        lines = []
        lines.append("=" * 60)
        lines.append("  AUDIO-STATE DIAGNOSE")
        lines.append("=" * 60)
        lines.append("")

        if res.db_paths_found:
            lines.append(f"📁 SQLite-DBs gefunden: {len(res.db_paths_found)}")
            for p in res.db_paths_found:
                size_kb = p.stat().st_size / 1024
                lines.append(f"   • {p.name} ({size_kb:.1f} KB)")
        else:
            lines.append("📁 Keine SQLite-DBs vorhanden (Erst-Installation)")
        lines.append("")

        lines.append(f"⚙️  QSettings: {'vorhanden' if res.qsettings_present else 'nicht vorhanden'}")
        if res.qsettings_audio_keys:
            lines.append(f"   Audio-relevante Keys: {len(res.qsettings_audio_keys)}")
            for k, v in res.qsettings_audio_keys[:8]:
                lines.append(f"      {k} = {v}")
            if len(res.qsettings_audio_keys) > 8:
                lines.append(f"      ... und {len(res.qsettings_audio_keys) - 8} weitere")
        lines.append("")

        if res.cache_size_mb > 0:
            lines.append(f"💾 Cache: {res.cache_size_mb:.1f} MB")
        if res.n_crash_logs > 0:
            lines.append(f"💥 Crash-Logs: {res.n_crash_logs}")
        if res.cache_size_mb > 0 or res.n_crash_logs > 0:
            lines.append("")

        lines.append("=" * 60)
        if res.is_clean:
            lines.append("  ✅ ALLE SETTINGS SAUBER")
            lines.append("=" * 60)
            lines.append("")
            lines.append("Keine Werte > 1.5 gefunden.")
            lines.append("")
            lines.append("Wenn der Sound trotzdem schlecht ist, liegt es")
            lines.append("nicht an persistenten Settings. Prüfe die")
            lines.append("[GAIN-DIAG]-Logs in der Console während der")
            lines.append("Wiedergabe.")
        else:
            lines.append(f"  ⚠️  {res.n_hot} 'HOT' WERTE GEFUNDEN")
            lines.append("=" * 60)
            lines.append("")
            for f in res.findings:
                lines.append(f"  ⚠️  {f}")
            lines.append("")
            lines.append("Diese Werte triggern den Saturator und können")
            lines.append("'müll'/'blechernd' verursachen.")
            lines.append("")
            lines.append("→ Nutze 'Soft-Reset' um die Werte zurückzusetzen.")
            lines.append("  Projekte und Presets bleiben unverändert.")

        if res.errors:
            lines.append("")
            lines.append("Fehler beim Lesen:")
            for e in res.errors:
                lines.append(f"  ⚠ {e}")

        self._set_text("\n".join(lines))

    def _action_soft_reset(self) -> None:
        # First a dry run to show what would change.
        try:
            preview = asd.reset_hot_values(dry_run=True)
        except Exception as e:
            self._set_text(f"❌ Reset-Vorschau fehlgeschlagen: {e}")
            return

        if preview.n_changes == 0:
            QMessageBox.information(
                self, "Soft-Reset",
                "Keine Werte > 1.5 gefunden — nichts zu tun."
            )
            self._action_diagnose()
            return

        # Confirm
        msg = (
            f"<b>{preview.n_changes} Wert(e)</b> würden auf "
            f"{asd.SAFE_DEFAULT_VOL} (-1.9 dB) zurückgesetzt.<br><br>"
            f"<b>Was passiert:</b><br>"
            f"• DBs werden vorher als <code>.bak.&lt;timestamp&gt;</code> gesichert<br>"
            f"• Nur Werte &gt; {asd.HOT_THRESHOLD} werden geändert<br>"
            f"• Projekte, Clips, MIDI, Audio-Files, Presets bleiben unverändert<br><br>"
            f"Fortfahren?"
        )
        confirm = QMessageBox.question(
            self, "Soft-Reset bestätigen", msg,
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )
        if confirm != QMessageBox.StandardButton.Yes:
            self._append("\n→ Soft-Reset abgebrochen.")
            return

        # Run for real
        try:
            res = asd.reset_hot_values(dry_run=False)
        except Exception as e:
            QMessageBox.critical(self, "Soft-Reset fehlgeschlagen", str(e))
            return

        lines = []
        lines.append("=" * 60)
        lines.append(f"  SOFT-RESET ABGESCHLOSSEN — {res.n_changes} Wert(e)")
        lines.append("=" * 60)
        lines.append("")
        lines.append("Backups:")
        for b in res.backups_made:
            lines.append(f"   • {b}")
        lines.append("")
        lines.append("Geänderte Werte:")
        for c in res.changes:
            lines.append(f"   • {c}")
        if res.errors:
            lines.append("")
            lines.append("Fehler:")
            for e in res.errors:
                lines.append(f"   ⚠ {e}")
        lines.append("")
        lines.append("→ Re-Diagnose mit dem Diagnose-Button um zu prüfen.")
        self._set_text("\n".join(lines))

    def _action_wipe(self) -> None:
        msg = (
            "<b>⚠️  WIPE-ALL — radikale Variante</b><br><br>"
            "Das gesamte Config-Verzeichnis "
            "<code>~/.config/ChronoScaleStudio/</code> und die QSettings-"
            "Datei werden gelöscht.<br><br>"
            "<b>Backup wird vorher angelegt</b> (Verzeichnis-Kopie + .bak-Files).<br><br>"
            "<b>Was bleibt erhalten:</b><br>"
            "• Deine Projekt-Dateien (außerhalb von ~/.config)<br>"
            "• Audio-Files und Samples<br>"
            "• Backup-Kopien zum Wiederherstellen<br><br>"
            "<b>Was wird zurückgesetzt:</b><br>"
            "• Alle Track/FX/Mixer-Settings<br>"
            "• Preset-DB (kann neu indiziert werden)<br>"
            "• UI-Layout, Fenster-Positionen, etc.<br><br>"
            "<b>App-Restart wird nach diesem Vorgang dringend empfohlen.</b><br><br>"
            "Fortfahren?"
        )
        confirm = QMessageBox.warning(
            self, "Wipe-All bestätigen", msg,
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )
        if confirm != QMessageBox.StandardButton.Yes:
            self._append("\n→ Wipe-All abgebrochen.")
            return

        try:
            res = asd.wipe_all(dry_run=False)
        except Exception as e:
            QMessageBox.critical(self, "Wipe-All fehlgeschlagen", str(e))
            return

        lines = []
        lines.append("=" * 60)
        lines.append(f"  WIPE-ALL ABGESCHLOSSEN — {res.n_changes} Verzeichnis(se)/Datei(en)")
        lines.append("=" * 60)
        lines.append("")
        lines.append("Backups:")
        for b in res.backups_made:
            lines.append(f"   • {b}")
        if not res.backups_made:
            lines.append("   (keine — Verzeichnisse waren leer)")
        lines.append("")
        lines.append("Aktionen:")
        for c in res.changes:
            lines.append(f"   • {c}")
        if res.errors:
            lines.append("")
            lines.append("Fehler:")
            for e in res.errors:
                lines.append(f"   ⚠ {e}")
        lines.append("")
        lines.append("→ Bitte Py_DAW jetzt neu starten.")
        lines.append("  Beim nächsten Start werden DBs als saubere")
        lines.append("  Erst-Installation neu angelegt.")
        self._set_text("\n".join(lines))

        # Visually mark that restart is needed
        QMessageBox.information(
            self, "Wipe-All abgeschlossen",
            f"{res.n_changes} Element(e) gelöscht (mit Backup).\n\n"
            f"Bitte Py_DAW jetzt neu starten."
        )
