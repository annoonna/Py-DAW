"""
pydaw.flux.living_patterns_picker_dialog
==========================================

Overflow-Picker-Dialog für Living Patterns (v0.0.21.231).

Wird angezeigt wenn der User auf einen `+N more`-Chip am Modul klickt.
Zeigt ALLE observed/promoted Tags in einer Liste, mit Click-zu-(De)Promote.

UX:
* Modal-Dialog (nicht non-modal — der User trifft eine Auswahl und schließt)
* Zwei Sections: PROMOTED (mit ×-Button zum Demote) und OBSERVED (Click zum Promote)
* Suche/Filter-Feld am oberen Rand für Patches mit vielen Tags
* Counts in der Header-Zeile

NICHTS-KAPUTT
-------------
Reine UI — alle Mutationen gehen über den existierenden FluxScene-Pfad
(``_lp_promote`` / ``_lp_demote``). Wenn Qt fehlt, ist der Dialog ein Stub
und das +N more chip-Click ist ein no-op (wie in v.230).
"""

from __future__ import annotations

import logging
from typing import Optional

logger = logging.getLogger(__name__)


try:
    from PyQt6.QtCore import Qt, pyqtSignal
    from PyQt6.QtWidgets import (
        QDialog, QVBoxLayout, QHBoxLayout, QLabel,
        QListWidget, QListWidgetItem, QLineEdit, QPushButton,
        QWidget,
    )
    _QT_AVAILABLE = True
except ImportError:
    _QT_AVAILABLE = False


if _QT_AVAILABLE:

    class LivingPatternsPickerDialog(QDialog):  # type: ignore[misc]
        """Modal-Dialog mit ALLEN Tags eines Living-Patterns-Moduls.

        Signals:
            promote_requested(value)  — User klickt einen Observed-Eintrag
            demote_requested(value)   — User klickt einen Promoted-Eintrag

        Der Caller (FluxMainWidget) verbindet diese Signale mit den
        FluxScene-Coordination-Methoden (`_lp_promote` / `_lp_demote`).
        Nach jeder Mutation wird der Dialog-Inhalt neu aufgebaut, sodass
        der User mehrere Patterns hintereinander promoten/demoten kann
        bevor er den Dialog schließt.
        """

        promote_requested = pyqtSignal(object)
        demote_requested  = pyqtSignal(object)

        def __init__(
            self,
            module_label: str,
            promoted: list,
            observed: list,
            parent: Optional[QWidget] = None,
        ):
            super().__init__(parent)
            self.setWindowTitle(f"Living Patterns — {module_label}")
            self.setMinimumWidth(380)
            self.setMinimumHeight(420)
            self.setStyleSheet(
                "QDialog { background:#0a0e14; }"
                "QLabel  { color:#e6edf3; font-family: monospace; font-size: 10px; }"
                "QLineEdit { background:#0a0e14; color:#c4b5fd; "
                "border: 1px solid #2a1f3f; padding: 4px 6px; "
                "font-family: monospace; font-size: 10px; }"
                "QListWidget { background:#0a0e14; color:#e6edf3; "
                "border: 1px solid #161b22; font-family: monospace; "
                "font-size: 10px; }"
                "QListWidget::item { padding: 4px 6px; }"
                "QListWidget::item:selected { background:#1f1530; "
                "color:#a78bfa; }"
                "QPushButton { background:#0a0e14; color:#a78bfa; "
                "border: 1px solid #2a1f3f; padding: 4px 12px; "
                "font-family: monospace; font-size: 10px; }"
                "QPushButton:hover { background:#1f1530; }"
            )

            self._promoted: list = list(promoted)
            self._observed: list = list(observed)

            lay = QVBoxLayout(self)
            lay.setContentsMargins(8, 8, 8, 8)
            lay.setSpacing(6)

            # Header
            self._header = QLabel()
            self._header.setStyleSheet(
                "color:#a78bfa; font-weight: bold; font-size: 11px;"
            )
            lay.addWidget(self._header)

            # Filter
            self._filter = QLineEdit()
            self._filter.setPlaceholderText("Filter…")
            self._filter.textChanged.connect(self._rebuild_lists)
            lay.addWidget(self._filter)

            # Promoted-Section
            promoted_hdr = QLabel("❉ PROMOTED")
            promoted_hdr.setStyleSheet(
                "color:#a78bfa; font-weight: bold; padding: 4px 0 2px 0;"
            )
            lay.addWidget(promoted_hdr)
            self._promoted_list = QListWidget()
            self._promoted_list.itemClicked.connect(self._on_promoted_clicked)
            lay.addWidget(self._promoted_list, 1)

            # Observed-Section
            observed_hdr = QLabel("⊙ OBSERVED")
            observed_hdr.setStyleSheet(
                "color:#7d8dac; font-weight: bold; padding: 4px 0 2px 0;"
            )
            lay.addWidget(observed_hdr)
            self._observed_list = QListWidget()
            self._observed_list.itemClicked.connect(self._on_observed_clicked)
            lay.addWidget(self._observed_list, 1)

            # Footer
            footer_row = QHBoxLayout()
            self._hint = QLabel(
                "Klick auf einen Eintrag = (de)promote · ESC schließt"
            )
            self._hint.setStyleSheet(
                "color:#6b5e8a; font-size: 9px; font-style: italic;"
            )
            self._hint.setWordWrap(True)
            footer_row.addWidget(self._hint, 1)

            close_btn = QPushButton("Schließen")
            close_btn.clicked.connect(self.accept)
            footer_row.addWidget(close_btn)
            lay.addLayout(footer_row)

            self._rebuild_lists()

        # ─── Public API zum Refresh ────────────────────────────────

        def update_data(self, promoted: list, observed: list) -> None:
            """Aktualisiert die Listen — nach Promote/Demote vom Caller."""
            self._promoted = list(promoted)
            self._observed = list(observed)
            self._rebuild_lists()

        # ─── List-Aufbau ──────────────────────────────────────────

        def _rebuild_lists(self) -> None:
            try:
                from pydaw.flux.living_patterns import format_tag_label
            except Exception:
                format_tag_label = lambda v: str(v)

            f = (self._filter.text() or "").strip().lower()

            self._promoted_list.clear()
            for v in self._promoted:
                lbl = format_tag_label(v)
                if f and f not in lbl.lower():
                    continue
                item = QListWidgetItem(f"  {lbl}    ✕")
                item.setData(Qt.ItemDataRole.UserRole, v)
                item.setForeground(self.palette().color(
                    self.palette().ColorRole.WindowText
                ))
                self._promoted_list.addItem(item)

            self._observed_list.clear()
            for v in self._observed:
                lbl = format_tag_label(v)
                if f and f not in lbl.lower():
                    continue
                item = QListWidgetItem(f"  {lbl}")
                item.setData(Qt.ItemDataRole.UserRole, v)
                self._observed_list.addItem(item)

            self._header.setText(
                f"Patterns: {len(self._promoted)}   ·   "
                f"Observed: {len(self._observed)}"
            )

        # ─── Click-Handlers ───────────────────────────────────────

        def _on_promoted_clicked(self, item: QListWidgetItem) -> None:
            v = item.data(Qt.ItemDataRole.UserRole)
            self.demote_requested.emit(v)

        def _on_observed_clicked(self, item: QListWidgetItem) -> None:
            v = item.data(Qt.ItemDataRole.UserRole)
            self.promote_requested.emit(v)


else:
    # Qt fehlt — kein Dialog, kein Crash. Caller checkt None.
    LivingPatternsPickerDialog = None  # type: ignore[assignment,misc]


__all__ = ["LivingPatternsPickerDialog"]
