"""time_travel_tagger.py — KI-Auto-Tagging for the Time-Travel Engine.

v0.0.20.901 — Phase T6 der TIME_TRAVEL_ROADMAP.

Analysiert Journal-Events und generiert menschenlesbare Tags:
- MIDI-Analyse: Tonart, Rhythmus, Dichte, Register
- Parameter-Analyse: Filter-Bewegung, FX-Charakter, Dynamik
- Kontext-Analyse: Track-Name, Plugin, Preset, Gleichzeitigkeit

Lokal, kein API-Key noetig. Nutzt harmony_analysis.py fuer Tonart-Erkennung.

Tagging-Intervall: Alle 10 Sekunden wenn sich etwas aendert.
Keine Duplikate — aehnliche Tags werden zusammengefasst.

Usage:
    from pydaw.services.time_travel_tagger import TimeTravelTagger
    tagger = TimeTravelTagger.get()
    tagger.start(journal)
    # ... laeuft automatisch im Hintergrund ...
    tagger.stop()
"""

from __future__ import annotations

import logging
import time
from collections import Counter
from typing import Any, Dict, List, Optional, Set, Tuple

log = logging.getLogger(__name__)

try:
    from PyQt6.QtCore import QObject, QTimer
    _QT = True
except ImportError:
    _QT = False


# ── Tag generation helpers ──

_NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]


def _pitch_register(pitch: int) -> str:
    """Classify MIDI pitch into register."""
    if pitch < 36:
        return "Sub-Bass"
    elif pitch < 48:
        return "Bass"
    elif pitch < 60:
        return "unteres Mittel"
    elif pitch < 72:
        return "Mittel"
    elif pitch < 84:
        return "oberes Mittel"
    elif pitch < 96:
        return "Hoehe"
    return "Obertoene"


def _velocity_descriptor(vel: int) -> str:
    """Describe velocity character."""
    if vel < 30:
        return "sehr leise"
    elif vel < 60:
        return "leise"
    elif vel < 90:
        return "mittel"
    elif vel < 115:
        return "laut"
    return "sehr laut"


def _density_descriptor(note_count: int, duration_sec: float) -> str:
    """Describe note density."""
    if duration_sec <= 0:
        return ""
    nps = note_count / max(0.1, duration_sec)
    if nps < 0.5:
        return "spaerlich"
    elif nps < 2:
        return "locker"
    elif nps < 5:
        return "mittel"
    elif nps < 10:
        return "dicht"
    return "sehr dicht"


def _detect_key_from_pitches(pitches: List[int]) -> str:
    """Detect key from a list of MIDI pitches using harmony_analysis."""
    if len(pitches) < 3:
        return ""
    try:
        from pydaw.music.harmony_analysis import detect_key
        notes = [{"pitch": p, "duration": 1.0} for p in pitches]
        key_info = detect_key(notes)
        if key_info.confidence > 0.4:
            return key_info.full_name
    except Exception:
        pass
    return ""


def _param_change_descriptor(param_id: str, values: List[float]) -> str:
    """Describe a parameter change pattern."""
    if not values or len(values) < 2:
        return ""

    first, last = values[0], values[-1]
    diff = last - first
    spread = max(values) - min(values)

    pid = param_id.lower()

    # Identify parameter type
    if "cutoff" in pid or "filter" in pid or "freq" in pid:
        if diff > 0.15:
            return "Filter oeffnet"
        elif diff < -0.15:
            return "Filter schliesst"
        elif spread > 0.3:
            return "Filter Sweep"
        return "Filter-Bewegung"

    if "resonance" in pid or "reso" in pid or "q" == pid:
        if diff > 0.1:
            return "Resonanz steigt"
        elif diff < -0.1:
            return "Resonanz faellt"
        return "Resonanz-Aenderung"

    if "volume" in pid or "gain" in pid or "level" in pid:
        if diff > 0.1:
            return "Crescendo"
        elif diff < -0.1:
            return "Decrescendo"
        return "Lautstaerke-Aenderung"

    if "pan" in pid:
        if abs(diff) > 0.2:
            return "Pan-Bewegung"
        return ""

    if "reverb" in pid or "hall" in pid or "room" in pid:
        return "Hall-Aenderung"

    if "delay" in pid or "echo" in pid:
        return "Delay-Aenderung"

    if "drive" in pid or "dist" in pid or "overdrive" in pid:
        return "Distortion-Aenderung"

    if "attack" in pid or "release" in pid or "decay" in pid:
        return "Huellkurve angepasst"

    if "lfo" in pid or "rate" in pid:
        return "LFO/Rate geaendert"

    # Generic
    if spread > 0.3:
        return f"{param_id} grosser Sweep"
    elif abs(diff) > 0.1:
        return f"{param_id} geaendert"
    return ""


if _QT:

    class TimeTravelTagger(QObject):
        """Automatic tag generator for the Time-Travel journal.

        Singleton. Runs on a 10-second timer, analyzes recent events,
        generates human-readable tags, and stores them in the DB.
        """

        _instance: Optional["TimeTravelTagger"] = None

        @classmethod
        def get(cls) -> "TimeTravelTagger":
            if cls._instance is None:
                cls._instance = cls()
            return cls._instance

        def __init__(self, parent=None):
            super().__init__(parent)
            self._journal = None
            self._db = None
            self._running = False
            self._last_tag_ms: int = 0  # last tagged timestamp
            self._recent_tags: List[str] = []  # dedup buffer (last 20)
            self._tag_interval_ms = 10000  # 10s between tag generations

            self._timer = QTimer(self)
            self._timer.setInterval(self._tag_interval_ms)
            self._timer.timeout.connect(self._generate_tags)

        @property
        def is_running(self) -> bool:
            return self._running

        def start(self, journal=None) -> None:
            """Start automatic tagging."""
            self._journal = journal
            try:
                from pydaw.services.time_travel_db import TimeTravelDB
                self._db = TimeTravelDB.get()
                self._db.ensure_loaded()
            except Exception:
                pass

            if self._journal and self._db:
                self._running = True
                self._timer.start()
                log.info("[Tagger] Started (every %dms)", self._tag_interval_ms)

        def stop(self) -> None:
            """Stop automatic tagging."""
            self._timer.stop()
            self._running = False
            log.info("[Tagger] Stopped")

        def _generate_tags(self) -> None:
            """Analyze recent events and generate tags."""
            if not self._journal or not self._journal.is_running:
                return
            if not self._db:
                return

            session_id = self._journal.session_id
            current_ms = self._journal._timestamp_ms()

            # Analyze the last 10 seconds
            window_start = max(0, self._last_tag_ms)
            window_end = current_ms

            if window_end - window_start < 1000:
                return  # Too short, skip

            events = self._db.get_events_in_range(
                session_id, window_start, window_end
            )

            if not events:
                self._last_tag_ms = current_ms
                return

            # Generate tags from different analysis modules
            tags: List[str] = []
            tags.extend(self._analyze_midi_events(events))
            tags.extend(self._analyze_param_events(events))
            tags.extend(self._analyze_context_events(events))

            # Deduplicate against recent tags
            new_tags = []
            for tag in tags:
                tag_lower = tag.lower().strip()
                if tag_lower and tag_lower not in [t.lower() for t in self._recent_tags]:
                    new_tags.append(tag)
                    self._recent_tags.append(tag)

            # Keep dedup buffer at 50
            self._recent_tags = self._recent_tags[-50:]

            # Store tags
            if new_tags:
                combined = ", ".join(new_tags)
                self._db.add_tag(
                    session_id, current_ms,
                    combined, confidence=0.8, source="auto"
                )
                self._db.flush_events()
                log.debug("[Tagger] Generated: %s", combined)

            self._last_tag_ms = current_ms

        # ══════════════════════════════════════════════════════════
        # MIDI Analysis
        # ══════════════════════════════════════════════════════════

        def _analyze_midi_events(self, events: List[dict]) -> List[str]:
            """Analyze MIDI events and generate tags."""
            tags: List[str] = []

            midi_note_ons = [
                e for e in events
                if e.get("event_type") == "midi_note_on"
            ]

            if not midi_note_ons:
                return tags

            # Collect pitches and velocities
            pitches = [int(e.get("value_int", 60) or 60) for e in midi_note_ons]
            velocities = [int(e.get("value_float", 100) or 100) for e in midi_note_ons]

            # Key detection
            key_name = _detect_key_from_pitches(pitches)
            if key_name:
                tags.append(key_name)

            # Register analysis
            avg_pitch = sum(pitches) / len(pitches)
            register = _pitch_register(int(avg_pitch))
            tags.append(register)

            # Density
            if len(midi_note_ons) >= 2:
                first_ts = midi_note_ons[0].get("timestamp_ms", 0)
                last_ts = midi_note_ons[-1].get("timestamp_ms", 0)
                duration_sec = max(0.1, (last_ts - first_ts) / 1000)
                density = _density_descriptor(len(midi_note_ons), duration_sec)
                if density:
                    tags.append(density)

            # Velocity character
            if velocities:
                avg_vel = sum(velocities) / len(velocities)
                vel_desc = _velocity_descriptor(int(avg_vel))
                if vel_desc:
                    tags.append(vel_desc)

            # Polyphony detection
            # Check for simultaneous notes (same timestamp within 50ms)
            timestamps = sorted(set(e.get("timestamp_ms", 0) for e in midi_note_ons))
            if len(timestamps) >= 2:
                clusters = []
                cluster = [timestamps[0]]
                for t in timestamps[1:]:
                    if t - cluster[-1] < 50:
                        cluster.append(t)
                    else:
                        clusters.append(len(cluster))
                        cluster = [t]
                clusters.append(len(cluster))

                max_simul = max(clusters) if clusters else 1
                if max_simul >= 3:
                    tags.append("Akkorde")
                elif max_simul == 2:
                    tags.append("Intervalle")

            # Track context
            track_ids = set(e.get("track_id", "") for e in midi_note_ons if e.get("track_id"))
            if len(track_ids) > 1:
                tags.append(f"MIDI auf {len(track_ids)} Tracks")

            return tags

        # ══════════════════════════════════════════════════════════
        # Parameter Analysis
        # ══════════════════════════════════════════════════════════

        def _analyze_param_events(self, events: List[dict]) -> List[str]:
            """Analyze parameter change events."""
            tags: List[str] = []

            param_events = [
                e for e in events
                if e.get("event_type") == "param_change"
            ]

            if not param_events:
                return tags

            # Group by param_id → track value sequence
            by_param: Dict[str, List[float]] = {}
            for e in param_events:
                pid = e.get("param_id", "")
                vf = e.get("value_float")
                if pid and vf is not None:
                    by_param.setdefault(pid, []).append(float(vf))

            # Analyze each parameter
            for pid, values in by_param.items():
                desc = _param_change_descriptor(pid, values)
                if desc:
                    tags.append(desc)

            # Mixer changes
            mixer_params = {"volume", "pan", "muted", "solo"}
            mixer_changes = [e for e in param_events
                             if e.get("param_id") in mixer_params]
            if len(mixer_changes) > 5:
                tags.append("Mixer-Arbeit")

            return tags[:5]  # Max 5 param tags

        # ══════════════════════════════════════════════════════════
        # Context Analysis
        # ══════════════════════════════════════════════════════════

        def _analyze_context_events(self, events: List[dict]) -> List[str]:
            """Analyze context: plugins, presets, transport."""
            tags: List[str] = []

            for e in events:
                et = e.get("event_type", "")

                if et == "plugin_load":
                    plugin_name = e.get("value_text", "")
                    if plugin_name:
                        tags.append(f"Plugin: {plugin_name}")

                elif et == "preset_change":
                    preset = e.get("value_text", "")
                    plugin = e.get("plugin_id", "")
                    if preset:
                        tag = f"Preset: {preset}"
                        if plugin:
                            tag = f"{plugin} → {preset}"
                        tags.append(tag)

                elif et == "transport_play":
                    pass  # Don't tag every play

                elif et == "transport_bpm":
                    bpm = e.get("value_float")
                    if bpm:
                        tags.append(f"BPM: {int(bpm)}")

                elif et == "plugin_remove":
                    plugin_name = e.get("value_text", "")
                    if plugin_name:
                        tags.append(f"Entfernt: {plugin_name}")

            return tags[:4]  # Max 4 context tags

        # ══════════════════════════════════════════════════════════
        # Manual Tag
        # ══════════════════════════════════════════════════════════

        def tag_now(self, label: str) -> None:
            """Manually add a user tag at the current moment."""
            if not self._journal or not self._db:
                return
            session_id = self._journal.session_id
            current_ms = self._journal._timestamp_ms()
            self._db.add_tag(session_id, current_ms, label,
                              confidence=1.0, source="user")
            self._db.flush_events()

else:
    class TimeTravelTagger:
        _instance = None

        @classmethod
        def get(cls):
            if cls._instance is None:
                cls._instance = cls()
            return cls._instance

        def __init__(self):
            pass

        def start(self, journal=None):
            pass

        def stop(self):
            pass

        def tag_now(self, label=""):
            pass
