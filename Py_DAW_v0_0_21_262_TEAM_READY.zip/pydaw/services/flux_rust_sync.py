"""
pydaw.services.flux_rust_sync
==============================

**v0.0.21.183 — F-1.1 Audio-Routing Phase 1: Engine Sync Foundation.**

Diese Datei ist die Python-Seite des FLUX-Engine-Syncs. Wenn der User in
der UI einen FLUX-Patch baut, ändert oder einer Track zuweist, schickt
dieser Service den entsprechenden IPC-Befehl an die Rust-Engine.

Die Rust-Engine (`pydaw_engine/src/flux/registry.rs`) hält daraufhin
einen Spiegel des Patch-States in ihrer `FluxPatchRegistry`. F-1.1
liefert NUR den Sync — der Audio-Render-Pfad zur DAW-Track ist noch
nicht angeschlossen (das ist F-1.2..F-1.5). Bis dahin: Engine kennt
die Patches, hört sie aber noch nicht; Test-Play läuft weiter über
`pydaw.flux.audio_preview` (numpy).

Architektur
-----------

::

    UI (FluxMainWidget)
       │  add()/remove()/assign_to_track()/set_param()
       ▼
    FluxPatchService (Python, Single-Source-of-Truth)
       │  via Hook
       ▼
    FluxRustSync   ──IPC──→   FluxPatchRegistry (Rust)
       │
       └── RustEngineBridge.instance().send_command({"cmd": "FluxSyncPatch", ...})

Defensive Properties
---------------------

* **No-engine-mode**: wenn die Rust-Engine nicht läuft (Bridge nicht
  verbunden), schluckt der Sync alle Aufrufe lautlos. UI-Funktionalität
  bleibt unbeeinträchtigt — alle FLUX-Features funktionieren weiter
  rein in Python.
* **Idempotent**: `sync_patch()` kann beliebig oft mit dem gleichen
  Patch aufgerufen werden; die Rust-Seite ersetzt einfach.
* **Best-Effort**: Send-Fehler werden als WARN geloggt, nicht
  geworfen. Der UI-Thread bleibt am Leben.

Testbarkeit
-----------

Die `FluxRustSync.build_*_command()`-Methoden sind reine Funktionen,
die ein Dict bauen. Sie sind ohne laufende Engine testbar (siehe
`tests/test_flux_rust_sync.py`).
"""

from __future__ import annotations

import logging
from typing import Any, Optional

from pydaw.flux.patch_model import Patch


logger = logging.getLogger(__name__)


class FluxRustSync:
    """Stateless-ish IPC-Client für FLUX → Rust-Engine.

    Nutzt `RustEngineBridge.instance()` lazy beim ersten Aufruf — solange
    die Engine nicht läuft (oder das Rust-Backend deaktiviert ist), sind
    alle Methoden no-ops.

    Eine Instanz pro Anwendung reicht (`get_flux_rust_sync()`-Singleton),
    aber die Klasse ist auch ohne Singleton instanziierbar (für Tests).
    """

    def __init__(self) -> None:
        # Cached bridge — wird lazy aufgelöst, weil die Bridge-Singleton
        # erst nach Container-Init verfügbar ist.
        self._bridge: Any = None
        # Anzahl erfolgreich abgeschickter Commands (für Diagnose).
        self._sent_count: int = 0
        # Zähler abgewiesener Sends (Bridge nicht da).
        self._dropped_count: int = 0

    # ─── Bridge-Auflösung ────────────────────────────────────────────

    def _get_bridge(self) -> Any:
        """Holt die RustEngineBridge-Singleton — None wenn nicht verfügbar.

        Wird bei jedem Send aufgerufen: falls die Bridge nach Reconnect
        eine neue Instanz hat, sehen wir das. Defensiv gegen ImportError
        (z.B. in headless-Tests ohne Rust-Engine-Modul).
        """
        try:
            from pydaw.services.rust_engine_bridge import RustEngineBridge
            return RustEngineBridge.instance()
        except Exception as e:
            logger.debug("[FLUX-SYNC] Bridge unavailable: %s", e)
            return None

    def _send(self, cmd: dict) -> bool:
        """Versucht, ein Command zu senden. Bei Fehler: warn + return False."""
        bridge = self._get_bridge()
        if bridge is None:
            self._dropped_count += 1
            return False
        # Bridge-Methode `send_command(cmd: dict) -> bool`
        try:
            ok = bool(bridge.send_command(cmd))
        except Exception as e:
            logger.warning("[FLUX-SYNC] send_command threw: %s", e)
            self._dropped_count += 1
            return False
        if ok:
            self._sent_count += 1
        else:
            self._dropped_count += 1
            logger.debug("[FLUX-SYNC] send_command returned False (engine offline?)")
        return ok

    # ─── Command-Builder (PURE FUNCTIONS — testbar ohne Bridge) ──────

    @staticmethod
    def build_sync_patch_command(patch: Patch) -> dict:
        """Baut das `FluxSyncPatch`-IPC-Dict für einen Patch.

        Inputs/Outputs/Position werden bewusst NICHT übertragen — Rust
        nutzt `module_factory()`, das die kanonischen Ports kennt; und
        Position ist UI-only.

        v0.0.21.195: **UI-Widget-Filter** — Frigg-Module (Knob, Slider,
        Toggle, Bang, NumberBox, Comment) werden hier rausgefiltert,
        weil die Rust-Engine sie nicht kennt. Connections die durch
        ein UI-Widget gehen (als Source ODER Target) werden ebenfalls
        rausgefiltert. Der Effekt der UI-Widget-Verbindungen wird
        Python-side von `UiModuleBridge` direkt als
        `set_module_param`-Call am DSP-Ziel realisiert.

        v0.0.21.202: **Saga-Python-Only-Filter** — Saga.Magic ist in
        S-0 nur Python-side (Stippling-Visualizer ohne Rust-DSP).
        Es wird wie ein UI-Widget rausgefiltert: das Modul selbst
        verschwindet aus dem Sync-Payload, und Connections die durch
        Saga.Magic laufen werden so umverdrahtet, dass das Audio-
        Signal Saga.Magic effektiv überspringt (Pass-Through-Logik
        Python-seitig). In S-1+ wenn die Rust-Engine Saga-Module
        kennt, fällt dieser Filter weg.

        v0.0.21.203: **Saga.Magic Pass-Through-Rewiring (Bug-Fix)** —
        Die v.202-Logik droppte Connections an Saga.Magic-Endpunkten
        komplett, was den Audio-Pfad ``A → Saga.Magic → MasterOut`` zu
        zwei isolierten Inseln zerschnitt: Master hörte Stille. Jetzt
        werden Saga.Magic-IDs in eine separate Klasse ``passthrough_
        module_ids`` einsortiert: ein- und ausgehende Audio-Connections
        werden zu synthetischen ``A → MasterOut``-Connections
        zusammengefügt. UI-Widgets behalten das alte
        Drop-Verhalten (CV-Brücke übernimmt die Funktion).
        """
        # 1) UI-Widget-IDs, Saga-Pass-Through-IDs und alle bypass-IDs sammeln
        from pydaw.flux.saga.saga_magic_module import is_saga_python_only
        ui_module_ids: set[str] = set()
        # `passthrough_module_ids` = Module die KEIN Engine-Eintrag bekommen,
        # aber deren Audio-Connections rewired werden (Saga.Magic).
        passthrough_module_ids: set[str] = set()
        # `bypass_module_ids` = Vereinigung aus UI-Widgets + Pass-Through.
        # Module hier werden NICHT in `modules` gepackt (Engine kennt sie
        # nicht). Verbindungs-Behandlung unterscheidet sich (s.u.).
        bypass_module_ids: set[str] = set()
        modules = []
        for m in patch.modules:
            if m.is_ui_widget():
                ui_module_ids.add(str(m.id))
                bypass_module_ids.add(str(m.id))
                # NICHT in das `modules`-Array — Engine kennt Frigg nicht
                continue
            if is_saga_python_only(str(m.god), str(m.kind)):
                # Saga.Magic in S-0: Python-only Pass-Through.
                # NICHT im Sync-Payload — aber ein/aus-Connections
                # werden weiter unten zu Pass-Through-Routes umgebaut.
                passthrough_module_ids.add(str(m.id))
                bypass_module_ids.add(str(m.id))
                continue
            modules.append({
                "id":     str(m.id),
                "god":    str(m.god),
                "kind":   str(m.kind),
                # Params als Dict mit float-Werten — rmp-serde mappt das
                # nach HashMap<String, f32>.
                "params": {str(k): float(v) for (k, v) in (m.params or {}).items()
                           if isinstance(v, (int, float)) and not isinstance(v, bool)},
                # v0.0.21.246: String-Params separat senden. Z.B. Zerberus.Sampler
                # `file_path`, Ullr.Expr `expr`, Hermod.Osc* Pfade. Der Rust-Sync
                # ruft `set_string_param` für jedes Modul auf das diese Methode
                # implementiert (Default-Trait-Impl ist No-Op).
                "string_params": {str(k): str(v) for (k, v) in (m.params or {}).items()
                                  if isinstance(v, str)},
            })
        # 2) Connections filtern + Saga-Pass-Through rewiren.
        # Strategie:
        #   - Für JEDES Pass-Through-Modul X sammeln wir
        #       inputs[X][port_in]  = (src_module_id, src_port, scale, offset)
        #       outputs[X][port_out] = list of (tgt_module_id, tgt_port, scale, offset)
        #     (Es kann mehrere Targets pro Output-Port geben — Fan-Out!)
        #   - Beim L-Out wird aus jeder L-In-Source × jedem L-Out-Target
        #     eine synthetische Direktverbindung erzeugt. Analog R.
        #   - Skalen werden multipliziert, Offsets addiert (lineare Kette).
        # Saga.Magic kennt diese Audio-Port-Paare:
        SAGA_PORT_PAIRS = [
            ("audio_in_l", "audio_out_l"),
            ("audio_in_r", "audio_out_r"),
        ]
        passthrough_inputs: dict[str, dict[str, tuple]] = {
            mid: {} for mid in passthrough_module_ids
        }
        passthrough_outputs: dict[str, dict[str, list[tuple]]] = {
            mid: {} for mid in passthrough_module_ids
        }
        connections: list[dict] = []
        for c in patch.connections:
            src_id = str(c.source_module)
            tgt_id = str(c.target_module)
            # Schritt a) Connections die ein UI-Widget berühren -> droppen
            if src_id in ui_module_ids or tgt_id in ui_module_ids:
                continue
            # Schritt b) Connections die ein Saga-Pass-Through-Modul
            # als Endpunkt haben -> aufzeichnen für Rewiring, NICHT
            # in `connections` packen.
            if tgt_id in passthrough_module_ids:
                # ankommend bei Saga: Source soll später durchgeschleift werden
                passthrough_inputs[tgt_id][str(c.target_port)] = (
                    src_id, str(c.source_port), float(c.scale), float(c.offset),
                )
                continue
            if src_id in passthrough_module_ids:
                # abgehend von Saga: dieses Target wird gleich neu verdrahtet
                outs = passthrough_outputs[src_id].setdefault(
                    str(c.source_port), [],
                )
                outs.append((
                    tgt_id, str(c.target_port), float(c.scale), float(c.offset),
                ))
                continue
            # Schritt c) Normale DSP-zu-DSP-Connection
            connections.append({
                "id":            str(c.id),
                "source_module": src_id,
                "source_port":   str(c.source_port),
                "target_module": tgt_id,
                "target_port":   str(c.target_port),
                "scale":         float(c.scale),
                "offset":        float(c.offset),
            })
        # Schritt d) Pass-Through-Connections synthetisieren.
        # Pro Saga-Modul + Audio-Port-Paar: kreuze (alle Sources × alle Targets)
        # zu A→C-Connections, mit ID `<saga_id>__pt_<idx>` damit dedup-frei.
        synth_idx = 0
        for saga_id in passthrough_module_ids:
            ins = passthrough_inputs.get(saga_id, {})
            outs = passthrough_outputs.get(saga_id, {})
            for in_port, out_port in SAGA_PORT_PAIRS:
                src_tuple = ins.get(in_port)
                out_targets = outs.get(out_port, [])
                if src_tuple is None or not out_targets:
                    continue   # Pfad nicht voll verdrahtet -> leise OK
                src_mod, src_p, scale_a, offset_a = src_tuple
                # Wenn der Source SELBST ein Pass-Through-Modul ist,
                # bricht die Rewire-Kette hier ab (Cascade Saga→Saga
                # ist S-0 nicht supportet — Manifest §7).
                if src_mod in passthrough_module_ids:
                    logger.debug(
                        "[FLUX-SYNC] saga-cascade source %s skipped "
                        "(saga→saga not supported in S-0)", src_mod,
                    )
                    continue
                for tgt_mod, tgt_p, scale_b, offset_b in out_targets:
                    if tgt_mod in passthrough_module_ids:
                        # Cascade Saga→Saga abgefangen
                        logger.debug(
                            "[FLUX-SYNC] saga-cascade target %s skipped",
                            tgt_mod,
                        )
                        continue
                    connections.append({
                        "id":            f"{saga_id}__pt_{synth_idx}",
                        "source_module": src_mod,
                        "source_port":   src_p,
                        "target_module": tgt_mod,
                        "target_port":   tgt_p,
                        # Skalen multiplizieren, Offsets addieren
                        # (Saga.Magic ist linearer Pass-Through).
                        "scale":         scale_a * scale_b,
                        "offset":        offset_a + offset_b,
                    })
                    synth_idx += 1
                    logger.debug(
                        "[FLUX-SYNC] saga pass-through: %s.%s -> %s.%s "
                        "(via %s)", src_mod, src_p, tgt_mod, tgt_p, saga_id,
                    )
        return {
            "cmd":         "FluxSyncPatch",
            "patch_id":    str(patch.id),
            "name":        str(patch.name),
            "modules":     modules,
            "connections": connections,
        }

    @staticmethod
    def build_remove_patch_command(patch_id: str) -> dict:
        return {
            "cmd":      "FluxRemovePatch",
            "patch_id": str(patch_id),
        }

    @staticmethod
    def build_assign_command(track_id: str, patch_id: str) -> dict:
        # Leerer patch_id = Zuweisung entfernen (Rust-Seite erkennt das).
        return {
            "cmd":      "FluxAssignPatchToTrack",
            "track_id": str(track_id),
            "patch_id": str(patch_id or ""),
        }

    @staticmethod
    def build_set_param_command(
        patch_id: str, module_id: str, param: str, value: float,
    ) -> dict:
        return {
            "cmd":       "FluxSetModuleParam",
            "patch_id":  str(patch_id),
            "module_id": str(module_id),
            "param":     str(param),
            "value":     float(value),
        }

    # ─── High-Level-API (= das was FluxPatchService aufruft) ─────────

    def sync_patch(self, patch: Patch) -> bool:
        """Sendet kompletten Patch-State an die Engine."""
        cmd = self.build_sync_patch_command(patch)
        # Logging mit Statistik — hilft bei Diagnose, wenn ein Patch im
        # Audio-Pfad (F-1.3+) nicht angekommen zu sein scheint.
        n_mods = len(cmd["modules"])
        n_cons = len(cmd["connections"])
        logger.info(
            "[FLUX-SYNC] → engine: patch '%s' (%s) — %d modules, %d connections",
            patch.id, patch.name, n_mods, n_cons,
        )
        return self._send(cmd)

    def remove_patch(self, patch_id: str) -> bool:
        if not patch_id:
            return False
        logger.info("[FLUX-SYNC] → engine: remove patch '%s'", patch_id)
        return self._send(self.build_remove_patch_command(patch_id))

    def assign_to_track(self, track_id: str, patch_id: str) -> bool:
        logger.info(
            "[FLUX-SYNC] → engine: track '%s' → patch '%s'",
            track_id, patch_id or "(none)",
        )
        return self._send(self.build_assign_command(track_id, patch_id))

    def set_module_param(
        self, patch_id: str, module_id: str, param: str, value: float,
    ) -> bool:
        # v0.0.21.189: Param-Updates auf INFO-Level für Diagnose.
        # v0.0.21.190 — D-2: Anno's v.189-Live-Test hat bestätigt, dass
        # alle drei Diagnose-Logs (UI, SYNC, RUST) zuverlässig feuern —
        # der Bruch lag im Engine-Render-Pfad, nicht im IPC-Stack. Bei
        # 60+ Hz Knob-Drehrate würde diese Zeile das Log fluten —
        # daher zurück auf debug(). Die neue Engine-Diagnose
        # `[FLUX-RUST] param: ... (mod_name) ...` (D-1) gibt jetzt
        # genug Information ohne den Python-Layer zu spammen.
        ok = self._send(
            self.build_set_param_command(patch_id, module_id, param, value)
        )
        logger.debug(
            "[FLUX-SYNC] → engine: param patch=%s mod=%s %s=%g (sent=%s)",
            patch_id[:16], module_id[:16], param, value, ok,
        )
        return ok

    # ─── Diagnose ────────────────────────────────────────────────────

    def stats(self) -> dict[str, int]:
        return {
            "sent_count":    self._sent_count,
            "dropped_count": self._dropped_count,
        }

    def is_engine_available(self) -> bool:
        """True wenn die Bridge gerade verbunden ist (Best-Effort-Test)."""
        return self._get_bridge() is not None


# ─── Module-Level Singleton (mit lazy-init) ──────────────────────────

_INSTANCE: Optional[FluxRustSync] = None


def get_flux_rust_sync() -> FluxRustSync:
    """Singleton-Accessor. Sicher gegen mehrfache Aufrufe."""
    global _INSTANCE
    if _INSTANCE is None:
        _INSTANCE = FluxRustSync()
    return _INSTANCE


__all__ = ["FluxRustSync", "get_flux_rust_sync"]
