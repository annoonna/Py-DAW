"""
pydaw.flux.ui_widgets.toggle — Frigg.Toggle Bool-Schalter (Phase U-2)
=====================================================================

PureData-Style Toggle: rechteckiges Feld mit Kreuz / Häkchen das den
Zustand (off/on, also 0.0/1.0) zeigt. Klick wechselt den Zustand.

Eingebaut in v0.0.21.195 als zweites FLUX-PD-Widget nach dem
AnimatedKnob (v.194).
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


try:
    from PyQt6.QtCore import Qt, QRectF, QSize, pyqtSignal
    from PyQt6.QtGui import QColor, QPainter, QPen, QBrush, QFont
    from PyQt6.QtWidgets import QWidget, QSizePolicy
    _QT_AVAILABLE = True
except ImportError:
    _QT_AVAILABLE = False


if _QT_AVAILABLE:

    class ToggleWidget(QWidget):  # type: ignore[misc]
        """Rechteckiger PD-Toggle. Klick wechselt 0↔1.

        Signale
        -------
        ``value_changed(float)`` — feuert beim Klick mit dem neuen Wert
            (0.0 oder 1.0).
        """

        DEFAULT_SIZE = 36

        # Farben harmonieren mit FLUX-Stil
        COL_BG = "#0a0e14"
        COL_BORDER = "#3df0e0"
        COL_BORDER_DIM = "#1a1f29"
        COL_MARK_ON = "#3df0e0"
        COL_MARK_OFF = "#1a1f29"

        value_changed = pyqtSignal(float)

        def __init__(self, value: float = 0.0, parent=None):
            super().__init__(parent)
            self._value = 1.0 if float(value) >= 0.5 else 0.0
            size = self.DEFAULT_SIZE
            self.setMinimumSize(size, size)
            self.setMaximumSize(size + 4, size + 4)
            self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
            self.setToolTip(self._tooltip())

        @property
        def value(self) -> float:
            return self._value

        def set_value(self, value: float, *, emit_signal: bool = True) -> None:
            new_v = 1.0 if float(value) >= 0.5 else 0.0
            if new_v == self._value:
                return
            self._value = new_v
            if emit_signal:
                self.value_changed.emit(self._value)
            self.setToolTip(self._tooltip())
            self.update()

        def toggle(self) -> None:
            self.set_value(1.0 - self._value, emit_signal=True)

        def mousePressEvent(self, event):  # type: ignore[override]
            if event.button() == Qt.MouseButton.LeftButton:
                self.toggle()
                event.accept()
            else:
                super().mousePressEvent(event)

        def paintEvent(self, event):  # type: ignore[override]
            painter = QPainter(self)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)

            w = self.width()
            h = self.height()
            size = min(w, h) - 4
            x0 = (w - size) / 2
            y0 = (h - size) / 2
            rect = QRectF(x0, y0, size, size)

            # Hintergrund
            painter.setBrush(QBrush(QColor(self.COL_BG)))
            border_color = self.COL_BORDER if self._value > 0.5 else self.COL_BORDER_DIM
            painter.setPen(QPen(QColor(border_color), 1.5))
            painter.drawRoundedRect(rect, 3.0, 3.0)

            # Kreuz/Häkchen — wenn an: gefülltes inneres Quadrat
            if self._value > 0.5:
                inner = rect.adjusted(size * 0.20, size * 0.20,
                                       -size * 0.20, -size * 0.20)
                painter.setBrush(QBrush(QColor(self.COL_MARK_ON)))
                painter.setPen(Qt.PenStyle.NoPen)
                painter.drawRoundedRect(inner, 2.0, 2.0)

            painter.end()

        def _tooltip(self) -> str:
            state = "ON" if self._value > 0.5 else "OFF"
            return (
                f"<b>Toggle</b>: {state} ({self._value:g})<br>"
                "<span style='color:#8b949e;'>Klick = umschalten</span>"
            )

        def sizeHint(self):  # type: ignore[override]
            return QSize(self.DEFAULT_SIZE, self.DEFAULT_SIZE)

else:
    ToggleWidget = None  # type: ignore[assignment,misc]


__all__ = ["ToggleWidget"]
