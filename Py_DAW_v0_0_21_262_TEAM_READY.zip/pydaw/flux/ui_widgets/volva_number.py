"""
pydaw.flux.ui_widgets.volva_number — Frigg.VolvaNumber (Phase W-2)
=====================================================================

**Eingebaut in v0.0.21.200** als prophetisch-sigil-stilisierte
Zahlen-Anzeige. Spezifikation: ``PROJECT_DOCS/FLUX_GROVE_MANIFEST.md``
Sektion „FLUX Sigil — eigene Widget-Designs", W-2 Punkt 1.

Design (aus dem Manifest)
-------------------------

* Großes monospaced Zahlen-Display mit zarter Glow-Aura
* Bei Wert-Wechsel läuft eine **Pulse-Wave** von innen nach außen
  (kurzer One-Shot ANIM_PULSE_WAVE)
* Idle: subtiler Shimmer-Glow (Idle-Loop ANIM_SHIMMER, niedrige Amplitude)
* Klick → Edit-Modus mit Zahleneingabe
* Mausrad → Wert ändern (wie NumberBox)
* Drag-Vertikal → Wert ändern (mit Beschleunigung bei Shift)
* Wert wird mit konfigurierbarem Format dargestellt (default: 3 Dezimalen)

Nichts-Kaputt-Garantie
----------------------

* Identischer Signal-Vertrag wie ``NumberBoxWidget`` (v.195):
  ``value_changed(float)``, ``set_value(v, *, emit_signal=...)``,
  ``_minimum``/``_maximum``/``_default``-Felder. Damit funktioniert
  Auto-Range, UiModuleBridge, PropertiesPanel-Sync — unverändert.
* Reine Python-Schicht — keine Rust/IPC-Änderungen.
* Defensiv gegen fehlendes Qt — ``VolvaNumberWidget = None`` als Stub.
* Animation läuft über die zentrale ``AnimationEngine`` — CPU-budgetiert,
  SENTINEL-aware, reduced-motion-fähig.
* ``closeEvent()`` räumt Animation-Subscriptions auf
  (siehe v.198 Cleanup-Pakt mit ``FluxScene.set_patch``).
"""

from __future__ import annotations

import logging
from typing import Optional

logger = logging.getLogger(__name__)


try:
    from PyQt6.QtCore import (
        Qt, QPointF, QRectF, QSize, pyqtSignal,
    )
    from PyQt6.QtGui import (
        QColor, QPainter, QPen, QBrush, QFont, QRadialGradient,
    )
    from PyQt6.QtWidgets import QWidget, QSizePolicy
    _QT_AVAILABLE = True
except ImportError:
    _QT_AVAILABLE = False


from pydaw.flux.animation_engine import (
    get_animation_engine, ANIM_PULSE_WAVE, ANIM_SHIMMER,
)


def _clamp(v: float, lo: float, hi: float) -> float:
    if v < lo:
        return lo
    if v > hi:
        return hi
    return v


if _QT_AVAILABLE:

    class VolvaNumberWidget(QWidget):  # type: ignore[misc]
        """Prophetische Zahlen-Anzeige für FLUX-Patches.

        Signal-Vertrag (kompatibel zu ``NumberBoxWidget``):
            ``value_changed(float)`` — feuert sofort beim User-Eingriff
            ``set_value(v, *, emit_signal=True)`` — programmatischer Setter
            ``_minimum``, ``_maximum``, ``_default`` — Range-Felder
        """

        DEFAULT_W = 100
        DEFAULT_H = 56

        # Style-Tokens (Norse-Cyan + Goldglanz wie die anderen Sigils)
        BG_COLOR    = QColor(18, 24, 38)         # tiefes Dunkelblau
        BORDER_COL  = QColor(70, 90, 130, 200)
        DIGIT_COL   = QColor(125, 215, 230)       # Norse-Cyan
        DIGIT_GLOW  = QColor(125, 215, 230, 90)
        SHIMMER_COL = QColor(250, 220, 130, 100)  # Goldglanz
        PULSE_COL   = QColor(125, 215, 230, 130)

        value_changed = pyqtSignal(float)

        def __init__(
            self,
            value: float = 0.0,
            minimum: float = -1e6,
            maximum: float = 1e6,
            default: float = 0.0,
            decimals: int = 3,
            unit: str = "",
            module_id: Optional[str] = None,
            parent=None,
        ):
            super().__init__(parent)
            self._minimum = float(minimum)
            self._maximum = float(maximum)
            self._default = _clamp(float(default), self._minimum, self._maximum)
            self._value = _clamp(float(value), self._minimum, self._maximum)
            self._decimals = max(0, min(6, int(decimals)))
            self._unit = str(unit or "")
            self._module_id = str(module_id or "vol_unbound")

            # Animation-State
            self._pulse_phase: float = 0.0   # 0..1, läuft beim Wert-Wechsel
            self._shimmer_phase: float = 0.0  # 0..1, langsamer Idle-Loop

            # Drag-State
            self._drag_origin_y: Optional[float] = None
            self._drag_origin_value: float = 0.0

            self.setMinimumSize(self.DEFAULT_W, self.DEFAULT_H)
            self.setSizePolicy(QSizePolicy.Policy.Preferred,
                               QSizePolicy.Policy.Preferred)
            self.setMouseTracking(True)

            # Idle-Shimmer-Loop subscriben
            self._subscribe_idle_loop()

        # ─── Animation-Subscribes ─────────────────────────────────

        def _subscribe_idle_loop(self) -> None:
            try:
                eng = get_animation_engine()
                eng.subscribe(
                    sub_id=f"{self._module_id}::shimmer",
                    anim_name=ANIM_SHIMMER,
                    on_frame=self._on_shimmer_tick,
                )
            except Exception as e:
                logger.debug("[VolvaNumber] shimmer subscribe failed: %s", e)

        def _on_shimmer_tick(self, phase: float, frame: int) -> None:
            self._shimmer_phase = float(phase)
            try:
                self.update()
            except RuntimeError:
                # Widget ist deleted — Engine fängt's silent (v.198)
                raise

        def _trigger_pulse_wave(self) -> None:
            """Startet einen Pulse-Wave-One-Shot beim Wert-Wechsel."""
            try:
                eng = get_animation_engine()
                eng.subscribe(
                    sub_id=f"{self._module_id}::pulse",
                    anim_name=ANIM_PULSE_WAVE,
                    on_frame=self._on_pulse_tick,
                )
            except Exception as e:
                logger.debug("[VolvaNumber] pulse subscribe failed: %s", e)

        def _on_pulse_tick(self, phase: float, frame: int) -> None:
            self._pulse_phase = float(phase)
            try:
                self.update()
            except RuntimeError:
                raise

        # ─── Signal-Vertrag ────────────────────────────────────────

        @property
        def minimum(self) -> float:
            return self._minimum

        @property
        def maximum(self) -> float:
            return self._maximum

        def set_value(self, value: float, *, emit_signal: bool = True) -> None:
            new_v = _clamp(float(value), self._minimum, self._maximum)
            if abs(new_v - self._value) < 1e-12:
                return
            self._value = new_v
            self._trigger_pulse_wave()
            self.update()
            if emit_signal:
                self.value_changed.emit(self._value)

        def reset_to_default(self) -> None:
            self.set_value(self._default, emit_signal=True)

        def value(self) -> float:
            return self._value

        # ─── Painting ──────────────────────────────────────────────

        def sizeHint(self) -> QSize:
            return QSize(self.DEFAULT_W, self.DEFAULT_H)

        def paintEvent(self, event) -> None:
            p = QPainter(self)
            p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            r = self.rect().adjusted(2, 2, -2, -2)

            # Hintergrund mit Pulse-Aura wenn aktiv
            if self._pulse_phase > 0.0 and self._pulse_phase < 1.0:
                aura_alpha = int(80 * (1.0 - self._pulse_phase))
                aura = QRadialGradient(
                    QPointF(r.center().x(), r.center().y()),
                    r.width() * (0.5 + 0.5 * self._pulse_phase),
                )
                col = QColor(self.PULSE_COL)
                col.setAlpha(aura_alpha)
                aura.setColorAt(0.0, col)
                aura.setColorAt(1.0, QColor(0, 0, 0, 0))
                p.setBrush(QBrush(aura))
                p.setPen(Qt.PenStyle.NoPen)
                p.drawRoundedRect(QRectF(r), 6, 6)

            # Hintergrund (Dunkelblau)
            p.setBrush(QBrush(self.BG_COLOR))
            border = QPen(self.BORDER_COL, 1.2)
            p.setPen(border)
            p.drawRoundedRect(QRectF(r), 5, 5)

            # Idle-Shimmer als feiner Goldglanz-Streifen oben
            if self._shimmer_phase < 1.0:
                shimmer_x = float(r.left()) + r.width() * self._shimmer_phase
                shimmer_w = max(8.0, r.width() * 0.18)
                col = QColor(self.SHIMMER_COL)
                col.setAlpha(int(60 + 40 * self._shimmer_phase))
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QBrush(col))
                p.drawRect(QRectF(shimmer_x - shimmer_w / 2, r.top() + 2,
                                   shimmer_w, 2))

            # Zahlen-Text mit Glow
            text = self._format_value()
            font = QFont("monospace", 14, QFont.Weight.Bold)
            p.setFont(font)
            # Glow-Schicht
            glow_pen = QPen(self.DIGIT_GLOW, 3)
            p.setPen(glow_pen)
            p.drawText(r, Qt.AlignmentFlag.AlignCenter, text)
            # Echte Zahl
            p.setPen(QPen(self.DIGIT_COL, 1))
            p.drawText(r, Qt.AlignmentFlag.AlignCenter, text)

            p.end()

        def _format_value(self) -> str:
            if self._decimals == 0:
                txt = f"{self._value:.0f}"
            else:
                txt = f"{self._value:.{self._decimals}f}"
            if self._unit:
                txt = f"{txt} {self._unit}"
            return txt

        # ─── User-Eingabe ─────────────────────────────────────────

        def wheelEvent(self, event) -> None:
            steps = event.angleDelta().y() / 120.0
            range_ = self._maximum - self._minimum
            # 1% pro Klick, oder 0.1% mit Shift, oder 5% mit Ctrl
            mods = event.modifiers()
            if mods & Qt.KeyboardModifier.ShiftModifier:
                step = range_ * 0.001
            elif mods & Qt.KeyboardModifier.ControlModifier:
                step = range_ * 0.05
            else:
                step = range_ * 0.01
            self.set_value(self._value + steps * step, emit_signal=True)
            event.accept()

        def mousePressEvent(self, event) -> None:
            if event.button() == Qt.MouseButton.LeftButton:
                self._drag_origin_y = event.position().y()
                self._drag_origin_value = self._value
                event.accept()

        def mouseMoveEvent(self, event) -> None:
            if self._drag_origin_y is None:
                return
            dy = self._drag_origin_y - event.position().y()
            range_ = self._maximum - self._minimum
            # Drag-Beschleunigung: 1px = 0.5% der Range
            mods = event.modifiers()
            if mods & Qt.KeyboardModifier.ShiftModifier:
                speed = range_ * 0.0005
            else:
                speed = range_ * 0.005
            new_v = self._drag_origin_value + dy * speed
            self.set_value(new_v, emit_signal=True)
            event.accept()

        def mouseReleaseEvent(self, event) -> None:
            self._drag_origin_y = None
            event.accept()

        def mouseDoubleClickEvent(self, event) -> None:
            # Double-Click → reset to default
            if event.button() == Qt.MouseButton.LeftButton:
                self.reset_to_default()
                event.accept()

        # ─── Cleanup ──────────────────────────────────────────────

        def closeEvent(self, event) -> None:  # type: ignore[override]
            try:
                eng = get_animation_engine()
                eng.unsubscribe_prefix(f"{self._module_id}::")
            except Exception:
                pass
            super().closeEvent(event)


else:
    # Qt fehlt — Stub für Headless / Tests
    VolvaNumberWidget = None  # type: ignore[assignment,misc]


__all__ = ["VolvaNumberWidget"]
