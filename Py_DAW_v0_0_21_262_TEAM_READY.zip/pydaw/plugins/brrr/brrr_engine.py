"""BRRR Engine — Chaotic Flutter Synthesizer (PADsynth + S&H Flutter)

v0.0.20.767: S&H-Flutter durch Vibrato+Tremolo ersetzt.
  - Layer A: PADsynth Spektral-Synthese — organisch, warm, exakte Harmonische
  - Layer B: S&H-Flutter — gezähmt (depth 0.4, rate 4Hz), kein R2D2 mehr
  - FM Depth Knob → PADsynth Bandwidth (schmal→breit)
  - BP Freq Knob-Bug gefixt (Range-Skalierung für Drag-Sensitivity)
  - Scrawl-Envelopes modulieren ADSR
v0.0.20.755: Alle per-sample Python-Loops durch numpy vectorisiert.

Port des ZynAddSubFX BRRRRRR2-Fantasy als Py_DAW-Instrument.
Kompatibel mit SamplerRegistry (note_on/note_off/pull).
"""
from __future__ import annotations

import math
import threading
import numpy as np
from typing import Optional

# Pre-import scipy.signal damit der erste render()-Aufruf nicht ~2.5s hängt
try:
    from scipy.signal import lfilter as _lfilter
    _SCIPY_OK = True
except ImportError:
    _lfilter = None
    _SCIPY_OK = False

_SR_DEFAULT = 48000
_MAX_VOICES = 8          # reduziert von 16 → weniger CPU
_TWO_PI = 2.0 * math.pi


def _midi_to_hz(note: int) -> float:
    return 440.0 * (2.0 ** ((int(note) - 69) / 12.0))


# ── S&H-LFO (vollständig vektorisiert) ───────────────────────────────────────

class _SampleAndHoldLFO:
    def __init__(self):
        self.rate_hz: float = 0.78
        self.depth:   float = 1.0
        self._phase:  float = 0.0
        self._held:   float = 0.0

    def process_block(self, frames: int, sr: float) -> np.ndarray:
        """Vektorisiert: S&H-Ausgabe als Array (v0.0.20.759 — echte Vektorisierung)."""
        inc = self.rate_hz / max(1.0, sr)
        # Phase-Array aufbauen
        phases = self._phase + np.arange(frames, dtype=np.float64) * inc
        # Integer-Teil: bei jedem Wechsel wird ein neuer Wert gehalten
        crossings = np.floor(phases).astype(np.int64)
        prev_cross = int(math.floor(self._phase))

        # Finde alle Stellen wo sich der Integer-Teil ändert
        cross_diff = np.diff(crossings, prepend=prev_cross)
        change_mask = cross_diff > 0

        # Zufallswerte nur an Wechselstellen generieren
        n_changes = int(np.sum(change_mask))
        if n_changes == 0:
            # Kein einziger Wechsel — durchgehend den gehaltenen Wert
            out = np.full(frames, self._held, dtype=np.float64)
        else:
            # Zufallswerte für alle Wechselstellen
            rng_vals = (np.random.random(n_changes) * 2.0 - 1.0) * self.depth
            # Ergebnis-Array: an jeder Position den zuletzt gehaltenen Wert
            out = np.empty(frames, dtype=np.float64)
            change_indices = np.nonzero(change_mask)[0]
            # Segmente füllen: vor dem ersten Wechsel = alter held-Wert
            prev_end = 0
            held = self._held
            for seg_i in range(n_changes):
                ci = int(change_indices[seg_i])
                # Segment vom letzten Wechsel bis hierhin mit altem Wert füllen
                if ci > prev_end:
                    out[prev_end:ci] = held
                held = float(rng_vals[seg_i])
                prev_end = ci
            # Rest nach letztem Wechsel
            out[prev_end:] = held
            self._held = held

        # Phase aktualisieren
        final_phase = phases[-1] + inc if frames > 0 else self._phase
        self._phase = final_phase - math.floor(final_phase)
        return out


# ── Einfache ADSR-Hüllkurve (vektorisiert) ───────────────────────────────────

class _SimpleEnv:
    """Schnelle ADSR ohne Scrawl — für BRRR ausreichend.
    v0.0.20.759: Optimierte Blockverarbeitung — weniger Python-Overhead."""
    def __init__(self):
        self.attack_s  = 0.0
        self.decay_s   = 0.35
        self.sustain   = 0.0
        self.release_s = 0.25
        self._stage    = 0   # 0=idle 1=att 2=dec 3=sus 4=rel
        self._level    = 0.0
        self._vel      = 1.0

    def gate_on(self, velocity: float = 1.0) -> None:
        self._vel   = max(0.001, min(1.0, float(velocity)))
        self._stage = 1
        self._level = 0.0

    def gate_off(self) -> None:
        if self._stage > 0:
            self._stage = 4

    def is_active(self) -> bool:
        return self._stage > 0

    def process_block(self, frames: int, sr: float) -> np.ndarray:
        """Blockverarbeitung der ADSR — per-Stage Batch statt per-Sample Loop."""
        if self._stage == 0:
            return np.zeros(frames, dtype=np.float64)
        if self._stage == 3:
            # Sustain: konstanter Wert
            return np.full(frames, self.sustain * self._vel, dtype=np.float64)

        out = np.empty(frames, dtype=np.float64)
        lv  = self._level
        st  = self._stage
        vel = self._vel
        att = 1.0 / max(0.0001, self.attack_s  * sr) if self.attack_s  > 0.0001 else 1e9
        dec = 1.0 / max(0.0001, self.decay_s   * sr) if self.decay_s   > 0.0001 else 1e9
        rel = 1.0 / max(0.0001, self.release_s * sr) if self.release_s > 0.0001 else 1e9
        sus = self.sustain * vel

        pos = 0
        while pos < frames:
            remaining = frames - pos
            if st == 0:
                out[pos:] = 0.0
                lv = 0.0
                break
            elif st == 1:
                # Attack: lv steigt um att pro Sample bis vel
                samples_to_peak = max(1, int(math.ceil((vel - lv) / att)))
                n = min(remaining, samples_to_peak)
                out[pos:pos + n] = np.linspace(lv, lv + att * n, n, endpoint=False)
                lv += att * n
                pos += n
                if lv >= vel:
                    lv = vel
                    st = 2
            elif st == 2:
                # Decay: lv fällt um dec pro Sample bis sus
                if lv <= sus:
                    lv = sus
                    st = 3 if sus > 0.001 else 0
                    continue
                samples_to_sus = max(1, int(math.ceil((lv - sus) / dec)))
                n = min(remaining, samples_to_sus)
                out[pos:pos + n] = np.linspace(lv, lv - dec * n, n, endpoint=False)
                lv -= dec * n
                pos += n
                if lv <= sus:
                    lv = sus
                    st = 3 if sus > 0.001 else 0
            elif st == 3:
                out[pos:] = sus
                lv = sus
                break
            elif st == 4:
                if lv <= 0.001:
                    lv = 0.0
                    st = 0
                    out[pos:] = 0.0
                    break
                samples_to_zero = max(1, int(math.ceil(lv / rel)))
                n = min(remaining, samples_to_zero)
                out[pos:pos + n] = np.linspace(lv, lv - rel * n, n, endpoint=False)
                lv -= rel * n
                pos += n
                if lv <= 0.001:
                    lv = 0.0
                    st = 0
            else:
                out[pos:] = 0.0
                break

        np.clip(out, 0.0, None, out=out)
        self._level = max(0.0, lv)
        self._stage = st
        return out


# ── Scrawl-Hüllkurve Lookup (vektorisiert) ─────────────────────────────────

def _scrawl_lookup(table: np.ndarray, age_samples: int, frames: int,
                   total_duration_s: float, sr: float) -> np.ndarray:
    """Liest Scrawl-Tabelle als Envelope-Modulator, positionsbasiert auf Voice-Alter.

    table:           np.ndarray (0..1), typisch 256 Samples
    age_samples:     aktuelles Voice-Alter in Samples (vor diesem Block)
    frames:          Blockgröße
    total_duration_s: Gesamtdauer in Sekunden (aus ADSR A+D+R)
    sr:              Sample-Rate

    Returns: np.ndarray (frames,) mit Werten 0..1 als Amplituden-Multiplikator.
    """
    tbl_len = len(table)
    total_samples = max(1.0, total_duration_s * sr)
    # Positionen im Block (0-based ab Voice-Start)
    sample_positions = np.arange(age_samples, age_samples + frames, dtype=np.float64)
    # Fortschritt 0..1 über die Gesamtdauer, geclampt auf 0..1
    progress = np.clip(sample_positions / total_samples, 0.0, 1.0)
    # In Tabellenindex umrechnen (0..tbl_len-1)
    tbl_pos = progress * (tbl_len - 1)
    idx_lo = tbl_pos.astype(np.intp)
    idx_hi = np.minimum(idx_lo + 1, tbl_len - 1)
    frac = tbl_pos - idx_lo
    # Lineare Interpolation
    return table[idx_lo] * (1.0 - frac) + table[idx_hi] * frac


# ── PADsynth Wavetable (Paul Nasca) ───────────────────────────────────────────

_PADSYNTH_SIZE = 65536

# BRRRRRR2-Harmonisches Profil aus demo.mp3 Analyse
_BRRRR_HARMONICS = {
    1: 1.000, 2: 0.350, 3: 0.150, 4: 0.050,
    5: 0.030, 6: 0.080, 7: 0.060, 8: 0.020, 9: 0.015,
}


def _padsynth_table(f0: float, sr: float,
                    bandwidth_cents: float = 40.0) -> np.ndarray:
    """PADsynth: Gauß-Bandbreiten pro Harmonische → organische Wavetable."""
    N = _PADSYNTH_SIZE
    freq_spectrum = np.zeros(N // 2 + 1, dtype=np.float64)
    freqs = np.fft.rfftfreq(N, 1.0 / sr)
    for h_num, amp in _BRRRR_HARMONICS.items():
        h_freq = f0 * h_num
        if h_freq >= sr * 0.45:
            continue
        bw_hz = max(0.5, (2.0 ** (bandwidth_cents / 1200.0) - 1.0) * h_freq)
        sigma = max(0.01, bw_hz / (2.0 * math.sqrt(2.0 * math.log(2.0))))
        freq_spectrum += amp * np.exp(-0.5 * ((freqs - h_freq) / sigma) ** 2)
    phases = np.random.uniform(0, _TWO_PI, len(freq_spectrum))
    table = np.fft.irfft(freq_spectrum * np.exp(1j * phases), n=N)
    peak = np.max(np.abs(table))
    if peak > 1e-10:
        table *= (0.9 / peak)
    return table.astype(np.float64)


# ── BRRR Voice (PADsynth Buzz + S&H Flutter) ─────────────────────────────────

class _BrrrVoice:
    def __init__(self, sr: int = _SR_DEFAULT):
        self._sr   = float(sr)
        self.active = False
        self.pitch  = 60
        self.freq   = 440.0
        self.velocity = 1.0
        self._age   = 0

        # Layer A: PADsynth Buzz
        self._pad_table: Optional[np.ndarray] = None
        self._pad_phase  = np.zeros(3, dtype=np.float64)
        self._buzz_env   = _SimpleEnv()
        self._detune_l   = -18.0
        self._detune_r   = 15.0

        # Layer B: Flutter (S&H LFO → Pitch-Modulation)
        self._flutter_env  = [_SimpleEnv(), _SimpleEnv()]
        self._sah_lfo      = [_SampleAndHoldLFO(), _SampleAndHoldLFO()]
        self._flutter_ph   = np.zeros(2, dtype=np.float64)
        self._bp_zi = [np.zeros((2, 1)), np.zeros((2, 1))]

        # Scrawl envelope
        self._buzz_env_total_s    = 1.0
        self._flutter_env_total_s = 1.0

    def note_on(self, pitch: int, velocity: float,
                buzz_a, buzz_d, buzz_s, buzz_r,
                flutter_a, flutter_r,
                sah_rate_a, sah_depth_a, sah_rate_b, sah_depth_b,
                fm_depth, detune_l, detune_r) -> None:
        self.active   = True
        self.pitch    = pitch
        self.freq     = _midi_to_hz(pitch)
        self.velocity = max(0.001, min(1.0, float(velocity) / 127.0))
        self._age     = 0
        self._pad_phase[:] = 0.0
        self._flutter_ph[:] = 0.0
        self._bp_zi = [np.zeros((2, 1)), np.zeros((2, 1))]

        # PADsynth Wavetable generieren (~5-25ms, einmalig pro Note)
        bw = 40.0 + float(fm_depth) * 80.0
        self._pad_table = _padsynth_table(self.freq, self._sr, bandwidth_cents=bw)

        e = self._buzz_env
        e.attack_s = buzz_a; e.decay_s = buzz_d
        e.sustain  = buzz_s; e.release_s = buzz_r
        e.gate_on(self.velocity)

        for k, (fa, fr) in enumerate([(flutter_a * (1 + k * 0.3), flutter_r)
                                       for k in range(2)]):
            fenv = self._flutter_env[k]
            fenv.attack_s = fa; fenv.decay_s = 0.1
            fenv.sustain  = 1.0; fenv.release_s = fr
            fenv.gate_on(self.velocity)

        self._sah_lfo[0].rate_hz = sah_rate_a
        self._sah_lfo[0].depth   = sah_depth_a
        self._sah_lfo[1].rate_hz = sah_rate_b
        self._sah_lfo[1].depth   = sah_depth_b
        self._detune_l = float(detune_l)
        self._detune_r = float(detune_r)

        self._buzz_env_total_s    = max(0.05, buzz_a + buzz_d + buzz_r)
        self._flutter_env_total_s = max(0.05, flutter_a + 0.1 + flutter_r)

    def note_off(self) -> None:
        for e in [self._buzz_env] + self._flutter_env:
            e.gate_off()

    def is_active(self) -> bool:
        return self.active and (
            self._buzz_env.is_active()
            or any(e.is_active() for e in self._flutter_env)
        )

    def render(self, frames: int, buzz_vol: float, flutter_vol: float,
               bp_b: np.ndarray, bp_a: np.ndarray,
               buzz_scrawl: 'Optional[np.ndarray]' = None,
               flutter_scrawl: 'Optional[np.ndarray]' = None) -> np.ndarray:
        out = np.zeros(frames, dtype=np.float64)
        sr  = self._sr
        freq = self.freq
        vel  = self.velocity
        t   = np.arange(frames, dtype=np.float64)

        # ── Layer A: PADsynth Buzz ────────────────────────────────────
        if buzz_vol > 0.001 and self._pad_table is not None:
            buzz_env = self._buzz_env.process_block(frames, sr)

            if buzz_scrawl is not None and len(buzz_scrawl) > 1:
                scrawl_mod = _scrawl_lookup(buzz_scrawl, self._age, frames,
                                            self._buzz_env_total_s, sr)
                buzz_env *= scrawl_mod

            tbl = self._pad_table
            tbl_len = len(tbl)

            voice_freqs = np.array([
                freq,
                freq * (2.0 ** (self._detune_l / 1200.0)),
                freq * (2.0 ** (self._detune_r / 1200.0)),
            ])
            pan_w = np.array([0.5, 0.25, 0.25])

            buzz_buf = np.zeros(frames, dtype=np.float64)
            for vi in range(3):
                inc = voice_freqs[vi] / (freq * float(tbl_len))
                phases = (self._pad_phase[vi] + t * inc) % 1.0
                pos = phases * tbl_len
                idx_lo = pos.astype(np.intp) % tbl_len
                idx_hi = (idx_lo + 1) % tbl_len
                frac = pos - np.floor(pos)
                v_buf = tbl[idx_lo] * (1.0 - frac) + tbl[idx_hi] * frac
                buzz_buf += v_buf * pan_w[vi]
                self._pad_phase[vi] = (self._pad_phase[vi] + frames * inc) % 1.0

            out += buzz_buf * buzz_env * buzz_vol * vel

        # ── Modulation: Vibrato + Tremolo auf PADsynth ────────────────
        # (ersetzt den alten S&H-Flutter Layer komplett)
        if flutter_vol > 0.001:
            # Vibrato: smooth Sine-LFO auf Pitch (±Cents, nicht Oktaven!)
            vib_rate = self._sah_lfo[0].rate_hz   # repurposed: Vibrato-Rate
            vib_depth = self._sah_lfo[0].depth    # repurposed: Vibrato-Depth in Cents
            if vib_depth > 0.01:
                vib_phase_inc = vib_rate / sr
                vib_phases = _TWO_PI * (self._flutter_ph[0] + t * vib_phase_inc)
                vib_mod = np.sin(vib_phases) * (vib_depth / 1200.0)  # Cents → Ratio
                # Vibrato moduliert den PADsynth-Output per Pitch-Shift
                # (Frequenz-Modulation auf den fertigen Sound = Chorus-artiger Effekt)
                out *= (1.0 + vib_mod * flutter_vol)
                self._flutter_ph[0] = (self._flutter_ph[0] + frames * vib_phase_inc) % 1.0

            # Tremolo: smooth Sine-LFO auf Amplitude
            trem_rate = self._sah_lfo[1].rate_hz   # repurposed: Tremolo-Rate
            trem_depth = self._sah_lfo[1].depth     # repurposed: Tremolo-Depth (0-1)
            if trem_depth > 0.01:
                trem_phase_inc = trem_rate / sr
                trem_phases = _TWO_PI * (self._flutter_ph[1] + t * trem_phase_inc)
                # Tremolo: 1.0 ± depth*flutter_vol (nie unter 0)
                trem_mod = 1.0 - (0.5 + 0.5 * np.sin(trem_phases)) * trem_depth * flutter_vol
                out *= trem_mod
                self._flutter_ph[1] = (self._flutter_ph[1] + frames * trem_phase_inc) % 1.0

        self._age += frames
        if not self.is_active():
            self.active = False
        return out


def _make_bp_coeffs(freq_hz: float, q: float, sr: float):
    """Biquad Bandpass Koeffizienten für scipy.signal.lfilter."""
    w0    = _TWO_PI * freq_hz / max(1.0, sr)
    alpha = math.sin(w0) / (2.0 * max(0.1, q))
    b0    =  alpha
    b2    = -alpha
    a0    =  1.0 + alpha
    a1    = -2.0 * math.cos(w0)
    a2    =  1.0 - alpha
    b = np.array([b0 / a0, 0.0, b2 / a0])
    a = np.array([1.0, a1 / a0, a2 / a0])
    return b, a


# ── BRRR Engine ───────────────────────────────────────────────────────────────

class BrrrEngine:
    PLUGIN_ID = "chrono.brrr"

    def __init__(self, target_sr: int = _SR_DEFAULT):
        self._sr   = int(target_sr)
        self._lock = threading.Lock()
        self._voices = [_BrrrVoice(self._sr) for _ in range(_MAX_VOICES)]

        # v0.0.20.765: PADsynth Buzz + gezähmter Flutter
        self.buzz_volume   = 0.90
        self.buzz_attack   = 0.000
        self.buzz_decay    = 0.40
        self.buzz_sustain  = 0.40
        self.buzz_release  = 0.20
        self.fm_depth      = 0.20
        self.detune_l      = -18.0
        self.detune_r      = 15.0
        # v0.0.20.767: Vibrato + Tremolo statt S&H Flutter
        self.flutter_volume  = 0.50
        self.flutter_attack  = 0.08
        self.flutter_release = 0.50
        self.sah_rate_a    = 4.5     # Vibrato Rate (Hz)
        self.sah_depth_a   = 15.0    # Vibrato Depth (Cents)
        self.sah_rate_b    = 3.0     # Tremolo Rate (Hz)
        self.sah_depth_b   = 0.3     # Tremolo Depth (0-1)
        self.bp_freq       = 1400.0
        self.bp_q          = 0.6
        self.gain          = 1.4
        self.pan           = 0.0
        self.vel_sensitivity = 0.85

        # v0.0.20.762: 1-Pole HP State bei ~40Hz (Sub-Rumble entfernen)
        self._hp_z1 = 0.0
        self._hp_zi = np.zeros((1, 1), dtype=np.float64)  # lfilter state

        # Pre-compute BP-Koeffizienten (aktualisiert wenn bp_freq/bp_q sich ändert)
        self._bp_b, self._bp_a = _make_bp_coeffs(self.bp_freq, self.bp_q, self._sr)
        self._last_bp_freq = self.bp_freq
        self._last_bp_q    = self.bp_q

        self.buzz_scrawl_table    = None
        self.flutter_scrawl_table = None

    def _ensure_bp(self) -> None:
        if self.bp_freq != self._last_bp_freq or self.bp_q != self._last_bp_q:
            self._bp_b, self._bp_a = _make_bp_coeffs(self.bp_freq, self.bp_q, self._sr)
            self._last_bp_freq = self.bp_freq
            self._last_bp_q    = self.bp_q

    def note_on(self, pitch: int, velocity: int = 100, **_) -> bool:
        with self._lock:
            vel_f = float(velocity) / 127.0
            vel_s = 1.0 - self.vel_sensitivity + self.vel_sensitivity * vel_f
            voice = self._alloc(pitch)
            if voice is None:
                return False
            voice.note_on(
                pitch=int(pitch),
                velocity=int(vel_s * 127),
                buzz_a=self.buzz_attack, buzz_d=self.buzz_decay,
                buzz_s=self.buzz_sustain, buzz_r=self.buzz_release,
                flutter_a=self.flutter_attack, flutter_r=self.flutter_release,
                sah_rate_a=self.sah_rate_a, sah_depth_a=self.sah_depth_a,
                sah_rate_b=self.sah_rate_b, sah_depth_b=self.sah_depth_b,
                fm_depth=self.fm_depth,
                detune_l=self.detune_l, detune_r=self.detune_r,
            )
            return True

    def note_off(self, pitch: int = -1) -> None:
        with self._lock:
            for v in self._voices:
                if v.active and (pitch < 0 or v.pitch == pitch):
                    v.note_off()

    def all_notes_off(self) -> None:
        with self._lock:
            for v in self._voices:
                v.active = False

    def trigger_note(self, pitch: int, velocity: int = 100) -> None:
        self.note_on(pitch, velocity)

    def pull(self, frames: int, sr: int) -> Optional[np.ndarray]:
        with self._lock:
            active = [v for v in self._voices if v.is_active()]
            if not active:
                return None
            # v0.0.20.759: SR-Wechsel erkennen und BP-Koeffizienten anpassen
            actual_sr = float(sr) if sr > 0 else self._sr
            if actual_sr != self._sr:
                self._sr = actual_sr
                for v in self._voices:
                    v._sr = actual_sr
                self._bp_b, self._bp_a = _make_bp_coeffs(
                    self.bp_freq, self.bp_q, actual_sr)
                self._last_bp_freq = self.bp_freq
                self._last_bp_q = self.bp_q
                self._hp_zi = np.zeros((1, 1), dtype=np.float64)
            bv = self.buzz_volume
            fv = self.flutter_volume
            gain = self.gain
            pan  = self.pan
            self._ensure_bp()
            bp_b = self._bp_b.copy()
            bp_a = self._bp_a.copy()
            # v0.0.20.761: Scrawl-Tabellen unter Lock kopieren (Thread-Safety)
            b_scrawl = self.buzz_scrawl_table
            f_scrawl = self.flutter_scrawl_table

        mix = np.zeros(frames, dtype=np.float64)
        for v in active:
            try:
                mix += v.render(frames, bv, fv, bp_b, bp_a,
                                buzz_scrawl=b_scrawl,
                                flutter_scrawl=f_scrawl)
            except Exception:
                pass

        # v0.0.20.762: 1-Pole HP bei ~40Hz — Sub-Rumble entfernen (vektorisiert)
        try:
            if _SCIPY_OK:
                R = math.exp(-_TWO_PI * 40.0 / max(1.0, actual_sr))
                hp_b = np.array([1.0, -1.0])
                hp_a = np.array([1.0, -R])
                filtered, self._hp_zi = _lfilter(
                    hp_b, hp_a, mix.reshape(1, -1),
                    axis=1, zi=self._hp_zi
                )
                mix = filtered.reshape(-1)
        except Exception:
            pass  # Fallback: kein HP (lieber Sound als Crash)

        # v0.0.20.762: Sanftere Sättigung, höherer Pegel (wie ZynAdd)
        np.tanh(mix * 0.6, out=mix)
        mix *= gain

        p = max(0.0, min(1.0, (pan + 1.0) * 0.5))
        stereo = np.empty((frames, 2), dtype=np.float64)
        stereo[:, 0] = mix * math.cos(p * math.pi * 0.5)
        stereo[:, 1] = mix * math.sin(p * math.pi * 0.5)
        return stereo

    def export_state(self) -> dict:
        with self._lock:
            return {
                "schema": 1,
                "buzz_volume": self.buzz_volume, "buzz_attack": self.buzz_attack,
                "buzz_decay": self.buzz_decay, "buzz_sustain": self.buzz_sustain,
                "buzz_release": self.buzz_release, "fm_depth": self.fm_depth,
                "detune_l": self.detune_l, "detune_r": self.detune_r,
                "flutter_volume": self.flutter_volume, "flutter_attack": self.flutter_attack,
                "flutter_release": self.flutter_release,
                "sah_rate_a": self.sah_rate_a, "sah_depth_a": self.sah_depth_a,
                "sah_rate_b": self.sah_rate_b, "sah_depth_b": self.sah_depth_b,
                "bp_freq": self.bp_freq, "bp_q": self.bp_q,
                "gain": self.gain, "pan": self.pan, "vel_sensitivity": self.vel_sensitivity,
                "buzz_scrawl": self.buzz_scrawl_table.tolist()
                    if self.buzz_scrawl_table is not None else None,
                "flutter_scrawl": self.flutter_scrawl_table.tolist()
                    if self.flutter_scrawl_table is not None else None,
            }

    def import_state(self, d: dict) -> None:
        if not isinstance(d, dict):
            return
        with self._lock:
            for k in ("buzz_volume","buzz_attack","buzz_decay","buzz_sustain",
                      "buzz_release","fm_depth","flutter_volume","flutter_attack",
                      "flutter_release","sah_rate_a","sah_depth_a","sah_rate_b",
                      "sah_depth_b","bp_freq","bp_q","gain","pan",
                      "vel_sensitivity","detune_l","detune_r"):
                if k in d:
                    try: setattr(self, k, float(d[k]))
                    except Exception: pass
            bs = d.get("buzz_scrawl")
            self.buzz_scrawl_table = np.array(bs, dtype=np.float64) if bs else None
            fs = d.get("flutter_scrawl")
            self.flutter_scrawl_table = np.array(fs, dtype=np.float64) if fs else None
            # BP-Koeffizienten neu berechnen
            self._bp_b, self._bp_a = _make_bp_coeffs(self.bp_freq, self.bp_q, self._sr)
            self._last_bp_freq = self.bp_freq
            self._last_bp_q    = self.bp_q

    def _alloc(self, pitch: int):
        for v in self._voices:
            if v.active and v.pitch == pitch:
                v.active = False
        for v in self._voices:
            if not v.active:
                return v
        oldest = max(self._voices, key=lambda v: v._age)
        oldest.active = False
        return oldest
