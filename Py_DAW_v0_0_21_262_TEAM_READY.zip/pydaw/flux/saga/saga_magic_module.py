"""
pydaw.flux.saga.saga_magic_module — Saga.Magic Modul-Definition
================================================================

**v0.0.21.202 — S-0**

Liefert die Modul-Factory ``make_saga_magic()`` für die Registrierung
in ``module_library.MODULE_REGISTRY``.

Spec aus FLUX_SAGA_MANIFEST §4.1
--------------------------------

::

    kind: Saga.Magic
    god: Saga
    title: Magic
    ports:
      inputs:
        - audio_in_l (audio)
        - audio_in_r (audio)
      outputs:
        - audio_out_l (audio)  # Pass-through
        - audio_out_r (audio)  # Pass-through
    parameters:
      shape:           int 0..23, Default: 0 (Heart)
      density:         float 0..1, Default: 0.7
      rotation_speed:  float -2..2, Default: 0.5
      audio_react:     float 0..1, Default: 0.6
      palette:         int 0..N, Default: 0 (Norse-Cyan)
    body_height: 200

Audio-Verhalten in S-0
----------------------

**Pass-Through (Python-side).** Da Saga.Magic in S-0 noch keinen Rust-
DSP-Counterpart hat, übersetzt sich die `audio_in_*`/`audio_out_*`-
Verkabelung direkt in einen verlustfreien Wire-Through im Patch-Graph.

In S-0+ wird die Rust-Engine das Modul tappen (Audio-Features) bevor
sie weiterleitet — das bleibt Pass-Through aber liefert RMS/Centroid/
Flatness/Onset an den Python-Renderer.

**KRITISCH für die Rust-Sync:** Saga.Magic ist KEIN UI-Widget wie Frigg.
Der ``flux_rust_sync.build_sync_patch_command()`` würde es deshalb in
seinen `module_factory()`-Lookup leiten und scheitern (kein DSP-Code).
Damit der Stand v.202 lauffähig ist, MUSS die Rust-Sync das Modul
explizit ausfiltern (siehe ``flux_rust_sync.py``-Patch in derselben
Session) bzw. die Rust-Engine MUSS einen Pass-Through-Stub kennen.
Wir wählen den Filter-Pfad — minimaler Eingriff, keine Rust-Änderung.
"""
from __future__ import annotations

from pydaw.flux.patch_model import (
    Module, Port, PortDirection, PortKind,
)
from pydaw.services.saga_factory_shapes import DEFAULT_SHAPE_ID


# Default-Bodyhöhe etwas größer als andere Module (Manifest §4.1 = 200 px).
# Andere FLUX-Module haben default 96-130 px — Saga.Magic darf größer
# sein damit die Form gut sichtbar ist.
SAGA_MAGIC_BODY_HEIGHT = 200


def make_saga_magic() -> Module:
    """Saga.Magic — Stippling-Visualizer mit 24 Formen, Pass-Through-Audio.

    Inputs:
        audio_in_l  (AUDIO) — Linker Audio-Eingang (für Audio-Features)
        audio_in_r  (AUDIO) — Rechter Audio-Eingang
        shape       (CV)    — Form-ID 0..23 (Default 0 = Heart)
        density     (CV)    — Punkt-Density 0..1 (Default 0.7)
        rotation    (CV)    — Rotations-Geschwindigkeit -2..2 (Default 0.5)
        audio_react (CV)    — Audio-Reaktivität 0..1 (Default 0.6)
        palette     (CV)    — Color-Palette-ID 0..N (Default 0)
    Outputs:
        audio_out_l (AUDIO) — Pass-Through L
        audio_out_r (AUDIO) — Pass-Through R

    Default-Form: Heart ❤. Default-Body-Höhe: 200 px (vs. ~120 für Standard-
    Module) — die Form braucht sichtbaren Platz.
    """
    return Module(
        god="Saga",
        kind="Magic",
        params={
            "shape":          float(DEFAULT_SHAPE_ID),  # 0 = Heart
            "density":        0.7,
            "rotation_speed": 0.5,
            "audio_react":    0.6,
            "palette":        0.0,
        },
        inputs=[
            Port(
                "audio_in_l", PortKind.AUDIO, PortDirection.INPUT,
                "L In",
            ),
            Port(
                "audio_in_r", PortKind.AUDIO, PortDirection.INPUT,
                "R In",
            ),
            Port(
                "shape", PortKind.CV, PortDirection.INPUT, "Shape",
                default=float(DEFAULT_SHAPE_ID),
                minimum=0.0, maximum=23.0,
            ),
            Port(
                "density", PortKind.CV, PortDirection.INPUT, "Density",
                default=0.7, minimum=0.0, maximum=1.0,
            ),
            Port(
                "rotation_speed", PortKind.CV, PortDirection.INPUT, "Rotation",
                default=0.5, minimum=-2.0, maximum=2.0,
            ),
            Port(
                "audio_react", PortKind.CV, PortDirection.INPUT, "Audio React",
                default=0.6, minimum=0.0, maximum=1.0,
            ),
            Port(
                "palette", PortKind.CV, PortDirection.INPUT, "Palette",
                default=0.0, minimum=0.0, maximum=8.0,
            ),
        ],
        outputs=[
            Port(
                "audio_out_l", PortKind.AUDIO, PortDirection.OUTPUT,
                "L Out",
            ),
            Port(
                "audio_out_r", PortKind.AUDIO, PortDirection.OUTPUT,
                "R Out",
            ),
        ],
    )


# Liste der Modul-Kinds die im flux_rust_sync ausgefiltert werden
# müssen weil sie KEIN Rust-DSP-Pendant haben (S-0 Saga.Magic).
# In S-1+ wenn die Rust-Engine die Saga-Module kennt, kann diese Liste
# wieder schrumpfen.
SAGA_PYTHON_ONLY_KINDS: set[tuple[str, str]] = {
    ("Saga", "Magic"),
}


def is_saga_python_only(god: str, kind: str) -> bool:
    """True wenn das Modul keinen Rust-DSP hat und vom Sync ausgeschlossen
    werden muss. Aktuell nur Saga.Magic in S-0.
    """
    return (god, kind) in SAGA_PYTHON_ONLY_KINDS


__all__ = [
    "make_saga_magic",
    "SAGA_MAGIC_BODY_HEIGHT",
    "SAGA_PYTHON_ONLY_KINDS",
    "is_saga_python_only",
]
