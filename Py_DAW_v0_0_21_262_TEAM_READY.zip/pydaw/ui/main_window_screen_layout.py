"""Screen Layout Mixin — Extracted from main_window.py (v0.0.20.816).

Contains screen layout management: init, populate menu, apply preset,
panel detach/dock.

Self-contained via self: references docks, panels, and the ScreenLayoutManager.

~248 lines extracted.
"""

from __future__ import annotations

import logging

from .screen_layout import ScreenLayoutManager, PanelId, LAYOUT_PRESETS

log = logging.getLogger(__name__)


class ScreenLayoutMixin:
    """Screen layout management — mixed into MainWindow."""

    def _init_screen_layout_manager(self) -> None:
        """Initialize the Bitwig-style multi-monitor layout system (v0.0.20.444).

        Registers all detachable panels and populates the Ansicht → Bildschirm-Layout menu.
        """
        self._screen_layout_mgr = ScreenLayoutManager(self)

        # --- Register panels ---
        # Each panel needs a restore callback that puts the widget back
        # in its original dock position when re-docked.

        # Editor panel
        editor_widget = self.editor_tabs
        editor_dock = self.editor_dock

        def _restore_editor(w):
            try:
                editor_dock.setWidget(w)
            except Exception:
                pass

        self._screen_layout_mgr.register_panel(
            PanelId.EDITOR, "Editor", editor_widget,
            dock_parent=editor_dock,
            dock_restore_cb=_restore_editor,
        )

        # Mixer panel
        mixer_widget = self.mixer
        mixer_dock = self.mixer_dock

        def _restore_mixer(w):
            try:
                mixer_dock.setWidget(w)
            except Exception:
                pass

        self._screen_layout_mgr.register_panel(
            PanelId.MIXER, "Mixer", mixer_widget,
            dock_parent=mixer_dock,
            dock_restore_cb=_restore_mixer,
        )

        # Device panel
        device_widget = self.device_panel
        device_dock = self.device_dock

        def _restore_device(w):
            try:
                device_dock.setWidget(w)
            except Exception:
                pass

        self._screen_layout_mgr.register_panel(
            PanelId.DEVICE, "Device", device_widget,
            dock_parent=device_dock,
            dock_restore_cb=_restore_device,
        )

        # Browser panel (right dock)
        browser_tabs = getattr(self, '_right_tabs', None)
        browser_dock = self.browser_dock
        if browser_tabs is not None:
            def _restore_browser(w):
                try:
                    browser_dock.setWidget(w)
                except Exception:
                    pass

            self._screen_layout_mgr.register_panel(
                PanelId.BROWSER, "Browser", browser_tabs,
                dock_parent=browser_dock,
                dock_restore_cb=_restore_browser,
            )

        # v0.0.20.624: Clip Launcher panel (right dock, tabified with Browser)
        launcher_widget = self.launcher_panel
        launcher_dock = self.launcher_dock

        def _restore_launcher(w):
            try:
                launcher_dock.setWidget(w)
            except Exception:
                pass

        self._screen_layout_mgr.register_panel(
            PanelId.CLIP_LAUNCHER, "Clip Launcher", launcher_widget,
            dock_parent=launcher_dock,
            dock_restore_cb=_restore_launcher,
        )

        # Automation panel (inside the arranger's vertical splitter)
        auto_widget = getattr(self.arranger, '_enhanced_automation', None)
        if auto_widget is None:
            auto_widget = self.automation
        _auto_splitter = auto_widget.parentWidget() if auto_widget else None
        _auto_splitter_idx = -1
        if _auto_splitter and hasattr(_auto_splitter, 'indexOf'):
            try:
                _auto_splitter_idx = _auto_splitter.indexOf(auto_widget)
            except Exception:
                _auto_splitter_idx = -1

        def _restore_automation(w):
            try:
                if _auto_splitter is not None and hasattr(_auto_splitter, 'insertWidget') and _auto_splitter_idx >= 0:
                    _auto_splitter.insertWidget(_auto_splitter_idx, w)
                elif _auto_splitter is not None and hasattr(_auto_splitter, 'addWidget'):
                    _auto_splitter.addWidget(w)
            except Exception:
                pass

        if auto_widget is not None:
            self._screen_layout_mgr.register_panel(
                PanelId.AUTOMATION, "Automation", auto_widget,
                dock_parent=_auto_splitter,
                dock_restore_cb=_restore_automation,
            )

        # --- Populate the menu ---
        self._populate_screen_layout_menu()

        # v0.0.20.534: Keyboard shortcuts for layout presets (Ctrl+Alt+1..8)
        try:
            _preset_keys = [p.key for p in LAYOUT_PRESETS]
            for i, pkey in enumerate(_preset_keys[:8]):
                sc = QShortcut(QKeySequence(f"Ctrl+Alt+{i + 1}"), self)
                sc.activated.connect(lambda _k=pkey: self._safe_call(self._apply_screen_layout, _k))
                # Keep reference alive
                setattr(self, f"_layout_shortcut_{i}", sc)
        except Exception:
            pass

    def _populate_screen_layout_menu(self) -> None:
        """Build the Ansicht → Bildschirm-Layout submenu.

        Groups presets by screen count. Shows which presets are available
        based on the number of connected monitors.
        """
        menu = getattr(self, '_screen_layout_menu', None)
        if menu is None:
            return

        menu.clear()

        mgr = getattr(self, '_screen_layout_mgr', None)
        if mgr is None:
            menu.addAction("(Layout-System nicht verfügbar)")
            return

        n_screens = mgr.available_screens()

        # Info header
        act_info = menu.addAction(f"Bildschirme erkannt: {n_screens}")
        act_info.setEnabled(False)
        menu.addSeparator()

        # Group presets by min_screens
        groups: dict[str, list] = {}
        for preset in LAYOUT_PRESETS:
            if preset.min_screens == 1 and preset.max_screens == 1:
                grp = "1_only"
            elif preset.min_screens == 1:
                grp = "1"
            elif preset.min_screens == 2:
                grp = "2"
            elif preset.min_screens == 3:
                grp = "3"
            else:
                grp = "other"
            groups.setdefault(grp, []).append(preset)

        # 1 Monitor
        for grp_key, grp_label in [("1", "Ein Bildschirm"), ("1_only", None), ("2", "Zwei Bildschirme"), ("3", "Drei Bildschirme")]:
            presets = groups.get(grp_key, [])
            if not presets:
                continue
            if grp_label:
                menu.addSeparator()
            for preset in presets:
                available = (preset.min_screens <= n_screens)
                # v0.0.20.534: Show keyboard shortcut hint
                _all_keys = [p.key for p in LAYOUT_PRESETS]
                _idx = _all_keys.index(preset.key) if preset.key in _all_keys else -1
                _sc_hint = f"  (Ctrl+Alt+{_idx + 1})" if 0 <= _idx < 8 else ""
                act = menu.addAction(f"{preset.label}{_sc_hint}")
                act.setEnabled(available)
                act.setToolTip(f"{preset.description}{_sc_hint}")
                if not available:
                    act.setText(f"{preset.label}  (benötigt {preset.min_screens} Monitore)")
                # Checkmark for active preset
                if mgr.active_preset_key == preset.key:
                    act.setCheckable(True)
                    act.setChecked(True)
                # Connect
                key = preset.key
                act.triggered.connect(lambda _=False, k=key: self._safe_call(self._apply_screen_layout, k))

        # Separator + detach toggles for individual panels
        menu.addSeparator()
        detach_menu = menu.addMenu("Panel abkoppeln…")
        for pid, dp in mgr.panels.items():
            act = detach_menu.addAction(f"{'✓ ' if dp.is_detached else ''}{dp.title}")
            act.setCheckable(True)
            act.setChecked(dp.is_detached)
            _pid = pid
            act.triggered.connect(lambda _=False, p=_pid: self._safe_call(self._toggle_panel_detach, p))

        # Dock all
        menu.addSeparator()
        act_dock_all = menu.addAction("Alle Panels andocken")
        act_dock_all.triggered.connect(lambda _=False: self._safe_call(self._dock_all_panels))

    def _apply_screen_layout(self, preset_key: str) -> None:
        """Apply a screen layout preset."""
        mgr = getattr(self, '_screen_layout_mgr', None)
        if mgr is None:
            return
        ok = mgr.apply_preset(preset_key)
        if ok:
            self._set_status(f"Layout angewendet: {preset_key}", 2500)
            # Re-populate menu to update checkmarks
            self._populate_screen_layout_menu()
        else:
            self._set_status(f"Layout '{preset_key}' konnte nicht angewendet werden.", 3000)

    def _toggle_panel_detach(self, panel_id: PanelId) -> None:
        """Toggle detach for a single panel."""
        mgr = getattr(self, '_screen_layout_mgr', None)
        if mgr is None:
            return
        dp = mgr.get_panel(panel_id)
        if dp is None:
            return
        dp.toggle()
        self._populate_screen_layout_menu()
        state = "abgekoppelt" if dp.is_detached else "angedockt"
        self._set_status(f"{dp.title}: {state}", 1800)

    def _dock_all_panels(self) -> None:
        """Re-dock all floating panels."""
        mgr = getattr(self, '_screen_layout_mgr', None)
        if mgr is None:
            return
        mgr.dock_all()
        self._populate_screen_layout_menu()
        self._set_status("Alle Panels angedockt.", 1800)

