"""
pydaw.flux.ui_widgets.rune_toggle — Frigg.RuneToggle (Phase W-1)
================================================================

**Eingebaut in v0.0.21.197** als Norse-Sigil-Replacement für den
klassischen ``ToggleWidget`` (v.195). Spezifikation:
``PROJECT_DOCS/FLUX_GROVE_MANIFEST.md`` Sektion „FLUX Sigil — eigene
Widget-Designs", Punkt 3.

Design (aus dem Manifest)
-------------------------

* Rune (z.B. ᚠ für Frigg, ᚦ für Thor, ᛟ für Odin) je nach Kontext
* Im OFF-Zustand: matt graviert
* Im ON-Zustand: glüht in Cyan, mit sanfter Glow-Pulsation
* Beim Klick: kurzer Spark-Burst an den Rune-Ecken

Animation: **Rune-Glow** — Idle-Loop wenn aktiv, sanftes In/Out 800 ms.
Beim Klick zusätzlich kurzer **Spark-Burst** (4 kleine Funken-Punkte).

Welche Rune?
------------

Die zu zeigende Rune wird per ``rune`` Parameter gesetzt. Default:
``ᚠ`` (Fehu — Reichtum, Frigg-Symbol). Andere passende Norse-Runen:

* ᚦ (Thurisaz)  — Thor (Donner)
* ᛟ (Othala)    — Odin (Heim/Erbe)
* ᛟ ᛚ (Laguz)   — Wasser/Iduna
* ᛉ (Algiz)     — Schutz/Heimdall
* ᛒ (Berkano)   — Birke/Frigg
* ᛏ (Tiwaz)     — Tyr
* ᛚ (Laguz)     — Wasser/Njord

Standard ist ᚠ — universal.

Nichts-Kaputt-Garantie
----------------------

* Identischer Signal-Vertrag wie ``ToggleWidget``: ``value_changed(float)``
* Reine Python-Schicht
* Defensiv gegen fehlendes Qt
"""

from __future__ import annotations

import logging
import math
import random
from typing import Optional

logger = logging.getLogger(__name__)


try:
    from PyQt6.QtCore import Qt, QPointF, QRectF, QSize, pyqtSignal
    from PyQt6.QtGui import QColor, QPainter, QPen, QBrush, QFont
    from PyQt6.QtWidgets import QWidget, QSizePolicy
    _QT_AVAILABLE = True
except ImportError:
    _QT_AVAILABLE = False


from pydaw.flux.animation_engine import (
    get_animation_engine, ANIM_RUNE_GLOW, ANIM_SPARK_BURST,
)


# Default-Rune: Fehu (ᚠ) — Frigg-Symbol
DEFAULT_RUNE = "ᚠ"


if _QT_AVAILABLE:

    class RuneToggleWidget(QWidget):  # type: ignore[misc]
        """Sigil-Toggle: glühende Rune wenn aktiv.

        Signal-Vertrag (identisch zu ToggleWidget):
        ``value_changed(float)`` — feuert beim Klick mit 0.0/1.0
        ``set_value(v, *, emit_signal=...)``
        Felder: ``_minimum=0``, ``_maximum=1``, ``_default=0`` für API-Konsistenz
        """

        DEFAULT_SIZE = 40

        # Farben
        COL_BG          = "#0a0e14"
        COL_BORDER_OFF  = "#1a1f29"
        COL_BORDER_ON   = "#3df0e0"
        COL_RUNE_OFF    = "#3a4452"      # matt-graviert
        COL_RUNE_ON     = "#3df0e0"      # cyan-glow
        COL_GLOW        = "#3df0e0"
        COL_SPARK       = "#fbbf24"      # gold-Spark beim Klick

        value_changed = pyqtSignal(float)

        def __init__(
            self,
            value: float = 0.0,
            rune: str = DEFAULT_RUNE,
            module_id: str = "",
            parent=None,
        ):
            super().__init__(parent)
            self._value = 1.0 if float(value) >= 0.5 else 0.0
            self._rune = str(rune) if rune else DEFAULT_RUNE
            self._module_id = str(module_id) or f"rune_{id(self):x}"

            # Auto-Range-Adapter compat
            self._minimum = 0.0
            self._maximum = 1.0
            self._default = 0.0

            # Animation-State
            self._glow_phase = 0.0       # 0..1 (Idle-Loop wenn ON)
            self._spark_phase = 0.0      # 0..1 (One-Shot beim Klick)
            # 4 Spark-Positionen am Rand der Rune (wird bei _trigger_spark
            # neu randomisiert)
            self._spark_offsets: list[tuple[float, float]] = []

            size = self.DEFAULT_SIZE
            self.setMinimumSize(size, size)
            self.setMaximumSize(size + 4, size + 4)
            self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
            self.setToolTip(self._tooltip())

            # Wenn der Initialwert ON ist, sofort die Glow-Loop starten
            if self._value >= 0.5:
                self._start_glow_loop()

        # ─── Public API ────────────────────────────────────────────

        @property
        def value(self) -> float:
            return self._value

        def set_value(self, value: float, *, emit_signal: bool = True) -> None:
            new_v = 1.0 if float(value) >= 0.5 else 0.0
            if new_v == self._value:
                return
            self._value = new_v
            if emit_signal:
                self.value_changed.emit(self._value)
            # Glow-Loop an oder aus, je nach neuem Wert
            if self._value >= 0.5:
                self._start_glow_loop()
            else:
                self._stop_glow_loop()
            self.setToolTip(self._tooltip())
            self.update()

        def toggle(self) -> None:
            new_val = 1.0 - self._value
            self.set_value(new_val, emit_signal=True)
            # Bei jedem Klick (an oder aus) ein Spark-Burst
            self._trigger_spark_burst()

        def closeEvent(self, event):  # type: ignore[override]
            try:
                eng = get_animation_engine()
                eng.unsubscribe_prefix(f"{self._module_id}::")
            except Exception:
                pass
            super().closeEvent(event)

        # ─── Animation-Trigger ─────────────────────────────────────

        def _start_glow_loop(self) -> None:
            eng = get_animation_engine()
            sub_id = f"{self._module_id}::glow"
            eng.subscribe(
                sub_id, ANIM_RUNE_GLOW,
                self._on_glow_frame,
                duration_ms=800,
            )

        def _stop_glow_loop(self) -> None:
            eng = get_animation_engine()
            eng.unsubscribe(f"{self._module_id}::glow")
            self._glow_phase = 0.0
            self.update()

        def _trigger_spark_burst(self) -> None:
            """4 Spark-Funken an den Ecken der Rune."""
            # Ecken-Positionen randomisieren um „organisch" zu wirken
            self._spark_offsets = [
                (
                    random.uniform(-0.4, 0.4),
                    random.uniform(-0.4, 0.4),
                )
                for _ in range(4)
            ]
            eng = get_animation_engine()
            sub_id = f"{self._module_id}::spark"
            eng.subscribe(
                sub_id, ANIM_SPARK_BURST,
                self._on_spark_frame,
                duration_ms=600,
            )

        def _on_glow_frame(self, phase: float, frame: int) -> None:
            self._glow_phase = float(phase)
            self.update()

        def _on_spark_frame(self, phase: float, frame: int) -> None:
            self._spark_phase = float(phase)
            if phase >= 1.0:
                self._spark_phase = 0.0
            self.update()

        # ─── Mouse ─────────────────────────────────────────────────

        def mousePressEvent(self, event):  # type: ignore[override]
            if event.button() == Qt.MouseButton.LeftButton:
                self.toggle()
                event.accept()
            else:
                super().mousePressEvent(event)

        # ─── Painting ──────────────────────────────────────────────

        def paintEvent(self, event):  # type: ignore[override]
            painter = QPainter(self)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            painter.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)

            w = self.width()
            h = self.height()
            size = min(w, h) - 4
            x0 = (w - size) / 2
            y0 = (h - size) / 2
            rect = QRectF(x0, y0, size, size)

            # 1) Hintergrund + Border
            painter.setBrush(QBrush(QColor(self.COL_BG)))
            border_color = (
                self.COL_BORDER_ON if self._value > 0.5 else self.COL_BORDER_OFF
            )
            border_pen = QPen(QColor(border_color), 1.5)
            # Bei aktivem Glow: Border-Helligkeit pulsiert mit der Phase
            if self._value > 0.5 and self._glow_phase > 0:
                glow_alpha = int(120 + 100 * self._glow_phase)
                glow_col = QColor(border_color)
                glow_col.setAlpha(glow_alpha)
                border_pen = QPen(glow_col, 1.8)
            painter.setPen(border_pen)
            painter.drawRoundedRect(rect, 3.0, 3.0)

            # 2) Glow-Halo (nur wenn ON) — als Brush-Layer hinter der Rune
            if self._value > 0.5:
                halo_alpha = int(40 + 60 * self._glow_phase)
                halo = QColor(self.COL_GLOW)
                halo.setAlpha(halo_alpha)
                halo_rect = rect.adjusted(2, 2, -2, -2)
                painter.setBrush(QBrush(halo))
                painter.setPen(Qt.PenStyle.NoPen)
                painter.drawRoundedRect(halo_rect, 4.0, 4.0)

            # 3) Rune-Glyph (zentriert)
            font = QFont("Noto Sans Runic", int(size * 0.55))
            # Falls die Rune-Font fehlt, fällt Qt automatisch auf die
            # System-Fallback-Font zurück. Den Glyph kann Qt auch in
            # generischer Sans-Serif zeichnen (Unicode-Block U+16A0..U+16F8).
            font.setBold(True)
            painter.setFont(font)
            rune_color = (
                self.COL_RUNE_ON if self._value > 0.5 else self.COL_RUNE_OFF
            )
            # Bei aktivem Glow: Rune-Helligkeit moduliert mit Phase
            if self._value > 0.5 and self._glow_phase > 0:
                bell = 0.5 + 0.5 * self._glow_phase   # 0.5..1.0
                col = QColor(rune_color)
                # Lighter zwischen 100..150
                col = col.lighter(int(100 + 50 * bell))
                painter.setPen(col)
            else:
                painter.setPen(QColor(rune_color))
            painter.drawText(rect, int(Qt.AlignmentFlag.AlignCenter), self._rune)

            # 4) Spark-Burst (One-Shot — 4 Funken an Ecken)
            if self._spark_phase > 0.0 and self._spark_offsets:
                # Funken laufen auswärts vom Zentrum
                cx = rect.center().x()
                cy = rect.center().y()
                radius = size * (0.45 + 0.35 * self._spark_phase)
                spark_alpha = int((1.0 - self._spark_phase) * 220)
                spark_color = QColor(self.COL_SPARK)
                spark_color.setAlpha(spark_alpha)
                spark_pen = QPen(spark_color)
                spark_pen.setWidthF(1.0 + (1.0 - self._spark_phase))
                painter.setPen(spark_pen)
                painter.setBrush(QBrush(spark_color))
                for ox, oy in self._spark_offsets:
                    sx = cx + radius * (math.cos(math.atan2(oy, ox))) + ox * 4
                    sy = cy + radius * (math.sin(math.atan2(oy, ox))) + oy * 4
                    painter.drawEllipse(QPointF(sx, sy), 1.5, 1.5)

            painter.end()

        # ─── Tooltip ───────────────────────────────────────────────

        def _tooltip(self) -> str:
            state = "ON" if self._value > 0.5 else "OFF"
            return (
                f"<b>RuneToggle</b> ({self._rune}): {state}<br>"
                "<span style='color:#8b949e;'>Klick = umschalten</span>"
            )

        def sizeHint(self):  # type: ignore[override]
            return QSize(self.DEFAULT_SIZE, self.DEFAULT_SIZE)

else:
    RuneToggleWidget = None  # type: ignore[assignment,misc]


__all__ = ["RuneToggleWidget", "DEFAULT_RUNE"]
