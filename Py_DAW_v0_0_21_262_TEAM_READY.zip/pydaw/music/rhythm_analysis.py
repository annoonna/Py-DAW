"""Rhythm Analysis Engine (P2B + P2E) — Offline groove/rhythm analysis.

Pure Python, no ML dependencies. Works on MIDI notes directly.

Features:
- Groove extraction: timing deviations, velocity patterns
- Pattern recognition: detect repetition, symmetry
- Rhythmic complexity scoring
- Genre classification (heuristic)
- Groove template extraction for re-use

v0.0.20.807 — Phase P2B/P2E
"""

from __future__ import annotations

import logging
import math
from collections import Counter
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Tuple, Any

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class RhythmReport:
    """Complete rhythmic analysis of a MIDI pattern."""
    density: float = 0.0              # notes per beat
    complexity: float = 0.0           # 0..1 (syncopation + variety)
    syncopation: float = 0.0          # 0..1 (off-beat activity)
    swing_amount: float = 0.0         # 0..1 detected swing
    velocity_range: float = 0.0       # dynamic range 0..1
    velocity_mean: float = 0.0        # average velocity 0..127
    pattern_length_beats: float = 0.0 # detected loop length
    is_straight: bool = True          # True if mostly on-grid
    is_swung: bool = False            # True if swing detected
    dominant_subdivision: str = "8th" # "4th" | "8th" | "16th" | "32nd" | "triplet"
    genre_hints: List[str] = field(default_factory=list)
    groove_template: List[Dict[str, float]] = field(default_factory=list)
    description: str = ""
    histogram_16th: List[int] = field(default_factory=list)  # 16 slots per bar

    def to_dict(self) -> dict:
        return {
            "density": round(self.density, 3),
            "complexity": round(self.complexity, 3),
            "syncopation": round(self.syncopation, 3),
            "swing_amount": round(self.swing_amount, 3),
            "velocity_range": round(self.velocity_range, 3),
            "velocity_mean": round(self.velocity_mean, 1),
            "pattern_length_beats": self.pattern_length_beats,
            "is_straight": self.is_straight,
            "is_swung": self.is_swung,
            "dominant_subdivision": self.dominant_subdivision,
            "genre_hints": self.genre_hints,
            "groove_template": self.groove_template,
            "description": self.description,
            "histogram_16th": self.histogram_16th,
        }


@dataclass
class GrooveTemplate:
    """Extracted groove timing+velocity template for re-application."""
    name: str = ""
    steps: int = 16
    timing_offsets: List[float] = field(default_factory=list)   # beats offset per step
    velocity_factors: List[float] = field(default_factory=list)  # 0..1 per step
    length_factors: List[float] = field(default_factory=list)    # duration factor per step

    def to_dict(self) -> dict:
        return {
            "name": self.name, "steps": self.steps,
            "timing_offsets": [round(t, 4) for t in self.timing_offsets],
            "velocity_factors": [round(v, 3) for v in self.velocity_factors],
            "length_factors": [round(l, 3) for l in self.length_factors],
        }

    @classmethod
    def from_dict(cls, d: dict) -> "GrooveTemplate":
        try:
            return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})
        except Exception:
            return cls()


# ---------------------------------------------------------------------------
# Analysis functions
# ---------------------------------------------------------------------------

def _get_note_starts(notes: List[Dict[str, Any]]) -> List[Tuple[float, int, float]]:
    """Extract (start_beats, pitch, velocity) from notes."""
    result = []
    for n in notes:
        try:
            s = float(n.get("start", 0) if isinstance(n, dict) else getattr(n, "start_beats", 0))
            p = int(n.get("pitch", 0) if isinstance(n, dict) else getattr(n, "pitch", 0))
            v = float(n.get("velocity", 100) if isinstance(n, dict) else getattr(n, "velocity", 100))
            result.append((s, p, v))
        except Exception:
            continue
    return sorted(result, key=lambda x: x[0])


def _total_beats(notes: List[Dict[str, Any]]) -> float:
    """Get total duration of note sequence in beats."""
    max_end = 0.0
    for n in notes:
        try:
            s = float(n.get("start", 0) if isinstance(n, dict) else getattr(n, "start_beats", 0))
            d = float(n.get("duration", 1) if isinstance(n, dict) else getattr(n, "duration", 1))
            max_end = max(max_end, s + d)
        except Exception:
            continue
    return max(max_end, 0.25)


def _detect_swing(starts: List[float], grid: float = 0.25) -> float:
    """Detect swing amount from note start positions.

    Returns 0..1 (0 = straight, 0.5 = triplet swing).
    """
    if not starts or grid <= 0:
        return 0.0

    # Look at pairs of consecutive grid positions
    # Swing = even 16ths are on-grid, odd 16ths are late
    offsets_even = []
    offsets_odd = []

    for start in starts:
        grid_pos = start / grid
        nearest_grid = round(grid_pos)
        offset = (grid_pos - nearest_grid) * grid  # in beats

        if int(nearest_grid) % 2 == 0:
            offsets_even.append(abs(offset))
        else:
            offsets_odd.append(offset)  # keep sign for swing direction

    if not offsets_odd or not offsets_even:
        return 0.0

    # Average positive offset on odd positions = swing amount
    avg_odd = sum(offsets_odd) / len(offsets_odd)
    swing = max(0.0, min(1.0, avg_odd / (grid * 0.5)))

    return swing


def _detect_syncopation(starts: List[float], beats_per_bar: float = 4.0) -> float:
    """Calculate syncopation score (0..1).

    Syncopation = proportion of notes on weak beats/off-beats.
    """
    if not starts:
        return 0.0

    strong_beats = {0.0, beats_per_bar / 2}  # beat 1 and 3 in 4/4
    medium_beats = {1.0, 3.0}  # beat 2 and 4

    total = len(starts)
    on_strong = 0
    on_medium = 0
    off_beat = 0

    for s in starts:
        pos_in_bar = s % beats_per_bar
        # Check with tolerance
        is_strong = any(abs(pos_in_bar - b) < 0.06 for b in strong_beats)
        is_medium = any(abs(pos_in_bar - b) < 0.06 for b in medium_beats)

        if is_strong:
            on_strong += 1
        elif is_medium:
            on_medium += 1
        else:
            off_beat += 1

    # More off-beat → higher syncopation
    return min(1.0, off_beat / total) if total > 0 else 0.0


def _build_16th_histogram(starts: List[float], total_beats: float,
                          beats_per_bar: float = 4.0) -> List[int]:
    """Build a 16th-note histogram per bar (16 slots)."""
    histogram = [0] * 16
    grid = beats_per_bar / 16  # 0.25 beats per 16th

    for s in starts:
        pos_in_bar = s % beats_per_bar
        slot = int(round(pos_in_bar / grid)) % 16
        histogram[slot] += 1

    return histogram


def _detect_dominant_subdivision(starts: List[float]) -> str:
    """Detect the most common rhythmic subdivision."""
    if not starts or len(starts) < 2:
        return "4th"

    # Compute inter-onset intervals
    iois = []
    for i in range(1, len(starts)):
        ioi = starts[i] - starts[i - 1]
        if ioi > 0.01:
            iois.append(ioi)

    if not iois:
        return "4th"

    # Average IOI
    avg_ioi = sum(iois) / len(iois)

    # Map to subdivision
    if avg_ioi > 0.9:
        return "4th"
    elif avg_ioi > 0.4:
        return "8th"
    elif avg_ioi > 0.2:
        return "16th"
    elif avg_ioi > 0.1:
        return "32nd"
    else:
        return "32nd"

    # Check for triplet feel
    triplet_grid = 1.0 / 3.0
    triplet_count = sum(1 for ioi in iois if abs(ioi - triplet_grid) < 0.05 or abs(ioi - triplet_grid * 2) < 0.05)
    if triplet_count > len(iois) * 0.3:
        return "triplet"

    return "16th"


def _classify_genre(
    density: float,
    syncopation: float,
    swing: float,
    subdivision: str,
    velocity_range: float,
) -> List[str]:
    """Heuristic genre hints based on rhythmic features."""
    hints = []

    # High density + straight + 16th = EDM/Techno
    if density > 4.0 and syncopation < 0.3 and swing < 0.1:
        hints.append("Techno/EDM")

    # Moderate density + swing = Jazz/Funk
    if swing > 0.15:
        if density > 3.0:
            hints.append("Funk")
        else:
            hints.append("Jazz/Swing")

    # High syncopation + moderate density = Funk/Reggae
    if syncopation > 0.5 and density < 4.0:
        hints.append("Funk/Reggae")

    # Low density + straight = Ballad/Ambient
    if density < 1.5 and syncopation < 0.2:
        hints.append("Ballad/Ambient")

    # Medium density + moderate syncopation = Pop/Rock
    if 2.0 < density < 5.0 and 0.15 < syncopation < 0.5:
        hints.append("Pop/Rock")

    # High density + high syncopation = Breakbeat/D&B
    if density > 5.0 and syncopation > 0.4:
        hints.append("Breakbeat/D&B")

    # Triplet feel
    if subdivision == "triplet":
        hints.append("Triplet-Feel (Hip-Hop/Trap)")

    # Strong velocity dynamics = Live/Acoustic feel
    if velocity_range > 0.4:
        hints.append("Live/Akustisch")

    if not hints:
        hints.append("Gemischt")

    return hints[:3]


# ---------------------------------------------------------------------------
# Groove extraction
# ---------------------------------------------------------------------------

def extract_groove(
    notes: List[Dict[str, Any]],
    *,
    steps: int = 16,
    beats_per_bar: float = 4.0,
) -> GrooveTemplate:
    """Extract a groove template from MIDI notes.

    Analyzes timing deviations, velocity patterns, and note lengths
    per grid step to create a reusable groove template.
    """
    entries = _get_note_starts(notes)
    if not entries:
        return GrooveTemplate(steps=steps)

    grid = beats_per_bar / steps  # beat length per step

    # Collect per-step data
    step_timings: Dict[int, List[float]] = {i: [] for i in range(steps)}
    step_velocities: Dict[int, List[float]] = {i: [] for i in range(steps)}
    step_durations: Dict[int, List[float]] = {i: [] for i in range(steps)}

    for s, p, v in entries:
        pos_in_bar = s % beats_per_bar
        nearest_step = int(round(pos_in_bar / grid)) % steps
        timing_offset = pos_in_bar - nearest_step * grid
        step_timings[nearest_step].append(timing_offset)
        step_velocities[nearest_step].append(v / 127.0)

    # Also collect durations
    for n in notes:
        try:
            s = float(n.get("start", 0) if isinstance(n, dict) else getattr(n, "start_beats", 0))
            d = float(n.get("duration", 1) if isinstance(n, dict) else getattr(n, "duration", 1))
            pos_in_bar = s % beats_per_bar
            nearest_step = int(round(pos_in_bar / grid)) % steps
            step_durations[nearest_step].append(d / grid)  # normalized to grid
        except Exception:
            continue

    # Average per step
    timing_offsets = []
    velocity_factors = []
    length_factors = []

    for i in range(steps):
        if step_timings[i]:
            timing_offsets.append(sum(step_timings[i]) / len(step_timings[i]))
        else:
            timing_offsets.append(0.0)

        if step_velocities[i]:
            velocity_factors.append(sum(step_velocities[i]) / len(step_velocities[i]))
        else:
            velocity_factors.append(0.5)

        if step_durations[i]:
            length_factors.append(sum(step_durations[i]) / len(step_durations[i]))
        else:
            length_factors.append(1.0)

    return GrooveTemplate(
        name="Extracted",
        steps=steps,
        timing_offsets=timing_offsets,
        velocity_factors=velocity_factors,
        length_factors=length_factors,
    )


# ---------------------------------------------------------------------------
# Full analysis
# ---------------------------------------------------------------------------

def analyze_rhythm(
    notes: List[Dict[str, Any]],
    *,
    beats_per_bar: float = 4.0,
) -> RhythmReport:
    """Complete rhythmic analysis of MIDI notes."""
    if not notes:
        return RhythmReport(description="Keine Noten für Analyse.")

    entries = _get_note_starts(notes)
    if not entries:
        return RhythmReport(description="Keine Noten für Analyse.")

    starts = [s for s, p, v in entries]
    velocities = [v for s, p, v in entries]
    total = _total_beats(notes)

    # Basic metrics
    density = len(entries) / max(0.25, total)
    vel_min = min(velocities) if velocities else 0
    vel_max = max(velocities) if velocities else 0
    vel_range = (vel_max - vel_min) / 127.0 if velocities else 0
    vel_mean = sum(velocities) / len(velocities) if velocities else 0

    # Advanced metrics
    swing = _detect_swing(starts)
    syncopation = _detect_syncopation(starts, beats_per_bar)
    subdivision = _detect_dominant_subdivision(starts)
    histogram = _build_16th_histogram(starts, total, beats_per_bar)

    # Complexity: combination of syncopation, velocity variety, density
    complexity = min(1.0, syncopation * 0.4 + vel_range * 0.2 + min(1.0, density / 8.0) * 0.4)

    # Genre hints
    genre_hints = _classify_genre(density, syncopation, swing, subdivision, vel_range)

    # Detect pattern repetition (simple: check if first half ≈ second half)
    pattern_len = total
    if total >= 8:
        half = total / 2
        first_half = [s for s in starts if s < half]
        second_half = [s - half for s in starts if s >= half]
        if len(first_half) > 0 and len(second_half) > 0:
            if abs(len(first_half) - len(second_half)) <= 2:
                pattern_len = half

    # Extract groove
    groove = extract_groove(notes, beats_per_bar=beats_per_bar)

    # Build description
    desc_parts = []
    desc_parts.append(f"Dichte: {density:.1f} Noten/Beat")
    desc_parts.append(f"Subdivision: {subdivision}")
    if swing > 0.1:
        desc_parts.append(f"Swing: {swing:.0%}")
    else:
        desc_parts.append("Straight (kein Swing)")
    desc_parts.append(f"Synkopierung: {syncopation:.0%}")
    desc_parts.append(f"Dynamik: {vel_range:.0%} Range (Ø{vel_mean:.0f})")
    desc_parts.append(f"Komplexität: {complexity:.0%}")
    if genre_hints:
        desc_parts.append(f"Genre: {', '.join(genre_hints)}")

    return RhythmReport(
        density=density,
        complexity=complexity,
        syncopation=syncopation,
        swing_amount=swing,
        velocity_range=vel_range,
        velocity_mean=vel_mean,
        pattern_length_beats=pattern_len,
        is_straight=swing < 0.1,
        is_swung=swing >= 0.1,
        dominant_subdivision=subdivision,
        genre_hints=genre_hints,
        groove_template=groove.to_dict().get("timing_offsets", []),
        description=". ".join(desc_parts),
        histogram_16th=histogram,
    )
