"""
pydaw.flux.ui_widgets
=====================

PureData-/Max-for-Live-/Bitwig-Style Control-Widgets für FLUX.

Diese Widgets erscheinen im FLUX-Canvas als Frigg.*-Module
(siehe `module_library.py`) und können wie alle anderen Module über
Patch-Cords mit DSP-Modulen verbunden werden. Die `UiModuleBridge`
(`pydaw.services.ui_module_bridge`) übersetzt Wert-Änderungen in
Param-Updates an verbundene Ziel-Module.

**v0.0.21.194** — Phase U-1: AnimatedKnob (PD-Style, Lerp-Animation)
**v0.0.21.195** — Phase U-2/U-3: Toggle, Bang, Slider (V/H), NumberBox, Comment
**v0.0.21.197** — Phase W-1: FLUX-Sigil-Widgets (Norse-Designs)
                    PulseRing, AuroraSlider, RuneToggle, SparkBang

Folge-Phasen U-4..U-6/W-2..W-4 erweitern um VU-Meter, Graph/Array, Radio,
Symbol, MessageBox, Cluster-Layout. Siehe
`PROJECT_DOCS/FLUX_UI_MODULES_ROADMAP.md` und
`PROJECT_DOCS/FLUX_GROVE_MANIFEST.md`.

Backward-Compat (Manifest-Pakt)
-------------------------------

Alle alten Frigg-Widgets (Knob, Slider, Toggle, Bang, NumberBox, Comment)
bleiben unter alten Namen funktional. Die neuen Sigil-Widgets
(PulseRing, AuroraSlider, RuneToggle, SparkBang) sind **eigenständige**
neue Modul-Kinds, keine Replacements. Existierende Patches laufen
unverändert weiter.
"""

from __future__ import annotations

# v.194 — U-1
from pydaw.flux.ui_widgets.knob import AnimatedKnob

# v.195 — U-2/U-3
from pydaw.flux.ui_widgets.toggle import ToggleWidget
from pydaw.flux.ui_widgets.bang import BangWidget
from pydaw.flux.ui_widgets.slider import SliderWidget
from pydaw.flux.ui_widgets.number_box import NumberBoxWidget
from pydaw.flux.ui_widgets.comment import CommentWidget

# v.197 — W-1: FLUX-Sigil-Widgets (Norse-Designs)
from pydaw.flux.ui_widgets.pulse_ring import PulseRingWidget
from pydaw.flux.ui_widgets.aurora_slider import AuroraSliderWidget
from pydaw.flux.ui_widgets.rune_toggle import RuneToggleWidget
from pydaw.flux.ui_widgets.spark_bang import SparkBangWidget

# v.200 — W-2: FLUX-Sigil-Display-Widgets
from pydaw.flux.ui_widgets.volva_number import VolvaNumberWidget
from pydaw.flux.ui_widgets.bauta_stone import BautaStoneWidget
from pydaw.flux.ui_widgets.mani_meter import ManiMeterWidget

# v.231 — Live-Probe für CV/RUNE-Werte (Anno's „number modul mit ein und ausgängen")
from pydaw.flux.ui_widgets.number_flow import NumberFlowWidget

__all__ = [
    # v.194/195 — Klassiker
    "AnimatedKnob",
    "ToggleWidget",
    "BangWidget",
    "SliderWidget",
    "NumberBoxWidget",
    "CommentWidget",
    # v.197 — W-1 Sigil
    "PulseRingWidget",
    "AuroraSliderWidget",
    "RuneToggleWidget",
    "SparkBangWidget",
    # v.200 — W-2 Display-Sigil
    "VolvaNumberWidget",
    "BautaStoneWidget",
    "ManiMeterWidget",
    # v.231 — Live-Probe
    "NumberFlowWidget",
]
