"""Audio-State-Diagnostics service module — shared logic for CLI and UI.

v0.0.21.237: Extracted from audio_state_diagnose.py / audio_state_reset.py
so that the same code path serves both:
  - CLI tools (audio_state_diagnose.py / audio_state_reset.py)
  - In-app dialog (pydaw/ui/audio_state_dialog.py)

Pure-Python, no Qt deps. Stateless functions return data; UI/CLI does
its own presentation.

Anno's Pattern: User-State-Drift — alte Code-Backup zeigt gleichen Audio-Bug
weil persistente DBs zwischen Versionen Werte > 1.0 ansammeln (MIDI-CCs,
OSC-Messages, Doppelklicks auf Fader). Diagnose findet das, Reset fixt es,
ohne Projekte/Presets zu zerstören.
"""
from __future__ import annotations

import shutil
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Tuple

# ── Paths ─────────────────────────────────────────────────────────────
DB_DIR = Path.home() / ".config" / "ChronoScaleStudio"
QSETTINGS_FILE = Path.home() / ".config" / "Py_DAW" / "ChronoScaleStudio.conf"
CACHE_DIR = Path.home() / ".cache" / "ChronoScaleStudio"
CRASH_DIR = Path.home() / ".pydaw" / "crash_logs"

DB_NAMES = ("pydaw.db", "preset_database.db", "param_registry.db")

# ── Policy constants ──────────────────────────────────────────────────
HOT_THRESHOLD = 1.5             # values above this are "hot" / suspect
SAFE_DEFAULT_VOL = 0.8          # what we reset hot values to (-1.9 dB)
AUDIO_KEYWORDS = ("volume", "vol", "gain", "level", "amp",
                  "master", "fader", "fx_")


@dataclass
class HotFinding:
    """A single suspect setting."""
    source: str              # "pydaw.db/tracks.volume" or "QSettings/master_vol"
    key: str                 # e.g. "master_volume" or "track_3.volume"
    value: float
    note: str = ""           # optional context

    def __str__(self) -> str:
        return f"{self.source}: {self.key} = {self.value:.3f}"


@dataclass
class DiagnosisResult:
    """Outcome of a full diagnose() pass."""
    findings: List[HotFinding] = field(default_factory=list)
    db_paths_found: List[Path] = field(default_factory=list)
    qsettings_present: bool = False
    qsettings_audio_keys: List[Tuple[str, str]] = field(default_factory=list)  # (key, value as-string)
    cache_size_mb: float = 0.0
    n_crash_logs: int = 0
    errors: List[str] = field(default_factory=list)

    @property
    def is_clean(self) -> bool:
        return len(self.findings) == 0

    @property
    def n_hot(self) -> int:
        return len(self.findings)


@dataclass
class ResetResult:
    """Outcome of a reset() pass."""
    n_changes: int = 0
    backups_made: List[Path] = field(default_factory=list)
    changes: List[str] = field(default_factory=list)   # human-readable change descriptions
    errors: List[str] = field(default_factory=list)


# ── Helpers ───────────────────────────────────────────────────────────

def _is_audio_column(col_name: str) -> bool:
    cl = col_name.lower()
    return any(k in cl for k in AUDIO_KEYWORDS)


def _try_float(v) -> Optional[float]:
    if v is None:
        return None
    try:
        return float(v)
    except (ValueError, TypeError):
        return None


# ── Diagnose ──────────────────────────────────────────────────────────

def diagnose() -> DiagnosisResult:
    """Read-only scan of all persistent settings. No side effects."""
    res = DiagnosisResult()

    # SQLite databases
    if DB_DIR.exists():
        for name in DB_NAMES:
            db_path = DB_DIR / name
            if not db_path.exists():
                continue
            res.db_paths_found.append(db_path)
            _diagnose_db(db_path, res)

    # QSettings INI file
    if QSETTINGS_FILE.exists():
        res.qsettings_present = True
        _diagnose_qsettings(res)

    # Caches and crashes (informational only)
    if CACHE_DIR.exists():
        try:
            res.cache_size_mb = sum(
                f.stat().st_size for f in CACHE_DIR.rglob("*") if f.is_file()
            ) / (1024 * 1024)
        except OSError:
            pass
    if CRASH_DIR.exists():
        try:
            res.n_crash_logs = len(list(CRASH_DIR.glob("*.log")))
        except OSError:
            pass

    return res


def _diagnose_db(db_path: Path, res: DiagnosisResult) -> None:
    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True, timeout=2.0)
    except sqlite3.Error as e:
        res.errors.append(f"open {db_path.name}: {e}")
        return
    try:
        cur = conn.cursor()
        cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [r[0] for r in cur.fetchall()]

        for tbl in tables:
            try:
                cur.execute(f"PRAGMA table_info({tbl})")
                cols = [(r[1], r[2]) for r in cur.fetchall()]
            except sqlite3.Error:
                continue

            col_names = [c[0] for c in cols]
            audio_cols = [(c, t) for c, t in cols if _is_audio_column(c)]

            # Column-based scan: numeric audio columns
            for col_name, col_type in audio_cols:
                try:
                    cur.execute(
                        f'SELECT "{col_name}" FROM "{tbl}" '
                        f'WHERE "{col_name}" IS NOT NULL LIMIT 100'
                    )
                    for (v,) in cur.fetchall():
                        fv = _try_float(v)
                        if fv is not None and abs(fv) > HOT_THRESHOLD:
                            res.findings.append(HotFinding(
                                source=f"{db_path.name}/{tbl}",
                                key=col_name,
                                value=fv,
                            ))
                except sqlite3.Error:
                    pass

            # Key/value pattern: settings tables
            if "key" in col_names and "value" in col_names:
                try:
                    cur.execute(
                        f'SELECT key, value FROM "{tbl}" '
                        f'WHERE LOWER(key) LIKE \'%vol%\' '
                        f'   OR LOWER(key) LIKE \'%gain%\' '
                        f'   OR LOWER(key) LIKE \'%master%\''
                    )
                    for k, v in cur.fetchall():
                        fv = _try_float(v)
                        if fv is not None and abs(fv) > HOT_THRESHOLD:
                            res.findings.append(HotFinding(
                                source=f"{db_path.name}/{tbl}",
                                key=str(k),
                                value=fv,
                            ))
                except sqlite3.Error:
                    pass
    finally:
        conn.close()


def _diagnose_qsettings(res: DiagnosisResult) -> None:
    try:
        with open(QSETTINGS_FILE, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                stripped = line.strip()
                if "=" not in stripped or stripped.startswith("["):
                    continue
                k, v = stripped.split("=", 1)
                kl = k.lower()
                if not any(t in kl for t in AUDIO_KEYWORDS):
                    continue
                res.qsettings_audio_keys.append((k.strip(), v.strip()))
                fv = _try_float(v.strip())
                if fv is not None and abs(fv) > HOT_THRESHOLD:
                    res.findings.append(HotFinding(
                        source="QSettings",
                        key=k.strip(),
                        value=fv,
                    ))
    except OSError as e:
        res.errors.append(f"read QSettings: {e}")


# ── Reset (soft: only hot values) ─────────────────────────────────────

def reset_hot_values(dry_run: bool = False) -> ResetResult:
    """Reset only values above HOT_THRESHOLD to SAFE_DEFAULT_VOL.

    Backs up DBs and QSettings before touching them. Projects/presets/
    clips/MIDI/audio files are NOT touched — only audio-level columns
    and key/value rows whose key contains an audio keyword.
    """
    res = ResetResult()

    if DB_DIR.exists():
        for name in DB_NAMES:
            db_path = DB_DIR / name
            if not db_path.exists():
                continue
            _reset_db(db_path, res, dry_run)

    if QSETTINGS_FILE.exists():
        _reset_qsettings(res, dry_run)

    return res


def _backup_file(path: Path, res: ResetResult) -> None:
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    bak = path.with_suffix(path.suffix + f".bak.{ts}")
    try:
        shutil.copy2(path, bak)
        res.backups_made.append(bak)
    except OSError as e:
        res.errors.append(f"backup {path.name}: {e}")


def _reset_db(db_path: Path, res: ResetResult, dry_run: bool) -> None:
    if not dry_run:
        _backup_file(db_path, res)

    try:
        conn = sqlite3.connect(db_path, timeout=5.0)
    except sqlite3.Error as e:
        res.errors.append(f"open {db_path.name}: {e}")
        return

    try:
        cur = conn.cursor()
        cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [r[0] for r in cur.fetchall()]

        for tbl in tables:
            try:
                cur.execute(f"PRAGMA table_info({tbl})")
                cols = [(r[1], r[2]) for r in cur.fetchall()]
            except sqlite3.Error:
                continue
            col_names = [c[0] for c in cols]

            # Numeric audio columns
            for col_name, _ in cols:
                if not _is_audio_column(col_name):
                    continue
                try:
                    cur.execute(
                        f'SELECT COUNT(*) FROM "{tbl}" WHERE "{col_name}" > ?',
                        (HOT_THRESHOLD,)
                    )
                    n_hot = cur.fetchone()[0]
                    if n_hot > 0:
                        res.changes.append(
                            f"{db_path.name}/{tbl}.{col_name}: "
                            f"{n_hot} value(s) > {HOT_THRESHOLD} → {SAFE_DEFAULT_VOL}"
                        )
                        if not dry_run:
                            cur.execute(
                                f'UPDATE "{tbl}" SET "{col_name}" = ? '
                                f'WHERE "{col_name}" > ?',
                                (SAFE_DEFAULT_VOL, HOT_THRESHOLD)
                            )
                        res.n_changes += n_hot
                except sqlite3.Error:
                    pass

            # Key/value pattern
            if "key" in col_names and "value" in col_names:
                try:
                    cur.execute(
                        f'SELECT key, value FROM "{tbl}" '
                        f'WHERE LOWER(key) LIKE \'%vol%\' '
                        f'   OR LOWER(key) LIKE \'%gain%\' '
                        f'   OR LOWER(key) LIKE \'%master%\''
                    )
                    for k, v in cur.fetchall():
                        fv = _try_float(v)
                        if fv is not None and abs(fv) > HOT_THRESHOLD:
                            res.changes.append(
                                f"{db_path.name}/{tbl}/key={k}: "
                                f"{fv:.3f} → {SAFE_DEFAULT_VOL}"
                            )
                            if not dry_run:
                                cur.execute(
                                    f'UPDATE "{tbl}" SET value = ? WHERE key = ?',
                                    (str(SAFE_DEFAULT_VOL), k)
                                )
                            res.n_changes += 1
                except sqlite3.Error:
                    pass

        if not dry_run:
            conn.commit()
    finally:
        conn.close()


def _reset_qsettings(res: ResetResult, dry_run: bool) -> None:
    if not dry_run:
        _backup_file(QSETTINGS_FILE, res)

    new_lines = []
    try:
        with open(QSETTINGS_FILE, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                stripped = line.strip()
                handled = False
                if "=" in stripped and not stripped.startswith("["):
                    k, v = stripped.split("=", 1)
                    kl = k.lower()
                    if any(t in kl for t in AUDIO_KEYWORDS):
                        fv = _try_float(v.strip())
                        if fv is not None and abs(fv) > HOT_THRESHOLD:
                            res.changes.append(
                                f"QSettings/{k.strip()}: "
                                f"{fv:.3f} → {SAFE_DEFAULT_VOL}"
                            )
                            new_lines.append(f"{k}={SAFE_DEFAULT_VOL}\n")
                            res.n_changes += 1
                            handled = True
                if not handled:
                    new_lines.append(line)
    except OSError as e:
        res.errors.append(f"read QSettings: {e}")
        return

    if not dry_run and res.n_changes > 0:
        try:
            with open(QSETTINGS_FILE, "w", encoding="utf-8") as f:
                f.writelines(new_lines)
        except OSError as e:
            res.errors.append(f"write QSettings: {e}")


# ── Hard wipe (everything) ────────────────────────────────────────────

def wipe_all(dry_run: bool = False) -> ResetResult:
    """Nuclear option: backup-and-delete the entire ChronoScaleStudio
    config directory + the QSettings file.

    Safe: backups are made before deletion. Projects (saved as separate
    files outside ~/.config/) are NOT affected. Caches and waveform
    bitmaps will be regenerated automatically on next start.

    Equivalent to Anno's manual ``rm -rf ~/.config/ChronoScaleStudio
    ~/.config/Py_DAW`` but with a backup safety net.
    """
    res = ResetResult()
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")

    # DB directory
    if DB_DIR.exists():
        bak_dir = DB_DIR.parent / f"{DB_DIR.name}.bak.{ts}"
        if dry_run:
            res.changes.append(f"WOULD: backup {DB_DIR} → {bak_dir} and delete original")
        else:
            try:
                shutil.copytree(DB_DIR, bak_dir)
                res.backups_made.append(bak_dir)
                shutil.rmtree(DB_DIR)
                res.changes.append(f"Deleted {DB_DIR} (backup at {bak_dir})")
                res.n_changes += 1
            except OSError as e:
                res.errors.append(f"wipe DB dir: {e}")

    # QSettings file
    if QSETTINGS_FILE.exists():
        if dry_run:
            res.changes.append(f"WOULD: backup-and-delete {QSETTINGS_FILE}")
        else:
            try:
                _backup_file(QSETTINGS_FILE, res)
                QSETTINGS_FILE.unlink()
                res.changes.append(f"Deleted {QSETTINGS_FILE}")
                res.n_changes += 1
            except OSError as e:
                res.errors.append(f"wipe QSettings: {e}")

    return res
