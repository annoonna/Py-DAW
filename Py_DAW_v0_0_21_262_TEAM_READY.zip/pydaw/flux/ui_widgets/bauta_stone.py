"""
pydaw.flux.ui_widgets.bauta_stone — Frigg.BautaStone (Phase W-2)
=================================================================

**Eingebaut in v0.0.21.200** als runisch-gravierter Stein mit
State-Wechsel. Spezifikation: ``PROJECT_DOCS/FLUX_GROVE_MANIFEST.md``
Sektion „FLUX Sigil — eigene Widget-Designs", W-2 Punkt 2.

Design (aus dem Manifest)
-------------------------

* Stein-grauer Hintergrund mit subtiler Textur (Noise-Pattern)
* Eingravierte Rune in Norse-Cyan; Glow-Aura im Idle
* Klick wechselt zur nächsten Rune (4 States: ᚠ ᚢ ᚦ ᚨ)
* State-Wechsel triggert kurzen Frost-Crystal-Effekt (One-Shot)
* Idle: subtile Rune-Glow-Pulsation (langsam)

Anwendung
---------

Geeignet für **diskrete Multi-State-Switches** wo Toggle nicht reicht:
* Filter-Type-Wahl (LP/HP/BP/Notch)
* Wave-Form-Switch (Sine/Saw/Square/Triangle)
* Modus-Wahl in Multi-Mode-Modulen

Nichts-Kaputt-Garantie
----------------------

* Signal-Vertrag: ``state_changed(int)`` als 0..3 plus
  ``value_changed(float)`` als 0..1 (kompatibel zu RuneToggle); plus
  ``set_value(v, *, emit_signal=...)``, ``_minimum``/``_maximum``/``_default``.
* Reine Python-Schicht, defensiv gegen fehlendes Qt.
* Animation läuft über die zentrale ``AnimationEngine``.
* ``closeEvent()`` räumt Subscriptions auf (v.198 Cleanup-Pakt).
"""

from __future__ import annotations

import logging
from typing import Optional

logger = logging.getLogger(__name__)


try:
    from PyQt6.QtCore import (
        Qt, QPointF, QRectF, QSize, pyqtSignal,
    )
    from PyQt6.QtGui import (
        QColor, QPainter, QPen, QBrush, QFont, QRadialGradient,
        QLinearGradient, QFontMetricsF,
    )
    from PyQt6.QtWidgets import QWidget, QSizePolicy
    _QT_AVAILABLE = True
except ImportError:
    _QT_AVAILABLE = False


from pydaw.flux.animation_engine import (
    get_animation_engine, ANIM_RUNE_GLOW, ANIM_FROST_CRYSTAL,
)


# Vier Standard-Runen (Elder-Futhark erste vier Buchstaben)
DEFAULT_RUNES = ["ᚠ", "ᚢ", "ᚦ", "ᚨ"]


def _clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


if _QT_AVAILABLE:

    class BautaStoneWidget(QWidget):  # type: ignore[misc]
        """Runen-Stein mit Multi-State-Switch.

        Signal-Vertrag:
            ``state_changed(int)`` — feuert beim Klick mit dem neuen
                State-Index (0..len(runes)-1)
            ``value_changed(float)`` — alias-Signal mit dem State als
                normalisierter Float (0..1) für Auto-Range-Compat.
            ``set_value(v, *, emit_signal=True)`` — programmatisch setzen
                (v wird gerundet auf den nächsten State-Index normalisiert).
        """

        DEFAULT_W = 64
        DEFAULT_H = 64

        # Style: Stein-Grau mit Norse-Cyan-Rune
        STONE_DARK   = QColor(50, 56, 68)
        STONE_LIGHT  = QColor(82, 90, 106)
        STONE_BORDER = QColor(28, 32, 42, 220)
        RUNE_COLOR   = QColor(125, 215, 230)         # Norse-Cyan
        RUNE_GLOW    = QColor(125, 215, 230, 110)
        FROST_COLOR  = QColor(220, 240, 255, 180)    # Eis-Schimmer

        state_changed = pyqtSignal(int)
        value_changed = pyqtSignal(float)

        def __init__(
            self,
            value: float = 0.0,
            runes: Optional[list[str]] = None,
            module_id: Optional[str] = None,
            parent=None,
        ):
            super().__init__(parent)
            self._runes = list(runes or DEFAULT_RUNES)
            if not self._runes:
                self._runes = list(DEFAULT_RUNES)

            self._minimum = 0.0
            self._maximum = 1.0
            self._default = 0.0
            self._value = _clamp(float(value), 0.0, 1.0)
            self._state = self._value_to_state(self._value)

            self._module_id = str(module_id or "bauta_unbound")

            # Animation-State
            self._glow_phase: float = 0.0
            self._frost_phase: float = 1.0  # 1.0 = inaktiv

            self.setMinimumSize(self.DEFAULT_W, self.DEFAULT_H)
            self.setSizePolicy(QSizePolicy.Policy.Preferred,
                               QSizePolicy.Policy.Preferred)
            self.setCursor(Qt.CursorShape.PointingHandCursor)

            # Idle-Glow-Loop subscriben
            self._subscribe_idle_loop()

        # ─── Animation-Subscribes ─────────────────────────────────

        def _subscribe_idle_loop(self) -> None:
            try:
                eng = get_animation_engine()
                eng.subscribe(
                    sub_id=f"{self._module_id}::glow",
                    anim_name=ANIM_RUNE_GLOW,
                    on_frame=self._on_glow_tick,
                )
            except Exception as e:
                logger.debug("[BautaStone] glow subscribe failed: %s", e)

        def _on_glow_tick(self, phase: float, frame: int) -> None:
            self._glow_phase = float(phase)
            try:
                self.update()
            except RuntimeError:
                raise

        def _trigger_frost_burst(self) -> None:
            try:
                eng = get_animation_engine()
                eng.subscribe(
                    sub_id=f"{self._module_id}::frost",
                    anim_name=ANIM_FROST_CRYSTAL,
                    on_frame=self._on_frost_tick,
                )
            except Exception as e:
                logger.debug("[BautaStone] frost subscribe failed: %s", e)

        def _on_frost_tick(self, phase: float, frame: int) -> None:
            self._frost_phase = float(phase)
            try:
                self.update()
            except RuntimeError:
                raise

        # ─── State-Konvertierung ──────────────────────────────────

        def _value_to_state(self, v: float) -> int:
            """0..1 → 0..len(runes)-1."""
            n = len(self._runes)
            if n <= 1:
                return 0
            idx = int(round(v * (n - 1)))
            return _clamp(idx, 0, n - 1)

        def _state_to_value(self, s: int) -> float:
            n = len(self._runes)
            if n <= 1:
                return 0.0
            return float(s) / float(n - 1)

        # ─── Signal-Vertrag ────────────────────────────────────────

        @property
        def minimum(self) -> float:
            return self._minimum

        @property
        def maximum(self) -> float:
            return self._maximum

        def set_value(self, value: float, *, emit_signal: bool = True) -> None:
            new_v = _clamp(float(value), 0.0, 1.0)
            new_state = self._value_to_state(new_v)
            if new_state == self._state:
                # Floating-Point-Drift abfangen — Wert auf den Snap-Punkt setzen
                snap_v = self._state_to_value(self._state)
                if abs(snap_v - self._value) > 1e-9:
                    self._value = snap_v
                    self.update()
                return
            self._state = new_state
            self._value = self._state_to_value(self._state)
            self._trigger_frost_burst()
            self.update()
            if emit_signal:
                self.state_changed.emit(self._state)
                self.value_changed.emit(self._value)

        def reset_to_default(self) -> None:
            self.set_value(self._default, emit_signal=True)

        def value(self) -> float:
            return self._value

        def state(self) -> int:
            return self._state

        # ─── Painting ──────────────────────────────────────────────

        def sizeHint(self) -> QSize:
            return QSize(self.DEFAULT_W, self.DEFAULT_H)

        def paintEvent(self, event) -> None:
            p = QPainter(self)
            p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            r = self.rect().adjusted(3, 3, -3, -3)

            # Stein-Verlauf (Diagonal von dunkel nach hell)
            grad = QLinearGradient(QPointF(r.left(), r.top()),
                                   QPointF(r.right(), r.bottom()))
            grad.setColorAt(0.0, self.STONE_LIGHT)
            grad.setColorAt(1.0, self.STONE_DARK)
            p.setBrush(QBrush(grad))
            p.setPen(QPen(self.STONE_BORDER, 1.5))
            p.drawRoundedRect(QRectF(r), 8, 8)

            # Subtile Stein-Adern (zwei diagonale dünne Linien)
            vein = QPen(QColor(28, 32, 42, 120), 0.8)
            p.setPen(vein)
            p.drawLine(
                QPointF(r.left() + r.width() * 0.18, r.top() + r.height() * 0.32),
                QPointF(r.left() + r.width() * 0.72, r.bottom() - r.height() * 0.18),
            )
            p.drawLine(
                QPointF(r.left() + r.width() * 0.40, r.top() + r.height() * 0.10),
                QPointF(r.left() + r.width() * 0.65, r.top() + r.height() * 0.55),
            )

            # Idle-Glow um die Rune (pulsiert sanft)
            glow_intensity = 0.4 + 0.3 * self._glow_phase  # 0.4..0.7
            glow_alpha = int(120 * glow_intensity)
            cx = r.center().x()
            cy = r.center().y()
            glow_grad = QRadialGradient(
                QPointF(cx, cy), r.width() * 0.45,
            )
            glow_col = QColor(self.RUNE_GLOW)
            glow_col.setAlpha(glow_alpha)
            glow_grad.setColorAt(0.0, glow_col)
            glow_grad.setColorAt(1.0, QColor(0, 0, 0, 0))
            p.setBrush(QBrush(glow_grad))
            p.setPen(Qt.PenStyle.NoPen)
            p.drawEllipse(
                QPointF(cx, cy),
                r.width() * 0.45, r.height() * 0.45,
            )

            # Frost-Burst-Overlay beim State-Wechsel
            if self._frost_phase < 1.0:
                fr_alpha = int(180 * (1.0 - self._frost_phase))
                fr_col = QColor(self.FROST_COLOR)
                fr_col.setAlpha(fr_alpha)
                fr_size = r.width() * (0.3 + 0.6 * self._frost_phase)
                p.setBrush(QBrush(fr_col))
                p.setPen(Qt.PenStyle.NoPen)
                p.drawEllipse(QPointF(cx, cy), fr_size, fr_size)

            # Rune zeichnen
            rune_text = self._runes[self._state] if self._runes else "ᚠ"
            font = QFont("monospace", int(r.height() * 0.55))
            font.setBold(True)
            p.setFont(font)
            # Schatten/Glow
            p.setPen(QPen(self.RUNE_GLOW, 4))
            p.drawText(r, Qt.AlignmentFlag.AlignCenter, rune_text)
            # Echte Rune
            p.setPen(QPen(self.RUNE_COLOR, 1))
            p.drawText(r, Qt.AlignmentFlag.AlignCenter, rune_text)

            # State-Indikator: kleine Punkte unten zeigen welcher State aktiv ist
            n = len(self._runes)
            if n > 1:
                dot_y = float(r.bottom()) - 6
                spacing = 6.0
                total_w = (n - 1) * spacing
                start_x = float(cx) - total_w / 2
                for i in range(n):
                    is_active = (i == self._state)
                    col = (self.RUNE_COLOR if is_active
                           else QColor(70, 80, 95, 180))
                    p.setBrush(QBrush(col))
                    p.setPen(Qt.PenStyle.NoPen)
                    p.drawEllipse(
                        QPointF(start_x + i * spacing, dot_y),
                        1.5, 1.5,
                    )

            p.end()

        # ─── User-Eingabe ─────────────────────────────────────────

        def mousePressEvent(self, event) -> None:
            if event.button() == Qt.MouseButton.LeftButton:
                # Cycle: nächster State (mit Wrap)
                next_state = (self._state + 1) % len(self._runes)
                self.set_value(self._state_to_value(next_state),
                                emit_signal=True)
                event.accept()
            elif event.button() == Qt.MouseButton.RightButton:
                # Right-click: vorheriger State
                prev_state = (self._state - 1) % len(self._runes)
                self.set_value(self._state_to_value(prev_state),
                                emit_signal=True)
                event.accept()

        def wheelEvent(self, event) -> None:
            steps = int(event.angleDelta().y() / 120.0)
            if steps == 0:
                return
            new_state = (self._state + steps) % len(self._runes)
            self.set_value(self._state_to_value(new_state),
                            emit_signal=True)
            event.accept()

        def mouseDoubleClickEvent(self, event) -> None:
            if event.button() == Qt.MouseButton.LeftButton:
                self.reset_to_default()
                event.accept()

        # ─── Cleanup ──────────────────────────────────────────────

        def closeEvent(self, event) -> None:  # type: ignore[override]
            try:
                eng = get_animation_engine()
                eng.unsubscribe_prefix(f"{self._module_id}::")
            except Exception:
                pass
            super().closeEvent(event)


else:
    BautaStoneWidget = None  # type: ignore[assignment,misc]


__all__ = ["BautaStoneWidget", "DEFAULT_RUNES"]
