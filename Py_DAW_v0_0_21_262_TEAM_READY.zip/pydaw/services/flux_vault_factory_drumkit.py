"""
pydaw.services.flux_vault_factory_drumkit — Drum-Kit Style Factory-Presets

**v0.0.21.214 — Drum-Kit v1**
=============================

Erste **Drum-Synthese-Familie** (vorher: nur tonale Lead/Pad-Familien).
Anno: „Kannst du uns Patches erstellen — Kick Snare HiHat-open HiHat-Closed
Clap Tom".

Folgt dem Sacred-v2-Charakter-Modul-Schema: jeder Drum bekommt eine
einzigartige Synthese-Kette die das jeweilige Drum-Sound-Character liefert.

| Preset       | Synthese-Kette                                  |
|--------------|--------------------------------------------------|
| Kick         | SineOsc(60Hz) + ADSR (fast Click) + Lowpass     |
| Snare        | NoiseOsc + Bandpass(200Hz) + ADSR + EQ4         |
| HiHat-Closed | NoiseOsc + Highpass(8kHz) + ADSR (kurz)         |
| HiHat-Open   | NoiseOsc + Highpass(8kHz) + ADSR (langer Tail)  |
| Clap         | NoiseOsc + Bandpass(1.5kHz) + ADSR + Reverb-Tail|
| Tom          | SineOsc(120Hz) + ADSR + Lowpass + Saturation    |

Versions-Marker ``"FLUX Factory (Drum-Kit v1)"`` für sauberes Re-Seeding
über den existierenden ``_seed_style_family``-Mechanismus.

NICHTS-KAPUTT-Pakt:
* Reine **Hinzufügung** — keine bestehenden Presets/Module verändert.
* Verwendet **nur** existierende Module (53 Module aus module_library.py).
* Lazy-Build: erst beim ersten Iter-Zugriff werden Builder ausgeführt.
* Build-Fehler einzelner Presets verwerfen NUR den betroffenen Preset
  (defensive try/except), die anderen 5 werden trotzdem geseedet.
"""

from __future__ import annotations

import logging
from typing import Optional

logger = logging.getLogger(__name__)


DRUMKIT_FACTORY_VERSION = "v1"
DRUMKIT_FACTORY_AUTHOR = (
    f"FLUX Factory (Drum-Kit {DRUMKIT_FACTORY_VERSION})"
)


# ─── Helper ───────────────────────────────────────────────────────


def _connect(patch, src_id: str, src_port: str,
             tgt_id: str, tgt_port: str) -> bool:
    """Helper: Connection hinzufügen, defensiv gegen fehlende Module."""
    from pydaw.flux.patch_model import Connection
    src = patch.get_module(src_id)
    tgt = patch.get_module(tgt_id)
    if src is None or tgt is None:
        return False
    return patch.add_connection(Connection(
        source_module=src_id, source_port=src_port,
        target_module=tgt_id, target_port=tgt_port,
    ))


def _set(module, **params) -> None:
    """Helper: Module-Params setzen (defensiv gegen fehlende Keys)."""
    if module is None:
        return
    for k, v in params.items():
        if k in module.params:
            module.params[k] = v


def _build_patch_dict(name: str, builder) -> Optional[dict]:
    """Wrappt einen Patch-Builder in to_dict, defensiv gegen Fehler."""
    try:
        from pydaw.flux.patch_model import Patch
        p = builder()
        if not isinstance(p, Patch):
            return None
        p.name = name
        return p.to_dict()
    except Exception as e:
        logger.warning("[DrumKitPresets-v1] build %s failed: %s", name, e)
        return None


# ─── Patch-Builder pro Drum (Drum-Kit v1) ─────────────────────────


def _build_kick():
    """Kick — SineOsc(60Hz) + ADSR (Click + Body) + Lowpass.

    Charakter: tiefer Sub-Punch. ADSR mit sehr schnellem Attack (5ms) und
    mittlerem Decay (250ms) modelliert den klassischen Kick-Verlauf:
    Click + abklingender Body. Lowpass-Filter schneidet alles über 250 Hz
    weg, damit die Kick „schwarz und tief" bleibt.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_sine_osc, make_freyr_adsr, make_tyr_pulse_gate,
        make_forseti_lowpass, make_heimdall_master_out,
    )
    p = Patch(name="Kick")

    osc = make_bragi_sine_osc(); osc.position = (260, 200)
    _set(osc, freq=60.0, gain=0.0)  # Sub-Bass; gain wird per ADSR moduliert

    env = make_freyr_adsr(); env.position = (60, 320)
    _set(env, attack=0.005, decay=0.25, sustain=0.0, release=0.05)

    gate = make_tyr_pulse_gate(); gate.position = (60, 200)
    _set(gate, rate=2.0, pulse_width=0.1)  # Test-Trigger 2 Hz

    flt = make_forseti_lowpass(); flt.position = (480, 200)
    _set(flt, cutoff=250.0, resonance=0.4)

    out = make_heimdall_master_out(); out.position = (700, 200)

    for m in (osc, env, gate, flt, out):
        p.add_module(m)
    _connect(p, gate.id, "gate_out", env.id, "gate")
    _connect(p, env.id, "cv_out", osc.id, "gain")
    _connect(p, osc.id, "audio_out", flt.id, "audio_in")
    _connect(p, flt.id, "audio_out", out.id, "audio_in_l")
    _connect(p, flt.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_snare():
    """Snare — NoiseOsc + Bandpass(200Hz) + ADSR + EQ4 (Body+Snap).

    Klassisches Schichten: Noise durch Bandpass für „Snap"-Charakter,
    schnelles ADSR damit der Hit knackig bleibt, EQ4 zum Bändchen schärfen.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_noise_osc, make_freyr_adsr, make_tyr_pulse_gate,
        make_forseti_bandpass, make_forseti_eq4,
        make_heimdall_master_out,
    )
    p = Patch(name="Snare")

    noise = make_bragi_noise_osc(); noise.position = (260, 200)
    _set(noise, gain=0.0)

    env = make_freyr_adsr(); env.position = (60, 320)
    _set(env, attack=0.001, decay=0.15, sustain=0.0, release=0.05)

    gate = make_tyr_pulse_gate(); gate.position = (60, 200)
    _set(gate, rate=2.0, pulse_width=0.05)

    bp = make_forseti_bandpass(); bp.position = (480, 200)
    _set(bp, cutoff=200.0, resonance=2.0)

    eq = make_forseti_eq4(); eq.position = (700, 200)
    _set(eq, low_gain=-2.0, lowmid_gain=4.0, highmid_gain=2.0, high_gain=6.0)

    out = make_heimdall_master_out(); out.position = (920, 200)

    for m in (noise, env, gate, bp, eq, out):
        p.add_module(m)
    _connect(p, gate.id, "gate_out", env.id, "gate")
    _connect(p, env.id, "cv_out", noise.id, "gain")
    _connect(p, noise.id, "audio_out", bp.id, "audio_in")
    _connect(p, bp.id, "audio_out", eq.id, "audio_in")
    _connect(p, eq.id, "audio_out", out.id, "audio_in_l")
    _connect(p, eq.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_hihat_closed():
    """HiHat-Closed — NoiseOsc + Highpass(8kHz) + ADSR (kurz).

    Geschlossene HiHat: hartes Highpass-Filter ab 8 kHz lässt nur die
    metallischen Obertöne durch, sehr kurzes Decay (60ms) — knackiger
    Tssss-Hit ohne Tail.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_noise_osc, make_freyr_adsr, make_tyr_pulse_gate,
        make_forseti_highpass, make_heimdall_master_out,
    )
    p = Patch(name="HiHat-Closed")

    noise = make_bragi_noise_osc(); noise.position = (260, 200)
    _set(noise, gain=0.0)

    env = make_freyr_adsr(); env.position = (60, 320)
    _set(env, attack=0.001, decay=0.06, sustain=0.0, release=0.02)

    gate = make_tyr_pulse_gate(); gate.position = (60, 200)
    _set(gate, rate=4.0, pulse_width=0.05)

    hp = make_forseti_highpass(); hp.position = (480, 200)
    _set(hp, cutoff=8000.0, resonance=0.6)

    out = make_heimdall_master_out(); out.position = (700, 200)

    for m in (noise, env, gate, hp, out):
        p.add_module(m)
    _connect(p, gate.id, "gate_out", env.id, "gate")
    _connect(p, env.id, "cv_out", noise.id, "gain")
    _connect(p, noise.id, "audio_out", hp.id, "audio_in")
    _connect(p, hp.id, "audio_out", out.id, "audio_in_l")
    _connect(p, hp.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_hihat_open():
    """HiHat-Open — NoiseOsc + Highpass(8kHz) + ADSR (langer Tail).

    Offene HiHat: gleicher Filter wie Closed, aber Decay 400ms — das
    zischt schön aus, ideal für Off-Beat-Akzente in Hardcore-Patterns.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_noise_osc, make_freyr_adsr, make_tyr_pulse_gate,
        make_forseti_highpass, make_heimdall_master_out,
    )
    p = Patch(name="HiHat-Open")

    noise = make_bragi_noise_osc(); noise.position = (260, 200)
    _set(noise, gain=0.0)

    env = make_freyr_adsr(); env.position = (60, 320)
    _set(env, attack=0.001, decay=0.4, sustain=0.0, release=0.15)

    gate = make_tyr_pulse_gate(); gate.position = (60, 200)
    _set(gate, rate=2.0, pulse_width=0.05)

    hp = make_forseti_highpass(); hp.position = (480, 200)
    _set(hp, cutoff=8000.0, resonance=0.7)

    out = make_heimdall_master_out(); out.position = (700, 200)

    for m in (noise, env, gate, hp, out):
        p.add_module(m)
    _connect(p, gate.id, "gate_out", env.id, "gate")
    _connect(p, env.id, "cv_out", noise.id, "gain")
    _connect(p, noise.id, "audio_out", hp.id, "audio_in")
    _connect(p, hp.id, "audio_out", out.id, "audio_in_l")
    _connect(p, hp.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_clap():
    """Clap — NoiseOsc + Bandpass(1.5kHz) + ADSR + Reverb-Tail.

    Klatscher: mittlerer Bandpass für die Hand-Charakteristik (vocal-
    formant-Bereich), kurzes ADSR, dann sanftes Reverb für Raum-Tiefe
    (typisch 808/909-Clap-Klang mit kurzem Tail).
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_noise_osc, make_freyr_adsr, make_tyr_pulse_gate,
        make_forseti_bandpass, make_iduna_reverb,
        make_heimdall_master_out,
    )
    p = Patch(name="Clap")

    noise = make_bragi_noise_osc(); noise.position = (260, 200)
    _set(noise, gain=0.0)

    env = make_freyr_adsr(); env.position = (60, 320)
    _set(env, attack=0.005, decay=0.1, sustain=0.0, release=0.05)

    gate = make_tyr_pulse_gate(); gate.position = (60, 200)
    _set(gate, rate=2.0, pulse_width=0.08)

    bp = make_forseti_bandpass(); bp.position = (480, 200)
    _set(bp, cutoff=1500.0, resonance=1.2)

    rev = make_iduna_reverb(); rev.position = (700, 200)
    _set(rev, room_size=0.3, damping=0.6, mix=0.35)

    out = make_heimdall_master_out(); out.position = (920, 200)

    for m in (noise, env, gate, bp, rev, out):
        p.add_module(m)
    _connect(p, gate.id, "gate_out", env.id, "gate")
    _connect(p, env.id, "cv_out", noise.id, "gain")
    _connect(p, noise.id, "audio_out", bp.id, "audio_in")
    _connect(p, bp.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_tom():
    """Tom — SineOsc(120Hz) + ADSR + Lowpass + leichte Saturation.

    Mid-Tom-Klang: SineOsc bei 120 Hz für tiefen Body, ADSR mit langsamerem
    Decay (350ms) als Kick, Lowpass-Filter für Wärme, leichte Saturation
    gibt der Tom den nötigen „Holz-Charakter".
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_bragi_sine_osc, make_freyr_adsr, make_tyr_pulse_gate,
        make_forseti_lowpass, make_thor_saturation,
        make_heimdall_master_out,
    )
    p = Patch(name="Tom")

    osc = make_bragi_sine_osc(); osc.position = (260, 200)
    _set(osc, freq=120.0, gain=0.0)

    env = make_freyr_adsr(); env.position = (60, 320)
    _set(env, attack=0.003, decay=0.35, sustain=0.0, release=0.1)

    gate = make_tyr_pulse_gate(); gate.position = (60, 200)
    _set(gate, rate=1.5, pulse_width=0.1)

    flt = make_forseti_lowpass(); flt.position = (480, 200)
    _set(flt, cutoff=400.0, resonance=0.5)

    sat = make_thor_saturation(); sat.position = (700, 200)
    _set(sat, amount=0.3, mix=0.4)

    out = make_heimdall_master_out(); out.position = (920, 200)

    for m in (osc, env, gate, flt, sat, out):
        p.add_module(m)
    _connect(p, gate.id, "gate_out", env.id, "gate")
    _connect(p, env.id, "cv_out", osc.id, "gain")
    _connect(p, osc.id, "audio_out", flt.id, "audio_in")
    _connect(p, flt.id, "audio_out", sat.id, "audio_in")
    _connect(p, sat.id, "audio_out", out.id, "audio_in_l")
    _connect(p, sat.id, "audio_out", out.id, "audio_in_r")
    return p


# ─── Lazy Preset-Liste (entspricht Sacred/Bach/Ambient/Synthwave) ──


_DRUM_PRESETS_SPEC = [
    ("Kick",         _build_kick,         "Sub-Bass Punch (60 Hz + Lowpass)",       []),
    ("Snare",        _build_snare,        "Bandpass-Snap mit EQ4",                  []),
    ("HiHat-Closed", _build_hihat_closed, "Highpass-Tssss, kurzer Decay",           []),
    ("HiHat-Open",   _build_hihat_open,   "Highpass-Tssss, langer Tail",            []),
    ("Clap",         _build_clap,         "Bandpass + Reverb-Tail (808-Style)",     []),
    ("Tom",          _build_tom,          "Mid-Tom mit Saturation-Wärme",           []),
]


def _build_all() -> list[dict]:
    """Iteriert _DRUM_PRESETS_SPEC und baut alle Patches als dict."""
    result: list[dict] = []
    for name, builder, desc, tags in _DRUM_PRESETS_SPEC:
        d = _build_patch_dict(name, builder)
        if d is None:
            continue
        result.append({
            "name": name,
            "description": desc,
            "author": DRUMKIT_FACTORY_AUTHOR,
            "patch": d,
            "tags": tags,
            "bpm": None,
            "musical_key": "",
            "icon_svg": "",
        })
    return result


class _LazyPresetList:
    """Same pattern wie SACRED_PRESETS / BACH_PRESETS / AMBIENT_PRESETS /
    SYNTHWAVE_PRESETS — lazy-built, supports __len__, __iter__, __getitem__.
    """
    def __init__(self):
        self._cache: Optional[list[dict]] = None

    def _ensure(self) -> list[dict]:
        if self._cache is None:
            self._cache = _build_all()
            logger.info(
                "[DrumKitPresets-v1] built %d Drum-Kit presets (%s) lazily",
                len(self._cache), DRUMKIT_FACTORY_VERSION,
            )
        return self._cache

    def __iter__(self):
        return iter(self._ensure())

    def __len__(self):
        return len(self._ensure())

    def __getitem__(self, i):
        return self._ensure()[i]


DRUMKIT_PRESETS = _LazyPresetList()


__all__ = [
    "DRUMKIT_PRESETS",
    "DRUMKIT_FACTORY_VERSION",
    "DRUMKIT_FACTORY_AUTHOR",
]
