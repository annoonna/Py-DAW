"""Chrono Theme CSS — Extracted from main_window.py (v0.0.20.815).

Minimal dark QSS so the whole UI feels like a single Pro-DAW-Style frame.
"""

CHRONO_THEME_CSS = \
            """
            QMainWindow { background: #212121; color: #BBBBBB; }
            QWidget { color: #BBBBBB; }

            /* Classic menu bar (exact like reference screenshot) */
            QMenuBar { background: #1E1E1E; border: none; padding: 2px 6px; }
            QMenuBar::item { background: transparent; padding: 6px 10px; margin: 0px 2px; border-radius: 4px; }
            QMenuBar::item:selected { background: #b000b0; color: #FFFFFF; }
            QMenu { background: #1E1E1E; border: 1px solid #2A2A2A; }
            QMenu::item { padding: 6px 28px 6px 16px; }
            QMenu::separator { height: 1px; background: #2A2A2A; margin: 4px 8px; }
            QMenu::item:selected { background: #b000b0; color: #FFFFFF; }

            /* Toolbars below menu bar */
            QToolBar { background: #232323; border: none; spacing: 6px; padding: 2px 6px; }
            QToolBar::separator { background: #2A2A2A; width: 1px; margin: 0 6px; }

            /* Transport row */
            #transportPanel QPushButton {
                background: #2A2A2A;
                border: 1px solid #343434;
                border-radius: 6px;
                padding: 4px 8px;
                min-width: 28px;
            }
            #transportPanel QPushButton:hover { background: #333333; border-color: #3F3F3F; }
            #transportPanel QLabel { color: #BBBBBB; }
            #transportPanel QSpinBox, #transportPanel QComboBox {
                background: #2A2A2A;
                border: 1px solid #343434;
                border-radius: 6px;
                padding: 2px 6px;
                min-height: 24px;
            }

            /* Tools row */
            #toolBarPanel QComboBox {
                background: #2A2A2A;
                border: 1px solid #343434;
                border-radius: 6px;
                padding: 2px 8px;
                min-height: 24px;
            }
            #toolBarPanel QToolButton {
                background: #2A2A2A;
                border: 1px solid #343434;
                border-radius: 6px;
                padding: 4px 10px;
            }
            #toolBarPanel QToolButton:hover { background: #333333; border-color: #3F3F3F; }

            /* Python logo button styling (the button now lives in the status signature) */
            #toolBarPanel QToolButton#pythonLogoBtn {
                background: transparent;
                border: 1px solid transparent;
                border-radius: 999px;
                padding: 0px;
            }
            #toolBarPanel QToolButton#pythonLogoBtn:hover {
                background: rgba(255,255,255,0.06);
                border-color: #3F3F3F;
            }


            #chronoHeader { background: #1E1E1E; border-bottom: 1px solid #2A2A2A; }
            #chronoLogo { background: #2A2A2A; border: 1px solid #343434; border-radius: 6px; }
            #chronoSep { color: #555555; }

            QToolButton#chronoHeaderButton {
                background: #2A2A2A;
                border: 1px solid #343434;
                border-radius: 6px;
                padding: 2px 8px;
            }
            QToolButton#chronoHeaderButton:hover { background: #333333; border-color: #3F3F3F; }

            #chronoToolStrip { background: #1C1C1C; border-right: 1px solid #2A2A2A; }
            QToolButton#chronoToolButton {
                background: #2A2A2A;
                border: 1px solid #343434;
                border-radius: 8px;
                font-size: 14px;
            }
            QToolButton#chronoToolButton:hover { background: #333333; border-color: #3F3F3F; }

            QDockWidget::title {
                background: #1E1E1E;
                border: 1px solid #2A2A2A;
                padding: 4px;
            }
            QDockWidget { border: 1px solid #2A2A2A; }

            QTabWidget::pane { border: 1px solid #2A2A2A; }
            QTabBar::tab { background: #2A2A2A; border: 1px solid #343434; padding: 6px 10px; margin: 1px; }
            QTabBar::tab:selected { background: #333333; }

            QComboBox { background: #2A2A2A; border: 1px solid #343434; padding: 4px 8px; border-radius: 6px; }
            QComboBox::drop-down { border: none; }

            QToolButton#chronoMenuButton {
                background: transparent;
                border: 1px solid transparent;
                border-radius: 6px;
                padding: 2px 8px;
            }
            QToolButton#chronoMenuButton:hover { background: #2A2A2A; border-color: #343434; }

            #chronoBottomNav { background: #1E1E1E; border-top: 1px solid #2A2A2A; }
            QWidget#chronoTechSignature { background: transparent; }
            QToolButton#statusQtLogoButton,
            QToolButton#statusPythonLogoButton,
            QToolButton#statusRustLogoButton {
                background: transparent;
                border: none;
                padding: 0px;
                margin: 0px;
            }
            QToolButton#chronoViewTab {
                background: #2A2A2A;
                border: 1px solid #343434;
                border-radius: 8px;
                padding: 4px 10px;
                margin-right: 6px;
                font-weight: 600;
            }
            QToolButton#chronoViewTab:checked {
                background: #333333;
                border-color: #D77A00;
                color: #EEEEEE;
            }
            QLabel#chronoSnapLabel { color: #9E9E9E; padding-right: 6px; }

            /* Device panel placeholder */
            #devicePanel { background: #212121; }
            QLabel#devicePanelTitle { color: #DDDDDD; font-weight: 700; font-size: 14px; }
            QLabel#devicePanelHint { color: #9E9E9E; }
            QLabel#devicePanelEmpty { color: #7E7E7E; }
            #devicePanelSep { background: #2A2A2A; }
            """
