"""Preset Format & Importer (P6C) — Standardized .pydaw-preset format.

Machine-readable + human-readable YAML-based preset format.
Supports AETERNA, Fusion, DrumMachine, ProSampler presets.
Includes Serum .fxp → AETERNA converter (best-effort).

Features:
- .pydaw-preset format: YAML with metadata, parameters, tags
- Save/load presets to/from files
- Serum preset importer (basic parameter mapping)
- Preset search by tags/name/category
- Community preset metadata (author, license, description)

v0.0.20.811 — Phase P6C
"""

from __future__ import annotations

import logging
import json
import os
import struct
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Dict, Any, Tuple

log = logging.getLogger(__name__)

try:
    import yaml  # type: ignore
    _HAS_YAML = True
except ImportError:
    _HAS_YAML = False


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class PresetMetadata:
    """Metadata for a preset."""
    name: str = "Untitled"
    author: str = ""
    description: str = ""
    category: str = ""           # "Bass"|"Lead"|"Pad"|"Pluck"|"Keys"|"Drums"|"FX"|"Other"
    tags: List[str] = field(default_factory=list)
    genre: str = ""              # "Electronic"|"Hip-Hop"|"Rock"|...
    license: str = "CC0"         # "CC0"|"CC-BY"|"proprietary"|...
    version: str = "1.0"
    created: str = ""
    source: str = ""             # "factory"|"user"|"community"|"imported"

    def to_dict(self) -> dict:
        return {
            "name": self.name, "author": self.author,
            "description": self.description, "category": self.category,
            "tags": self.tags, "genre": self.genre,
            "license": self.license, "version": self.version,
            "created": self.created, "source": self.source,
        }


@dataclass
class PyDawPreset:
    """Complete .pydaw-preset container."""
    format_version: str = "1.0"
    synth: str = "aeterna"         # "aeterna"|"fusion"|"drum_machine"|"pro_sampler"
    metadata: PresetMetadata = field(default_factory=PresetMetadata)
    parameters: Dict[str, Any] = field(default_factory=dict)
    modulation: List[Dict[str, Any]] = field(default_factory=list)
    fx_chain: List[Dict[str, Any]] = field(default_factory=list)
    notes: str = ""                # Free-form notes

    def to_dict(self) -> dict:
        return {
            "pydaw_preset": {
                "format_version": self.format_version,
                "synth": self.synth,
                "metadata": self.metadata.to_dict(),
                "parameters": self.parameters,
                "modulation": self.modulation,
                "fx_chain": self.fx_chain,
                "notes": self.notes,
            }
        }

    def to_yaml(self) -> str:
        """Serialize to YAML string."""
        if _HAS_YAML:
            return yaml.dump(
                self.to_dict(),
                default_flow_style=False,
                allow_unicode=True,
                sort_keys=False,
            )
        # Fallback: JSON with nice formatting
        return json.dumps(self.to_dict(), indent=2, ensure_ascii=False)

    def to_json(self) -> str:
        """Serialize to JSON string."""
        return json.dumps(self.to_dict(), indent=2, ensure_ascii=False)


# ---------------------------------------------------------------------------
# Save / Load
# ---------------------------------------------------------------------------

_PRESET_EXTENSION = ".pydaw-preset"


def save_preset(preset: PyDawPreset, path: str) -> bool:
    """Save a preset to a .pydaw-preset file.

    Args:
        preset: the preset to save
        path: file path (extension added if missing)

    Returns:
        True on success.
    """
    try:
        p = Path(path)
        if p.suffix != _PRESET_EXTENSION:
            p = p.with_suffix(_PRESET_EXTENSION)

        content = preset.to_yaml()
        p.write_text(content, encoding="utf-8")
        log.info("Preset saved: %s", p)
        return True
    except Exception as exc:
        log.error("Failed to save preset: %s", exc)
        return False


def load_preset(path: str) -> Optional[PyDawPreset]:
    """Load a preset from a .pydaw-preset file.

    Supports both YAML and JSON formats.

    Returns:
        PyDawPreset or None on error.
    """
    try:
        p = Path(path)
        text = p.read_text(encoding="utf-8")

        # Try YAML first
        data = None
        if _HAS_YAML:
            try:
                data = yaml.safe_load(text)
            except Exception:
                pass

        # Fallback: JSON
        if data is None:
            try:
                data = json.loads(text)
            except Exception:
                log.error("Could not parse preset file: %s", path)
                return None

        # Extract from wrapper
        pd = data.get("pydaw_preset", data)

        meta_dict = pd.get("metadata", {})
        metadata = PresetMetadata(
            name=meta_dict.get("name", p.stem),
            author=meta_dict.get("author", ""),
            description=meta_dict.get("description", ""),
            category=meta_dict.get("category", ""),
            tags=meta_dict.get("tags", []),
            genre=meta_dict.get("genre", ""),
            license=meta_dict.get("license", ""),
            version=meta_dict.get("version", "1.0"),
            created=meta_dict.get("created", ""),
            source=meta_dict.get("source", "user"),
        )

        return PyDawPreset(
            format_version=pd.get("format_version", "1.0"),
            synth=pd.get("synth", "aeterna"),
            metadata=metadata,
            parameters=pd.get("parameters", {}),
            modulation=pd.get("modulation", []),
            fx_chain=pd.get("fx_chain", []),
            notes=pd.get("notes", ""),
        )
    except Exception as exc:
        log.error("Failed to load preset: %s — %s", path, exc)
        return None


# ---------------------------------------------------------------------------
# Preset Library (scan directory)
# ---------------------------------------------------------------------------

@dataclass
class PresetEntry:
    """Entry in the preset library."""
    path: str = ""
    name: str = ""
    synth: str = ""
    category: str = ""
    tags: List[str] = field(default_factory=list)
    author: str = ""
    source: str = ""

    def to_dict(self) -> dict:
        return {
            "path": self.path, "name": self.name,
            "synth": self.synth, "category": self.category,
            "tags": self.tags, "author": self.author, "source": self.source,
        }


def scan_preset_directory(directory: str) -> List[PresetEntry]:
    """Scan a directory for .pydaw-preset files.

    Returns list of PresetEntry objects (lightweight, no full parameter load).
    """
    entries: List[PresetEntry] = []
    base = Path(directory)
    if not base.exists():
        return entries

    for f in sorted(base.rglob(f"*{_PRESET_EXTENSION}")):
        try:
            preset = load_preset(str(f))
            if preset:
                entries.append(PresetEntry(
                    path=str(f),
                    name=preset.metadata.name,
                    synth=preset.synth,
                    category=preset.metadata.category,
                    tags=list(preset.metadata.tags),
                    author=preset.metadata.author,
                    source=preset.metadata.source,
                ))
        except Exception:
            pass

    return entries


def search_presets(
    entries: List[PresetEntry],
    query: str = "",
    synth: str = "",
    category: str = "",
    tags: Optional[List[str]] = None,
) -> List[PresetEntry]:
    """Search/filter preset entries.

    Args:
        entries: list of PresetEntry to search
        query: free-text search (name, author)
        synth: filter by synth type
        category: filter by category
        tags: filter by tags (any match)

    Returns:
        Filtered list of PresetEntry.
    """
    results = list(entries)
    query_lower = query.lower()

    if query:
        results = [e for e in results
                   if query_lower in e.name.lower()
                   or query_lower in e.author.lower()
                   or any(query_lower in t.lower() for t in e.tags)]

    if synth:
        results = [e for e in results if e.synth == synth]

    if category:
        results = [e for e in results if e.category.lower() == category.lower()]

    if tags:
        tag_set = set(t.lower() for t in tags)
        results = [e for e in results
                   if tag_set & set(t.lower() for t in e.tags)]

    return results


# ---------------------------------------------------------------------------
# Serum .fxp Importer (best-effort)
# ---------------------------------------------------------------------------

# Serum oscillator waveform types (simplified mapping)
_SERUM_WAVE_MAP = {
    0: 1,   # Default → Saw
    1: 0,   # Sine → Sine
    2: 1,   # Saw → Saw
    3: 2,   # Square → Square
    4: 3,   # Triangle → Triangle
    5: 4,   # Noise → Noise
}

# Serum filter types (simplified)
_SERUM_FILTER_MAP = {
    0: 0,   # LP → LP
    1: 1,   # HP → HP
    2: 2,   # BP → BP
    3: 3,   # Notch → Notch
}


def import_serum_fxp(path: str) -> Optional[PyDawPreset]:
    """Import a Serum .fxp preset file → PyDawPreset (best-effort).

    Serum .fxp is a VST2 preset format (FXP/FXB). We extract what we can
    and map to AETERNA parameters. Many parameters won't map 1:1.

    Args:
        path: path to .fxp file

    Returns:
        PyDawPreset with best-effort parameter mapping, or None.
    """
    try:
        p = Path(path)
        data = p.read_bytes()

        if len(data) < 60:
            log.warning("FXP file too small: %s", path)
            return None

        # FXP header: "CcnK" magic, then version, fxID, etc.
        magic = data[:4]
        if magic != b"CcnK":
            log.warning("Not a valid FXP file (bad magic): %s", path)
            return None

        # Extract preset name from FXP header (offset 28, 28 bytes)
        try:
            name_bytes = data[28:56]
            name = name_bytes.split(b'\x00')[0].decode('ascii', errors='ignore').strip()
        except Exception:
            name = p.stem

        # The actual parameter data starts after the header.
        # Serum's internal format is not publicly documented, so we do
        # best-effort extraction of common parameters.

        # Create a preset with sensible defaults
        params: Dict[str, float] = {
            "osc1_waveform": 1,     # Saw (Serum default)
            "osc1_level": 0.8,
            "osc1_octave": 0,
            "osc1_detune": 0.0,
            "osc2_waveform": 1,
            "osc2_level": 0.0,      # Off by default
            "osc2_octave": 0,
            "osc2_detune": 0.0,
            "filter_type": 0,
            "filter_cutoff": 8000.0,
            "filter_resonance": 0.2,
            "filter_env_amount": 0.3,
            "amp_attack": 0.005,
            "amp_decay": 0.3,
            "amp_sustain": 0.7,
            "amp_release": 0.3,
            "filter_attack": 0.005,
            "filter_decay": 0.5,
            "filter_sustain": 0.3,
            "filter_release": 0.5,
            "chorus_mix": 0.0,
            "reverb_mix": 0.0,
            "delay_mix": 0.0,
            "unison_voices": 1,
            "unison_detune": 0.0,
            "master_volume": 0.75,
        }

        # Try to extract floats from the opaque chunk
        # Serum stores parameters as 32-bit floats in its chunk
        chunk_start = 60  # approximate
        if len(data) > chunk_start + 200:
            try:
                # Read first ~50 floats as potential parameters
                floats = []
                for i in range(50):
                    offset = chunk_start + i * 4
                    if offset + 4 <= len(data):
                        val = struct.unpack('<f', data[offset:offset + 4])[0]
                        if -100.0 <= val <= 100.0:  # sanity check
                            floats.append(val)
                        else:
                            floats.append(0.0)

                # Best-effort mapping of first few floats
                # (These positions are approximate and may vary by Serum version)
                if len(floats) > 10:
                    # Osc levels
                    if 0.0 <= floats[0] <= 1.0:
                        params["osc1_level"] = floats[0]
                    if 0.0 <= floats[1] <= 1.0:
                        params["osc2_level"] = floats[1]
                    # Filter cutoff (normalized 0..1 → Hz)
                    if 0.0 <= floats[5] <= 1.0:
                        params["filter_cutoff"] = 20.0 + floats[5] * 19980.0
                    if 0.0 <= floats[6] <= 1.0:
                        params["filter_resonance"] = floats[6]

            except Exception:
                pass

        # Determine category from name
        name_lower = name.lower()
        category = "Other"
        if any(k in name_lower for k in ("bass", "sub", "808")):
            category = "Bass"
        elif any(k in name_lower for k in ("lead", "solo")):
            category = "Lead"
        elif any(k in name_lower for k in ("pad", "ambient", "atmo")):
            category = "Pad"
        elif any(k in name_lower for k in ("pluck", "stab", "key")):
            category = "Pluck"
        elif any(k in name_lower for k in ("drum", "perc", "kick", "snare")):
            category = "Drums"
        elif any(k in name_lower for k in ("fx", "riser", "impact")):
            category = "FX"

        preset = PyDawPreset(
            synth="aeterna",
            metadata=PresetMetadata(
                name=name,
                author="Serum Import",
                description=f"Importiert aus {p.name} (Best-Effort-Konvertierung)",
                category=category,
                tags=["imported", "serum"],
                source="imported",
            ),
            parameters=params,
            notes="Hinweis: Serum→AETERNA Konvertierung ist approximativ. "
                  "Wavetable-Positionen und komplexe Modulationen werden nicht übertragen.",
        )

        log.info("Serum preset imported: %s → %s", p.name, name)
        return preset

    except Exception as exc:
        log.error("Failed to import Serum FXP: %s — %s", path, exc)
        return None


# ---------------------------------------------------------------------------
# Factory presets generator
# ---------------------------------------------------------------------------

def create_factory_presets() -> List[PyDawPreset]:
    """Generate a set of factory presets for AETERNA.

    Returns list of ready-to-save PyDawPreset objects.
    """
    presets: List[PyDawPreset] = []

    # ── Init / Default ────────────────────────────────────────────────
    presets.append(PyDawPreset(
        synth="aeterna",
        metadata=PresetMetadata(
            name="Init", category="Other", tags=["init", "default"],
            source="factory", description="Leerer Ausgangspunkt",
        ),
        parameters={
            "osc1_waveform": 1, "osc1_level": 0.8, "osc1_octave": 0,
            "osc2_level": 0.0, "filter_cutoff": 20000, "filter_resonance": 0.0,
            "amp_attack": 0.005, "amp_decay": 0.3, "amp_sustain": 0.7,
            "amp_release": 0.3, "master_volume": 0.75,
        },
    ))

    # ── Classic Pads ──────────────────────────────────────────────────
    presets.append(PyDawPreset(
        synth="aeterna",
        metadata=PresetMetadata(
            name="Warm Pad", category="Pad", tags=["warm", "pad", "80s", "lush"],
            source="factory",
        ),
        parameters={
            "osc1_waveform": 1, "osc1_level": 0.7, "osc2_waveform": 1,
            "osc2_level": 0.5, "osc2_detune": 8.0, "filter_cutoff": 3500,
            "filter_resonance": 0.15, "amp_attack": 1.5, "amp_decay": 2.0,
            "amp_sustain": 0.8, "amp_release": 3.0, "chorus_mix": 0.35,
            "reverb_mix": 0.25, "unison_voices": 3, "unison_detune": 12.0,
        },
    ))

    # ── Supersaw Lead ─────────────────────────────────────────────────
    presets.append(PyDawPreset(
        synth="aeterna",
        metadata=PresetMetadata(
            name="Supersaw Lead", category="Lead",
            tags=["supersaw", "trance", "bright", "wide"],
            source="factory",
        ),
        parameters={
            "osc1_waveform": 1, "osc1_level": 0.9, "osc2_waveform": 1,
            "osc2_level": 0.7, "osc2_detune": 5.0, "filter_cutoff": 12000,
            "filter_resonance": 0.1, "filter_env_amount": 0.3,
            "amp_attack": 0.005, "amp_sustain": 0.9, "amp_release": 0.4,
            "unison_voices": 7, "unison_detune": 30.0, "unison_spread": 0.8,
            "delay_mix": 0.15,
        },
    ))

    # ── Sub Bass ──────────────────────────────────────────────────────
    presets.append(PyDawPreset(
        synth="aeterna",
        metadata=PresetMetadata(
            name="Deep Sub Bass", category="Bass",
            tags=["sub", "bass", "deep", "808"],
            source="factory",
        ),
        parameters={
            "osc1_waveform": 0, "osc1_level": 1.0, "osc1_octave": -1,
            "osc2_waveform": 3, "osc2_level": 0.3, "osc2_octave": -1,
            "filter_cutoff": 800, "filter_resonance": 0.1,
            "filter_env_amount": 0.4, "filter_decay": 0.5,
            "amp_attack": 0.001, "amp_decay": 0.8, "amp_sustain": 0.6,
            "amp_release": 0.2,
        },
    ))

    # ── Pluck ─────────────────────────────────────────────────────────
    presets.append(PyDawPreset(
        synth="aeterna",
        metadata=PresetMetadata(
            name="Crystal Pluck", category="Pluck",
            tags=["pluck", "bell", "short", "bright"],
            source="factory",
        ),
        parameters={
            "osc1_waveform": 2, "osc1_level": 0.7, "osc2_waveform": 3,
            "osc2_level": 0.4, "osc2_octave": 1, "filter_cutoff": 10000,
            "filter_resonance": 0.2, "filter_env_amount": 0.6,
            "filter_decay": 0.2, "filter_sustain": 0.0,
            "amp_attack": 0.001, "amp_decay": 0.25, "amp_sustain": 0.0,
            "amp_release": 0.3, "reverb_mix": 0.3, "delay_mix": 0.2,
        },
    ))

    return presets
