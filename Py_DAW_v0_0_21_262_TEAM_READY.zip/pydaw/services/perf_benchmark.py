# -*- coding: utf-8 -*-
"""Performance Benchmark — CPU, Latency, XRun, GIL Monitoring.

v0.0.21.027 — Block B Phase B5.3–B5.6 + Block E Phase E2.3

Tools for comparing Python vs Rust audio performance and
managing memory budgets for caches.

Usage:
    from pydaw.services.perf_benchmark import PerfBenchmark, MemoryBudget

    bench = PerfBenchmark()
    bench.start_monitoring()
    # ... run DAW for a while ...
    report = bench.get_report()
    print(report)

    budget = MemoryBudget(waveform_mb=500, sample_mb=200)
    budget.check_and_evict(waveform_cache, sample_cache)
"""
from __future__ import annotations

import logging
import os
import sys
import time
import threading
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

log = logging.getLogger(__name__)


@dataclass
class PerfSnapshot:
    """Single performance measurement."""
    timestamp: float = 0.0
    cpu_percent: float = 0.0
    gil_starvation_ms: float = 0.0
    xrun_count: int = 0
    latency_ms: float = 0.0
    engine: str = "python"  # "python" or "rust"
    tracks: int = 0
    memory_mb: float = 0.0


class PerfBenchmark:
    """B5.3–B5.6: Performance monitoring and comparison.

    Collects CPU%, GIL starvation, XRun count, and latency data
    for both Python and Rust audio engines.
    """

    def __init__(self):
        self._snapshots: List[PerfSnapshot] = []
        self._monitoring = False
        self._thread: Optional[threading.Thread] = None
        self._interval = 1.0  # seconds
        self._xrun_count = 0
        self._start_time = 0.0

    def start_monitoring(self, interval: float = 1.0) -> None:
        """Start background performance monitoring."""
        if self._monitoring:
            return
        self._monitoring = True
        self._interval = interval
        self._start_time = time.monotonic()
        self._snapshots.clear()
        self._thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self._thread.start()
        log.info("[PERF] Monitoring started (interval=%.1fs)", interval)

    def stop_monitoring(self) -> None:
        self._monitoring = False
        if self._thread:
            self._thread.join(timeout=2.0)
            self._thread = None
        log.info("[PERF] Monitoring stopped (%d snapshots)", len(self._snapshots))

    def _monitor_loop(self) -> None:
        while self._monitoring:
            try:
                snap = self._take_snapshot()
                self._snapshots.append(snap)
            except Exception:
                pass
            time.sleep(self._interval)

    def _take_snapshot(self) -> PerfSnapshot:
        snap = PerfSnapshot(timestamp=time.monotonic() - self._start_time)

        # CPU
        try:
            import psutil
            snap.cpu_percent = psutil.Process().cpu_percent(interval=0)
        except Exception:
            pass

        # Memory
        try:
            import psutil
            snap.memory_mb = psutil.Process().memory_info().rss / (1024 * 1024)
        except Exception:
            pass

        # GIL starvation — check SENTINEL anomaly detector
        try:
            from pydaw.services.sentinel_anomaly import _last_gil_peak_ms
            snap.gil_starvation_ms = float(_last_gil_peak_ms)
        except Exception:
            snap.gil_starvation_ms = 0.0

        # Engine type
        try:
            from pydaw.services.rust_engine_bridge import RustEngineBridge
            bridge = RustEngineBridge.instance()
            if bridge and bridge.is_connected:
                snap.engine = "rust"
            else:
                snap.engine = "python"
        except Exception:
            snap.engine = "python"

        return snap

    def increment_xrun(self) -> None:
        """Call when an XRun is detected."""
        self._xrun_count += 1

    def get_report(self) -> Dict[str, Any]:
        """B5.3–B5.6: Generate performance report."""
        if not self._snapshots:
            return {"error": "No data collected"}

        cpu_values = [s.cpu_percent for s in self._snapshots if s.cpu_percent > 0]
        gil_values = [s.gil_starvation_ms for s in self._snapshots]
        mem_values = [s.memory_mb for s in self._snapshots if s.memory_mb > 0]
        duration = self._snapshots[-1].timestamp if self._snapshots else 0

        engine = self._snapshots[-1].engine if self._snapshots else "unknown"

        report = {
            "duration_s": round(duration, 1),
            "engine": engine,
            "snapshots": len(self._snapshots),
            "cpu": {
                "avg": round(sum(cpu_values) / max(1, len(cpu_values)), 1),
                "peak": round(max(cpu_values) if cpu_values else 0, 1),
                "min": round(min(cpu_values) if cpu_values else 0, 1),
            },
            "gil_starvation_ms": {
                "avg": round(sum(gil_values) / max(1, len(gil_values)), 1),
                "peak": round(max(gil_values) if gil_values else 0, 1),
                "zero_count": sum(1 for g in gil_values if g == 0),
            },
            "xruns": self._xrun_count,
            "memory_mb": {
                "avg": round(sum(mem_values) / max(1, len(mem_values)), 1),
                "peak": round(max(mem_values) if mem_values else 0, 1),
            },
        }

        # B5.6: Check if GIL starvation is 0 (Rust takeover active)
        if engine == "rust" and report["gil_starvation_ms"]["peak"] == 0:
            report["gil_eliminated"] = True
        else:
            report["gil_eliminated"] = False

        return report

    def format_report(self) -> str:
        """Human-readable report string."""
        r = self.get_report()
        if "error" in r:
            return r["error"]
        lines = [
            f"═══ Performance Report ({r['duration_s']}s, {r['engine']} engine) ═══",
            f"CPU:  avg={r['cpu']['avg']}%  peak={r['cpu']['peak']}%",
            f"GIL:  avg={r['gil_starvation_ms']['avg']}ms  peak={r['gil_starvation_ms']['peak']}ms",
            f"XRuns: {r['xruns']}",
            f"RAM:  avg={r['memory_mb']['avg']}MB  peak={r['memory_mb']['peak']}MB",
            f"GIL eliminated: {'✅ YES' if r.get('gil_eliminated') else '❌ NO'}",
        ]
        return "\n".join(lines)


class MemoryBudget:
    """E2.3: Configurable memory budgets for caches.

    Monitors cache sizes and triggers eviction when budgets exceeded.
    """

    def __init__(self, waveform_mb: float = 500, sample_mb: float = 200,
                 pixmap_mb: float = 100):
        self.waveform_budget = int(waveform_mb * 1024 * 1024)
        self.sample_budget = int(sample_mb * 1024 * 1024)
        self.pixmap_budget = int(pixmap_mb * 1024 * 1024)

    def estimate_cache_size(self, cache: dict, item_size_est: int = 4096) -> int:
        """Estimate memory usage of a dict cache."""
        return len(cache) * item_size_est

    def should_evict(self, cache: dict, budget_bytes: int,
                     item_size_est: int = 4096) -> int:
        """Return number of items to evict (0 if within budget)."""
        used = self.estimate_cache_size(cache, item_size_est)
        if used <= budget_bytes:
            return 0
        excess = used - budget_bytes
        return max(1, excess // max(1, item_size_est))

    def check_waveform_cache(self, cache: dict) -> int:
        """Check waveform cache and return items to evict."""
        return self.should_evict(cache, self.waveform_budget, item_size_est=8192)

    def check_pixmap_cache(self, cache: dict) -> int:
        """Check pixmap cache and return items to evict."""
        # QPixmap: roughly width * height * 4 bytes
        return self.should_evict(cache, self.pixmap_budget, item_size_est=50000)

    def get_status(self) -> Dict[str, Any]:
        return {
            "waveform_budget_mb": self.waveform_budget / (1024 * 1024),
            "sample_budget_mb": self.sample_budget / (1024 * 1024),
            "pixmap_budget_mb": self.pixmap_budget / (1024 * 1024),
        }
