"""FluidSynth Realtime Engine for SF2 Live MIDI Playback.

v0.0.20.430: Enables live MIDI keyboard → SF2 SoundFont audio output.

Design (Best Practice — matches Bitwig/Ableton/Cubase approach):
- FluidSynth synthesizes audio in realtime (no offline WAV cache)
- Registered as pull-source in HybridAudioCallback (same as ProSamplerEngine)
- Registered in SamplerRegistry for MIDI dispatch (note_on/note_off)
- Audio output goes through track mixer (Volume/Pan/Mute/Solo/VU)

Architecture:
  MIDI Keyboard → MidiManager.live_note_on → SamplerRegistry.note_on(track_id)
                                                    ↓
                                         FluidSynthRealtimeEngine.note_on(pitch, vel)
                                                    ↓
                                         fluidsynth.Synth.noteon(channel, pitch, vel)
                                                    ↓
  Audio Callback → pull(frames, sr) → synth.get_samples(frames) → float32 stereo
                                                    ↓
                                         HybridAudioCallback mixes per-track
"""
from __future__ import annotations

import sys
import threading
from typing import Optional

import numpy as np

import logging

log = logging.getLogger(__name__)
def _clamp(v: int, lo: int, hi: int) -> int:
    return max(lo, min(hi, int(v)))

class FluidSynthRealtimeEngine:
    """Realtime FluidSynth engine for SF2 live MIDI playback.

    Implements the pull-source + SamplerRegistry interface:
    - note_on(pitch, vel, **kwargs) -> bool
    - note_off(pitch=...) -> None
    - all_notes_off() -> None
    - pull(frames, sr) -> np.ndarray (frames, 2) float32
    - shutdown() -> None
    """

    def __init__(self, sf2_path: str, bank: int = 0, preset: int = 0,
                 sr: int = 48000, track_id: str = "", gain: float = 0.5):
        # v0.0.21.234: Default gain reduced from 0.8 → 0.5 (-6 dB).
        # Previous 0.8 ließ einzelne SF2-Notes mit peak ~0.8 in den Mix,
        # bei Akkorden 2-3× akkumuliert → 1.6-2.4 → Saturator engaged → blechernd.
        # 0.5 hält single-note bei 0.5 peak und 4-note-Akkord bei 2.0 → mit
        # zusätzlichem Source-Headroom in audio_engine.py × 0.5 = 1.0 (saturator
        # transparent oder mild).
        self._ok = False
        self._err = ""
        self._synth = None
        self._sfid = -1
        self._lock = threading.Lock()
        self._sr = int(sr)
        self._track_id = str(track_id)
        self._sf2_path = str(sf2_path)
        self._bank = int(bank)
        self._preset = int(preset)
        self._active_notes: set = set()  # track active pitches for polyphonic note_off
        self._shutdown = False

        try:
            import fluidsynth as _fs
            self._fs_module = _fs
        except ImportError:
            self._err = "pyfluidsynth not installed"
            log.error(f"[SF2-RT] ERROR: {self._err}")
            return

        try:
            # Create synth WITHOUT audio driver — we pull samples manually
            self._synth = _fs.Synth(gain=float(gain), samplerate=float(sr))

            # v0.0.21.207 — Slice B: Explicitly set highest-quality
            # interpolation. FluidSynth supports: 'none', 'linear',
            # 'cubic' (4th-order), '7thorder'. Default is 'cubic' which
            # is OK but '7thorder' has audibly cleaner anti-aliasing on
            # transposed/pitched samples (i.e. when a SF2 sample is
            # played at a pitch other than its native sample rate). The
            # CPU cost is negligible compared to the audio improvement.
            try:
                # pyfluidsynth exposes interpolation via setting() (string
                # API) — the constants are FLUID_INTERP_*: 0=none,
                # 1=linear, 4=cubic, 7=7thorder.
                if hasattr(self._synth, 'setting'):
                    # Both write APIs exist depending on pyfluidsynth version.
                    try:
                        self._synth.setting('synth.interpolation', '7thorder')
                    except Exception:
                        try:
                            self._synth.setting('synth.interpolation', 7)
                        except Exception:
                            pass
                # Some versions expose set_interp_method on each channel.
                if hasattr(self._synth, 'set_interp_method'):
                    try:
                        # 7 = FLUID_INTERP_7THORDER
                        self._synth.set_interp_method(-1, 7)
                    except Exception:
                        pass
            except Exception:
                pass  # Non-fatal: fall back to default cubic interpolation.

            # Load soundfont
            self._sfid = self._synth.sfload(str(sf2_path))
            if self._sfid < 0:
                self._err = f"sfload failed for {sf2_path}"
                log.error(f"[SF2-RT] ERROR: {self._err}")
                return

            # Select bank/preset on channel 0
            self._synth.program_select(0, self._sfid, int(bank), int(preset))

            # Verify get_samples is available
            if not hasattr(self._synth, 'get_samples'):
                self._err = "pyfluidsynth version too old (no get_samples)"
                log.error(f"[SF2-RT] ERROR: {self._err}")
                return

            self._ok = True
            log.info(f"[SF2-RT] Engine created: track={track_id} sf2={sf2_path} "
                  f"bank={bank} preset={preset} sr={sr} interp=7thorder")
        except Exception as exc:
            self._err = str(exc)
            log.error(f"[SF2-RT] Engine creation failed: {exc}")
            import traceback
            traceback.print_exc(file=sys.stderr)

    @property
    def path(self) -> str:
        """Compatibility with VST engine reuse logic."""
        return self._sf2_path

    # ── MIDI Interface (called from SamplerRegistry / GUI thread) ──

    def note_on(self, pitch: int, velocity: int = 100, *,
                pitch_offset_semitones: float = 0.0,
                micropitch_curve: list = None,
                note_duration_samples: int = 0) -> bool:
        """Start a sustained note (live MIDI keyboard).

        Compatible with SamplerRegistry.note_on() dispatch.
        """
        if not self._ok or self._synth is None or self._shutdown:
            return False
        try:
            pitch = _clamp(int(pitch), 0, 127)
            velocity = _clamp(int(velocity), 1, 127)
            with self._lock:
                self._synth.noteon(0, pitch, velocity)
                self._active_notes.add(pitch)
            return True
        except Exception as exc:
            log.error(f"[SF2-RT] note_on error: {exc}")
            return False

    def note_off(self, pitch: int = -1) -> None:
        """Stop a note. If pitch >= 0: polyphonic release. If < 0: release all."""
        if not self._ok or self._synth is None or self._shutdown:
            return
        try:
            with self._lock:
                if pitch >= 0:
                    self._synth.noteoff(0, _clamp(int(pitch), 0, 127))
                    self._active_notes.discard(int(pitch))
                else:
                    # Release all active notes
                    for p in list(self._active_notes):
                        try:
                            self._synth.noteoff(0, int(p))
                        except Exception:
                            pass
                    self._active_notes.clear()
        except Exception as exc:
            log.error(f"[SF2-RT] note_off error: {exc}")
    def all_notes_off(self) -> None:
        """Panic: stop all notes on all channels."""
        if not self._ok or self._synth is None or self._shutdown:
            return
        try:
            with self._lock:
                for ch in range(16):
                    for p in range(128):
                        try:
                            self._synth.noteoff(ch, p)
                        except Exception:
                            pass
                self._active_notes.clear()
        except Exception:
            pass

    def trigger_note(self, pitch: int, velocity: int = 100,
                     duration_ms: int = 140) -> None:
        """One-shot note trigger (preview/audition)."""
        if not self._ok or self._synth is None or self._shutdown:
            return
        try:
            pitch = _clamp(int(pitch), 0, 127)
            velocity = _clamp(int(velocity), 1, 127)
            with self._lock:
                self._synth.noteon(0, pitch, velocity)
            # Schedule note-off after duration
            import threading as _th
            def _off():
                try:
                    with self._lock:
                        if self._synth is not None:
                            self._synth.noteoff(0, pitch)
                except Exception:
                    pass
            _th.Timer(max(0.01, float(duration_ms) / 1000.0), _off).start()
        except Exception:
            pass

    # ── Pull-Source Interface (called from Audio Thread) ──

    def pull(self, frames: int, sr: int) -> Optional[np.ndarray]:
        """Generate audio samples (called from HybridAudioCallback).

        Returns np.ndarray of shape (frames, 2) float32, or None if silent.

        v0.0.21.207 — Slice B: If the engine ``sr`` differs from the
        FluidSynth-configured ``self._sr``, the get_samples() output is
        in the wrong sample rate. Without conversion this produces severe
        aliasing — the same "blechernd" symptom Anno reported. We detect
        this on the first mismatch (rate-limited log) and resample the
        per-block output to engine-sr using ``scipy.signal.resample_poly``.

        For the common Linux setup (ALSA/PipeWire @ 48 kHz, FluidSynth
        configured @ 48 kHz at __init__) this branch is a no-op and the
        code path is identical to v.205. The branch only activates if
        the audio device is at a different SR than the synth.
        """
        if not self._ok or self._synth is None or self._shutdown:
            return None

        try:
            with self._lock:
                # get_samples returns ctypes array of int16, interleaved stereo
                # Length = frames * 2 (L, R, L, R, ...)
                # v0.0.21.207: If engine sr != synth sr, ask FluidSynth for
                # the equivalent number of frames at synth-sr so the
                # resample-to-engine-sr afterwards yields exactly `frames`.
                synth_sr = int(self._sr)
                eng_sr = int(sr) if sr else synth_sr
                if eng_sr != synth_sr and eng_sr > 0:
                    # frames at engine_sr → frames_synth at synth_sr
                    synth_frames = max(1, int(round(frames * synth_sr / eng_sr)))
                else:
                    synth_frames = int(frames)
                raw = self._synth.get_samples(synth_frames)

            if raw is None:
                return None

            # Convert to numpy float32 stereo
            arr = np.frombuffer(raw, dtype=np.int16).copy()

            if len(arr) == 0:
                return None

            # Convert int16 → float32 normalized
            out = arr.astype(np.float32) / 32768.0

            # Reshape to (synth_frames, 2) stereo
            if len(out) >= synth_frames * 2:
                out = out[:synth_frames * 2].reshape(synth_frames, 2)
            else:
                # Pad if too short
                padded = np.zeros(synth_frames * 2, dtype=np.float32)
                padded[:len(out)] = out
                out = padded.reshape(synth_frames, 2)

            # v0.0.21.207: Resample if engine_sr != synth_sr.
            # This is the safety net for SR-mismatch. The polyphase resampler
            # has a built-in anti-alias FIR — output is mathematically clean.
            if eng_sr != synth_sr and eng_sr > 0:
                try:
                    from scipy.signal import resample_poly
                    from math import gcd
                    g = gcd(eng_sr, synth_sr)
                    up = eng_sr // g
                    down = synth_sr // g
                    rs_l = resample_poly(out[:, 0], up, down).astype(np.float32)
                    rs_r = resample_poly(out[:, 1], up, down).astype(np.float32)
                    # Trim/pad to exactly `frames` so the caller gets the
                    # block size it asked for. resample_poly may produce
                    # ±1 sample due to integer rounding.
                    new_n = min(rs_l.shape[0], rs_r.shape[0])
                    if new_n >= frames:
                        out = np.empty((frames, 2), dtype=np.float32)
                        out[:, 0] = rs_l[:frames]
                        out[:, 1] = rs_r[:frames]
                    else:
                        out = np.zeros((frames, 2), dtype=np.float32)
                        out[:new_n, 0] = rs_l[:new_n]
                        out[:new_n, 1] = rs_r[:new_n]
                    # Rate-limited diagnostic log (once per ~5 sec)
                    if not hasattr(self, '_sr_warn_counter'):
                        self._sr_warn_counter = 0
                    self._sr_warn_counter += 1
                    if self._sr_warn_counter % 250 == 1:  # ~once per 5 sec @ 48k/256
                        log.info(
                            f"[SF2-SR] resampling {synth_sr}→{eng_sr} Hz "
                            f"(up={up} down={down}) — anti-alias active. "
                            f"Consider re-creating SF2 engine with sr={eng_sr} "
                            f"to avoid per-block resampling overhead."
                        )
                except Exception as exc:
                    # Defensive: if scipy unavailable or resampling fails,
                    # fall back to returning the raw buffer (will sound wrong
                    # but won't crash). Log once.
                    if not hasattr(self, '_sr_fail_logged'):
                        self._sr_fail_logged = True
                        log.warning(
                            f"[SF2-SR] resample {synth_sr}→{eng_sr} failed "
                            f"({type(exc).__name__}: {exc}) — falling back "
                            f"to raw output (will alias)"
                        )
                    # Trim to expected frames
                    if out.shape[0] > frames:
                        out = out[:frames, :]
                    elif out.shape[0] < frames:
                        padded = np.zeros((frames, 2), dtype=np.float32)
                        padded[:out.shape[0], :] = out
                        out = padded

            # Quick silence check — don't return zeros
            if np.max(np.abs(out)) < 1e-8:
                return None

            return out

        except Exception as exc:
            # Don't spam logs in audio thread
            return None

    # ── Program Change ──

    def set_program(self, bank: int = 0, preset: int = 0) -> None:
        """Change bank/preset (e.g. when user switches in SF2 widget)."""
        if not self._ok or self._synth is None or self._shutdown:
            return
        try:
            with self._lock:
                self._bank = int(bank)
                self._preset = int(preset)
                self._synth.program_select(0, self._sfid, int(bank), int(preset))
        except Exception as exc:
            log.error(f"[SF2-RT] set_program error: {exc}")
    # ── Lifecycle ──

    def shutdown(self) -> None:
        """Clean up FluidSynth resources."""
        self._shutdown = True
        self._ok = False
        try:
            with self._lock:
                if self._synth is not None:
                    try:
                        self.all_notes_off()
                    except Exception:
                        pass
                    try:
                        if self._sfid >= 0:
                            self._synth.sfunload(self._sfid)
                    except Exception:
                        pass
                    try:
                        self._synth.delete()
                    except Exception:
                        pass
                    self._synth = None
                    self._sfid = -1
        except Exception:
            pass
        log.info(f"[SF2-RT] Engine shutdown: track={self._track_id}")
    def __del__(self):
        try:
            if not self._shutdown:
                self.shutdown()
        except Exception:
            pass
