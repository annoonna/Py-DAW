"""plugin_host_state_db.py — SQLite-backed Plugin Host State Cache.

v0.0.20.892 — Phase 28 der SQLite Migration Roadmap.

Persists plugin state blobs (VST2/3/CLAP/LV2/LADSPA) in SQLite for:
- Fast state restore on project load (no re-scan needed)
- Crash recovery (last-known-good state survives crashes)
- Cross-session state persistence independent of project JSON

Table: plugin_states
- track_id + slot_index + plugin_id = unique key
- state_b64: Base64-encoded state blob
- plugin_type: vst2/vst3/clap/lv2/ladspa/builtin
- last_params_json: JSON snapshot of parameter values
- updated_at: timestamp of last update

Usage:
    from pydaw.services.plugin_host_state_db import PluginHostStateDB
    db = PluginHostStateDB.get()
    db.ensure_loaded()

    db.save_state("track_1", 0, "surge-xt", "vst3", state_b64, params)
    state = db.get_state("track_1", 0, "surge-xt")
    db.remove_states_for_track("track_1")
"""

import json
import sqlite3
import logging
import time
from pathlib import Path
from typing import Dict, List, Optional, Any

log = logging.getLogger(__name__)


_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS plugin_states (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    track_id        TEXT NOT NULL,
    slot_index      INTEGER NOT NULL DEFAULT 0,
    plugin_id       TEXT NOT NULL,
    plugin_type     TEXT NOT NULL DEFAULT '',
    plugin_name     TEXT NOT NULL DEFAULT '',
    state_b64       TEXT NOT NULL DEFAULT '',
    last_params_json TEXT NOT NULL DEFAULT '{}',
    project_path    TEXT NOT NULL DEFAULT '',
    updated_at      REAL NOT NULL DEFAULT 0.0,
    UNIQUE(track_id, slot_index, plugin_id)
);

CREATE INDEX IF NOT EXISTS idx_ps_track ON plugin_states(track_id);
CREATE INDEX IF NOT EXISTS idx_ps_plugin ON plugin_states(plugin_id);
CREATE INDEX IF NOT EXISTS idx_ps_project ON plugin_states(project_path);
"""


class PluginHostStateDB:
    """SQLite-backed plugin state cache.

    Singleton. Writes go to disk immediately (WAL mode).
    Reads are cached in RAM for fast lookups.
    """

    _instance: Optional["PluginHostStateDB"] = None

    @classmethod
    def get(cls) -> "PluginHostStateDB":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._db_path = Path.home() / ".config" / "ChronoScaleStudio" / "pydaw.db"
        self._cache: Dict[str, dict] = {}  # key → row dict
        self._loaded = False

    @staticmethod
    def _make_key(track_id: str, slot_index: int, plugin_id: str) -> str:
        return f"{track_id}:{slot_index}:{plugin_id}"

    def ensure_loaded(self) -> None:
        """Create table and load existing states into RAM. Idempotent."""
        if self._loaded:
            return
        try:
            self._db_path.parent.mkdir(parents=True, exist_ok=True)
            conn = sqlite3.connect(str(self._db_path))
            conn.row_factory = sqlite3.Row
            try:
                conn.executescript(_SCHEMA_SQL)
                conn.commit()
                rows = conn.execute(
                    "SELECT * FROM plugin_states ORDER BY updated_at DESC"
                ).fetchall()
                for r in rows:
                    d = dict(r)
                    key = self._make_key(
                        d.get("track_id", ""),
                        int(d.get("slot_index", 0)),
                        d.get("plugin_id", ""),
                    )
                    self._cache[key] = d
            finally:
                conn.close()
            self._loaded = True
            log.info("[PluginHostStateDB] Loaded %d plugin states", len(self._cache))
        except Exception as e:
            log.warning("[PluginHostStateDB] Failed to load: %s", e)

    # ── Write ─────────────────────────────────────────────────────────

    def save_state(
        self,
        track_id: str,
        slot_index: int,
        plugin_id: str,
        plugin_type: str = "",
        state_b64: str = "",
        params: Optional[Dict[str, Any]] = None,
        plugin_name: str = "",
        project_path: str = "",
    ) -> bool:
        """Save or update a plugin state. Returns True on success."""
        if not track_id or not plugin_id:
            return False
        now = time.time()
        params_json = json.dumps(params or {}, ensure_ascii=False)
        key = self._make_key(track_id, slot_index, plugin_id)

        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.execute(
                    """INSERT INTO plugin_states
                       (track_id, slot_index, plugin_id, plugin_type, plugin_name,
                        state_b64, last_params_json, project_path, updated_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                       ON CONFLICT(track_id, slot_index, plugin_id)
                       DO UPDATE SET
                           plugin_type = excluded.plugin_type,
                           plugin_name = excluded.plugin_name,
                           state_b64 = excluded.state_b64,
                           last_params_json = excluded.last_params_json,
                           project_path = excluded.project_path,
                           updated_at = excluded.updated_at
                    """,
                    (track_id, slot_index, plugin_id, plugin_type, plugin_name,
                     state_b64, params_json, project_path, now),
                )
                conn.commit()
            finally:
                conn.close()

            # Update RAM cache
            self._cache[key] = {
                "track_id": track_id,
                "slot_index": slot_index,
                "plugin_id": plugin_id,
                "plugin_type": plugin_type,
                "plugin_name": plugin_name,
                "state_b64": state_b64,
                "last_params_json": params_json,
                "project_path": project_path,
                "updated_at": now,
            }
            return True
        except Exception as e:
            log.debug("[PluginHostStateDB] save_state failed: %s", e)
            return False

    # ── Read ──────────────────────────────────────────────────────────

    def get_state(
        self,
        track_id: str,
        slot_index: int,
        plugin_id: str,
    ) -> Optional[dict]:
        """Get a plugin state dict (with state_b64, params, etc.)."""
        key = self._make_key(track_id, slot_index, plugin_id)
        return self._cache.get(key)

    def get_states_for_track(self, track_id: str) -> List[dict]:
        """Get all plugin states for a track."""
        return [v for v in self._cache.values() if v.get("track_id") == track_id]

    def get_states_for_project(self, project_path: str) -> List[dict]:
        """Get all plugin states for a project path."""
        return [v for v in self._cache.values() if v.get("project_path") == project_path]

    def get_all_states(self) -> List[dict]:
        """Get all cached states."""
        return list(self._cache.values())

    def get_state_b64(
        self,
        track_id: str,
        slot_index: int,
        plugin_id: str,
    ) -> str:
        """Get just the Base64 state blob. Returns '' if not found."""
        entry = self.get_state(track_id, slot_index, plugin_id)
        if entry:
            return str(entry.get("state_b64", ""))
        return ""

    def get_params(
        self,
        track_id: str,
        slot_index: int,
        plugin_id: str,
    ) -> Dict[str, Any]:
        """Get last known parameter values. Returns {} if not found."""
        entry = self.get_state(track_id, slot_index, plugin_id)
        if entry:
            try:
                return json.loads(entry.get("last_params_json", "{}"))
            except Exception:
                pass
        return {}

    # ── Delete ────────────────────────────────────────────────────────

    def remove_state(
        self,
        track_id: str,
        slot_index: int,
        plugin_id: str,
    ) -> None:
        """Remove a single plugin state."""
        key = self._make_key(track_id, slot_index, plugin_id)
        self._cache.pop(key, None)
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.execute(
                    "DELETE FROM plugin_states WHERE track_id=? AND slot_index=? AND plugin_id=?",
                    (track_id, slot_index, plugin_id),
                )
                conn.commit()
            finally:
                conn.close()
        except Exception as e:
            log.debug("[PluginHostStateDB] remove_state failed: %s", e)

    def remove_states_for_track(self, track_id: str) -> int:
        """Remove all plugin states for a track. Returns count removed."""
        keys_to_remove = [k for k, v in self._cache.items() if v.get("track_id") == track_id]
        for k in keys_to_remove:
            self._cache.pop(k, None)
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                cur = conn.execute(
                    "DELETE FROM plugin_states WHERE track_id=?", (track_id,)
                )
                conn.commit()
                return cur.rowcount
            finally:
                conn.close()
        except Exception as e:
            log.debug("[PluginHostStateDB] remove_states_for_track failed: %s", e)
        return len(keys_to_remove)

    def remove_states_for_project(self, project_path: str) -> int:
        """Remove all plugin states for a project. Returns count removed."""
        keys_to_remove = [k for k, v in self._cache.items() if v.get("project_path") == project_path]
        for k in keys_to_remove:
            self._cache.pop(k, None)
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                cur = conn.execute(
                    "DELETE FROM plugin_states WHERE project_path=?", (project_path,)
                )
                conn.commit()
                return cur.rowcount
            finally:
                conn.close()
        except Exception as e:
            log.debug("[PluginHostStateDB] remove_states_for_project failed: %s", e)
        return len(keys_to_remove)

    def clear_all(self) -> None:
        """Remove all plugin states."""
        self._cache.clear()
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.execute("DELETE FROM plugin_states")
                conn.commit()
            finally:
                conn.close()
        except Exception as e:
            log.debug("[PluginHostStateDB] clear_all failed: %s", e)

    # ── Maintenance ───────────────────────────────────────────────────

    def prune_old_states(self, max_age_days: int = 90) -> int:
        """Remove plugin states older than max_age_days. Returns count removed."""
        cutoff = time.time() - (max_age_days * 86400)
        keys_to_remove = [
            k for k, v in self._cache.items()
            if float(v.get("updated_at", 0)) < cutoff
        ]
        for k in keys_to_remove:
            self._cache.pop(k, None)
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                cur = conn.execute(
                    "DELETE FROM plugin_states WHERE updated_at < ?", (cutoff,)
                )
                conn.commit()
                removed = cur.rowcount
                if removed > 0:
                    log.info("[PluginHostStateDB] Pruned %d old states (>%d days)",
                             removed, max_age_days)
                return removed
            finally:
                conn.close()
        except Exception as e:
            log.debug("[PluginHostStateDB] prune failed: %s", e)
        return len(keys_to_remove)

    def stats(self) -> Dict[str, Any]:
        """Return statistics about the state cache."""
        total_size = sum(len(v.get("state_b64", "")) for v in self._cache.values())
        by_type: Dict[str, int] = {}
        for v in self._cache.values():
            pt = v.get("plugin_type", "unknown")
            by_type[pt] = by_type.get(pt, 0) + 1
        return {
            "total_states": len(self._cache),
            "total_blob_size_bytes": total_size,
            "by_type": by_type,
        }
