"""ki_counterpoint.py — Counterpoint & Fugue Engine (v0.0.20.985)

KK2: Kontrapunkt-Engine (Bach-Fokus)

Implements classical counterpoint rules for automatic generation:
  - Cantus Firmus generation
  - Species counterpoint (1:1, 2:1, 4:1, free)
  - Fugue: Subject → Answer → Episodes → Stretto
  - Canon: Retrograde, Inversion, Augmentation, Diminution
  - Chorale harmonization (Bach-style 4-part writing)
  - Invention (2-voice, 3-voice Sinfonia)
  - Passacaglia/Chaconne (ostinato variations)

All generation is rule-based (no neural networks).

Usage:
    from pydaw.services.ki_counterpoint import CounterpointEngine

    cp = CounterpointEngine(root="C", mode="major")
    melody = cp.generate_cantus_firmus(length=12)
    counterpoint = cp.add_counterpoint(melody, species=1)
    fugue = cp.generate_fugue(subject=[60, 62, 64, 65, 67])
"""

import random
import logging
from dataclasses import dataclass, field
from typing import List, Optional, Tuple, Dict
from enum import Enum

log = logging.getLogger(__name__)

# Import theory module
try:
    from .ki_composition_theory import (
        Scale, Chord, is_consonant, is_perfect_consonance,
        note_name_to_pc, pc_to_note_name, midi_to_name,
    )
except ImportError:
    from pydaw.services.ki_composition_theory import (
        Scale, Chord, is_consonant, is_perfect_consonance,
        note_name_to_pc, pc_to_note_name, midi_to_name,
    )


# ═══════════════════════════════════════════════════════════════
# Cantus Firmus Generator
# ═══════════════════════════════════════════════════════════════

class CantusGenerator:
    """Generate a Cantus Firmus (base melody) following classical rules.

    Rules:
      - Stay within an octave (±1 note)
      - Mostly stepwise motion
      - Single climax point
      - Start and end on tonic
      - No repeated notes
      - Approach final by step
    """

    def __init__(self, scale: Scale, octave: int = 4):
        self.scale = scale
        self.octave = octave
        self.tonic = scale.degree_to_midi(1, 0)

    def generate(self, length: int = 12) -> List[int]:
        """Generate a cantus firmus melody."""
        if length < 5:
            length = 5

        notes = [self.tonic]  # Start on tonic
        scale_notes = self.scale.get_notes(octaves=2)
        # Shift to correct octave
        base = self.octave * 12
        scale_notes = [n + base for n in scale_notes if 0 <= n + base <= 127]

        # Plan climax position (60-80% through)
        climax_pos = int(length * random.uniform(0.6, 0.8))
        climax_note = max(scale_notes[:8])  # Highest note in range

        for i in range(1, length - 1):
            prev = notes[-1]

            if i == climax_pos:
                notes.append(climax_note)
                continue

            # Prefer stepwise motion (80% probability)
            candidates = []
            for n in scale_notes:
                interval = abs(n - prev)
                if interval == 0:
                    continue  # no repeated notes
                if n in notes and n != self.tonic:
                    continue  # avoid repetition (except tonic)

                # Weight by interval size
                if interval <= 2:
                    candidates.extend([n] * 5)  # step = high weight
                elif interval <= 4:
                    candidates.extend([n] * 2)  # third = medium
                elif interval <= 7:
                    candidates.append(n)  # up to fifth = low

            if not candidates:
                candidates = [n for n in scale_notes if n != prev]

            if candidates:
                notes.append(random.choice(candidates))

        # End on tonic, approach by step
        penultimate = self.scale.degree_to_midi(2, 0) + base  # Re (step above)
        if notes[-1] != penultimate:
            notes[-1] = penultimate
        notes.append(self.tonic)

        return notes


# ═══════════════════════════════════════════════════════════════
# Species Counterpoint
# ═══════════════════════════════════════════════════════════════

class SpeciesCounterpoint:
    """Generate counterpoint against a cantus firmus.

    Species:
      1 — Note against note (1:1)
      2 — Two notes against one (2:1)
      3 — Four notes against one (4:1)
      4 — Suspensions (syncopated)
      5 — Free counterpoint (mixed)
    """

    def __init__(self, scale: Scale):
        self.scale = scale
        self.scale_pcs = set(n % 12 for n in scale.get_notes())

    def first_species(self, cantus: List[int], above: bool = True) -> List[int]:
        """1:1 counterpoint — one note against one."""
        counterpoint = []
        direction = 1 if above else -1

        for i, cf_note in enumerate(cantus):
            candidates = self._consonant_notes(cf_note, above)

            if i == 0 or i == len(cantus) - 1:
                # Start and end on perfect consonance (unison, 5th, 8ve)
                candidates = [n for n in candidates
                              if abs(n - cf_note) % 12 in (0, 7)]
                if not candidates:
                    candidates = [cf_note + direction * 12]  # octave

            # Avoid parallel fifths and octaves
            if counterpoint:
                prev_cp = counterpoint[-1]
                prev_cf = cantus[i - 1]
                candidates = [
                    n for n in candidates
                    if not self._is_parallel(prev_cf, cf_note, prev_cp, n)
                ]

            # Prefer stepwise motion
            if counterpoint:
                prev = counterpoint[-1]
                step_candidates = [n for n in candidates if abs(n - prev) <= 4]
                if step_candidates:
                    candidates = step_candidates

            if candidates:
                counterpoint.append(random.choice(candidates))
            else:
                # Fallback: octave above/below
                counterpoint.append(cf_note + direction * 12)

        return counterpoint

    def second_species(self, cantus: List[int], above: bool = True) -> List[int]:
        """2:1 counterpoint — two notes per cantus note."""
        result = []
        for i, cf_note in enumerate(cantus):
            # Strong beat: consonance
            consonant = self._consonant_notes(cf_note, above)
            if result:
                prev = result[-1]
                step = [n for n in consonant if abs(n - prev) <= 4]
                n1 = random.choice(step if step else consonant)
            else:
                n1 = random.choice(consonant)
            result.append(n1)

            # Weak beat: can be dissonant if passing tone
            if i < len(cantus) - 1:
                next_cf = cantus[i + 1]
                passing = (n1 + random.choice([-1, 1, -2, 2]))
                # Keep in scale
                if passing % 12 in self.scale_pcs:
                    result.append(passing)
                else:
                    result.append(n1 + random.choice([-2, 2]))

        return result

    def _consonant_notes(self, cf_note: int, above: bool) -> List[int]:
        """Get scale notes consonant with the cantus firmus note."""
        notes = []
        low = cf_note - 5 if not above else cf_note
        high = cf_note + 16 if above else cf_note + 5

        for n in range(low, high):
            if n % 12 not in self.scale_pcs:
                continue
            interval = abs(n - cf_note) % 12
            if is_consonant(interval):
                notes.append(n)
        return notes if notes else [cf_note + (12 if above else -12)]

    @staticmethod
    def _is_parallel(cf1: int, cf2: int, cp1: int, cp2: int) -> bool:
        """Check for parallel fifths or octaves (forbidden)."""
        int1 = abs(cp1 - cf1) % 12
        int2 = abs(cp2 - cf2) % 12
        if int1 == int2 and int1 in (0, 7):  # unison/octave or fifth
            # Same direction of motion
            cf_dir = cf2 - cf1
            cp_dir = cp2 - cp1
            if (cf_dir > 0 and cp_dir > 0) or (cf_dir < 0 and cp_dir < 0):
                return True
        return False


# ═══════════════════════════════════════════════════════════════
# Fugue Generator
# ═══════════════════════════════════════════════════════════════

@dataclass
class FugueVoice:
    """A voice in a fugue."""
    name: str
    notes: List[int] = field(default_factory=list)
    start_beat: float = 0.0


@dataclass
class FugueResult:
    """Complete fugue result."""
    subject: List[int]
    answer: List[int]
    voices: List[FugueVoice]
    num_voices: int
    key: str
    description: str


class FugueGenerator:
    """Generate fugues following classical rules.

    Structure:
      Exposition: Subject → Answer → Subject → (Answer)
      Episode: Modulatory passage using fragments
      Development: Subject entries in related keys
      Stretto: Overlapping entries (optional)
      Final: Return to tonic
    """

    def __init__(self, scale: Scale):
        self.scale = scale

    def generate_answer(self, subject: List[int], tonal: bool = True) -> List[int]:
        """Generate the fugue answer (transposed to dominant).

        Args:
            subject: MIDI notes of the subject
            tonal: True for tonal answer (adjusted at boundaries),
                   False for real answer (exact transposition)
        """
        if not subject:
            return []

        # Transpose up a fifth (7 semitones)
        answer = [n + 7 for n in subject]

        if tonal:
            # Tonal answer: adjust the first note if it starts on tonic
            root_pc = self.scale.root_pc
            dom_pc = (root_pc + 7) % 12
            if subject[0] % 12 == root_pc:
                answer[0] = subject[0] + 7  # tonic → dominant
            elif subject[0] % 12 == dom_pc:
                answer[0] = subject[0] + 5  # dominant → tonic (up a 4th)

        return answer

    def generate_countersubject(self, subject: List[int]) -> List[int]:
        """Generate a countersubject using first-species counterpoint."""
        cp = SpeciesCounterpoint(self.scale)
        return cp.first_species(subject, above=True)

    def generate(self, subject: List[int], num_voices: int = 3) -> FugueResult:
        """Generate a complete fugue exposition.

        Args:
            subject: MIDI notes of the fugue subject
            num_voices: Number of voices (2-4)
        """
        num_voices = max(2, min(4, num_voices))
        answer = self.generate_answer(subject)
        counter_subject = self.generate_countersubject(subject)

        voice_names = ["Soprano", "Alto", "Tenor", "Bass"][-num_voices:]
        voices = []

        for i in range(num_voices):
            voice = FugueVoice(name=voice_names[i])
            voice.start_beat = i * len(subject)

            # Alternate subject and answer
            if i % 2 == 0:
                # Transpose subject to voice range
                octave_shift = (num_voices - 1 - i) * -12
                voice.notes = [n + octave_shift for n in subject]
            else:
                octave_shift = (num_voices - 1 - i) * -12
                voice.notes = [n + octave_shift for n in answer]

            voices.append(voice)

        key_name = f"{pc_to_note_name(self.scale.root_pc)} {self.scale.mode}"

        return FugueResult(
            subject=subject,
            answer=answer,
            voices=voices,
            num_voices=num_voices,
            key=key_name,
            description=f"Fuge in {key_name}, {num_voices} Stimmen, "
                        f"Subjekt: {len(subject)} Noten",
        )

    def generate_stretto(self, subject: List[int],
                         overlap: int = 2) -> List[FugueVoice]:
        """Generate stretto (overlapping subject entries)."""
        voices = []
        for i in range(3):
            voice = FugueVoice(name=f"Stretto-{i+1}")
            voice.start_beat = i * overlap
            octave_shift = -i * 12
            voice.notes = [n + octave_shift for n in subject]
            voices.append(voice)
        return voices


# ═══════════════════════════════════════════════════════════════
# Canon Generator
# ═══════════════════════════════════════════════════════════════

class CanonType(Enum):
    DIRECT = "direct"           # Same melody, delayed
    RETROGRADE = "retrograde"   # Backwards
    INVERSION = "inversion"     # Intervals flipped
    RETROGRADE_INVERSION = "retrograde_inversion"
    AUGMENTATION = "augmentation"   # Note values doubled
    DIMINUTION = "diminution"       # Note values halved


class CanonGenerator:
    """Generate canons in various styles."""

    @staticmethod
    def generate(melody: List[int], canon_type: CanonType = CanonType.DIRECT,
                 delay_beats: int = 4, interval: int = 0) -> List[int]:
        """Generate the follower voice of a canon.

        Args:
            melody: Leader melody (MIDI notes)
            canon_type: Type of canon transformation
            delay_beats: Delay of follower (in beats)
            interval: Transposition interval (semitones)
        """
        if not melody:
            return []

        if canon_type == CanonType.DIRECT:
            return [n + interval for n in melody]

        elif canon_type == CanonType.RETROGRADE:
            return [n + interval for n in reversed(melody)]

        elif canon_type == CanonType.INVERSION:
            axis = melody[0]
            return [2 * axis - n + interval for n in melody]

        elif canon_type == CanonType.RETROGRADE_INVERSION:
            axis = melody[0]
            inverted = [2 * axis - n for n in melody]
            return [n + interval for n in reversed(inverted)]

        elif canon_type == CanonType.AUGMENTATION:
            # Double each note (repeat it)
            result = []
            for n in melody:
                result.extend([n + interval, n + interval])
            return result

        elif canon_type == CanonType.DIMINUTION:
            # Take every other note
            return [melody[i] + interval for i in range(0, len(melody), 2)]

        return melody


# ═══════════════════════════════════════════════════════════════
# Chorale Harmonization (Bach-style 4-part writing)
# ═══════════════════════════════════════════════════════════════

class ChoraleHarmonizer:
    """Harmonize a soprano melody in Bach chorale style.

    4-part SATB writing with classical voice leading:
      - Soprano: given melody
      - Alto: fill inner voice (stay in range A3–D5)
      - Tenor: fill inner voice (stay in range C3–G4)
      - Bass: harmonic foundation (stay in range E2–D4)
    """

    SOPRANO_RANGE = (60, 79)  # C4–G5
    ALTO_RANGE = (55, 72)     # G3–C5
    TENOR_RANGE = (48, 67)    # C3–G4
    BASS_RANGE = (40, 60)     # E2–C4

    def __init__(self, scale: Scale):
        self.scale = scale
        self.scale_pcs = set(n % 12 for n in scale.get_notes())

    def harmonize(self, soprano: List[int]) -> Dict[str, List[int]]:
        """Generate SATB harmonization of a soprano melody.

        Returns dict with keys 'soprano', 'alto', 'tenor', 'bass'.
        """
        alto = []
        tenor = []
        bass = []

        for i, s_note in enumerate(soprano):
            # Determine chord (simplified: assign chord by degree)
            degree = self.scale.degree_of(s_note)
            if degree is None:
                degree = 1

            chord = Chord.from_scale(self.scale, degree)
            chord_pcs = set(chord.pitch_classes)

            # Bass: chord root
            b_note = self._find_in_range(chord.root_pc, self.BASS_RANGE,
                                          bass[-1] if bass else 48)
            bass.append(b_note)

            # Tenor: chord third or fifth
            remaining = chord_pcs - {s_note % 12, b_note % 12}
            t_pc = remaining.pop() if remaining else chord.pitch_classes[1]
            t_note = self._find_in_range(t_pc, self.TENOR_RANGE,
                                          tenor[-1] if tenor else 55)
            tenor.append(t_note)

            # Alto: remaining chord tone
            remaining2 = chord_pcs - {s_note % 12, b_note % 12, t_note % 12}
            a_pc = remaining2.pop() if remaining2 else chord.pitch_classes[2 % len(chord.pitch_classes)]
            a_note = self._find_in_range(a_pc, self.ALTO_RANGE,
                                          alto[-1] if alto else 62)
            alto.append(a_note)

        return {
            "soprano": soprano,
            "alto": alto,
            "tenor": tenor,
            "bass": bass,
        }

    @staticmethod
    def _find_in_range(pc: int, note_range: Tuple[int, int],
                       prev_note: int) -> int:
        """Find the closest MIDI note with given pitch class in range."""
        low, high = note_range
        candidates = [n for n in range(low, high + 1) if n % 12 == pc]
        if not candidates:
            return prev_note

        # Prefer closest to previous note (voice leading)
        return min(candidates, key=lambda n: abs(n - prev_note))


# ═══════════════════════════════════════════════════════════════
# Main Interface
# ═══════════════════════════════════════════════════════════════

class CounterpointEngine:
    """Unified interface for all counterpoint generation."""

    def __init__(self, root: str = "C", mode: str = "major"):
        self.scale = Scale(root=root, mode=mode)
        self.cantus = CantusGenerator(self.scale)
        self.species = SpeciesCounterpoint(self.scale)
        self.fugue = FugueGenerator(self.scale)
        self.chorale = ChoraleHarmonizer(self.scale)

    def generate_cantus_firmus(self, length: int = 12) -> List[int]:
        return self.cantus.generate(length)

    def add_counterpoint(self, melody: List[int], species: int = 1,
                         above: bool = True) -> List[int]:
        if species == 1:
            return self.species.first_species(melody, above)
        elif species == 2:
            return self.species.second_species(melody, above)
        else:
            return self.species.first_species(melody, above)

    def generate_fugue(self, subject: List[int],
                       num_voices: int = 3) -> FugueResult:
        return self.fugue.generate(subject, num_voices)

    def generate_canon(self, melody: List[int],
                       canon_type: CanonType = CanonType.DIRECT,
                       interval: int = 0) -> List[int]:
        return CanonGenerator.generate(melody, canon_type, interval=interval)

    def harmonize_chorale(self, soprano: List[int]) -> Dict[str, List[int]]:
        return self.chorale.harmonize(soprano)
