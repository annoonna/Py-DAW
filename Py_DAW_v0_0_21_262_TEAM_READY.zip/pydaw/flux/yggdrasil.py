"""
pydaw.flux.yggdrasil
====================

Yggdrasil ist der Weltenbaum — in FLUX die Wurzel-Metapher für jeden
Patch. Jedes Modul gehört zu einer "Familie" mythologischer Götter,
die in WAECHTER für **Sicherheits**-Aufgaben stehen und in FLUX für
**Klang**-Aufgaben (mit denselben Farb-Codes für visuelle Konsistenz).

Diese Datei ist die *Single Source of Truth* für Modul-Namen und
ihre visuelle Identität (Farbe, Glyphe, Kategorie). Wer in einer
Folge-Session ein neues Modul anlegt, registriert es **hier**.

Designprinzip
-------------

Familien-Namen aus der nordischen Mythologie wie in WAECHTER —
plus eine Erweiterung um klang-spezifische Götter:

    WAECHTER (Sicherheit)         FLUX (Klang)
    ─────────────────────         ─────────────────────
    Argus     pcap/DNS            (übernommen für I/O)
    Heimdall  Master-Daemon       Heimdall   Mixer/Master
    Odin      KI-Decision         Odin       KI-Patcher
    Mimir     FTS5/IOCs           Mimir      Memory/Buffer
    Tyr       Honeypot            (übernommen für Test-Signale)
    Walkuere  Notify              Walkuere   Side-Chain/Trigger
    Zerberus  inotify/FIM         Zerberus   File-Sample-Loader

    NEU für Klang:
    Bragi     Gott der Dichtkunst & Musik   → Oszillatoren, Synths
    Loki      Trickster, Wandler            → LFO, Modulatoren
    Freyr     Wachstum, Fruchtbarkeit       → Hüllkurven (ADSR)
    Forseti   Gerechtigkeit, Balance        → Filter, EQ
    Thor      Donner, Kraft                 → Distortion, Drive
    Iduna     Erneuerung, Zeit              → Delay, Reverb
    Skadi     Winter, Kälte                 → Chorus, Flanger, Phaser
    Vidar     Stille, Vergeltung            → Gate, Limiter, Compressor
    Eir       Heilung                       → Denoise, Restore
    Sif       Goldenes Haar (Harmonie)      → Pitch, Harmonizer
    Njörd     Meer, Ströme                  → Spectral, Filterbank
    Hel       Tod, Stille                   → Mute, Kill-Switch
    Sleipnir  Achtbeiniges Pferd            → Multi-Out Splitter
    Fenrir    Wolf der Verschlingung        → Bit-Crush, Decimate
    Yggdrasil Weltenbaum                    → Patch-Container selbst

Farben (übernommen aus WAECHTER für visuelle Konsistenz)
--------------------------------------------------------

    WAECHTER-Farbcode                FLUX-Verwendung
    ─────────────────                ───────────────
    Cyan  (#3df0e0)   Heimdall       I/O & Routing
    Lila  (#a78bfa)   Odin           KI & Decision
    Magenta (#ec4899) Mimir          Memory/Buffer/FX-Time
    Orange (#f59e0b)  Zerberus       File/Sample/Source
    Grün  (#10b981)   Argus          Oscillator/Synth (Bragi)
    Rot/Pink (#ef4444) Tyr           Test/Trigger/Side-Chain
    Gelb  (#fbbf24)   Walkuere       Notify/Modulator (Loki)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class FluxColor(str, Enum):
    """Wächter-Farbpalette — wiederverwendet für FLUX-Module.

    String-Enum, damit man direkt `color.value` als CSS/Qt-Farbe
    nutzen kann.
    """
    CYAN     = "#3df0e0"   # Heimdall  / I/O / Master
    PURPLE   = "#a78bfa"   # Odin      / KI / Decision
    MAGENTA  = "#ec4899"   # Mimir     / Memory / Time-FX
    ORANGE   = "#f59e0b"   # Zerberus  / Sample / Source
    GREEN    = "#10b981"   # Bragi     / Oscillator / Synth
    RED      = "#ef4444"   # Tyr       / Trigger / Test
    YELLOW   = "#fbbf24"   # Loki      / Modulator / Walkuere
    BLUE     = "#3b82f6"   # Forseti   / Filter / EQ
    AMBER    = "#d97706"   # Thor      / Distortion / Drive
    INDIGO   = "#6366f1"   # Iduna     / Reverb / Delay
    TEAL     = "#14b8a6"   # Skadi     / Chorus / Flanger
    SLATE    = "#64748b"   # Vidar     / Gate / Limiter
    PINK     = "#f472b6"   # Sif       / Pitch / Harmonizer
    EMERALD  = "#34d399"   # Njörd     / Spectral / Filterbank
    ROSE     = "#fb7185"   # Hel       / Mute / Stille
    LIME     = "#a3e635"   # Sleipnir  / Splitter / Multi-Out
    FUCHSIA  = "#d946ef"   # Fenrir    / Bit-Crush / Decimate
    # v0.0.21.221 — Rune-Realm Familien-Farben (Phase 3 Norns):
    # VIOLET ist tiefer-purple als Vör's #a78bfa, sichtbar distinct
    # aber im selben Realm. Module-Header VIOLET, Ports/Cables bleiben
    # PURPLE (KIND_COLORS[RUNE] = #a78bfa) — der Realm hat eine Farbe,
    # die Familien innerhalb haben Variationen.
    VIOLET   = "#8b5cf6"   # Norns     / Time / Sequencing
    # v0.0.21.225 — Phase 4 Rune-Realm: Ullr (Math/Expr) + Ratatosk
    # (Cross-Realm-Bridges). STONE ist warm-grau für präzise Mathematik
    # (Ullrs Bogenschützen-Präzision). SKY ist hell-türkis für die
    # Eichhörnchen-Boten zwischen den Realms.
    STONE    = "#78716c"   # Ullr      / Math / Expr
    SKY      = "#38bdf8"   # Ratatosk  / Cross-Realm-Bridges
    # v0.0.21.228 — Phase 6 Rune-Realm: Hermod (Network / OSC).
    # AQUA ist heller-cyan für Network-Datenfluss (Hermod ist der
    # schnellste Bote der Götter, der zwischen Welten reitet — passt
    # zu Network-IO).
    AQUA     = "#22d3ee"   # Hermod    / Network / OSC


class FluxCategory(str, Enum):
    """Hochlevel-Kategorien für die Modul-Palette."""
    SOURCE      = "source"       # Klang-Erzeugung (Bragi)
    MODULATOR   = "modulator"    # LFO, Envelope (Loki, Freyr)
    FILTER      = "filter"       # Filter, EQ (Forseti)
    DRIVE       = "drive"        # Distortion, Saturation (Thor)
    TIME        = "time"         # Delay, Reverb (Iduna)
    SPACE       = "space"        # Chorus, Flanger, Phaser (Skadi)
    DYNAMICS    = "dynamics"     # Gate, Compressor, Limiter (Vidar)
    PITCH       = "pitch"        # Pitch-Shift, Harmonizer (Sif)
    SPECTRAL    = "spectral"     # Filterbank, Vocoder (Njörd)
    UTILITY     = "utility"      # Mixer, Splitter, Meter (Heimdall, Sleipnir)
    SAMPLE      = "sample"       # File-Loader, SF2 (Zerberus)
    AI          = "ai"           # KI-Patcher, Auto-Match (Odin)
    MEMORY      = "memory"       # Buffer, Looper (Mimir)
    TRIGGER     = "trigger"      # Side-Chain, Test-Tone (Tyr)
    DESTROY     = "destroy"      # Bit-Crush, Decimate (Fenrir)
    SILENCE     = "silence"      # Mute, Gate-Kill (Hel)
    # v0.0.21.195 — UI-Widget-Kategorie für Pure-Data-/Max-/Bitwig-
    # Style Module: Knob, Slider, Toggle, Bang, NumberBox, Comment, …
    # Diese Module HABEN KEIN DSP — sie produzieren CV-Werte die an
    # andere Module weitergeleitet werden (Python-side Bridge).
    CONTROL     = "control"      # UI-Widgets als Module (Frigg)
    # v0.0.21.215 — Rune-Realm-Kategorie für Message-Passing-Module
    # (Pure-Data-/Max-/Reaktor-Core-Style). Module dieser Kategorie
    # arbeiten mit diskreten Messages (PortKind.RUNE) statt mit Audio
    # oder CV. Erste Familie: Vör (Routing & Logic). Geplant: Norns
    # (Time/Sequencing), Ullr (Math/Expr), Ratatosk (Realm-Bridges),
    # Hoenir (Subpatch-Container).
    MESSAGE     = "message"      # Rune-Realm — Message-Passing


@dataclass(frozen=True)
class GodDescriptor:
    """Beschreibt eine Gott-Familie: Name, Farbe, Default-Kategorie, Glyphe."""
    name: str                       # "Bragi"
    color: FluxColor                # FluxColor.GREEN
    category: FluxCategory          # FluxCategory.SOURCE
    glyph: str                      # "𝆒"  (Notenschlüssel)
    description: str
    waechter_origin: Optional[str] = None  # Ursprung in WAECHTER, falls geteilt
    # v0.0.21.195 — UI-Widget-Marker. Wenn True, sind alle Module dieser
    # Familie reine Python-side Control-Widgets (Knob, Slider, Toggle,
    # Bang, NumberBox, Comment). Die Rust-Engine kennt sie NICHT —
    # `flux_rust_sync.build_sync_patch_command()` filtert sie raus, und
    # `UiModuleBridge` übersetzt ihre Werte direkt in Param-Updates an
    # verbundene DSP-Module.
    is_ui_widget: bool = False


# ─── Götter-Registry ──────────────────────────────────────────────
# Diese Liste ist die Single Source of Truth.  Erweitern, nie löschen.

GODS: dict[str, GodDescriptor] = {
    # WAECHTER-Erbe (selbe Bedeutung in FLUX)
    "Heimdall": GodDescriptor(
        name="Heimdall", color=FluxColor.CYAN, category=FluxCategory.UTILITY,
        glyph="⌬", description="Wächter der Bifröst-Brücke — Master-Out, Mixer, zentrale Routing-Knoten.",
        waechter_origin="Master-Daemon",
    ),
    "Odin": GodDescriptor(
        name="Odin", color=FluxColor.PURPLE, category=FluxCategory.AI,
        glyph="ᚠ", description="Allvater — KI-Module, automatisches Patchen, Cluster-Erkennung.",
        waechter_origin="KI-Decision",
    ),
    "Mimir": GodDescriptor(
        name="Mimir", color=FluxColor.MAGENTA, category=FluxCategory.MEMORY,
        glyph="ᛗ", description="Brunnen der Weisheit — Audio-Puffer, Looper, Tape-Delay.",
        waechter_origin="FTS5/IOCs",
    ),
    "Tyr": GodDescriptor(
        name="Tyr", color=FluxColor.RED, category=FluxCategory.TRIGGER,
        glyph="ᛏ", description="Gott der Wahrheit — Test-Töne, Side-Chain-Triggers, Ground-Truth-Signale.",
        waechter_origin="Honeypot",
    ),
    "Walkuere": GodDescriptor(
        name="Walkuere", color=FluxColor.YELLOW, category=FluxCategory.MODULATOR,
        glyph="ᚹ", description="Schildmaiden — wählen Signale aus, Trigger-Logik, Notify-Module.",
        waechter_origin="Notify/Webhook",
    ),
    "Zerberus": GodDescriptor(
        name="Zerberus", color=FluxColor.ORANGE, category=FluxCategory.SAMPLE,
        glyph="ᚲ", description="Wächter der Tore — File-Sample-Loader, SF2, Audio-Disk-IO.",
        waechter_origin="inotify/FIM",
    ),
    "Argus": GodDescriptor(
        name="Argus", color=FluxColor.GREEN, category=FluxCategory.UTILITY,
        glyph="◉", description="Hundertäugiger Wächter — Audio-Input, Mikrofon, Live-Capture.",
        waechter_origin="pcap/DNS",
    ),

    # NEUE Klang-Götter
    "Bragi": GodDescriptor(
        name="Bragi", color=FluxColor.GREEN, category=FluxCategory.SOURCE,
        glyph="𝆒", description="Gott der Dichtkunst — Oszillatoren, Wavetable, FM-Synths.",
    ),
    "Loki": GodDescriptor(
        name="Loki", color=FluxColor.YELLOW, category=FluxCategory.MODULATOR,
        glyph="ᛚ", description="Wandler — LFOs, Random-Modulation, S&H, Chaos.",
    ),
    "Freyr": GodDescriptor(
        name="Freyr", color=FluxColor.YELLOW, category=FluxCategory.MODULATOR,
        glyph="ᚠ", description="Fruchtbarkeit, Wachstum — ADSR-Envelopes, AHDSR, DAHDSR.",
    ),
    "Forseti": GodDescriptor(
        name="Forseti", color=FluxColor.BLUE, category=FluxCategory.FILTER,
        glyph="ᚦ", description="Gott der Gerechtigkeit — Filter (LP/HP/BP/Notch), EQ, Tilt.",
    ),
    "Thor": GodDescriptor(
        name="Thor", color=FluxColor.AMBER, category=FluxCategory.DRIVE,
        glyph="ᚦ", description="Donner — Distortion, Saturation, Tube, Fuzz, Overdrive.",
    ),
    "Iduna": GodDescriptor(
        name="Iduna", color=FluxColor.INDIGO, category=FluxCategory.TIME,
        glyph="ᛁ", description="Hüterin der Erneuerungs-Äpfel — Delay, Reverb, Echo.",
    ),
    "Skadi": GodDescriptor(
        name="Skadi", color=FluxColor.TEAL, category=FluxCategory.SPACE,
        glyph="ᛋ", description="Skigöttin, kalt und weit — Chorus, Flanger, Phaser, Stereo-Imager.",
    ),
    "Vidar": GodDescriptor(
        name="Vidar", color=FluxColor.SLATE, category=FluxCategory.DYNAMICS,
        glyph="ᚢ", description="Stille Vergeltung — Gate, Compressor, Limiter, De-Esser.",
    ),
    "Eir": GodDescriptor(
        name="Eir", color=FluxColor.SLATE, category=FluxCategory.DYNAMICS,
        glyph="ᛖ", description="Heilerin — Denoise, Declick, Hum-Removal, Restoration.",
    ),
    "Sif": GodDescriptor(
        name="Sif", color=FluxColor.PINK, category=FluxCategory.PITCH,
        glyph="ᛊ", description="Goldenes Haar — Pitch-Shift, Harmonizer, Auto-Tune.",
    ),
    "Njörd": GodDescriptor(
        name="Njörd", color=FluxColor.EMERALD, category=FluxCategory.SPECTRAL,
        glyph="ᚾ", description="Gott der Meere — Filterbank, Vocoder, Spectral-Freeze.",
    ),
    "Hel": GodDescriptor(
        name="Hel", color=FluxColor.ROSE, category=FluxCategory.SILENCE,
        glyph="ᚺ", description="Herrin der Unterwelt — Mute, Kill-Switch, hartes Ducking.",
    ),
    "Sleipnir": GodDescriptor(
        name="Sleipnir", color=FluxColor.LIME, category=FluxCategory.UTILITY,
        glyph="ᛇ", description="Achtbeiniges Pferd — Splitter, Mux, Multi-Out, Round-Robin.",
    ),
    "Fenrir": GodDescriptor(
        name="Fenrir", color=FluxColor.FUCHSIA, category=FluxCategory.DESTROY,
        glyph="ᚠ", description="Wolf der Verschlingung — Bit-Crush, Decimator, Sample-Reduction.",
    ),
    "Yggdrasil": GodDescriptor(
        name="Yggdrasil", color=FluxColor.CYAN, category=FluxCategory.UTILITY,
        glyph="🜨", description="Der Weltenbaum — der Patch-Container selbst, Sub-Patch, Container-Modul.",
    ),

    # v0.0.21.195 — UI-Widgets als Module (Pure-Data-/Max-/Bitwig-Style)
    "Frigg": GodDescriptor(
        name="Frigg", color=FluxColor.CYAN, category=FluxCategory.CONTROL,
        glyph="❉",
        description=(
            "Königin der Asen — UI-Control-Widgets (Knob, Slider, Toggle, "
            "Bang, NumberBox, Comment). Module dieser Familie sind reine "
            "Python-Helper, die ihren Wert über Patch-Connections an DSP-"
            "Module weiterreichen. Sie haben kein Rust-DSP."
        ),
        is_ui_widget=True,
    ),

    # v0.0.21.202 — S-0: Saga (Sigil-Sight Visualisierungen)
    "Saga": GodDescriptor(
        name="Saga", color=FluxColor.CYAN, category=FluxCategory.UTILITY,
        glyph="ᛟ",
        description=(
            "Saga, die Geschichten-Hüterin am Sökkvabekk — visualisiert "
            "Audio-Signale und parametrische Formen direkt im Modul-Body. "
            "Saga.Magic zeigt eine von 24 Formen (Heart, Pentagram, Norse-"
            "Sigils, Lissajous, Lotus, ...), audio-reaktiv per Stippling. "
            "Standard-Form: Heart ❤. In S-0 läuft die Form-Berechnung "
            "Python-seitig (Pass-Through-Audio); in S-0+ übernimmt die "
            "Rust-Engine die Punkt-Generierung GIL-frei."
        ),
        # Saga.Magic IST kein Pure-Python-Widget wie Frigg — es hat audio-
        # in/out-Ports und ist im Patch-Graph aktiv. Der Standard-Wert
        # `is_ui_widget=False` ist also korrekt. Audio-Pass-Through wird
        # in S-0 über die normale Patch-Connection-Logik realisiert; in
        # S-0+ tappt die Rust-Engine direkt am Eingang.
    ),

    # v0.0.21.215 — Phase 1 Rune-Realm: Vör (Routing & Logic).
    # Erste Familie im neuen Message-Passing-Realm. Vör ist die nordische
    # Göttin der sorgfältigen Befragung und Wahrnehmung — ihre Module
    # untersuchen Rune-Messages (Bangs, Floats, Lists, Symbols) und
    # routen sie. In Phase 1 v.215 nur Bang+RuneTap als Foundation-Proof;
    # Route/Select/Spigot/Trigger kommen in v.216-218.
    "Vör": GodDescriptor(
        name="Vör", color=FluxColor.PURPLE, category=FluxCategory.MESSAGE,
        glyph="ᚹ",
        description=(
            "Vör, Göttin der Bewusstheit und sorgfältigen Befragung — "
            "Routing & Logic im Rune-Realm. Module dieser Familie arbeiten "
            "mit diskreten Message-Events (Bangs, Floats, Lists, Symbols) "
            "statt mit Audio oder CV. Phase 1 (v.215): Bang (Producer) und "
            "RuneTap (Consumer/Counter). Phase 2 (v.216-218): Route, "
            "Select, Spigot, Trigger."
        ),
    ),

    # v0.0.21.221 — Phase 3 Rune-Realm: Norns (Time & Sequencing).
    # Die drei Schicksals-Göttinnen Urð (Vergangenheit), Verðandi
    # (Gegenwart), Skuld (Zukunft) — sie weben das Schicksal an
    # Yggdrasils Wurzeln. Module dieser Familie arbeiten mit der
    # ZEIT — sample-genaues Bang-Timing (Metro), Float-Ramps (Line),
    # Message-Delays (Pipe, Delay). Im Gegensatz zu Vör.Bang's
    # block-rate-Vereinfachung sind Norns-Module sample-präzise:
    # ts-Werte in Messages werden korrekt gesetzt.
    "Norns": GodDescriptor(
        name="Norns", color=FluxColor.VIOLET, category=FluxCategory.MESSAGE,
        glyph="ᚾ",
        description=(
            "Norns, die drei Schicksals-Göttinnen (Urð, Verðandi, Skuld) — "
            "weben Zeit & Sequenz im Rune-Realm. Sample-genaue Module: "
            "Metro (Bang-Generator mit Hz-Rate), Line (Float-Ramp über "
            "Zeit), Pipe (Message-Delay-Queue), Delay (Single-Shot-Delay). "
            "Phase 3 (v.221-223). Lösen Vör.Bang's block-rate-Vereinfachung "
            "ab — ts-Werte sind sample-präzise."
        ),
    ),

    # v0.0.21.225 — Phase 4 Rune-Realm: Ullr (Math & Expressions).
    # Ullr ist der nordische Gott des Bogenschießens, Skifahrens und
    # der präzisen Zielerfassung. In FLUX: Math-Operationen mit
    # Bogenschützen-Präzision. Plus/Minus/Times/Divide für
    # Arithmetik, Clip/Abs/Min/Max für Range-Tools, Random für
    # Pseudozufall, Expr für Expression-Evaluator. Komplementär zu
    # Vör (Routing) und Norns (Timing): Ullr bestimmt die Werte.
    "Ullr": GodDescriptor(
        name="Ullr", color=FluxColor.STONE, category=FluxCategory.MESSAGE,
        glyph="ᛁ",
        description=(
            "Ullr, Gott des Bogenschießens und der Präzision — Math & "
            "Expressions im Rune-Realm. Module: Plus/Minus/Times/Divide "
            "(Arithmetik), Clip/Abs/Min/Max (Range-Tools), Random "
            "(Pseudozufall), Expr (Expression-Evaluator: `(a+b)*2`). "
            "Phase 4 (v.225-227). Pendant zu PD's `+ 60`, `* 0.5`, "
            "`random 4`, `expr` etc."
        ),
    ),

    # v0.0.21.227 — Phase 5 Rune-Realm: Ratatosk (Cross-Realm-Bridges).
    # Ratatosk ist das Eichhörnchen das zwischen Adler in Yggdrasils
    # Krone und Drache Niðhöggr an den Wurzeln Botschaften vermittelt
    # — der ewige Bote zwischen Welten. In FLUX: parametrische
    # Konvertierungen zwischen Realms (Bang↔CV mit Smoothing,
    # MIDI↔Rune, Mtof/Ftom). Foundation in v.227 mit Mtof+Ftom als
    # Bonus, vollständige Familie in Phase 5 (v.228-230).
    "Ratatosk": GodDescriptor(
        name="Ratatosk", color=FluxColor.SKY, category=FluxCategory.MESSAGE,
        glyph="ᚱ",
        description=(
            "Ratatosk, das Eichhörnchen-Botschafter im Yggdrasil — "
            "Cross-Realm-Bridges mit Parametern. v.227 Foundation: "
            "Mtof (MIDI-Note → Frequenz Hz), Ftom (Frequenz → MIDI-Note). "
            "Phase 5 (v.228+) wird parametrische Pulse-Bridges (Smoothing, "
            "Threshold mit Hysterese), MIDI↔Rune-Konvertierungen "
            "ergänzen. Die parameterlosen Pulse-Bridges (v.219/v.220) "
            "decken den 80%-Use-Case bereits ab."
        ),
    ),

    # v0.0.21.228 — Phase 6 Rune-Realm: Hermod (Network / OSC).
    # Hermod ist der schnellste Bote der Götter, sohn Odins, reitet
    # auf Sleipnir bis nach Hel und zurück — perfekt für die
    # Network-Bote-Rolle. In FLUX: OSC (Open Sound Control) über UDP.
    # Module: OscReceive (Listener), OscSend (Sender), OscPath
    # (Filter by OSC-Path), OscPrint (Debug). Anno-Direktive
    # (PD-Patch mit netreceive/oscparse): „können wir noch osc mit
    # einbauen ich kann den patch sonst nicht nachbauen".
    "Hermod": GodDescriptor(
        name="Hermod", color=FluxColor.AQUA, category=FluxCategory.MESSAGE,
        glyph="ᛚ",
        description=(
            "Hermod, der schnellste Bote der Götter — Network & OSC im "
            "Rune-Realm. Module: OscReceive (UDP-Listener), OscSend "
            "(UDP-Sender), OscPath (Filter by Path), OscPrint (Debug). "
            "Pendant zu PD's `netreceive -u -b` + `oscparse`. v.228."
        ),
    ),
}


def get_god(name: str) -> Optional[GodDescriptor]:
    """Liefert einen Gott-Descriptor — case-insensitive Lookup."""
    if not name:
        return None
    # Normalisierung: Erste Buchstabe groß, Rest klein
    key = name.strip().capitalize()
    return GODS.get(key)


def gods_by_category(category: FluxCategory) -> list[GodDescriptor]:
    """Alle Götter einer Kategorie — fürs Palette-Panel-Grouping."""
    return [g for g in GODS.values() if g.category == category]


__all__ = [
    "FluxColor", "FluxCategory", "GodDescriptor",
    "GODS", "get_god", "gods_by_category",
]
