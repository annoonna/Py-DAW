"""video_mood_panel.py — KI Mood Matcher Panel for VE13 (v0.0.20.950).

UI panel for reference-based color grading:
  - Film look preset gallery (15 presets)
  - Reference clip analysis
  - One-click grade application
  - Audio EQ matching

Usage:
    panel = MoodMatcherPanel(project_service)
    panel.set_clip_id("clip_123")
    panel.grade_applied.connect(on_grade)
"""

from __future__ import annotations

import logging
from typing import Optional

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QComboBox, QGroupBox, QScrollArea, QGridLayout,
    QFileDialog, QSizePolicy,
)

log = logging.getLogger(__name__)


class MoodMatcherPanel(QWidget):
    """KI Mood Matcher control panel.

    Signals:
        grade_applied(str): Emitted with preset name when grade applied
    """

    grade_applied = pyqtSignal(str)

    def __init__(self, project_service=None, parent=None):
        super().__init__(parent)
        self._ps = project_service
        self._clip_id: Optional[str] = None
        self._reference_path: Optional[str] = None
        self._setup_ui()

    def _setup_ui(self) -> None:
        lay = QVBoxLayout(self)
        lay.setContentsMargins(4, 4, 4, 4)
        lay.setSpacing(6)

        hdr = QLabel("🎨 Mood Matcher")
        hdr.setStyleSheet(
            "font-weight: bold; color: #e0e0e0; font-size: 11px;")
        lay.addWidget(hdr)

        # ── Film Look Presets ──
        grp_presets = QGroupBox("🎬 Film-Looks")
        grp_presets.setStyleSheet(
            "QGroupBox { color: #ddd; border: 1px solid #444; "
            "border-radius: 4px; margin-top: 6px; padding-top: 14px; "
            "font-size: 10px; }"
            "QGroupBox::title { subcontrol-origin: margin; left: 8px; }"
        )
        grid = QGridLayout(grp_presets)
        grid.setSpacing(3)

        self._preset_btns = {}
        presets = [
            ("cinematic", "🎬 Cinematic", "#3a4a5a"),
            ("warm_cinematic", "🌅 Warm", "#4a3a2a"),
            ("cool_cinematic", "❄ Cool", "#2a3a4a"),
            ("vintage", "📷 Vintage", "#4a3a3a"),
            ("noir", "🖤 Noir", "#2a2a2a"),
            ("teal_orange", "🔶 Teal/Orange", "#3a4a4a"),
            ("sunset", "🌇 Sunset", "#4a3a2a"),
            ("moonlight", "🌙 Moonlight", "#2a2a4a"),
            ("bleach_bypass", "⬜ Bleach", "#3a3a3a"),
            ("documentary", "📹 Doku", "#3a3a3a"),
            ("horror", "👻 Horror", "#2a3a2a"),
            ("dream", "💭 Dream", "#3a3a4a"),
            ("retro_80s", "🕹 80er", "#4a2a4a"),
            ("instagram_warm", "📱 Insta", "#4a3a2a"),
            ("desaturated", "🎭 Entsättigt", "#3a3a3a"),
        ]

        for i, (pid, label, color) in enumerate(presets):
            btn = QPushButton(label)
            btn.setFixedHeight(24)
            btn.setStyleSheet(
                f"QPushButton {{ background: {color}; "
                f"border: 1px solid #555; border-radius: 3px; "
                f"color: #ddd; font-size: 9px; padding: 0 4px; }}"
                f"QPushButton:hover {{ background: #5a5a6a; "
                f"border-color: #88f; }}"
            )
            btn.clicked.connect(lambda _, p=pid: self._on_preset(p))
            row, col = divmod(i, 3)
            grid.addWidget(btn, row, col)
            self._preset_btns[pid] = btn

        lay.addWidget(grp_presets)

        # ── Reference Clip ──
        grp_ref = QGroupBox("🎞 Referenz-Clip")
        grp_ref.setStyleSheet(grp_presets.styleSheet())
        rl = QVBoxLayout(grp_ref)
        rl.setSpacing(4)

        self._lbl_ref = QLabel("Kein Referenz-Clip geladen")
        self._lbl_ref.setStyleSheet("color: #aaa; font-size: 10px;")
        self._lbl_ref.setWordWrap(True)
        rl.addWidget(self._lbl_ref)

        ref_row = QHBoxLayout()
        btn_load = QPushButton("📂 Referenz laden")
        btn_load.setFixedHeight(24)
        btn_load.setStyleSheet(
            "QPushButton { background: #2a3a3a; border: 1px solid #4a6a6a; "
            "border-radius: 3px; color: #aadddd; font-size: 10px; }"
            "QPushButton:hover { background: #3a4a4a; }"
        )
        btn_load.clicked.connect(self._on_load_reference)
        ref_row.addWidget(btn_load)

        self._btn_apply_ref = QPushButton("🎨 Anwenden")
        self._btn_apply_ref.setFixedHeight(24)
        self._btn_apply_ref.setEnabled(False)
        self._btn_apply_ref.setStyleSheet(
            "QPushButton { background: #3a3a2a; border: 1px solid #6a6a4a; "
            "border-radius: 3px; color: #ffddaa; font-size: 10px; }"
            "QPushButton:hover { background: #4a4a3a; }"
            "QPushButton:disabled { background: #222; color: #555; }"
        )
        self._btn_apply_ref.clicked.connect(self._on_apply_reference)
        ref_row.addWidget(self._btn_apply_ref)

        rl.addLayout(ref_row)
        lay.addWidget(grp_ref)

        # ── Audio Matching ──
        grp_audio = QGroupBox("🔊 Audio-Match")
        grp_audio.setStyleSheet(grp_presets.styleSheet())
        al = QVBoxLayout(grp_audio)
        al.setSpacing(4)

        self._lbl_audio = QLabel("Audio-Profil vom Referenz-Clip übernehmen")
        self._lbl_audio.setStyleSheet("color: #aaa; font-size: 10px;")
        self._lbl_audio.setWordWrap(True)
        al.addWidget(self._lbl_audio)

        self._btn_audio_match = QPushButton("🔊 Audio-EQ übertragen")
        self._btn_audio_match.setFixedHeight(24)
        self._btn_audio_match.setEnabled(False)
        self._btn_audio_match.setStyleSheet(
            "QPushButton { background: #2a2a3a; border: 1px solid #4a4a6a; "
            "border-radius: 3px; color: #aaaaff; font-size: 10px; }"
            "QPushButton:hover { background: #3a3a4a; }"
            "QPushButton:disabled { background: #222; color: #555; }"
        )
        self._btn_audio_match.clicked.connect(self._on_audio_match)
        al.addWidget(self._btn_audio_match)

        lay.addWidget(grp_audio)

        # ── Status ──
        self._lbl_status = QLabel("")
        self._lbl_status.setStyleSheet(
            "color: #888; font-size: 9px; padding: 2px;")
        self._lbl_status.setWordWrap(True)
        lay.addWidget(self._lbl_status)

        lay.addStretch(1)
        self.setStyleSheet("background: #12121e;")
        self.setMinimumWidth(200)

    # ── Public API ──

    def set_clip_id(self, clip_id: Optional[str]) -> None:
        self._clip_id = clip_id

    # ── Preset application ──

    def _on_preset(self, preset_name: str) -> None:
        if not self._clip_id:
            self._lbl_status.setText("⚠ Kein Clip ausgewählt")
            return

        try:
            from pydaw.services.video_mood_matcher import MoodMatcherService
            svc = MoodMatcherService()
            ok = svc.apply_to_filter_service(self._clip_id, preset_name)
            if ok:
                label = preset_name.replace("_", " ").title()
                self._lbl_status.setText(f"✅ Look angewandt: {label}")
                self.grade_applied.emit(preset_name)
            else:
                self._lbl_status.setText("❌ Anwendung fehlgeschlagen")
        except Exception as exc:
            self._lbl_status.setText(f"❌ Fehler: {exc}")

    # ── Reference clip ──

    def _on_load_reference(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Referenz-Clip laden",
            "",
            "Video-Dateien (*.mp4 *.mkv *.avi *.mov *.webm);;"
            "Alle Dateien (*)",
        )
        if not path:
            return

        self._reference_path = path
        self._lbl_ref.setText(f"Analysiere: {path.split('/')[-1]}...")

        try:
            from pydaw.services.video_mood_matcher import MoodMatcherService
            svc = MoodMatcherService()
            profile = svc.analyze_reference_clip(path)
            self._svc_ref = svc

            self._lbl_ref.setText(
                f"✅ {path.split('/')[-1]}\n"
                f"Helligkeit: {profile.avg_brightness:.2f} | "
                f"Sättigung: {profile.avg_saturation:.2f} | "
                f"Kontrast: {profile.contrast:.2f}")
            self._btn_apply_ref.setEnabled(True)
            self._btn_audio_match.setEnabled(True)
        except Exception as exc:
            self._lbl_ref.setText(f"❌ Fehler: {exc}")

    def _on_apply_reference(self) -> None:
        if not self._clip_id or not hasattr(self, '_svc_ref'):
            return

        try:
            ok = self._svc_ref.apply_to_filter_service(self._clip_id)
            if ok:
                self._lbl_status.setText("✅ Referenz-Look übertragen")
                self.grade_applied.emit("reference")
            else:
                self._lbl_status.setText("❌ Übertragung fehlgeschlagen")
        except Exception as exc:
            self._lbl_status.setText(f"❌ Fehler: {exc}")

    # ── Audio match ──

    def _on_audio_match(self) -> None:
        if not self._reference_path:
            return

        try:
            from pydaw.services.video_mood_matcher import MoodMatcherService
            svc = MoodMatcherService()
            profile = svc.analyze_reference_audio(self._reference_path)
            af = svc.get_audio_filter()
            self._lbl_audio.setText(
                f"✅ Audio-Profil:\n"
                f"Loudness: {profile['loudness_db']:.1f} dB\n"
                f"Filter: {af[:60]}...")
            self._lbl_status.setText("✅ Audio-EQ bereit für Export")
        except Exception as exc:
            self._lbl_audio.setText(f"❌ Fehler: {exc}")
