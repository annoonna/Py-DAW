"""video_transitions.py — Video Transition Engine (VE10).

Provides:
  - Crossfade / Dissolve between adjacent clips
  - Wipe transitions: left, right, up, down, diagonal
  - Slide / Push transitions
  - Dip to Black / Dip to White
  - Transition duration in beats (beat-synced!)
  - KI-Morph transition stub

v0.0.20.946  VE10 Transition Engine
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# Transition Types
# ═══════════════════════════════════════════════════════════════

class TransitionType(Enum):
    """Available transition types."""
    CROSSFADE = "crossfade"       # standard dissolve
    DISSOLVE = "dissolve"         # same as crossfade with easing
    WIPE_LEFT = "wipe_left"
    WIPE_RIGHT = "wipe_right"
    WIPE_UP = "wipe_up"
    WIPE_DOWN = "wipe_down"
    WIPE_DIAGONAL = "wipe_diagonal"
    SLIDE_LEFT = "slide_left"     # outgoing slides out, incoming slides in
    SLIDE_RIGHT = "slide_right"
    PUSH_LEFT = "push_left"       # incoming pushes outgoing
    PUSH_RIGHT = "push_right"
    DIP_BLACK = "dip_black"       # fade out → black → fade in
    DIP_WHITE = "dip_white"       # fade out → white → fade in
    KI_MORPH = "ki_morph"         # AI-generated in-between frames (stub)


class TransitionEasing(Enum):
    """Easing function for transition progress."""
    LINEAR = "linear"
    EASE_IN = "ease_in"
    EASE_OUT = "ease_out"
    EASE_IN_OUT = "ease_in_out"


# ═══════════════════════════════════════════════════════════════
# Transition Data
# ═══════════════════════════════════════════════════════════════

@dataclass
class VideoTransition:
    """A transition between two adjacent video clips.

    Placed at the junction of clip_a (outgoing) and clip_b (incoming).
    The transition covers `duration_beats` centered on the cut point,
    meaning clip_a needs handle (extra frames) at its end, and clip_b
    needs handle at its start.

    Attributes:
        transition_id: unique ID
        clip_a_id: outgoing clip ID
        clip_b_id: incoming clip ID
        transition_type: what kind of transition
        duration_beats: length in beats (beat-synced!)
        easing: easing function
        position_beats: beat position of the cut point (junction)
        color: for dip transitions — the dip color
        params: extra parameters (wipe angle, softness, etc.)
    """
    transition_id: str = ""
    clip_a_id: str = ""
    clip_b_id: str = ""
    transition_type: TransitionType = TransitionType.CROSSFADE
    duration_beats: float = 2.0
    easing: TransitionEasing = TransitionEasing.EASE_IN_OUT
    position_beats: float = 0.0
    color: Tuple[int, int, int] = (0, 0, 0)
    params: Dict[str, Any] = field(default_factory=dict)

    @property
    def start_beat(self) -> float:
        """Transition start (half-duration before cut point)."""
        return self.position_beats - self.duration_beats / 2.0

    @property
    def end_beat(self) -> float:
        """Transition end (half-duration after cut point)."""
        return self.position_beats + self.duration_beats / 2.0

    def progress_at(self, beat: float) -> float:
        """Get transition progress (0.0–1.0) at a given beat.

        Applies easing function.
        """
        if self.duration_beats <= 0:
            return 1.0

        start = self.start_beat
        end = self.end_beat

        if beat <= start:
            return 0.0
        if beat >= end:
            return 1.0

        t = (beat - start) / self.duration_beats
        return self._apply_easing(t)

    def _apply_easing(self, t: float) -> float:
        """Apply easing function to linear progress t."""
        if self.easing == TransitionEasing.EASE_IN:
            return t * t
        elif self.easing == TransitionEasing.EASE_OUT:
            return 1.0 - (1.0 - t) * (1.0 - t)
        elif self.easing == TransitionEasing.EASE_IN_OUT:
            if t < 0.5:
                return 2.0 * t * t
            else:
                return 1.0 - 2.0 * (1.0 - t) * (1.0 - t)
        return t  # LINEAR

    def get_opacity_a(self, beat: float) -> float:
        """Opacity of outgoing clip A at given beat."""
        p = self.progress_at(beat)

        if self.transition_type in (TransitionType.CROSSFADE,
                                     TransitionType.DISSOLVE):
            return 1.0 - p

        elif self.transition_type == TransitionType.DIP_BLACK:
            # A fades out in first half, B fades in in second half
            if p <= 0.5:
                return 1.0 - (p * 2.0)
            return 0.0

        elif self.transition_type == TransitionType.DIP_WHITE:
            if p <= 0.5:
                return 1.0 - (p * 2.0)
            return 0.0

        # Wipe/Slide/Push: A stays at full opacity, mask handles transition
        return 1.0

    def get_opacity_b(self, beat: float) -> float:
        """Opacity of incoming clip B at given beat."""
        p = self.progress_at(beat)

        if self.transition_type in (TransitionType.CROSSFADE,
                                     TransitionType.DISSOLVE):
            return p

        elif self.transition_type in (TransitionType.DIP_BLACK,
                                       TransitionType.DIP_WHITE):
            if p >= 0.5:
                return (p - 0.5) * 2.0
            return 0.0

        return 1.0

    def get_wipe_position(self, beat: float) -> float:
        """For wipe/slide transitions: position of the wipe edge (0–1)."""
        return self.progress_at(beat)

    def get_dip_color_intensity(self, beat: float) -> float:
        """For dip transitions: intensity of the dip color overlay (0–1)."""
        p = self.progress_at(beat)
        if self.transition_type == TransitionType.DIP_BLACK:
            # Bell shape: peak at 0.5
            return 1.0 - abs(p - 0.5) * 2.0
        elif self.transition_type == TransitionType.DIP_WHITE:
            return 1.0 - abs(p - 0.5) * 2.0
        return 0.0

    # ── ffmpeg filter generation ──

    def to_ffmpeg_filter(self, clip_a_duration_sec: float,
                         transition_duration_sec: float) -> str:
        """Generate ffmpeg filter_complex string for this transition.

        Used during video export.
        """
        offset = clip_a_duration_sec - transition_duration_sec
        dur = transition_duration_sec

        if self.transition_type == TransitionType.CROSSFADE:
            return f"xfade=transition=fade:duration={dur}:offset={offset}"
        elif self.transition_type == TransitionType.DISSOLVE:
            return f"xfade=transition=dissolve:duration={dur}:offset={offset}"
        elif self.transition_type == TransitionType.WIPE_LEFT:
            return f"xfade=transition=wipeleft:duration={dur}:offset={offset}"
        elif self.transition_type == TransitionType.WIPE_RIGHT:
            return f"xfade=transition=wiperight:duration={dur}:offset={offset}"
        elif self.transition_type == TransitionType.WIPE_UP:
            return f"xfade=transition=wipeup:duration={dur}:offset={offset}"
        elif self.transition_type == TransitionType.WIPE_DOWN:
            return f"xfade=transition=wipedown:duration={dur}:offset={offset}"
        elif self.transition_type == TransitionType.SLIDE_LEFT:
            return f"xfade=transition=slideleft:duration={dur}:offset={offset}"
        elif self.transition_type == TransitionType.SLIDE_RIGHT:
            return f"xfade=transition=slideright:duration={dur}:offset={offset}"
        elif self.transition_type == TransitionType.DIP_BLACK:
            return f"xfade=transition=fade:duration={dur}:offset={offset}"
        elif self.transition_type == TransitionType.DIP_WHITE:
            return f"xfade=transition=fade:duration={dur}:offset={offset}"
        else:
            return f"xfade=transition=fade:duration={dur}:offset={offset}"

    # ── Serialization ──

    def to_dict(self) -> Dict[str, Any]:
        return {
            "transition_id": self.transition_id,
            "clip_a_id": self.clip_a_id,
            "clip_b_id": self.clip_b_id,
            "transition_type": self.transition_type.value,
            "duration_beats": self.duration_beats,
            "easing": self.easing.value,
            "position_beats": self.position_beats,
            "color": list(self.color),
            "params": self.params,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "VideoTransition":
        return cls(
            transition_id=d.get("transition_id", ""),
            clip_a_id=d.get("clip_a_id", ""),
            clip_b_id=d.get("clip_b_id", ""),
            transition_type=TransitionType(d.get("transition_type", "crossfade")),
            duration_beats=float(d.get("duration_beats", 2.0)),
            easing=TransitionEasing(d.get("easing", "ease_in_out")),
            position_beats=float(d.get("position_beats", 0.0)),
            color=tuple(d.get("color", [0, 0, 0])),
            params=d.get("params", {}),
        )


# ═══════════════════════════════════════════════════════════════
# Transition Store (project-wide)
# ═══════════════════════════════════════════════════════════════

class VideoTransitionStore:
    """Stores all transitions for a project.

    Transitions are keyed by transition_id and indexed by clip pairs.
    """

    def __init__(self):
        self._transitions: Dict[str, VideoTransition] = {}
        self._next_id = 1

    def add(self, clip_a_id: str, clip_b_id: str,
            position_beats: float,
            transition_type: TransitionType = TransitionType.CROSSFADE,
            duration_beats: float = 2.0,
            easing: TransitionEasing = TransitionEasing.EASE_IN_OUT) -> VideoTransition:
        """Add a transition between two clips."""
        tid = f"vtrans_{self._next_id}"
        self._next_id += 1

        # Remove existing transition between same clips
        self._remove_between(clip_a_id, clip_b_id)

        tr = VideoTransition(
            transition_id=tid,
            clip_a_id=clip_a_id,
            clip_b_id=clip_b_id,
            transition_type=transition_type,
            duration_beats=duration_beats,
            easing=easing,
            position_beats=position_beats,
        )

        if transition_type == TransitionType.DIP_WHITE:
            tr.color = (255, 255, 255)

        self._transitions[tid] = tr
        log.info("[Transitions] Added %s between %s → %s (%.1f beats)",
                 transition_type.value, clip_a_id, clip_b_id, duration_beats)
        return tr

    def remove(self, transition_id: str) -> None:
        """Remove a transition by ID."""
        self._transitions.pop(transition_id, None)

    def _remove_between(self, clip_a_id: str, clip_b_id: str) -> None:
        """Remove any existing transition between two clips."""
        to_remove = [
            tid for tid, tr in self._transitions.items()
            if (tr.clip_a_id == clip_a_id and tr.clip_b_id == clip_b_id)
        ]
        for tid in to_remove:
            del self._transitions[tid]

    def get_transition_at(self, beat: float) -> Optional[VideoTransition]:
        """Find a transition that covers the given beat position."""
        for tr in self._transitions.values():
            if tr.start_beat <= beat <= tr.end_beat:
                return tr
        return None

    def get_transitions_for_clip(self, clip_id: str) -> List[VideoTransition]:
        """Get all transitions involving a clip (as A or B)."""
        return [
            tr for tr in self._transitions.values()
            if tr.clip_a_id == clip_id or tr.clip_b_id == clip_id
        ]

    def get_all(self) -> List[VideoTransition]:
        """Get all transitions."""
        return list(self._transitions.values())

    # ── Serialization ──

    def to_dict(self) -> Dict[str, Any]:
        return {
            "transitions": [tr.to_dict() for tr in self._transitions.values()],
            "next_id": self._next_id,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "VideoTransitionStore":
        store = cls()
        store._next_id = d.get("next_id", 1)
        for tr_data in d.get("transitions", []):
            tr = VideoTransition.from_dict(tr_data)
            store._transitions[tr.transition_id] = tr
        return store
