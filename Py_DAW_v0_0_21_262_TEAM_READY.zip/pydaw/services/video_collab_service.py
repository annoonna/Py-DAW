"""video_collab_service.py — Video Collaboration Service (v0.0.20.946).

Handles all video-specific collab operations, completely isolated from
audio/MIDI collab to prevent breaking existing functionality.

Operations:
  - video_clip_add / video_clip_move / video_clip_resize / video_clip_delete
  - video_clip_split / video_clip_props
  - video_filter_sync (filter presets per clip)
  - video_automation_sync (VE9 opacity/speed/volume curves)
  - video_transition_sync (VE10 transitions between clips)
  - video_timecode_sync (VE8 FPS, DF/NDF settings)
  - video_cursor_sync (playhead position in video editor)

Architecture:
  - Hooks into existing CollabPanel._send_collab_op() for sending
  - Registers handler in _on_remote_operation() for receiving
  - All ops prefixed with 'video_' to avoid collisions
  - Errors in video collab never propagate to audio collab
  - Uses try/finally safety wrappers everywhere

v0.0.20.946  Initial implementation
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

log = logging.getLogger(__name__)

# Op-type constants (all prefixed 'video_' for isolation)
OP_VIDEO_CLIP_ADD = "video_clip_add"
OP_VIDEO_CLIP_MOVE = "video_clip_move"
OP_VIDEO_CLIP_RESIZE = "video_clip_resize"
OP_VIDEO_CLIP_DELETE = "video_clip_delete"
OP_VIDEO_CLIP_SPLIT = "video_clip_split"
OP_VIDEO_CLIP_PROPS = "video_clip_props"
OP_VIDEO_FILTER_SYNC = "video_filter_sync"
OP_VIDEO_AUTOMATION_SYNC = "video_automation_sync"
OP_VIDEO_TRANSITION_SYNC = "video_transition_sync"
OP_VIDEO_TRANSITION_REMOVE = "video_transition_remove"
OP_VIDEO_TIMECODE_SYNC = "video_timecode_sync"
OP_VIDEO_CURSOR_SYNC = "video_cursor_sync"

ALL_VIDEO_OPS = {
    OP_VIDEO_CLIP_ADD, OP_VIDEO_CLIP_MOVE, OP_VIDEO_CLIP_RESIZE,
    OP_VIDEO_CLIP_DELETE, OP_VIDEO_CLIP_SPLIT, OP_VIDEO_CLIP_PROPS,
    OP_VIDEO_FILTER_SYNC, OP_VIDEO_AUTOMATION_SYNC,
    OP_VIDEO_TRANSITION_SYNC, OP_VIDEO_TRANSITION_REMOVE,
    OP_VIDEO_TIMECODE_SYNC, OP_VIDEO_CURSOR_SYNC,
}


class VideoCollabService:
    """Handles video-specific collaboration operations.

    Design principles:
    - NEVER touches audio/MIDI collab code
    - All methods wrapped in try/except — failures log but don't crash
    - Lazy initialization — no overhead if video isn't used
    - Stateless sender, stateful receiver (applies to project model)

    Usage:
        vcs = VideoCollabService(project_service, send_fn)
        vcs.send_clip_move(clip_id, new_start, new_track)
        vcs.handle_remote_op(payload)  # called from collab_panel
    """

    def __init__(self, project_service=None, send_fn=None):
        self._ps = project_service
        self._send_fn = send_fn  # collab_panel._send_collab_op
        self._suppress = False   # prevent echo loops
        self._media_sync = None  # set externally from collab_panel
        self._max_video_size = 200 * 1024 * 1024  # 200 MB max transfer
        log.info("[VideoCollab] Service initialized")

    def set_media_sync(self, media_sync) -> None:
        """Set MediaSyncService reference for video file transfer."""
        self._media_sync = media_sync

    def set_send_fn(self, fn) -> None:
        """Set the send function (collab_panel._send_collab_op)."""
        self._send_fn = fn

    def is_video_op(self, op_type: str) -> bool:
        """Check if an op_type is a video collab operation."""
        return op_type in ALL_VIDEO_OPS

    # ═══════════════════════════════════════════════════════════════
    # SEND Operations (local → remote)
    # ═══════════════════════════════════════════════════════════════

    def _send(self, payload: dict) -> None:
        """Send a video collab op (safe wrapper)."""
        if self._suppress or not self._send_fn:
            return
        try:
            self._send_fn(payload)
        except Exception as e:
            log.debug("[VideoCollab] send error: %s", e)

    def send_clip_add(self, clip_id: str, track_id: str,
                      start_beats: float, length_beats: float,
                      source_path: str = "", label: str = "") -> None:
        """Send video clip addition + offer the video file."""
        self._send({
            "op_type": OP_VIDEO_CLIP_ADD,
            "clip_id": clip_id,
            "track_id": track_id,
            "start_beats": start_beats,
            "length_beats": length_beats,
            "source_path": source_path,
            "label": label,
        })
        # Offer the actual video file via MediaSync
        if source_path:
            self._offer_video_file(source_path, clip_id)

    def send_clip_move(self, clip_id: str, start_beats: float,
                       track_id: str = "") -> None:
        """Send video clip move."""
        self._send({
            "op_type": OP_VIDEO_CLIP_MOVE,
            "clip_id": clip_id,
            "start_beats": start_beats,
            "track_id": track_id,
        })

    def send_clip_resize(self, clip_id: str, length_beats: float) -> None:
        """Send video clip resize."""
        self._send({
            "op_type": OP_VIDEO_CLIP_RESIZE,
            "clip_id": clip_id,
            "length_beats": length_beats,
        })

    def send_clip_delete(self, clip_id: str) -> None:
        """Send video clip deletion."""
        self._send({
            "op_type": OP_VIDEO_CLIP_DELETE,
            "clip_id": clip_id,
        })

    def send_clip_split(self, clip_id: str, split_beat: float) -> None:
        """Send video clip split at beat position."""
        self._send({
            "op_type": OP_VIDEO_CLIP_SPLIT,
            "clip_id": clip_id,
            "split_beat": split_beat,
        })

    def send_clip_props(self, clip_id: str, props: dict) -> None:
        """Send video clip property changes (opacity, speed, label, etc.)."""
        self._send({
            "op_type": OP_VIDEO_CLIP_PROPS,
            "clip_id": clip_id,
            "props": props,
        })

    def send_filter_sync(self, clip_id: str, filter_chain: dict) -> None:
        """Send video filter preset/chain for a clip."""
        self._send({
            "op_type": OP_VIDEO_FILTER_SYNC,
            "clip_id": clip_id,
            "filter_chain": filter_chain,
        })

    def send_automation_sync(self, clip_id: str, automation_data: dict) -> None:
        """Send VE9 automation data for a clip."""
        self._send({
            "op_type": OP_VIDEO_AUTOMATION_SYNC,
            "clip_id": clip_id,
            "automation": automation_data,
        })

    def send_transition_sync(self, transition_data: dict) -> None:
        """Send VE10 transition data."""
        self._send({
            "op_type": OP_VIDEO_TRANSITION_SYNC,
            "transition": transition_data,
        })

    def send_transition_remove(self, transition_id: str) -> None:
        """Send transition removal."""
        self._send({
            "op_type": OP_VIDEO_TRANSITION_REMOVE,
            "transition_id": transition_id,
        })

    def send_timecode_sync(self, fps: float, drop_frame: bool) -> None:
        """Send VE8 timecode settings."""
        self._send({
            "op_type": OP_VIDEO_TIMECODE_SYNC,
            "fps": fps,
            "drop_frame": drop_frame,
        })

    def send_cursor_sync(self, beat: float) -> None:
        """Send video editor cursor/playhead position."""
        self._send({
            "op_type": OP_VIDEO_CURSOR_SYNC,
            "beat": beat,
        })

    # ═══════════════════════════════════════════════════════════════
    # Video File Transfer (via MediaSync)
    # ═══════════════════════════════════════════════════════════════

    def _offer_video_file(self, source_path: str, clip_id: str = "") -> None:
        """Offer a video file to remote participants via MediaSync.

        For files ≤200MB: transfer via chunk-based MediaSync.
        For files >200MB: send notification only (user must share manually).
        """
        try:
            from pathlib import Path
            p = Path(source_path)
            if not p.is_file():
                log.debug("[VideoCollab] File not found: %s", source_path)
                return

            file_size = p.stat().st_size

            if file_size > self._max_video_size:
                # Too large — notify remote that file is needed
                log.info("[VideoCollab] Video too large for transfer (%d MB): %s",
                         file_size // (1024 * 1024), p.name)
                self._send({
                    "op_type": "video_file_required",
                    "file_name": p.name,
                    "file_size": file_size,
                    "clip_id": clip_id,
                    "message": f"Video '{p.name}' ({file_size // (1024*1024)} MB) "
                               f"zu groß für Transfer. Bitte manuell bereitstellen.",
                })
                return

            # Use MediaSync for transfer
            if self._media_sync and hasattr(self._media_sync, 'offer_file'):
                self._media_sync.offer_file(str(p), {
                    "type": "video",
                    "clip_id": clip_id,
                    "video_source": True,
                })
                log.info("[VideoCollab] Offered video '%s' (%d KB) via MediaSync",
                         p.name, file_size // 1024)
            else:
                log.debug("[VideoCollab] No MediaSync available for video transfer")
        except Exception as e:
            log.debug("[VideoCollab] _offer_video_file: %s", e)

    def offer_all_video_files(self) -> None:
        """Offer all video files in the project to a late-joiner.

        Called when a new participant joins and requests full sync.
        """
        proj = self._get_project()
        if not proj:
            return
        for c in (proj.clips or []):
            if str(getattr(c, 'kind', '')) != 'video':
                continue
            path = str(getattr(c, 'source_path', '') or '')
            cid = str(getattr(c, 'id', ''))
            if path:
                self._offer_video_file(path, cid)

    # ═══════════════════════════════════════════════════════════════
    # RECEIVE Operations (remote → local)
    # ═══════════════════════════════════════════════════════════════

    def handle_remote_op(self, payload: dict) -> bool:
        """Handle a remote video collab operation.

        Returns True if this was a video op (handled), False otherwise.
        Called from collab_panel._on_remote_operation().
        """
        op_type = payload.get("op_type", "")
        if not self.is_video_op(op_type):
            return False

        self._suppress = True
        try:
            if op_type == OP_VIDEO_CLIP_ADD:
                self._recv_clip_add(payload)
            elif op_type == OP_VIDEO_CLIP_MOVE:
                self._recv_clip_move(payload)
            elif op_type == OP_VIDEO_CLIP_RESIZE:
                self._recv_clip_resize(payload)
            elif op_type == OP_VIDEO_CLIP_DELETE:
                self._recv_clip_delete(payload)
            elif op_type == OP_VIDEO_CLIP_SPLIT:
                self._recv_clip_split(payload)
            elif op_type == OP_VIDEO_CLIP_PROPS:
                self._recv_clip_props(payload)
            elif op_type == OP_VIDEO_FILTER_SYNC:
                self._recv_filter_sync(payload)
            elif op_type == OP_VIDEO_AUTOMATION_SYNC:
                self._recv_automation_sync(payload)
            elif op_type == OP_VIDEO_TRANSITION_SYNC:
                self._recv_transition_sync(payload)
            elif op_type == OP_VIDEO_TRANSITION_REMOVE:
                self._recv_transition_remove(payload)
            elif op_type == OP_VIDEO_TIMECODE_SYNC:
                self._recv_timecode_sync(payload)
            elif op_type == OP_VIDEO_CURSOR_SYNC:
                self._recv_cursor_sync(payload)
            log.info("[VideoCollab] Applied: %s", op_type)
        except Exception as e:
            log.warning("[VideoCollab] Error handling %s: %s", op_type, e)
        finally:
            self._suppress = False

        return True

    # ── Receivers ──

    def _get_project(self):
        """Get project object safely."""
        ps = self._ps
        if not ps:
            return None
        ctx = getattr(ps, 'ctx', None)
        return getattr(ctx, 'project', None) if ctx else None

    def _find_clip(self, clip_id: str):
        """Find a clip by ID in the project."""
        proj = self._get_project()
        if not proj:
            return None
        for c in (proj.clips or []):
            if str(getattr(c, 'id', '')) == str(clip_id):
                return c
        return None

    def _emit_updated(self) -> None:
        """Emit project updated signal."""
        try:
            ps = self._ps
            if ps and hasattr(ps, 'project_updated'):
                ps.project_updated.emit()
            elif ps and hasattr(ps, '_emit_updated'):
                ps._emit_updated()
        except Exception:
            pass

    def _recv_clip_add(self, payload: dict) -> None:
        """Add a video clip from remote."""
        proj = self._get_project()
        if not proj:
            return
        try:
            from pydaw.model.project import Clip
            clip = Clip(
                kind="video",
                track_id=str(payload.get("track_id", "")),
                label=str(payload.get("label", "Video")),
                source_path=str(payload.get("source_path", "")),
                start_beats=float(payload.get("start_beats", 0)),
                length_beats=float(payload.get("length_beats", 4)),
            )
            # Use remote clip ID for consistency
            remote_id = payload.get("clip_id", "")
            if remote_id:
                clip.id = str(remote_id)
            proj.clips.append(clip)
            self._emit_updated()
        except Exception as e:
            log.warning("[VideoCollab] clip_add: %s", e)

    def _recv_clip_move(self, payload: dict) -> None:
        """Move a video clip from remote."""
        clip = self._find_clip(payload.get("clip_id", ""))
        if not clip:
            return
        clip.start_beats = float(payload.get("start_beats", 0))
        if payload.get("track_id"):
            clip.track_id = str(payload["track_id"])
        self._emit_updated()

    def _recv_clip_resize(self, payload: dict) -> None:
        """Resize a video clip from remote."""
        clip = self._find_clip(payload.get("clip_id", ""))
        if not clip:
            return
        clip.length_beats = float(payload.get("length_beats", 4))
        self._emit_updated()

    def _recv_clip_delete(self, payload: dict) -> None:
        """Delete a video clip from remote."""
        proj = self._get_project()
        if not proj:
            return
        cid = str(payload.get("clip_id", ""))
        proj.clips = [c for c in proj.clips
                       if str(getattr(c, 'id', '')) != cid]
        self._emit_updated()

    def _recv_clip_split(self, payload: dict) -> None:
        """Split a video clip from remote."""
        clip = self._find_clip(payload.get("clip_id", ""))
        if not clip:
            return
        proj = self._get_project()
        if not proj:
            return

        split_beat = float(payload.get("split_beat", 0))
        cs = float(getattr(clip, 'start_beats', 0))
        cl = float(getattr(clip, 'length_beats', 0))
        if split_beat <= cs or split_beat >= cs + cl:
            return

        try:
            from pydaw.model.project import Clip
            # Shorten original
            clip.length_beats = split_beat - cs
            # Create new clip after split
            bpm = float(getattr(proj, 'bpm', 120) or 120)
            new_clip = Clip(
                kind="video",
                track_id=str(getattr(clip, 'track_id', '')),
                label=str(getattr(clip, 'label', '')) + " (B)",
                source_path=str(getattr(clip, 'source_path', '')),
                start_beats=split_beat,
                length_beats=(cs + cl) - split_beat,
                offset_seconds=float(getattr(clip, 'offset_seconds', 0) or 0)
                    + (split_beat - cs) * 60.0 / max(1, bpm),
            )
            proj.clips.append(new_clip)
            self._emit_updated()
        except Exception as e:
            log.warning("[VideoCollab] clip_split: %s", e)

    def _recv_clip_props(self, payload: dict) -> None:
        """Apply video clip property changes from remote."""
        clip = self._find_clip(payload.get("clip_id", ""))
        if not clip:
            return
        props = payload.get("props", {})
        for key, val in props.items():
            if key in ("opacity", "speed", "label", "color_grade",
                       "offset_seconds"):
                try:
                    setattr(clip, key, val)
                except Exception:
                    pass
        # Update SQLite persistence if available
        try:
            from pydaw.services.video_filter_service import VideoFilterService
            vfs = VideoFilterService.instance()
            if vfs and hasattr(vfs, 'save_clip_props'):
                vfs.save_clip_props(str(payload.get("clip_id", "")), props)
        except Exception:
            pass
        self._emit_updated()

    def _recv_filter_sync(self, payload: dict) -> None:
        """Apply video filter chain from remote."""
        clip_id = str(payload.get("clip_id", ""))
        chain = payload.get("filter_chain", {})
        if not clip_id or not chain:
            return
        try:
            from pydaw.services.video_filter_service import VideoFilterService
            vfs = VideoFilterService.instance()
            if vfs and hasattr(vfs, 'set_filter_chain'):
                vfs.set_filter_chain(clip_id, chain)
        except Exception as e:
            log.debug("[VideoCollab] filter_sync: %s", e)

    def _recv_automation_sync(self, payload: dict) -> None:
        """Apply VE9 automation data from remote."""
        clip_id = str(payload.get("clip_id", ""))
        auto_data = payload.get("automation", {})
        if not clip_id or not auto_data:
            return
        try:
            from pydaw.services.video_automation import ClipAutomation
            auto = ClipAutomation.from_dict(auto_data)
            # Store in video editor's automation store if available
            self._apply_to_video_editor("set_automation", clip_id, auto)
        except Exception as e:
            log.debug("[VideoCollab] automation_sync: %s", e)

    def _recv_transition_sync(self, payload: dict) -> None:
        """Apply VE10 transition from remote."""
        tr_data = payload.get("transition", {})
        if not tr_data:
            return
        try:
            from pydaw.services.video_transitions import VideoTransition
            tr = VideoTransition.from_dict(tr_data)
            self._apply_to_video_editor("add_transition_obj", tr)
        except Exception as e:
            log.debug("[VideoCollab] transition_sync: %s", e)

    def _recv_transition_remove(self, payload: dict) -> None:
        """Remove a transition from remote."""
        tr_id = str(payload.get("transition_id", ""))
        if tr_id:
            self._apply_to_video_editor("remove_transition_by_id", tr_id)

    def _recv_timecode_sync(self, payload: dict) -> None:
        """Apply VE8 timecode settings from remote."""
        fps = float(payload.get("fps", 24.0))
        df = bool(payload.get("drop_frame", False))
        self._apply_to_video_editor("set_timecode_settings", fps, df)

    def _recv_cursor_sync(self, payload: dict) -> None:
        """Apply video cursor position from remote (low priority)."""
        # Intentionally lightweight — no model update needed
        pass

    def _apply_to_video_editor(self, method: str, *args) -> None:
        """Apply an operation to the VideoEditor widget if it exists.

        Safe: if no video editor is open, does nothing.
        """
        try:
            from pydaw.services.video_connector import VideoConnector
            vc = VideoConnector.instance()
            if not vc:
                return
            ve = getattr(vc, '_video_editor', None)
            if not ve:
                return
            canvas = getattr(ve, '_canvas', None)
            if canvas and hasattr(canvas, method):
                getattr(canvas, method)(*args)
            elif hasattr(ve, method):
                getattr(ve, method)(*args)
        except Exception as e:
            log.debug("[VideoCollab] _apply_to_video_editor(%s): %s", method, e)
