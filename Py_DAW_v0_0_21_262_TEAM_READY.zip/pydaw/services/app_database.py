"""app_database.py — Combined SQLite store for lightweight app-wide tables.

v0.0.20.890 — Phases 19-22, 25-26, 34, 37-38 der SQLite Migration Roadmap.

Bundles multiple small key-value and list-based tables into one module:
- P19: keybindings — Custom keyboard shortcuts
- P20: ui_layout — Window positions, dock states, zoom levels
- P21: audio_config — Audio device configuration
- P22: recording_config — Recording settings (punch, count-in, takes)
- P25: export_config — Export format/quality settings
- P26: browser_places + browser_recents — File browser favorites
- P34: ai_config — Music AI settings (composer, drummer, orchestrator)
- P37: accessibility_config — Screen reader, high contrast, focus
- P38: input_config — CV-Gate, OSC, Gamepad configuration

All tables use the shared pydaw.db. Each section has its own get/set API.
RAM-cached, old systems (QSettings, hardcoded defaults) remain as fallback.

Usage:
    from pydaw.services.app_database import AppDatabase
    db = AppDatabase.get()
    db.ensure_loaded()

    # Key bindings
    db.set_keybinding("Ctrl+S", "file_save")
    action = db.get_keybinding("Ctrl+S")

    # UI Layout
    db.set_layout("main_window_geometry", "100,100,1920,1080")
    geom = db.get_layout("main_window_geometry")

    # Browser
    db.add_browser_place("/home/user/Samples", "My Samples")
    db.add_browser_recent("/home/user/project.pydaw")
    places = db.get_browser_places()
    recents = db.get_browser_recents(limit=20)
"""

import sqlite3
import logging
import time
from pathlib import Path
from typing import Dict, List, Optional, Any

log = logging.getLogger(__name__)


class AppDatabase:
    """Combined lightweight app-wide SQLite store.

    Singleton. All tables cached in RAM dicts.
    """

    _instance: Optional["AppDatabase"] = None

    @classmethod
    def get(cls) -> "AppDatabase":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._db_path = Path.home() / ".config" / "ChronoScaleStudio" / "pydaw.db"
        # P19: keybindings
        self._keybindings: Dict[str, str] = {}      # shortcut → action
        self._keybindings_rev: Dict[str, str] = {}   # action → shortcut
        # P20: ui_layout
        self._layout: Dict[str, str] = {}
        # P21: audio_config
        self._audio_config: Dict[str, str] = {}
        # P22: recording_config
        self._recording_config: Dict[str, str] = {}
        # P25: export_config
        self._export_config: Dict[str, str] = {}
        # P26: browser
        self._browser_places: List[dict] = []
        self._browser_recents: List[dict] = []
        # P34: ai_config
        self._ai_config: Dict[str, str] = {}
        # P37: accessibility_config
        self._accessibility_config: Dict[str, str] = {}
        # P38: input_config
        self._input_config: Dict[str, str] = {}
        self._loaded = False

    def ensure_loaded(self) -> None:
        """Create all tables, seed defaults, load into RAM. Idempotent."""
        if self._loaded:
            return
        try:
            self._init_db()
            self._load_to_ram()
            self._loaded = True
            log.info("[AppDB] Loaded: %d keybindings, %d layout, %d places, %d recents",
                     len(self._keybindings), len(self._layout),
                     len(self._browser_places), len(self._browser_recents))
        except Exception as e:
            log.warning("[AppDB] Failed to load: %s", e)

    # ══════════════════════════════════════════════════════════════
    # P19: Key Bindings
    # ══════════════════════════════════════════════════════════════

    def get_keybinding(self, shortcut: str) -> Optional[str]:
        """Get action for a keyboard shortcut."""
        self.ensure_loaded()
        return self._keybindings.get(shortcut)

    def get_shortcut_for_action(self, action: str) -> Optional[str]:
        """Get shortcut for an action name."""
        self.ensure_loaded()
        return self._keybindings_rev.get(action)

    def get_all_keybindings(self) -> Dict[str, str]:
        """All keybindings as {shortcut: action}."""
        self.ensure_loaded()
        return dict(self._keybindings)

    def set_keybinding(self, shortcut: str, action: str) -> None:
        """Set or update a keyboard shortcut binding."""
        self.ensure_loaded()
        self._keybindings[shortcut] = action
        self._keybindings_rev[action] = shortcut
        self._write_kv("keybindings", shortcut, action)

    def remove_keybinding(self, shortcut: str) -> None:
        """Remove a keyboard shortcut."""
        action = self._keybindings.pop(shortcut, None)
        if action:
            self._keybindings_rev.pop(action, None)
        self._delete_kv("keybindings", shortcut)

    def reset_keybindings(self) -> None:
        """Reset all keybindings to factory defaults."""
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.execute("DELETE FROM keybindings")
                self._seed_keybindings(conn)
                conn.commit()
            finally:
                conn.close()
            self._loaded = False
            self.ensure_loaded()
        except Exception:
            pass

    # ══════════════════════════════════════════════════════════════
    # P20: UI Layout
    # ══════════════════════════════════════════════════════════════

    def get_layout(self, key: str, default: str = "") -> str:
        """Get a UI layout value."""
        self.ensure_loaded()
        return self._layout.get(key, default)

    def set_layout(self, key: str, value: str) -> None:
        """Set a UI layout value."""
        self.ensure_loaded()
        self._layout[key] = value
        self._write_kv("ui_layout", key, value)

    def get_all_layout(self) -> Dict[str, str]:
        """All layout values."""
        self.ensure_loaded()
        return dict(self._layout)

    # ══════════════════════════════════════════════════════════════
    # P21: Audio Device Config
    # ══════════════════════════════════════════════════════════════

    def get_audio_config(self, key: str, default: str = "") -> str:
        """Get an audio config value."""
        self.ensure_loaded()
        return self._audio_config.get(key, default)

    def set_audio_config(self, key: str, value: str) -> None:
        """Set an audio config value."""
        self.ensure_loaded()
        self._audio_config[key] = value
        self._write_kv("audio_config", key, value)

    def get_all_audio_config(self) -> Dict[str, str]:
        """All audio config values."""
        self.ensure_loaded()
        return dict(self._audio_config)

    # ══════════════════════════════════════════════════════════════
    # P22: Recording Config
    # ══════════════════════════════════════════════════════════════

    def get_recording_config(self, key: str, default: str = "") -> str:
        """Get a recording config value."""
        self.ensure_loaded()
        return self._recording_config.get(key, default)

    def set_recording_config(self, key: str, value: str) -> None:
        """Set a recording config value."""
        self.ensure_loaded()
        self._recording_config[key] = value
        self._write_kv("recording_config", key, value)

    # ══════════════════════════════════════════════════════════════
    # P25: Export Config
    # ══════════════════════════════════════════════════════════════

    def get_export_config(self, key: str, default: str = "") -> str:
        """Get an export config value."""
        self.ensure_loaded()
        return self._export_config.get(key, default)

    def set_export_config(self, key: str, value: str) -> None:
        """Set an export config value."""
        self.ensure_loaded()
        self._export_config[key] = value
        self._write_kv("export_config", key, value)

    def get_all_export_config(self) -> Dict[str, str]:
        """All export config values."""
        self.ensure_loaded()
        return dict(self._export_config)

    # ══════════════════════════════════════════════════════════════
    # P26: Browser Places + Recents
    # ══════════════════════════════════════════════════════════════

    def get_browser_places(self) -> List[dict]:
        """Get all browser favorite places."""
        self.ensure_loaded()
        return list(self._browser_places)

    def add_browser_place(self, path: str, name: str = "",
                          icon: str = "📁") -> bool:
        """Add a browser favorite place."""
        if not name:
            name = Path(path).name
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.execute(
                    """INSERT OR REPLACE INTO browser_places (path, name, icon, sort_order)
                       VALUES (?,?,?,?)""",
                    (path, name, icon, len(self._browser_places))
                )
                conn.commit()
            finally:
                conn.close()
            self._loaded = False
            self.ensure_loaded()
            return True
        except Exception:
            return False

    def remove_browser_place(self, path: str) -> None:
        """Remove a browser favorite place."""
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.execute("DELETE FROM browser_places WHERE path = ?", (path,))
                conn.commit()
            finally:
                conn.close()
            self._browser_places = [p for p in self._browser_places
                                     if p.get("path") != path]
        except Exception:
            pass

    def get_browser_recents(self, limit: int = 20) -> List[dict]:
        """Get recent files, most recent first."""
        self.ensure_loaded()
        return self._browser_recents[:limit]

    def add_browser_recent(self, path: str, file_type: str = "project") -> None:
        """Add or update a recent file entry."""
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.execute(
                    """INSERT OR REPLACE INTO browser_recents
                       (path, type, last_opened)
                       VALUES (?,?,datetime('now'))""",
                    (path, file_type)
                )
                # Keep only last 50
                conn.execute(
                    """DELETE FROM browser_recents WHERE path NOT IN
                       (SELECT path FROM browser_recents ORDER BY last_opened DESC LIMIT 50)"""
                )
                conn.commit()
            finally:
                conn.close()
            self._loaded = False
            self.ensure_loaded()
        except Exception:
            pass

    def clear_browser_recents(self) -> None:
        """Clear all recent files."""
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.execute("DELETE FROM browser_recents")
                conn.commit()
            finally:
                conn.close()
            self._browser_recents.clear()
        except Exception:
            pass

    def pin_recent(self, path: str) -> None:
        """Pin a recent file (pin_order > 0)."""
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.execute(
                    "UPDATE browser_recents SET pin_order = 1 WHERE path = ?",
                    (path,))
                conn.commit()
            finally:
                conn.close()
        except Exception:
            pass

    # ══════════════════════════════════════════════════════════════
    # P34: Music AI Config
    # ══════════════════════════════════════════════════════════════

    def get_ai_config(self, key: str, default: str = "") -> str:
        """Get a Music AI configuration value."""
        self.ensure_loaded()
        return self._ai_config.get(key, default)

    def set_ai_config(self, key: str, value: str) -> None:
        """Set a Music AI configuration value."""
        self.ensure_loaded()
        self._ai_config[key] = value
        self._write_kv("ai_config", key, value)

    def get_all_ai_config(self) -> Dict[str, str]:
        """All AI config values."""
        self.ensure_loaded()
        return dict(self._ai_config)

    # ══════════════════════════════════════════════════════════════
    # P37: Accessibility Config
    # ══════════════════════════════════════════════════════════════

    def get_accessibility_config(self, key: str, default: str = "") -> str:
        """Get an accessibility configuration value."""
        self.ensure_loaded()
        return self._accessibility_config.get(key, default)

    def set_accessibility_config(self, key: str, value: str) -> None:
        """Set an accessibility configuration value."""
        self.ensure_loaded()
        self._accessibility_config[key] = value
        self._write_kv("accessibility_config", key, value)

    def get_all_accessibility_config(self) -> Dict[str, str]:
        """All accessibility config values."""
        self.ensure_loaded()
        return dict(self._accessibility_config)

    # ══════════════════════════════════════════════════════════════
    # P38: Alternative Input Config (CV-Gate, OSC, Gamepad)
    # ══════════════════════════════════════════════════════════════

    def get_input_config(self, key: str, default: str = "") -> str:
        """Get an alternative input configuration value."""
        self.ensure_loaded()
        return self._input_config.get(key, default)

    def set_input_config(self, key: str, value: str) -> None:
        """Set an alternative input configuration value."""
        self.ensure_loaded()
        self._input_config[key] = value
        self._write_kv("input_config", key, value)

    def get_all_input_config(self) -> Dict[str, str]:
        """All alternative input config values."""
        self.ensure_loaded()
        return dict(self._input_config)

    # ══════════════════════════════════════════════════════════════
    # Internal
    # ══════════════════════════════════════════════════════════════

    def _write_kv(self, table: str, key: str, value: str) -> None:
        """Write a key-value pair to a table."""
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.execute(
                    f"INSERT OR REPLACE INTO {table} (key, value) VALUES (?,?)",
                    (key, value))
                conn.commit()
            finally:
                conn.close()
        except Exception:
            pass

    def _delete_kv(self, table: str, key: str) -> None:
        """Delete a key from a table."""
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                conn.execute(f"DELETE FROM {table} WHERE key = ?", (key,))
                conn.commit()
            finally:
                conn.close()
        except Exception:
            pass

    def _init_db(self) -> None:
        """Create all tables + seed defaults."""
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(self._db_path))
        try:
            conn.executescript(_SCHEMA_SQL)
            kb_count = conn.execute("SELECT COUNT(*) FROM keybindings").fetchone()[0]
            if kb_count == 0:
                self._seed_keybindings(conn)
            conn.commit()
        finally:
            conn.close()

    def _load_to_ram(self) -> None:
        """Load all tables into RAM."""
        conn = sqlite3.connect(str(self._db_path))
        conn.row_factory = sqlite3.Row
        try:
            # P19: Keybindings
            self._keybindings.clear()
            self._keybindings_rev.clear()
            for row in conn.execute("SELECT * FROM keybindings"):
                k, v = row["key"], row["value"]
                self._keybindings[k] = v
                self._keybindings_rev[v] = k

            # P20: UI Layout
            self._layout.clear()
            for row in conn.execute("SELECT * FROM ui_layout"):
                self._layout[row["key"]] = row["value"]

            # P21: Audio Config
            self._audio_config.clear()
            for row in conn.execute("SELECT * FROM audio_config"):
                self._audio_config[row["key"]] = row["value"]

            # P22: Recording Config
            self._recording_config.clear()
            for row in conn.execute("SELECT * FROM recording_config"):
                self._recording_config[row["key"]] = row["value"]

            # P25: Export Config
            self._export_config.clear()
            for row in conn.execute("SELECT * FROM export_config"):
                self._export_config[row["key"]] = row["value"]

            # P26: Browser Places
            self._browser_places = [
                dict(row) for row in conn.execute(
                    "SELECT * FROM browser_places ORDER BY sort_order, name")
            ]

            # P26: Browser Recents
            self._browser_recents = [
                dict(row) for row in conn.execute(
                    "SELECT * FROM browser_recents ORDER BY pin_order DESC, last_opened DESC")
            ]

            # P34: AI Config
            self._ai_config.clear()
            for row in conn.execute("SELECT * FROM ai_config"):
                self._ai_config[row["key"]] = row["value"]

            # P37: Accessibility Config
            self._accessibility_config.clear()
            for row in conn.execute("SELECT * FROM accessibility_config"):
                self._accessibility_config[row["key"]] = row["value"]

            # P38: Input Config
            self._input_config.clear()
            for row in conn.execute("SELECT * FROM input_config"):
                self._input_config[row["key"]] = row["value"]
        finally:
            conn.close()

    def _seed_keybindings(self, conn: sqlite3.Connection) -> None:
        """Seed default keyboard shortcuts."""
        for shortcut, action in _DEFAULT_KEYBINDINGS:
            try:
                conn.execute(
                    "INSERT OR IGNORE INTO keybindings (key, value) VALUES (?,?)",
                    (shortcut, action))
            except Exception:
                pass


# ══════════════════════════════════════════════════════════════════
# Schema
# ══════════════════════════════════════════════════════════════════

_SCHEMA_SQL = """
-- P19: Key Bindings
CREATE TABLE IF NOT EXISTS keybindings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

-- P20: UI Layout
CREATE TABLE IF NOT EXISTS ui_layout (
    key TEXT PRIMARY KEY,
    value TEXT
);

-- P21: Audio Device Config
CREATE TABLE IF NOT EXISTS audio_config (
    key TEXT PRIMARY KEY,
    value TEXT
);

-- P22: Recording Config
CREATE TABLE IF NOT EXISTS recording_config (
    key TEXT PRIMARY KEY,
    value TEXT
);

-- P25: Export Config
CREATE TABLE IF NOT EXISTS export_config (
    key TEXT PRIMARY KEY,
    value TEXT
);

-- P26: Browser Places
CREATE TABLE IF NOT EXISTS browser_places (
    path TEXT PRIMARY KEY,
    name TEXT,
    icon TEXT DEFAULT '📁',
    sort_order INTEGER DEFAULT 0
);

-- P26: Browser Recents
CREATE TABLE IF NOT EXISTS browser_recents (
    path TEXT PRIMARY KEY,
    type TEXT,
    last_opened TEXT DEFAULT (datetime('now')),
    pin_order INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_recents_opened ON browser_recents(last_opened);

-- P34: Music AI Config
CREATE TABLE IF NOT EXISTS ai_config (
    key TEXT PRIMARY KEY,
    value TEXT
);

-- P37: Accessibility Config
CREATE TABLE IF NOT EXISTS accessibility_config (
    key TEXT PRIMARY KEY,
    value TEXT
);

-- P38: Alternative Input Config (CV-Gate, OSC, Gamepad)
CREATE TABLE IF NOT EXISTS input_config (
    key TEXT PRIMARY KEY,
    value TEXT
);
"""

# ══════════════════════════════════════════════════════════════════
# Factory Keybindings
# ══════════════════════════════════════════════════════════════════

_DEFAULT_KEYBINDINGS = [
    # File operations
    ("Ctrl+N", "file_new"),
    ("Ctrl+O", "file_open"),
    ("Ctrl+S", "file_save"),
    ("Ctrl+Shift+S", "file_save_as"),
    ("Ctrl+W", "file_close_tab"),
    ("Ctrl+Q", "app_quit"),

    # Edit
    ("Ctrl+Z", "edit_undo"),
    ("Ctrl+Shift+Z", "edit_redo"),
    ("Ctrl+X", "edit_cut"),
    ("Ctrl+C", "edit_copy"),
    ("Ctrl+V", "edit_paste"),
    ("Ctrl+A", "edit_select_all"),
    ("Delete", "edit_delete"),
    ("Ctrl+D", "edit_duplicate"),

    # Transport
    ("Space", "transport_play_stop"),
    ("R", "transport_record"),
    ("L", "transport_loop_toggle"),
    ("Home", "transport_goto_start"),
    ("End", "transport_goto_end"),
    (",", "transport_rewind"),
    (".", "transport_forward"),

    # Arranger
    ("Ctrl+T", "track_add"),
    ("Ctrl+Shift+T", "track_add_audio"),
    ("Ctrl+G", "track_group"),
    ("Ctrl+Shift+G", "track_ungroup"),
    ("Ctrl+J", "clip_join"),
    ("Ctrl+Shift+M", "clip_mute_toggle"),
    ("Ctrl+R", "clip_rename"),
    ("F2", "track_rename"),

    # View
    ("Ctrl+1", "view_arranger"),
    ("Ctrl+2", "view_mixer"),
    ("Ctrl+3", "view_piano_roll"),
    ("Ctrl+4", "view_notation"),
    ("Ctrl+5", "view_clip_launcher"),
    ("Ctrl+=", "zoom_in"),
    ("Ctrl+-", "zoom_out"),
    ("Ctrl+0", "zoom_fit"),
    ("F11", "view_fullscreen"),

    # MIDI
    ("Ctrl+M", "midi_learn_toggle"),

    # Piano Roll
    ("Ctrl+Up", "note_transpose_up"),
    ("Ctrl+Down", "note_transpose_down"),
    ("Ctrl+Shift+Up", "note_transpose_octave_up"),
    ("Ctrl+Shift+Down", "note_transpose_octave_down"),

    # Audio
    ("Ctrl+E", "audio_export"),
    ("Ctrl+Shift+E", "audio_export_stems"),

    # Tools
    ("Ctrl+Shift+P", "script_console"),
    ("Ctrl+,", "preferences"),
]
