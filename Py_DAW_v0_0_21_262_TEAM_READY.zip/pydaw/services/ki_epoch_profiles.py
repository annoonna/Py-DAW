"""ki_epoch_profiles.py — Musical Epoch Style Profiles (v0.0.20.985)

KK3: Epochen-Profile (Style-Engine) + KK4: Rhythmus-Engine

Provides style-specific parameters for automatic composition:
  - 16 epoch profiles (Medieval → Ambient)
  - Each profile defines: scales, chords, rhythm, tempo, articulation
  - Rhythm patterns per style (drum + accompaniment)
  - Humanize algorithms (timing + velocity variation)

Usage:
    from pydaw.services.ki_epoch_profiles import EpochEngine

    engine = EpochEngine()
    profile = engine.get_profile("baroque")
    rhythm = engine.generate_rhythm("jazz", bars=4)
"""

import random
import math
import logging
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple
from enum import Enum

log = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# KK3: Epoch Profiles
# ═══════════════════════════════════════════════════════════════

@dataclass
class EpochProfile:
    """Complete style profile for an epoch/genre."""
    name: str
    era: str                          # e.g. "1600–1750"
    description: str
    # Scales
    preferred_scales: List[str]       # e.g. ["major", "minor"]
    avoid_scales: List[str] = field(default_factory=list)
    # Harmony
    preferred_chords: List[str] = field(default_factory=list)
    max_chord_extensions: int = 3     # triads=3, 7th=4, 9th=5
    use_chromaticism: float = 0.0     # 0.0–1.0
    use_modulation: float = 0.0       # 0.0–1.0
    # Rhythm
    time_signatures: List[Tuple[int, int]] = field(default_factory=lambda: [(4, 4)])
    tempo_range: Tuple[int, int] = (80, 120)
    swing_amount: float = 0.0        # 0.0–1.0
    rhythmic_complexity: float = 0.5  # 0.0–1.0
    # Texture
    typical_voices: int = 4
    polyphonic: bool = True
    use_counterpoint: bool = False
    # Dynamics
    dynamic_range: float = 0.5       # 0.0–1.0
    articulation: List[str] = field(default_factory=lambda: ["legato"])
    # Typical patterns
    progression_patterns: List[str] = field(default_factory=list)
    # Instruments (suggested)
    instruments: List[str] = field(default_factory=list)


# Pre-defined epoch profiles
EPOCH_PROFILES: Dict[str, EpochProfile] = {
    "medieval": EpochProfile(
        name="Mittelalter", era="800–1400",
        description="Gregorianik, Organum, Ars Nova, Modalität",
        preferred_scales=["dorian", "phrygian", "mixolydian", "aeolian"],
        preferred_chords=["open_fifth"],
        max_chord_extensions=2,
        use_chromaticism=0.0,
        time_signatures=[(3, 4), (6, 8)],
        tempo_range=(60, 90),
        typical_voices=2,
        polyphonic=True,
        use_counterpoint=True,
        dynamic_range=0.3,
        articulation=["legato"],
        instruments=["voice", "lute", "recorder", "harp"],
    ),
    "renaissance": EpochProfile(
        name="Renaissance", era="1400–1600",
        description="Palestrina-Stil, Vokalpolyphonie, Imitation",
        preferred_scales=["dorian", "mixolydian", "ionian", "aeolian"],
        preferred_chords=["major", "minor"],
        max_chord_extensions=3,
        use_chromaticism=0.1,
        time_signatures=[(4, 4), (3, 4), (6, 8)],
        tempo_range=(60, 100),
        typical_voices=4,
        polyphonic=True,
        use_counterpoint=True,
        dynamic_range=0.4,
        articulation=["legato", "staccato"],
        instruments=["voice", "lute", "viol", "organ", "recorder"],
    ),
    "baroque": EpochProfile(
        name="Barock", era="1600–1750",
        description="Bach, Händel, Vivaldi — Generalbass, Concerto, Fuge",
        preferred_scales=["major", "minor", "harmonic_minor"],
        preferred_chords=["major", "minor", "dominant7"],
        max_chord_extensions=4,
        use_chromaticism=0.3,
        use_modulation=0.3,
        time_signatures=[(4, 4), (3, 4), (6, 8), (12, 8)],
        tempo_range=(60, 140),
        typical_voices=4,
        polyphonic=True,
        use_counterpoint=True,
        dynamic_range=0.5,
        articulation=["legato", "staccato", "trill"],
        progression_patterns=["I-IV-V-I", "I-vi-IV-V", "circle_of_fifths"],
        instruments=["harpsichord", "organ", "violin", "cello", "flute", "oboe"],
    ),
    "classical": EpochProfile(
        name="Klassik", era="1750–1820",
        description="Mozart, Haydn, Beethoven — Sonatenform, Durchführung",
        preferred_scales=["major", "minor"],
        preferred_chords=["major", "minor", "dominant7", "diminished"],
        max_chord_extensions=4,
        use_chromaticism=0.2,
        use_modulation=0.4,
        time_signatures=[(4, 4), (3, 4), (2, 4)],
        tempo_range=(70, 160),
        typical_voices=4,
        polyphonic=True,
        dynamic_range=0.7,
        articulation=["legato", "staccato", "sforzando", "crescendo"],
        progression_patterns=["I-IV-V-I", "I-ii-V-I"],
        instruments=["piano", "violin", "viola", "cello", "flute", "clarinet", "horn"],
    ),
    "romantic": EpochProfile(
        name="Romantik", era="1820–1900",
        description="Chopin, Liszt, Wagner — Chromatik, Leitmotiv",
        preferred_scales=["major", "minor", "harmonic_minor", "melodic_minor"],
        preferred_chords=["major", "minor", "dominant7", "diminished7", "augmented"],
        max_chord_extensions=5,
        use_chromaticism=0.6,
        use_modulation=0.6,
        time_signatures=[(4, 4), (3, 4), (6, 8)],
        tempo_range=(40, 180),
        typical_voices=4,
        polyphonic=True,
        dynamic_range=0.9,
        articulation=["legato", "rubato", "crescendo", "sforzando", "pianissimo"],
        instruments=["piano", "orchestra", "voice"],
    ),
    "impressionism": EpochProfile(
        name="Impressionismus", era="1880–1920",
        description="Debussy, Ravel — Ganztonleiter, Quartenakkorde",
        preferred_scales=["whole_tone", "major", "pentatonic_major", "dorian"],
        preferred_chords=["major7", "minor7", "dominant9", "sus4"],
        max_chord_extensions=5,
        use_chromaticism=0.5,
        use_modulation=0.3,
        time_signatures=[(4, 4), (3, 4), (5, 4)],
        tempo_range=(50, 110),
        typical_voices=3,
        dynamic_range=0.6,
        articulation=["legato", "pianissimo", "tremolo"],
        instruments=["piano", "harp", "flute", "strings"],
    ),
    "jazz": EpochProfile(
        name="Jazz", era="1900–",
        description="Blues-Schema, Bebop-Changes, Modal Jazz, Free Jazz",
        preferred_scales=["major", "dorian", "mixolydian", "blues", "chromatic"],
        preferred_chords=["dominant7", "major7", "minor7", "diminished7", "dominant9"],
        max_chord_extensions=5,
        use_chromaticism=0.7,
        use_modulation=0.5,
        time_signatures=[(4, 4), (3, 4)],
        tempo_range=(80, 280),
        swing_amount=0.6,
        rhythmic_complexity=0.8,
        typical_voices=4,
        dynamic_range=0.7,
        articulation=["swing", "legato", "staccato", "ghost_note"],
        progression_patterns=["ii-V-I", "I-vi-ii-V", "blues_12"],
        instruments=["piano", "bass", "drums", "saxophone", "trumpet"],
    ),
    "blues": EpochProfile(
        name="Blues", era="1870–",
        description="12-Takt, Pentatonik, Blue Notes, Shuffle",
        preferred_scales=["blues", "pentatonic_minor", "mixolydian"],
        preferred_chords=["dominant7"],
        max_chord_extensions=4,
        use_chromaticism=0.3,
        time_signatures=[(4, 4), (12, 8)],
        tempo_range=(60, 140),
        swing_amount=0.5,
        typical_voices=3,
        progression_patterns=["blues_12"],
        instruments=["guitar", "bass", "drums", "harmonica", "piano"],
    ),
    "rock": EpochProfile(
        name="Rock/Pop", era="1950–",
        description="Vierakkord-Progressionen, Vers-Refrain, Power Chords",
        preferred_scales=["major", "minor", "pentatonic_minor", "mixolydian"],
        preferred_chords=["major", "minor", "power_chord"],
        max_chord_extensions=3,
        time_signatures=[(4, 4)],
        tempo_range=(100, 160),
        rhythmic_complexity=0.5,
        typical_voices=4,
        progression_patterns=["I-V-vi-IV", "I-IV-V-I", "vi-IV-I-V"],
        instruments=["guitar", "bass", "drums", "vocals", "keyboard"],
    ),
    "electronic": EpochProfile(
        name="Electronic", era="1970–",
        description="Synth-Sequenzen, Arpeggiator, Sidechain, Drop",
        preferred_scales=["minor", "phrygian", "harmonic_minor"],
        preferred_chords=["minor", "sus2", "power_chord"],
        max_chord_extensions=3,
        time_signatures=[(4, 4)],
        tempo_range=(110, 150),
        rhythmic_complexity=0.7,
        typical_voices=3,
        instruments=["synthesizer", "drum_machine", "sampler", "bass_synth"],
    ),
    "hiphop": EpochProfile(
        name="Hip-Hop", era="1980–",
        description="Boom Bap, Trap, Lo-Fi Beats, Sample-Chop-Logik",
        preferred_scales=["minor", "pentatonic_minor", "blues", "dorian"],
        preferred_chords=["minor", "minor7"],
        max_chord_extensions=4,
        time_signatures=[(4, 4)],
        tempo_range=(70, 160),
        swing_amount=0.3,
        rhythmic_complexity=0.6,
        typical_voices=3,
        instruments=["sampler", "808", "bass_synth", "piano"],
    ),
    "metal": EpochProfile(
        name="Metal", era="1970–",
        description="Riff-Generator, Palm Mute, Blast Beat, Drop Tuning",
        preferred_scales=["minor", "phrygian", "harmonic_minor", "locrian"],
        preferred_chords=["power_chord", "diminished"],
        max_chord_extensions=2,
        use_chromaticism=0.5,
        time_signatures=[(4, 4), (7, 8), (5, 4)],
        tempo_range=(100, 240),
        rhythmic_complexity=0.8,
        typical_voices=4,
        dynamic_range=0.4,
        instruments=["guitar_distorted", "bass", "drums", "vocals"],
    ),
    "latin": EpochProfile(
        name="Latin", era="Salsa, Bossa Nova, Samba",
        description="Clave-Rhythmen, Montuno",
        preferred_scales=["major", "dorian", "mixolydian"],
        preferred_chords=["major7", "minor7", "dominant7"],
        max_chord_extensions=4,
        time_signatures=[(4, 4), (6, 8)],
        tempo_range=(90, 160),
        swing_amount=0.2,
        rhythmic_complexity=0.9,
        typical_voices=5,
        instruments=["piano", "bass", "congas", "timbales", "trumpet"],
    ),
    "film": EpochProfile(
        name="Filmmusik", era="1930–",
        description="Leitmotiv, Mickey-Mousing, Orchestration",
        preferred_scales=["major", "minor", "harmonic_minor", "whole_tone"],
        preferred_chords=["major", "minor", "augmented", "diminished7", "sus4"],
        max_chord_extensions=5,
        use_chromaticism=0.5,
        use_modulation=0.7,
        time_signatures=[(4, 4), (3, 4), (6, 8)],
        tempo_range=(40, 180),
        typical_voices=6,
        dynamic_range=1.0,
        instruments=["orchestra", "strings", "brass", "woodwinds", "percussion", "choir"],
    ),
    "minimalism": EpochProfile(
        name="Minimalismus", era="1960–",
        description="Steve Reich Phasing, Glass Arpeggios, Additive Prozesse",
        preferred_scales=["major", "dorian", "mixolydian"],
        preferred_chords=["major", "minor", "sus2"],
        max_chord_extensions=3,
        time_signatures=[(4, 4), (3, 4), (5, 4), (7, 8)],
        tempo_range=(100, 140),
        rhythmic_complexity=0.3,
        typical_voices=3,
        instruments=["piano", "marimba", "strings", "organ"],
    ),
    "ambient": EpochProfile(
        name="Ambient", era="1970–",
        description="Drones, Generative Loops, Granular Texturen",
        preferred_scales=["major", "pentatonic_major", "whole_tone", "lydian"],
        preferred_chords=["major7", "sus2", "add9"],
        max_chord_extensions=5,
        use_chromaticism=0.2,
        time_signatures=[(4, 4)],
        tempo_range=(50, 90),
        rhythmic_complexity=0.1,
        typical_voices=2,
        dynamic_range=0.3,
        instruments=["synthesizer", "pad", "granular", "reverb"],
    ),
}


# ═══════════════════════════════════════════════════════════════
# KK4: Rhythm Engine
# ═══════════════════════════════════════════════════════════════

@dataclass
class RhythmPattern:
    """A rhythm pattern with note positions and velocities."""
    name: str
    time_signature: Tuple[int, int]  # (numerator, denominator)
    # Hits: list of (beat_position, velocity, duration_beats)
    hits: List[Tuple[float, int, float]] = field(default_factory=list)
    swing: float = 0.0


# Common rhythm patterns per style
RHYTHM_PATTERNS: Dict[str, List[RhythmPattern]] = {
    "rock_basic": [
        RhythmPattern("Rock Beat", (4, 4), [
            (0.0, 100, 0.5), (1.0, 80, 0.5),   # kick
            (2.0, 100, 0.5), (3.0, 80, 0.5),   # snare on 2,4
        ]),
    ],
    "jazz_swing": [
        RhythmPattern("Swing Ride", (4, 4), [
            (0.0, 90, 0.67), (0.67, 60, 0.33),  # ding-da-ding
            (1.0, 90, 0.67), (1.67, 60, 0.33),
            (2.0, 90, 0.67), (2.67, 60, 0.33),
            (3.0, 90, 0.67), (3.67, 60, 0.33),
        ], swing=0.67),
    ],
    "blues_shuffle": [
        RhythmPattern("Blues Shuffle", (4, 4), [
            (0.0, 100, 0.67), (0.67, 70, 0.33),
            (1.0, 90, 0.67), (1.67, 70, 0.33),
            (2.0, 100, 0.67), (2.67, 70, 0.33),
            (3.0, 90, 0.67), (3.67, 70, 0.33),
        ], swing=0.6),
    ],
    "latin_clave": [
        RhythmPattern("Son Clave 3-2", (4, 4), [
            (0.0, 100, 0.25), (0.75, 90, 0.25),
            (1.5, 90, 0.25),  # bar 1: 3 hits
            (2.5, 90, 0.25), (3.0, 90, 0.25),   # bar 2: 2 hits
        ]),
    ],
    "electronic_four": [
        RhythmPattern("Four on the Floor", (4, 4), [
            (0.0, 110, 0.25), (1.0, 100, 0.25),
            (2.0, 110, 0.25), (3.0, 100, 0.25),
        ]),
    ],
    "metal_blast": [
        RhythmPattern("Blast Beat", (4, 4), [
            (i * 0.25, 110, 0.125) for i in range(16)
        ]),
    ],
}


class RhythmEngine:
    """Generate rhythm patterns with humanization.

    KK4: Rhythmus-Engine
    """

    @staticmethod
    def generate_pattern(style: str, bars: int = 4,
                         tempo: int = 120) -> List[RhythmPattern]:
        """Generate rhythm patterns for a given style."""
        patterns = RHYTHM_PATTERNS.get(style, RHYTHM_PATTERNS.get("rock_basic", []))
        result = []
        for bar in range(bars):
            for p in patterns:
                shifted = RhythmPattern(
                    name=f"{p.name} (bar {bar + 1})",
                    time_signature=p.time_signature,
                    hits=[(h[0] + bar * p.time_signature[0], h[1], h[2])
                          for h in p.hits],
                    swing=p.swing,
                )
                result.append(shifted)
        return result

    @staticmethod
    def humanize(hits: List[Tuple[float, int, float]],
                 timing_var: float = 0.02,
                 velocity_var: float = 10,
                 use_golden_ratio: bool = True) -> List[Tuple[float, int, float]]:
        """Apply humanization to rhythm hits.

        Args:
            hits: List of (beat_pos, velocity, duration)
            timing_var: Max timing deviation in beats (default ±20ms @ 120bpm)
            velocity_var: Max velocity deviation (0–127)
            use_golden_ratio: Use golden ratio for more natural variation

        Returns humanized hits.
        """
        phi = (1 + math.sqrt(5)) / 2  # golden ratio
        result = []

        for i, (pos, vel, dur) in enumerate(hits):
            if use_golden_ratio:
                # Golden ratio modulated variation (more natural than pure random)
                phase = (i * phi) % 1.0
                t_offset = timing_var * math.sin(phase * 2 * math.pi)
                v_offset = velocity_var * math.cos(phase * 3.7)
            else:
                t_offset = random.gauss(0, timing_var * 0.5)
                v_offset = random.gauss(0, velocity_var * 0.5)

            new_pos = max(0.0, pos + t_offset)
            new_vel = max(1, min(127, int(vel + v_offset)))
            result.append((new_pos, new_vel, dur))

        return result

    @staticmethod
    def polyrhythm(base: int, over: int, bars: int = 1,
                   velocity: int = 100) -> List[Tuple[float, int, float]]:
        """Generate a polyrhythm pattern (e.g. 3:4, 5:4, 7:4).

        Args:
            base: Base rhythm subdivisions per bar
            over: Overlay rhythm subdivisions per bar
        """
        total_beats = bars * 4  # assuming 4/4

        base_hits = [(i * total_beats / base, velocity, 0.1)
                     for i in range(base * bars)]
        over_hits = [(i * total_beats / over, int(velocity * 0.8), 0.1)
                     for i in range(over * bars)]

        return sorted(base_hits + over_hits, key=lambda h: h[0])


# ═══════════════════════════════════════════════════════════════
# Main Interface
# ═══════════════════════════════════════════════════════════════

class EpochEngine:
    """Unified interface for epoch profiles and rhythm generation."""

    def __init__(self):
        self.profiles = EPOCH_PROFILES

    def get_profile(self, epoch: str) -> Optional[EpochProfile]:
        """Get a style profile by name."""
        return self.profiles.get(epoch.lower())

    def list_epochs(self) -> List[str]:
        """List all available epoch names."""
        return list(self.profiles.keys())

    def suggest_tempo(self, epoch: str) -> int:
        """Suggest a tempo for an epoch."""
        profile = self.get_profile(epoch)
        if profile is None:
            return 120
        lo, hi = profile.tempo_range
        return random.randint(lo, hi)

    def suggest_scale(self, epoch: str) -> str:
        """Suggest a scale for an epoch."""
        profile = self.get_profile(epoch)
        if profile is None:
            return "major"
        return random.choice(profile.preferred_scales)

    def generate_rhythm(self, epoch: str, bars: int = 4) -> List[RhythmPattern]:
        """Generate rhythm patterns for an epoch."""
        style_map = {
            "jazz": "jazz_swing", "blues": "blues_shuffle",
            "latin": "latin_clave", "electronic": "electronic_four",
            "metal": "metal_blast", "rock": "rock_basic",
            "hiphop": "electronic_four",
        }
        style = style_map.get(epoch, "rock_basic")
        return RhythmEngine.generate_pattern(style, bars)

    def get_progression_for_epoch(self, epoch: str) -> List[str]:
        """Get typical chord progression patterns for an epoch."""
        profile = self.get_profile(epoch)
        if profile is None or not profile.progression_patterns:
            return ["I-IV-V-I"]
        return profile.progression_patterns
