# FLUX × Claude — Programmierungs-API
**Wie Anno und Claude gemeinsam neue Sound-Module für FLUX bauen**

---

## Kern-Idee

FLUX-Module bestehen aus drei parallelen Schichten — alle drei
müssen synchron geändert werden, sonst bricht das Modul:

| Schicht | Datei | Was beschrieben wird |
|---|---|---|
| **Mythologie** | `pydaw/flux/yggdrasil.py` | Gott-Familie, Farbe, Glyphe, Kategorie |
| **Schnittstelle** | `pydaw/flux/module_library.py` | Ports, Default-Params, UI-Layout |
| **DSP** | `pydaw_engine/src/flux/modules.rs` | Audio-Verarbeitung in Rust |

In jeder Folge-Session ergänzt Claude alle drei Schichten **zusammen**
für ein neues Modul. Anno reviewt + buildet + testet.

---

## Workflow für eine Modul-Anlage-Session

### 1. Anno fordert ein neues Modul

> *"Claude, bau mir bitte einen Iduna.Reverb (Plate-Style)."*

### 2. Claude prüft die drei Schichten

**Yggdrasil:** Iduna ist registriert (Indigo, Time-Kategorie) ✅ — keine Änderung
nötig. Wäre ein Gott neu, würde Claude in `GODS`-Dict einen
`GodDescriptor` mit Farbe + Glyphe + Kategorie ergänzen.

**Module-Library:** Factory-Funktion ergänzen:

```python
def make_iduna_reverb_plate() -> Module:
    """Iduna.ReverbPlate — Plate-Reverb (Schroeder-Topologie)."""
    return Module(
        god="Iduna",
        kind="ReverbPlate",
        params={"size": 0.7, "damping": 0.5, "mix": 0.3},
        inputs=[
            _audio_in("audio_in_l", "L In"),
            _audio_in("audio_in_r", "R In"),
            _cv_in("size",    "Size",    0.7,  0.0, 1.0),
            _cv_in("damping", "Damping", 0.5,  0.0, 1.0),
            _cv_in("mix",     "Wet/Dry", 0.3,  0.0, 1.0),
        ],
        outputs=[
            _audio_out("audio_out_l", "L Out"),
            _audio_out("audio_out_r", "R Out"),
        ],
    )

# In MODULE_REGISTRY ergänzen:
MODULE_REGISTRY[("Iduna", "ReverbPlate")] = make_iduna_reverb_plate
```

**Rust-DSP:** entweder neu schreiben oder bestehende
`fx/reverb.rs` als FluxModule wrappen:

```rust
// pydaw_engine/src/flux/modules.rs

use crate::fx::reverb::PlateReverb;

pub struct IdunaReverbPlate {
    inner: PlateReverb,
    output: AudioBlock,
}

impl FluxModule for IdunaReverbPlate {
    fn name(&self) -> &str { "Iduna.ReverbPlate" }
    fn set_sample_rate(&mut self, sr: f32) { self.inner.set_sample_rate(sr); }
    fn process(&mut self, inputs: &HashMap<String, &AudioBlock>, n: usize) {
        if self.output.len() != n { self.output = AudioBlock::silent(n); }
        if let (Some(l), Some(r)) = (inputs.get("audio_in_l"), inputs.get("audio_in_r")) {
            for i in 0..n {
                let (out_l, out_r) = self.inner.process(l.left[i], r.right[i]);
                self.output.left[i]  = out_l;
                self.output.right[i] = out_r;
            }
        }
    }
    fn output(&self) -> &AudioBlock { &self.output }
    fn set_param(&mut self, name: &str, v: f32) {
        match name {
            "size"    => self.inner.set_size(v),
            "damping" => self.inner.set_damping(v),
            "mix"     => self.inner.set_mix(v),
            _ => {}
        }
    }
}

// In module_factory() ergänzen:
"Iduna.ReverbPlate" => Some(Box::new(modules::IdunaReverbPlate::new())),
```

### 3. Claude verifiziert beide Schichten

* Python-Seite: `python3 -c "from pydaw.flux import make_module; ..."`
* Rust-Seite: `cargo check -p pydaw_engine` (Build-Test)
* Smoke-Test: Modul wird geladen, Demo-Patch hängt es ein, Audio läuft

### 4. Anno testet live + reviewt

Anno startet die DAW, sieht das neue Modul in der Palette, doppelklickt,
verbindet, hört. Bei Fehlverhalten → Folge-Session zum Fix.

---

## Sicherheits-Regeln für Claude in FLUX-Sessions

**OBERSTE DIREKTIVE:** NICHTS KAPUTT MACHEN. FLUX ist additiv.

1. **Niemals** bestehende Module umbenennen oder entfernen ohne explizite
   Anno-Erlaubnis (sonst brechen alte Patches).
2. **Niemals** Port-Schemas existierender Module ändern (Patches verlieren
   ihre Verbindungen). Stattdessen: neue Variante anlegen
   (`Iduna.ReverbPlate` neben `Iduna.ReverbHall`).
3. **Niemals** `Cargo.toml`-Versionen erfinden — SemVer-Regel
   (Pre-ZIP-Pipeline-Lehre v.166).
4. **Niemals** ohne Test-Rendering committen — mindestens ein Mock-
   Smoke-Test pro neuem Modul (Pre-ZIP-Pipeline-Lehre v.168).
5. **Niemals** `rm`, `rm -rf`, `format`, `find -delete` oder ähnliche
   destruktive Operationen.
6. **Defensives Coding:** alle Imports in `try/except`, alle Disk-Zugriffe
   robust gegen Fehlen von Files. Ein Fehler in FLUX darf den Editor-Tab
   nicht zum Crash bringen.

---

## Auto-Patch-KI (Odin-Modul)

Eine spätere Phase (F-15 ff): Odin als KI-Modul, das **automatisch**
Patches aufbaut. Beispiel-Workflow:

1. Anno: *"Bau mir einen schmutzigen 90er-Acid-Bass"*
2. Odin schickt die Anfrage an einen lokalen oder remote LLM
3. LLM antwortet mit JSON-Patch:
   ```json
   {
     "modules": [
       {"god":"Bragi", "kind":"SawOsc"},
       {"god":"Forseti", "kind":"Lowpass24"},
       {"god":"Loki", "kind":"LFO"},
       {"god":"Thor", "kind":"TubeDistortion"},
       {"god":"Heimdall", "kind":"MasterOut"}
     ],
     "connections": [...]
   }
   ```
4. FLUX importiert den Patch via `Patch.from_dict()`
5. Layout-Manager (Odin) ordnet die Module räumlich an
6. Anno hört, regelt nach, fertig

Für F-0 ist das **noch nicht implementiert** — die JSON-Schnittstelle
(`Patch.to_dict()`/`from_dict()`) ist aber schon bereit.

---

## Cluster-Erkennung (zukünftig F-20)

Inspiriert von WAECHTER's `Argus`-Cluster-Detection: Das System erkennt
**ähnliche Verbindungs-Muster** und schlägt vor, sie zu einem
**Yggdrasil-Container** (Sub-Patch) zusammenzufassen.

Beispiel: Drei Tracks haben jedes mal *Bragi.Saw → Forseti.LP24 → Thor.Drive*.
FLUX-KI erkennt: "Du baust gerade dreimal denselben Acid-Bass — soll ich
das zu einem `MyAcidBass`-Container kapseln?"

---

## Tasten-Combos (komplett)

| Combo | Wirkung |
|---|---|
| Doppelklick auf Canvas | Modul-Auswahl-Popup an Klick-Position |
| Drag von Output-Port | Verbindungs-Kabel zum Ziel-Input-Port |
| Drag von Input-Port (mit Verbindung) | Trennen (F-1) |
| Drag eines Moduls | Verschieben |
| Klick auf Modul | Selektieren → Properties-Panel |
| Strg+Klick | Multi-Select |
| Strg+A | Alles selektieren |
| Del / Backspace | Selektion löschen |
| Strg+D | Selektion duplizieren (F-1) |
| Strg+R | Selektion umbenennen (F-1) |
| Mausrad | Zoom (Ankerpunkt = Cursor) |
| Mittlere Maustaste-Drag | Pan (F-1) |
| Strg+S (DAW-global) | Patch wird mit Projekt gespeichert |

---

## Daten-Persistenz

FLUX-Patches landen im Projekt-JSON unter:

```json
{
  "flux_patches": [
    {
      "id": "patch_xyz",
      "name": "Acid Bass",
      "modules": [...],
      "connections": [...]
    }
  ],
  "tracks": [
    {
      "id": "trk_1",
      "flux_patch_id": "patch_xyz"   // optionale Referenz
    }
  ]
}
```

Die `Patch.to_dict()` / `Patch.from_dict()` Methoden sind bereits
JSON-kompatibel. Folge-Session F-2 hängt das in den Save-Pfad
(analog zum VST-Preset-Mechanismus aus v0.0.21.168).
