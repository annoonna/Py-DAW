"""mix_analysis.py — Audio-Based Mix Analysis & Recommendations.

v0.0.20.910 — C4.3: KI-Kompositions-Feature.

Analyzes audio tracks for spectral balance, loudness (LUFS-approximation),
stereo width, and crest factor, then generates actionable mix recommendations.

No external dependencies — uses only numpy (already in project).

Usage:
    from pydaw.services.mix_analysis import MixAnalyzer

    analyzer = MixAnalyzer(sample_rate=48000)

    # Analyze a single track (mono or stereo numpy array)
    report = analyzer.analyze_track(audio_data, name="Kick")
    print(report.lufs)         # → -14.2
    print(report.spectral)     # → {"sub": -18.3, "low": -10.1, ...}
    print(report.suggestions)  # → ["Low-end heavy — consider HP filter at 40Hz"]

    # Analyze full mix (dict of track_name → audio_data)
    mix_report = analyzer.analyze_mix({
        "Kick": kick_data,
        "Bass": bass_data,
        "Vocals": vocal_data,
    })
    print(mix_report.conflicts)     # → frequency conflict warnings
    print(mix_report.suggestions)   # → overall mix suggestions
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

log = logging.getLogger(__name__)

try:
    import numpy as np
    _HAS_NUMPY = True
except ImportError:
    np = None  # type: ignore
    _HAS_NUMPY = False


# ---------------------------------------------------------------------------
# Constants — Frequency Band Definitions
# ---------------------------------------------------------------------------

# Standard mix analysis bands (Hz)
FREQUENCY_BANDS = {
    "sub":        (20, 60),
    "low":        (60, 250),
    "low_mid":    (250, 500),
    "mid":        (500, 2000),
    "high_mid":   (2000, 6000),
    "high":       (6000, 12000),
    "air":        (12000, 20000),
}

# Reference balance targets (relative dB from peak, approximate)
# Based on typical mastered pop/rock mixes
REFERENCE_BALANCE = {
    "sub":     -18.0,
    "low":     -10.0,
    "low_mid": -8.0,
    "mid":     -6.0,
    "high_mid": -8.0,
    "high":    -12.0,
    "air":     -20.0,
}

# LUFS targets for different contexts
LUFS_TARGETS = {
    "streaming":  -14.0,   # Spotify, YouTube, Apple Music
    "broadcast":  -23.0,   # EBU R128
    "cd":         -9.0,    # CD mastering
    "podcast":    -16.0,   # Podcast standard
}

# Acceptable deviation from reference (dB)
BAND_TOLERANCE = 6.0


# ---------------------------------------------------------------------------
# Data Classes
# ---------------------------------------------------------------------------

@dataclass
class TrackAnalysis:
    """Analysis result for a single audio track."""
    name: str = ""
    # Loudness
    rms_db: float = -100.0
    peak_db: float = -100.0
    lufs: float = -100.0         # Approximated integrated LUFS
    crest_factor_db: float = 0.0  # Peak - RMS (dynamic range indicator)
    # Spectral balance (band → dB)
    spectral: Dict[str, float] = field(default_factory=dict)
    # Stereo
    stereo_width: float = 0.0    # 0.0 = mono, 1.0 = full stereo
    stereo_balance: float = 0.0  # -1.0 = left, 0.0 = center, 1.0 = right
    # DC offset
    dc_offset: float = 0.0
    # Suggestions
    suggestions: List[str] = field(default_factory=list)
    # Duration
    duration_seconds: float = 0.0
    # Is clipping?
    clipping: bool = False


@dataclass
class FrequencyConflict:
    """Detected frequency conflict between two tracks."""
    band: str = ""
    freq_range: Tuple[float, float] = (0.0, 0.0)
    track_a: str = ""
    track_b: str = ""
    overlap_db: float = 0.0
    suggestion: str = ""


@dataclass
class MixReport:
    """Full mix analysis report."""
    tracks: List[TrackAnalysis] = field(default_factory=list)
    conflicts: List[FrequencyConflict] = field(default_factory=list)
    suggestions: List[str] = field(default_factory=list)
    overall_lufs: float = -100.0
    overall_peak_db: float = -100.0
    overall_crest_db: float = 0.0
    headroom_db: float = 0.0
    spectral_balance: Dict[str, float] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# MixAnalyzer
# ---------------------------------------------------------------------------

class MixAnalyzer:
    """Audio-based mix analysis engine.

    Analyzes tracks for loudness, spectral content, stereo image,
    and provides actionable mix improvement suggestions.
    """

    def __init__(self, sample_rate: int = 48000):
        self._sr = max(1, int(sample_rate))

    @property
    def sample_rate(self) -> int:
        return self._sr

    # ------------------------------------------------------------------
    # Single Track Analysis
    # ------------------------------------------------------------------

    def analyze_track(self, audio: "np.ndarray", name: str = "Track") -> TrackAnalysis:
        """Analyze a single audio track.

        Args:
            audio: numpy array, shape (samples,) for mono or (samples, 2) for stereo
            name: track display name

        Returns:
            TrackAnalysis with loudness, spectral, stereo metrics + suggestions
        """
        if not _HAS_NUMPY:
            return TrackAnalysis(name=name, suggestions=["numpy nicht verfügbar"])

        result = TrackAnalysis(name=name)

        try:
            audio = np.asarray(audio, dtype=np.float64)
            if audio.size == 0:
                result.suggestions.append("Leere Audio-Daten")
                return result

            # Ensure 2D: (samples, channels)
            if audio.ndim == 1:
                audio = audio.reshape(-1, 1)
            elif audio.ndim > 2:
                audio = audio.reshape(-1, audio.shape[-1])

            n_samples, n_channels = audio.shape
            result.duration_seconds = n_samples / self._sr

            # Mono mix for analysis
            mono = audio.mean(axis=1)

            # --- Loudness ---
            result.rms_db = self._rms_db(mono)
            result.peak_db = self._peak_db(mono)
            result.crest_factor_db = result.peak_db - result.rms_db
            result.lufs = self._approx_lufs(mono)
            result.clipping = bool(result.peak_db > -0.1)

            # --- DC Offset ---
            result.dc_offset = float(np.mean(mono))

            # --- Spectral Balance ---
            result.spectral = self._spectral_balance(mono)

            # --- Stereo Analysis ---
            if n_channels >= 2:
                left = audio[:, 0]
                right = audio[:, 1]
                result.stereo_width = self._stereo_width(left, right)
                result.stereo_balance = self._stereo_balance(left, right)

            # --- Generate Suggestions ---
            result.suggestions = self._track_suggestions(result)

        except Exception as e:
            log.warning("Mix analysis error for '%s': %s", name, e)
            result.suggestions.append(f"Analyse-Fehler: {e}")

        return result

    # ------------------------------------------------------------------
    # Full Mix Analysis
    # ------------------------------------------------------------------

    def analyze_mix(self, tracks: Dict[str, "np.ndarray"]) -> MixReport:
        """Analyze a full mix (multiple tracks).

        Args:
            tracks: dict of track_name → numpy audio array

        Returns:
            MixReport with per-track analysis, conflicts, and overall suggestions
        """
        if not _HAS_NUMPY:
            return MixReport(suggestions=["numpy nicht verfügbar"])

        report = MixReport()

        # Analyze each track
        for name, audio in tracks.items():
            try:
                analysis = self.analyze_track(audio, name=name)
                report.tracks.append(analysis)
            except Exception as e:
                log.warning("Skipping track '%s': %s", name, e)

        if not report.tracks:
            report.suggestions.append("Keine Tracks zum Analysieren")
            return report

        # Detect frequency conflicts
        report.conflicts = self._detect_conflicts(report.tracks)

        # Overall mix metrics
        try:
            all_audio = []
            for name, audio in tracks.items():
                arr = np.asarray(audio, dtype=np.float64)
                if arr.ndim == 1:
                    arr = arr.reshape(-1, 1)
                all_audio.append(arr)

            # Sum all tracks (simple mix)
            max_len = max(a.shape[0] for a in all_audio)
            max_ch = max(a.shape[1] for a in all_audio)
            mix_sum = np.zeros((max_len, max_ch), dtype=np.float64)
            for arr in all_audio:
                sl = min(arr.shape[0], max_len)
                ch = min(arr.shape[1], max_ch)
                mix_sum[:sl, :ch] += arr[:sl, :ch]

            mono_mix = mix_sum.mean(axis=1)
            report.overall_lufs = self._approx_lufs(mono_mix)
            report.overall_peak_db = self._peak_db(mono_mix)
            report.overall_crest_db = self._peak_db(mono_mix) - self._rms_db(mono_mix)
            report.headroom_db = 0.0 - report.overall_peak_db
            report.spectral_balance = self._spectral_balance(mono_mix)
        except Exception as e:
            log.warning("Overall mix analysis error: %s", e)

        # Overall suggestions
        report.suggestions = self._mix_suggestions(report)

        return report

    # ------------------------------------------------------------------
    # Internal: Loudness Metrics
    # ------------------------------------------------------------------

    def _rms_db(self, mono: "np.ndarray") -> float:
        """RMS level in dB."""
        rms = float(np.sqrt(np.mean(mono ** 2)))
        if rms < 1e-10:
            return -100.0
        return 20.0 * math.log10(rms)

    def _peak_db(self, mono: "np.ndarray") -> float:
        """Peak level in dB."""
        peak = float(np.max(np.abs(mono)))
        if peak < 1e-10:
            return -100.0
        return 20.0 * math.log10(peak)

    def _approx_lufs(self, mono: "np.ndarray") -> float:
        """Approximate integrated LUFS (simplified K-weighting).

        This is a simplified approximation — for precise LUFS,
        use pyloudnorm or a proper ITU-R BS.1770 implementation.
        The approximation applies a basic high-shelf boost at 2kHz
        and measures the gated loudness.
        """
        try:
            n = len(mono)
            if n < 400:
                return self._rms_db(mono) - 0.691

            # Simple K-weighting approximation: boost high frequencies
            # Apply first-order high-shelf filter (approximation)
            fc = 2000.0 / self._sr
            if fc >= 0.5:
                weighted = mono.copy()
            else:
                # Simple 1-pole high-shelf boost (~+3.5dB above 2kHz)
                alpha = 2.0 * math.pi * fc
                coeff = alpha / (alpha + 1.0)
                weighted = mono.copy()
                hp = np.zeros_like(mono)
                hp[0] = mono[0]
                for i in range(1, min(n, 50000)):  # limit for performance
                    hp[i] = coeff * hp[i-1] + coeff * (mono[i] - mono[i-1])
                if n > 50000:
                    # For long files, apply a simpler spectral boost
                    weighted = mono * 1.1  # ~+0.8dB overall
                else:
                    weighted = mono + 0.5 * hp  # add high-shelf boost

            # Gated measurement (exclude silence below -70 LUFS)
            # Use 400ms blocks
            block_size = max(1, int(0.4 * self._sr))
            n_blocks = n // block_size
            if n_blocks == 0:
                return self._rms_db(weighted) - 0.691

            block_loudness = []
            for i in range(n_blocks):
                block = weighted[i * block_size: (i + 1) * block_size]
                bl = float(np.mean(block ** 2))
                if bl > 1e-10:
                    block_loudness.append(bl)

            if not block_loudness:
                return -100.0

            # Absolute gate: -70 LUFS
            abs_gate = 10 ** (-70 / 10)
            gated = [b for b in block_loudness if b > abs_gate]
            if not gated:
                return -100.0

            # Relative gate: -10 dB below ungated mean
            ungated_mean = sum(gated) / len(gated)
            rel_gate = ungated_mean * 10 ** (-10 / 10)
            final = [b for b in gated if b > rel_gate]
            if not final:
                return -100.0

            lufs = -0.691 + 10.0 * math.log10(sum(final) / len(final))
            return round(lufs, 1)

        except Exception:
            return self._rms_db(mono) - 0.691

    # ------------------------------------------------------------------
    # Internal: Spectral Analysis
    # ------------------------------------------------------------------

    def _spectral_balance(self, mono: "np.ndarray") -> Dict[str, float]:
        """Compute energy in each frequency band (dB)."""
        result = {}
        try:
            n = len(mono)
            if n < 256:
                return {band: -100.0 for band in FREQUENCY_BANDS}

            # Use FFT
            # Window to reduce spectral leakage
            window = np.hanning(n)
            windowed = mono * window
            spectrum = np.abs(np.fft.rfft(windowed))
            freqs = np.fft.rfftfreq(n, d=1.0 / self._sr)

            # Total energy for normalization
            total_energy = float(np.sum(spectrum ** 2))
            if total_energy < 1e-20:
                return {band: -100.0 for band in FREQUENCY_BANDS}

            for band_name, (f_low, f_high) in FREQUENCY_BANDS.items():
                mask = (freqs >= f_low) & (freqs < f_high)
                band_energy = float(np.sum(spectrum[mask] ** 2))
                if band_energy < 1e-20:
                    result[band_name] = -100.0
                else:
                    # dB relative to total
                    result[band_name] = round(
                        10.0 * math.log10(band_energy / total_energy), 1
                    )
        except Exception as e:
            log.warning("Spectral analysis error: %s", e)
            result = {band: -100.0 for band in FREQUENCY_BANDS}

        return result

    # ------------------------------------------------------------------
    # Internal: Stereo Analysis
    # ------------------------------------------------------------------

    def _stereo_width(self, left: "np.ndarray", right: "np.ndarray") -> float:
        """Stereo width: 0.0 = mono, 1.0 = full stereo, >1.0 = out of phase."""
        try:
            mid = (left + right) / 2.0
            side = (left - right) / 2.0
            mid_rms = float(np.sqrt(np.mean(mid ** 2)))
            side_rms = float(np.sqrt(np.mean(side ** 2)))
            if mid_rms < 1e-10:
                return 0.0
            return round(min(2.0, side_rms / mid_rms), 3)
        except Exception:
            return 0.0

    def _stereo_balance(self, left: "np.ndarray", right: "np.ndarray") -> float:
        """Stereo balance: -1.0 = full left, 0.0 = center, 1.0 = full right."""
        try:
            l_rms = float(np.sqrt(np.mean(left ** 2)))
            r_rms = float(np.sqrt(np.mean(right ** 2)))
            total = l_rms + r_rms
            if total < 1e-10:
                return 0.0
            return round((r_rms - l_rms) / total, 3)
        except Exception:
            return 0.0

    # ------------------------------------------------------------------
    # Internal: Conflict Detection
    # ------------------------------------------------------------------

    def _detect_conflicts(self, tracks: List[TrackAnalysis]) -> List[FrequencyConflict]:
        """Detect frequency conflicts between tracks."""
        conflicts = []
        if len(tracks) < 2:
            return conflicts

        # Check each pair of tracks for overlapping bands
        for i in range(len(tracks)):
            for j in range(i + 1, len(tracks)):
                ta = tracks[i]
                tb = tracks[j]
                for band_name, freq_range in FREQUENCY_BANDS.items():
                    a_db = ta.spectral.get(band_name, -100.0)
                    b_db = tb.spectral.get(band_name, -100.0)
                    # Both tracks have significant energy in this band
                    if a_db > -20.0 and b_db > -20.0:
                        # Check if both are dominant (within 6dB of each other)
                        overlap = min(a_db, b_db)
                        if abs(a_db - b_db) < BAND_TOLERANCE and overlap > -15.0:
                            suggestion = self._conflict_suggestion(
                                band_name, ta.name, tb.name
                            )
                            conflicts.append(FrequencyConflict(
                                band=band_name,
                                freq_range=freq_range,
                                track_a=ta.name,
                                track_b=tb.name,
                                overlap_db=round(overlap, 1),
                                suggestion=suggestion,
                            ))
        return conflicts

    def _conflict_suggestion(self, band: str, track_a: str, track_b: str) -> str:
        """Generate a suggestion for resolving a frequency conflict."""
        suggestions = {
            "sub": (
                f"'{track_a}' und '{track_b}' konkurrieren im Sub-Bass. "
                f"Erwäge einen HP-Filter auf einem der Tracks bei ~60Hz."
            ),
            "low": (
                f"'{track_a}' und '{track_b}' überlappen im Bass. "
                f"Sidechain-Compression oder EQ-Carving (200-300Hz) kann helfen."
            ),
            "low_mid": (
                f"Low-Mid-Kollision zwischen '{track_a}' und '{track_b}'. "
                f"Schmaler Cut bei 250-500Hz auf einem Track."
            ),
            "mid": (
                f"Mitten-Maskierung: '{track_a}' und '{track_b}'. "
                f"Panning oder Mid/Side-EQ können die Trennung verbessern."
            ),
            "high_mid": (
                f"Obere Mitten: '{track_a}' und '{track_b}' konkurrieren. "
                f"De-esser oder dynamischer EQ bei 2-4kHz."
            ),
            "high": (
                f"Höhen-Konflikt zwischen '{track_a}' und '{track_b}'. "
                f"Leichtes Shelving oder Panning für Separation."
            ),
            "air": (
                f"Air-Band-Überlappung: '{track_a}' und '{track_b}'. "
                f"Meist unkritisch — bei Bedarf LP-Filter auf einem Track."
            ),
        }
        return suggestions.get(band, f"Frequenz-Konflikt in {band}")

    # ------------------------------------------------------------------
    # Internal: Suggestions
    # ------------------------------------------------------------------

    def _track_suggestions(self, t: TrackAnalysis) -> List[str]:
        """Generate actionable suggestions for a single track."""
        suggestions = []

        # Clipping
        if t.clipping:
            suggestions.append(
                f"⚠️ Clipping erkannt (Peak: {t.peak_db:.1f} dB). "
                f"Gain um {abs(t.peak_db):.1f} dB reduzieren."
            )

        # DC Offset
        if abs(t.dc_offset) > 0.01:
            suggestions.append(
                f"DC-Offset erkannt ({t.dc_offset:.4f}). "
                f"HP-Filter bei 20Hz oder DC-Offset-Removal anwenden."
            )

        # Crest factor (dynamics)
        if t.crest_factor_db < 3.0 and t.rms_db > -30:
            suggestions.append(
                f"Sehr geringe Dynamik (Crest: {t.crest_factor_db:.1f} dB). "
                f"Track klingt möglicherweise über-komprimiert."
            )
        elif t.crest_factor_db > 20.0 and t.rms_db > -40:
            suggestions.append(
                f"Hohe Dynamik (Crest: {t.crest_factor_db:.1f} dB). "
                f"Kompression könnte den Track gleichmäßiger machen."
            )

        # Spectral imbalances
        for band_name, db_val in t.spectral.items():
            ref = REFERENCE_BALANCE.get(band_name, -10.0)
            if db_val > ref + BAND_TOLERANCE and db_val > -20.0:
                labels = {
                    "sub": "Sub-Bass", "low": "Bass", "low_mid": "Untere Mitten",
                    "mid": "Mitten", "high_mid": "Obere Mitten",
                    "high": "Höhen", "air": "Air",
                }
                label = labels.get(band_name, band_name)
                suggestions.append(
                    f"{label} ist dominant ({db_val:.1f} dB vs. Referenz {ref:.0f} dB). "
                    f"EQ-Cut bei {FREQUENCY_BANDS[band_name][0]}-"
                    f"{FREQUENCY_BANDS[band_name][1]}Hz erwägen."
                )

        # Stereo
        if t.stereo_width > 1.2:
            suggestions.append(
                f"Breites Stereo-Bild ({t.stereo_width:.2f}). "
                f"Mögliche Phasenprobleme — Mono-Check empfohlen."
            )
        if abs(t.stereo_balance) > 0.3:
            side = "links" if t.stereo_balance < 0 else "rechts"
            suggestions.append(
                f"Track ist nach {side} verschoben (Balance: {t.stereo_balance:.2f}). "
                f"Pan-Korrektur prüfen."
            )

        return suggestions

    def _mix_suggestions(self, report: MixReport) -> List[str]:
        """Generate overall mix suggestions."""
        suggestions = []

        # Headroom
        if report.headroom_db < 1.0:
            suggestions.append(
                f"⚠️ Wenig Headroom ({report.headroom_db:.1f} dB). "
                f"Gesamtlevel reduzieren für Mastering-Spielraum."
            )
        elif report.headroom_db > 12.0:
            suggestions.append(
                f"Viel Headroom ({report.headroom_db:.1f} dB). "
                f"Mix ist relativ leise — Gain-Staging prüfen."
            )

        # LUFS targets
        lufs = report.overall_lufs
        if lufs > -100:
            if lufs > -8.0:
                suggestions.append(
                    f"Mix ist sehr laut ({lufs:.1f} LUFS). "
                    f"Streaming-Plattformen werden stark normalisieren."
                )
            elif lufs < -20.0:
                suggestions.append(
                    f"Mix ist relativ leise ({lufs:.1f} LUFS). "
                    f"Streaming-Ziel: ca. -14 LUFS."
                )
            else:
                closest = min(LUFS_TARGETS.items(),
                              key=lambda x: abs(x[1] - lufs))
                suggestions.append(
                    f"Lautheit: {lufs:.1f} LUFS "
                    f"(nah an {closest[0]}-Standard: {closest[1]:.0f} LUFS)."
                )

        # Frequency conflicts count
        n_conflicts = len(report.conflicts)
        if n_conflicts > 3:
            suggestions.append(
                f"{n_conflicts} Frequenz-Konflikte erkannt. "
                f"EQ-Carving und Panning können die Separation verbessern."
            )
        elif n_conflicts > 0:
            suggestions.append(
                f"{n_conflicts} Frequenz-Konflikt(e) erkannt — "
                f"Details in den einzelnen Konflikten."
            )

        # Spectral balance of full mix
        for band, db_val in report.spectral_balance.items():
            ref = REFERENCE_BALANCE.get(band, -10.0)
            if db_val > ref + 8.0 and db_val > -15.0:
                suggestions.append(
                    f"Mix hat Überbetonung im {band}-Bereich ({db_val:.1f} dB)."
                )

        return suggestions

    # ------------------------------------------------------------------
    # Utility: Format Report as Text
    # ------------------------------------------------------------------

    def format_report(self, report: MixReport) -> str:
        """Format a MixReport as human-readable text."""
        lines = ["═══ Mix-Analyse Bericht ═══", ""]

        # Per-track summary
        for t in report.tracks:
            lines.append(f"── {t.name} ──")
            lines.append(
                f"  LUFS: {t.lufs:.1f}  |  Peak: {t.peak_db:.1f} dB  |  "
                f"RMS: {t.rms_db:.1f} dB  |  Crest: {t.crest_factor_db:.1f} dB"
            )
            if t.stereo_width > 0:
                lines.append(
                    f"  Stereo: Breite={t.stereo_width:.2f}  "
                    f"Balance={t.stereo_balance:+.2f}"
                )
            if t.spectral:
                bands = "  Spektral: " + ", ".join(
                    f"{b}={db:.0f}dB" for b, db in t.spectral.items()
                    if db > -50
                )
                lines.append(bands)
            for s in t.suggestions:
                lines.append(f"  💡 {s}")
            lines.append("")

        # Conflicts
        if report.conflicts:
            lines.append("── Frequenz-Konflikte ──")
            for c in report.conflicts:
                lines.append(
                    f"  ⚠️ {c.band} ({c.freq_range[0]:.0f}-{c.freq_range[1]:.0f}Hz): "
                    f"{c.track_a} ↔ {c.track_b} ({c.overlap_db:.1f} dB)"
                )
                lines.append(f"     {c.suggestion}")
            lines.append("")

        # Overall
        lines.append("── Gesamt-Mix ──")
        lines.append(
            f"  LUFS: {report.overall_lufs:.1f}  |  "
            f"Peak: {report.overall_peak_db:.1f} dB  |  "
            f"Headroom: {report.headroom_db:.1f} dB"
        )
        for s in report.suggestions:
            lines.append(f"  💡 {s}")

        return "\n".join(lines)
