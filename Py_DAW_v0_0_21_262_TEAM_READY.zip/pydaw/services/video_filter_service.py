"""video_filter_service.py — VP6: Non-Destructive Video Filter Chain (v0.0.20.924).

Per-clip video filters (like Audio FX-Chain but for video).
Each clip can have an ordered list of filters applied non-destructively.
At export time, the filter chain is rendered as an ffmpeg filter_complex graph.

Supported Filters:
    - brightness   (factor: -1.0 .. 1.0, default 0.0)
    - contrast     (factor: 0.0 .. 3.0, default 1.0)
    - saturation   (factor: 0.0 .. 3.0, default 1.0)
    - gamma        (factor: 0.1 .. 5.0, default 1.0)
    - blur         (radius: 0 .. 20, default 0)
    - sharpen      (amount: 0.0 .. 5.0, default 0.0)
    - vignette     (intensity: 0.0 .. 1.0, default 0.0)
    - lut          (path to .cube file)
    - color_lift   (RGB shift for shadows, -1.0..1.0 each)
    - color_gamma  (RGB shift for midtones, -1.0..1.0 each)
    - color_gain   (RGB shift for highlights, -1.0..1.0 each)

Usage:
    from pydaw.services.video_filter_service import VideoFilterService, VideoFilter

    svc = VideoFilterService.instance()
    svc.add_filter(clip_id, VideoFilter("brightness", value=0.2))
    svc.add_filter(clip_id, VideoFilter("contrast", value=1.3))
    svc.add_filter(clip_id, VideoFilter("saturation", value=0.8))

    # Get ffmpeg filter string for export
    ffmpeg_filter = svc.get_ffmpeg_filter_string(clip_id)
    # → "eq=brightness=0.2:contrast=1.3:saturation=0.8"
"""

from __future__ import annotations

import copy
import json
import logging
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

log = logging.getLogger(__name__)


@dataclass
class VideoFilter:
    """A single video filter effect.

    Args:
        kind: Filter type name (brightness, contrast, saturation, etc.)
        value: Primary filter value (semantics depend on kind)
        enabled: Whether this filter is currently active
        params: Additional parameters (e.g. RGB values for color grading)
    """
    kind: str = "brightness"
    value: float = 0.0
    enabled: bool = True
    params: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> VideoFilter:
        return cls(
            kind=str(d.get("kind", "brightness")),
            value=float(d.get("value", 0.0)),
            enabled=bool(d.get("enabled", True)),
            params=dict(d.get("params", {})),
        )

    @property
    def display_name(self) -> str:
        names = {
            "brightness": "🔆 Helligkeit",
            "contrast": "◐ Kontrast",
            "saturation": "🎨 Sättigung",
            "gamma": "γ Gamma",
            "blur": "💨 Weichzeichner",
            "sharpen": "🔪 Schärfe",
            "vignette": "🔲 Vignette",
            "lut": "🎬 LUT",
            "color_lift": "🌑 Lift (Schatten)",
            "color_gamma": "🌗 Gamma (Mitten)",
            "color_gain": "🌕 Gain (Lichter)",
        }
        return names.get(self.kind, self.kind.title())

    @property
    def default_value(self) -> float:
        defaults = {
            "brightness": 0.0,
            "contrast": 1.0,
            "saturation": 1.0,
            "gamma": 1.0,
            "blur": 0.0,
            "sharpen": 0.0,
            "vignette": 0.0,
        }
        return defaults.get(self.kind, 0.0)

    @property
    def value_range(self) -> tuple:
        """(min, max, step) for UI sliders."""
        ranges = {
            "brightness": (-1.0, 1.0, 0.01),
            "contrast": (0.0, 3.0, 0.01),
            "saturation": (0.0, 3.0, 0.01),
            "gamma": (0.1, 5.0, 0.01),
            "blur": (0.0, 20.0, 0.5),
            "sharpen": (0.0, 5.0, 0.1),
            "vignette": (0.0, 1.0, 0.01),
        }
        return ranges.get(self.kind, (0.0, 1.0, 0.01))


class VideoFilterChain:
    """Ordered list of filters for one clip."""

    def __init__(self):
        self.filters: List[VideoFilter] = []

    def add(self, f: VideoFilter) -> None:
        self.filters.append(f)

    def remove(self, index: int) -> None:
        if 0 <= index < len(self.filters):
            self.filters.pop(index)

    def move(self, from_idx: int, to_idx: int) -> None:
        if 0 <= from_idx < len(self.filters) and 0 <= to_idx < len(self.filters):
            f = self.filters.pop(from_idx)
            self.filters.insert(to_idx, f)

    def clear(self) -> None:
        self.filters.clear()

    def to_ffmpeg_filter(self) -> str:
        """Build ffmpeg -vf filter string from active filters."""
        parts = []
        eq_parts = {}  # Merge brightness/contrast/saturation/gamma into one eq=

        for f in self.filters:
            if not f.enabled:
                continue
            kind = f.kind

            if kind == "brightness":
                eq_parts["brightness"] = f"{f.value:.3f}"
            elif kind == "contrast":
                eq_parts["contrast"] = f"{f.value:.3f}"
            elif kind == "saturation":
                eq_parts["saturation"] = f"{f.value:.3f}"
            elif kind == "gamma":
                eq_parts["gamma"] = f"{f.value:.3f}"
            elif kind == "blur":
                if f.value > 0:
                    r = max(1, int(f.value))
                    parts.append(f"boxblur={r}:{r}")
            elif kind == "sharpen":
                if f.value > 0:
                    parts.append(f"unsharp=5:5:{f.value:.2f}")
            elif kind == "vignette":
                if f.value > 0:
                    angle = f.value * 1.5  # scale to PI/5 range
                    parts.append(f"vignette=angle={angle:.3f}")
            elif kind == "lut":
                lut_path = str(f.params.get("path", ""))
                if lut_path:
                    parts.append(f"lut3d='{lut_path}'")
            elif kind in ("color_lift", "color_gamma", "color_gain"):
                r = float(f.params.get("r", 0.0))
                g = float(f.params.get("g", 0.0))
                b = float(f.params.get("b", 0.0))
                if abs(r) > 0.001 or abs(g) > 0.001 or abs(b) > 0.001:
                    prefix = kind.replace("color_", "")
                    parts.append(f"colorbalance={prefix}r={r:.3f}:{prefix}g={g:.3f}:{prefix}b={b:.3f}")

        # Merge eq= params
        if eq_parts:
            eq_str = ":".join(f"{k}={v}" for k, v in eq_parts.items())
            parts.insert(0, f"eq={eq_str}")

        return ",".join(parts)

    def has_active_filters(self) -> bool:
        return any(f.enabled for f in self.filters)

    def to_dict(self) -> list:
        return [f.to_dict() for f in self.filters]

    @classmethod
    def from_dict(cls, data: list) -> VideoFilterChain:
        chain = cls()
        for d in data:
            chain.add(VideoFilter.from_dict(d))
        return chain


class VideoFilterService:
    """Singleton service managing filter chains for all video clips.

    Thread-safe for read access. Write operations should be done from UI thread.
    """

    _instance: Optional[VideoFilterService] = None

    @classmethod
    def instance(cls) -> VideoFilterService:
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        # clip_id → VideoFilterChain
        self._chains: Dict[str, VideoFilterChain] = {}

    def get_chain(self, clip_id: str) -> VideoFilterChain:
        """Get or create filter chain for a clip."""
        if clip_id not in self._chains:
            self._chains[clip_id] = VideoFilterChain()
        return self._chains[clip_id]

    def add_filter(self, clip_id: str, f: VideoFilter) -> None:
        """Add a filter to a clip's chain."""
        self.get_chain(clip_id).add(f)
        log.info("[VideoFilter] Added %s to clip %s (value=%.3f)",
                 f.kind, clip_id[:8], f.value)

    def set_filter(self, clip_id: str, f: VideoFilter) -> None:
        """Set a filter value (replace if same kind exists, add if new).

        v0.0.20.935: Upsert semantics — replaces existing filter of same kind.
        """
        chain = self.get_chain(clip_id)
        for i, existing in enumerate(chain.filters):
            if existing.kind == f.kind:
                chain.filters[i] = f
                return
        chain.add(f)

    def remove_filter(self, clip_id: str, index: int) -> None:
        """Remove a filter by index from a clip's chain."""
        chain = self._chains.get(clip_id)
        if chain:
            chain.remove(index)

    def clear_filters(self, clip_id: str) -> None:
        """Remove all filters from a clip."""
        if clip_id in self._chains:
            self._chains[clip_id].clear()

    def get_ffmpeg_filter_string(self, clip_id: str) -> str:
        """Get the ffmpeg -vf filter string for a clip."""
        chain = self._chains.get(clip_id)
        if not chain:
            return ""
        return chain.to_ffmpeg_filter()

    def has_filters(self, clip_id: str) -> bool:
        """Check if clip has any active filters."""
        chain = self._chains.get(clip_id)
        return bool(chain and chain.has_active_filters())

    def duplicate_chain(self, src_clip_id: str, dst_clip_id: str) -> None:
        """Copy filter chain from one clip to another."""
        chain = self._chains.get(src_clip_id)
        if chain:
            self._chains[dst_clip_id] = copy.deepcopy(chain)

    # ── Persistence ──────────────────────────────────────────

    def save_all(self) -> dict:
        """Serialize all filter chains to dict (for DB/JSON save)."""
        return {
            cid: chain.to_dict()
            for cid, chain in self._chains.items()
            if chain.filters
        }

    def load_all(self, data: dict) -> None:
        """Load filter chains from dict."""
        self._chains.clear()
        for cid, chain_data in data.items():
            try:
                self._chains[cid] = VideoFilterChain.from_dict(chain_data)
            except Exception as e:
                log.debug("[VideoFilter] load error for %s: %s", cid, e)

    def save_to_db(self, db) -> None:
        """Save all filter chains to the project database."""
        try:
            data = self.save_all()
            if not data:
                return
            json_str = json.dumps(data)
            if hasattr(db, 'set_meta'):
                db.set_meta("video_filter_chains", json_str)
            elif hasattr(db, 'execute'):
                db.execute(
                    "INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
                    ("video_filter_chains", json_str),
                )
                db.commit()
            log.info("[VideoFilter] Saved %d filter chains to DB", len(data))
        except Exception as e:
            log.debug("[VideoFilter] save_to_db: %s", e)

    def load_from_db(self, db) -> None:
        """Load filter chains from the project database."""
        try:
            json_str = None
            if hasattr(db, 'get_meta'):
                json_str = db.get_meta("video_filter_chains")
            elif hasattr(db, 'execute'):
                row = db.execute(
                    "SELECT value FROM meta WHERE key = ?",
                    ("video_filter_chains",),
                ).fetchone()
                if row:
                    json_str = row[0]
            if json_str:
                data = json.loads(json_str)
                self.load_all(data)
                log.info("[VideoFilter] Loaded %d filter chains from DB",
                         len(self._chains))
        except Exception as e:
            log.debug("[VideoFilter] load_from_db: %s", e)

    # ── Preset Library ───────────────────────────────────────

    @staticmethod
    def preset_chains() -> Dict[str, List[VideoFilter]]:
        """Built-in filter presets for quick application."""
        return {
            "Warm Sunset": [
                VideoFilter("brightness", 0.05),
                VideoFilter("contrast", 1.1),
                VideoFilter("saturation", 1.2),
                VideoFilter("color_gain", params={"r": 0.1, "g": 0.02, "b": -0.05}),
            ],
            "Cool Blue": [
                VideoFilter("brightness", -0.03),
                VideoFilter("contrast", 1.15),
                VideoFilter("saturation", 0.85),
                VideoFilter("color_lift", params={"r": -0.05, "g": 0.0, "b": 0.08}),
            ],
            "Film Noir": [
                VideoFilter("saturation", 0.0),
                VideoFilter("contrast", 1.4),
                VideoFilter("vignette", 0.6),
                VideoFilter("gamma", 0.85),
            ],
            "Vintage 8mm": [
                VideoFilter("saturation", 0.7),
                VideoFilter("contrast", 1.2),
                VideoFilter("brightness", 0.08),
                VideoFilter("vignette", 0.4),
                VideoFilter("color_lift", params={"r": 0.06, "g": 0.03, "b": -0.02}),
            ],
            "High Contrast": [
                VideoFilter("contrast", 1.5),
                VideoFilter("saturation", 1.1),
                VideoFilter("sharpen", 1.5),
            ],
            "Soft Dreamy": [
                VideoFilter("blur", 1.5),
                VideoFilter("brightness", 0.06),
                VideoFilter("saturation", 1.1),
                VideoFilter("contrast", 0.9),
            ],
        }

    def apply_preset(self, clip_id: str, preset_name: str) -> bool:
        """Apply a built-in preset to a clip (replaces existing chain)."""
        presets = self.preset_chains()
        if preset_name not in presets:
            return False
        chain = self.get_chain(clip_id)
        chain.clear()
        for f in presets[preset_name]:
            chain.add(copy.deepcopy(f))
        log.info("[VideoFilter] Applied preset '%s' to clip %s",
                 preset_name, clip_id[:8])
        return True
