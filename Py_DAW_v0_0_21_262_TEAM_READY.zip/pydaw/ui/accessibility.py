"""Accessibility Service (Tech Debt) — Screen-Reader & Keyboard Navigation.

Makes Py_DAW accessible for users with visual or motor impairments.

Features:
- Screen-reader-friendly labels (QAccessible)
- Keyboard navigation for all major panels
- Focus indicators (visible focus ring)
- ARIA-like role descriptions for custom widgets
- Tab order management
- Keyboard shortcut overlay (show all shortcuts)
- Announce mode: speak status changes via QAccessible
- High contrast mode integration (see theme_manager)
- Reduced motion mode (disable animations)

v0.0.20.814 — Tech Debt: Accessibility
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any, Callable

from PyQt6.QtCore import QObject, pyqtSignal, Qt, QSettings, QTimer
from PyQt6.QtGui import QKeySequence, QShortcut, QAction
from PyQt6.QtWidgets import (
    QWidget, QApplication, QMainWindow, QPushButton, QLabel,
    QSlider, QSpinBox, QComboBox, QCheckBox, QToolButton,
    QDockWidget, QTabWidget, QStatusBar, QAccessibleWidget,
)

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class AccessibilityConfig:
    """User accessibility preferences."""
    screen_reader_enabled: bool = False
    announce_transport: bool = True       # announce play/stop/record
    announce_selection: bool = True       # announce track/clip selection
    announce_values: bool = True          # announce slider/knob value changes
    keyboard_nav_enabled: bool = True
    focus_indicators: bool = True         # visible focus ring on all widgets
    reduced_motion: bool = False          # disable animations
    large_text: bool = False              # increase font size by 30%
    high_contrast: bool = False           # use high contrast theme
    tooltip_delay_ms: int = 500           # tooltip delay (shorter for accessibility)
    tab_focus_wrap: bool = True           # Tab wraps around at end of panel

    def to_dict(self) -> dict:
        return {k: v for k, v in self.__dict__.items()}

    @staticmethod
    def from_dict(data: dict) -> AccessibilityConfig:
        cfg = AccessibilityConfig()
        for k, v in data.items():
            if hasattr(cfg, k):
                setattr(cfg, k, type(getattr(cfg, k))(v))
        return cfg


# ---------------------------------------------------------------------------
# Widget labeling helpers
# ---------------------------------------------------------------------------

def set_accessible_name(widget: QWidget, name: str) -> None:
    """Set accessible name for screen readers."""
    try:
        widget.setAccessibleName(name)
    except Exception:
        pass


def set_accessible_description(widget: QWidget, desc: str) -> None:
    """Set accessible description (extended help text)."""
    try:
        widget.setAccessibleDescription(desc)
    except Exception:
        pass


def label_widget(widget: QWidget, name: str, role: str = "",
                 description: str = "") -> None:
    """Set all accessibility properties on a widget at once.

    Args:
        widget: the Qt widget
        name: screen-reader name (e.g. "Track 1 Volume")
        role: ARIA-like role (e.g. "slider", "button", "fader")
        description: extended help text
    """
    set_accessible_name(widget, name)
    if description:
        set_accessible_description(widget, description)
    if role:
        widget.setProperty("accessibleRole", role)
    # Ensure widget is focusable via keyboard
    try:
        policy = widget.focusPolicy()
        if policy == Qt.FocusPolicy.NoFocus:
            widget.setFocusPolicy(Qt.FocusPolicy.TabFocus)
    except Exception:
        pass


def label_track_widgets(
    track_widgets: Dict[str, Dict[str, QWidget]],
    tracks: list,
) -> None:
    """Bulk-label all track mixer widgets for screen readers.

    Args:
        track_widgets: {track_id: {"fader": QSlider, "pan": QDial, ...}}
        tracks: list of track objects with .name attribute
    """
    for track in tracks:
        tid = getattr(track, 'id', '')
        name = getattr(track, 'name', 'Track')
        widgets = track_widgets.get(tid, {})

        if "fader" in widgets:
            label_widget(widgets["fader"],
                         f"{name} Lautstärke", "slider",
                         f"Lautstärke für Track {name}, 0 bis 100 Prozent")
        if "pan" in widgets:
            label_widget(widgets["pan"],
                         f"{name} Panorama", "slider",
                         f"Stereo-Position für Track {name}, Links bis Rechts")
        if "mute" in widgets:
            label_widget(widgets["mute"],
                         f"{name} Stumm", "toggle",
                         f"Track {name} stummschalten")
        if "solo" in widgets:
            label_widget(widgets["solo"],
                         f"{name} Solo", "toggle",
                         f"Nur Track {name} abhören")
        if "record" in widgets:
            label_widget(widgets["record"],
                         f"{name} Aufnahme", "toggle",
                         f"Aufnahme auf Track {name} aktivieren")


# ---------------------------------------------------------------------------
# Keyboard shortcut registry
# ---------------------------------------------------------------------------

@dataclass
class ShortcutEntry:
    """A registered keyboard shortcut."""
    key: str                    # e.g. "Ctrl+S"
    action: str                 # e.g. "Projekt speichern"
    category: str = "Allgemein"  # e.g. "Transport", "Editing", "Navigation"
    is_global: bool = True


class ShortcutRegistry:
    """Central registry for all keyboard shortcuts.

    Enables showing a complete shortcut overlay to the user.
    """

    def __init__(self):
        self._shortcuts: List[ShortcutEntry] = []
        self._register_defaults()

    def register(self, key: str, action: str, category: str = "Allgemein",
                 is_global: bool = True) -> None:
        """Register a keyboard shortcut."""
        self._shortcuts.append(ShortcutEntry(key, action, category, is_global))

    def get_all(self) -> List[ShortcutEntry]:
        return list(self._shortcuts)

    def get_by_category(self) -> Dict[str, List[ShortcutEntry]]:
        result: Dict[str, List[ShortcutEntry]] = {}
        for s in self._shortcuts:
            result.setdefault(s.category, []).append(s)
        return result

    def to_text(self) -> str:
        """Generate a formatted text list of all shortcuts."""
        lines = ["Py_DAW — Tastaturkürzel\n"]
        for cat, shortcuts in sorted(self.get_by_category().items()):
            lines.append(f"\n{cat}:")
            for s in shortcuts:
                lines.append(f"  {s.key:<20} {s.action}")
        return "\n".join(lines)

    def _register_defaults(self) -> None:
        """Register all built-in shortcuts."""
        # Transport
        for key, action in [
            ("Space", "Play / Stop"),
            ("R", "Aufnahme starten/stoppen"),
            ("L", "Loop ein/aus"),
            (".", "Stop + Zurück zum Anfang"),
            (",", "Zurückspulen"),
        ]:
            self.register(key, action, "Transport")

        # File
        for key, action in [
            ("Ctrl+N", "Neues Projekt"),
            ("Ctrl+O", "Projekt öffnen"),
            ("Ctrl+S", "Projekt speichern"),
            ("Ctrl+Shift+S", "Projekt speichern unter"),
            ("Ctrl+Z", "Rückgängig"),
            ("Ctrl+Shift+Z", "Wiederholen"),
        ]:
            self.register(key, action, "Datei")

        # Editing
        for key, action in [
            ("Ctrl+A", "Alles auswählen"),
            ("Ctrl+C", "Kopieren"),
            ("Ctrl+V", "Einfügen"),
            ("Ctrl+X", "Ausschneiden"),
            ("Ctrl+D", "Duplizieren"),
            ("Delete", "Auswahl löschen"),
            ("Ctrl+Q", "Quantisieren"),
        ]:
            self.register(key, action, "Bearbeiten")

        # Tools
        for key, action in [
            ("V", "Auswahl-Werkzeug"),
            ("P", "Stift-Werkzeug"),
            ("E", "Radierer-Werkzeug"),
            ("K", "Messer-Werkzeug"),
        ]:
            self.register(key, action, "Werkzeuge")

        # Navigation
        for key, action in [
            ("F11", "Vollbild / Live-Modus"),
            ("Escape", "Vollbild beenden"),
            ("Tab", "Nächstes Panel"),
            ("Shift+Tab", "Vorheriges Panel"),
            ("Ctrl+1", "Arranger anzeigen"),
            ("Ctrl+2", "Mixer anzeigen"),
            ("Ctrl+3", "Piano Roll anzeigen"),
        ]:
            self.register(key, action, "Navigation")

        # Zoom
        for key, action in [
            ("Ctrl++", "Hineinzoomen"),
            ("Ctrl+-", "Herauszoomen"),
            ("Ctrl+0", "Zoom zurücksetzen"),
            ("H", "Horizontal anpassen"),
        ]:
            self.register(key, action, "Zoom")


# ---------------------------------------------------------------------------
# Focus navigation
# ---------------------------------------------------------------------------

class FocusNavigator:
    """Manages keyboard focus order across DAW panels.

    Enables Tab/Shift+Tab navigation between major UI areas:
    Toolbar → Arranger → Editor → Browser → Mixer → back to Toolbar
    """

    def __init__(self):
        self._panels: List[QWidget] = []
        self._current_index: int = 0

    def register_panel(self, widget: QWidget, name: str = "") -> None:
        """Register a panel in the focus navigation order."""
        self._panels.append(widget)
        if name:
            set_accessible_name(widget, name)

    def focus_next(self) -> None:
        """Move focus to the next panel."""
        if not self._panels:
            return
        self._current_index = (self._current_index + 1) % len(self._panels)
        self._focus_current()

    def focus_prev(self) -> None:
        """Move focus to the previous panel."""
        if not self._panels:
            return
        self._current_index = (self._current_index - 1) % len(self._panels)
        self._focus_current()

    def focus_panel(self, index: int) -> None:
        """Focus a specific panel by index."""
        if 0 <= index < len(self._panels):
            self._current_index = index
            self._focus_current()

    def _focus_current(self) -> None:
        """Set focus to the current panel."""
        if 0 <= self._current_index < len(self._panels):
            widget = self._panels[self._current_index]
            try:
                widget.setFocus(Qt.FocusReason.TabFocusReason)
                widget.raise_()
            except Exception:
                pass


# ---------------------------------------------------------------------------
# Focus ring stylesheet
# ---------------------------------------------------------------------------

FOCUS_RING_CSS = """
/* Accessibility: visible focus indicators */
*:focus {
    outline: 2px solid #4fc3f7;
    outline-offset: 2px;
}

QPushButton:focus, QToolButton:focus {
    border: 2px solid #4fc3f7 !important;
}

QSlider:focus::groove:horizontal {
    border: 2px solid #4fc3f7;
}

QComboBox:focus, QSpinBox:focus, QLineEdit:focus {
    border: 2px solid #4fc3f7 !important;
}

QListWidget:focus, QTreeWidget:focus, QTableWidget:focus {
    border: 2px solid #4fc3f7 !important;
}

QTabBar::tab:focus {
    border-bottom: 3px solid #4fc3f7 !important;
}
"""

REDUCED_MOTION_CSS = """
/* Accessibility: disable all animations */
* {
    animation-duration: 0s !important;
    transition-duration: 0s !important;
}
"""

LARGE_TEXT_CSS = """
/* Accessibility: larger text */
* {
    font-size: 15px;
}
QLabel {
    font-size: 15px;
}
QPushButton, QToolButton {
    font-size: 14px;
    min-height: 28px;
}
QMenuBar {
    font-size: 14px;
}
QMenu {
    font-size: 14px;
}
"""


# ---------------------------------------------------------------------------
# Accessibility Service
# ---------------------------------------------------------------------------

class AccessibilityService(QObject):
    """Central accessibility service for Py_DAW.

    Usage:
        a11y = AccessibilityService(main_window)
        a11y.apply_config(config)  # apply user preferences
        a11y.label_transport(play_btn, stop_btn, rec_btn)
        a11y.announce("Aufnahme gestartet")
    """

    announcement = pyqtSignal(str)  # for UI display of announcements
    config_changed = pyqtSignal(object)

    def __init__(self, main_window: Optional[QWidget] = None, parent=None):
        super().__init__(parent)
        self._main_window = main_window
        self._config = AccessibilityConfig()
        self._shortcuts = ShortcutRegistry()
        self._focus_nav = FocusNavigator()
        self._settings = QSettings("ChronoScaleStudio", "PyDAW")
        self._extra_css: List[str] = []

    @property
    def config(self) -> AccessibilityConfig:
        return self._config

    @property
    def shortcuts(self) -> ShortcutRegistry:
        return self._shortcuts

    @property
    def focus_navigator(self) -> FocusNavigator:
        return self._focus_nav

    def apply_config(self, config: AccessibilityConfig) -> None:
        """Apply accessibility configuration."""
        self._config = config
        self._extra_css.clear()

        if config.focus_indicators:
            self._extra_css.append(FOCUS_RING_CSS)

        if config.reduced_motion:
            self._extra_css.append(REDUCED_MOTION_CSS)

        if config.large_text:
            self._extra_css.append(LARGE_TEXT_CSS)

        # Apply extra CSS
        app = QApplication.instance()
        if app and self._extra_css:
            current = app.styleSheet()
            extra = "\n".join(self._extra_css)
            # Append (don't replace) — theme manager handles base
            if "/* Accessibility:" not in current:
                app.setStyleSheet(current + "\n" + extra)

        # Tooltip delay
        try:
            if app:
                app.setStyleSheet(
                    app.styleSheet().replace(
                        "QToolTip {", f"QToolTip {{ /* delay: {config.tooltip_delay_ms}ms */ "
                    )
                )
        except Exception:
            pass

        self._save_config()

        try:
            self.config_changed.emit(config)
        except Exception:
            pass

        log.info("Accessibility config applied: focus=%s, motion=%s, text=%s",
                 config.focus_indicators, not config.reduced_motion,
                 "large" if config.large_text else "normal")

    def announce(self, text: str) -> None:
        """Announce a status change for screen readers.

        Also emits the announcement signal for visual display.
        """
        if not self._config.screen_reader_enabled:
            return

        try:
            self.announcement.emit(text)
        except Exception:
            pass

        # Qt Accessibility notification
        try:
            from PyQt6.QtGui import QAccessible
            if self._main_window:
                # Send accessible notification
                event = QAccessible.Event.NameChanged
                QAccessible.updateAccessibility(
                    QAccessible.queryAccessibleInterface(self._main_window),
                    0, event
                )
        except Exception:
            pass

        log.debug("A11y announce: %s", text)

    def announce_transport(self, state: str) -> None:
        """Announce transport state changes."""
        if self._config.announce_transport:
            messages = {
                "play": "Wiedergabe gestartet",
                "stop": "Wiedergabe gestoppt",
                "record": "Aufnahme gestartet",
                "record_stop": "Aufnahme gestoppt",
                "pause": "Pausiert",
            }
            self.announce(messages.get(state, state))

    def announce_selection(self, what: str, name: str) -> None:
        """Announce selection changes."""
        if self._config.announce_selection:
            self.announce(f"{what} ausgewählt: {name}")

    def announce_value(self, param: str, value: str) -> None:
        """Announce parameter value changes."""
        if self._config.announce_values:
            self.announce(f"{param}: {value}")

    def label_transport(
        self,
        play_btn: Optional[QWidget] = None,
        stop_btn: Optional[QWidget] = None,
        record_btn: Optional[QWidget] = None,
        bpm_spin: Optional[QWidget] = None,
        loop_btn: Optional[QWidget] = None,
    ) -> None:
        """Label transport controls for screen readers."""
        if play_btn:
            label_widget(play_btn, "Wiedergabe", "button",
                         "Wiedergabe starten oder stoppen. Taste: Leertaste")
        if stop_btn:
            label_widget(stop_btn, "Stop", "button",
                         "Wiedergabe stoppen und zum Anfang zurückkehren")
        if record_btn:
            label_widget(record_btn, "Aufnahme", "toggle",
                         "Aufnahme aktivieren. Taste: R")
        if bpm_spin:
            label_widget(bpm_spin, "Tempo BPM", "spinbox",
                         "Tempo in Schlägen pro Minute einstellen")
        if loop_btn:
            label_widget(loop_btn, "Loop", "toggle",
                         "Loop-Region wiederholen ein/aus. Taste: L")

    def register_panel(self, widget: QWidget, name: str) -> None:
        """Register a panel for Tab-navigation."""
        self._focus_nav.register_panel(widget, name)

    def setup_keyboard_shortcuts(self, window: QMainWindow) -> None:
        """Install Tab/Shift+Tab panel navigation shortcuts."""
        try:
            QShortcut(QKeySequence(Qt.Key.Key_F6), window,
                      self._focus_nav.focus_next)
            QShortcut(QKeySequence(Qt.Key.Key_F6 | Qt.KeyboardModifier.ShiftModifier),
                      window, self._focus_nav.focus_prev)
        except Exception:
            pass

    def _save_config(self) -> None:
        """Persist config to QSettings."""
        import json
        self._settings.setValue("accessibility",
                                json.dumps(self._config.to_dict()))

    def restore_config(self) -> AccessibilityConfig:
        """Restore config from QSettings."""
        try:
            import json
            raw = self._settings.value("accessibility", "")
            if raw:
                data = json.loads(str(raw))
                self._config = AccessibilityConfig.from_dict(data)
        except Exception:
            self._config = AccessibilityConfig()
        return self._config

    def get_shortcut_text(self) -> str:
        """Return formatted text of all shortcuts."""
        return self._shortcuts.to_text()

    def shutdown(self) -> None:
        """Cleanup."""
        pass
