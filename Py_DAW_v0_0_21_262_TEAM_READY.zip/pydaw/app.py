"""Application bootstrap."""

from __future__ import annotations

import os
import sys
import traceback
import faulthandler
import signal

from PyQt6.QtWidgets import QApplication

from .utils.logging_setup import setup_logging

from .core.settings import SettingsKeys
from .core.settings_store import get_value
from .services.container import ServiceContainer
from .ui.main_window import MainWindow
from .fileio import recovery


def run(argv: list[str] | None = None) -> int:
    """Start GUI application."""
    argv = argv if argv is not None else sys.argv

    # v0.0.21.021 A1.1: GIL-Tuning — switch every 2ms instead of default 5ms.
    # Reduces audio-thread GIL starvation from 720ms peak to <20ms.
    try:
        sys.setswitchinterval(0.002)
    except Exception:
        pass

    # Early logging (before Qt): keep terminal output + write logfile.
    # This is critical when the app restarts itself via exec (PipeWire-JACK / port changes).
    try:
        setup_logging(app_name="ChronoScaleStudio")
    except Exception:
        pass


    # AUTO_PW_JACK: Wenn Backend=JACK gewählt ist, aber kein JACK-Server erreichbar ist,
    # starten wir uns automatisch über pw-jack neu (PipeWire-JACK). Dadurch muss der User
    # nichts im Terminal tippen und QPWGraph sieht den Client sofort.
    try:
        from shutil import which
        from .services.jack_client_service import JackClientService

        keys = SettingsKeys()
        backend = str(get_value(keys.audio_backend, "sounddevice"))
        under_pw = os.environ.get("PYDAW_UNDER_PW_JACK") == "1" or os.environ.get("PW_JACK") == "1"
        pw = which("pw-jack")

        if backend == "jack" and (not under_pw) and pw and (not JackClientService.probe_available()):
            env = os.environ.copy()
            env["PYDAW_UNDER_PW_JACK"] = "1"
            env["PW_JACK"] = "1"
            # Projektpfad merken, damit nach Restart nicht ein leeres Projekt erscheint
            if env.get("PYDAW_REOPEN_PROJECT") is None:
                # wenn bereits ein Projekt geladen war, wird es von MainWindow beim Audio-Apply gesetzt
                pass
            os.execvpe(pw, [pw, sys.executable, *argv], env)
    except Exception:
        # Niemals blockieren – im Zweifel normal starten.
        pass

    # Crash/exception diagnostics: if Qt aborts (SIGABRT) we want a Python stack dump.
    try:
        faulthandler.enable(all_threads=True)
        for sig in (signal.SIGABRT, signal.SIGSEGV, signal.SIGFPE, signal.SIGILL):
            try:
                faulthandler.register(sig, all_threads=True, chain=True)
            except Exception:
                pass
    except Exception:
        pass

    class SafeApplication(QApplication):
        """QApplication that prevents Qt aborts on unhandled exceptions.

        PySide6/Qt may terminate the whole process with SIGABRT when an exception
        escapes a Qt event handler (e.g. during painting or slot execution).
        Catching here keeps the GUI alive and logs the traceback.
        """

        def notify(self, receiver, event):  # noqa: N802
            try:
                return super().notify(receiver, event)
            except Exception:
                try:
                    traceback.print_exc()
                except Exception:
                    pass
                return False

    app = SafeApplication(argv)

    # v0.0.20.746 P0D: Global crash reporter — unhandled Python exceptions
    # show a user-friendly dialog instead of silently dying.
    def _install_crash_reporter(qt_app: QApplication) -> None:
        """Install sys.excepthook that shows a QMessageBox on fatal errors."""
        import traceback as _tb

        def _excepthook(exc_type, exc_value, exc_tb):
            # Always log to stderr first (so terminal output is preserved)
            try:
                _tb.print_exception(exc_type, exc_value, exc_tb)
            except Exception:
                pass

            # Don't show dialog for KeyboardInterrupt
            if issubclass(exc_type, KeyboardInterrupt):
                sys.__excepthook__(exc_type, exc_value, exc_tb)
                return

            # Format a short summary for the dialog
            try:
                summary = "".join(_tb.format_exception(exc_type, exc_value, exc_tb))
            except Exception:
                summary = f"{exc_type.__name__}: {exc_value}"

            # Try to write a crash log next to the executable
            try:
                import datetime
                crash_log = Path(__file__).resolve().parent.parent / "crash.log"
                with open(crash_log, "a", encoding="utf-8") as f:
                    f.write(f"\n{'='*60}\n")
                    f.write(f"CRASH @ {datetime.datetime.now().isoformat()}\n")
                    f.write(summary)
            except Exception:
                pass

            # Show Qt dialog (only when event loop is running)
            try:
                from PyQt6.QtWidgets import QMessageBox
                box = QMessageBox()
                box.setWindowTitle("Py_DAW — Unbehandelter Fehler")
                box.setIcon(QMessageBox.Icon.Critical)
                box.setText(
                    "<b>Ein unbehandelter Fehler ist aufgetreten.</b><br>"
                    "Die Anwendung läuft weiter, aber bitte speichere dein Projekt jetzt.<br>"
                    f"<br><tt>{exc_type.__name__}: {exc_value}</tt>"
                )
                box.setDetailedText(summary[-4000:])  # cap at 4 kB
                box.setStandardButtons(QMessageBox.StandardButton.Ok)
                box.exec()
            except Exception:
                pass  # Dialog failed — traceback already printed to stderr

        sys.excepthook = _excepthook

    try:
        _install_crash_reporter(app)
    except Exception:
        pass

    # v0.0.20.185: Qt hardening (prevents SIGABRT on some Wayland/PyQt6 setups)
    # If a Python exception escapes a Qt virtual method (paintEvent/eventFilter/etc.),
    # SIP/PyQt can call qFatal("Unhandled Python exception") -> SIGABRT.
    # We defensively wrap our own UI classes so exceptions are swallowed + logged.
    try:
        from .ui.qt_hardening import harden_qt_virtuals, harden_signal_slots

        # v0.0.20.186: pyqtSlot safety. Prevents PyQt6 qFatal("Unhandled Python exception")
        # by wrapping Python slots connected via signal.connect.
        try:
            harden_signal_slots()
        except Exception:
            pass

        # v0.0.20.185: Virtual method hardening for pydaw.ui classes.
        harden_qt_virtuals()
    except Exception:
        pass

    # Apply persisted JACK/PipeWire-JACK preferences early (before services are created).
    #
    # IMPORTANT: This controls *port visibility / routing* in qpwgraph and is independent
    # from the engine backend (sounddevice vs jack). We must not force-switch backend.
    keys = SettingsKeys()
    jack_en = str(get_value(keys.jack_enable, "0"))
    jack_enabled = jack_en.lower() in ("1", "true", "yes", "on")

    # Enable/disable the JACK client according to user settings.
    os.environ["PYDAW_ENABLE_JACK"] = "1" if jack_enabled else "0"

    try:
        os.environ["PYDAW_JACK_IN"] = str(int(get_value(keys.jack_in_ports, 2)))
        os.environ["PYDAW_JACK_OUT"] = str(int(get_value(keys.jack_out_ports, 2)))
        os.environ["PYDAW_JACK_MONITOR"] = "1" if str(get_value(keys.jack_input_monitor, "0")).lower() in ("1","true","yes","on") else "0"
    except Exception:
        os.environ.setdefault("PYDAW_JACK_IN", "2")
        os.environ.setdefault("PYDAW_JACK_OUT", "2")
        os.environ.setdefault("PYDAW_JACK_MONITOR", "0")

    # v0.0.20.956: Splash Screen with loading progress
    splash = None
    try:
        from .ui.splash_screen import SplashScreen
        version = "?"
        try:
            vf = os.path.join(os.path.dirname(os.path.dirname(__file__)), "VERSION")
            if os.path.isfile(vf):
                version = open(vf).read().strip()
        except Exception:
            pass
        splash = SplashScreen(version=version)
        splash.show()
        splash.set_status("Dienste initialisieren...", "⚙")
        splash.set_progress(0.05)
    except Exception:
        splash = None

    # v0.0.20.956: Progress callback for splash screen
    def _splash_progress(msg, pct):
        if splash:
            splash.set_status(msg, "⚙")
            splash.set_progress(pct)

    services = ServiceContainer.create_default(progress_callback=_splash_progress)

    if splash:
        splash.set_status("644 Plugins geladen", "🔌")
        splash.set_progress(0.40)

    # v0.0.20.173: Crash-recovery session marker (Bitwig-style).
    # We mark the session as "unclean" at startup and flip to clean on normal close.
    try:
        keys = SettingsKeys()
        lastp = str(get_value(keys.last_project, "") or "")
        recovery.mark_startup(lastp)
    except Exception:
        try:
            recovery.mark_startup("")
        except Exception:
            pass

    if splash:
        splash.set_status("Hauptfenster aufbauen...", "🖥")
        splash.set_progress(0.60)

    window = MainWindow(services=services)

    if splash:
        splash.set_status("Audio-Engine starten...", "🔊")
        splash.set_progress(0.85)

    window.show()

    if splash:
        splash.set_status("Bereit!", "✅")
        splash.set_progress(1.0)
        splash.finish(window)

    # v0.0.20.755: Ctrl+C soll die App beenden (Qt blockiert SIGINT sonst).
    # SIG_DFL lässt Python den Standard-Handler (KeyboardInterrupt) wieder aktiv.
    # Der QTimer-Tick alle 200ms gibt Python den GIL zurück damit SIGINT ankommt.
    try:
        import signal as _sig
        _sig.signal(_sig.SIGINT, _sig.SIG_DFL)
        from PyQt6.QtCore import QTimer as _QT
        _ctrlc_timer = _QT()
        _ctrlc_timer.start(200)
        _ctrlc_timer.timeout.connect(lambda: None)
    except Exception:
        pass

    return app.exec()
