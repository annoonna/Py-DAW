#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Standalone CLAP native editor helper.

Only intended for problematic CLAP GUIs (currently Surge XT on Linux/X11).
The audio/DSP path stays in the main DAW process. This helper owns only a
second GUI-facing plugin instance and mirrors parameter/state changes over
JSON lines.
"""

from __future__ import annotations

import base64
import json
import logging
import os
import sys
from pathlib import Path
from typing import Dict, List, Optional

# Ensure project root is importable when executed via absolute helper path.
try:
    _ROOT = Path(__file__).resolve().parents[2]
    if str(_ROOT) not in sys.path:
        sys.path.insert(0, str(_ROOT))
except Exception:
    pass

from PyQt6.QtCore import QObject, QSocketNotifier, QTimer
from PyQt6.QtWidgets import QApplication

from pydaw.audio.clap_host import _ClapPlugin

log = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

_stdout_lock = None


def _emit(obj: dict) -> None:
    try:
        line = json.dumps(obj, ensure_ascii=False)
        sys.stdout.write(line + "\n")
        sys.stdout.flush()
    except Exception:
        pass


def _parse_args() -> tuple[str, str, str]:
    args = sys.argv[1:]
    positional: List[str] = []
    title = ""
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--title" and i + 1 < len(args):
            title = args[i + 1]
            i += 2
        else:
            positional.append(a)
            i += 1
    path = positional[0] if positional else ""
    plugin_id = positional[1] if len(positional) > 1 else ""
    try:
        if path and "::" in path:
            split_path, split_id = path.rsplit("::", 1)
            if split_path:
                path = split_path
            if split_id and not plugin_id:
                plugin_id = split_id
    except Exception:
        pass
    return path, plugin_id, title


class ClapGuiHelper(QObject):
    def __init__(self, plugin_path: str, plugin_id: str, title: str):
        super().__init__()
        self._plugin_path = str(plugin_path or "")
        self._plugin_id = str(plugin_id or "")
        self._title = str(title or "")
        self._plugin: Optional[_ClapPlugin] = None
        self._stdin_notifier: Optional[QSocketNotifier] = None
        self._stdin_buffer = ""
        self._fd_notifiers: dict = {}
        self._gui_timers: dict = {}
        self._prime_frames = 180
        self._last_params: Dict[str, float] = {}
        self._param_name_to_id: Dict[str, int] = {}
        self._poll_timer = QTimer(self)
        self._poll_timer.setInterval(80)
        self._poll_timer.timeout.connect(self._poll_params)
        self._pump_timer = QTimer(self)
        self._pump_timer.setInterval(16)
        self._pump_timer.timeout.connect(self._pump_gui)
        self._closed_emitted = False
        QTimer.singleShot(0, self._bootstrap)

    def _bootstrap(self) -> None:
        if not self._plugin_path or not self._plugin_id:
            _emit({"event": "error", "msg": "Missing CLAP path/plugin_id"})
            QApplication.instance().quit()
            return
        try:
            self._plugin = _ClapPlugin(self._plugin_path, self._plugin_id, sr=48000, block_size=256)
        except Exception as exc:
            _emit({"event": "error", "msg": f"CLAP load exception: {exc}"})
            QApplication.instance().quit()
            return
        if self._plugin is None or not self._plugin._ok:
            msg = getattr(self._plugin, "_err", "unknown") if self._plugin is not None else "unknown"
            _emit({"event": "error", "msg": f"CLAP load failed: {msg}"})
            QApplication.instance().quit()
            return
        if not self._plugin.has_gui():
            _emit({"event": "error", "msg": "Plugin has no CLAP GUI"})
            QApplication.instance().quit()
            return

        self._snapshot_param_infos()
        _emit({
            "event": "ready",
            "plugin": self._plugin_id,
            "params": [
                {"name": name, "value": value}
                for name, value in sorted(self._last_params.items())
            ],
        })

        try:
            ok, width, height, mode = self._plugin.show_detached_gui()
        except Exception as exc:
            ok, width, height, mode = False, 0, 0, ""
            _emit({"event": "error", "msg": f"show_detached_gui exception: {exc}"})
        if not ok:
            _emit({"event": "error", "msg": "Detached CLAP editor could not be opened"})
            QApplication.instance().quit()
            return

        _emit({"event": "gui_opened", "mode": mode, "width": int(width), "height": int(height)})
        self._setup_stdin_notifier()
        self._poll_timer.start()
        self._pump_timer.start()

    def _snapshot_param_infos(self) -> None:
        if self._plugin is None:
            return
        current: Dict[str, float] = {}
        try:
            count = int(self._plugin.get_param_count())
        except Exception:
            count = 0
        for index in range(max(0, count)):
            try:
                info = self._plugin.get_param_info(index)
            except Exception:
                info = None
            if info is None:
                continue
            name = str(getattr(info, "name", "") or "")
            param_id = int(getattr(info, "id", 0))
            if not name:
                continue
            self._param_name_to_id[name] = param_id
            try:
                value = self._plugin.get_param_value(param_id)
            except Exception:
                value = None
            if value is not None:
                current[name] = float(value)
        self._last_params = current

    def _setup_stdin_notifier(self) -> None:
        try:
            fd = sys.stdin.fileno()
        except Exception:
            return
        try:
            notifier = QSocketNotifier(fd, QSocketNotifier.Type.Read, self)
            notifier.activated.connect(self._on_stdin_ready)
            self._stdin_notifier = notifier
        except Exception:
            self._stdin_notifier = None

    def _on_stdin_ready(self, *_args) -> None:
        try:
            chunk = os.read(sys.stdin.fileno(), 65536).decode("utf-8", errors="replace")
        except Exception:
            return
        if not chunk:
            return
        self._stdin_buffer += chunk
        lines = self._stdin_buffer.split("\n")
        self._stdin_buffer = lines[-1]
        for raw in lines[:-1]:
            line = raw.strip()
            if not line:
                continue
            try:
                cmd = json.loads(line)
            except Exception:
                continue
            self._handle_command(cmd)

    def _handle_command(self, cmd: dict) -> None:
        action = str(cmd.get("cmd", "") or "")
        if action == "quit":
            self._emit_closed_once()
            QApplication.instance().quit()
            return
        if self._plugin is None:
            return
        if action == "set_state":
            blob = str(cmd.get("blob", "") or "")
            if blob:
                try:
                    data = base64.b64decode(blob)
                    ok = bool(self._plugin.set_state(data))
                    if ok:
                        try:
                            self._plugin.pump_main_thread(force=True, max_calls=8)
                        except Exception:
                            pass
                        self._snapshot_param_infos()
                except Exception as exc:
                    _emit({"event": "error", "msg": f"set_state failed: {exc}"})
            return
        if action == "set_param":
            name = str(cmd.get("name", "") or "")
            value = cmd.get("value")
            if not name or value is None:
                return
            param_id = self._param_name_to_id.get(name)
            if param_id is None:
                return
            try:
                ok = bool(self._plugin.set_param_value(int(param_id), float(value)))
                if ok:
                    self._last_params[name] = float(value)
            except Exception as exc:
                _emit({"event": "error", "msg": f"set_param failed: {exc}"})

    def _sync_async_sources(self) -> None:
        plugin = self._plugin
        if plugin is None:
            self._clear_async_sources()
            return
        try:
            fd_map = plugin.get_registered_gui_fds()
        except Exception:
            fd_map = {}
        try:
            timer_map = plugin.get_registered_gui_timers()
        except Exception:
            timer_map = {}

        desired_fd_keys = set()
        flag_specs = []
        try:
            flag_specs.append((1, QSocketNotifier.Type.Read))
        except Exception:
            pass
        try:
            flag_specs.append((2, QSocketNotifier.Type.Write))
        except Exception:
            pass
        try:
            flag_specs.append((4, QSocketNotifier.Type.Exception))
        except Exception:
            pass

        for fd, flags in list(fd_map.items()):
            try:
                fd_i = int(fd)
                flags_i = int(flags)
            except Exception:
                continue
            for bit, qt_type in flag_specs:
                key = (fd_i, bit)
                if flags_i & bit:
                    desired_fd_keys.add(key)
                    if key not in self._fd_notifiers:
                        try:
                            notifier = QSocketNotifier(fd_i, qt_type, self)
                            notifier.activated.connect(lambda _ignored=None, fd=fd_i, bit=bit: self._on_gui_fd_event(fd, bit))
                            self._fd_notifiers[key] = notifier
                        except Exception:
                            continue

        for key, notifier in list(self._fd_notifiers.items()):
            if key not in desired_fd_keys:
                try:
                    notifier.setEnabled(False)
                    notifier.deleteLater()
                except Exception:
                    pass
                self._fd_notifiers.pop(key, None)

        desired_timer_ids = {int(k): int(v) for k, v in list(timer_map.items())}
        for timer_id, period_ms in desired_timer_ids.items():
            timer = self._gui_timers.get(timer_id)
            if timer is None:
                try:
                    timer = QTimer(self)
                    timer.timeout.connect(lambda tid=timer_id: self._on_gui_timer(tid))
                    self._gui_timers[timer_id] = timer
                except Exception:
                    continue
            try:
                period = max(1, int(period_ms))
                if timer.interval() != period:
                    timer.setInterval(period)
                if not timer.isActive():
                    timer.start()
            except Exception:
                pass

        for timer_id, timer in list(self._gui_timers.items()):
            if timer_id not in desired_timer_ids:
                try:
                    timer.stop()
                    timer.deleteLater()
                except Exception:
                    pass
                self._gui_timers.pop(timer_id, None)

    def _clear_async_sources(self) -> None:
        for notifier in list(self._fd_notifiers.values()):
            try:
                notifier.setEnabled(False)
                notifier.deleteLater()
            except Exception:
                pass
        self._fd_notifiers = {}
        for timer in list(self._gui_timers.values()):
            try:
                timer.stop()
                timer.deleteLater()
            except Exception:
                pass
        self._gui_timers = {}

    def _on_gui_fd_event(self, fd: int, flags: int) -> None:
        if self._plugin is None:
            return
        try:
            self._plugin.dispatch_gui_fd(int(fd), int(flags))
        except Exception:
            pass
        try:
            self._plugin.pump_main_thread(force=True, max_calls=6)
        except Exception:
            pass
        self._sync_async_sources()

    def _on_gui_timer(self, timer_id: int) -> None:
        if self._plugin is None:
            return
        try:
            self._plugin.dispatch_gui_timer(int(timer_id))
        except Exception:
            pass
        try:
            self._plugin.pump_main_thread(force=True, max_calls=6)
        except Exception:
            pass
        self._sync_async_sources()

    def _pump_gui(self) -> None:
        plugin = self._plugin
        if plugin is None:
            return
        self._sync_async_sources()
        force = self._prime_frames > 0
        try:
            target = 16 if force else 120
            if self._pump_timer.interval() != target:
                self._pump_timer.setInterval(target)
            plugin.pump_main_thread(force=force, max_calls=4 if force else 2)
        except Exception:
            pass
        try:
            visible_req = plugin.take_requested_gui_visibility()
        except Exception:
            visible_req = None
        if visible_req is False:
            self._emit_closed_once()
            QApplication.instance().quit()
            return
        if self._prime_frames > 0:
            self._prime_frames -= 1

    def _poll_params(self) -> None:
        plugin = self._plugin
        if plugin is None:
            return
        for name, param_id in list(self._param_name_to_id.items()):
            try:
                value = plugin.get_param_value(param_id)
            except Exception:
                value = None
            if value is None:
                continue
            value_f = float(value)
            prev = self._last_params.get(name)
            if prev is None or abs(value_f - prev) > 1e-7:
                self._last_params[name] = value_f
                _emit({"event": "param", "name": name, "value": value_f})

    def _emit_closed_once(self) -> None:
        if self._closed_emitted:
            return
        self._closed_emitted = True
        _emit({"event": "closed"})

    def shutdown(self) -> None:
        self._poll_timer.stop()
        self._pump_timer.stop()
        self._clear_async_sources()
        if self._stdin_notifier is not None:
            try:
                self._stdin_notifier.setEnabled(False)
                self._stdin_notifier.deleteLater()
            except Exception:
                pass
            self._stdin_notifier = None
        plugin = self._plugin
        self._plugin = None
        if plugin is not None:
            try:
                plugin.destroy_gui()
            except Exception:
                pass
            try:
                plugin.close()
            except Exception:
                pass


def main() -> int:
    plugin_path, plugin_id, title = _parse_args()
    if not plugin_path:
        _emit({"event": "error", "msg": "Usage: clap_gui_process.py <path> <plugin_id> [--title T]"})
        return 1
    # v0.0.21.060: If no plugin_id given, try loading the first plugin in the bundle
    if not plugin_id:
        plugin_id = ""  # ClapPlugin.load() will use index 0
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)
    helper = ClapGuiHelper(plugin_path, plugin_id, title)
    try:
        rc = app.exec()
    finally:
        try:
            helper.shutdown()
        except Exception:
            pass
    return int(rc)


if __name__ == "__main__":
    sys.exit(main())
