"""video_automation.py — Video Clip Automation Engine (VE9).

Provides:
  - Per-clip automation lanes: Opacity, Speed, Volume
  - Breakpoint system with linear and Bezier interpolation
  - Preset curves: Fade In, Fade Out, S-Curve, Bell
  - Value evaluation at any beat position

v0.0.20.946  VE9 Automation Draw
"""

from __future__ import annotations

import copy
import logging
import math
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# Enums
# ═══════════════════════════════════════════════════════════════

class AutomationLane(Enum):
    """Automation lane types for video clips."""
    OPACITY = "opacity"
    SPEED = "speed"
    VOLUME = "volume"


class InterpolationMode(Enum):
    """Interpolation between breakpoints."""
    LINEAR = "linear"
    BEZIER = "bezier"
    HOLD = "hold"        # step — hold value until next point


# ═══════════════════════════════════════════════════════════════
# Breakpoint
# ═══════════════════════════════════════════════════════════════

@dataclass
class AutomationPoint:
    """Single automation breakpoint.

    position: relative beat position within the clip (0.0 = clip start)
    value: normalized 0.0–1.0 (mapped to lane range at render time)
    interpolation: how to reach the NEXT point
    bezier_cp1: control point 1 (relative offset) for bezier
    bezier_cp2: control point 2 (relative offset) for bezier
    """
    position: float = 0.0
    value: float = 1.0
    interpolation: InterpolationMode = InterpolationMode.LINEAR
    bezier_cp1: Tuple[float, float] = (0.0, 0.0)
    bezier_cp2: Tuple[float, float] = (0.0, 0.0)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "position": self.position,
            "value": self.value,
            "interpolation": self.interpolation.value,
            "bezier_cp1": list(self.bezier_cp1),
            "bezier_cp2": list(self.bezier_cp2),
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "AutomationPoint":
        return cls(
            position=float(d.get("position", 0.0)),
            value=float(d.get("value", 1.0)),
            interpolation=InterpolationMode(d.get("interpolation", "linear")),
            bezier_cp1=tuple(d.get("bezier_cp1", [0.0, 0.0])),
            bezier_cp2=tuple(d.get("bezier_cp2", [0.0, 0.0])),
        )


# ═══════════════════════════════════════════════════════════════
# Automation Curve (per lane per clip)
# ═══════════════════════════════════════════════════════════════

class AutomationCurve:
    """A single automation curve with ordered breakpoints.

    Points are kept sorted by position.
    """

    def __init__(self, lane: AutomationLane, default_value: float = 1.0):
        self.lane = lane
        self.default_value = default_value
        self.points: List[AutomationPoint] = []
        self.enabled: bool = True

    # ── Point Management ──

    def add_point(self, position: float, value: float,
                  interpolation: InterpolationMode = InterpolationMode.LINEAR) -> AutomationPoint:
        """Add or update a breakpoint at the given position."""
        value = max(0.0, min(1.0, value))
        position = max(0.0, position)

        # Check if point exists near this position (within 0.01 beats)
        for pt in self.points:
            if abs(pt.position - position) < 0.01:
                pt.value = value
                pt.interpolation = interpolation
                return pt

        pt = AutomationPoint(position=position, value=value,
                             interpolation=interpolation)
        self.points.append(pt)
        self.points.sort(key=lambda p: p.position)
        return pt

    def remove_point(self, index: int) -> None:
        """Remove breakpoint by index."""
        if 0 <= index < len(self.points):
            self.points.pop(index)

    def remove_point_at(self, position: float, tolerance: float = 0.1) -> bool:
        """Remove point nearest to position within tolerance."""
        best_idx = -1
        best_dist = tolerance
        for i, pt in enumerate(self.points):
            dist = abs(pt.position - position)
            if dist < best_dist:
                best_dist = dist
                best_idx = i
        if best_idx >= 0:
            self.points.pop(best_idx)
            return True
        return False

    def clear(self) -> None:
        """Remove all breakpoints."""
        self.points.clear()

    def move_point(self, index: int, new_position: float, new_value: float) -> None:
        """Move a breakpoint to a new position/value."""
        if 0 <= index < len(self.points):
            self.points[index].position = max(0.0, new_position)
            self.points[index].value = max(0.0, min(1.0, new_value))
            self.points.sort(key=lambda p: p.position)

    # ── Evaluation ──

    def evaluate(self, position: float) -> float:
        """Get the automation value at a given position.

        Interpolates between surrounding breakpoints.
        """
        if not self.enabled or not self.points:
            return self.default_value

        # Before first point → use first point value
        if position <= self.points[0].position:
            return self.points[0].value

        # After last point → use last point value
        if position >= self.points[-1].position:
            return self.points[-1].value

        # Find surrounding points
        for i in range(len(self.points) - 1):
            p1 = self.points[i]
            p2 = self.points[i + 1]
            if p1.position <= position <= p2.position:
                return self._interpolate(p1, p2, position)

        return self.default_value

    def _interpolate(self, p1: AutomationPoint, p2: AutomationPoint,
                     position: float) -> float:
        """Interpolate between two points."""
        span = p2.position - p1.position
        if span <= 0:
            return p1.value

        t = (position - p1.position) / span

        if p1.interpolation == InterpolationMode.HOLD:
            return p1.value

        elif p1.interpolation == InterpolationMode.BEZIER:
            return self._bezier_eval(p1, p2, t)

        else:
            # Linear
            return p1.value + (p2.value - p1.value) * t

    def _bezier_eval(self, p1: AutomationPoint, p2: AutomationPoint,
                     t: float) -> float:
        """Evaluate cubic Bezier between two points.

        Control points are relative offsets from the endpoints.
        """
        # Convert control points to absolute values
        span = p2.position - p1.position
        cy1 = p1.value + p1.bezier_cp1[1]
        cy2 = p2.value + p2.bezier_cp2[1]

        # Cubic bezier: B(t) = (1-t)³·P0 + 3(1-t)²t·P1 + 3(1-t)t²·P2 + t³·P3
        u = 1.0 - t
        return (u * u * u * p1.value +
                3.0 * u * u * t * cy1 +
                3.0 * u * t * t * cy2 +
                t * t * t * p2.value)

    def evaluate_array(self, start: float, end: float,
                       num_samples: int) -> List[float]:
        """Evaluate the curve at evenly-spaced positions.

        Useful for drawing the automation line in the UI.
        """
        if num_samples <= 0:
            return []
        if num_samples == 1:
            return [self.evaluate(start)]
        step = (end - start) / (num_samples - 1)
        return [self.evaluate(start + i * step) for i in range(num_samples)]

    # ── Serialization ──

    def to_dict(self) -> Dict[str, Any]:
        return {
            "lane": self.lane.value,
            "default_value": self.default_value,
            "enabled": self.enabled,
            "points": [p.to_dict() for p in self.points],
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "AutomationCurve":
        lane = AutomationLane(d.get("lane", "opacity"))
        curve = cls(lane=lane, default_value=d.get("default_value", 1.0))
        curve.enabled = d.get("enabled", True)
        curve.points = [AutomationPoint.from_dict(p) for p in d.get("points", [])]
        return curve


# ═══════════════════════════════════════════════════════════════
# Preset Factory
# ═══════════════════════════════════════════════════════════════

class AutomationPresets:
    """Factory for common automation curves."""

    @staticmethod
    def fade_in(duration: float = 4.0, lane: AutomationLane = AutomationLane.OPACITY) -> AutomationCurve:
        """Linear fade from 0 to 1 over duration beats."""
        curve = AutomationCurve(lane=lane, default_value=1.0)
        curve.add_point(0.0, 0.0, InterpolationMode.LINEAR)
        curve.add_point(duration, 1.0, InterpolationMode.LINEAR)
        return curve

    @staticmethod
    def fade_out(clip_length: float, duration: float = 4.0,
                 lane: AutomationLane = AutomationLane.OPACITY) -> AutomationCurve:
        """Linear fade from 1 to 0 ending at clip_length."""
        curve = AutomationCurve(lane=lane, default_value=1.0)
        curve.add_point(max(0, clip_length - duration), 1.0, InterpolationMode.LINEAR)
        curve.add_point(clip_length, 0.0, InterpolationMode.LINEAR)
        return curve

    @staticmethod
    def s_curve(duration: float = 4.0, lane: AutomationLane = AutomationLane.OPACITY) -> AutomationCurve:
        """S-shaped fade in using Bezier."""
        curve = AutomationCurve(lane=lane, default_value=1.0)
        p1 = curve.add_point(0.0, 0.0, InterpolationMode.BEZIER)
        p1.bezier_cp1 = (duration * 0.4, 0.0)
        p2 = curve.add_point(duration, 1.0, InterpolationMode.LINEAR)
        p2.bezier_cp2 = (-duration * 0.4, 0.0)
        return curve

    @staticmethod
    def bell(clip_length: float, peak_pos: float = 0.5,
             lane: AutomationLane = AutomationLane.OPACITY) -> AutomationCurve:
        """Bell/hump shape: 0 → 1 → 0 with peak at relative position."""
        curve = AutomationCurve(lane=lane, default_value=0.0)
        peak_beat = clip_length * peak_pos
        curve.add_point(0.0, 0.0, InterpolationMode.BEZIER)
        p_peak = curve.add_point(peak_beat, 1.0, InterpolationMode.BEZIER)
        p_peak.bezier_cp1 = (-peak_beat * 0.3, 0.0)
        p_peak.bezier_cp2 = ((clip_length - peak_beat) * 0.3, 0.0)
        curve.add_point(clip_length, 0.0, InterpolationMode.LINEAR)
        return curve

    @staticmethod
    def speed_ramp_slow_mo(clip_length: float,
                           slow_start: float = 0.25,
                           slow_end: float = 0.75,
                           slow_factor: float = 0.25) -> AutomationCurve:
        """Speed ramp: normal → slow-mo → normal."""
        curve = AutomationCurve(lane=AutomationLane.SPEED, default_value=1.0)
        s1 = clip_length * slow_start
        s2 = clip_length * slow_end
        ramp = clip_length * 0.05  # 5% ramp
        curve.add_point(0.0, 1.0, InterpolationMode.LINEAR)
        curve.add_point(max(0, s1 - ramp), 1.0, InterpolationMode.BEZIER)
        curve.add_point(s1, slow_factor, InterpolationMode.LINEAR)
        curve.add_point(s2, slow_factor, InterpolationMode.BEZIER)
        curve.add_point(min(clip_length, s2 + ramp), 1.0, InterpolationMode.LINEAR)
        curve.add_point(clip_length, 1.0, InterpolationMode.LINEAR)
        return curve

    @staticmethod
    def constant(value: float = 1.0,
                 lane: AutomationLane = AutomationLane.OPACITY) -> AutomationCurve:
        """Flat constant value."""
        curve = AutomationCurve(lane=lane, default_value=value)
        return curve


# ═══════════════════════════════════════════════════════════════
# Clip Automation Container
# ═══════════════════════════════════════════════════════════════

class ClipAutomation:
    """Container for all automation lanes of a single clip.

    Usage:
        auto = ClipAutomation(clip_id="clip_123")
        auto.opacity.add_point(0.0, 0.0)  # start transparent
        auto.opacity.add_point(4.0, 1.0)  # fade in over 4 beats
        val = auto.opacity.evaluate(2.0)   # → 0.5
    """

    def __init__(self, clip_id: str = ""):
        self.clip_id = clip_id
        self.opacity = AutomationCurve(AutomationLane.OPACITY, default_value=1.0)
        self.speed = AutomationCurve(AutomationLane.SPEED, default_value=1.0)
        self.volume = AutomationCurve(AutomationLane.VOLUME, default_value=1.0)

    def get_lane(self, lane: AutomationLane) -> AutomationCurve:
        """Get automation curve by lane enum."""
        if lane == AutomationLane.OPACITY:
            return self.opacity
        elif lane == AutomationLane.SPEED:
            return self.speed
        elif lane == AutomationLane.VOLUME:
            return self.volume
        raise ValueError(f"Unknown lane: {lane}")

    def has_automation(self) -> bool:
        """Check if any lane has breakpoints."""
        return bool(self.opacity.points or self.speed.points or self.volume.points)

    def apply_preset(self, preset_name: str, clip_length: float) -> None:
        """Apply a named preset to the opacity lane."""
        presets = {
            "fade_in": lambda: AutomationPresets.fade_in(min(4.0, clip_length / 2)),
            "fade_out": lambda: AutomationPresets.fade_out(clip_length,
                                                           min(4.0, clip_length / 2)),
            "s_curve": lambda: AutomationPresets.s_curve(min(4.0, clip_length / 2)),
            "bell": lambda: AutomationPresets.bell(clip_length),
        }
        factory = presets.get(preset_name)
        if factory:
            new_curve = factory()
            self.opacity.points = new_curve.points
            self.opacity.enabled = True

    def to_dict(self) -> Dict[str, Any]:
        return {
            "clip_id": self.clip_id,
            "opacity": self.opacity.to_dict(),
            "speed": self.speed.to_dict(),
            "volume": self.volume.to_dict(),
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ClipAutomation":
        auto = cls(clip_id=d.get("clip_id", ""))
        if "opacity" in d:
            auto.opacity = AutomationCurve.from_dict(d["opacity"])
        if "speed" in d:
            auto.speed = AutomationCurve.from_dict(d["speed"])
        if "volume" in d:
            auto.volume = AutomationCurve.from_dict(d["volume"])
        return auto


# ═══════════════════════════════════════════════════════════════
# Automation Store (project-wide)
# ═══════════════════════════════════════════════════════════════

class VideoAutomationStore:
    """Stores automation data for all video clips in a project.

    Usage:
        store = VideoAutomationStore()
        auto = store.get_or_create("clip_123")
        auto.opacity.add_point(0, 0)
        auto.opacity.add_point(4, 1)
    """

    def __init__(self):
        self._clips: Dict[str, ClipAutomation] = {}

    def get(self, clip_id: str) -> Optional[ClipAutomation]:
        return self._clips.get(clip_id)

    def get_or_create(self, clip_id: str) -> ClipAutomation:
        if clip_id not in self._clips:
            self._clips[clip_id] = ClipAutomation(clip_id=clip_id)
        return self._clips[clip_id]

    def remove(self, clip_id: str) -> None:
        self._clips.pop(clip_id, None)

    def to_dict(self) -> Dict[str, Any]:
        return {cid: auto.to_dict() for cid, auto in self._clips.items()}

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "VideoAutomationStore":
        store = cls()
        for cid, data in d.items():
            store._clips[cid] = ClipAutomation.from_dict(data)
        return store
