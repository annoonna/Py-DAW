"""
pydaw.flux.flux_main_widget
===========================

Das Hauptwidget für FLUX — kombiniert den Canvas, eine Modul-Palette
auf der linken Seite und ein Properties-Panel auf der rechten Seite
zu einem kompletten Editor.

Layout:

    ┌──────────────────────────────────────────────────────────────┐
    │ Toolbar:  [+ Demo] [Clear] [BPM Sync] [Pulse: ▶ ▮▮]         │
    ├──────────┬───────────────────────────────────┬──────────────┤
    │          │                                   │              │
    │ Palette  │           FluxCanvas              │ Properties  │
    │  ─────   │                                   │              │
    │ Bragi    │     ╔═══════╗                     │ Modul:       │
    │  SineOsc │     ║ Bragi ║───╮                 │  Bragi.SineOsc │
    │ Forseti  │     ╚═══════╝   │                 │              │
    │  Lowpass │                 ▼                 │ freq: [440]  │
    │ Heimdall │              ╔═════════╗          │ gain: [0.5]  │
    │  Master  │              ║ Forseti ║          │              │
    │  …       │              ╚═════════╝          │              │
    │          │                                   │              │
    └──────────┴───────────────────────────────────┴──────────────┘
                              [Status-Leiste: 3 Module · 3 Cables]

Im DAW:  als neuer Tab im MainWindow (zwischen "Editor" und "Mixer").
"""

from __future__ import annotations

import logging
from typing import Optional

try:
    from PyQt6.QtCore import Qt, QPointF, pyqtSignal
    from PyQt6.QtGui import QFont, QColor, QPalette
    from PyQt6.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QSplitter, QFrame,
        QLabel, QPushButton, QToolBar, QStatusBar,
        QListWidget, QListWidgetItem, QFormLayout, QDoubleSpinBox,
        QGroupBox, QSizePolicy, QToolButton, QStyle, QLineEdit,
        QFileDialog,  # v0.0.21.244: Sampler-Loading via Properties-Panel
    )
    _QT_AVAILABLE = True
except ImportError:
    _QT_AVAILABLE = False

from pydaw.flux.patch_model import Patch, Module, Port, PortDirection
from pydaw.flux.module_library import (
    MODULE_REGISTRY, list_available_modules, make_module, make_demo_patch,
)
from pydaw.flux.yggdrasil import GODS, get_god, FluxCategory

# v0.0.21.194 — U-1 Animated Knob (PD-Style). Optional-Import: wenn die
# Knob-Datei aus irgendeinem Grund fehlt oder Qt nicht da ist, fallen wir
# anmutig auf SpinBox-only zurück (alte v.193-Optik).
try:
    from pydaw.flux.ui_widgets import AnimatedKnob  # type: ignore
except Exception as _knob_import_err:  # pragma: no cover - defensive
    AnimatedKnob = None  # type: ignore[assignment]
    logging.getLogger(__name__).debug(
        "[FLUX-UI] AnimatedKnob import failed (%s) — fallback to SpinBox-only",
        _knob_import_err,
    )


logger = logging.getLogger(__name__)


if _QT_AVAILABLE:
    from pydaw.flux.flux_canvas import FluxScene, FluxView


    class ModulePaletteWidget(QWidget):
        """Linkes Panel: Liste aller verfügbaren Module, gruppiert nach Gott.

        Doppelklick auf einen Eintrag → Modul wird in der Mitte des
        sichtbaren Canvas-Bereichs erzeugt.
        """

        module_requested = pyqtSignal(str, str)   # (god, kind)

        def __init__(self, parent=None):
            super().__init__(parent)
            self.setMinimumWidth(180)
            self.setMaximumWidth(260)
            layout = QVBoxLayout(self)
            layout.setContentsMargins(4, 4, 4, 4)
            layout.setSpacing(4)

            header = QLabel("⚛ MODULE")
            header.setStyleSheet(
                "color: #3df0e0; font-family: monospace; font-weight: bold;"
                "font-size: 11px; padding: 4px 6px;"
            )
            layout.addWidget(header)

            # v0.0.21.214 — Such-Feld (Anno: „mach auch ein suchfeld wo ich
            # nach namen suchen kann"). Filtert die Module-Liste live nach
            # case-insensitive Substring im god.kind oder doc-string.
            self.search_field = QLineEdit()
            self.search_field.setPlaceholderText("🔍 Suche (god/kind/doc) …")
            self.search_field.setClearButtonEnabled(True)
            self.search_field.setStyleSheet("""
                QLineEdit {
                    background: #0a0e14;
                    color: #e6edf3;
                    border: 1px solid #161b22;
                    font-family: monospace;
                    font-size: 11px;
                    padding: 4px 6px;
                }
                QLineEdit:focus {
                    border: 1px solid #3df0e0;
                }
            """)
            self.search_field.textChanged.connect(self._on_search_changed)
            layout.addWidget(self.search_field)

            self.list_widget = QListWidget()
            self.list_widget.setStyleSheet("""
                QListWidget {
                    background: #0a0e14;
                    color: #e6edf3;
                    border: 1px solid #161b22;
                    font-family: monospace;
                    font-size: 11px;
                    outline: none;
                }
                QListWidget::item {
                    padding: 4px 6px;
                    border-bottom: 1px solid #161b22;
                }
                QListWidget::item:selected {
                    background: #1f2937;
                }
                QListWidget::item:hover {
                    background: #161b22;
                }
            """)
            self.list_widget.itemDoubleClicked.connect(self._on_double_click)
            layout.addWidget(self.list_widget, 1)

            self._populate()

        def _populate(self) -> None:
            """Modul-Liste aus MODULE_REGISTRY aufbauen — gruppiert per Gott."""
            # Gruppieren: { god: [ (kind, doc), ... ] }
            from collections import defaultdict
            by_god: dict[str, list[tuple[str, str]]] = defaultdict(list)
            for god, kind, doc in list_available_modules():
                by_god[god].append((kind, doc))

            for god in sorted(by_god):
                desc = get_god(god)
                color = desc.color.value if desc else "#888"
                glyph = desc.glyph if desc else "?"
                # Header-Eintrag (nicht-anklickbar)
                head = QListWidgetItem(f"  {glyph}  {god}")
                head.setFlags(Qt.ItemFlag.NoItemFlags)
                f = head.font(); f.setBold(True); f.setPointSize(10)
                head.setFont(f)
                head.setForeground(QColor(color))
                self.list_widget.addItem(head)
                # Module-Einträge
                for kind, doc in sorted(by_god[god]):
                    item = QListWidgetItem(f"      {kind}")
                    item.setData(Qt.ItemDataRole.UserRole, (god, kind))
                    item.setToolTip(doc)
                    self.list_widget.addItem(item)

        def _on_double_click(self, item: QListWidgetItem) -> None:
            data = item.data(Qt.ItemDataRole.UserRole)
            if isinstance(data, tuple) and len(data) == 2:
                god, kind = data
                self.module_requested.emit(god, kind)

        def _on_search_changed(self, text: str) -> None:
            """v0.0.21.214 — Live-Filter für die Module-Liste.

            Verhalten:
            * Leere Suche → alle Items sichtbar (inklusive Gott-Header).
            * Suchtext → case-insensitive Substring-Match auf:
              - kind-Name (z.B. „SineOsc")
              - god-Name (z.B. „Bragi")
              - doc-String aus dem Tooltip (Modul-Beschreibung)
              Gott-Header werden nur angezeigt wenn mindestens ein
              Untereintrag dieses Gottes matcht — sauber gruppiert.
            """
            query = (text or "").strip().lower()
            if not query:
                # Alle wieder sichtbar
                for i in range(self.list_widget.count()):
                    self.list_widget.item(i).setHidden(False)
                return

            # Erste Pass: pro god, prüfe ob mindestens ein Item matcht.
            # Header werden via setFlags(NoItemFlags) gemarkt — die
            # haben keinen UserRole-Tuple; wir tracken sie über ihre
            # Position.
            current_god_header_idx: int = -1
            current_god_has_match = False
            header_indices_with_match: set[int] = set()

            n = self.list_widget.count()
            for i in range(n):
                item = self.list_widget.item(i)
                data = item.data(Qt.ItemDataRole.UserRole)
                if not isinstance(data, tuple):
                    # Header-Item — Block-Wechsel
                    if current_god_header_idx >= 0 and current_god_has_match:
                        header_indices_with_match.add(current_god_header_idx)
                    current_god_header_idx = i
                    current_god_has_match = False
                else:
                    god, kind = data
                    text_label = item.text()
                    tooltip = item.toolTip() or ""
                    haystack = (
                        f"{god} {kind} {text_label} {tooltip}".lower()
                    )
                    if query in haystack:
                        current_god_has_match = True

            # Letzten Block flushen
            if current_god_header_idx >= 0 and current_god_has_match:
                header_indices_with_match.add(current_god_header_idx)

            # Zweite Pass: Sichtbarkeit setzen.
            current_god_header_idx = -1
            for i in range(n):
                item = self.list_widget.item(i)
                data = item.data(Qt.ItemDataRole.UserRole)
                if not isinstance(data, tuple):
                    current_god_header_idx = i
                    item.setHidden(i not in header_indices_with_match)
                else:
                    god, kind = data
                    text_label = item.text()
                    tooltip = item.toolTip() or ""
                    haystack = (
                        f"{god} {kind} {text_label} {tooltip}".lower()
                    )
                    item.setHidden(query not in haystack)


    class PropertiesPanelWidget(QWidget):
        """Rechtes Panel: zeigt Parameter des aktuell selektierten Moduls.

        v0.0.21.194 (U-1) — Pro Param wird jetzt ein **AnimatedKnob**
        (PD-Style, Lerp-Animation) NEBEN einer kompakten SpinBox
        eingeblendet:

        * Knob = visuelles + drag-bedienbares Hauptelement
        * SpinBox = numerische Feinjustage / präzise Werteingabe

        Beide sind synchron — ändert man den einen, folgt der andere
        ohne `param_changed` doppelt zu feuern. Die nach außen
        sichtbare Signal-Architektur (``param_changed(module_id,
        param, value)``) ist unverändert; das ist der gleiche D-1-Pfad
        den die Engine seit v.184 (F-1.1.5) erwartet.

        Falls die Knob-Klasse nicht verfügbar ist (Import-Fehler oder
        Qt-Stub), fallen wir transparent auf die alte SpinBox-only-
        Optik zurück.
        """

        param_changed = pyqtSignal(str, str, float)   # (module_id, param, value)
        # v0.0.21.244: String-Param-Signal für file_path (Sampler) und Expr-Strings
        param_str_changed = pyqtSignal(str, str, str)  # (module_id, param, str_value)
        # v0.0.21.230 — Living Patterns Signale (FluxMainWidget vermittelt
        # diese an die FluxScene weiter, da das Properties-Panel selber
        # keinen Scene-Zugriff hat). Argument: module.id.
        lp_frozen_toggle_requested  = pyqtSignal(str, bool)   # (mod_id, frozen)
        lp_snapshot_requested       = pyqtSignal(str)
        lp_clear_requested          = pyqtSignal(str)
        # v0.0.21.231 — Living Patterns Undo/Redo (kein mod_id — Stack
        # ist scene-global)
        lp_undo_requested           = pyqtSignal()
        lp_redo_requested           = pyqtSignal()

        def __init__(self, parent=None):
            super().__init__(parent)
            self.setMinimumWidth(220)
            self.setMaximumWidth(340)
            self._current_module: Optional[Module] = None
            self._spinboxes: dict[str, QDoubleSpinBox] = {}
            # v.194 — AnimatedKnobs analog zu _spinboxes (None wenn Fallback)
            self._knobs: dict[str, "AnimatedKnob"] = {}  # type: ignore[name-defined]
            # Re-Entry-Schutz beim Sync zwischen Knob ↔ SpinBox
            self._syncing_param: Optional[str] = None

            self._layout = QVBoxLayout(self)
            self._layout.setContentsMargins(4, 4, 4, 4)
            self._layout.setSpacing(6)

            header = QLabel("⚙ PROPERTIES")
            header.setStyleSheet(
                "color: #3df0e0; font-family: monospace; font-weight: bold;"
                "font-size: 11px; padding: 4px 6px;"
            )
            self._layout.addWidget(header)

            self._info_label = QLabel("Kein Modul ausgewählt")
            self._info_label.setStyleSheet(
                "color: #8b949e; font-family: monospace; font-size: 10px;"
                "padding: 8px; font-style: italic;"
            )
            self._info_label.setWordWrap(True)
            self._layout.addWidget(self._info_label)

            self._param_group = QGroupBox("Parameter")
            self._param_group.setStyleSheet("""
                QGroupBox {
                    color: #e6edf3; font-family: monospace; font-size: 10px;
                    border: 1px solid #161b22; border-radius: 4px;
                    margin-top: 8px; padding-top: 8px;
                }
                QGroupBox::title {
                    subcontrol-origin: margin; left: 8px; padding: 0 4px;
                }
            """)
            self._param_form = QFormLayout(self._param_group)
            self._param_form.setContentsMargins(8, 8, 8, 8)
            self._param_form.setSpacing(6)
            self._layout.addWidget(self._param_group)
            self._param_group.hide()

            # v0.0.21.230 — Living Patterns Section.
            # Sichtbar nur wenn das selektierte Modul ``dynamic_outputs=True``
            # hat (Vör.Route/RouteV/Select/SelectV). Bietet:
            #   * ❄ Frozen-Toggle (stoppt Live-Tag-Tracking)
            #   * 📸 Snapshot (alle observed → frozen_tags + neue Ports)
            #   * 🗑 Clear (alle Patterns demoten + Connections cleanup)
            self._lp_group = QGroupBox("Living Patterns")
            self._lp_group.setStyleSheet("""
                QGroupBox {
                    color: #a78bfa; font-family: monospace; font-size: 10px;
                    border: 1px solid #2a1f3f; border-radius: 4px;
                    margin-top: 8px; padding-top: 8px;
                }
                QGroupBox::title {
                    subcontrol-origin: margin; left: 8px; padding: 0 4px;
                }
            """)
            lp_lay = QVBoxLayout(self._lp_group)
            lp_lay.setContentsMargins(8, 8, 8, 8)
            lp_lay.setSpacing(4)
            self._lp_status = QLabel("—")
            self._lp_status.setStyleSheet(
                "color: #c4b5fd; font-family: monospace; font-size: 9px;"
                "padding: 2px 0;"
            )
            self._lp_status.setWordWrap(True)
            lp_lay.addWidget(self._lp_status)

            btn_row = QHBoxLayout()
            btn_row.setSpacing(4)
            self._lp_btn_frozen = QPushButton("❄ Freeze")
            self._lp_btn_frozen.setCheckable(True)
            self._lp_btn_frozen.setStyleSheet(
                "QPushButton { background:#0a0e14; color:#a78bfa;"
                "border:1px solid #2a1f3f; padding:3px 6px;"
                "font-family: monospace; font-size: 10px; }"
                "QPushButton:checked { background:#a78bfa; color:#0a0814;"
                "border:1px solid #c4b5fd; }"
                "QPushButton:hover { border-color:#a78bfa; }"
            )
            self._lp_btn_frozen.toggled.connect(self._on_lp_frozen_toggled)
            btn_row.addWidget(self._lp_btn_frozen)

            self._lp_btn_snapshot = QPushButton("📸 Snap")
            self._lp_btn_snapshot.setStyleSheet(
                "QPushButton { background:#0a0e14; color:#a78bfa;"
                "border:1px solid #2a1f3f; padding:3px 6px;"
                "font-family: monospace; font-size: 10px; }"
                "QPushButton:hover { background:#1f1530; border-color:#a78bfa; }"
            )
            self._lp_btn_snapshot.clicked.connect(self._on_lp_snapshot_clicked)
            btn_row.addWidget(self._lp_btn_snapshot)

            self._lp_btn_clear = QPushButton("🗑")
            self._lp_btn_clear.setMaximumWidth(34)
            self._lp_btn_clear.setStyleSheet(
                "QPushButton { background:#0a0e14; color:#ef4444;"
                "border:1px solid #3a1f1f; padding:3px 6px;"
                "font-family: monospace; font-size: 10px; }"
                "QPushButton:hover { background:#3a1f1f; border-color:#ef4444; }"
            )
            self._lp_btn_clear.setToolTip("Demote alle Patterns")
            self._lp_btn_clear.clicked.connect(self._on_lp_clear_clicked)
            btn_row.addWidget(self._lp_btn_clear)

            lp_lay.addLayout(btn_row)

            # v0.0.21.231 — Undo/Redo Buttons für Promote/Demote
            undo_row = QHBoxLayout()
            undo_row.setSpacing(4)
            self._lp_btn_undo = QPushButton("↶ Undo")
            self._lp_btn_undo.setStyleSheet(
                "QPushButton { background:#0a0e14; color:#8b949e;"
                "border:1px solid #2a1f3f; padding:3px 6px;"
                "font-family: monospace; font-size: 10px; }"
                "QPushButton:hover:!disabled { background:#1f1530; "
                "border-color:#a78bfa; color:#a78bfa; }"
                "QPushButton:disabled { color:#3a3050; border-color:#1a1424; }"
            )
            self._lp_btn_undo.setToolTip("Undo letzte Promote/Demote-Aktion")
            self._lp_btn_undo.clicked.connect(self._on_lp_undo_clicked)
            undo_row.addWidget(self._lp_btn_undo)
            self._lp_btn_redo = QPushButton("↷ Redo")
            self._lp_btn_redo.setStyleSheet(self._lp_btn_undo.styleSheet())
            self._lp_btn_redo.setToolTip("Redo")
            self._lp_btn_redo.clicked.connect(self._on_lp_redo_clicked)
            undo_row.addWidget(self._lp_btn_redo)
            lp_lay.addLayout(undo_row)
            # ─── v0.0.21.238 — Living Patterns Histogramm ─────────
            # Anno's Roadmap-Wunsch (v.232+): „Property-Panel
            # Living-Patterns-Stats-Histogramm (Wie oft kam jeder
            # observed Tag)". Zeigt Top-5 observierte Tags mit Bar-
            # Visualisierung in monospace, Counter-Wert rechts.
            self._lp_histo_label = QLabel("Tag-Histogramm")
            self._lp_histo_label.setStyleSheet(
                "color: #a78bfa; font-family: monospace; font-size: 9px;"
                "padding: 4px 0 2px 0; font-weight: bold;"
            )
            lp_lay.addWidget(self._lp_histo_label)
            self._lp_histogram = QLabel("—")
            self._lp_histogram.setStyleSheet(
                "color: #c4b5fd; font-family: 'Courier New', monospace;"
                "font-size: 9px; padding: 2px 4px; "
                "background: #0a0814; border: 1px solid #1a1424; "
                "border-radius: 3px;"
            )
            self._lp_histogram.setWordWrap(False)
            self._lp_histogram.setTextFormat(Qt.TextFormat.PlainText)
            lp_lay.addWidget(self._lp_histogram)
            self._lp_hint = QLabel(
                "Klick auf einen Tag-Chip am Modul: Observed → Promote, "
                "Promoted → Demote."
            )
            self._lp_hint.setStyleSheet(
                "color: #6b5e8a; font-family: monospace; font-size: 8px;"
                "padding: 2px 0; font-style: italic;"
            )
            self._lp_hint.setWordWrap(True)
            lp_lay.addWidget(self._lp_hint)

            self._layout.addWidget(self._lp_group)
            self._lp_group.hide()

            self._layout.addStretch(1)

        # ─── Helper: Port-Range für einen Param holen ────────────

        @staticmethod
        def _port_for_param(module: Module, param_name: str) -> Optional[Port]:
            """Sucht einen Input-Port mit gleichem Namen wie der Param.

            FLUX-Konvention (siehe module_library.py): Modul-Params
            haben die gleichen Namen wie ihre CV-Input-Ports. Damit
            kennt der Knob die korrekte Range/Default/Unit ohne
            Sonder-Konfiguration.
            """
            for p in module.inputs:
                if p.name == param_name:
                    return p
            return None

        def show_module(self, module: Optional[Module]) -> None:
            """Aktualisiere das Panel auf das gegebene Modul."""
            self._current_module = module
            # Param-Form leeren — sowohl SpinBoxen als auch Knobs werden
            # mit removeRow zerstört (deleteLater im Hintergrund)
            while self._param_form.rowCount() > 0:
                self._param_form.removeRow(0)
            self._spinboxes.clear()
            self._knobs.clear()

            if module is None:
                self._info_label.setText("Kein Modul ausgewählt")
                self._info_label.show()
                self._param_group.hide()
                self._lp_group.hide()
                return

            desc = get_god(module.god)
            glyph = desc.glyph if desc else "?"
            color = desc.color.value if desc else "#888"
            html = (f"<span style='color:{color}; font-weight:bold;'>{glyph} "
                    f"{module.god}.{module.kind}</span>"
                    f"<br><span style='color:#8b949e; font-size:9px;'>"
                    f"id: {module.id}</span>")
            self._info_label.setText(html)
            self._info_label.show()

            if module.params:
                self._param_group.show()
                for name, value in module.params.items():
                    if isinstance(value, str):
                        # v0.0.21.244: String-Params bekommen ein QLineEdit;
                        # bei `file_path`-Params zusätzlich einen 📂 Browse-
                        # Button. Anno-Direktive: „kuck mal sampler wie und
                        # wo soll ich ein sample rein laden". Vorher wurden
                        # alle String-Params übersprungen → kein Lade-UI
                        # für Sampler.file_path.
                        self._add_string_param_row(module, name, value)
                        continue
                    if isinstance(value, bool):
                        # bool zählt isinstance(int) — separat behandeln
                        self._add_param_row(module, name, float(value))
                        continue
                    if isinstance(value, (int, float)):
                        self._add_param_row(module, name, float(value))
            else:
                self._param_group.hide()

            # v0.0.21.230 — Living Patterns Section ein/ausblenden
            self._update_lp_section(module)

        def _update_lp_section(self, module: Module) -> None:
            """Living-Patterns-Section auf das aktuelle Modul abstimmen.

            Sichtbar nur wenn ``module.dynamic_outputs == True``. Status-
            Text zeigt die aktuellen Counts (Promoted / Observed) und
            den Frozen-Zustand.
            """
            if not getattr(module, "dynamic_outputs", False):
                self._lp_group.hide()
                return
            self._lp_group.show()

            promoted = list(module.frozen_tags.get("rune_in", []))
            observed = list(module.observed_tags.get("rune_in", []))
            promoted_set = {repr(p) for p in promoted}
            observed_unique = [v for v in observed if repr(v) not in promoted_set]

            status = (
                f"Patterns: {len(promoted)}  ·  "
                f"Observed: {len(observed_unique)}"
            )
            if module.frozen:
                status = "❄ FROZEN  ·  " + status
            self._lp_status.setText(status)

            # Toggle-State synchronisieren OHNE Signal zu feuern
            self._lp_btn_frozen.blockSignals(True)
            try:
                self._lp_btn_frozen.setChecked(bool(module.frozen))
                self._lp_btn_frozen.setText(
                    "❄ Frozen" if module.frozen else "❄ Freeze"
                )
            finally:
                self._lp_btn_frozen.blockSignals(False)

            self._lp_btn_snapshot.setEnabled(len(observed_unique) > 0)
            self._lp_btn_clear.setEnabled(len(promoted) > 0)

            # ─── v0.0.21.238 — Histogramm-Render ────────────────────
            # Top-5 observed Tags mit Counts. observed_counts ist
            # repr(tag) → count. Wir matchen wieder zu observed_tags
            # damit wir den menschen-lesbaren Tag-Wert zeigen.
            self._update_lp_histogram(module)

            # v.231 — Undo/Redo enabled-state. Wir lookuppen die Scene
            # über das parent-FluxMainWidget; defensiv falls noch nicht
            # angehängt.
            can_undo = False
            can_redo = False
            try:
                parent = self.parent()
                while parent is not None:
                    if hasattr(parent, "scene"):
                        scene = parent.scene
                        if hasattr(scene, "lp_can_undo"):
                            can_undo = scene.lp_can_undo()
                        if hasattr(scene, "lp_can_redo"):
                            can_redo = scene.lp_can_redo()
                        break
                    parent = parent.parent() if hasattr(parent, "parent") else None
            except Exception:
                pass
            self._lp_btn_undo.setEnabled(can_undo)
            self._lp_btn_redo.setEnabled(can_redo)

        def refresh_lp_status(self) -> None:
            """Wird vom FluxMainWidget aufgerufen wenn die LP-Section
            aktualisiert werden soll, ohne show_module() neu zu rufen
            (z.B. nach Promote/Demote im Canvas, damit Counts stimmen).
            """
            if self._current_module is None:
                return
            self._update_lp_section(self._current_module)

        def _update_lp_histogram(self, module: Module) -> None:
            """v0.0.21.238 — Top-5 Histogramm der observed Tags.

            Format (monospace):
                ─ Tag-Histogramm ─
                42 ████████████  1.5
                28 ████████      bang
                15 ████          0.0
                 7 ██            note_on
                 3 █             /lfo

            Bar-Length skaliert auf den höchsten Counter (8 Zeichen
            max). observed_counts kommt vom Renderer; bei frozen=True
            wird kein neuer Counter hinzugefügt aber alte stehen weiter.
            Bei leeren Counts → "(noch keine Daten)".
            """
            counts_map = getattr(module, "observed_counts", None) or {}
            port_counts = counts_map.get("rune_in", {}) or {}
            if not port_counts:
                self._lp_histogram.setText("(noch keine Daten)")
                return
            # Sort by count desc, take top 5
            top = sorted(port_counts.items(), key=lambda kv: -kv[1])[:5]
            if not top:
                self._lp_histogram.setText("(noch keine Daten)")
                return
            max_count = max(c for _, c in top) or 1
            bar_max = 12  # Zeichen
            lines = []
            # Spaltenbreiten: Count rechtsbündig 4 Stellen, dann Bar
            # 12 Zeichen, dann tag-repr (gekürzt 14 Zeichen)
            for tag_repr, count in top:
                bar_len = max(1, int((count / max_count) * bar_max))
                bar = "█" * bar_len + " " * (bar_max - bar_len)
                # tag_repr ist repr(value); für Anzeige strippen wir
                # umschließende quotes wenn es ein str-tag ist
                disp = tag_repr
                if disp.startswith("'") and disp.endswith("'"):
                    disp = disp[1:-1]
                if len(disp) > 14:
                    disp = disp[:13] + "…"
                lines.append(f"{count:>4}  {bar}  {disp}")
            self._lp_histogram.setText("\n".join(lines))

        def _on_lp_frozen_toggled(self, checked: bool) -> None:
            if self._current_module is None:
                return
            self.lp_frozen_toggle_requested.emit(
                self._current_module.id, bool(checked),
            )

        def _on_lp_snapshot_clicked(self) -> None:
            if self._current_module is None:
                return
            self.lp_snapshot_requested.emit(self._current_module.id)

        def _on_lp_clear_clicked(self) -> None:
            if self._current_module is None:
                return
            self.lp_clear_requested.emit(self._current_module.id)

        def _on_lp_undo_clicked(self) -> None:
            self.lp_undo_requested.emit()

        def _on_lp_redo_clicked(self) -> None:
            self.lp_redo_requested.emit()

        def _add_string_param_row(
            self, module: Module, name: str, value: str,
        ) -> None:
            """v0.0.21.244: String-Param-Zeile mit QLineEdit + ggf. Browse-Button.

            Anno-Direktive: „kuck mal sampler wie und wo soll ich ein sample
            rein laden". Vorher wurden alle String-Params übersprungen →
            der Sampler hatte gar keine UI für `file_path`.

            Verhalten:
            - Param-Name endet auf `_path` oder ist exakt `file_path` →
              QLineEdit + 📂 Browse-Button (öffnet QFileDialog)
            - Andere Strings (Ullr.Expr.expr, Hermod.Osc*-Strings) →
              QLineEdit ohne Button

            Bei Änderung: emit `param_str_changed(module_id, param, value)`.
            FluxScene/FluxMainWidget verkabeln das so dass `module.params[name]`
            gesetzt wird (analog zum numerischen `param_changed`-Pfad).
            """
            row = QWidget()
            row_layout = QHBoxLayout(row)
            row_layout.setContentsMargins(0, 0, 0, 0)
            row_layout.setSpacing(4)

            # QLineEdit für aktuellen Wert
            line_edit = QLineEdit(value)
            line_edit.setStyleSheet(
                "QLineEdit { color: #e6edf3; background: #0d1117; "
                "border: 1px solid #161b22; border-radius: 3px; "
                "padding: 3px 6px; font-family: monospace; font-size: 10px; } "
                "QLineEdit:focus { border-color: #3df0e0; }"
            )
            line_edit.setMinimumWidth(140)
            line_edit.setToolTip(f"String-Wert für {name}")

            # Heuristik: Path-artiger Name → Browse-Button
            is_path = name in ('file_path', 'sample_path', 'preset_path') \
                      or name.endswith('_path') or name.endswith('_file')

            mod_id = module.id

            # v0.0.21.246 — Doppel-Dialog-Bug-Fix:
            # Vorher hatte `editingFinished.connect(...)` das Signal beim
            # Focus-Verlust gefeuert (z.B. wenn der User auf 📂 klickt).
            # In Kombination mit dem Browse-Click und dem anschließenden
            # patch_modified-Rebuild des Properties-Panels öffnete sich der
            # File-Dialog manchmal zweimal hintereinander.
            # Fix: returnPressed (Enter-Press) statt editingFinished — der
            # User muss aktiv bestätigen. Plus: Re-entry-Guard im Browse-
            # Handler verhindert dass mehrere Dialoge parallel offen sind.
            line_edit.returnPressed.connect(
                lambda mid=mod_id, p=name, le=line_edit:
                    self.param_str_changed.emit(mid, p, le.text())
            )
            row_layout.addWidget(line_edit, 1)

            if is_path:
                # 📂 Browse-Button
                browse_btn = QPushButton("📂")
                browse_btn.setMaximumWidth(32)
                browse_btn.setToolTip(
                    f"Datei auswählen für {name}\n"
                    "Unterstützt: WAV, FLAC, OGG, AIFF, MP3, MP4, M4A, "
                    "AAC, OPUS, WMA und alles was ffmpeg lesen kann"
                )
                browse_btn.setStyleSheet(
                    "QPushButton { color: #3df0e0; background: #0d1117; "
                    "border: 1px solid #161b22; border-radius: 3px; "
                    "padding: 2px; font-size: 11px; } "
                    "QPushButton:hover { border-color: #3df0e0; }"
                )

                def _on_browse(mid=mod_id, p=name, le=line_edit, btn=browse_btn):
                    # v0.0.21.246 — Re-entry-Guard: verhindert Doppel-Dialog
                    # wenn das clicked-Signal aus irgendeinem Grund mehrfach
                    # feuert (Qt event-loop Verschachtelung beim modalen
                    # QFileDialog.exec() kann das auslösen).
                    if getattr(btn, '_browse_in_progress', False):
                        return
                    btn._browse_in_progress = True
                    try:
                        # Letzter Pfad als Start-Verzeichnis
                        start_path = le.text() or ""
                        if start_path:
                            import os as _os
                            start_dir = _os.path.dirname(start_path)
                        else:
                            start_dir = ""
                        selected, _ = QFileDialog.getOpenFileName(
                            self,
                            f"Sample-Datei für {p}",
                            start_dir,
                            "Audio-Dateien (*.wav *.flac *.ogg *.aif *.aiff "
                            "*.au *.w64 *.mp3 *.mp4 *.m4a *.aac *.opus *.wma "
                            "*.mov *.mkv *.webm);;Alle Dateien (*)",
                        )
                        if selected:
                            # blockSignals während setText, damit returnPressed
                            # nicht aus Versehen feuert (defensiv)
                            le.blockSignals(True)
                            le.setText(selected)
                            le.blockSignals(False)
                            self.param_str_changed.emit(mid, p, selected)
                    finally:
                        btn._browse_in_progress = False

                browse_btn.clicked.connect(_on_browse)
                row_layout.addWidget(browse_btn)

            self._param_form.addRow(name + ":", row)

        def _add_param_row(
            self, module: Module, name: str, value: float,
        ) -> None:
            """Fügt eine Zeile (Label : [Knob][SpinBox]) ins Form ein.

            Die Range/Default/Unit kommt aus dem korrespondierenden
            Input-Port (CV-Konvention). Falls kein Port existiert,
            fallen wir auf eine generische Range zurück.
            """
            port = self._port_for_param(module, name)
            if port is not None:
                lo, hi = float(port.minimum), float(port.maximum)
                default = float(port.default)
                unit = str(port.unit)
            else:
                # Generischer Fallback (alte v.193-Optik)
                lo, hi, default, unit = -1e6, 1e6, value, ""

            # SpinBox — präzise Eingabe + sichtbarer Zahlenwert
            sb = QDoubleSpinBox()
            # Range-Setzen vor setValue, sonst clamped Qt
            sb_lo, sb_hi = lo, hi
            if sb_lo == sb_hi:
                sb_lo, sb_hi = -1e6, 1e6
            # Etwas mehr Headroom als Knob, damit Power-User auch mal
            # über die GUI-Range hinausschießen können (Engine clamped
            # selbst nochmal, falls nötig)
            sb.setRange(min(sb_lo, -1e6 if sb_lo < 0 else sb_lo), max(sb_hi, 1e6 if sb_hi > 0 else sb_hi))
            # Decimals abhängig von Größenordnung
            range_abs = max(abs(sb_hi), abs(sb_lo), 1.0)
            decimals = 0 if range_abs >= 1000 else (1 if range_abs >= 10 else 3)
            sb.setDecimals(decimals)
            sb.setValue(value)
            # Step-Size: 1/100 der Range (oder 1.0 wenn Range "groß")
            step = max((hi - lo) / 100.0, 0.001) if hi > lo else 1.0
            sb.setSingleStep(step)
            sb.setMaximumWidth(82)
            sb.setStyleSheet(
                "QDoubleSpinBox { background:#0a0e14; color:#e6edf3;"
                "border:1px solid #161b22; padding:2px 4px;"
                "font-family: monospace; font-size: 10px; }"
            )
            sb.valueChanged.connect(
                lambda v, n=name: self._on_spinbox_changed(n, v)
            )
            self._spinboxes[name] = sb

            # AnimatedKnob (optional — Fallback bei Import-Fehler)
            knob = None
            if AnimatedKnob is not None:
                try:
                    knob = AnimatedKnob(
                        name=name,
                        value=value,
                        minimum=lo, maximum=hi,
                        default=default,
                        unit=unit,
                        compact=True,  # kompakt — der Wert steht schon in der SpinBox
                    )
                    knob.value_changed.connect(
                        lambda v, n=name: self._on_knob_changed(n, v)
                    )
                except Exception as e:  # pragma: no cover
                    logger.debug("[FLUX-UI] knob create failed for %s: %s", name, e)
                    knob = None

            if knob is not None:
                self._knobs[name] = knob
                # Container für Knob+SpinBox in einer Zeile
                row = QWidget()
                row_lay = QHBoxLayout(row)
                row_lay.setContentsMargins(0, 0, 0, 0)
                row_lay.setSpacing(4)
                row_lay.addWidget(knob)
                row_lay.addWidget(sb, 1)
                self._param_form.addRow(name + ":", row)
            else:
                # Fallback: nur SpinBox (alte v.193-Optik)
                self._param_form.addRow(name + ":", sb)

        # ─── Sync-Slots: Knob ↔ SpinBox ↔ Patch-Modell ───────────

        def _on_knob_changed(self, param: str, value: float) -> None:
            """Knob wurde gedreht → SpinBox nachziehen + param_changed feuern."""
            if self._syncing_param == param:
                return
            sb = self._spinboxes.get(param)
            if sb is not None:
                self._syncing_param = param
                try:
                    # blockSignals: SpinBox.setValue würde sonst
                    # _on_spinbox_changed re-triggern → Echo-Loop
                    sb.blockSignals(True)
                    sb.setValue(float(value))
                    sb.blockSignals(False)
                finally:
                    self._syncing_param = None
            self._emit_param_changed(param, float(value))

        def _on_spinbox_changed(self, param: str, value: float) -> None:
            """SpinBox-Eingabe → Knob nachziehen + param_changed feuern."""
            if self._syncing_param == param:
                return
            knob = self._knobs.get(param)
            if knob is not None:
                self._syncing_param = param
                try:
                    # set_value mit emit_signal=False, sonst feuert der
                    # Knob auch noch sein value_changed → Echo-Loop
                    knob.set_value(float(value), emit_signal=False)
                finally:
                    self._syncing_param = None
            self._emit_param_changed(param, float(value))

        def _emit_param_changed(self, param: str, value: float) -> None:
            """Zentrale Stelle die Patch-Modell + Outbound-Signal aktualisiert.

            Kümmert sich um:
            - lokale `_current_module.params[param]` Aktualisierung
            - Outbound `param_changed(module_id, param, value)` Signal
              (das `FluxMainWidget._on_param_changed` triggert und ans
               Rust-Backend dispatcht — D-1-Pfad seit v.184).
            """
            if self._current_module is None:
                return
            self._current_module.params[param] = float(value)
            self.param_changed.emit(self._current_module.id, param, float(value))

        # ─── Backwards-Compat: alte _on_param_changed Signatur ───
        # Falls externer Code (Tests, Plug-ins) noch die alte Direkt-
        # Methode aufruft, leiten wir auf den neuen Pfad um.

        def _on_param_changed(self, param: str, value: float) -> None:
            """Legacy-Slot — bleibt aus Kompatibilitätsgründen erhalten."""
            self._emit_param_changed(param, float(value))


    # ════════════════════════════════════════════════════════════════
    # v0.0.21.260 — KI-Modul-Alias-Map (Safety-Net gegen Halluzinationen)
    # ════════════════════════════════════════════════════════════════
    #
    # Mapping (KI-sagte) → (real existiert in MODULE_REGISTRY).
    #
    # Beobachtete Halluzinations-Muster aus v.258-Live-Tests
    # (Anno's Screenshots vom 2026-05-05):
    #
    # 1. CASE-DIFF: KI nutzt PascalCase wo Registry UPPERCASE-Akronyme hat
    #    z.B. "LfoSine" statt "LFOSine"
    #
    # 2. FALSCHER GOTT: KI ordnet Module dem falschen Gott zu
    #    z.B. Iduna.Chorus → real: Skadi.Chorus
    #         Fenrir.Saturator → real: Thor.Saturation
    #
    # 3. NICHT-EXISTENT: KI erfindet Module ganz
    #    z.B. Loki.LfoSawDown — fallback auf nächstähnliches LFO
    #         Iduna.ReverbPlate — fallback auf Iduna.Reverb
    _KI_MODULE_ALIASES: dict[tuple[str, str], tuple[str, str]] = {
        # ─── Loki: PascalCase + erfundene Wellenformen ───────────
        ("Loki", "LfoSine"):       ("Loki", "LFOSine"),
        ("Loki", "LfoTriangle"):   ("Loki", "LFOTriangle"),
        ("Loki", "LfoSquare"):     ("Loki", "LFOSquare"),
        ("Loki", "LfoSampleHold"): ("Loki", "LFOSampleHold"),
        # KI erfindet Saw-LFOs die nicht existieren → fallback Triangle
        ("Loki", "LfoSawUp"):      ("Loki", "LFOTriangle"),
        ("Loki", "LfoSawDown"):    ("Loki", "LFOTriangle"),
        ("Loki", "LFOSawUp"):      ("Loki", "LFOTriangle"),
        ("Loki", "LFOSawDown"):    ("Loki", "LFOTriangle"),
        # ─── Skadi-Module die KI bei Iduna sucht ─────────────────
        ("Iduna", "Chorus"):   ("Skadi", "Chorus"),
        ("Iduna", "Flanger"):  ("Skadi", "Flanger"),
        ("Iduna", "Phaser"):   ("Skadi", "Phaser"),
        # ─── Iduna-Reverb-Varianten ───────────────────────────────
        ("Iduna", "ReverbPlate"): ("Iduna", "Reverb"),
        ("Iduna", "PlateReverb"): ("Iduna", "Reverb"),
        ("Iduna", "ReverbHall"):  ("Iduna", "Reverb"),
        # ─── Thor-Distortion-Module die KI bei Fenrir sucht ──────
        ("Fenrir", "Saturator"):    ("Thor", "Saturation"),
        ("Fenrir", "Saturation"):   ("Thor", "Saturation"),
        ("Fenrir", "Drive"):        ("Thor", "TubeDrive"),
        ("Fenrir", "TubeDrive"):    ("Thor", "TubeDrive"),
        ("Fenrir", "Overdrive"):    ("Thor", "TubeDrive"),
        ("Fenrir", "Distortion"):   ("Thor", "TubeDrive"),
        ("Fenrir", "Fuzz"):         ("Thor", "Fuzz"),
        ("Fenrir", "WaveShaper"):   ("Thor", "WaveShaper"),
        # Thor selbst: Aliase für die echten Kinds
        ("Thor", "Saturator"):  ("Thor", "Saturation"),
        ("Thor", "Drive"):      ("Thor", "TubeDrive"),
        ("Thor", "Overdrive"):  ("Thor", "TubeDrive"),
        ("Thor", "Distortion"): ("Thor", "TubeDrive"),
        # ─── Vidar-Variationen ────────────────────────────────────
        ("Vidar", "PeakLimit"):  ("Vidar", "PeakLimiter"),
        ("Vidar", "BrickWall"):  ("Vidar", "PeakLimiter"),
        # ─── Forseti-Filter-Aliase ────────────────────────────────
        ("Forseti", "LowPass"):  ("Forseti", "Lowpass"),
        ("Forseti", "HighPass"): ("Forseti", "Highpass"),
        ("Forseti", "BandPass"): ("Forseti", "Bandpass"),
        # ─── Bragi-Oszillator-Aliase ──────────────────────────────
        ("Bragi", "Sine"):     ("Bragi", "SineOsc"),
        ("Bragi", "Saw"):      ("Bragi", "SawOsc"),
        ("Bragi", "Square"):   ("Bragi", "SquareOsc"),
        ("Bragi", "Triangle"): ("Bragi", "TriangleOsc"),
        ("Bragi", "Noise"):    ("Bragi", "NoiseOsc"),
        ("Bragi", "Pulse"):    ("Bragi", "PulseOsc"),
        ("Bragi", "Sub"):      ("Bragi", "SubOsc"),
        ("Bragi", "Swarm"):    ("Bragi", "SwarmOsc"),
        ("Bragi", "FM"):       ("Bragi", "FMOsc"),
        # ─── Freyr-Hüllkurven ─────────────────────────────────────
        # KI erfindet manchmal AHDSR — fallback auf ADSR
        ("Freyr", "AHDSR"):    ("Freyr", "ADSR"),
        ("Freyr", "Envelope"): ("Freyr", "ADSR"),
    }


    # ════════════════════════════════════════════════════════════════
    # v0.0.21.261 — KI-Port-Alias-Map (Safety-Net gegen Port-Halluzinationen)
    # ════════════════════════════════════════════════════════════════
    #
    # Mapping (kind, halluzinierter_port) → echter_port_name
    #
    # Beobachtetes Bug-Pattern aus v.260-Live-Test (Anno's Bild 18:35):
    #   `WARNING [FLUX-Build] connection[2]: src_port 'env_out'
    #    nicht in Freyr.ADSR outputs`
    # KI nutzte `env_out`, der echte Port-Name ist `cv_out`.
    #
    # Auch im v.258-Schema-Beispiel war fälschlich `gain_out` → KI hat
    # das in andere Halluzinationen wie `env_out`, `lfo_out` variiert.
    # In v.261 ist das Schema-Beispiel korrigiert UND die KI bekommt
    # explizit „immer cv_out" im Prompt — diese Map ist Safety-Net falls
    # die KI trotzdem auf alte Aliase zurückfällt.
    #
    # Format: kind alleine (ohne god) reicht — die Auflösung passiert
    # nach dem Modul-Build, da haben wir das Modul-Objekt mit echten Ports.
    _KI_PORT_ALIASES_OUT: dict[tuple[str, str], str] = {
        # Modulator-Module: cv_out ist der echte Output
        ("ADSR",          "env_out"):    "cv_out",
        ("ADSR",          "gain_out"):   "cv_out",
        ("ADSR",          "envelope"):   "cv_out",
        ("ADSR",          "out"):        "cv_out",
        ("ADSR",          "output"):     "cv_out",
        ("LFOSine",       "lfo_out"):    "cv_out",
        ("LFOSine",       "out"):        "cv_out",
        ("LFOSine",       "output"):     "cv_out",
        ("LFOTriangle",   "lfo_out"):    "cv_out",
        ("LFOTriangle",   "out"):        "cv_out",
        ("LFOSquare",     "lfo_out"):    "cv_out",
        ("LFOSquare",     "out"):        "cv_out",
        ("LFOSampleHold", "lfo_out"):    "cv_out",
        ("LFOSampleHold", "out"):        "cv_out",
        # Audio-Module: gängige Halluzinationen
        # (z.B. KI sagt "out" statt "audio_out")
        # Diese werden generisch via _resolve_audio_port_alias gelöst.
    }

    # Generische Port-Aliase die für jedes Modul gelten
    _KI_PORT_ALIASES_GENERIC: dict[str, str] = {
        "out":       "audio_out",
        "output":    "audio_out",
        "audio":     "audio_out",
        "in":        "audio_in",
        "input":     "audio_in",
        "left":      "audio_in_l",
        "right":     "audio_in_r",
        "out_l":     "audio_out_l",
        "out_r":     "audio_out_r",
        "out_left":  "audio_out_l",
        "out_right": "audio_out_r",
    }


    def _resolve_port_alias(port_name: str, mod, is_output: bool) -> str:
        """v0.0.21.261 — Resolves a possibly-hallucinated port name to
        the real port on the module.

        Strategy (in order):
        1. If port_name exists on the module, return it (no aliasing).
        2. Look up (mod.kind, port_name) in `_KI_PORT_ALIASES_OUT` for
           outputs — these are kind-specific (e.g. ADSR.env_out → cv_out).
        3. Look up port_name in `_KI_PORT_ALIASES_GENERIC` for generic
           cases (e.g. "out" → "audio_out").
        4. If aliased name exists on the module, use it.
        5. Otherwise return original (will fail port-check downstream
           with a visible warning).
        """
        ports = mod.outputs if is_output else mod.inputs
        port_set = {p.name for p in ports}
        if port_name in port_set:
            return port_name  # already correct
        # Kind-specific output alias
        if is_output:
            kind_alias = _KI_PORT_ALIASES_OUT.get((mod.kind, port_name))
            if kind_alias is not None and kind_alias in port_set:
                return kind_alias
        # Generic alias (works for both directions)
        generic_alias = _KI_PORT_ALIASES_GENERIC.get(port_name)
        if generic_alias is not None and generic_alias in port_set:
            return generic_alias
        # Last resort: no alias matched
        return port_name


    class FluxMainWidget(QWidget):
        """Das vollständige FLUX-Interface — als Tab im MainWindow nutzbar.

        Toolbar oben, Splitter mit (Palette | Canvas | Properties) in der
        Mitte, Status-Leiste unten.

        v0.0.21.171: Per-Track-Architektur. Das Widget beobachtet den
        aktuellen Track-Selection-Status und zeigt automatisch den FLUX-
        Patch dieser Track. Mehrere Tracks → mehrere Patches.
        """

        # Signale für die DAW-Integration
        patch_modified = pyqtSignal()  # Patch wurde geändert (für dirty-flag)

        def __init__(self, project_service=None, parent=None):
            super().__init__(parent)
            # v0.0.21.259 — Tooltip-Schrift cyan NUR für FLUX
            # ------------------------------------------------
            # Anno's Korrektur (2026-05-05): „cyan sollte nur in flux sein
            # der rest war doch gut" — v.257 hatte den Stylesheet global
            # via app.setStyleSheet() gesetzt, dadurch waren ALLE Tooltips
            # cyan (Track-Zeile, MIDI-Input, Mute, Knife etc).
            #
            # Qt-Stylesheets mit QToolTip-Selektor auf einem Widget gelten
            # nur für Tooltips, die von diesem Widget oder seinen Children
            # erzeugt werden — nicht systemweit. Damit ist das Cyan jetzt
            # auf den FLUX-Bereich beschränkt: Module-Browser, Toolbar,
            # Status-Strip, Properties-Panel — alles innerhalb des FLUX-
            # Widgets. Außerhalb (Arranger, Editor, Track-Headers) bleibt
            # das v.256-Originalverhalten erhalten.
            self.setStyleSheet(
                "background: #0a0e14;"
                "QToolTip { color: #00ffff; }"
            )
            self._project_service = project_service
            self._current_track_id: str = ""
            # Wenn KEIN Projekt-Service da ist (z.B. Standalone-Test),
            # arbeiten wir im „Workspace-Modus" mit einem einzelnen Demo-Patch.
            self._workspace_patch: Optional[Patch] = None

            root = QVBoxLayout(self)
            root.setContentsMargins(0, 0, 0, 0)
            root.setSpacing(0)

            # ─── Toolbar ─────────────────────────────────────────
            toolbar = QFrame()
            toolbar.setStyleSheet(
                "background:#0d1117; border-bottom:1px solid #161b22;"
            )
            toolbar.setFixedHeight(36)
            tb_layout = QHBoxLayout(toolbar)
            tb_layout.setContentsMargins(8, 4, 8, 4)
            tb_layout.setSpacing(8)

            label = QLabel("⚡ FLUX")
            label.setStyleSheet(
                "color:#3df0e0; font-family:monospace; font-weight:bold;"
                "font-size:12px;"
            )
            tb_layout.addWidget(label)

            # v0.0.21.171: Track-Status-Label — zeigt aktuelle Track + Patch
            self._track_label = QLabel("")
            try:
                from PyQt6.QtCore import Qt as _Qt
                self._track_label.setTextFormat(_Qt.TextFormat.RichText)
            except Exception:
                pass
            self._track_label.setStyleSheet(
                "color:#8b949e; font-family:monospace; font-size:10px;"
                "padding: 0 8px;"
            )
            tb_layout.addWidget(self._track_label, 1)

            # v0.0.21.171: Patch-Verwaltungs-Buttons
            self._btn_create = self._tool_btn("⊕ Patch erstellen", "#10b981")
            self._btn_create.clicked.connect(self._create_patch_for_track)
            self._btn_create.setToolTip(
                "Erzeugt einen neuen FLUX-Patch und weist ihn der aktuellen Track zu.")
            tb_layout.addWidget(self._btn_create)

            self._btn_unlink = self._tool_btn("🔗 Lösen", "#f59e0b")
            self._btn_unlink.clicked.connect(self._unlink_patch_from_track)
            self._btn_unlink.setToolTip(
                "Hebt die Zuordnung Patch → Track auf. Der Patch bleibt im "
                "Projekt erhalten und kann anderen Tracks zugewiesen werden.")
            tb_layout.addWidget(self._btn_unlink)

            btn_demo = self._tool_btn("⊕ Demo-Patch", "#10b981")
            btn_demo.clicked.connect(self._load_demo)
            tb_layout.addWidget(btn_demo)

            # v0.0.21.197 V-1: FLUX-Vault Save/Load
            self._btn_vault_save = self._tool_btn("💾 Vault Save", "#3df0e0")
            self._btn_vault_save.clicked.connect(self._vault_save)
            self._btn_vault_save.setToolTip(
                "Speichert den aktuellen FLUX-Patch im Vault\n"
                "(SQLite: ~/.config/ChronoScaleStudio/flux_vault.db)\n\n"
                "Mit Name, Beschreibung, Tags, Style.\n"
                "Vorhandene User-Patches werden mit history-archive überschrieben.")
            tb_layout.addWidget(self._btn_vault_save)

            self._btn_vault_load = self._tool_btn("📂 Vault Load", "#3df0e0")
            self._btn_vault_load.clicked.connect(self._vault_load)
            self._btn_vault_load.setToolTip(
                "Lädt einen Patch aus dem Vault.\n"
                "Beim ersten Aufruf werden 12 Sacred-Pilot-Presets geseedet:\n"
                "Vesper, Matins, Compline, Te Deum, Hymnal-Pad, Choir-Drone,\n"
                "Pipe-Organ, Bell-Tower, Cathedral, Stained-Glass,\n"
                "Incense, Sancta-Sanctorum.")
            tb_layout.addWidget(self._btn_vault_load)

            # v0.0.21.181: Cluster-Button — Auto-Layout nach Topologie
            btn_cluster = self._tool_btn("⌗ Cluster", "#06b6d4")
            btn_cluster.clicked.connect(self._cluster_layout)
            btn_cluster.setToolTip(
                "Ordnet alle Module nach Topologie automatisch an:\n"
                "  • Sources (Bragi/Loki)         → linke Spalte\n"
                "  • Modulators (Freyr/Tyr)       → 2. Spalte\n"
                "  • FX (Forseti/Iduna/Hel/...)   → mittlere Spalten\n"
                "  • Outputs (Heimdall)            → rechte Spalte\n\n"
                "Animation: 300ms sanfter Übergang per Lerp.")
            tb_layout.addWidget(btn_cluster)

            self._btn_pulse = self._tool_btn("⏸ Pulses", "#a78bfa")
            self._btn_pulse.clicked.connect(self._toggle_pulses)
            self._pulses_running = True
            tb_layout.addWidget(self._btn_pulse)

            # v0.0.21.170 Mini-F-1: Test-Play & Stop
            self._btn_play = self._tool_btn("▶ Test Play", "#10b981")
            self._btn_play.clicked.connect(self._test_play)
            self._btn_play.setToolTip(
                "Rendert den Patch lokal mit numpy und spielt ihn 2 Sekunden\n"
                "über sounddevice ab. KEIN Routing zur DAW-Track —\n"
                "Sofort-Hör-Test für den Patch-Editor.")
            tb_layout.addWidget(self._btn_play)

            self._btn_stop = self._tool_btn("■ Stop", "#fbbf24")
            self._btn_stop.clicked.connect(self._test_stop)
            tb_layout.addWidget(self._btn_stop)

            # v0.0.21.241: Diagnose-Button — checkt Patch auf häufige
            # „stumme Oszi"-Probleme OHNE Audio zu rendern. Anno-Direktive:
            # „einige der oszilatoren in flux funktionieren nicht und sind
            # stumm obwohl sie lautstärke haben" → 5 typische UX-Probleme
            # erkennen (kein Master, Master nicht verbunden, gain=0,
            # Mtof ohne Trigger, orphan-oscillator).
            self._btn_diagnose = self._tool_btn("🔍 Diagnose", "#06b6d4")
            self._btn_diagnose.clicked.connect(self._diagnose_patch)
            self._btn_diagnose.setToolTip(
                "Scant den Patch auf häufige Probleme die Oszis stumm machen:\n"
                "• Kein/unverbundenes MasterOut\n"
                "• Knob/Slider auf 0 → gain wird gegen 0 gezogen\n"
                "• Mtof/Ftom ohne Trigger\n"
                "• Oszi nicht im Pfad zum Master\n"
                "• v.242: Live-Activity-Check (Probe-Render)\n"
                "Zeigt Diagnose-Bericht als Dialog.")
            tb_layout.addWidget(self._btn_diagnose)

            # v0.0.21.242: Smart-Connect-Helper. Anno-Use-Case: er hat
            # mehrere Oszis im Canvas die nicht zum Master verbunden
            # sind („14 stumm trotz Lautstärke"). Mit einem Klick werden
            # alle orphan-Oszis (audio_out unverbunden) sequenziell mit
            # MasterOut.audio_in_l/r verbunden.
            self._btn_smart_connect = self._tool_btn("🔗 Smart-Connect", "#a78bfa")
            self._btn_smart_connect.clicked.connect(self._smart_connect_to_master)
            self._btn_smart_connect.setToolTip(
                "Verbindet alle Oszillatoren die nicht zum Master\n"
                "verbunden sind direkt mit Heimdall.MasterOut\n"
                "(audio_in_l + audio_in_r). Wenn kein MasterOut da ist,\n"
                "wird einer hinzugefügt. Idealer Fix gegen 'stumme\n"
                "Oszi'-Patches die im Canvas drauf warten verbunden zu\n"
                "werden.")
            tb_layout.addWidget(self._btn_smart_connect)

            root.addWidget(toolbar)

            # ─── Mitte: Splitter ────────────────────────────────
            splitter = QSplitter(Qt.Orientation.Horizontal)
            splitter.setStyleSheet(
                "QSplitter::handle { background:#161b22; width:1px; }"
            )

            self.palette = ModulePaletteWidget()
            splitter.addWidget(self.palette)

            # v0.0.21.172: Canvas-Container mit Stack für Overlay-Hinweise.
            # Bitwig-Grid-Modell: wenn FLUX nicht aktiv ist, sieht Anno
            # einen großen Hinweis statt eines verwirrenden Editors.
            from PyQt6.QtWidgets import QStackedWidget
            self._canvas_stack = QStackedWidget()

            # v0.0.21.171: Initialer Patch
            if project_service is None:
                self._workspace_patch = make_demo_patch()
                initial_patch = self._workspace_patch
            else:
                initial_patch = Patch(name="(keine Track ausgewählt)")
            self.scene = FluxScene(initial_patch)
            self.view = FluxView(self.scene)
            self._canvas_stack.addWidget(self.view)  # index 0

            # Overlay-Hinweis-Widget
            self._overlay = self._make_overlay_widget()
            self._canvas_stack.addWidget(self._overlay)  # index 1

            splitter.addWidget(self._canvas_stack)

            self.properties = PropertiesPanelWidget()
            splitter.addWidget(self.properties)

            splitter.setStretchFactor(0, 0)
            splitter.setStretchFactor(1, 1)
            splitter.setStretchFactor(2, 0)
            splitter.setSizes([220, 800, 260])
            root.addWidget(splitter, 1)

            # ─── Status-Leiste ───────────────────────────────────
            status = QFrame()
            status.setStyleSheet(
                "background:#0d1117; border-top:1px solid #161b22; color:#8b949e;"
                "font-family:monospace; font-size:10px;"
            )
            status.setFixedHeight(22)
            self._status_layout = QHBoxLayout(status)
            self._status_layout.setContentsMargins(8, 2, 8, 2)
            self._status_label = QLabel(self._status_text())
            try:
                from PyQt6.QtCore import Qt as _Qt
                self._status_label.setTextFormat(_Qt.TextFormat.RichText)
            except Exception:
                pass
            self._status_layout.addWidget(self._status_label)
            self._status_layout.addStretch(1)
            self._status_right = QLabel("DEFENSIV-ONLY · Read-only · niemals offensiv")
            self._status_right.setStyleSheet("color:#10b981;")
            self._status_layout.addWidget(self._status_right)
            root.addWidget(status)

            # ─── v0.0.21.256: Live-Telemetry-Strip ───────────────
            # Defensiv-Import: wenn das Modul fehlt, fällt der FLUX-Tab
            # einfach auf die alte Status-Optik zurück (NICHTS-KAPUTT).
            self._telemetry_strip = None
            try:
                from pydaw.flux.flux_telemetry_strip import FluxTelemetryStrip
                self._telemetry_strip = FluxTelemetryStrip(parent=self)
                self._telemetry_strip.tip_requested.connect(
                    self._on_flux_tip_requested)
                root.addWidget(self._telemetry_strip)
            except Exception as exc:
                logger.debug(
                    "FluxTelemetryStrip nicht verfügbar (NICHTS-KAPUTT-Fallback): %s",
                    exc)

            # ─── Verkabelung ─────────────────────────────────────
            self.palette.module_requested.connect(self._on_palette_request)
            self.scene.selectionChanged.connect(self._on_selection_changed)
            self.scene.patch_changed.connect(self._on_patch_changed)
            # v0.0.21.196: param_only_changed (Knob-Drehung) — nur dirty-flag,
            # KEIN Engine-Resync (würde bei 60Hz die GIL festfrieren)
            self.scene.param_only_changed.connect(self.patch_modified.emit)
            # v0.0.21.184 (F-1.1.5): Live-Resync nach Param-Änderungen.
            # Knob-Drehung im Properties-Panel → Rust-Engine bekommt den
            # neuen Wert per FluxSetModuleParam-IPC.
            self.properties.param_changed.connect(self._on_param_changed)
            # v0.0.21.244 — String-Param-Änderungen (Sampler.file_path,
            # Ullr.Expr.expr, Hermod.Osc*-Strings). Eigener Pfad weil
            # die Rust-Engine `set_module_param` nur f32 nimmt — String-
            # Params werden im Python-Modell gespeichert und der Renderer
            # liest sie via `module.params` (nicht via IPC).
            self.properties.param_str_changed.connect(self._on_param_str_changed)

            # v0.0.21.230 — Living Patterns: Properties-Panel → FluxScene
            # Die Buttons im LP-Group des Properties-Panels feuern Signale
            # mit module.id; wir lookuppen das Modul im aktuellen Patch
            # und rufen die Scene-Coordination-Methoden auf. Nach jeder
            # Aktion wird das Properties-Panel mit `refresh_lp_status()`
            # aktualisiert damit die Counts stimmen.
            self.properties.lp_frozen_toggle_requested.connect(
                self._on_lp_frozen_toggle
            )
            self.properties.lp_snapshot_requested.connect(self._on_lp_snapshot)
            self.properties.lp_clear_requested.connect(self._on_lp_clear)
            # v0.0.21.231 — Undo/Redo
            self.properties.lp_undo_requested.connect(self._on_lp_undo)
            self.properties.lp_redo_requested.connect(self._on_lp_redo)

            # v0.0.21.174: Reagiere auf ProjectService-Signale damit der
            # FLUX-Tab auch dann aktualisiert wird wenn das Projekt
            # NACH dem FLUX-Tab-Init geladen wird (Init-Reihenfolge).
            if project_service is not None:
                for sig_name in ("project_opened", "project_changed"):
                    try:
                        sig = getattr(project_service, sig_name, None)
                        if sig is not None and hasattr(sig, "connect"):
                            sig.connect(self._on_project_signal)
                    except Exception:
                        pass

            # v0.0.21.172: Initial-Overlay je nach Modus
            if project_service is None:
                # Workspace-Modus — Canvas direkt anzeigen
                self._hide_overlay()
            else:
                # v0.0.21.173: Defensive Auto-Detection — wenn ProjectService
                # bereits einen aktiven Track hat (z.B. weil das Projekt gerade
                # geöffnet wurde), übernehmen wir den. Sonst Overlay "no_track".
                initial_track_id = self._resolve_active_track_id()
                if initial_track_id:
                    self._current_track_id = initial_track_id
                    self._refresh_for_current_track()
                else:
                    self._show_overlay("no_track")
                    self._refresh_track_label(None, None, "no_track")

            # v0.0.21.209: Saga.Magic Audio-Reaktivität anbinden.
            # Wir wiren die Track-Meter-Pipeline (rust_engine_bridge →
            # SagaRendererProxy.update_audio_features) so dass das Herz
            # tatsächlich pulsiert wenn Audio durchfließt. Defensiv:
            # bei Fehlern bleibt die Saga.Magic statisch (wie vor v.209).
            try:
                self._setup_saga_audio_bridge()
            except Exception as e:
                logger.debug(
                    "[FLUX-UI] saga audio bridge setup skipped: %s", e
                )

        def _tool_btn(self, text: str, color: str) -> QPushButton:
            b = QPushButton(text)
            b.setStyleSheet(f"""
                QPushButton {{
                    background: #161b22; color: {color};
                    border: 1px solid {color}; border-radius: 3px;
                    padding: 3px 10px; font-family: monospace;
                    font-size: 10px; font-weight: bold;
                }}
                QPushButton:hover {{ background: {color}; color: #0a0e14; }}
                QPushButton:disabled {{ color: #4a4a4a; border-color: #2a2a2a; }}
            """)
            return b

        def _make_overlay_widget(self) -> "QWidget":
            """Großer Hinweis-Bildschirm für Tracks ohne aktives FLUX.

            Wird statt des Canvas eingeblendet damit Anno klar sieht:
            'Diese Track ist NICHT auf FLUX gesetzt — es passiert hier nichts'.
            """
            w = QWidget()
            w.setStyleSheet("background: #0a0e14;")
            from PyQt6.QtWidgets import QVBoxLayout
            lay = QVBoxLayout(w)
            lay.setContentsMargins(40, 40, 40, 40)
            lay.setSpacing(16)
            lay.addStretch(1)

            self._overlay_icon = QLabel("⚡")
            self._overlay_icon.setStyleSheet(
                "color: #3df0e0; font-size: 64px; font-family: monospace;"
            )
            self._overlay_icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
            lay.addWidget(self._overlay_icon)

            self._overlay_title = QLabel("FLUX")
            self._overlay_title.setTextFormat(Qt.TextFormat.RichText)
            self._overlay_title.setStyleSheet(
                "color: #3df0e0; font-size: 28px; font-weight: bold;"
                "font-family: monospace;"
            )
            self._overlay_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
            lay.addWidget(self._overlay_title)

            self._overlay_message = QLabel("")
            self._overlay_message.setTextFormat(Qt.TextFormat.RichText)
            self._overlay_message.setStyleSheet(
                "color: #e6edf3; font-size: 13px; font-family: monospace;"
                "padding: 16px;"
            )
            self._overlay_message.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self._overlay_message.setWordWrap(True)
            lay.addWidget(self._overlay_message)

            self._overlay_hint = QLabel("")
            self._overlay_hint.setTextFormat(Qt.TextFormat.RichText)
            self._overlay_hint.setStyleSheet(
                "color: #8b949e; font-size: 11px; font-family: monospace;"
                "padding: 8px;"
            )
            self._overlay_hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self._overlay_hint.setWordWrap(True)
            lay.addWidget(self._overlay_hint)

            lay.addStretch(2)
            return w

        def _show_overlay(self, mode: str, track_name: str = "",
                           plugin_type: str = "") -> None:
            """Zeigt das Overlay je nach Modus (no_track/other_plugin/no_instrument)."""
            messages = {
                "no_track": (
                    "Keine Track ausgewählt",
                    "Klick im <b>Arranger</b> auf eine Track um deren FLUX-Patch zu sehen, "
                    "oder klick auf eine Track-Spur und dann auf <b>FLUX aktivieren</b> oben.",
                    "💡 FLUX ist <b>pro Track</b> — wie VST oder SF2.",
                ),
                "other_plugin": (
                    f'Track <b>„{track_name}"</b> nutzt <b>{plugin_type.upper()}</b>',
                    f"Diese Track hat bereits ein <b>{plugin_type.upper()}-Instrument</b> als Tonerzeuger. "
                    f"FLUX läuft hier <b>nicht</b>.",
                    "💡 Klick oben auf <b>FLUX aktivieren</b> um {plugin_type} durch FLUX zu ersetzen, "
                    "oder wähle eine andere Track.".replace("{plugin_type}", plugin_type.upper()),
                ),
                "no_instrument": (
                    f'Track <b>„{track_name}"</b> hat kein Instrument',
                    "Diese Track ist eine MIDI/Audio-Track ohne Tonerzeuger. "
                    "Du kannst FLUX als Instrument zuweisen.",
                    "⚡ Klick oben auf <b>FLUX aktivieren</b> um einen FLUX-Patch für diese Track zu erstellen.",
                ),
            }
            title, message, hint = messages.get(mode, messages["no_track"])
            self._overlay_title.setText(title)
            self._overlay_message.setText(message)
            self._overlay_hint.setText(hint)
            self._canvas_stack.setCurrentIndex(1)  # zeige Overlay

        def _hide_overlay(self) -> None:
            """Zeigt wieder den Canvas (wenn FLUX aktiv ist)."""
            self._canvas_stack.setCurrentIndex(0)

        def _status_text(self) -> str:
            s = self.scene.patch.stats()
            return (f"⚡ {s['modules']} Module · {s['connections']} Cables · "
                    f"{s['audio_connections']} Audio-Verbindungen")

        # ─── Slots ─────────────────────────────────────────────────

        def _on_palette_request(self, god: str, kind: str) -> None:
            module = make_module(god, kind)
            if module is None:
                logger.warning("[FLUX] Unknown module: %s.%s", god, kind)
                return
            # Position in der Mitte des aktuell sichtbaren View-Bereichs
            center = self.view.mapToScene(self.view.viewport().rect().center())
            self.scene.add_module(module, center)

        def _on_selection_changed(self) -> None:
            from pydaw.flux.flux_canvas import ModuleItem
            sel = self.scene.selectedItems()
            mod = None
            for it in sel:
                if isinstance(it, ModuleItem):
                    mod = it.module
                    break
            self.properties.show_module(mod)
            # v0.0.21.256 — Telemetry-Strip nachziehen
            try:
                if hasattr(self, "_telemetry_strip") and self._telemetry_strip is not None:
                    self._telemetry_strip.set_module(mod)
            except Exception:
                pass

        def _on_flux_tip_requested(self, module_kind_full: str, module_id: str) -> None:
            """v0.0.21.256 — KI-Tipp-Button im Telemetry-Strip wurde geklickt.

            Sammelt Patch-Kontext + Modul-Auswahl, öffnet das KI-Assistent-
            Dock und triggert den ``_FLUX_PATCH_TIP_``-Quick-Prompt.

            Defensive Implementierung: wenn das KI-Panel nicht erreichbar
            ist (z.B. weil der User es noch nicht geöffnet hat oder die
            Services nicht durchgeleitet sind), fällt das Ganze auf eine
            Status-Bar-Meldung zurück.
            """
            try:
                # Patch-Dict aktuell
                patch = getattr(self.scene, "patch", None)
                patch_dict = None
                if patch is not None and hasattr(patch, "to_dict"):
                    patch_dict = patch.to_dict()

                # MainWindow finden (für KI-Dock-Toggle)
                main_window = None
                try:
                    parent = self.parent()
                    while parent is not None:
                        if hasattr(parent, "_ki_assistant_panel") or \
                           hasattr(parent, "_toggle_ki_assistant_dock"):
                            main_window = parent
                            break
                        parent = parent.parent() if hasattr(parent, "parent") else None
                except Exception:
                    pass

                ki_panel = None
                if main_window is not None:
                    # Versuche das Dock zu öffnen (analog zur Toggle-Action)
                    try:
                        dock_toggle = getattr(main_window,
                                              "_toggle_ki_assistant_dock", None)
                        if callable(dock_toggle):
                            dock_toggle(True)
                    except Exception:
                        pass
                    ki_panel = getattr(main_window, "_ki_assistant_panel", None)

                if ki_panel is not None and hasattr(ki_panel, "request_flux_patch_tip"):
                    ki_panel.request_flux_patch_tip(
                        patch_dict=patch_dict,
                        module_id=module_id,
                        module_kind=module_kind_full,
                    )
                    self._status_label.setText(
                        f"💡 KI-Tipp angefragt für {module_kind_full}…")
                else:
                    # Fallback: wenn das KI-Panel nicht da ist
                    self._status_label.setText(
                        "💡 Bitte zuerst das KI-Assistent-Dock öffnen "
                        "(Ansicht → KI-Assistent), dann erneut auf 💡 KI-Tipp klicken.")
            except Exception as exc:
                logger.warning("FLUX KI-Tipp Request gescheitert: %s", exc)
                try:
                    self._status_label.setText(f"💡 KI-Tipp-Fehler: {exc}")
                except Exception:
                    pass

        # ─── v0.0.21.258 — FLUX-Patch-Builder (KI baut Patches im Canvas) ──
        # Anno's Direktive: "wenn ich dich frage 'baue patch' dann machst
        # du das in der chatbox aber der patch kommt nie an auf flux spur"
        # → Diese Methoden machen die KI-Patches Realität im Canvas.

        def apply_ki_patch_build(self, d: dict) -> bool:
            """Public-API: KI-generiertes kompakt-JSON → echter Patch im Canvas.

            Wird von main_window aufgerufen, sobald `KiAssistantPanel.
            flux_patch_build_requested` feuert. Nutzt die gleiche
            Lade-Pipeline wie der Vault-Load-Pfad, damit der Patch
            korrekt im FluxPatchService registriert und der aktuellen
            Track zugewiesen wird.

            Args:
                d: Kompaktes KI-JSON mit `type: "flux_patch"`, `modules`,
                   `connections`. Schema siehe `_do_flux_patch_build`
                   im KI-Panel.

            Returns:
                True wenn erfolgreich aufgebaut, False bei Fehler.
            """
            try:
                patch = self._build_patch_from_ki_dict(d)
            except Exception as exc:
                logger.warning("[FLUX-Build] Patch-Build fehlgeschlagen: %s", exc)
                try:
                    self._status_label.setText(
                        f"<span style='color:#ef4444;'>⚠ KI-Patch-Build "
                        f"fehlgeschlagen: {exc}</span>")
                except Exception:
                    pass
                return False

            if patch is None or len(patch.modules) == 0:
                try:
                    self._status_label.setText(
                        "<span style='color:#ef4444;'>⚠ KI-Patch hat keine "
                        "validen Module — nicht geladen</span>")
                except Exception:
                    pass
                return False

            # Selbe Lade-Pipeline wie Vault-Load (Zeile ~2107-2160) —
            # FluxPatchService registrieren + Track zuweisen.
            project = self._get_project()
            track = self._get_current_track()
            svc = None
            try:
                from pydaw.services.flux_patch_service import get_flux_patch_service
                svc = get_flux_patch_service()
            except Exception as e:
                logger.warning("[FLUX-Build] FluxPatchService nicht verfügbar: %s", e)

            if svc is not None and project is not None and track is not None:
                try:
                    old_pid = str(getattr(track, "flux_patch_id", "") or "")
                    if old_pid and old_pid != patch.id:
                        try:
                            svc.remove(old_pid, project)
                        except Exception as e:
                            logger.debug("[FLUX-Build] old patch remove failed: %s", e)
                    svc.add(patch)
                    svc.assign_to_track(project, str(track.id), patch.id)
                    try:
                        if str(getattr(track, "plugin_type", "") or "").lower() != "flux":
                            track.plugin_type = "flux"
                    except Exception:
                        pass
                    logger.info(
                        "[FLUX-Build] KI-Patch '%s' (%s) → track '%s' assigned",
                        patch.name, patch.id, getattr(track, "id", "?"))
                except Exception as e:
                    logger.exception("[FLUX-Build] track assignment failed: %s", e)

            self.scene.set_patch(patch)
            # v0.0.21.260 — Skip-/Alias-Report im Status anzeigen
            # damit Anno SIEHT was die KI halluziniert hat.
            skipped = list(getattr(self, "_last_build_skipped", []) or [])
            aliased = list(getattr(self, "_last_build_aliased", []) or [])
            try:
                base = (f"🎛 KI-Patch '{patch.name}' aufgebaut: "
                        f"{len(patch.modules)} Module, "
                        f"{len(patch.connections)} Verbindungen")
                parts = [f"<span style='color:#3df0e0;'>{base}</span>"]
                if aliased:
                    parts.append(
                        f"<span style='color:#fbbf24;'> · "
                        f"⤷ {len(aliased)} aliased: "
                        f"{', '.join(aliased[:3])}"
                        f"{' …' if len(aliased) > 3 else ''}</span>")
                if skipped:
                    parts.append(
                        f"<span style='color:#ef4444;'> · "
                        f"⚠ {len(skipped)} übersprungen: "
                        f"{', '.join(skipped[:3])}"
                        f"{' …' if len(skipped) > 3 else ''}</span>")
                self._status_label.setText("".join(parts))
            except Exception:
                pass
            return True

        def _build_patch_from_ki_dict(self, d: dict) -> Optional[Patch]:
            """Kompaktes KI-JSON → vollständiger Patch via MODULE_REGISTRY.

            Das Schema des KI-JSONs ist bewusst kompakt — nur
            `god + kind + params` pro Modul. Diese Methode löst über
            MODULE_REGISTRY die vollständigen Modul-Definitionen
            (mit allen Ports + Default-Param-Werten) auf und überschreibt
            nur die KI-genannten Param-Werte.

            v0.0.21.260: Alias-Map als Safety-Net für KI-Halluzinationen.
            Selbst wenn die KI alte Aliase produziert (LfoSine statt
            LFOSine, Iduna.Chorus statt Skadi.Chorus etc.), fängt der
            Builder es per Mapping ab. Übersprungene Module werden in
            `self._last_build_skipped` gesammelt und im Status sichtbar.

            Defensiv-Verhalten:
            - Unbekannte (god, kind)-Tupel: Alias-Lookup; wenn auch der
              fehlschlägt, Modul wird übersprungen + Warning geloggt
              + im Skip-Report sichtbar.
            - Unbekannte Params: werden trotzdem übernommen — Module
              ignorieren unbekannte Schlüssel im DSP-Layer.
            - Connection mit ungültigem Index oder unbekanntem Port:
              wird übersprungen + Warning geloggt.

            Layout: Module werden in Spalten je nach God-Kategorie
            angeordnet (Sources links, Modulators 2., FX mitte,
            Output rechts) — gleiche Logik wie Cluster-Layout.
            """
            from pydaw.flux.patch_model import Patch as _Patch, Connection as _Conn, _new_id
            from pydaw.flux.module_library import MODULE_REGISTRY
            from pydaw.flux.yggdrasil import get_god

            if not isinstance(d, dict):
                return None
            ki_modules = d.get("modules") or []
            ki_conns   = d.get("connections") or []
            if not isinstance(ki_modules, list) or not ki_modules:
                return None

            # Skip-Report initialisieren — wird von der UI gelesen damit
            # Anno sieht WAS schief ging (statt nur Module-Counter).
            self._last_build_skipped: list[str] = []
            self._last_build_aliased: list[str] = []

            # Module bauen
            built_modules = []
            ki_index_to_real_index: dict[int, int] = {}
            for ki_idx, m in enumerate(ki_modules):
                if not isinstance(m, dict):
                    logger.warning("[FLUX-Build] modul[%d] ist kein dict — übersprungen", ki_idx)
                    self._last_build_skipped.append(f"#{ki_idx}: kein dict")
                    continue
                god = str(m.get("god", "")).strip()
                kind = str(m.get("kind", "")).strip()
                if not god or not kind:
                    logger.warning("[FLUX-Build] modul[%d] hat kein god/kind — übersprungen", ki_idx)
                    self._last_build_skipped.append(f"#{ki_idx}: kein god/kind")
                    continue
                # 1. Direkter Lookup
                factory = MODULE_REGISTRY.get((god, kind))
                # 2. Alias-Lookup (Safety-Net für KI-Halluzinationen)
                if factory is None:
                    aliased = _KI_MODULE_ALIASES.get((god, kind))
                    if aliased is not None:
                        factory = MODULE_REGISTRY.get(aliased)
                        if factory is not None:
                            logger.info("[FLUX-Build] modul[%d] %s.%s → alias %s.%s",
                                        ki_idx, god, kind, aliased[0], aliased[1])
                            self._last_build_aliased.append(
                                f"{god}.{kind} → {aliased[0]}.{aliased[1]}")
                            # Für die god-Spalten-Zuordnung im Layout:
                            # Wir behalten den Original-god aus der KI-Antwort
                            # nicht — der real existierende god ist relevant.
                            god = aliased[0]
                            kind = aliased[1]
                if factory is None:
                    logger.warning("[FLUX-Build] modul[%d] unbekannt: %s.%s — übersprungen", ki_idx, god, kind)
                    self._last_build_skipped.append(f"{god}.{kind}")
                    continue
                try:
                    mod_obj = factory()
                except Exception as e:
                    logger.warning("[FLUX-Build] modul[%d] %s.%s factory failed: %s", ki_idx, god, kind, e)
                    self._last_build_skipped.append(f"{god}.{kind} (factory failed)")
                    continue
                # KI-Params auf das Modul anwenden (override defaults)
                ki_params = m.get("params") or {}
                if isinstance(ki_params, dict):
                    for pk, pv in ki_params.items():
                        try:
                            mod_obj.params[str(pk)] = pv
                            # CV-Inputs haben Default-Wert in port.default —
                            # synchronisieren damit Knobs den KI-Wert anzeigen.
                            for port in mod_obj.inputs:
                                if port.name == str(pk):
                                    try:
                                        port.default = float(pv)
                                    except (TypeError, ValueError):
                                        pass
                                    break
                        except Exception:
                            pass
                ki_index_to_real_index[ki_idx] = len(built_modules)
                built_modules.append(mod_obj)

            if not built_modules:
                return None

            # Layout: kategorie-basierte Spalten (wie Cluster-Auto-Layout)
            try:
                self._auto_layout_built_modules(built_modules)
            except Exception as e:
                logger.debug("[FLUX-Build] Auto-Layout fehlgeschlagen, "
                             "Module bleiben auf (0,0): %s", e)

            # Connections bauen
            built_conns = []
            for ki_c_idx, c in enumerate(ki_conns):
                if not isinstance(c, dict):
                    continue
                src_ki = c.get("src")
                tgt_ki = c.get("tgt")
                src_port = str(c.get("src_port", "")).strip()
                tgt_port = str(c.get("tgt_port", "")).strip()
                if not isinstance(src_ki, int) or not isinstance(tgt_ki, int):
                    continue
                if src_ki not in ki_index_to_real_index or tgt_ki not in ki_index_to_real_index:
                    logger.warning("[FLUX-Build] connection[%d] zeigt auf "
                                   "übersprungenes Modul — übersprungen", ki_c_idx)
                    continue
                src_mod = built_modules[ki_index_to_real_index[src_ki]]
                tgt_mod = built_modules[ki_index_to_real_index[tgt_ki]]
                # v0.0.21.261 — Port-Alias-Resolver (Safety-Net)
                # KI halluziniert manchmal Port-Namen (`env_out` statt
                # `cv_out`, `out` statt `audio_out`). Wir versuchen
                # vor dem Schema-Check eine Auflösung über die Aliase.
                src_port_resolved = _resolve_port_alias(
                    src_port, src_mod, is_output=True)
                tgt_port_resolved = _resolve_port_alias(
                    tgt_port, tgt_mod, is_output=False)
                if src_port_resolved != src_port:
                    self._last_build_aliased.append(
                        f"{src_mod.god}.{src_mod.kind}.{src_port}"
                        f" → {src_port_resolved}")
                    src_port = src_port_resolved
                if tgt_port_resolved != tgt_port:
                    self._last_build_aliased.append(
                        f"{tgt_mod.god}.{tgt_mod.kind}.{tgt_port}"
                        f" → {tgt_port_resolved}")
                    tgt_port = tgt_port_resolved
                # Port-Existenz-Check (defensiv)
                if not any(p.name == src_port for p in src_mod.outputs):
                    logger.warning("[FLUX-Build] connection[%d]: src_port '%s' "
                                   "nicht in %s.%s outputs", ki_c_idx, src_port,
                                   src_mod.god, src_mod.kind)
                    self._last_build_skipped.append(
                        f"conn: {src_mod.god}.{src_mod.kind}.{src_port} (out)")
                    continue
                if not any(p.name == tgt_port for p in tgt_mod.inputs):
                    logger.warning("[FLUX-Build] connection[%d]: tgt_port '%s' "
                                   "nicht in %s.%s inputs", ki_c_idx, tgt_port,
                                   tgt_mod.god, tgt_mod.kind)
                    self._last_build_skipped.append(
                        f"conn: {tgt_mod.god}.{tgt_mod.kind}.{tgt_port} (in)")
                    continue
                built_conns.append(_Conn(
                    source_module=src_mod.id,
                    source_port=src_port,
                    target_module=tgt_mod.id,
                    target_port=tgt_port,
                ))

            patch_name = str(d.get("name", "KI-Patch")).strip() or "KI-Patch"
            patch_desc = str(d.get("description", "")).strip()
            patch = _Patch(
                id=_new_id("patch"),
                name=patch_name,
                modules=built_modules,
                connections=built_conns,
                author="KI",
                description=patch_desc,
            )
            # Drop invalid connections (Port-Schema-Drift safeguard)
            patch.connections = [c for c in patch.connections if patch._validate_connection(c)]
            return patch

        @staticmethod
        def _auto_layout_built_modules(modules: list) -> None:
            """Setzt module.position basierend auf God-Kategorie.

            Spalten-Layout (gleiche Idee wie Cluster-Auto-Layout):
              0: Sources      (Bragi, Loki)
              1: Modulators   (Freyr, Tyr)
              2: FX-1         (Forseti, Iduna)
              3: FX-2         (Hel, Vidar, Fenrir, etc.)
              4: Output       (Heimdall)

            Module derselben Spalte werden vertikal gestapelt.
            """
            from pydaw.flux.yggdrasil import get_god
            COL_SOURCES = 0
            COL_MODULATORS = 1
            COL_FX1 = 2
            COL_FX2 = 3
            COL_OUTPUT = 4

            COL_MAP = {
                # Sources
                "Bragi": COL_SOURCES, "Loki": COL_SOURCES,
                # Modulators
                "Freyr": COL_MODULATORS, "Tyr": COL_MODULATORS,
                "Norns": COL_MODULATORS, "Ullr": COL_MODULATORS,
                # FX-1 (Filter, Time)
                "Forseti": COL_FX1, "Iduna": COL_FX1,
                # FX-2 (Distortion, Dynamics)
                "Hel": COL_FX2, "Vidar": COL_FX2, "Fenrir": COL_FX2,
                "Voer": COL_FX2, "Soviet": COL_FX2,
                # Output
                "Heimdall": COL_OUTPUT,
            }

            X_SPACING = 280
            Y_SPACING = 140
            X_OFFSET = 100
            Y_OFFSET = 100

            col_counts: dict[int, int] = {}
            for m in modules:
                col = COL_MAP.get(m.god, COL_FX2)  # unbekannte Götter → FX2
                row = col_counts.get(col, 0)
                col_counts[col] = row + 1
                m.position = (
                    X_OFFSET + col * X_SPACING,
                    Y_OFFSET + row * Y_SPACING,
                )

        def _on_patch_changed(self) -> None:
            self._status_label.setText(self._status_text())
            # v0.0.21.230 — Living Patterns: Properties-Panel-Status
            # nachziehen (Promote/Demote-Click im Canvas ändert die
            # Counts). refresh_lp_status() ist no-op wenn das selektierte
            # Modul kein dynamic_outputs-Modul ist.
            try:
                self.properties.refresh_lp_status()
            except Exception:
                pass
            # v0.0.21.184 (F-1.1.5): Strukturelle Patch-Mutation
            # (Modul hinzugefügt, Cable gezogen, Modul gelöscht etc.) →
            # kompletten Patch zur Rust-Engine re-syncen. Defensive: bei
            # Fehler nur log, niemals UI crashen.
            try:
                from pydaw.services.flux_rust_sync import get_flux_rust_sync
                from pydaw.services.flux_patch_service import get_flux_patch_service
                patch = self.scene.patch
                if patch is not None and getattr(patch, "modules", None):
                    get_flux_rust_sync().sync_patch(patch)
                    # Falls der Patch Teil des Service-Indexes ist, dort
                    # auch das Patch-Objekt aktualisieren — Service hält
                    # einen Verweis-Eintrag, der auf dasselbe Objekt zeigt.
                    # Re-`add()` ist idempotent (überschreibt mit gleicher ID).
                    svc = get_flux_patch_service()
                    if svc.get(patch.id) is not None:
                        # Kein doppelter Engine-Sync — wir haben gerade
                        # selbst gesynct. Setze daher direkt im Index.
                        svc._patches[patch.id] = patch  # type: ignore[attr-defined]
            except Exception as e:
                logger.debug("[FLUX-UI] patch resync skipped: %s", e)
            # v0.0.21.209: Saga-Audio-Bridge informieren — neue Module könnten
            # Saga.Magic-Instances sein, die jetzt Track-Meter-Updates kriegen
            # müssen, oder gelöschte Module brauchen kein Routing mehr.
            try:
                from pydaw.services.saga_audio_bridge import (
                    get_saga_audio_bridge,
                )
                get_saga_audio_bridge().refresh_module_track_map()
            except Exception as e:
                logger.debug("[FLUX-UI] saga bridge refresh skipped: %s", e)
            self.patch_modified.emit()

        # v0.0.21.209 — Saga.Magic Audio-Reaktivität-Setup
        def _setup_saga_audio_bridge(self) -> None:
            """Initialisiert die ``SagaAudioBridge`` und verbindet sie mit
            audio_engine + project_service.

            Wird einmal in __init__ aufgerufen. Idempotent — die Bridge
            selbst ist auch idempotent.

            Wenn das audio_engine zum Init-Zeitpunkt noch keinen
            rust_engine_bridge hat (Race-Condition beim Cold-Start),
            wird der Connect verzögert: bei jedem _on_patch_changed ruft
            der Bridge `refresh_module_track_map()` auf, und beim ersten
            Saga.Magic-Instanz-Add sollte der rust_engine_bridge schon
            stehen (Audio-Engine ist beim FLUX-Tab-Open meist fertig).
            """
            ps = self._project_service
            if ps is None:
                return
            try:
                ae = getattr(ps, "audio_engine", None)
                if ae is None:
                    # ServiceContainer-Pfad: project_service.ctx.audio_engine
                    ctx = getattr(ps, "ctx", None)
                    if ctx is not None:
                        ae = getattr(ctx, "audio_engine", None)
            except Exception:
                ae = None

            try:
                from pydaw.services.saga_audio_bridge import (
                    get_saga_audio_bridge,
                )
                bridge = get_saga_audio_bridge()
                bridge.bind(
                    audio_engine=ae,
                    project_service=ps,
                    flux_main_widget=self,
                )
                # Erste Modul-Track-Map sofort aufbauen
                bridge.refresh_module_track_map()
                logger.debug(
                    "[FLUX-UI] saga audio bridge initialized "
                    "(audio_engine=%s)", "yes" if ae else "deferred",
                )
            except Exception as e:
                logger.debug(
                    "[FLUX-UI] _setup_saga_audio_bridge failed: %s", e
                )

        def _on_param_changed(self, module_id: str, param: str, value: float) -> None:
            """v0.0.21.184 (F-1.1.5): Knob-Drehung → Rust-Engine.

            Wird vom PropertiesPanel emittiert. Wir senden ein einzelnes
            FluxSetModuleParam-IPC anstatt den ganzen Patch zu re-syncen
            — das ist drag-rate-tauglich (~ms-Latenz) und produziert
            keine IPC-Bursts.

            v0.0.21.189: INFO-Log + defensive Patch-Modell-Aktualisierung
            (das PropertiesPanel-Slot setzt auch schon `_current_module
            .params[param]`, aber wenn `_current_module` nicht mit dem
            Patch-Modell synchron ist (z.B. nach Patch-Reload), würde
            das Update verloren gehen).
            """
            patch = self.scene.patch
            if patch is None:
                return
            # Defensive: lokales Patch-Modul direkt aus patch.modules
            # auch noch updaten — falls _current_module aus einem alten
            # Patch-Snapshot stammt, wäre dort der Wert sonst stale.
            target_mod = None
            for mod in patch.modules:
                if mod.id == module_id:
                    mod.params[param] = float(value)
                    target_mod = mod
                    break

            # v0.0.21.195: UI-Widget-Module (Frigg.*) gehen durch die
            # UiModuleBridge statt direkt an die Engine — die Engine
            # kennt sie nicht. Außerdem aktualisieren wir das embedded
            # Canvas-Widget, damit Knob im Canvas und Knob im
            # PropertiesPanel synchron bleiben.
            if (target_mod is not None
                    and target_mod.is_ui_widget()
                    and param == "value"):
                # Canvas-Widget mit-aktualisieren (ohne Echo-Loop)
                canvas_item = self.scene.module_items.get(module_id)
                widget = getattr(canvas_item, "embedded_widget", None)
                if widget is not None:
                    try:
                        # AnimatedKnob/SliderWidget/NumberBox/ToggleWidget
                        # haben alle eine set_value(emit_signal=False) API
                        if hasattr(widget, "set_value"):
                            widget.set_value(float(value), emit_signal=False)
                    except Exception as e:
                        logger.debug("[FLUX-UI] canvas widget sync failed: %s", e)
                # Bridge: dispatcht an alle DSP-Ziele
                try:
                    from pydaw.services.ui_module_bridge import (
                        get_ui_module_bridge,
                    )
                    get_ui_module_bridge().handle_ui_value_changed(
                        patch, module_id, float(value),
                    )
                except Exception as e:
                    logger.debug(
                        "[FLUX-UI] ui-bridge dispatch failed: %s", e,
                    )
                self.patch_modified.emit()
                return

            # v0.0.21.203: Saga.Magic-Module sind Python-only — KEIN
            # set_module_param an die Rust-Engine (würde nur ignoriert
            # bzw. zu einem Warning im Engine-Log führen). Stattdessen
            # zum SagaRendererProxy schicken, damit die Visualisierung
            # live auf Knob-Drehungen reagiert. Der Canvas-ModuleItem
            # bleibt durch den 20-Hz-Tick eh aktuell.
            if (target_mod is not None
                    and str(target_mod.god) == "Saga"
                    and str(target_mod.kind) == "Magic"):
                canvas_item = self.scene.module_items.get(module_id)
                if canvas_item is not None and hasattr(canvas_item, "_saga_apply_param_update"):
                    try:
                        canvas_item._saga_apply_param_update()
                    except Exception as e:
                        logger.debug("[FLUX-SAGA] apply param update failed: %s", e)
                self.patch_modified.emit()
                return

            try:
                from pydaw.services.flux_rust_sync import get_flux_rust_sync
                get_flux_rust_sync().set_module_param(
                    patch.id, module_id, param, float(value)
                )
            except Exception as e:
                logger.info("[FLUX-UI] param resync failed: %s", e)
            # v0.0.21.190 — D-2: INFO→DEBUG, da Anno's v.189-Live-Test
            # bestätigt hat dass der UI-Pfad zuverlässig feuert. Bei
            # 60+ Hz Knob-Drehrate würde das Log spammen. Die neue
            # Engine-Diagnose `[FLUX-RUST] param: ... (mod_name) ...`
            # liefert die entscheidende Info (welcher Modul-Typ getroffen wird)
            # auf einer einzigen Log-Zeile — der Python-Vorlauf ist
            # redundant geworden.
            logger.debug(
                "[FLUX-UI] param changed: patch=%s mod=%s %s=%g",
                str(patch.id)[:16], str(module_id)[:16], param, value,
            )
            # Patch-Param ist auch dirty → Save-State signalisieren
            self.patch_modified.emit()

        def _on_param_str_changed(self, module_id: str, param: str, value: str) -> None:
            """v0.0.21.244: String-Param-Änderung (Sampler.file_path etc.).

            Im Gegensatz zu numerischen Params gehen String-Werte NICHT
            via `set_module_param`-IPC an die Rust-Engine — die nimmt
            nur f32. Stattdessen wird der String im Patch-Modell
            gespeichert; der Renderer (Python-FluxAudioPreview oder
            Rust-Pendant) liest ihn beim nächsten Render aus
            `module.params[param]`.

            Anno-Use-Case: Sampler.file_path setzen via 📂 Browse-Button.
            """
            patch = self.scene.patch
            if patch is None:
                return
            target_mod = None
            for mod in patch.modules:
                if mod.id == module_id:
                    mod.params[param] = str(value)
                    target_mod = mod
                    break
            if target_mod is None:
                return
            # Status-Label-Feedback bei file_path: kurze Bestätigung
            if param == "file_path" and value:
                import os as _os
                fname = _os.path.basename(value)
                self._status_label.setText(
                    f"<span style='color:#10b981;'>📂 Sample geladen: "
                    f"{fname}</span>"
                )
            # Patch ist dirty
            self.patch_modified.emit()

        # ─── v0.0.21.230 — Living Patterns Coordination Slots ──────

        def _lp_lookup_module(self, module_id: str) -> Optional[Module]:
            """Findet das Modul-Object im aktuellen Patch."""
            patch = self.scene.patch
            if patch is None:
                return None
            for m in patch.modules:
                if m.id == module_id:
                    return m
            return None

        def _on_lp_frozen_toggle(self, module_id: str, frozen: bool) -> None:
            """Properties-Panel ❄ Toggle → Scene → Module mutieren."""
            mod = self._lp_lookup_module(module_id)
            if mod is None:
                return
            self.scene._lp_set_frozen(mod, bool(frozen))
            self.properties.refresh_lp_status()
            self._status_label.setText(
                f"❄ {mod.god}.{mod.kind}: {'frozen' if frozen else 'live'}"
            )

        def _on_lp_snapshot(self, module_id: str) -> None:
            """Properties-Panel 📸 Snapshot → alle observed_tags promoten."""
            mod = self._lp_lookup_module(module_id)
            if mod is None:
                return
            count = self.scene._lp_snapshot(mod)
            self.properties.refresh_lp_status()
            self._status_label.setText(
                f"📸 {mod.god}.{mod.kind}: {count} Patterns hinzugefügt"
            )

        def _on_lp_clear(self, module_id: str) -> None:
            """Properties-Panel 🗑 Clear → alle Patterns demoten."""
            mod = self._lp_lookup_module(module_id)
            if mod is None:
                return
            count = self.scene._lp_clear(mod)
            self.properties.refresh_lp_status()
            self._status_label.setText(
                f"🗑 {mod.god}.{mod.kind}: {count} Patterns entfernt"
            )

        def _on_lp_undo(self) -> None:
            """Properties-Panel ↶ Undo → letzte LP-Aktion rückgängig."""
            ok = self.scene.lp_undo()
            self.properties.refresh_lp_status()
            if ok:
                self._status_label.setText("↶ Undo: letzte Promote/Demote rückgängig")
            else:
                self._status_label.setText("↶ Undo: nichts mehr zum Rückgängigmachen")

        def _on_lp_redo(self) -> None:
            """Properties-Panel ↷ Redo → vorletzte LP-Aktion wiederholen."""
            ok = self.scene.lp_redo()
            self.properties.refresh_lp_status()
            if ok:
                self._status_label.setText("↷ Redo: Promote/Demote wiederhergestellt")
            else:
                self._status_label.setText("↷ Redo: nichts zum Wiederherstellen")

        def _load_demo(self) -> None:
            self.scene.set_patch(make_demo_patch())
            self._status_label.setText(self._status_text())

        def _clear_patch(self) -> None:
            self.scene.set_patch(Patch(name="Empty Patch"))
            self._status_label.setText(self._status_text())

        def _cluster_layout(self) -> None:
            """v0.0.21.181: Auto-Layout — Module nach Topologie clustern.

            Delegiert an FluxScene.cluster_layout() das die Klassifikation
            (Source/Modulator/FX/Output) und die Lerp-Animation steuert."""
            try:
                self.scene.cluster_layout()
                n = len(self.scene.module_items)
                self._status_label.setText(
                    f"⌗ Cluster: {n} Module nach Topologie angeordnet"
                )
            except Exception as e:
                logger.exception("Cluster-Layout fehlgeschlagen")
                self._status_label.setText(f"⚠ Cluster-Fehler: {e}")

        def _toggle_pulses(self) -> None:
            timer = self.scene._pulse_timer
            if self._pulses_running:
                timer.stop()
                self._btn_pulse.setText("▶ Pulses")
            else:
                timer.start(50)
                self._btn_pulse.setText("⏸ Pulses")
            self._pulses_running = not self._pulses_running

        # ─── Mini-F-1: Test-Play (lokales Preview) ────────────────────

        def _test_play(self) -> None:
            """Rendere den aktuellen Patch und spiele ihn lokal über sounddevice.

            Defensiv: Wenn sounddevice oder numpy fehlt, zeigt das Status-Label
            eine klare Fehlermeldung statt zu crashen.
            """
            try:
                from pydaw.flux.audio_preview import get_preview
                preview = get_preview()
            except Exception as e:
                self._status_label.setText(
                    f"<span style='color:#ef4444;'>⚠ FLUX-Preview-Fehler: {e}</span>"
                )
                return
            ok, msg = preview.play_patch(self.scene.patch, duration_sec=2.0)
            color = "#10b981" if ok else "#ef4444"
            symbol = "✓" if ok else "⚠"
            self._status_label.setText(
                f"<span style='color:{color};'>{symbol} {msg}</span>"
            )

        def _test_stop(self) -> None:
            """Stoppt das laufende Test-Playback."""
            try:
                from pydaw.flux.audio_preview import get_preview
                get_preview().stop()
                self._status_label.setText("■ Test-Play gestoppt")
            except Exception:
                pass

        def _diagnose_patch(self) -> None:
            """v0.0.21.241/.242: Patch-Diagnose mit Live-Activity-Check.

            v.241: Statische Diagnose (kein Audio-Render).
            v.242: Plus optional Live-Activity-Check via Probe-Render
                   um echte stumm-Module zu finden — Anno's Bug-Tool.

            Scant den aktuellen Patch auf häufige „stumme Oszi"-
            Probleme und zeigt ein Dialog mit Befunden + Fix-Hints.
            Wenn alles ok ist → Status-Label „Patch sieht gut aus".
            """
            try:
                from pydaw.flux.diagnostics import (
                    diagnose_patch, format_diagnosis_full,
                )
            except Exception as e:
                self._status_label.setText(
                    f"<span style='color:#ef4444;'>⚠ Diagnose nicht "
                    f"verfügbar: {e}</span>"
                )
                return
            # v.242: Audio-Preview für Live-Activity-Check übergeben.
            # Wenn die Preview nicht erreichbar ist, fällt diagnose_patch
            # auf statische Diagnose zurück (audio_preview=None).
            audio_preview = None
            try:
                from pydaw.flux.audio_preview import get_preview
                audio_preview = get_preview()
            except Exception:
                pass
            try:
                diags = diagnose_patch(self.scene.patch,
                                        audio_preview=audio_preview)
            except Exception as e:
                self._status_label.setText(
                    f"<span style='color:#ef4444;'>⚠ Diagnose-Fehler: "
                    f"{e}</span>"
                )
                logger.exception("[FLUX] diagnose_patch crashed")
                return
            if not diags:
                self._status_label.setText(
                    "<span style='color:#10b981;'>✓ Patch sieht gut aus "
                    "— keine offensichtlichen Probleme</span>"
                )
                return
            # Dialog mit allen Befunden
            try:
                from PyQt6.QtWidgets import QMessageBox
                msg = QMessageBox(self.window() if hasattr(self, 'window') else None)
                n_err = sum(1 for d in diags if d.severity == 'error')
                n_warn = sum(1 for d in diags if d.severity == 'warning')
                if n_err > 0:
                    msg.setIcon(QMessageBox.Icon.Critical)
                    title = f"FLUX-Diagnose: {n_err} Fehler"
                else:
                    msg.setIcon(QMessageBox.Icon.Warning)
                    title = f"FLUX-Diagnose: {n_warn} Warnung(en)"
                msg.setWindowTitle(title)
                msg.setText(format_diagnosis_full(diags))
                msg.setStandardButtons(QMessageBox.StandardButton.Ok)
                msg.exec()
            except Exception as e:
                # Falls QMessageBox nicht klappt: nur Status-Label
                logger.warning("[FLUX] QMessageBox failed: %s", e)
            # Status-Label kurz-Zusammenfassung
            try:
                from pydaw.flux.diagnostics import format_diagnosis_summary
                summary = format_diagnosis_summary(diags, max_lines=1)
                color = "#ef4444" if any(d.severity == 'error' for d in diags) else "#fbbf24"
                self._status_label.setText(
                    f"<span style='color:{color};'>{summary}</span>"
                )
            except Exception:
                pass

        def _smart_connect_to_master(self) -> None:
            """v0.0.21.242: One-Click-Fix für orphan-Oszi-Patches.

            Anno-Use-Case: „14 oszilatoren sind stumm" — nach
            Bug-Triage v.241 wahrscheinlichste Ursache: User hat
            Oszis auf Canvas gezogen, aber die Connections zum Master
            vergessen. Dieser Helper findet alle orphan-Oszis (deren
            audio_out keine Verbindung zum Master hat) und verbindet
            sie direkt mit MasterOut.audio_in_l + audio_in_r.

            Wenn kein Heimdall.MasterOut im Patch existiert, wird einer
            hinzugefügt (rechts neben dem rechtesten Oszi).

            NICHTS-KAPUTT: Bestehende Connections bleiben unverändert.
            Es werden NUR neue Connections hinzugefügt. User kann mit
            Strg+Z jede unerwünschte Connection wieder rückgängig
            machen (sofern Undo unterstützt — sonst manuell entfernen).
            """
            try:
                from pydaw.flux.module_library import make_module
                from pydaw.flux.patch_model import Connection
                from pydaw.flux.diagnostics import (
                    _is_oscillator, _has_audio_path_to_master,
                )
            except Exception as e:
                self._status_label.setText(
                    f"<span style='color:#ef4444;'>⚠ Smart-Connect "
                    f"nicht verfügbar: {e}</span>"
                )
                return
            patch = self.scene.patch
            # 1) MasterOut finden oder erstellen
            master = next(
                (m for m in patch.modules
                 if m.god == 'Heimdall' and m.kind == 'MasterOut'),
                None,
            )
            added_master = False
            if master is None:
                master = make_module('Heimdall', 'MasterOut')
                # Position: rechts vom rechtesten existierenden Modul
                if patch.modules:
                    max_x = max((m.position[0] for m in patch.modules),
                                default=0.0)
                    max_y = sum(m.position[1] for m in patch.modules) / \
                        max(1, len(patch.modules))
                    master.position = (max_x + 250.0, max_y)
                else:
                    master.position = (700.0, 200.0)
                patch.add_module(master)
                added_master = True
            # 2) Orphan-Oszis identifizieren
            orphans: list = []
            for m in patch.modules:
                if not _is_oscillator(m):
                    continue
                # Hat das Modul überhaupt einen audio_out-Output?
                has_audio_out = any(p.name == 'audio_out' for p in m.outputs)
                if not has_audio_out:
                    continue
                if not _has_audio_path_to_master(patch, master, m.id):
                    orphans.append(m)
            if not orphans:
                if added_master:
                    self._status_label.setText(
                        "<span style='color:#10b981;'>✓ MasterOut "
                        "hinzugefügt (keine orphan-Oszis gefunden)</span>"
                    )
                else:
                    self._status_label.setText(
                        "<span style='color:#10b981;'>✓ Alle Oszis sind "
                        "bereits zum Master verbunden — nichts zu tun</span>"
                    )
                # Patch-Mutation triggern damit View aktualisiert wird
                if hasattr(self.scene, 'rebuild_from_patch'):
                    try:
                        self.scene.rebuild_from_patch()
                    except Exception:
                        pass
                return
            # 3) Connections hinzufügen — jeder orphan zu Master.audio_in_l + audio_in_r
            n_added = 0
            for osc in orphans:
                # audio_in_l
                patch.add_connection(Connection(
                    source_module=osc.id, source_port='audio_out',
                    target_module=master.id, target_port='audio_in_l',
                ))
                # audio_in_r
                patch.add_connection(Connection(
                    source_module=osc.id, source_port='audio_out',
                    target_module=master.id, target_port='audio_in_r',
                ))
                n_added += 1
            # 4) Scene rebuild damit cables visible werden
            if hasattr(self.scene, 'rebuild_from_patch'):
                try:
                    self.scene.rebuild_from_patch()
                except Exception as e:
                    logger.warning("[FLUX] scene rebuild after Smart-Connect failed: %s", e)
            # 5) Status-Feedback
            extra = ' + MasterOut hinzugefügt' if added_master else ''
            self._status_label.setText(
                f"<span style='color:#10b981;'>🔗 Smart-Connect: "
                f"{n_added} Oszi(s) zum Master verbunden{extra}</span>"
            )

        # ─── v0.0.21.197 V-1: FLUX-Vault Save/Load ──────────────────

        def _vault_save(self) -> None:
            """Öffnet den Vault-Save-Dialog mit dem aktuellen Patch.

            Das eigentliche Save geschieht hier, NICHT im Dialog —
            der Dialog liefert nur die Metadaten zurück; wir verbinden
            sie hier mit dem Patch-Dict und delegieren an FluxVaultDB.

            v0.0.21.198 Hotfix: User-Patches bekommen IMMER eine neue
            Vault-ID — wir versuchen NIE einen Sacred-Factory-Eintrag
            zu überschreiben (der Factory-Schutz im DB-Service würde es
            zwar abweisen, aber Klick-Verwirrung beim User entstehen
            lassen).
            """
            try:
                from pydaw.flux.vault_dialog import VaultSaveDialog
                from pydaw.services.flux_vault_db import get_flux_vault
            except Exception as e:
                self._status_label.setText(
                    f"<span style='color:#ef4444;'>⚠ Vault nicht verfügbar: {e}</span>"
                )
                logger.exception("vault import failed")
                return

            if VaultSaveDialog is None:
                self._status_label.setText(
                    "<span style='color:#ef4444;'>⚠ Vault-Dialog: PyQt6 fehlt</span>"
                )
                return

            patch = self.scene.patch
            initial_name = patch.name if patch.name and patch.name != "Untitled Patch" else ""

            dlg = VaultSaveDialog(
                parent=self,
                initial_name=initial_name,
                initial_description=getattr(patch, "description", ""),
                initial_style="user",
                initial_author=getattr(patch, "author", ""),
            )
            if dlg.exec() != dlg.DialogCode.Accepted:
                self._status_label.setText("ℹ Vault-Save abgebrochen.")
                return

            meta = getattr(dlg, "metadata", None)
            if not meta:
                return

            try:
                vault = get_flux_vault()
                vault.ensure_loaded()
                # Patch-Name auch im Modell aktualisieren (User hat ihn hier
                # neu gewählt) — so behält die Toolbar-Anzeige Konsistenz.
                patch.name = meta["name"]
                if meta.get("description") is not None:
                    patch.description = meta["description"]
                # Save mit None als patch_id → DB erzeugt neue vp_-ID.
                # Wir respektieren patch_id NUR wenn der User explizit
                # einen update-Modus angefragt hat (existing_patch_id im
                # VaultSaveDialog) — derzeit nicht exposed, also immer None.
                pid = vault.save_patch(
                    patch_dict=patch.to_dict(),
                    name=meta["name"],
                    description=meta.get("description", ""),
                    author=meta.get("author", ""),
                    tags=meta.get("tags") or [],
                    style=meta.get("style", ""),
                    patch_id=meta.get("patch_id"),
                )
            except Exception as e:
                self._status_label.setText(
                    f"<span style='color:#ef4444;'>⚠ Vault-Save fehlgeschlagen: {e}</span>"
                )
                logger.exception("vault save_patch failed")
                return

            logger.info("[FLUX-Vault] saved patch '%s' as %s",
                        meta["name"], pid)
            self._status_label.setText(
                f"<span style='color:#10b981;'>💾 Vault: '{meta['name']}' "
                f"gespeichert ({pid})</span>"
            )

        def _vault_load(self) -> None:
            """Öffnet den Vault-Load-Dialog und lädt den ausgewählten Patch.

            v0.0.21.198 Hotfix: Der geladene Patch wird über
            ``FluxPatchService.add()`` registriert UND der aktuellen Track
            via ``assign_to_track()`` zugewiesen. Sonst überschreibt der
            Per-Track-Sync (v.171) beim nächsten Track-Wechsel den
            geladenen Patch mit dem alten Demo-Patch wieder.

            Außerdem: der Vault-Patch bekommt eine **frische ID**
            (`Patch.from_dict()` würde die DB-ID übernehmen — Sacred-
            Factory-IDs wie `factory_sacred_12` sind aber nicht eindeutig
            pro Track-Instanz; mehrfaches Laden würde zu Konflikten im
            FluxPatchService führen).
            """
            try:
                from pydaw.flux.vault_dialog import VaultLoadDialog
                from pydaw.services.flux_vault_db import get_flux_vault
                from pydaw.flux.patch_model import Patch
                from pydaw.services.flux_patch_service import (
                    get_flux_patch_service,
                )
            except Exception as e:
                self._status_label.setText(
                    f"<span style='color:#ef4444;'>⚠ Vault nicht verfügbar: {e}</span>"
                )
                logger.exception("vault import failed")
                return

            if VaultLoadDialog is None:
                self._status_label.setText(
                    "<span style='color:#ef4444;'>⚠ Vault-Dialog: PyQt6 fehlt</span>"
                )
                return

            dlg = VaultLoadDialog(parent=self)
            if dlg.exec() != dlg.DialogCode.Accepted:
                self._status_label.setText("ℹ Vault-Load abgebrochen.")
                return

            pid = getattr(dlg, "selected_patch_id", None)
            if not pid:
                return

            try:
                vault = get_flux_vault()
                patch_dict = vault.load_patch(pid)
            except Exception as e:
                self._status_label.setText(
                    f"<span style='color:#ef4444;'>⚠ Vault-Load fehlgeschlagen: {e}</span>"
                )
                logger.exception("vault load_patch failed")
                return

            if patch_dict is None:
                self._status_label.setText(
                    f"<span style='color:#ef4444;'>⚠ Patch {pid} nicht gefunden</span>"
                )
                return

            # ID frischen damit FluxPatchService keine Kollision mit
            # vorherigen Loads bekommt (Factory-IDs wie factory_sacred_12
            # sind sonst überall die gleichen).
            from pydaw.flux.patch_model import _new_id
            patch_dict = dict(patch_dict)
            patch_dict["id"] = _new_id("patch")

            try:
                patch = Patch.from_dict(patch_dict)
            except Exception as e:
                self._status_label.setText(
                    f"<span style='color:#ef4444;'>⚠ Patch-Parse fehlgeschlagen: {e}</span>"
                )
                logger.exception("Patch.from_dict failed")
                return

            # v.198 Hotfix: Patch in den FluxPatchService registrieren
            # und der aktuellen Track zuweisen, sonst geht er beim
            # Track-Wechsel verloren.
            project = self._get_project()
            track = self._get_current_track()
            svc = None
            try:
                svc = get_flux_patch_service()
            except Exception as e:
                logger.warning("[FLUX-Vault] FluxPatchService nicht verfügbar: %s", e)

            if svc is not None and project is not None and track is not None:
                try:
                    # Alten Track-Patch (falls einer existiert) entfernen,
                    # damit er nicht in der Engine verwaist liegt.
                    old_pid = str(getattr(track, "flux_patch_id", "") or "")
                    if old_pid and old_pid != patch.id:
                        try:
                            svc.remove(old_pid, project)
                        except Exception as e:
                            logger.debug("[FLUX-Vault] old patch remove failed: %s", e)
                    # Neuen Patch registrieren + zuweisen
                    svc.add(patch)
                    svc.assign_to_track(project, str(track.id), patch.id)
                    # Track-plugin_type sicherheitshalber auf 'flux' setzen
                    try:
                        if str(getattr(track, "plugin_type", "") or "").lower() != "flux":
                            track.plugin_type = "flux"
                    except Exception:
                        pass
                    logger.info(
                        "[FLUX-Vault] patch '%s' (%s) → track '%s' assigned",
                        patch.name, patch.id, getattr(track, "id", "?"),
                    )
                except Exception as e:
                    logger.exception("[FLUX-Vault] track assignment failed: %s", e)

            self.scene.set_patch(patch)
            logger.info("[FLUX-Vault] loaded patch '%s' (vault-id=%s, new-id=%s)",
                        patch.name, pid, patch.id)
            self._status_label.setText(
                f"<span style='color:#3df0e0;'>📂 Vault: '{patch.name}' geladen</span>"
            )
            # Track-Label refreshen damit der neue Patch-Name sichtbar wird
            try:
                if track is not None:
                    self._refresh_track_label(track, patch, "active")
            except Exception:
                pass
            # Project-Service über Patch-Update informieren (UI-Refresh,
            # Save-Dirty-Flag)
            try:
                if hasattr(self._project_service, "_emit_changed"):
                    self._project_service._emit_changed()
            except Exception:
                pass
            try:
                self.patch_modified.emit()
            except Exception:
                pass

        # ─── DAW-Integration ──────────────────────────────────────

        def get_patch(self) -> Patch:
            """Aktueller Patch — für Projekt-Save."""
            return self.scene.patch

        def set_patch(self, patch: Patch) -> None:
            """Patch laden — für Projekt-Load."""
            self.scene.set_patch(patch)
            self._status_label.setText(self._status_text())

        # ─── v0.0.21.171: Per-Track-Sync ─────────────────────────────

        def _get_project(self):
            """v0.0.21.174: Robuste Projekt-Zugriffsmethode.

            ProjectService hält das Projekt unter `service.ctx.project`,
            nicht direkt als `service.project`. Ältere Versionen meines
            Codes haben das übersehen — daher findet das Resolve die
            Tracks nicht und FLUX-Aktivieren bleibt wirkungslos.

            Diese Methode versucht beides + alle plausiblen Pfade.
            """
            ps = self._project_service
            if ps is None:
                return None
            # ProjectService.ctx.project (echter Pfad)
            try:
                ctx = getattr(ps, "ctx", None)
                if ctx is not None:
                    p = getattr(ctx, "project", None)
                    if p is not None:
                        return p
            except Exception:
                pass
            # ProjectService.project (alte/Mock-Schnittstelle)
            try:
                p = getattr(ps, "project", None)
                if p is not None:
                    return p
            except Exception:
                pass
            return None

        def _resolve_active_track_id(self) -> str:
            """v0.0.21.173: Liefert die aktuell aktive Track-ID — robust.

            Versucht zuerst self._current_track_id (vom Selection-Signal),
            fällt zurück auf project_service.active_track_id (Property),
            dann auf ._selected_track_id (privates Feld), und schließlich
            auf die erste Track im Projekt wenn gar nichts gesetzt ist.

            Damit funktioniert "FLUX aktivieren" auch ohne dass der User
            erst eine Track explizit anklicken muss.
            """
            if self._current_track_id:
                return self._current_track_id
            ps = self._project_service
            if ps is None:
                return ""
            # Property bevorzugen (öffentliche API)
            for attr in ("active_track_id", "selected_track_id", "_selected_track_id"):
                try:
                    val = getattr(ps, attr, "")
                    if callable(val):
                        val = val()
                    if val:
                        return str(val)
                except Exception:
                    pass
            # Letzter Ausweg: erste Track im Projekt nehmen
            try:
                project = self._get_project()
                if project is not None:
                    tracks = getattr(project, "tracks", []) or []
                    # Erste Nicht-Master-Track finden
                    for t in tracks:
                        kind = str(getattr(t, "kind", "") or "")
                        if kind not in ("master",):
                            return str(getattr(t, "id", ""))
            except Exception:
                pass
            return ""

        def showEvent(self, event) -> None:
            """v0.0.21.173: Bei jedem Tab-Wechsel/Show den aktiven Track refreshen.

            Fängt Fälle ab wo der FLUX-Tab vor der Track-Selection geladen
            wurde (kein Selection-Event verpasst), oder wo der User eine
            andere Track aus dem Arranger wählt während der FLUX-Tab nicht
            sichtbar war.
            """
            try:
                super().showEvent(event)
            except Exception:
                pass
            if self._project_service is None:
                return
            try:
                resolved = self._resolve_active_track_id()
                if resolved and resolved != self._current_track_id:
                    self._current_track_id = resolved
                self._refresh_for_current_track()
            except Exception:
                pass

        def _on_project_signal(self) -> None:
            """v0.0.21.174: Slot für ProjectService.project_opened/project_changed.

            Wenn das Projekt NACH dem FLUX-Tab-Init geladen wird (normale
            Reihenfolge), fängt dieser Slot das ab und triggert ein
            UI-Refresh. Ohne diesen Slot bleibt der Tab in „Keine Track
            ausgewählt" weil showEvent nur beim Tab-Wechsel feuert.
            """
            if self._project_service is None:
                return
            try:
                if not self._current_track_id:
                    self._current_track_id = self._resolve_active_track_id()
                self._refresh_for_current_track()
            except Exception:
                pass

        def set_active_track(self, track_id: str) -> None:
            """Vom MainWindow gerufen wenn der User eine andere Track wählt.

            Wechselt den angezeigten Patch auf den der Track. Wenn die Track
            keinen Patch hat, wird ein leerer Hinweis-Patch gezeigt.
            """
            if self._project_service is None:
                return  # Workspace-Modus — keine Track-Bindung
            self._current_track_id = str(track_id or "")
            self._refresh_for_current_track()

        def _refresh_for_current_track(self) -> None:
            """Lädt den Patch der aktuell selektierten Track in die Scene.

            Bitwig-Grid-Modell (v0.0.21.172):
            - Wenn keine Track ausgewählt → Overlay "no_track"
            - Wenn Track plugin_type != "flux" → Overlay "other_plugin"
            - Wenn Track plugin_type == "flux" und kein Patch → auto-create
            - Wenn Track plugin_type == "flux" und Patch da → Canvas + Patch
            """
            try:
                from pydaw.services.flux_patch_service import get_flux_patch_service
                svc = get_flux_patch_service()
            except Exception:
                return
            project = self._get_project()
            if project is None or not self._current_track_id:
                self._show_overlay("no_track")
                self._refresh_track_label(None, None, "no_track")
                return

            track = self._get_current_track()
            if track is None:
                self._show_overlay("no_track")
                self._refresh_track_label(None, None, "no_track")
                return

            plugin_type = str(getattr(track, "plugin_type", "") or "").lower()
            track_name = str(getattr(track, "name", "") or "Track")

            if plugin_type and plugin_type != "flux":
                # Track nutzt anderes Instrument — Overlay
                self._show_overlay("other_plugin", track_name, plugin_type)
                self._refresh_track_label(track, None, "other_plugin")
                self._status_label.setText(self._status_text())
                return

            if plugin_type != "flux":
                # Kein Instrument → Overlay
                self._show_overlay("no_instrument", track_name)
                self._refresh_track_label(track, None, "no_instrument")
                self._status_label.setText(self._status_text())
                return

            # plugin_type == "flux" → Canvas zeigen
            patch = svc.patch_for_track(project, self._current_track_id)
            if patch is None:
                # FLUX-Track ohne Patch → automatisch einen anlegen
                patch = svc.create_for_track(project, self._current_track_id, "demo")
                if patch is not None:
                    self._status_label.setText(
                        "<span style='color:#10b981;'>"
                        "✓ FLUX-Patch automatisch für Track erstellt</span>"
                    )
            if patch is not None:
                self.scene.set_patch(patch)
                self._refresh_track_label(track, patch, "active")
                self._hide_overlay()  # Canvas zeigen
            else:
                self._show_overlay("no_instrument", track_name)
                self._refresh_track_label(track, None, "error")
            self._status_label.setText(self._status_text())

            # v0.0.21.209: Saga-Audio-Bridge: Track-Wechsel = Modul-Map neu
            # aufbauen (anderer Patch = andere Saga.Magic-Module).
            try:
                from pydaw.services.saga_audio_bridge import (
                    get_saga_audio_bridge,
                )
                # bind() ist idempotent — re-attempts den Connect falls
                # rust_engine_bridge beim init noch nicht da war.
                bridge = get_saga_audio_bridge()
                bridge.bind(
                    project_service=self._project_service,
                )
                bridge.refresh_module_track_map()
            except Exception as e:
                logger.debug(
                    "[FLUX-UI] saga bridge track-switch refresh skipped: %s",
                    e,
                )

        def _get_current_track(self):
            project = self._get_project()
            if project is None or not self._current_track_id:
                return None
            for t in getattr(project, "tracks", []) or []:
                if str(getattr(t, "id", "")) == self._current_track_id:
                    return t
            return None

        def _refresh_track_label(self, track, patch, mode: str = "active") -> None:
            """Aktualisiert den Toolbar-Header mit klarer Botschaft je nach Modus.

            Modi (v0.0.21.172 Bitwig-Grid-Modell):
                no_track       — keine Track gewählt
                other_plugin   — Track nutzt VST/SF2/CLAP, FLUX inaktiv
                no_instrument  — Track hat kein Instrument zugewiesen
                active         — Track ist FLUX-Track mit Patch
                error          — irgendwas hat nicht geklappt
            """
            if track is None or mode == "no_track":
                self._track_label.setText(
                    "<span style='color:#8b949e;'>"
                    "Keine Track ausgewählt — klick im Arranger eine Track an"
                    "</span>"
                )
                # v0.0.21.173: Button trotzdem aktiv — Auto-Resolve fängt's
                self._btn_create.setText("⚙ FLUX für aktive Track aktivieren")
                self._btn_create.setEnabled(self._project_service is not None)
                self._btn_create.setToolTip(
                    "Aktiviert FLUX als Instrument. Wenn keine Track explizit "
                    "gewählt ist, wird die erste passende Track im Projekt verwendet."
                )
                self._btn_unlink.setEnabled(False)
                return

            track_name = str(getattr(track, "name", "") or "Track")

            if mode == "other_plugin":
                plugin_type = str(getattr(track, "plugin_type", "") or "").upper()
                self._track_label.setText(
                    f"<span style='color:#3df0e0;'>Track:</span> "
                    f"<span style='color:#e6edf3;'>{track_name}</span>"
                    f" · "
                    f"<span style='color:#f59e0b;'>nutzt {plugin_type}</span>"
                    f" · "
                    f"<span style='color:#8b949e;'>FLUX ist hier <b>nicht aktiv</b></span>"
                )
                self._btn_create.setText("⚙ Auf FLUX umschalten")
                self._btn_create.setEnabled(True)
                self._btn_create.setToolTip(
                    f"WARNUNG: Wechselt diese Track von {plugin_type} auf FLUX.\n"
                    f"Das alte Instrument wird entfernt."
                )
                self._btn_unlink.setEnabled(False)
                return

            if mode == "no_instrument":
                self._track_label.setText(
                    f"<span style='color:#3df0e0;'>Track:</span> "
                    f"<span style='color:#e6edf3;'>{track_name}</span>"
                    f" · "
                    f"<span style='color:#8b949e;'>kein Instrument</span>"
                )
                self._btn_create.setText("⚙ FLUX aktivieren")
                self._btn_create.setEnabled(True)
                self._btn_create.setToolTip(
                    "Aktiviert FLUX als Instrument für diese Track. "
                    "Erstellt automatisch einen Demo-Patch."
                )
                self._btn_unlink.setEnabled(False)
                return

            # mode == "active"
            if patch is None:
                self._track_label.setText(
                    f"<span style='color:#3df0e0;'>Track:</span> "
                    f"<span style='color:#e6edf3;'>{track_name}</span>"
                    f" · "
                    f"<span style='color:#ef4444;'>FLUX aktiv, aber kein Patch</span>"
                )
                self._btn_create.setText("⊕ Patch erstellen")
                self._btn_create.setEnabled(True)
                self._btn_unlink.setEnabled(False)
                return

            from pydaw.services.flux_patch_service import get_flux_patch_service
            svc = get_flux_patch_service()
            project = self._get_project()
            shared_count = len(svc.tracks_using_patch(project, patch.id))
            shared_note = (f" · <span style='color:#f472b6;'>"
                          f"geteilt mit {shared_count - 1} weiterer Track</span>"
                          if shared_count > 1 else "")
            self._track_label.setText(
                f"<span style='color:#3df0e0;'>Track:</span> "
                f"<span style='color:#e6edf3;'>{track_name}</span>"
                f" · "
                f"<span style='color:#10b981;'>⚡ FLUX aktiv</span>"
                f" · "
                f"<span style='color:#10b981;'>Patch:</span> "
                f"<span style='color:#e6edf3;'>{patch.name}</span>"
                f"{shared_note}"
            )
            self._btn_create.setText("⊕ Neuer Patch")
            self._btn_create.setEnabled(True)
            self._btn_unlink.setText("⚠ FLUX entfernen")
            self._btn_unlink.setToolTip(
                "Entfernt FLUX als Instrument von dieser Track. "
                "Der Patch bleibt im Projekt erhalten."
            )
            self._btn_unlink.setEnabled(True)

        def _create_patch_for_track(self) -> None:
            """⊕ FLUX aktivieren / Patch erstellen Button.

            Bitwig-Grid-Modell (v0.0.21.172):
            - Wenn Track keinen plugin_type hat → setzt plugin_type=flux + Patch
            - Wenn Track plugin_type=vst3/sf2/etc. hat → fragt User vorher
            - Wenn Track schon plugin_type=flux + Patch → erstellt NEUEN Patch

            v0.0.21.173: Fallback auf Auto-Detection — wenn keine Track
            explizit selektiert wurde, nimm die aktive aus dem ProjectService.
            """
            if self._project_service is None:
                self._status_label.setText(
                    "<span style='color:#ef4444;'>"
                    "⚠ Projekt-Service nicht verfügbar</span>"
                )
                return

            # v0.0.21.173: Auto-Detection wenn nichts explizit gewählt
            if not self._current_track_id:
                resolved = self._resolve_active_track_id()
                if resolved:
                    self._current_track_id = resolved
                else:
                    self._status_label.setText(
                        "<span style='color:#ef4444;'>"
                        "⚠ Keine Track im Projekt — erst eine Track anlegen</span>"
                    )
                    return
            try:
                from pydaw.services.flux_patch_service import get_flux_patch_service
                svc = get_flux_patch_service()
                project = self._get_project()
                track = self._get_current_track()
                if track is None:
                    return

                current_type = str(getattr(track, "plugin_type", "") or "").lower()

                # Fall A: Track nutzt anderes Plugin → User-Bestätigung
                if current_type and current_type != "flux":
                    try:
                        from PyQt6.QtWidgets import QMessageBox
                        reply = QMessageBox.question(
                            self,
                            "FLUX aktivieren?",
                            f"Diese Track nutzt aktuell <b>{current_type.upper()}</b> "
                            f"als Instrument.<br><br>"
                            f"Wenn du FLUX aktivierst, wird {current_type.upper()} "
                            f"als Instrument <b>entfernt</b> (FX-Chain bleibt erhalten).<br><br>"
                            f"FLUX wirklich aktivieren?",
                            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                            QMessageBox.StandardButton.No,
                        )
                        if reply != QMessageBox.StandardButton.Yes:
                            return
                    except Exception:
                        pass

                # Plugin-Type auf FLUX umstellen
                try:
                    track.plugin_type = "flux"
                except Exception:
                    pass

                # Patch erstellen wenn noch keiner da ist
                existing_pid = str(getattr(track, "flux_patch_id", "") or "")
                if existing_pid and svc.get(existing_pid) is not None:
                    # Schon ein Patch vorhanden — bei "Neuer Patch"-Klick einen frischen anlegen
                    patch = svc.create_for_track(project, self._current_track_id, "demo")
                else:
                    patch = svc.create_for_track(project, self._current_track_id, "demo")

                if patch is None:
                    self._status_label.setText(
                        "<span style='color:#ef4444;'>⚠ Patch konnte nicht erzeugt werden</span>"
                    )
                    return

                self._refresh_for_current_track()
                self._status_label.setText(
                    f'<span style="color:#10b981;">✓ FLUX aktiv: „{patch.name}"</span>'
                )
                self.patch_modified.emit()

                # Project-Service über Track-Update informieren (für UI-Refresh)
                try:
                    if hasattr(self._project_service, "_emit_changed"):
                        self._project_service._emit_changed()
                except Exception:
                    pass
            except Exception as e:
                self._status_label.setText(
                    f"<span style='color:#ef4444;'>⚠ Fehler: {e}</span>"
                )

        def _unlink_patch_from_track(self) -> None:
            """⚠ FLUX entfernen Button.

            Bitwig-Grid-Modell (v0.0.21.172):
            - Setzt plugin_type zurück auf None (Track hat dann kein Instrument)
            - Hebt flux_patch_id-Bindung auf
            - Patch bleibt im Projekt — Anno kann ihn anderer Track zuweisen
            """
            if self._project_service is None or not self._current_track_id:
                return
            try:
                from pydaw.services.flux_patch_service import get_flux_patch_service
                svc = get_flux_patch_service()
                project = self._get_project()
                track = self._get_current_track()
                if track is None:
                    return
                # Patch-Bindung lösen
                svc.assign_to_track(project, self._current_track_id, "")
                # plugin_type von "flux" zurück auf None — wenn jemand anders
                # den Slot belegt, ändern wir nichts
                try:
                    if str(getattr(track, "plugin_type", "") or "").lower() == "flux":
                        track.plugin_type = None
                except Exception:
                    pass
                self._refresh_for_current_track()
                self._status_label.setText(
                    "<span style='color:#f59e0b;'>"
                    "⚠ FLUX von Track entfernt — Patch bleibt im Projekt</span>"
                )
                self.patch_modified.emit()
                try:
                    if hasattr(self._project_service, "_emit_changed"):
                        self._project_service._emit_changed()
                except Exception:
                    pass
            except Exception:
                pass

else:
    class FluxMainWidget:  # type: ignore
        """Stub falls PyQt6 fehlt."""
        def __init__(self, *args, **kwargs):
            raise ImportError("PyQt6 nicht verfügbar — FluxMainWidget kann nicht erstellt werden")


__all__ = ["FluxMainWidget"]
