"""session_heatmap_widget.py — Session Activity Heatmap (Phase T14).

v0.0.20.901 — Phase T14 der TIME_TRAVEL_ROADMAP.

Visualisiert die Session-Aktivitaet als Heatmap:
- Horizontale Achse = Zeit (Session-Dauer)
- Vertikale Achse = Tracks
- Farbe = Aktivitaetsdichte (dunkel=wenig, hell=viel)
- Hover → Tooltip mit Event-Details
- Klick → springt zum Zeitpunkt im Time-Travel Panel
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

log = logging.getLogger(__name__)

try:
    from PyQt6.QtCore import Qt, pyqtSignal, QRectF, QPointF, QTimer
    from PyQt6.QtGui import (
        QPainter, QColor, QPen, QBrush, QFont, QLinearGradient,
        QMouseEvent,
    )
    from PyQt6.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QLabel, QSizePolicy,
        QToolTip, QScrollArea,
    )
    _QT = True
except ImportError:
    _QT = False


def _heat_color(intensity: float) -> QColor:
    """Map 0.0-1.0 intensity to a heatmap color (dark blue → red → yellow)."""
    if not _QT:
        return None
    t = max(0.0, min(1.0, intensity))
    if t < 0.25:
        # Dark blue → blue
        r, g, b = 20, 20, int(60 + t * 4 * 160)
    elif t < 0.5:
        # Blue → cyan
        s = (t - 0.25) * 4
        r, g, b = 20, int(60 + s * 180), 220
    elif t < 0.75:
        # Cyan → orange
        s = (t - 0.5) * 4
        r, g, b = int(60 + s * 195), int(240 - s * 80), int(220 - s * 180)
    else:
        # Orange → yellow/white
        s = (t - 0.75) * 4
        r, g, b = 255, int(160 + s * 95), int(40 + s * 160)
    return QColor(min(255, r), min(255, g), min(255, b))


if _QT:

    class SessionHeatmapWidget(QWidget):
        """Session activity heatmap — shows event density per track over time."""

        timestamp_clicked = pyqtSignal(int)  # timestamp_ms

        def __init__(self, parent=None):
            super().__init__(parent)
            self.setMinimumSize(300, 120)
            self.setMouseTracking(True)
            self.setSizePolicy(QSizePolicy.Policy.Expanding,
                               QSizePolicy.Policy.Expanding)

            self._data: Dict[str, List[int]] = {}  # track_id -> [count per bucket]
            self._track_names: Dict[str, str] = {}
            self._bucket_ms: int = 10000
            self._range_start_ms: int = 0
            self._range_end_ms: int = 0
            self._n_buckets: int = 0
            self._max_count: int = 1
            self._cursor_bucket: int = -1
            self._cursor_track: str = ""

            # Track label width
            self._label_w = 80
            self._row_h = 20

        def set_data(self, track_density: Dict[str, List[int]],
                       track_names: Dict[str, str],
                       bucket_ms: int,
                       range_start_ms: int, range_end_ms: int) -> None:
            """Set heatmap data.

            track_density: {track_id: [event_count_per_bucket, ...]}
            track_names: {track_id: display_name}
            """
            self._data = track_density
            self._track_names = track_names
            self._bucket_ms = max(1, bucket_ms)
            self._range_start_ms = range_start_ms
            self._range_end_ms = range_end_ms

            # Find max count for normalization
            self._max_count = 1
            self._n_buckets = 0
            for counts in track_density.values():
                if counts:
                    self._n_buckets = max(self._n_buckets, len(counts))
                    mc = max(counts)
                    if mc > self._max_count:
                        self._max_count = mc

            # Resize
            n_tracks = max(1, len(self._data))
            h = n_tracks * self._row_h + 30
            self.setMinimumHeight(max(80, h))
            self.update()

        def paintEvent(self, event):
            if not self._data:
                return
            p = QPainter(self)
            p.setRenderHint(QPainter.RenderHint.Antialiasing, False)
            w, h = self.width(), self.height()
            p.fillRect(0, 0, w, h, QColor(25, 25, 30))

            track_ids = sorted(self._data.keys())
            n_tracks = len(track_ids)
            if n_tracks == 0 or self._n_buckets == 0:
                p.end()
                return

            cell_w = max(1.0, (w - self._label_w) / self._n_buckets)
            row_h = self._row_h

            font = QFont("monospace", 8)
            p.setFont(font)

            for row, tid in enumerate(track_ids):
                y = row * row_h
                counts = self._data.get(tid, [])
                name = self._track_names.get(tid, tid[:8])

                # Track label
                p.setPen(QPen(QColor(170, 170, 180)))
                p.drawText(QRectF(2, y, self._label_w - 4, row_h),
                           Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignRight,
                           name[:10])

                # Heatmap cells
                for col, count in enumerate(counts):
                    cx = self._label_w + col * cell_w
                    intensity = count / max(1, self._max_count)
                    color = _heat_color(intensity) if count > 0 else QColor(30, 30, 35)
                    p.fillRect(QRectF(cx, y + 1, cell_w, row_h - 2), color)

                # Highlight hovered cell
                if tid == self._cursor_track and 0 <= self._cursor_bucket < len(counts):
                    hx = self._label_w + self._cursor_bucket * cell_w
                    p.setPen(QPen(QColor(255, 255, 255, 100), 1))
                    p.drawRect(QRectF(hx, y, cell_w, row_h))

            # Time labels at bottom
            bottom_y = n_tracks * row_h + 2
            p.setPen(QPen(QColor(120, 120, 130)))
            step = max(1, self._n_buckets // 6)
            for i in range(0, self._n_buckets, step):
                ms = self._range_start_ms + i * self._bucket_ms
                lx = self._label_w + i * cell_w
                total_s = ms // 1000
                m, s = divmod(abs(total_s), 60)
                label = f"{m}:{s:02d}"
                p.drawText(QPointF(lx, bottom_y + 12), label)

            p.end()

        def mouseMoveEvent(self, event: QMouseEvent):
            pos = event.position() if hasattr(event, 'position') else event.localPos()
            x, y = pos.x(), pos.y()

            track_ids = sorted(self._data.keys())
            row = int(y / max(1, self._row_h))
            col = int((x - self._label_w) / max(1, (self.width() - self._label_w) / max(1, self._n_buckets)))

            old_t, old_b = self._cursor_track, self._cursor_bucket

            if 0 <= row < len(track_ids) and 0 <= col < self._n_buckets:
                self._cursor_track = track_ids[row]
                self._cursor_bucket = col

                # Tooltip
                tid = self._cursor_track
                counts = self._data.get(tid, [])
                count = counts[col] if col < len(counts) else 0
                name = self._track_names.get(tid, tid[:8])
                ms = self._range_start_ms + col * self._bucket_ms
                total_s = ms // 1000
                m, s = divmod(total_s, 60)
                tip = f"{name} @ {m}:{s:02d} — {count} Events"
                QToolTip.showText(event.globalPosition().toPoint(), tip, self)
            else:
                self._cursor_track = ""
                self._cursor_bucket = -1

            if old_t != self._cursor_track or old_b != self._cursor_bucket:
                self.update()

        def mousePressEvent(self, event: QMouseEvent):
            if self._cursor_bucket >= 0:
                ms = self._range_start_ms + self._cursor_bucket * self._bucket_ms
                self.timestamp_clicked.emit(ms)

        def leaveEvent(self, event):
            self._cursor_track = ""
            self._cursor_bucket = -1
            self.update()

    # ──────────────────────────────────────────────────────────

    class SessionHeatmapPanel(QWidget):
        """Wrapper panel with title + heatmap + auto-refresh."""

        timestamp_clicked = pyqtSignal(int)

        def __init__(self, parent=None):
            super().__init__(parent)
            self._journal = None
            self._restore = None
            self._project_service = None

            self._refresh_timer = QTimer(self)
            self._refresh_timer.setInterval(5000)
            self._refresh_timer.timeout.connect(self._refresh)

            layout = QVBoxLayout(self)
            layout.setContentsMargins(4, 4, 4, 4)
            layout.setSpacing(4)

            title = QLabel("Session Heatmap")
            title.setStyleSheet("font-weight:bold; font-size:13px; color:#ccc;")
            layout.addWidget(title)

            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            self._heatmap = SessionHeatmapWidget()
            self._heatmap.timestamp_clicked.connect(self.timestamp_clicked.emit)
            scroll.setWidget(self._heatmap)
            layout.addWidget(scroll, stretch=1)

        def set_services(self, project_service=None, journal=None,
                           restore=None) -> None:
            self._project_service = project_service
            self._journal = journal
            self._restore = restore

        def showEvent(self, event):
            super().showEvent(event)
            self._refresh_timer.start()
            self._refresh()

        def hideEvent(self, event):
            super().hideEvent(event)
            self._refresh_timer.stop()

        def _refresh(self) -> None:
            if not self._journal or not self._journal.is_running:
                return
            if not self._restore:
                return

            session_id = self._journal.session_id
            current_ms = self._journal._timestamp_ms()

            # Get density per bucket
            bucket_ms = 10000  # 10s buckets
            density = self._restore.get_event_density(
                session_id, bucket_ms=bucket_ms, max_buckets=300
            )

            if not density:
                return

            # Build per-track density
            track_density: Dict[str, List[int]] = {}
            range_start = density[0]["start_ms"] if density else 0
            range_end = density[-1]["end_ms"] if density else current_ms
            n_buckets = max(1, (range_end - range_start) // bucket_ms + 1)

            # We need per-track data — get events grouped by track
            try:
                from pydaw.services.time_travel_db import TimeTravelDB
                db = TimeTravelDB.get()
                conn = db._conn()
                try:
                    rows = conn.execute(
                        """SELECT
                             track_id,
                             (timestamp_ms / ?) * ? as bucket_start,
                             COUNT(*) as cnt
                           FROM journal_events
                           WHERE session_id=? AND track_id != ''
                           GROUP BY track_id, bucket_start
                           ORDER BY track_id, bucket_start""",
                        (bucket_ms, bucket_ms, session_id),
                    ).fetchall()
                finally:
                    conn.close()

                for r in rows:
                    tid = r["track_id"]
                    bs = r["bucket_start"]
                    cnt = r["cnt"]
                    if tid not in track_density:
                        track_density[tid] = [0] * n_buckets
                    idx = (bs - range_start) // bucket_ms
                    if 0 <= idx < n_buckets:
                        track_density[tid][idx] += cnt
            except Exception:
                pass

            # Get track names
            track_names: Dict[str, str] = {}
            if self._project_service:
                try:
                    proj = self._project_service.ctx.project
                    for trk in (getattr(proj, 'tracks', []) or []):
                        tid = str(getattr(trk, 'id', ''))
                        if tid:
                            track_names[tid] = str(getattr(trk, 'name', tid[:8]))
                except Exception:
                    pass

            self._heatmap.set_data(
                track_density, track_names, bucket_ms,
                range_start, range_end,
            )

else:
    class SessionHeatmapWidget:
        def __init__(self, *a, **kw):
            pass

    class SessionHeatmapPanel:
        def __init__(self, *a, **kw):
            pass
