"""
pydaw.services.flux_vault_db — V-1 SQLite-Backend für FLUX-Patches
==================================================================

**Eingebaut in v0.0.21.197**. Spezifikation:
``PROJECT_DOCS/FLUX_GROVE_MANIFEST.md`` Sektion „FLUX Vault — Preset-System".

Ziel
----

Anno will:
* User-Patches speichern und laden (Snapshot mit Name, Tags, Beschreibung)
* Factory-Presets von „Gottesdienst bis Bach" (12 Genres × 12 Varianten)
* Speicher-effizientes Format (SQLite mit gzip-komprimierten JSON-Blobs)

V-1 (diese Version) liefert:
* SQLite-Backend mit den im Manifest spezifizierten Tabellen
* Save / Load / List / Delete / Search APIs
* 12 Sacred-Pilot-Presets als erste Style-Familie
* Time-Travel-Hook: jede Save schreibt Vorgänger-State in `patch_history`

V-2..V-4 (kommende Versionen) ergänzen:
* Bach + Ambient + Synthwave Styles (V-2 → 36 Presets)
* Restliche 9 Styles (V-3 → 144 Presets total)
* Auto-Preview-Render + Auto-Tag via Mimir (V-4)

Architektur
-----------

Pfad: ``~/.config/ChronoScaleStudio/flux_vault.db``

Tabellen:
* ``patch`` — Master-Tabelle mit Patch-Blob (gzip-JSON), Metadaten,
  optionalem Preview-Audio und Icon-SVG
* ``patch_history`` — Time-Travel-Archiv: jede Save schreibt den
  Vorgänger hier hinein, sortiert nach Snapshot-Zeitpunkt

Singleton-Pattern wie ``preset_database.py`` — eine Instanz pro Prozess,
RAM-cached für O(1)-Reads.

Nichts-Kaputt-Garantie
----------------------

* **Reine Python-Schicht** — keine Rust-Änderungen
* **Defensiv gegen fehlendes SQLite** (Standard-Library, sollte nie
  fehlen, aber Robustheit)
* **Idempotente Initialisierung** — `ensure_loaded()` mehrfach aufrufbar
* **Schema-Migration safe** — `CREATE TABLE IF NOT EXISTS`
* **Kein Auto-Schreiben** beim Start — nur explizite save_patch-Aufrufe
"""

from __future__ import annotations

import base64
import gzip
import io
import json
import logging
import sqlite3
import time
import uuid
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)


# ─── DB-Schema ────────────────────────────────────────────────────


_SCHEMA_SQL = r"""
CREATE TABLE IF NOT EXISTS patch (
    id            TEXT PRIMARY KEY,
    name          TEXT NOT NULL,
    description   TEXT NOT NULL DEFAULT '',
    author        TEXT NOT NULL DEFAULT '',
    is_factory    INTEGER NOT NULL DEFAULT 0,
    style         TEXT NOT NULL DEFAULT '',
    variant       INTEGER NOT NULL DEFAULT 0,
    tags          TEXT NOT NULL DEFAULT '[]',  -- JSON-array
    bpm           REAL,
    musical_key   TEXT NOT NULL DEFAULT '',
    created_at    TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at    TEXT NOT NULL DEFAULT (datetime('now')),
    patch_blob    BLOB NOT NULL,                -- gzip(json) Patch-Modell
    preview_wav   BLOB,                          -- 4s preview (V-4 — derzeit leer)
    icon_svg      TEXT NOT NULL DEFAULT ''       -- optionaler SVG-Thumb
);

CREATE INDEX IF NOT EXISTS idx_patch_style    ON patch(style);
CREATE INDEX IF NOT EXISTS idx_patch_variant  ON patch(style, variant);
CREATE INDEX IF NOT EXISTS idx_patch_factory  ON patch(is_factory);
CREATE INDEX IF NOT EXISTS idx_patch_name     ON patch(name);

CREATE TABLE IF NOT EXISTS patch_history (
    patch_id      TEXT NOT NULL,
    snapshot_at   TEXT NOT NULL DEFAULT (datetime('now')),
    patch_blob    BLOB NOT NULL,
    PRIMARY KEY (patch_id, snapshot_at)
);
"""


# ─── Hilfs-Funktionen ─────────────────────────────────────────────


def _gzip_json(data: dict) -> bytes:
    """Patch-Modell-Dict → gzip-komprimierte JSON-Bytes."""
    buf = io.BytesIO()
    payload = json.dumps(data, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    with gzip.GzipFile(fileobj=buf, mode="wb", compresslevel=6, mtime=0) as gz:
        gz.write(payload)
    return buf.getvalue()


def _gunzip_json(blob: bytes) -> dict:
    """Bytes → ent-gzipped JSON-Dict."""
    buf = io.BytesIO(blob)
    with gzip.GzipFile(fileobj=buf, mode="rb") as gz:
        raw = gz.read()
    return json.loads(raw.decode("utf-8"))


def _new_patch_id() -> str:
    return f"vp_{uuid.uuid4().hex[:12]}"


# ─── FluxVaultDB ──────────────────────────────────────────────────


class FluxVaultDB:
    """SQLite-backed Patch-Vault. Singleton pro Prozess.

    Usage::

        from pydaw.services.flux_vault_db import get_flux_vault
        vault = get_flux_vault()
        vault.ensure_loaded()
        vault.save_patch(my_patch_dict, name="My Pad", description="...")
        all_user = vault.list_patches(include_factory=False)
        loaded = vault.load_patch(patch_id)

    Patch-Daten gehen als ``dict`` rein und raus — die Konvertierung
    von/zu ``patch_model.Patch`` macht der Caller (Patch.from_dict /
    Patch.to_dict). So bleibt dieses Modul unabhängig vom Patch-Modell.
    """

    _instance: Optional["FluxVaultDB"] = None

    @classmethod
    def get(cls) -> "FluxVaultDB":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        # Pfad: konsistent mit preset_database.py
        self._db_path = (
            Path.home() / ".config" / "ChronoScaleStudio" / "flux_vault.db"
        )
        self._loaded = False

    # ─── Lifecycle ─────────────────────────────────────────────────

    def ensure_loaded(self) -> None:
        """DB anlegen falls nicht vorhanden, Factory-Presets seeden falls
        noch nicht da. Idempotent."""
        if self._loaded:
            return
        try:
            self._init_db()
            self._seed_factory_presets_if_empty()
            self._loaded = True
            stats = self.stats()
            logger.info(
                "[FluxVault] Ready (path=%s, %d patches, %d factory)",
                self._db_path, stats["total"], stats["factory"],
            )
        except Exception as e:
            logger.warning("[FluxVault] ensure_loaded failed: %s", e)
            # Wir bleiben unloaded — alle weiteren Aufrufe gehen
            # defensiv durch und scheitern lokal

    def _init_db(self) -> None:
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(self._db_path))
        try:
            conn.executescript(_SCHEMA_SQL)
            conn.commit()
        finally:
            conn.close()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self._db_path))
        conn.row_factory = sqlite3.Row
        return conn

    # ─── Save / Load APIs ──────────────────────────────────────────

    def save_patch(
        self,
        patch_dict: dict,
        *,
        name: str,
        description: str = "",
        author: str = "",
        tags: Optional[list[str]] = None,
        style: str = "",
        bpm: Optional[float] = None,
        musical_key: str = "",
        icon_svg: str = "",
        patch_id: Optional[str] = None,
    ) -> str:
        """Speichert oder aktualisiert einen User-Patch.

        Wenn ``patch_id`` gegeben ist und existiert, wird der vorhandene
        Eintrag überschrieben (und der alte State in `patch_history`
        archiviert). Sonst wird eine neue ID erzeugt.

        Factory-Presets werden via dieser API NICHT verändert — sie
        haben `is_factory=1` und werden vom Update-Pfad geschützt.

        Returns: die patch_id.
        """
        if not name:
            raise ValueError("save_patch: name is required")
        self.ensure_loaded()

        pid = patch_id or _new_patch_id()
        blob = _gzip_json(patch_dict)
        tags_json = json.dumps(tags or [], ensure_ascii=False)

        conn = self._connect()
        try:
            cur = conn.cursor()
            # Ist da schon ein User-Patch mit dieser ID?
            existing = cur.execute(
                "SELECT is_factory, patch_blob FROM patch WHERE id = ?",
                (pid,),
            ).fetchone()

            if existing is not None:
                if existing["is_factory"] == 1:
                    raise ValueError(
                        f"save_patch: cannot overwrite factory preset {pid}"
                    )
                # Time-Travel-Hook: alter Blob in History
                cur.execute(
                    "INSERT INTO patch_history (patch_id, snapshot_at, patch_blob) "
                    "VALUES (?, datetime('now'), ?)",
                    (pid, existing["patch_blob"]),
                )
                # UPDATE
                cur.execute(
                    """UPDATE patch
                       SET name = ?, description = ?, author = ?,
                           tags = ?, style = ?, bpm = ?, musical_key = ?,
                           updated_at = datetime('now'),
                           patch_blob = ?, icon_svg = ?
                       WHERE id = ?""",
                    (name, description, author, tags_json, style, bpm,
                     musical_key, blob, icon_svg, pid),
                )
            else:
                cur.execute(
                    """INSERT INTO patch
                       (id, name, description, author, is_factory, style,
                        variant, tags, bpm, musical_key, patch_blob, icon_svg)
                       VALUES (?, ?, ?, ?, 0, ?, 0, ?, ?, ?, ?, ?)""",
                    (pid, name, description, author, style, tags_json,
                     bpm, musical_key, blob, icon_svg),
                )
            conn.commit()
        finally:
            conn.close()
        logger.info("[FluxVault] save_patch ok: %s '%s'", pid, name)
        return pid

    def load_patch(self, patch_id: str) -> Optional[dict]:
        """Lädt einen Patch (User oder Factory) als Dict.

        Returns: das Patch-Dict (`Patch.to_dict`-Format) oder None wenn
        die ID unbekannt ist.
        """
        self.ensure_loaded()
        conn = self._connect()
        try:
            row = conn.execute(
                "SELECT patch_blob FROM patch WHERE id = ?",
                (patch_id,),
            ).fetchone()
        finally:
            conn.close()
        if row is None:
            return None
        try:
            return _gunzip_json(row["patch_blob"])
        except Exception as e:
            logger.warning("[FluxVault] load_patch decode failed for %s: %s",
                           patch_id, e)
            return None

    def delete_patch(self, patch_id: str) -> bool:
        """Löscht einen User-Patch. Factory-Presets werden geschützt.

        Returns: True wenn gelöscht, False sonst.
        """
        self.ensure_loaded()
        conn = self._connect()
        try:
            cur = conn.cursor()
            row = cur.execute(
                "SELECT is_factory FROM patch WHERE id = ?",
                (patch_id,),
            ).fetchone()
            if row is None:
                return False
            if row["is_factory"] == 1:
                logger.info(
                    "[FluxVault] delete_patch refused (factory): %s", patch_id,
                )
                return False
            cur.execute("DELETE FROM patch WHERE id = ?", (patch_id,))
            cur.execute("DELETE FROM patch_history WHERE patch_id = ?",
                        (patch_id,))
            conn.commit()
            return cur.rowcount > 0
        finally:
            conn.close()

    def list_patches(
        self,
        *,
        include_factory: bool = True,
        include_user: bool = True,
        style: Optional[str] = None,
        search: Optional[str] = None,
        limit: int = 500,
    ) -> list[dict]:
        """Liste Patches — Metadaten ohne den Blob.

        Returns: Liste von Dicts mit `id`, `name`, `description`, `author`,
        `is_factory`, `style`, `variant`, `tags`, `bpm`, `musical_key`,
        `created_at`, `updated_at`, `icon_svg`.
        """
        self.ensure_loaded()

        where_clauses = []
        params: list[Any] = []

        if include_factory and not include_user:
            where_clauses.append("is_factory = 1")
        elif include_user and not include_factory:
            where_clauses.append("is_factory = 0")
        elif not include_factory and not include_user:
            return []

        if style:
            where_clauses.append("style = ?")
            params.append(style)
        if search:
            where_clauses.append(
                "(name LIKE ? OR description LIKE ? OR tags LIKE ?)"
            )
            like = f"%{search}%"
            params.extend([like, like, like])

        where_sql = ""
        if where_clauses:
            where_sql = " WHERE " + " AND ".join(where_clauses)

        sql = (
            "SELECT id, name, description, author, is_factory, style, "
            "variant, tags, bpm, musical_key, created_at, updated_at, "
            "icon_svg "
            "FROM patch" + where_sql +
            " ORDER BY is_factory DESC, style, variant, name LIMIT ?"
        )
        params.append(int(limit))

        conn = self._connect()
        try:
            rows = conn.execute(sql, params).fetchall()
        finally:
            conn.close()

        result = []
        for r in rows:
            try:
                tags = json.loads(r["tags"]) if r["tags"] else []
            except Exception:
                tags = []
            result.append({
                "id": r["id"],
                "name": r["name"],
                "description": r["description"],
                "author": r["author"],
                "is_factory": bool(r["is_factory"]),
                "style": r["style"],
                "variant": int(r["variant"]),
                "tags": tags,
                "bpm": r["bpm"],
                "musical_key": r["musical_key"],
                "created_at": r["created_at"],
                "updated_at": r["updated_at"],
                "icon_svg": r["icon_svg"],
            })
        return result

    def list_styles(self) -> list[str]:
        """Liste aller Styles in der DB."""
        self.ensure_loaded()
        conn = self._connect()
        try:
            rows = conn.execute(
                "SELECT DISTINCT style FROM patch WHERE style != '' "
                "ORDER BY style"
            ).fetchall()
        finally:
            conn.close()
        return [r["style"] for r in rows]

    # ─── Diagnose ──────────────────────────────────────────────────

    def stats(self) -> dict:
        """Diagnose-Stats für SENTINEL / Vault-Browser."""
        if not self._db_path.exists():
            return {"total": 0, "user": 0, "factory": 0, "loaded": False}
        conn = self._connect()
        try:
            total = conn.execute("SELECT COUNT(*) AS n FROM patch").fetchone()["n"]
            user = conn.execute(
                "SELECT COUNT(*) AS n FROM patch WHERE is_factory = 0"
            ).fetchone()["n"]
            factory = conn.execute(
                "SELECT COUNT(*) AS n FROM patch WHERE is_factory = 1"
            ).fetchone()["n"]
        finally:
            conn.close()
        return {
            "total": int(total),
            "user": int(user),
            "factory": int(factory),
            "loaded": self._loaded,
            "path": str(self._db_path),
        }

    # ─── Factory-Presets (V-1: Sacred, V-2: + Bach + Ambient + Synthwave) ──

    def _seed_style_family(
        self,
        conn,
        style: str,
        factory_author: str,
        presets_iter,
        id_prefix: str,
        legacy_cleanup: bool = False,
    ) -> int:
        """Seed eine Style-Familie (12 Factory-Presets).

        Bedingungs-Logik:
        - Wenn die DB bereits ≥ 12 Presets dieses Styles **mit dem aktuellen
          Author-Marker** enthält, wird nichts getan (return 0).
        - Wenn ``legacy_cleanup=True`` und Einträge mit anderem Author-Marker
          des gleichen Styles existieren, werden diese (samt patch_history)
          komplett verworfen, bevor die aktuelle Version eingefügt wird.
          Dieser Pfad ist für Sacred-v2 reserviert (V-1 → V-2 Migration in
          v.199). Neue Style-Familien (Bach/Ambient/Synthwave in v.201)
          haben keine legacy-Vorgänger und nutzen ``legacy_cleanup=False``.
        - User-Patches (``is_factory=0``) bleiben in jedem Fall unberührt.

        Args:
            conn: aktive sqlite3.Connection
            style: ID-String der Style-Familie (z.B. ``"sacred"``)
            factory_author: aktueller Author-Marker mit Versionsbezeichner
                (z.B. ``"FLUX Factory (Sacred v2)"``)
            presets_iter: iterierbare Preset-Liste (LazyPresetList aus den
                ``flux_vault_factory_*.py``-Modulen)
            id_prefix: Präfix für Patch-IDs (z.B. ``"factory_sacred_"``);
                Variant-Nummer wird als ``{variant:02d}`` angehängt.
            legacy_cleanup: wenn True, alte-Author-Einträge dieses Styles
                vor dem Seed löschen.

        Returns:
            Anzahl tatsächlich eingefügter Presets (0 wenn schon aktuell).
        """
        # Wie viele Presets mit dem AKTUELLEN Versions-Marker?
        current_version_count = conn.execute(
            "SELECT COUNT(*) AS n FROM patch "
            "WHERE is_factory = 1 AND style = ? AND author = ?",
            (style, factory_author),
        ).fetchone()["n"]
        # v0.0.21.214: erwartete Anzahl aus presets_iter ableiten (statt
        # hardcoded 12). Das erlaubt Style-Familien beliebiger Größe —
        # z.B. Drum-Kit mit 6 Presets oder Thunderdome mit 12.
        try:
            expected_count = len(presets_iter)
        except TypeError:
            expected_count = 12  # Fallback für rein-iterable presets_iter
        if current_version_count >= expected_count:
            return 0  # schon mit aktueller Version geseeded

        cur = conn.cursor()

        if legacy_cleanup:
            # Gibt es ALTE Versionen dieses Styles mit anderem Author-Marker?
            old_count = conn.execute(
                "SELECT COUNT(*) AS n FROM patch "
                "WHERE is_factory = 1 AND style = ? AND author != ?",
                (style, factory_author),
            ).fetchone()["n"]
            if old_count > 0:
                logger.info(
                    "[FluxVault] re-seeding %s presets — found %d "
                    "old-version entries",
                    style, old_count,
                )
                # Erst History-Einträge wegräumen (FK-Sauberkeit)
                cur.execute(
                    "DELETE FROM patch_history WHERE patch_id IN "
                    "(SELECT id FROM patch WHERE is_factory = 1 AND style = ?)",
                    (style,),
                )
                # Dann die Style-Patches selbst
                cur.execute(
                    "DELETE FROM patch WHERE is_factory = 1 AND style = ?",
                    (style,),
                )

        # Neu seeden mit aktueller Version
        now = time.strftime("%Y-%m-%d %H:%M:%S")
        seeded = 0
        for variant, preset in enumerate(presets_iter, start=1):
            pid = f"{id_prefix}{variant:02d}"
            blob = _gzip_json(preset["patch"])
            tags_json = json.dumps(preset.get("tags") or [],
                                   ensure_ascii=False)
            cur.execute(
                """INSERT OR REPLACE INTO patch
                   (id, name, description, author, is_factory, style,
                    variant, tags, bpm, musical_key, created_at,
                    updated_at, patch_blob, icon_svg)
                   VALUES (?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (pid, preset["name"], preset.get("description", ""),
                 preset.get("author", factory_author),
                 style, variant, tags_json, preset.get("bpm"),
                 preset.get("musical_key", ""),
                 now, now, blob, preset.get("icon_svg", "")),
            )
            seeded += 1
        return seeded

    def _seed_factory_presets_if_empty(self) -> None:
        """Beim ersten Start die Factory-Presets aller Style-Familien einfügen.

        Geschichte:
        - v.197 (V-1): 12 Sacred-Pilot-Presets als erste Style-Familie
        - v.199 Hotfix: Versions-Re-Seed für Sacred (V-1 → V-2 Migration —
          wenn alter Author-Marker erkannt wird, komplett ersetzen)
        - v.201 (V-2): + Bach (12) + Ambient (12) + Synthwave (12) =
          insgesamt 48 Factory-Presets in 4 Style-Familien

        Jede Style-Familie wird unabhängig geprüft. User-Patches
        (``is_factory=0``) bleiben in jedem Fall unangetastet.
        """
        from pydaw.services.flux_vault_factory_sacred import (
            SACRED_PRESETS, SACRED_FACTORY_AUTHOR,
        )
        from pydaw.services.flux_vault_factory_bach import (
            BACH_PRESETS, BACH_FACTORY_AUTHOR,
        )
        from pydaw.services.flux_vault_factory_ambient import (
            AMBIENT_PRESETS, AMBIENT_FACTORY_AUTHOR,
        )
        from pydaw.services.flux_vault_factory_synthwave import (
            SYNTHWAVE_PRESETS, SYNTHWAVE_FACTORY_AUTHOR,
        )
        # v0.0.21.214 — Drum-Kit + Thunderdome (Anno: drum patches + 12 hardcore variations)
        from pydaw.services.flux_vault_factory_drumkit import (
            DRUMKIT_PRESETS, DRUMKIT_FACTORY_AUTHOR,
        )
        from pydaw.services.flux_vault_factory_thunderdome import (
            THUNDERDOME_PRESETS, THUNDERDOME_FACTORY_AUTHOR,
        )

        conn = self._connect()
        try:
            total_seeded = 0

            # Sacred — mit Legacy-Cleanup (V-1 → V-2 Migration in v.199)
            n = self._seed_style_family(
                conn, "sacred", SACRED_FACTORY_AUTHOR,
                SACRED_PRESETS, "factory_sacred_",
                legacy_cleanup=True,
            )
            if n > 0:
                logger.info(
                    "[FluxVault] seeded %d Sacred-Factory-Presets (%s)",
                    n, SACRED_FACTORY_AUTHOR,
                )
                total_seeded += n

            # Bach — neu in v.201 (V-2)
            n = self._seed_style_family(
                conn, "bach", BACH_FACTORY_AUTHOR,
                BACH_PRESETS, "factory_bach_",
                legacy_cleanup=False,
            )
            if n > 0:
                logger.info(
                    "[FluxVault] seeded %d Bach-Factory-Presets (%s)",
                    n, BACH_FACTORY_AUTHOR,
                )
                total_seeded += n

            # Ambient — neu in v.201 (V-2)
            n = self._seed_style_family(
                conn, "ambient", AMBIENT_FACTORY_AUTHOR,
                AMBIENT_PRESETS, "factory_ambient_",
                legacy_cleanup=False,
            )
            if n > 0:
                logger.info(
                    "[FluxVault] seeded %d Ambient-Factory-Presets (%s)",
                    n, AMBIENT_FACTORY_AUTHOR,
                )
                total_seeded += n

            # Synthwave — neu in v.201 (V-2)
            n = self._seed_style_family(
                conn, "synthwave", SYNTHWAVE_FACTORY_AUTHOR,
                SYNTHWAVE_PRESETS, "factory_synthwave_",
                legacy_cleanup=False,
            )
            if n > 0:
                logger.info(
                    "[FluxVault] seeded %d Synthwave-Factory-Presets (%s)",
                    n, SYNTHWAVE_FACTORY_AUTHOR,
                )
                total_seeded += n

            # Drum-Kit — neu in v.214 (Anno: Kick/Snare/HiHat/Clap/Tom)
            n = self._seed_style_family(
                conn, "drumkit", DRUMKIT_FACTORY_AUTHOR,
                DRUMKIT_PRESETS, "factory_drumkit_",
                legacy_cleanup=False,
            )
            if n > 0:
                logger.info(
                    "[FluxVault] seeded %d Drum-Kit-Factory-Presets (%s)",
                    n, DRUMKIT_FACTORY_AUTHOR,
                )
                total_seeded += n

            # Thunderdome — neu in v.214 (Anno: 12 Hardcore-Variationen)
            n = self._seed_style_family(
                conn, "thunderdome", THUNDERDOME_FACTORY_AUTHOR,
                THUNDERDOME_PRESETS, "factory_thunderdome_",
                legacy_cleanup=False,
            )
            if n > 0:
                logger.info(
                    "[FluxVault] seeded %d Thunderdome-Factory-Presets (%s)",
                    n, THUNDERDOME_FACTORY_AUTHOR,
                )
                total_seeded += n

            # v0.0.21.229 — Random-Family (algorithmic random patches)
            try:
                from pydaw.services.flux_vault_factory_random import (
                    RANDOM_PRESETS, RANDOM_FACTORY_AUTHOR,
                )
                n = self._seed_style_family(
                    conn, "random", RANDOM_FACTORY_AUTHOR,
                    RANDOM_PRESETS, "factory_random_",
                    legacy_cleanup=False,
                )
                if n > 0:
                    logger.info(
                        "[FluxVault] seeded %d Random-Factory-Presets (%s)",
                        n, RANDOM_FACTORY_AUTHOR,
                    )
                    total_seeded += n
            except ImportError:
                # Module nicht da — nicht blockierend (alte Builds)
                pass

            # v0.0.21.231 — Living-Family (Living Patterns + NumberFlow demos)
            try:
                from pydaw.services.flux_vault_factory_living import (
                    LIVING_PRESETS, LIVING_FACTORY_AUTHOR,
                )
                n = self._seed_style_family(
                    conn, "living", LIVING_FACTORY_AUTHOR,
                    LIVING_PRESETS, "factory_living_",
                    legacy_cleanup=False,
                )
                if n > 0:
                    logger.info(
                        "[FluxVault] seeded %d Living-Factory-Presets (%s)",
                        n, LIVING_FACTORY_AUTHOR,
                    )
                    total_seeded += n
            except ImportError:
                pass

            # v0.0.21.255 — Soviet-Family (12 sowjetische Synthesizer +
            # Raumfahrt-Hommagen, Anno-Wunsch nach v.254-CV-Sweep)
            try:
                from pydaw.services.flux_vault_factory_soviet import (
                    SOVIET_PRESETS, SOVIET_FACTORY_AUTHOR,
                )
                n = self._seed_style_family(
                    conn, "soviet", SOVIET_FACTORY_AUTHOR,
                    SOVIET_PRESETS, "factory_soviet_",
                    legacy_cleanup=False,
                )
                if n > 0:
                    logger.info(
                        "[FluxVault] seeded %d Soviet-Factory-Presets (%s)",
                        n, SOVIET_FACTORY_AUTHOR,
                    )
                    total_seeded += n
            except ImportError:
                # Module nicht da — nicht blockierend (alte Builds)
                pass

            if total_seeded > 0:
                conn.commit()
                logger.info(
                    "[FluxVault] V-2 seed complete: %d factory presets "
                    "across 5 style-families",
                    total_seeded,
                )
        except Exception as e:
            logger.warning("[FluxVault] seed factory presets failed: %s", e)
            try:
                conn.rollback()
            except Exception:
                pass
        finally:
            conn.close()


# ─── Singleton-Accessor ───────────────────────────────────────────


def get_flux_vault() -> FluxVaultDB:
    """Singleton-Accessor für den FluxVaultDB."""
    return FluxVaultDB.get()


__all__ = ["FluxVaultDB", "get_flux_vault"]
