"""JSFX Runtime (P6B) — Reaper-compatible DSP script interpreter.

Implements a subset of Reaper's JSFX language as a Python DSP processor.
Scripts are parsed and executed as Python, not natively — this is an
approximation for simple JSFX effects, not a full JSFX VM.

Supported JSFX features:
- @init, @slider, @block, @sample sections
- slider1..slider64 parameters
- spl0, spl1 (left/right sample access)
- Basic math functions (sin, cos, sqrt, abs, min, max, log, exp, pow)
- Memory access: array[] style via dict
- Conditionals, loops (while)

Limitations:
- No FFT (mdct_*), no file I/O, no GFX section
- No multi-channel beyond stereo
- Performance: Python is ~100x slower than native JSFX

v0.0.20.812 — Phase P6B
"""

from __future__ import annotations

import logging
import math
import re
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any, Tuple

log = logging.getLogger(__name__)

try:
    import numpy as np
except Exception:
    np = None  # type: ignore


# ---------------------------------------------------------------------------
# JSFX Parser
# ---------------------------------------------------------------------------

@dataclass
class JsfxSlider:
    """A JSFX slider parameter definition."""
    index: int              # 1-64
    default: float = 0.0
    minimum: float = 0.0
    maximum: float = 1.0
    step: float = 0.001
    label: str = ""
    current: float = 0.0

    def to_dict(self) -> dict:
        return {
            "index": self.index, "label": self.label,
            "default": self.default, "min": self.minimum, "max": self.maximum,
            "step": self.step, "current": round(self.current, 6),
        }


@dataclass
class JsfxScript:
    """Parsed JSFX script."""
    name: str = ""
    author: str = ""
    description: str = ""
    sliders: Dict[int, JsfxSlider] = field(default_factory=dict)
    init_code: str = ""
    slider_code: str = ""
    block_code: str = ""
    sample_code: str = ""
    raw_source: str = ""

    def to_dict(self) -> dict:
        return {
            "name": self.name, "author": self.author,
            "sliders": {k: v.to_dict() for k, v in self.sliders.items()},
            "has_init": bool(self.init_code),
            "has_sample": bool(self.sample_code),
            "has_block": bool(self.block_code),
        }


def parse_jsfx(source: str) -> JsfxScript:
    """Parse a JSFX source file into sections.

    Args:
        source: JSFX script text

    Returns:
        JsfxScript with parsed sections.
    """
    script = JsfxScript(raw_source=source)
    lines = source.split("\n")

    # Parse header
    for line in lines:
        line = line.strip()
        if line.startswith("desc:"):
            script.name = line[5:].strip()
            script.description = script.name
        elif line.startswith("author:"):
            script.author = line[7:].strip()
        # Slider definitions: slider1:0<0,1,0.01>Label
        m = re.match(r"slider(\d+):(-?[\d.]+)<(-?[\d.]+),(-?[\d.]+),?([\d.]*)>(.*)", line)
        if m:
            idx = int(m.group(1))
            default = float(m.group(2))
            lo = float(m.group(3))
            hi = float(m.group(4))
            step = float(m.group(5)) if m.group(5) else 0.001
            label = m.group(6).strip()
            script.sliders[idx] = JsfxSlider(
                index=idx, default=default, minimum=lo, maximum=hi,
                step=step, label=label, current=default,
            )

    # Parse sections
    current_section = ""
    section_lines: Dict[str, List[str]] = {
        "@init": [], "@slider": [], "@block": [], "@sample": [],
    }

    for line in lines:
        stripped = line.strip()
        if stripped in ("@init", "@slider", "@block", "@sample"):
            current_section = stripped
            continue
        if current_section in section_lines:
            section_lines[current_section].append(line)

    script.init_code = "\n".join(section_lines["@init"])
    script.slider_code = "\n".join(section_lines["@slider"])
    script.block_code = "\n".join(section_lines["@block"])
    script.sample_code = "\n".join(section_lines["@sample"])

    return script


# ---------------------------------------------------------------------------
# JSFX → Python transpiler (simple subset)
# ---------------------------------------------------------------------------

def _transpile_jsfx_to_python(jsfx_code: str) -> str:
    """Convert JSFX code to equivalent Python code (best-effort subset).

    Handles:
    - Variable assignments
    - Math functions
    - Conditionals (if/else, ternary ? :)
    - while loops
    - spl0/spl1 sample access
    """
    if not jsfx_code.strip():
        return "pass"

    lines = jsfx_code.split("\n")
    result: List[str] = []

    for line in lines:
        stripped = line.strip()
        if not stripped or stripped.startswith("//"):
            continue

        # Remove inline comments
        if "//" in stripped:
            stripped = stripped[:stripped.index("//")].strip()

        # Handle JSFX ternary: cond ? a : b → a if cond else b
        # (simple cases only)
        stripped = re.sub(
            r"(\w+)\s*\?\s*([^:]+)\s*:\s*(.+)",
            r"(\2) if (\1) else (\3)",
            stripped,
        )

        # JSFX uses = for both comparison and assignment in conditionals
        # Replace == where JSFX uses = in if conditions
        # Simple heuristic: if line starts with "if" or "while", = → ==
        # but only single = not preceded by < > ! and not +=, -=, *=, /=
        if re.match(r"\s*(if|while)\s*\(", stripped):
            # Protect assignments first
            stripped = re.sub(r"([^<>!=+\-*/])=([^=])", r"\1==\2", stripped)

        # JSFX semicolons → remove (Python doesn't need them)
        stripped = stripped.rstrip(";")

        # JSFX ( ) around if/while conditions
        stripped = re.sub(r"\bif\s*\(", "if (", stripped)
        stripped = re.sub(r"\bwhile\s*\(", "while (", stripped)

        # JSFX: end-of-block is just next section or ) at end
        # This is a simplified approach
        if stripped == ")" or stripped == ");":
            continue

        # Indent handling (JSFX uses ( ) blocks)
        stripped = stripped.replace("(", "").replace(")", "") if stripped in ("(", ")") else stripped

        # Add colon for if/while/else
        if re.match(r"^\s*(if|while|else)\b.*[^:]$", stripped):
            if not stripped.endswith(":"):
                stripped += ":"

        result.append(stripped)

    if not result:
        return "pass"
    return "\n".join(result)


# ---------------------------------------------------------------------------
# JSFX Runtime Engine
# ---------------------------------------------------------------------------

class JsfxRuntime:
    """Execute JSFX scripts as Python DSP processors.

    Usage:
        script = parse_jsfx(source_code)
        runtime = JsfxRuntime(script, sample_rate=44100)
        runtime.init()
        # Per block:
        runtime.process_block(left_buffer, right_buffer)
    """

    def __init__(self, script: JsfxScript, sample_rate: float = 44100.0):
        self._script = script
        self._sample_rate = sample_rate

        # JSFX built-in variables
        self._vars: Dict[str, float] = {
            "srate": sample_rate,
            "samplesblock": 512,
            "num_ch": 2,
            "spl0": 0.0,
            "spl1": 0.0,
            "tempo": 120.0,
            "play_state": 0.0,
            "beat_position": 0.0,
        }

        # Memory array (JSFX mem[] access)
        self._mem: Dict[int, float] = {}

        # Slider values
        for idx, sl in script.sliders.items():
            self._vars[f"slider{idx}"] = sl.current

        # Transpiled code cache
        self._init_py = ""
        self._sample_py = ""
        self._block_py = ""

    def init(self) -> None:
        """Execute @init section."""
        self._init_py = _transpile_jsfx_to_python(self._script.init_code)
        self._sample_py = _transpile_jsfx_to_python(self._script.sample_code)
        self._block_py = _transpile_jsfx_to_python(self._script.block_code)

        self._exec_safe(self._init_py)

    def set_slider(self, index: int, value: float) -> None:
        """Set a slider value and re-run @slider section."""
        key = f"slider{index}"
        sl = self._script.sliders.get(index)
        if sl:
            value = max(sl.minimum, min(sl.maximum, value))
            sl.current = value
        self._vars[key] = value

        slider_py = _transpile_jsfx_to_python(self._script.slider_code)
        self._exec_safe(slider_py)

    def process_block(self, left: Any, right: Any) -> None:
        """Process an audio block in-place.

        Args:
            left: numpy array or list (modified in-place)
            right: numpy array or list (modified in-place)
        """
        if np is None:
            return

        left = np.asarray(left, dtype=np.float64)
        right = np.asarray(right, dtype=np.float64)
        n = min(len(left), len(right))

        self._vars["samplesblock"] = float(n)

        # Execute @block
        if self._block_py and self._block_py != "pass":
            self._exec_safe(self._block_py)

        # Execute @sample for each sample
        if self._sample_py and self._sample_py != "pass":
            for i in range(n):
                self._vars["spl0"] = float(left[i])
                self._vars["spl1"] = float(right[i])
                self._exec_safe(self._sample_py)
                left[i] = self._vars.get("spl0", left[i])
                right[i] = self._vars.get("spl1", right[i])

    def get_vars(self) -> Dict[str, float]:
        """Return current variable state (for debugging)."""
        return dict(self._vars)

    def _exec_safe(self, code: str) -> None:
        """Execute transpiled code in a sandboxed namespace."""
        if not code or code == "pass":
            return

        # Build execution namespace with math functions
        ns: Dict[str, Any] = dict(self._vars)
        ns.update({
            "sin": math.sin, "cos": math.cos, "tan": math.tan,
            "sqrt": math.sqrt, "abs": abs, "min": min, "max": max,
            "log": math.log, "log10": math.log10, "exp": math.exp,
            "pow": pow, "floor": math.floor, "ceil": math.ceil,
            "sign": lambda x: 1.0 if x > 0 else (-1.0 if x < 0 else 0.0),
            "PI": math.pi, "$pi": math.pi,
            "mem": self._mem,
        })

        try:
            exec(code, {"__builtins__": {}}, ns)  # noqa: S102
        except Exception as exc:
            log.debug("JSFX exec error: %s", exc)
            return

        # Write back known variables
        for key in list(self._vars.keys()):
            if key in ns:
                try:
                    self._vars[key] = float(ns[key])
                except (ValueError, TypeError):
                    pass

    def shutdown(self) -> None:
        """Cleanup."""
        self._vars.clear()
        self._mem.clear()


# ---------------------------------------------------------------------------
# Factory presets (example JSFX scripts)
# ---------------------------------------------------------------------------

EXAMPLE_GAIN = """desc:Simple Gain
author:Py_DAW
slider1:0<-60,12,0.1>Gain (dB)

@init
gain_linear = 1.0;

@slider
gain_linear = pow(10, slider1 / 20);

@sample
spl0 = spl0 * gain_linear;
spl1 = spl1 * gain_linear;
"""

EXAMPLE_TREMOLO = """desc:Simple Tremolo
author:Py_DAW
slider1:4<0.1,20,0.1>Rate (Hz)
slider2:50<0,100,1>Depth (%)

@init
phase = 0;

@sample
lfo = sin(phase * 2 * $pi);
mod = 1.0 - (slider2 / 100) * (0.5 + 0.5 * lfo);
spl0 = spl0 * mod;
spl1 = spl1 * mod;
phase = phase + slider1 / srate;
"""

EXAMPLE_BITCRUSHER = """desc:Bitcrusher
author:Py_DAW
slider1:16<1,16,1>Bit Depth
slider2:1<1,32,1>Sample Rate Divisor

@init
hold_l = 0;
hold_r = 0;
counter = 0;

@sample
counter = counter + 1;
steps = pow(2, slider1);
spl0 = floor(spl0 * steps) / steps;
spl1 = floor(spl1 * steps) / steps;
"""

BUILTIN_JSFX: Dict[str, str] = {
    "Simple Gain": EXAMPLE_GAIN,
    "Simple Tremolo": EXAMPLE_TREMOLO,
    "Bitcrusher": EXAMPLE_BITCRUSHER,
}
