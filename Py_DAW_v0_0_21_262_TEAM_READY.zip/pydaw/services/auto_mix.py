"""Auto-Mix Service (P3B) — KI-gestütztes Auto-Mixing.

Offline, pure Python + numpy. No ML for auto-mix (heuristic).
Demucs stem separation = optional dependency (marked as stub if unavailable).

Features:
- One-Click-Mix: genre-aware EQ/Comp/Reverb presets applied per track
- Reference matching: analyze reference track → match LUFS + spectrum + stereo
- Genre-Mix-Presets: pre-configured mixing templates
- Stem-Separation stub (requires demucs/torchaudio)

v0.0.20.808 — Phase P3B
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Tuple, Any

log = logging.getLogger(__name__)

try:
    import numpy as np
except Exception:
    np = None  # type: ignore


# ---------------------------------------------------------------------------
# Genre Mix Presets
# ---------------------------------------------------------------------------

@dataclass
class TrackMixPreset:
    """Per-track mix settings."""
    eq_low_gain_db: float = 0.0      # shelf gain < 250 Hz
    eq_mid_gain_db: float = 0.0      # bell gain 250-4000 Hz
    eq_high_gain_db: float = 0.0     # shelf gain > 4000 Hz
    eq_low_freq: float = 100.0       # Hz
    eq_high_freq: float = 8000.0     # Hz
    comp_threshold_db: float = -20.0
    comp_ratio: float = 2.0
    comp_attack_ms: float = 10.0
    comp_release_ms: float = 100.0
    reverb_send: float = 0.0         # 0..1
    delay_send: float = 0.0          # 0..1
    pan: float = 0.0                 # -1..1
    gain_db: float = 0.0             # makeup gain

    def to_dict(self) -> dict:
        return {k: round(v, 2) for k, v in self.__dict__.items()}


@dataclass
class GenreMixPreset:
    """Genre-specific mixing template."""
    name: str = ""
    description: str = ""
    target_lufs: float = -14.0
    # Per-role presets
    kick: TrackMixPreset = field(default_factory=TrackMixPreset)
    snare: TrackMixPreset = field(default_factory=TrackMixPreset)
    bass: TrackMixPreset = field(default_factory=TrackMixPreset)
    vocals: TrackMixPreset = field(default_factory=TrackMixPreset)
    keys: TrackMixPreset = field(default_factory=TrackMixPreset)
    guitars: TrackMixPreset = field(default_factory=TrackMixPreset)
    pads: TrackMixPreset = field(default_factory=TrackMixPreset)
    default: TrackMixPreset = field(default_factory=TrackMixPreset)


# Pre-built genre presets
GENRE_PRESETS: Dict[str, GenreMixPreset] = {
    "Hip-Hop": GenreMixPreset(
        name="Hip-Hop", description="Fette Bässe, präsente Vocals, harte Drums",
        target_lufs=-10.0,
        kick=TrackMixPreset(eq_low_gain_db=3.0, eq_mid_gain_db=-2.0, comp_ratio=4.0, comp_threshold_db=-15.0),
        snare=TrackMixPreset(eq_mid_gain_db=2.0, eq_high_gain_db=1.0, comp_ratio=3.0, reverb_send=0.1),
        bass=TrackMixPreset(eq_low_gain_db=4.0, eq_mid_gain_db=-3.0, comp_ratio=3.0, comp_threshold_db=-18.0),
        vocals=TrackMixPreset(eq_low_gain_db=-4.0, eq_mid_gain_db=2.0, eq_high_gain_db=3.0, comp_ratio=4.0, comp_threshold_db=-15.0, delay_send=0.15),
        pads=TrackMixPreset(eq_low_gain_db=-6.0, reverb_send=0.3, pan=0.0),
    ),
    "Rock": GenreMixPreset(
        name="Rock", description="Gitarren breit, Drums punchy, Bass zentral",
        target_lufs=-12.0,
        kick=TrackMixPreset(eq_low_gain_db=2.0, eq_mid_gain_db=-1.0, comp_ratio=3.0),
        snare=TrackMixPreset(eq_mid_gain_db=3.0, comp_ratio=3.0, reverb_send=0.2),
        bass=TrackMixPreset(eq_low_gain_db=2.0, comp_ratio=3.0, comp_threshold_db=-20.0),
        guitars=TrackMixPreset(eq_mid_gain_db=1.0, eq_high_gain_db=2.0, pan=0.6, reverb_send=0.15),
        vocals=TrackMixPreset(eq_low_gain_db=-3.0, eq_high_gain_db=2.0, comp_ratio=3.0, delay_send=0.1),
    ),
    "EDM": GenreMixPreset(
        name="EDM", description="Maximale Lautheit, saubere Frequenztrennung",
        target_lufs=-8.0,
        kick=TrackMixPreset(eq_low_gain_db=4.0, eq_mid_gain_db=-4.0, comp_ratio=6.0, comp_threshold_db=-12.0),
        bass=TrackMixPreset(eq_low_gain_db=3.0, eq_mid_gain_db=-2.0, comp_ratio=4.0),
        pads=TrackMixPreset(eq_low_gain_db=-8.0, eq_high_gain_db=2.0, reverb_send=0.4, pan=0.3),
        keys=TrackMixPreset(eq_low_gain_db=-6.0, eq_high_gain_db=3.0, pan=-0.3),
    ),
    "Jazz": GenreMixPreset(
        name="Jazz", description="Natürlich, dynamisch, räumlich",
        target_lufs=-18.0,
        kick=TrackMixPreset(eq_low_gain_db=1.0, comp_ratio=2.0, reverb_send=0.2),
        bass=TrackMixPreset(eq_low_gain_db=1.0, comp_ratio=1.5),
        keys=TrackMixPreset(reverb_send=0.25, pan=-0.3),
        guitars=TrackMixPreset(reverb_send=0.2, pan=0.3),
        vocals=TrackMixPreset(eq_high_gain_db=1.0, comp_ratio=2.0, reverb_send=0.2),
    ),
    "Podcast": GenreMixPreset(
        name="Podcast", description="Sprache klar + gleichmäßig, Musik leise",
        target_lufs=-16.0,
        vocals=TrackMixPreset(eq_low_gain_db=-6.0, eq_low_freq=150.0, eq_mid_gain_db=2.0, eq_high_gain_db=3.0, comp_ratio=5.0, comp_threshold_db=-20.0, comp_attack_ms=5.0),
        pads=TrackMixPreset(gain_db=-12.0, eq_high_gain_db=-3.0),
        default=TrackMixPreset(gain_db=-10.0),
    ),
    "Ambient": GenreMixPreset(
        name="Ambient", description="Weiter Raum, langsame Dynamik",
        target_lufs=-20.0,
        pads=TrackMixPreset(reverb_send=0.5, eq_high_gain_db=2.0),
        keys=TrackMixPreset(reverb_send=0.4, delay_send=0.3),
        default=TrackMixPreset(reverb_send=0.3, comp_ratio=1.5),
    ),
}


def get_genre_names() -> List[str]:
    return list(GENRE_PRESETS.keys())


def get_genre_preset(name: str) -> Optional[GenreMixPreset]:
    return GENRE_PRESETS.get(name)


# ---------------------------------------------------------------------------
# Track role detection (heuristic)
# ---------------------------------------------------------------------------

def detect_track_role(track_name: str, track_kind: str = "") -> str:
    """Guess track role from name for auto-mix preset selection."""
    name = track_name.lower().strip()
    if any(k in name for k in ["kick", "bd", "bassdrum"]):
        return "kick"
    if any(k in name for k in ["snare", "sd", "clap"]):
        return "snare"
    if any(k in name for k in ["bass", "sub", "808"]):
        return "bass"
    if any(k in name for k in ["vocal", "vox", "voice", "sprech", "gesang"]):
        return "vocals"
    if any(k in name for k in ["guitar", "gitar", "git"]):
        return "guitars"
    if any(k in name for k in ["keys", "piano", "organ", "klavier", "synth lead"]):
        return "keys"
    if any(k in name for k in ["pad", "ambient", "atmo", "string"]):
        return "pads"
    if any(k in name for k in ["drum", "perc", "hi-hat", "hh", "cymbal"]):
        return "kick"  # generic drums → use kick preset
    return "default"


def get_track_preset(genre: str, role: str) -> TrackMixPreset:
    """Get mix preset for a track role in a genre."""
    gp = GENRE_PRESETS.get(genre)
    if gp is None:
        return TrackMixPreset()
    return getattr(gp, role, gp.default) or gp.default


# ---------------------------------------------------------------------------
# Reference matching
# ---------------------------------------------------------------------------

@dataclass
class ReferenceMatch:
    """Result of matching a mix to a reference track."""
    lufs_diff: float = 0.0
    gain_correction_db: float = 0.0
    spectral_tilt_db: float = 0.0    # positive = ref is brighter
    low_diff: float = 0.0
    mid_diff: float = 0.0
    high_diff: float = 0.0
    width_diff: float = 0.0
    suggestions: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "lufs_diff": round(self.lufs_diff, 1),
            "gain_correction_db": round(self.gain_correction_db, 1),
            "spectral_tilt_db": round(self.spectral_tilt_db, 1),
            "low_diff": round(self.low_diff, 3),
            "mid_diff": round(self.mid_diff, 3),
            "high_diff": round(self.high_diff, 3),
            "width_diff": round(self.width_diff, 3),
            "suggestions": self.suggestions,
        }


def match_to_reference(
    mix_audio: "np.ndarray",
    ref_audio: "np.ndarray",
    sr: int = 48000,
) -> ReferenceMatch:
    """Compare mix to a reference track and suggest adjustments."""
    if np is None:
        return ReferenceMatch(suggestions=["numpy nicht verfügbar"])

    from pydaw.services.smart_mixer import (
        _measure_lufs, _spectral_analysis, _stereo_analysis,
    )

    mix_mono = np.mean(np.asarray(mix_audio, dtype=np.float64).reshape(-1, max(1, mix_audio.shape[-1] if mix_audio.ndim > 1 else 1)), axis=1) if mix_audio.ndim > 1 else np.asarray(mix_audio, dtype=np.float64).flatten()
    ref_mono = np.mean(np.asarray(ref_audio, dtype=np.float64).reshape(-1, max(1, ref_audio.shape[-1] if ref_audio.ndim > 1 else 1)), axis=1) if ref_audio.ndim > 1 else np.asarray(ref_audio, dtype=np.float64).flatten()

    # LUFS comparison
    mix_lufs = _measure_lufs(mix_mono, sr)
    ref_lufs = _measure_lufs(ref_mono, sr)
    lufs_diff = ref_lufs - mix_lufs

    # Spectral comparison
    mix_spec = _spectral_analysis(mix_mono, sr)
    ref_spec = _spectral_analysis(ref_mono, sr)

    low_diff = ref_spec["low_energy"] - mix_spec["low_energy"]
    mid_diff = ref_spec["mid_energy"] - mix_spec["mid_energy"]
    high_diff = ref_spec["high_energy"] - mix_spec["high_energy"]
    tilt = (ref_spec["centroid"] - mix_spec["centroid"]) / 1000.0  # rough dB tilt

    # Stereo comparison
    mix_stereo = {"width": 0.0, "correlation": 1.0}
    ref_stereo = {"width": 0.0, "correlation": 1.0}
    if mix_audio.ndim == 2 and mix_audio.shape[1] >= 2:
        mix_stereo = _stereo_analysis(mix_audio[:, 0], mix_audio[:, 1])
    if ref_audio.ndim == 2 and ref_audio.shape[1] >= 2:
        ref_stereo = _stereo_analysis(ref_audio[:, 0], ref_audio[:, 1])
    width_diff = ref_stereo["width"] - mix_stereo["width"]

    # Generate suggestions
    suggestions = []
    if abs(lufs_diff) > 1.0:
        if lufs_diff > 0:
            suggestions.append(f"Mix ist {abs(lufs_diff):.1f} dB leiser als Referenz. Gain +{lufs_diff:.1f} dB.")
        else:
            suggestions.append(f"Mix ist {abs(lufs_diff):.1f} dB lauter als Referenz. Gain {lufs_diff:.1f} dB.")

    if abs(low_diff) > 0.05:
        if low_diff > 0:
            suggestions.append(f"Referenz hat mehr Bass (+{low_diff:.0%}). Low-End boosten.")
        else:
            suggestions.append(f"Mix hat zu viel Bass ({low_diff:.0%}). Low-End kürzen.")

    if abs(high_diff) > 0.05:
        if high_diff > 0:
            suggestions.append(f"Referenz ist heller (+{high_diff:.0%} Höhen). High-Shelf boosten.")
        else:
            suggestions.append(f"Mix ist heller als Referenz. Höhen etwas zurücknehmen.")

    if abs(width_diff) > 0.1:
        if width_diff > 0:
            suggestions.append(f"Referenz ist breiter. Stereo-Widener oder mehr Panning.")
        else:
            suggestions.append(f"Mix ist breiter als Referenz. Stereo einengen (Mid boost).")

    if not suggestions:
        suggestions.append("Mix und Referenz sind ähnlich — gut!")

    return ReferenceMatch(
        lufs_diff=lufs_diff, gain_correction_db=lufs_diff,
        spectral_tilt_db=tilt, low_diff=low_diff, mid_diff=mid_diff,
        high_diff=high_diff, width_diff=width_diff, suggestions=suggestions,
    )


# ---------------------------------------------------------------------------
# Auto-Mix one-click
# ---------------------------------------------------------------------------

def auto_mix_tracks(
    tracks: List[Dict[str, Any]],
    genre: str = "Pop",
    target_lufs: float = -14.0,
) -> List[Dict[str, Any]]:
    """Generate per-track mix settings for one-click mixing.

    tracks: list of dicts with 'name', 'kind', 'volume', 'pan'
    Returns: list of dicts with suggested settings per track.
    """
    preset = GENRE_PRESETS.get(genre, GENRE_PRESETS.get("Rock", GenreMixPreset()))
    results = []

    for t in tracks:
        name = str(t.get("name", "Track"))
        role = detect_track_role(name, str(t.get("kind", "")))
        tp = get_track_preset(genre, role)

        results.append({
            "track_name": name,
            "role": role,
            "eq_low_gain_db": tp.eq_low_gain_db,
            "eq_mid_gain_db": tp.eq_mid_gain_db,
            "eq_high_gain_db": tp.eq_high_gain_db,
            "comp_threshold_db": tp.comp_threshold_db,
            "comp_ratio": tp.comp_ratio,
            "reverb_send": tp.reverb_send,
            "delay_send": tp.delay_send,
            "suggested_pan": tp.pan,
            "gain_db": tp.gain_db,
        })

    return results


# ---------------------------------------------------------------------------
# Stem Separation (Demucs stub)
# ---------------------------------------------------------------------------

def separate_stems(
    audio_path: str,
    output_dir: str = "",
    *,
    model: str = "htdemucs",
) -> Dict[str, str]:
    """Separate audio into stems using Demucs.

    Returns dict mapping stem_name → output_path.
    Requires: pip install demucs torchaudio

    This is a stub — real separation requires GPU and large model download.
    """
    try:
        import demucs.api  # type: ignore
        separator = demucs.api.Separator(model=model)
        origin, separated = separator.separate_audio_file(audio_path)
        result = {}
        for stem_name, stem_audio in separated.items():
            import soundfile as sf  # type: ignore
            import os
            if not output_dir:
                output_dir = os.path.dirname(audio_path)
            base = os.path.splitext(os.path.basename(audio_path))[0]
            out_path = os.path.join(output_dir, f"{base}_{stem_name}.wav")
            sf.write(out_path, stem_audio.cpu().numpy().T, origin.sample_rate)
            result[stem_name] = out_path
        return result
    except ImportError:
        log.warning("Demucs nicht installiert. pip install demucs torchaudio")
        return {"error": "demucs nicht installiert (pip install demucs torchaudio)"}
    except Exception as exc:
        log.error("Stem separation failed: %s", exc)
        return {"error": str(exc)}
