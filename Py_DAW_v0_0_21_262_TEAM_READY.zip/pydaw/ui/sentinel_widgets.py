"""sentinel_widgets.py — SENTINEL Health UI Widgets (Phases S4 + S6).

v0.0.20.904 — Phases S4 (Health UI) + S6 (Self-Healing UI)

Widgets:
- SentinelStatusWidget: Herz-Icon in der Status-Bar (gruen/gelb/rot)
- SentinelAlertBanner: Warnung am oberen Fensterrand (Stufe 3+)
- SentinelDashboard: Health Dashboard als Dock-Widget
"""

from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional

log = logging.getLogger(__name__)

try:
    from PyQt6.QtCore import Qt, pyqtSignal, pyqtSlot, QTimer, QSize
    from PyQt6.QtGui import QColor, QFont, QPainter, QBrush, QPen
    from PyQt6.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
        QFrame, QScrollArea, QSizePolicy, QToolTip,
    )
    _QT = True
except ImportError:
    _QT = False

if _QT:

    class SentinelStatusWidget(QWidget):
        """Heart icon in the status bar — green/yellow/red."""

        clicked = pyqtSignal()

        def __init__(self, parent=None):
            super().__init__(parent)
            self.setFixedSize(24, 24)
            self.setCursor(Qt.CursorShape.PointingHandCursor)
            self.setToolTip("SENTINEL Health — Klick fuer Details")
            self._status = "healthy"  # healthy, warning, critical
            self._pulse = False

        def set_status(self, status: str) -> None:
            self._status = status
            tip_map = {
                "healthy": "SENTINEL: Alles OK",
                "warning": "SENTINEL: Warnung aktiv",
                "critical": "SENTINEL: Problem erkannt!",
            }
            self.setToolTip(tip_map.get(status, "SENTINEL"))
            self.update()

        def paintEvent(self, event):
            p = QPainter(self)
            p.setRenderHint(QPainter.RenderHint.Antialiasing)
            colors = {
                "healthy": QColor(80, 200, 80),
                "warning": QColor(240, 200, 40),
                "critical": QColor(220, 60, 60),
            }
            color = colors.get(self._status, colors["healthy"])
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QBrush(color))
            p.drawEllipse(4, 4, 16, 16)

            # Inner highlight
            p.setBrush(QBrush(color.lighter(140)))
            p.drawEllipse(7, 6, 6, 5)
            p.end()

        def mousePressEvent(self, event):
            self.clicked.emit()

    # ──────────────────────────────────────────────────────

    class SentinelAlertBanner(QWidget):
        """Alert banner at the top of the window (severity 3+).

        Shows warning/error messages with action buttons.
        Non-modal — does NOT block DAW usage.
        """

        action_requested = pyqtSignal(str, int)  # action_type, anomaly_id
        dismissed = pyqtSignal(int)               # anomaly_id

        def __init__(self, parent=None):
            super().__init__(parent)
            self.setFixedHeight(0)  # Hidden by default
            self._visible = False
            self._anomaly_id = 0
            self._action_type = ""

            layout = QHBoxLayout(self)
            layout.setContentsMargins(8, 4, 8, 4)
            layout.setSpacing(8)

            self._icon = QLabel("")
            self._icon.setFixedWidth(20)
            layout.addWidget(self._icon)

            self._lbl_message = QLabel("")
            self._lbl_message.setWordWrap(True)
            layout.addWidget(self._lbl_message, stretch=1)

            self._btn_action = QPushButton("Details")
            self._btn_action.setFixedWidth(70)
            self._btn_action.clicked.connect(self._on_action)
            layout.addWidget(self._btn_action)

            self._btn_undo = QPushButton("Rueckgaengig")
            self._btn_undo.setFixedWidth(90)
            self._btn_undo.clicked.connect(self._on_undo)
            self._btn_undo.setVisible(False)
            layout.addWidget(self._btn_undo)

            self._btn_dismiss = QPushButton("X")
            self._btn_dismiss.setFixedWidth(28)
            self._btn_dismiss.clicked.connect(self._on_dismiss)
            layout.addWidget(self._btn_dismiss)

        def show_alert(self, severity: int, anomaly_type: str,
                         message: str, anomaly_id: int = 0,
                         show_undo: bool = False) -> None:
            self._anomaly_id = anomaly_id
            self._action_type = anomaly_type

            if severity >= 5:
                self.setStyleSheet("background: #8b1a1a; color: white; border-radius: 4px;")
                self._icon.setText("!!!")
            elif severity >= 4:
                self.setStyleSheet("background: #8b4513; color: white; border-radius: 4px;")
                self._icon.setText("!!")
            else:
                self.setStyleSheet("background: #6b6b00; color: white; border-radius: 4px;")
                self._icon.setText("!")

            self._lbl_message.setText(message)
            self._btn_undo.setVisible(show_undo)
            self.setFixedHeight(36)
            self._visible = True

        def hide_alert(self) -> None:
            self.setFixedHeight(0)
            self._visible = False

        @property
        def is_showing(self) -> bool:
            return self._visible

        def _on_action(self):
            self.action_requested.emit(self._action_type, self._anomaly_id)

        def _on_undo(self):
            self.action_requested.emit("undo", self._anomaly_id)
            self.hide_alert()

        def _on_dismiss(self):
            self.dismissed.emit(self._anomaly_id)
            self.hide_alert()

    # ──────────────────────────────────────────────────────

    class SentinelDashboard(QWidget):
        """SENTINEL Health Dashboard — shows metrics, anomalies, crashes.

        v0.0.20.905 — Extended with S11 (CPU graph, track health, patterns)
                       and S12 (live-mode toggle, pre-show check).
        """

        def __init__(self, parent=None):
            super().__init__(parent)
            self._recorder = None
            self._anomaly = None
            self._db = None
            self._cpu_history: list = []  # [(timestamp, value), ...]
            self._mem_history: list = []
            self._live_mode = False
            self._session_start = time.time()
            self._session_anomalies = 0
            self._session_xruns = 0
            self._refresh_timer = QTimer(self)
            self._refresh_timer.setInterval(3000)
            self._refresh_timer.timeout.connect(self._refresh)
            self._setup_ui()

        def _setup_ui(self):
            layout = QVBoxLayout(self)
            layout.setContentsMargins(6, 6, 6, 6)
            layout.setSpacing(4)

            # ── Title row + Live-Mode toggle ──
            title_row = QHBoxLayout()
            title = QLabel("SENTINEL Health Dashboard")
            title.setStyleSheet("font-weight:bold; font-size:14px; color:#ccc;")
            title_row.addWidget(title)
            title_row.addStretch()

            # S12: Live-Mode toggle
            self._btn_live = QPushButton("LIVE MODE: OFF")
            self._btn_live.setFixedWidth(130)
            self._btn_live.setStyleSheet(
                "background:#333; color:#999; border:1px solid #555; "
                "border-radius:4px; padding:3px 8px; font-size:11px;"
            )
            self._btn_live.setToolTip(
                "Live-Mode: KEINE Auto-Isolierung (Stufe 5 → Stufe 4).\n"
                "Nur Warnungen, NIE automatische Eingriffe."
            )
            self._btn_live.clicked.connect(self._toggle_live_mode)
            title_row.addWidget(self._btn_live)

            # S12: Pre-Show Check
            self._btn_preshow = QPushButton("Pre-Show")
            self._btn_preshow.setFixedWidth(70)
            self._btn_preshow.setStyleSheet(
                "background:#2a3a2a; color:#8f8; border:1px solid #484; "
                "border-radius:4px; padding:3px 6px; font-size:11px;"
            )
            self._btn_preshow.setToolTip("Alle Systeme pruefen fuer Live-Performance")
            self._btn_preshow.clicked.connect(self._pre_show_check)
            title_row.addWidget(self._btn_preshow)

            layout.addLayout(title_row)

            # ── Metrics row ──
            metrics_frame = QFrame()
            metrics_frame.setStyleSheet("background:#2a2a30; border-radius:4px; padding:6px;")
            ml = QHBoxLayout(metrics_frame)
            ml.setSpacing(16)

            self._lbl_cpu = QLabel("Python-CPU: --")
            self._lbl_cpu.setStyleSheet("color:#8cf; font-size:12px;")
            ml.addWidget(self._lbl_cpu)

            self._lbl_mem = QLabel("RAM: --")
            self._lbl_mem.setStyleSheet("color:#8cf; font-size:12px;")
            ml.addWidget(self._lbl_mem)

            self._lbl_xruns = QLabel("XRuns: 0")
            self._lbl_xruns.setStyleSheet("color:#8cf; font-size:12px;")
            ml.addWidget(self._lbl_xruns)

            self._lbl_threads = QLabel("Threads: --")
            self._lbl_threads.setStyleSheet("color:#8cf; font-size:12px;")
            ml.addWidget(self._lbl_threads)

            self._lbl_status = QLabel("Status: OK")
            self._lbl_status.setStyleSheet("color:#8f8; font-size:12px; font-weight:bold;")
            ml.addWidget(self._lbl_status)

            # S11: API status
            self._lbl_api = QLabel("API: --")
            self._lbl_api.setStyleSheet("color:#666; font-size:11px;")
            ml.addWidget(self._lbl_api)

            ml.addStretch()
            layout.addWidget(metrics_frame)

            # ── S11: CPU History Graph ──
            self._cpu_graph = _CPUGraphWidget(self)
            self._cpu_graph.setFixedHeight(80)
            self._cpu_graph.setToolTip("CPU-Verlauf der letzten 5 Minuten")
            layout.addWidget(self._cpu_graph)

            # ── Anomalies section ──
            anom_label = QLabel("Aktive Anomalien")
            anom_label.setStyleSheet("color:#aaa; font-size:11px; font-weight:bold;")
            layout.addWidget(anom_label)

            self._anom_area = QScrollArea()
            self._anom_area.setWidgetResizable(True)
            self._anom_area.setMaximumHeight(120)
            self._anom_widget = QWidget()
            self._anom_layout = QVBoxLayout(self._anom_widget)
            self._anom_layout.setContentsMargins(2, 2, 2, 2)
            self._anom_layout.setSpacing(2)
            self._anom_layout.addStretch()
            self._anom_area.setWidget(self._anom_widget)
            layout.addWidget(self._anom_area)

            # ── Crashes section ──
            crash_label = QLabel("Letzte Crashes")
            crash_label.setStyleSheet("color:#aaa; font-size:11px; font-weight:bold;")
            layout.addWidget(crash_label)

            self._crash_area = QScrollArea()
            self._crash_area.setWidgetResizable(True)
            self._crash_area.setMaximumHeight(100)
            self._crash_widget = QWidget()
            self._crash_layout = QVBoxLayout(self._crash_widget)
            self._crash_layout.setContentsMargins(2, 2, 2, 2)
            self._crash_layout.setSpacing(2)
            self._crash_layout.addStretch()
            self._crash_area.setWidget(self._crash_widget)
            layout.addWidget(self._crash_area)

            # ── S11: Patterns section ──
            pat_label = QLabel("Gelernte Muster")
            pat_label.setStyleSheet("color:#aaa; font-size:11px; font-weight:bold;")
            layout.addWidget(pat_label)

            self._pat_area = QScrollArea()
            self._pat_area.setWidgetResizable(True)
            self._pat_area.setMaximumHeight(100)
            self._pat_widget = QWidget()
            self._pat_layout = QVBoxLayout(self._pat_widget)
            self._pat_layout.setContentsMargins(2, 2, 2, 2)
            self._pat_layout.setSpacing(2)
            self._pat_layout.addStretch()
            self._pat_area.setWidget(self._pat_widget)
            layout.addWidget(self._pat_area)

            # ── S12: Pre-Show result / Post-Show report ──
            self._lbl_preshow = QLabel("")
            self._lbl_preshow.setStyleSheet("color:#888; font-size:10px;")
            self._lbl_preshow.setWordWrap(True)
            self._lbl_preshow.setVisible(False)
            layout.addWidget(self._lbl_preshow)

            # Stats
            self._lbl_stats = QLabel("")
            self._lbl_stats.setStyleSheet("color:#666; font-size:10px;")
            layout.addWidget(self._lbl_stats)

            layout.addStretch()

        def set_services(self, recorder=None, anomaly=None) -> None:
            self._recorder = recorder
            self._anomaly = anomaly
            try:
                from pydaw.services.sentinel_db import SentinelDB
                self._db = SentinelDB.get()
                self._db.ensure_loaded()
            except Exception:
                pass

        def showEvent(self, event):
            super().showEvent(event)
            self._refresh_timer.start()
            self._refresh()

        def hideEvent(self, event):
            super().hideEvent(event)
            self._refresh_timer.stop()

        # ── S12: Live Mode ──

        def _toggle_live_mode(self):
            self._live_mode = not self._live_mode
            if self._live_mode:
                self._btn_live.setText("LIVE MODE: ON")
                self._btn_live.setStyleSheet(
                    "background:#4a1a1a; color:#f88; border:1px solid #f44; "
                    "border-radius:4px; padding:3px 8px; font-size:11px; font-weight:bold;"
                )
                self._session_start = time.time()
                self._session_anomalies = 0
                self._session_xruns = 0
                # Notify anomaly detector
                if self._anomaly and hasattr(self._anomaly, '_live_mode'):
                    self._anomaly._live_mode = True
                log.info("[SENTINEL] Live Mode ACTIVATED — no auto-isolation")
            else:
                self._btn_live.setText("LIVE MODE: OFF")
                self._btn_live.setStyleSheet(
                    "background:#333; color:#999; border:1px solid #555; "
                    "border-radius:4px; padding:3px 8px; font-size:11px;"
                )
                if self._anomaly and hasattr(self._anomaly, '_live_mode'):
                    self._anomaly._live_mode = False
                # Show post-show report
                self._show_post_show_report()
                log.info("[SENTINEL] Live Mode DEACTIVATED")

        def _pre_show_check(self):
            """S12: Run pre-show system check."""
            issues = []
            ok_items = []

            # CPU baseline
            if self._recorder and self._recorder._ringbuffer:
                last = self._recorder._ringbuffer[-1]
                cpu = last.get("cpu", 0)
                if cpu > 60:
                    issues.append(f"CPU aktuell bei {cpu:.0f}% (empfohlen: <60%)")
                else:
                    ok_items.append(f"CPU: {cpu:.0f}%")

                mem = last.get("mem_mb", 0)
                if mem > 4000:
                    issues.append(f"RAM: {mem:.0f} MB (hoch)")
                else:
                    ok_items.append(f"RAM: {mem:.0f} MB")

            # Disk space
            try:
                import shutil
                usage = shutil.disk_usage(".")
                free_gb = usage.free / (1024**3)
                if free_gb < 1.0:
                    issues.append(f"Disk: nur {free_gb:.1f} GB frei!")
                else:
                    ok_items.append(f"Disk: {free_gb:.1f} GB frei")
            except Exception:
                pass

            # Active anomalies
            if self._db:
                active = self._db.get_active_anomalies()
                if active:
                    issues.append(f"{len(active)} aktive Anomalie(n)")
                else:
                    ok_items.append("Keine aktiven Anomalien")

            # API server
            try:
                from pydaw.services.sentinel_api import SentinelAPIServer
                api = SentinelAPIServer.get()
                if api.is_running:
                    ok_items.append(f"API: Port {api.port}")
            except Exception:
                pass

            # Build result
            if not issues:
                result = "Pre-Show Check: ALLES BEREIT\n" + "\n".join(f"  {x}" for x in ok_items)
                self._lbl_preshow.setStyleSheet("color:#8f8; font-size:10px;")
            else:
                result = ("Pre-Show Check: WARNUNG\n" +
                          "\n".join(f"  {x}" for x in issues) + "\n" +
                          "\n".join(f"  {x}" for x in ok_items))
                self._lbl_preshow.setStyleSheet("color:#ff8; font-size:10px;")
            self._lbl_preshow.setText(result)
            self._lbl_preshow.setVisible(True)

        def _show_post_show_report(self):
            """S12: Generate post-show summary."""
            duration = time.time() - self._session_start
            mins = int(duration / 60)

            # Gather session stats
            xruns = 0
            if self._recorder and self._recorder._ringbuffer:
                xruns = self._recorder._ringbuffer[-1].get("xruns", 0)

            crash_count = 0
            if self._db:
                crashes = self._db.get_crashes(limit=50)
                crash_count = sum(1 for c in crashes
                                  if c.get("crash_time", 0) > self._session_start)

            if crash_count == 0 and xruns < 3:
                report = f"Post-Show Report ({mins} min): Keine Probleme"
                self._lbl_preshow.setStyleSheet("color:#8f8; font-size:10px;")
            else:
                parts = [f"Post-Show Report ({mins} min):"]
                if xruns:
                    parts.append(f"  XRuns: {xruns}")
                if crash_count:
                    parts.append(f"  Crashes: {crash_count}")
                if self._session_anomalies:
                    parts.append(f"  Warnungen: {self._session_anomalies}")
                report = "\n".join(parts)
                self._lbl_preshow.setStyleSheet("color:#ff8; font-size:10px;")

            self._lbl_preshow.setText(report)
            self._lbl_preshow.setVisible(True)

        # ── Refresh ──

        def _refresh(self):
            now = time.time()
            # Metrics
            if self._recorder and self._recorder._ringbuffer:
                last = self._recorder._ringbuffer[-1]
                cpu_val = last.get("cpu", 0)
                mem_val = last.get("mem_mb", 0)
                self._lbl_cpu.setText(f"Python-CPU: {cpu_val:.0f}%")
                self._lbl_mem.setText(f"RAM: {mem_val:.0f} MB")
                self._lbl_xruns.setText(f"XRuns: {last.get('xruns', 0)}")
                self._lbl_threads.setText(f"Threads: {last.get('threads', 0)}")

                # S11: Update CPU history (keep 5 min at 3s intervals = 100 points)
                self._cpu_history.append((now, cpu_val))
                self._mem_history.append((now, mem_val))
                cutoff = now - 300.0
                self._cpu_history = [(t, v) for t, v in self._cpu_history if t > cutoff]
                self._mem_history = [(t, v) for t, v in self._mem_history if t > cutoff]
                self._cpu_graph.set_data(self._cpu_history, self._mem_history)

            # Status
            if self._anomaly:
                status = self._anomaly.get_health_status()
                colors = {"healthy": "#8f8", "warning": "#ff0", "critical": "#f66"}
                mode_str = " [LIVE]" if self._live_mode else ""
                self._lbl_status.setText(f"Status: {status.upper()}{mode_str}")
                self._lbl_status.setStyleSheet(
                    f"color:{colors.get(status, '#8f8')}; font-size:12px; font-weight:bold;"
                )

            # API status
            try:
                from pydaw.services.sentinel_api import SentinelAPIServer
                api = SentinelAPIServer.get()
                if api.is_running:
                    self._lbl_api.setText(f"API: :{api.port}")
                    self._lbl_api.setStyleSheet("color:#8f8; font-size:11px;")
                else:
                    self._lbl_api.setText("API: off")
                    self._lbl_api.setStyleSheet("color:#666; font-size:11px;")
            except Exception:
                self._lbl_api.setText("API: --")

            # Anomalies
            if self._db:
                self._update_list(
                    self._anom_layout,
                    self._db.get_active_anomalies(),
                    lambda a: f"[Sev {a.get('severity',1)}] {a.get('anomaly_type','')} — {a.get('description','')}",
                    "#3a2a2a",
                )

                crashes = self._db.get_crashes(limit=10)
                self._update_list(
                    self._crash_layout,
                    crashes,
                    lambda c: f"{c.get('crash_type','')} in {c.get('component','')} — {c.get('error_message','')[:60]}",
                    "#2a2a3a",
                )

                # S11: Patterns
                patterns = self._db.get_patterns(limit=10)
                self._update_list(
                    self._pat_layout,
                    patterns,
                    lambda p: (f"[{p.get('confidence',0):.0%}] {p.get('description','')} "
                               f"(×{p.get('occurrences',1)})"),
                    "#2a302a",
                )

                stats = self._db.stats()
                self._lbl_stats.setText(
                    f"Events: {stats.get('sentinel_events', 0)} | "
                    f"Anomalien: {stats.get('sentinel_anomalies', 0)} | "
                    f"Crashes: {stats.get('sentinel_crashes', 0)} | "
                    f"Patterns: {stats.get('sentinel_patterns', 0)}"
                )

        def _update_list(self, layout, items, formatter, bg_color):
            while layout.count() > 1:
                item = layout.takeAt(0)
                w = item.widget()
                if w:
                    w.deleteLater()

            for i, item in enumerate(items[:10]):
                lbl = QLabel(formatter(item))
                lbl.setStyleSheet(
                    f"background: {bg_color}; color: #ccc; "
                    f"font-size: 10px; padding: 3px 6px; "
                    f"border-radius: 3px; margin: 1px;"
                )
                lbl.setWordWrap(True)
                layout.insertWidget(i, lbl)

            if not items:
                lbl = QLabel("Keine Eintraege")
                lbl.setStyleSheet("color:#666; font-size:10px; padding:4px;")
                layout.insertWidget(0, lbl)

    # ──────────────────────────────────────────────────────

    class _CPUGraphWidget(QWidget):
        """S11: Mini CPU+RAM history graph (last 5 min, QPainter)."""

        def __init__(self, parent=None):
            super().__init__(parent)
            self._cpu_data: list = []  # [(t, val)]
            self._mem_data: list = []
            self.setMinimumHeight(60)

        def set_data(self, cpu_data: list, mem_data: list) -> None:
            self._cpu_data = cpu_data
            self._mem_data = mem_data
            self.update()

        def paintEvent(self, event):
            p = QPainter(self)
            p.setRenderHint(QPainter.RenderHint.Antialiasing)
            w, h = self.width(), self.height()

            # Background
            p.fillRect(0, 0, w, h, QColor(30, 30, 36))

            # Grid lines at 25%, 50%, 75%
            p.setPen(QPen(QColor(50, 50, 60), 1))
            for pct in (0.25, 0.5, 0.75):
                y = int(h * (1 - pct))
                p.drawLine(0, y, w, y)

            # Labels
            p.setPen(QPen(QColor(80, 80, 100), 1))
            fnt = p.font()
            fnt.setPixelSize(9)
            p.setFont(fnt)
            p.drawText(2, int(h * 0.25) - 2, "75%")
            p.drawText(2, int(h * 0.50) - 2, "50%")
            p.drawText(2, int(h * 0.75) - 2, "25%")

            # Draw CPU line (blue)
            self._draw_line(p, self._cpu_data, w, h, QColor(100, 180, 255), 100.0)
            # Draw Memory line (green, normalized to 8GB max)
            self._draw_line(p, self._mem_data, w, h, QColor(100, 200, 100, 120), 8000.0)

            # Legend
            p.setPen(QPen(QColor(100, 180, 255), 1))
            p.drawText(w - 90, 12, "CPU")
            p.setPen(QPen(QColor(100, 200, 100), 1))
            p.drawText(w - 50, 12, "RAM")

            p.end()

        def _draw_line(self, painter, data, w, h, color, max_val):
            if len(data) < 2:
                return
            now = time.time()
            span = 300.0  # 5 minutes
            painter.setPen(QPen(color, 1.5))
            points = []
            for t, v in data:
                x = int(((t - (now - span)) / span) * w)
                y = int(h * (1.0 - min(v / max_val, 1.0)))
                points.append((x, y))
            for i in range(1, len(points)):
                x0, y0 = points[i - 1]
                x1, y1 = points[i]
                painter.drawLine(x0, y0, x1, y1)

else:
    class SentinelStatusWidget:
        def __init__(self, *a, **kw): pass

    class SentinelAlertBanner:
        def __init__(self, *a, **kw): pass

    class SentinelDashboard:
        def __init__(self, *a, **kw): pass
