"""
pydaw.services.flux_vault_factory_random — V-2 Random/Algorithmic Factory-Presets

**v0.0.21.229 — Random v1 (Algorithmic-Composition-Edition)**
=============================================================

Anno-Direktive (2026-05-04, mit PD-Patch-Vergleich Bilder 09:30,
10:55, 10:58 + dem Bug „flux macht random nichts in frequenz"):
„Vault Load → docs/demo_patches/osc_listener_demo.json gibt es nicht
behebe dies mache noch paar patches random kuck mal in die bilder".

Diese Factory liefert 6 algorithmische Random-Patches die PD's
``metro → random → arithmetik → osc~`` Workflows in FLUX abbilden.
Alle nutzen den v.229 Sample-and-Hold-Forward-Bridge — Random-Werte
modulieren jetzt korrekt SineOsc.frequency etc. (vorher kollabierte
die Pulse-Bridge alle Werte zu 1.0).

| Preset | Charakter | Algorithmus |
|---|---|---|
| Random-Beep | bleeper sequencer | Metro → Random(8) → +60 → Mtof → Sine |
| Algorithmic-Drone | atmosphäre + zufalls-pitch | Metro slow → Random → Mtof → Saw + Reverb |
| Bit-Hopper | 8-bit arpeggio | Metro fast → Random(16) → +48 → Mtof → Square + Delay |
| Random-Glitch | stochastische bursts | Metro burst → Random → Plus → Mtof → BitCrush |
| Bach-KI-Light | random walk over scale | Metro → Random → Clip → +60 → Mtof → Sine + Reverb |
| OSC-Driven-Synth | externes OSC steuert pitch | Hermod.OscReceive(/synth/freq) → Sine |

Versions-Marker ``"FLUX Factory (Random v1)"`` für sauberes
Re-Seeding.

NICHTS-KAPUTT: rein additiv, keine bestehenden Presets verändert.
"""
from __future__ import annotations

import logging
from typing import Optional

logger = logging.getLogger(__name__)


RANDOM_FACTORY_VERSION = "v1"
RANDOM_FACTORY_AUTHOR = (
    f"FLUX Factory (Random {RANDOM_FACTORY_VERSION})"
)


# ─── Helper ───────────────────────────────────────────────────────


def _connect(patch, src_id: str, src_port: str,
             tgt_id: str, tgt_port: str) -> bool:
    """Helper: Connection hinzufügen, defensiv gegen fehlende Module."""
    from pydaw.flux.patch_model import Connection
    src = patch.get_module(src_id)
    tgt = patch.get_module(tgt_id)
    if src is None or tgt is None:
        return False
    patch.add_connection(Connection(
        source_module=src_id, source_port=src_port,
        target_module=tgt_id, target_port=tgt_port,
    ))
    return True


def _set(module, **params) -> None:
    """Helper: Param-Update mit defensiv-Override."""
    for k, v in params.items():
        module.params[k] = v


def _build_patch_dict(name: str, builder) -> Optional[dict]:
    """Wrapper: builder ausführen + zu dict serialisieren."""
    from pydaw.flux.patch_model import Patch
    try:
        p = builder()
        if not isinstance(p, Patch):
            return None
        p.name = name
        return p.to_dict()
    except Exception as e:
        logger.warning("[RandomPresets-v1] build %s failed: %s", name, e)
        return None


# ─── Patch-Builder ────────────────────────────────────────────────


def _build_random_beep():
    """Random-Beep — Annos PD-Patch 1:1 als Vault-Preset.

    PD: ``metro 250 → random 8 → + 60 → mtof → osc~ frequency``
    FLUX: Norns.Metro(4Hz) → Ullr.Random(0-7) → Ullr.Plus(+60)
          → Ratatosk.Mtof → Bragi.SineOsc.frequency

    Erzeugt eine zufällige Note-Sequenz in C4-G4-Range mit 4Hz Tempo.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_norns_metro, make_ullr_random, make_ullr_plus,
        make_ratatosk_mtof, make_bragi_sine_osc,
        make_forseti_lowpass, make_iduna_reverb,
        make_heimdall_master_out,
    )
    p = Patch(name="Random-Beep")
    metro = make_norns_metro(); metro.position = (60, 200)
    _set(metro, rate_hz=4.0)
    rnd = make_ullr_random(); rnd.position = (240, 200)
    _set(rnd, max_value=8.0)  # 0-7 → 8 verschiedene Pitches
    plus = make_ullr_plus(); plus.position = (420, 200)
    _set(plus, b=60.0)  # MIDI 60 = C4
    mtof = make_ratatosk_mtof(); mtof.position = (600, 200)
    sine = make_bragi_sine_osc(); sine.position = (780, 200)
    _set(sine, gain=0.3)
    flt = make_forseti_lowpass(); flt.position = (960, 200)
    _set(flt, cutoff=4000.0, resonance=0.2)
    rev = make_iduna_reverb(); rev.position = (1140, 200)
    _set(rev, room_size=0.5, damping=0.5, mix=0.25)
    out = make_heimdall_master_out(); out.position = (1320, 200)
    for m in (metro, rnd, plus, mtof, sine, flt, rev, out):
        p.add_module(m)
    _connect(p, metro.id, "rune_out", rnd.id, "trigger")
    _connect(p, rnd.id, "rune_out", plus.id, "rune_in")
    _connect(p, plus.id, "rune_out", mtof.id, "rune_in")
    _connect(p, mtof.id, "rune_out", sine.id, "freq")
    _connect(p, sine.id, "audio_out", flt.id, "audio_in")
    _connect(p, flt.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_algorithmic_drone():
    """Algorithmic-Drone — slow-evolving zufalls-pitch + huge reverb.

    Langsamer Metro (1Hz), kleine Random-Range (0-3 = 4 Pitches),
    Saw durch Lowpass + großer Iduna.Reverb. Atmosphärisch.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_norns_metro, make_ullr_random, make_ullr_plus,
        make_ratatosk_mtof, make_bragi_saw_osc,
        make_forseti_lowpass, make_iduna_reverb,
        make_heimdall_master_out,
    )
    p = Patch(name="Algorithmic-Drone")
    metro = make_norns_metro(); metro.position = (60, 200)
    _set(metro, rate_hz=1.0)  # 1 Note pro Sekunde
    rnd = make_ullr_random(); rnd.position = (240, 200)
    _set(rnd, max_value=4.0)  # 4 Pitches
    plus = make_ullr_plus(); plus.position = (420, 200)
    _set(plus, b=48.0)  # MIDI 48 = C3 (tief)
    mtof = make_ratatosk_mtof(); mtof.position = (600, 200)
    saw = make_bragi_saw_osc(); saw.position = (780, 200)
    _set(saw, gain=0.25)
    flt = make_forseti_lowpass(); flt.position = (960, 200)
    _set(flt, cutoff=1500.0, resonance=0.3)
    rev = make_iduna_reverb(); rev.position = (1140, 200)
    _set(rev, room_size=0.95, damping=0.3, mix=0.6)  # huge
    out = make_heimdall_master_out(); out.position = (1320, 200)
    for m in (metro, rnd, plus, mtof, saw, flt, rev, out):
        p.add_module(m)
    _connect(p, metro.id, "rune_out", rnd.id, "trigger")
    _connect(p, rnd.id, "rune_out", plus.id, "rune_in")
    _connect(p, plus.id, "rune_out", mtof.id, "rune_in")
    _connect(p, mtof.id, "rune_out", saw.id, "freq")
    _connect(p, saw.id, "audio_out", flt.id, "audio_in")
    _connect(p, flt.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_bit_hopper():
    """Bit-Hopper — 8-bit-Arcade-Arpeggio mit Slap-Delay.

    Schneller Metro (12Hz), 16 Pitches, Square-Osc, Decimator/BitCrush
    für 8-bit Charakter, Slap-Delay.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_norns_metro, make_ullr_random, make_ullr_plus,
        make_ratatosk_mtof, make_bragi_square_osc,
        make_iduna_delay, make_heimdall_master_out,
    )
    p = Patch(name="Bit-Hopper")
    metro = make_norns_metro(); metro.position = (60, 200)
    _set(metro, rate_hz=12.0)  # schnell
    rnd = make_ullr_random(); rnd.position = (240, 200)
    _set(rnd, max_value=16.0)
    plus = make_ullr_plus(); plus.position = (420, 200)
    _set(plus, b=48.0)  # MIDI 48-63
    mtof = make_ratatosk_mtof(); mtof.position = (600, 200)
    sq = make_bragi_square_osc(); sq.position = (780, 200)
    _set(sq, gain=0.2)
    delay = make_iduna_delay(); delay.position = (960, 200)
    _set(delay, time=0.083, feedback=0.4, mix=0.35, tone=4500.0)  # slap
    out = make_heimdall_master_out(); out.position = (1140, 200)
    for m in (metro, rnd, plus, mtof, sq, delay, out):
        p.add_module(m)
    _connect(p, metro.id, "rune_out", rnd.id, "trigger")
    _connect(p, rnd.id, "rune_out", plus.id, "rune_in")
    _connect(p, plus.id, "rune_out", mtof.id, "rune_in")
    _connect(p, mtof.id, "rune_out", sq.id, "freq")
    _connect(p, sq.id, "audio_out", delay.id, "audio_in")
    _connect(p, delay.id, "audio_out", out.id, "audio_in_l")
    _connect(p, delay.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_random_glitch():
    """Random-Glitch — stochastische Bursts mit Saturation.

    Sehr schneller Metro (20Hz), wide Random-Range (32), Sine durch
    Thor.Saturation. Klingt wie kaputter Sequencer.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_norns_metro, make_ullr_random, make_ullr_plus,
        make_ratatosk_mtof, make_bragi_sine_osc,
        make_thor_saturation, make_iduna_delay,
        make_heimdall_master_out,
    )
    p = Patch(name="Random-Glitch")
    metro = make_norns_metro(); metro.position = (60, 200)
    _set(metro, rate_hz=20.0)
    rnd = make_ullr_random(); rnd.position = (240, 200)
    _set(rnd, max_value=32.0)
    plus = make_ullr_plus(); plus.position = (420, 200)
    _set(plus, b=48.0)  # MIDI 48-79 (C3-G5, breit)
    mtof = make_ratatosk_mtof(); mtof.position = (600, 200)
    sine = make_bragi_sine_osc(); sine.position = (780, 200)
    _set(sine, gain=0.3)
    sat = make_thor_saturation(); sat.position = (960, 200)
    _set(sat, drive=4.0, mix=0.7)
    delay = make_iduna_delay(); delay.position = (1140, 200)
    _set(delay, time=0.125, feedback=0.55, mix=0.4)
    out = make_heimdall_master_out(); out.position = (1320, 200)
    for m in (metro, rnd, plus, mtof, sine, sat, delay, out):
        p.add_module(m)
    _connect(p, metro.id, "rune_out", rnd.id, "trigger")
    _connect(p, rnd.id, "rune_out", plus.id, "rune_in")
    _connect(p, plus.id, "rune_out", mtof.id, "rune_in")
    _connect(p, mtof.id, "rune_out", sine.id, "freq")
    _connect(p, sine.id, "audio_out", sat.id, "audio_in")
    _connect(p, sat.id, "audio_out", delay.id, "audio_in")
    _connect(p, delay.id, "audio_out", out.id, "audio_in_l")
    _connect(p, delay.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_bach_ki_light():
    """Bach-KI-Light — random walk in eingeschränktem Range (Tonika).

    Random clamped via Ullr.Clip auf 0-12 (Oktav-Range), dann +60.
    Ergibt eine Melodie die immer in C-Dur-Range bleibt. Klingt
    musikalischer als unbeschränkter Random.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_norns_metro, make_ullr_random, make_ullr_clip,
        make_ullr_plus, make_ratatosk_mtof,
        make_bragi_sine_osc, make_forseti_lowpass,
        make_iduna_reverb, make_heimdall_master_out,
    )
    p = Patch(name="Bach-KI-Light")
    metro = make_norns_metro(); metro.position = (60, 200)
    _set(metro, rate_hz=3.0)
    rnd = make_ullr_random(); rnd.position = (240, 200)
    _set(rnd, max_value=24.0)  # breit
    clip = make_ullr_clip(); clip.position = (420, 200)
    _set(clip, lo=0.0, hi=12.0)  # auf Oktave begrenzen
    plus = make_ullr_plus(); plus.position = (600, 200)
    _set(plus, b=60.0)  # C4 als Tonika
    mtof = make_ratatosk_mtof(); mtof.position = (780, 200)
    sine = make_bragi_sine_osc(); sine.position = (960, 200)
    _set(sine, gain=0.35)
    flt = make_forseti_lowpass(); flt.position = (1140, 200)
    _set(flt, cutoff=3500.0, resonance=0.15)
    rev = make_iduna_reverb(); rev.position = (1320, 200)
    _set(rev, room_size=0.7, damping=0.5, mix=0.4)
    out = make_heimdall_master_out(); out.position = (1500, 200)
    for m in (metro, rnd, clip, plus, mtof, sine, flt, rev, out):
        p.add_module(m)
    _connect(p, metro.id, "rune_out", rnd.id, "trigger")
    _connect(p, rnd.id, "rune_out", clip.id, "rune_in")
    _connect(p, clip.id, "rune_out", plus.id, "rune_in")
    _connect(p, plus.id, "rune_out", mtof.id, "rune_in")
    _connect(p, mtof.id, "rune_out", sine.id, "freq")
    _connect(p, sine.id, "audio_out", flt.id, "audio_in")
    _connect(p, flt.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    return p


def _build_osc_driven_synth():
    """OSC-Driven-Synth — externer Sender steuert SineOsc.frequency.

    Hermod.OscReceive(:9000) → OscPath(/synth/freq) → SineOsc.freq.
    Test extern: ``oscsend localhost 9000 /synth/freq f 440.0``.

    Demo für Anno's PD-OSC-Workflow (Bild 10:55) als Vault-Preset.
    """
    from pydaw.flux.patch_model import Patch
    from pydaw.flux.module_library import (
        make_hermod_osc_receive, make_hermod_osc_path,
        make_hermod_osc_print, make_bragi_sine_osc,
        make_forseti_lowpass, make_iduna_reverb,
        make_heimdall_master_out,
    )
    p = Patch(name="OSC-Driven-Synth")
    recv = make_hermod_osc_receive(); recv.position = (60, 100)
    _set(recv, port=9000.0)
    path = make_hermod_osc_path(); path.position = (260, 100)
    path.params["path_pattern"] = "/synth/freq"
    debug = make_hermod_osc_print(); debug.position = (60, 280)
    debug.params["prefix"] = "[OSC-Synth]"
    sine = make_bragi_sine_osc(); sine.position = (480, 200)
    _set(sine, gain=0.4, freq=440.0)
    flt = make_forseti_lowpass(); flt.position = (660, 200)
    _set(flt, cutoff=3000.0, resonance=0.2)
    rev = make_iduna_reverb(); rev.position = (840, 200)
    _set(rev, room_size=0.6, damping=0.4, mix=0.3)
    out = make_heimdall_master_out(); out.position = (1020, 200)
    for m in (recv, path, debug, sine, flt, rev, out):
        p.add_module(m)
    _connect(p, recv.id, "rune_out", path.id, "rune_in")
    _connect(p, recv.id, "rune_out", debug.id, "rune_in")
    # OscPath emittiert single-arg /synth/freq als float-message;
    # Sample-and-Hold-Bridge (v.229) reicht den Wert an SineOsc.freq
    _connect(p, path.id, "match_out", sine.id, "freq")
    _connect(p, sine.id, "audio_out", flt.id, "audio_in")
    _connect(p, flt.id, "audio_out", rev.id, "audio_in")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_l")
    _connect(p, rev.id, "audio_out", out.id, "audio_in_r")
    return p


# ─── Build-All ────────────────────────────────────────────────────


def _build_all() -> list[dict]:
    """Build all Random presets. Each preset is dict with metadata."""
    builders = [
        ("Random-Beep",
         "PD-Klassiker: metro→random→+60→mtof→sine. C4-G4 Bleeper-Sequenz.",
         ["random", "metro", "sine", "pd-style"], "C4", _build_random_beep),
        ("Algorithmic-Drone",
         "Slow-evolving Saw mit huge Reverb, 4 Pitches, atmosphärisch.",
         ["random", "drone", "saw", "reverb", "atmospheric"], "C3",
         _build_algorithmic_drone),
        ("Bit-Hopper",
         "12Hz Square-Arpeggio mit Slap-Delay — 8-bit Arcade-Charakter.",
         ["random", "arpeggio", "square", "8bit", "delay"], "C3",
         _build_bit_hopper),
        ("Random-Glitch",
         "20Hz Bursts mit Saturation+Delay — kaputter Sequencer.",
         ["random", "glitch", "saturation", "burst", "experimental"], "C3",
         _build_random_glitch),
        ("Bach-KI-Light",
         "Random walk geclamped auf Oktav-Range, Tonika C4 — musikalisch.",
         ["random", "melody", "clamped", "musical", "walking-bass"], "C4",
         _build_bach_ki_light),
        ("OSC-Driven-Synth",
         "External OSC controller drives SineOsc.frequency. Test: "
         "oscsend localhost 9000 /synth/freq f 440.0",
         ["osc", "external", "remote", "control"], "A4",
         _build_osc_driven_synth),
    ]

    presets = []
    for name, desc, tags, key, builder in builders:
        patch_dict = _build_patch_dict(name, builder)
        if patch_dict is None:
            logger.warning("[RandomPresets-v1] %s skipped (build failed)", name)
            continue
        presets.append({
            "name": name,
            "description": desc,
            "tags": tags,
            "musical_key": key,
            "bpm": None,
            "author": RANDOM_FACTORY_AUTHOR,
            "icon_svg": "",
            "patch": patch_dict,
        })
    return presets


class _LazyPresetList:
    """Wrapper: baut die Patches erst beim ersten Iterieren."""

    def __init__(self):
        self._cache: Optional[list[dict]] = None

    def _ensure(self) -> list[dict]:
        if self._cache is None:
            self._cache = _build_all()
            logger.info(
                "[RandomPresets-v1] built %d Random presets (%s) lazily",
                len(self._cache), RANDOM_FACTORY_VERSION,
            )
        return self._cache

    def __iter__(self):
        return iter(self._ensure())

    def __len__(self):
        return len(self._ensure())

    def __getitem__(self, i):
        return self._ensure()[i]


RANDOM_PRESETS = _LazyPresetList()


__all__ = [
    "RANDOM_PRESETS",
    "RANDOM_FACTORY_VERSION",
    "RANDOM_FACTORY_AUTHOR",
]
