"""video_multi_service.py — VP10: Multi-Video + A/B Vergleich (v0.0.20.925).

Manages multiple video streams simultaneously:
- Multiple video tracks with independent playback
- A/B comparison (split-view)
- Multi-camera switching (cut between angles)
- Picture-in-Picture (PiP) compositing
- ffmpeg export with multi-video compositing

Architecture:
    - VideoSlot: one loaded video with position/size
    - MultiVideoMixer: combines slots into output frame
    - A/B mode: two slots side-by-side or overlay
    - PiP mode: one slot small in corner of main
    - Multi-cam: switch active camera via timeline markers

Usage:
    from pydaw.services.video_multi_service import MultiVideoService, VideoSlot

    svc = MultiVideoService.instance()
    svc.add_slot("A", "/path/to/video_a.mp4")
    svc.add_slot("B", "/path/to/video_b.mp4")
    svc.set_mode("split_h")  # horizontal split A/B
    svc.set_pip("B", position="bottom_right", scale=0.3)
    ffmpeg_cmd = svc.get_ffmpeg_export_cmd(output_path)
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Tuple

log = logging.getLogger(__name__)


# ── Data Classes ────────────────────────────────────────────────


@dataclass
class VideoSlot:
    """A single video source in the multi-video mixer."""
    slot_id: str = "A"             # "A", "B", "C", etc.
    video_path: str = ""
    label: str = ""                # display name
    enabled: bool = True
    # Position/Size in composition (normalized 0..1)
    x: float = 0.0
    y: float = 0.0
    width: float = 1.0
    height: float = 1.0
    # Timing
    offset_seconds: float = 0.0   # start offset in source video
    duration_seconds: float = 0.0  # 0 = use full video
    # Visual
    opacity: float = 1.0          # 0.0 .. 1.0
    z_order: int = 0              # higher = on top
    border_width: int = 0
    border_color: str = "#ffffff"

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> VideoSlot:
        return cls(**{k: d[k] for k in cls.__dataclass_fields__ if k in d})


@dataclass
class CameraCut:
    """A point in time where the active camera switches."""
    time_seconds: float = 0.0
    time_beats: float = 0.0
    from_slot: str = "A"
    to_slot: str = "B"
    transition: str = "cut"        # "cut", "dissolve", "wipe_left", "wipe_right"
    transition_duration: float = 0.0  # seconds (0 = hard cut)
    label: str = ""

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> CameraCut:
        return cls(**{k: d[k] for k in cls.__dataclass_fields__ if k in d})


@dataclass
class PiPConfig:
    """Picture-in-Picture configuration."""
    enabled: bool = False
    slot_id: str = "B"             # which slot is the PiP
    position: str = "bottom_right"  # "top_left", "top_right", "bottom_left", "bottom_right", "custom"
    scale: float = 0.25            # size relative to output (0.1 .. 0.5)
    margin: float = 0.02           # margin from edge (normalized)
    border_width: int = 2
    border_color: str = "#ffffff"
    opacity: float = 1.0
    shadow: bool = True
    # Custom position (only if position == "custom")
    custom_x: float = 0.7
    custom_y: float = 0.7

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> PiPConfig:
        return cls(**{k: d[k] for k in cls.__dataclass_fields__ if k in d})

    @property
    def position_coords(self) -> Tuple[float, float]:
        """Get normalized (x, y) for PiP position."""
        m = self.margin
        s = self.scale
        positions = {
            "top_left": (m, m),
            "top_right": (1.0 - s - m, m),
            "bottom_left": (m, 1.0 - s - m),
            "bottom_right": (1.0 - s - m, 1.0 - s - m),
            "custom": (self.custom_x, self.custom_y),
        }
        return positions.get(self.position, (1.0 - s - m, 1.0 - s - m))


# ── Main Service ───────────────────────────────────────────────


class MultiVideoService:
    """VP10: Multi-Video + A/B Comparison Service.

    Singleton. Manages multiple video slots and compositing modes.
    """

    _instance: Optional[MultiVideoService] = None

    # Compositing modes
    MODE_SINGLE = "single"         # Only slot A visible
    MODE_SPLIT_H = "split_h"      # Horizontal split (A left, B right)
    MODE_SPLIT_V = "split_v"      # Vertical split (A top, B bottom)
    MODE_OVERLAY = "overlay"       # B overlaid on A with opacity
    MODE_PIP = "pip"              # A fullscreen, B as PiP
    MODE_MULTICAM = "multicam"    # Switch between slots via CameraCuts

    VALID_MODES = {MODE_SINGLE, MODE_SPLIT_H, MODE_SPLIT_V,
                   MODE_OVERLAY, MODE_PIP, MODE_MULTICAM}

    @classmethod
    def instance(cls) -> MultiVideoService:
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._slots: Dict[str, VideoSlot] = {}
        self._mode: str = self.MODE_SINGLE
        self._pip: PiPConfig = PiPConfig()
        self._camera_cuts: List[CameraCut] = []
        self._active_slot: str = "A"
        self._output_width: int = 1920
        self._output_height: int = 1080

    # ── Slot Management ──────────────────────────────────────

    def add_slot(self, slot_id: str, video_path: str,
                 label: str = "") -> VideoSlot:
        """Add a video source slot."""
        slot = VideoSlot(
            slot_id=slot_id,
            video_path=video_path,
            label=label or f"Video {slot_id}",
        )
        self._slots[slot_id] = slot
        log.info("[VP10] Added slot %s: %s", slot_id, video_path)
        return slot

    def remove_slot(self, slot_id: str) -> bool:
        """Remove a video slot."""
        if slot_id in self._slots:
            del self._slots[slot_id]
            # Clean up camera cuts referencing this slot
            self._camera_cuts = [
                c for c in self._camera_cuts
                if c.from_slot != slot_id and c.to_slot != slot_id
            ]
            return True
        return False

    def get_slot(self, slot_id: str) -> Optional[VideoSlot]:
        return self._slots.get(slot_id)

    def list_slots(self) -> List[VideoSlot]:
        return list(self._slots.values())

    # ── Mode Control ─────────────────────────────────────────

    def set_mode(self, mode: str) -> None:
        """Set compositing mode."""
        if mode not in self.VALID_MODES:
            log.warning("[VP10] Invalid mode: %s", mode)
            return
        self._mode = mode
        self._update_slot_positions()
        log.info("[VP10] Mode set to: %s", mode)

    @property
    def mode(self) -> str:
        return self._mode

    def _update_slot_positions(self) -> None:
        """Update slot positions based on current mode."""
        slots = sorted(self._slots.values(), key=lambda s: s.slot_id)
        if not slots:
            return

        if self._mode == self.MODE_SINGLE:
            for s in slots:
                s.x, s.y, s.width, s.height = 0, 0, 1, 1
                s.enabled = (s.slot_id == self._active_slot)

        elif self._mode == self.MODE_SPLIT_H:
            if len(slots) >= 2:
                slots[0].x, slots[0].y = 0, 0
                slots[0].width, slots[0].height = 0.5, 1.0
                slots[0].enabled = True
                slots[1].x, slots[1].y = 0.5, 0
                slots[1].width, slots[1].height = 0.5, 1.0
                slots[1].enabled = True

        elif self._mode == self.MODE_SPLIT_V:
            if len(slots) >= 2:
                slots[0].x, slots[0].y = 0, 0
                slots[0].width, slots[0].height = 1.0, 0.5
                slots[0].enabled = True
                slots[1].x, slots[1].y = 0, 0.5
                slots[1].width, slots[1].height = 1.0, 0.5
                slots[1].enabled = True

        elif self._mode == self.MODE_OVERLAY:
            for s in slots:
                s.x, s.y, s.width, s.height = 0, 0, 1, 1
                s.enabled = True
            if len(slots) >= 2:
                slots[1].opacity = 0.5

        elif self._mode == self.MODE_PIP:
            if len(slots) >= 2:
                # Main
                slots[0].x, slots[0].y = 0, 0
                slots[0].width, slots[0].height = 1, 1
                slots[0].enabled = True
                # PiP
                px, py = self._pip.position_coords
                slots[1].x, slots[1].y = px, py
                slots[1].width = self._pip.scale
                slots[1].height = self._pip.scale
                slots[1].enabled = True

        elif self._mode == self.MODE_MULTICAM:
            for s in slots:
                s.x, s.y, s.width, s.height = 0, 0, 1, 1
                s.enabled = (s.slot_id == self._active_slot)

    # ── PiP Configuration ───────────────────────────────────

    def set_pip(self, slot_id: str = "B", position: str = "bottom_right",
                scale: float = 0.25, margin: float = 0.02) -> None:
        """Configure Picture-in-Picture."""
        self._pip.enabled = True
        self._pip.slot_id = slot_id
        self._pip.position = position
        self._pip.scale = max(0.1, min(0.5, scale))
        self._pip.margin = max(0.0, min(0.1, margin))
        if self._mode == self.MODE_PIP:
            self._update_slot_positions()

    @property
    def pip_config(self) -> PiPConfig:
        return self._pip

    # ── Multi-Camera Switching ───────────────────────────────

    def add_camera_cut(self, time_seconds: float, to_slot: str,
                       transition: str = "cut",
                       transition_duration: float = 0.0,
                       bpm: float = 120.0) -> CameraCut:
        """Add a camera cut point (multi-cam switching)."""
        cut = CameraCut(
            time_seconds=time_seconds,
            time_beats=time_seconds * bpm / 60.0,
            from_slot=self._active_slot,
            to_slot=to_slot,
            transition=transition,
            transition_duration=transition_duration,
            label=f"Cut → {to_slot}",
        )
        self._camera_cuts.append(cut)
        self._camera_cuts.sort(key=lambda c: c.time_seconds)
        log.info("[VP10] Camera cut at %.2fs: %s → %s (%s)",
                 time_seconds, cut.from_slot, to_slot, transition)
        return cut

    def remove_camera_cut(self, index: int) -> bool:
        if 0 <= index < len(self._camera_cuts):
            self._camera_cuts.pop(index)
            return True
        return False

    def get_active_slot_at(self, time_seconds: float) -> str:
        """Get which slot is active at a given time (for multi-cam mode)."""
        active = self._active_slot or "A"
        for cut in self._camera_cuts:
            if cut.time_seconds <= time_seconds:
                active = cut.to_slot
            else:
                break
        return active

    @property
    def camera_cuts(self) -> List[CameraCut]:
        return list(self._camera_cuts)

    # ── Output Configuration ─────────────────────────────────

    def set_output_resolution(self, width: int, height: int) -> None:
        self._output_width = max(320, width)
        self._output_height = max(240, height)

    # ── ffmpeg Export ─────────────────────────────────────────

    def get_ffmpeg_export_cmd(self, output_path: str,
                               duration: float = 0.0) -> List[str]:
        """Generate ffmpeg command for multi-video export.

        Handles split-view, PiP, overlay, and multi-cam compositing.
        """
        enabled_slots = [s for s in self._slots.values() if s.enabled and s.video_path]

        if not enabled_slots:
            return []

        w = self._output_width
        h = self._output_height
        cmd = ["ffmpeg", "-y"]

        # Input files
        for slot in enabled_slots:
            if slot.offset_seconds > 0:
                cmd.extend(["-ss", f"{slot.offset_seconds:.3f}"])
            cmd.extend(["-i", slot.video_path])

        if len(enabled_slots) == 1:
            # Single video — simple scale
            cmd.extend([
                "-vf", f"scale={w}:{h}:force_original_aspect_ratio=decrease,"
                       f"pad={w}:{h}:(ow-iw)/2:(oh-ih)/2:color=black",
            ])
        elif self._mode == self.MODE_SPLIT_H:
            # Horizontal split: A left, B right
            cmd.extend([
                "-filter_complex",
                f"[0:v]scale={w//2}:{h}[a];"
                f"[1:v]scale={w//2}:{h}[b];"
                f"[a][b]hstack=inputs=2[out]",
                "-map", "[out]",
            ])
        elif self._mode == self.MODE_SPLIT_V:
            # Vertical split: A top, B bottom
            cmd.extend([
                "-filter_complex",
                f"[0:v]scale={w}:{h//2}[a];"
                f"[1:v]scale={w}:{h//2}[b];"
                f"[a][b]vstack=inputs=2[out]",
                "-map", "[out]",
            ])
        elif self._mode == self.MODE_OVERLAY:
            # B overlaid on A
            opacity = enabled_slots[1].opacity if len(enabled_slots) > 1 else 0.5
            cmd.extend([
                "-filter_complex",
                f"[0:v]scale={w}:{h}[a];"
                f"[1:v]scale={w}:{h},format=rgba,"
                f"colorchannelmixer=aa={opacity:.2f}[b];"
                f"[a][b]overlay=0:0[out]",
                "-map", "[out]",
            ])
        elif self._mode == self.MODE_PIP:
            # PiP: A fullscreen, B small in corner
            px, py = self._pip.position_coords
            pw = int(w * self._pip.scale)
            ph = int(h * self._pip.scale)
            ox = int(w * px)
            oy = int(h * py)
            cmd.extend([
                "-filter_complex",
                f"[0:v]scale={w}:{h}[main];"
                f"[1:v]scale={pw}:{ph}[pip];"
                f"[main][pip]overlay={ox}:{oy}[out]",
                "-map", "[out]",
            ])
        elif self._mode == self.MODE_MULTICAM:
            # Multi-cam: generate timeline-based switching
            # For simplicity, use the first camera cut to select segments
            if self._camera_cuts and len(enabled_slots) >= 2:
                # Build concat filter with segments
                segments = []
                slot_map = {s.slot_id: i for i, s in enumerate(enabled_slots)}
                prev_time = 0.0
                for cut in self._camera_cuts:
                    active = self.get_active_slot_at(prev_time)
                    idx = slot_map.get(active, 0)
                    dur = cut.time_seconds - prev_time
                    if dur > 0:
                        segments.append((idx, prev_time, dur))
                    prev_time = cut.time_seconds
                # Last segment
                active = self.get_active_slot_at(prev_time)
                idx = slot_map.get(active, 0)
                if duration > prev_time:
                    segments.append((idx, prev_time, duration - prev_time))

                if segments:
                    filter_parts = []
                    for i, (src_idx, start, dur) in enumerate(segments):
                        filter_parts.append(
                            f"[{src_idx}:v]trim=start={start:.3f}:duration={dur:.3f},"
                            f"setpts=PTS-STARTPTS,scale={w}:{h}[seg{i}]"
                        )
                    seg_labels = "".join(f"[seg{i}]" for i in range(len(segments)))
                    filter_parts.append(
                        f"{seg_labels}concat=n={len(segments)}:v=1:a=0[out]"
                    )
                    cmd.extend([
                        "-filter_complex",
                        ";".join(filter_parts),
                        "-map", "[out]",
                    ])
            else:
                # Fallback: just use slot A
                cmd.extend([
                    "-vf", f"scale={w}:{h}",
                ])

        # Output settings
        if duration > 0:
            cmd.extend(["-t", f"{duration:.3f}"])
        cmd.extend([
            "-c:v", "libx264",
            "-preset", "medium",
            "-crf", "23",
            "-pix_fmt", "yuv420p",
            output_path,
        ])

        return cmd

    # ── Persistence ──────────────────────────────────────────

    def save_state(self) -> dict:
        """Serialize entire multi-video state."""
        return {
            "mode": self._mode,
            "active_slot": self._active_slot,
            "output_width": self._output_width,
            "output_height": self._output_height,
            "slots": {sid: s.to_dict() for sid, s in self._slots.items()},
            "pip": self._pip.to_dict(),
            "camera_cuts": [c.to_dict() for c in self._camera_cuts],
        }

    def load_state(self, data: dict) -> None:
        """Restore multi-video state from dict."""
        try:
            self._mode = data.get("mode", self.MODE_SINGLE)
            self._active_slot = data.get("active_slot", "A")
            self._output_width = int(data.get("output_width", 1920))
            self._output_height = int(data.get("output_height", 1080))

            self._slots.clear()
            for sid, sd in data.get("slots", {}).items():
                self._slots[sid] = VideoSlot.from_dict(sd)

            pip_data = data.get("pip", {})
            if pip_data:
                self._pip = PiPConfig.from_dict(pip_data)

            self._camera_cuts = [
                CameraCut.from_dict(c) for c in data.get("camera_cuts", [])
            ]

            log.info("[VP10] State loaded: %d slots, mode=%s, %d cuts",
                     len(self._slots), self._mode, len(self._camera_cuts))
        except Exception as e:
            log.debug("[VP10] load_state error: %s", e)

    def save_to_db(self, db) -> None:
        """Save to project database."""
        try:
            json_str = json.dumps(self.save_state())
            if hasattr(db, 'set_meta'):
                db.set_meta("vp10_multi_video", json_str)
            elif hasattr(db, 'execute'):
                db.execute(
                    "INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
                    ("vp10_multi_video", json_str),
                )
                db.commit()
        except Exception as e:
            log.debug("[VP10] save_to_db: %s", e)

    def load_from_db(self, db) -> None:
        """Load from project database."""
        try:
            json_str = None
            if hasattr(db, 'get_meta'):
                json_str = db.get_meta("vp10_multi_video")
            elif hasattr(db, 'execute'):
                row = db.execute(
                    "SELECT value FROM meta WHERE key = ?",
                    ("vp10_multi_video",),
                ).fetchone()
                if row:
                    json_str = row[0]
            if json_str:
                self.load_state(json.loads(json_str))
        except Exception as e:
            log.debug("[VP10] load_from_db: %s", e)

    # ── Convenience ──────────────────────────────────────────

    def setup_ab_comparison(self, path_a: str, path_b: str,
                             mode: str = "split_h") -> None:
        """Quick setup for A/B video comparison."""
        self.add_slot("A", path_a, "Video A")
        self.add_slot("B", path_b, "Video B")
        self.set_mode(mode)

    def setup_multicam(self, paths: Dict[str, str],
                        bpm: float = 120.0) -> None:
        """Quick setup for multi-camera project.

        Args:
            paths: {"A": "/path/a.mp4", "B": "/path/b.mp4", ...}
        """
        for slot_id, path in paths.items():
            self.add_slot(slot_id, path, f"Kamera {slot_id}")
        self.set_mode(self.MODE_MULTICAM)
        self._active_slot = next(iter(paths), "A")

    def setup_pip(self, main_path: str, pip_path: str,
                   position: str = "bottom_right",
                   scale: float = 0.25) -> None:
        """Quick setup for PiP."""
        self.add_slot("A", main_path, "Hauptvideo")
        self.add_slot("B", pip_path, "Bild-in-Bild")
        self.set_pip("B", position, scale)
        self.set_mode(self.MODE_PIP)
