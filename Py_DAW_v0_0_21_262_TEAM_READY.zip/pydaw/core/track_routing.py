"""
pydaw.core.track_routing
========================

Single source of truth for the question:

    "Does the Rust audio engine host the instrument on this track,
     or does Python's pull-source pipeline render it?"

This helper exists because the question used to be answered with subtly
different inline logic in three different places:

    * pydaw/audio/arrangement_renderer.py  (live-MIDI dispatch path)
    * pydaw/audio/audio_engine.py           (engine-map build)
    * pydaw/services/rust_sample_sync.py    (sync branching)

History (see CHANGELOG_v0.0.21.16x):

    * v0.0.21.053 R2 introduced a coarse "skip all instruments when Rust
      hosts MIDI instruments" filter — that broke SF2.
    * v0.0.21.161/162/163 fixed it by refining the filter to "skip only
      tracks Rust ACTUALLY hosts" — but the refined logic still lived
      inline in arrangement_renderer.py:725.
    * v0.0.21.165 (this module) extracts that logic into one tested
      helper so the next change has exactly one place to land.

Rules of thumb:

    * Rust hosts: VST2/VST3/CLAP/LV2/LADSPA — everything that has an
      external shared-object plugin file path (*.so / *.vst3 / *.clap /
      *.dylib / *.dll) OR an explicit plugin_type in that family.
    * Python hosts: SF2 (FluidSynth wrapper), Advanced Sampler,
      MultiSample, Drum Machine, Wavetable, BachOrgel, Aeterna, Fusion,
      BRRR Flutter, builtin synths — i.e. every Python pull-source
      instrument registered with SamplerRegistry.
"""

from __future__ import annotations

import logging
from typing import Any, Iterable

logger = logging.getLogger(__name__)

# v0.0.21.165: keep these in one place — the file extensions and plugin_type
# values that mean "this instrument is hosted by the Rust audio engine".
_RUST_PLUGIN_EXTENSIONS: tuple[str, ...] = (
    ".vst3",
    ".clap",
    ".so",
    ".dylib",
    ".dll",
)

_RUST_PLUGIN_TYPES: frozenset[str] = frozenset(
    {"vst2", "vst3", "clap", "lv2", "ladspa"}
)

# v0.0.21.205 — Rust-Migration der Built-In-Instrumente.
# Diese Plugin-IDs werden inzwischen vom Rust-Engine gehostet (siehe
# `pydaw_engine::instruments::*`). Wenn ein Track einen dieser Plugin-Typen
# hat, MUSS sein Python-Side-pull_source-Pfad im hybrid_callback bypassed
# werden — sonst rendert Python die Audio parallel zur Rust-Version und
# beide werden im Master gemischt → Phasing/Comb-Filtering ("blechern")
# und Timing-Drift-Knacksen.
#
# Bewusst NICHT in der Liste: ``chrono.sf2`` — SF2/FluidSynth läuft
# weiterhin Python-side via SharedMemory-Brücke. ``chrono.wavetable``
# ist ebenfalls nicht migriert (Stand v.205).
#
# v0.0.21.206b: ``chrono.pro_audio_sampler`` und ``chrono.multi_sample``
# nachgereicht. Anno meldete „Pro Audio Sampler klingt genauso blechern
# wie Drum Machine vor v.205". Diagnose: beide sind in
# ``pydaw/services/engine_migration.py::_RUST_INSTRUMENTS`` als
# Rust-hosted markiert, fehlten aber in dieser Liste — exakt derselbe
# Doppel-Render-Bug wie v.205 für Drum Machine, nur für Sampler.
# WICHTIG: Diese Liste MUSS synchron mit ``_RUST_INSTRUMENTS`` in
# ``engine_migration.py`` gehalten werden. v.207 plant einen
# automatischen Konsistenz-Check beim Boot.
_RUST_HOSTED_BUILTIN_PLUGIN_TYPES: frozenset[str] = frozenset({
    "chrono.pro_drum_machine",
    "chrono.drum_machine",
    "chrono.pro_sampler",
    "chrono.pro_audio_sampler",   # v0.0.21.206b — Anno-Report Doppel-Render
    "chrono.advanced_sampler",
    "chrono.multi_sample",        # v0.0.21.206b — analog Pro Audio Sampler
    "chrono.fusion",
    "chrono.brrr",
    "chrono.aeterna",
    "chrono.bach_orgel",
})


def _path_matches_rust_extension(plugin_path: str) -> bool:
    """True if plugin_path points to a file with a Rust-hostable extension.

    We accept both "endswith" (normal case: '/usr/lib/vst3/Surge XT.vst3')
    AND "ext anywhere in path" (bundle case: '.vst3' may appear as a
    directory component on macOS-style bundles cross-compiled to Linux).
    Both forms were tolerated in the v.163 inline check; we preserve that.
    """
    if not plugin_path:
        return False
    p = plugin_path.lower()
    return any(p.endswith(ext) or ext in p for ext in _RUST_PLUGIN_EXTENSIONS)


def _normalize_plugin_type(plugin_type: Any) -> str:
    if plugin_type is None:
        return ""
    return str(plugin_type).strip().lower()


def is_rust_hosted_instrument(track: Any) -> bool:
    """Return True iff the Rust engine hosts this track's instrument.

    Looks at two signals on the track object:
        1. plugin_path (preferred — fewer false positives, plugin_type is
           often missing or stale on legacy projects).
        2. plugin_type as fallback when plugin_path is empty/missing.

    A track that is NOT an instrument track at all (audio, master, bus,
    automation-only) trivially returns False — it has no instrument for
    Rust to host.

    This function is the inverse of "needs Python live-MIDI dispatch for
    its instrument". The two questions together are mutually exclusive
    for instrument tracks: every instrument is either Rust-hosted (skip
    Python MIDI dispatch) or Python-hosted (do dispatch).
    """
    # Defensive: callers pass project tracks of varying types
    # (dataclass, dict, attrs object). getattr() handles all.
    if track is None:
        return False

    # Only instrument tracks can be Rust-hosted instruments. Audio,
    # master, bus, send tracks have no instrument plugin at all.
    kind = str(getattr(track, "kind", "") or "")
    if kind and kind != "instrument":
        return False

    # Signal 1 — plugin_path
    plugin_path = str(getattr(track, "plugin_path", "") or "")
    if _path_matches_rust_extension(plugin_path):
        return True

    # Signal 2 — plugin_type fallback (external plugins via family name)
    plugin_type = _normalize_plugin_type(getattr(track, "plugin_type", None))
    if plugin_type in _RUST_PLUGIN_TYPES:
        return True

    # Signal 3 — v0.0.21.205: Rust-migrierte Built-In-Instrumente.
    # Plugin-IDs wie ``chrono.pro_drum_machine`` werden direkt verglichen.
    # Diese Erweiterung ist der Gegen-Hotfix für v.21.16x: der Filter war
    # auf externe Plugins begrenzt, alle migrierten Built-Ins (DrumMachine,
    # Fusion, Bach Orgel, …) wurden fälschlich als Python-hosted klassifiziert
    # → doppelte Audio-Generation (Python-pull + Rust) → "blechern" + Knacksen.
    if plugin_type in _RUST_HOSTED_BUILTIN_PLUGIN_TYPES:
        return True

    return False


def is_python_hosted_instrument(track: Any) -> bool:
    """Return True iff the Python pull-source pipeline owns this track.

    Convenience for callers that want the positive form (e.g. "should I
    register a SamplerRegistry engine for this track?"). Returns True
    only for instrument tracks that are NOT Rust-hosted — bus/audio/
    master tracks return False.
    """
    if track is None:
        return False
    kind = str(getattr(track, "kind", "") or "")
    if kind and kind != "instrument":
        return False
    return not is_rust_hosted_instrument(track)


def classify_tracks(tracks: Iterable[Any]) -> dict[str, list[Any]]:
    """Bucket an iterable of tracks into routing classes for diagnostics.

    Returns:
        {
            "rust_hosted":    [track, ...],   # Rust hosts the instrument
            "python_hosted":  [track, ...],   # Python pull-source
            "audio":          [track, ...],   # audio/master/bus/etc.
        }

    Useful for one-line debug logs at engine-map build time:

        buckets = classify_tracks(project.tracks)
        logger.debug(
            "[ROUTING] rust=%d py=%d audio=%d",
            len(buckets["rust_hosted"]),
            len(buckets["python_hosted"]),
            len(buckets["audio"]),
        )
    """
    rust: list[Any] = []
    py: list[Any] = []
    audio: list[Any] = []
    for t in tracks:
        kind = str(getattr(t, "kind", "") or "")
        if kind and kind != "instrument":
            audio.append(t)
        elif is_rust_hosted_instrument(t):
            rust.append(t)
        else:
            py.append(t)
    return {"rust_hosted": rust, "python_hosted": py, "audio": audio}


__all__ = [
    "is_rust_hosted_instrument",
    "is_python_hosted_instrument",
    "classify_tracks",
]
